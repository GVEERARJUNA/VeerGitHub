﻿using P2OBAL.Common;

namespace P2OBAL.PurchaseRequistion
{
    public interface IPurchaseRequistionBL
    {
        ResponseClass CreatePurchaseRequistion(PurchaseRequistionDTO shoppingCart);
    }
}