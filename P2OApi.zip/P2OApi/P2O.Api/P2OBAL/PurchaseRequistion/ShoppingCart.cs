﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.PurchaseRequistion
{
    public class ShoppingCart
    {
        public string PurchaseTypeCode { get; set; }
        public string PurchaseType { get; set; }
        public string PurchaseGroup { get; set; }
        public string Currency { get; set; }
        public string CostCenterFlag { get; set; }
        public string CostCenterCode { get; set; }
        public string CostCenter { get; set; }
        public string PlantCode { get; set; }
        public string PlantName { get; set; }
        public string PurchaseOrganisationCode { get; set; }
        public string PurchaseOrganisation { get; set; }
        public string VendorCode { get; set; }
        public string Vendor { get; set; }
        public string OnBehalfOfFlag { get; set; }
        public string CreatorCode { get; set; }
        public string CreatorName { get; set; }

        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

        public List<ShoppingCartDetails> shoppingCartDetails { get; set; }
    }

    public class ShoppingCartDetails
    {
        public string CartDetailNo { get; set; }
        public string MaterialCode { get; set; }
        public string MaterialDescription { get; set; }
        public string GLCode { get; set; }
        public string ProductType { get; set; }
        public double MaterialAmount { get; set; }
        public int MaterialQuantity { get; set; }

        public double NetAmount { get; set; }
        public string NeededByDate { get; set; }
        public string Comments { get; set; }
    }
}
