﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace P2OBAL.Common
{
    public class WriteLogFile
    {
        public static bool WriteLog(string strFileName, string strMessage)
        {
            try
            {
                string inputFileName = Path.Combine("D:/vsites/P2OAPI/P2OLogger/APILogs/");
                if (strFileName.ToLower() == "information")
                {
                    strFileName = "information";
                }
                else if (strFileName.ToLower() == "exception")
                {
                    strFileName = "Exception";
                }
                string path = string.Empty;

                path = inputFileName + "/" + DateTime.Now.ToString("yyyy-MM-dd");

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                FileStream objFilestream = new FileStream(string.Format("{0}\\{1}", path, strFileName), FileMode.Append, FileAccess.Write);
                StreamWriter objStreamWriter = new StreamWriter((Stream)objFilestream);
                objStreamWriter.WriteLine(strMessage);
                objStreamWriter.Close();
                objFilestream.Close();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
