﻿namespace P2OBAL.Common
{
    public interface IFireBaseAPICallBL
    {
        string FBCall(string devicetoken, string title, string body);
    }
}