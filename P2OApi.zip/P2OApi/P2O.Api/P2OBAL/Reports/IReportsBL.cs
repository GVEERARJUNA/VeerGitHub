﻿using P2OBAL.Common;

namespace P2OBAL.Reports
{
    public interface IReportsBL
    {
        ResponseClass GetPRReport(PRReportRequestDTO pRReportRequestDTO);
        ResponseClass GetHistoricalReport(HistoricalReportDTO historicalReportDTO);
        ResponseClass GetUserDashboard(UserDashboardRequestDTO userDashboardRequestDTO);
        ResponseClass GetRDAccress(UserDashboardRequestDTO userDashboardRequestDTO);

        ResponseClass GetWorkFlowReport(WorkflowReportrequestDTO request);
    }
}