﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Reports
{
    public class PRReportRequestDTO
    {
        public string ReportType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string SearchCriteria1 { get; set; }
        public string SearchCriteria2 { get; set; }


        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public string UserName { get; set; }
        public string CurrentRole { get; set; }
    }
    public class HistoricalReportDTO
    {
        public string ReportName { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string CustomParam1 { get; set; }
        public string CustomParam2 { get; set; }
        public string CustomParam3 { get; set; }
        public string CustomParam4 { get; set; }
        public string CustomParam5 { get; set; }
        public string CustomParam6 { get; set; }
        public string CustomParam7 { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public string LoginID { get; set; }
        public string CurrentRole { get; set; }
    }

    public class UserDashboardRequestDTO
    {
        public string LoginID { get; set; }
        public string CompanyCode { get; set; }
        public string CurrentRole { get; set; }
        public string ReportType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string SearchCriteria1 { get; set; }
        public string SearchCriteria2 { get; set; }
        public string SearchCriteria3 { get; set; }
        public string SearchCriteria4 { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }

    public class WorkflowReportrequestDTO
    {
        public string CompanyCode { get; set; }
    }

    public class WorkFlowLevelResponse
    {
        public string CostCenterCode { get; set; }
        public int AppLevel { get; set; }
        public string EMPCode { get; set; }

        public double FromAmount { get; set; }
        public double ToAmount { get; set; }
        public string CalculateSymbol { get; set; }
    }
}
