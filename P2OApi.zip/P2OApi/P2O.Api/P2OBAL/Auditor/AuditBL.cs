﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;

namespace P2OBAL.Auditor
{
    public class AuditBL : IAuditBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;


        public AuditBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass InsertAdminActivityLog(AdminActivityLogInsertDTO adminActivityLogInsertDTO)
        {
            ResponseClass response = new ResponseClass();

            List<OutParameter> outParameters = new List<OutParameter>();

            SqlParameter[] parameter = {
                new SqlParameter("@ActionEmployeeID", Convert.ToString(adminActivityLogInsertDTO.ActionEmployeeID)),
                new SqlParameter("@ActivityAction", Convert.ToString(adminActivityLogInsertDTO.ActivityAction)),
                new SqlParameter("@ActivitySubject", Convert.ToString(adminActivityLogInsertDTO.ActivitySubject)),
                new SqlParameter("@ActivityLog", Convert.ToString(adminActivityLogInsertDTO.ActivityLog)),
                new SqlParameter("@OldValue", Convert.ToString(adminActivityLogInsertDTO.OldValue)),
                new SqlParameter("@NewValue", Convert.ToString(adminActivityLogInsertDTO.NewValue)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            int result = dBConnection.ExecuteNonQuery("PRC_Admin_Activity_log", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");
            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;

            return response;

        }
    }
}
