﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Auditor
{
   public class AdminActivityLogInsertDTO
    {
        public string ActionEmployeeID { get; set; }
        public string ActivityAction { get; set; }
        public string ActivitySubject { get; set; }
        public string ActivityLog { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
    }
}
