﻿using P2OBAL.Common;

namespace P2OBAL.Auditor
{
    public interface IAuditBL
    {
        ResponseClass InsertAdminActivityLog(AdminActivityLogInsertDTO adminActivityLogInsertDTO);
    }
}