﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2OBAL.EmailMgt;
using P2OBAL.Error;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;


namespace P2OBAL.Approval
{
    public class ApprovalBL : IApprovalBL
    {
        private IErrorBL _ErrorBL;
        private readonly IOptions<IDBConnection> appSettings;
        ErrorDTO errorDTO = new ErrorDTO();
        private IEmailManagementBL _emailManagementBL;

        DBConnection dBConnection;

        public ApprovalBL(IOptions<IDBConnection> app, IErrorBL ErrorBL, IEmailManagementBL managementBL)
        {
            appSettings = app;
            dBConnection = new DBConnection(appSettings.Value.DbConnection);
            _ErrorBL = ErrorBL;
            errorDTO = new ErrorDTO();
            errorDTO.FileName = "ApprovalBL";
            errorDTO.Source = "API";
             _emailManagementBL = managementBL;
        }

        public ResponseClass GetApprovalLevels(ApprovalRequestDTO approvalRequestBO)
        {
           ResponseClass response = new ResponseClass();
            try
            {
                if (approvalRequestBO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "approvalRequestBO required";
                    return response;
                }


                if (string.IsNullOrEmpty(approvalRequestBO.LoggedInEmpId))
                {
                    response.responseCode = 0;
                    response.responseMessage = "approvalRequestBO.LoggedInEmpId required!";
                    return response;
                }

                if (approvalRequestBO.PurchaseRequistionID == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "approvalRequestBO.PurchaseRequistionID required!";
                    return response;
                }


                SqlParameter[] parameter = {
                new SqlParameter("@LoggedInEmpId", approvalRequestBO.LoggedInEmpId),
                new SqlParameter("@PurchaseRequistionID", approvalRequestBO.PurchaseRequistionID)

            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_GetApprovalTree", parameter, outParameters);


                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    dsResult.Tables[0].TableName = "DistinctLevel";
                    dsResult.Tables[1].TableName = "ApprovalData";
                    response.responseJSON = JsonConvert.SerializeObject(dsResult);
                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch(Exception ex)
            {
                errorDTO.ErrorDescription = ex.Message;
                errorDTO.Url = "Approval/GetApprovalLevels";
                response = _ErrorBL.SaveErrorDetails(errorDTO);
                response.responseCode = -1;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetWaitingForApprovalList(ApprovalRequestDTO approvalRequestBO)
        {
            ResponseClass response = new ResponseClass();

            if (approvalRequestBO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "approvalRequestBO required";
                return response;
            }


            if (string.IsNullOrEmpty(approvalRequestBO.LoggedInEmpId))
            {
                response.responseCode = 0;
                response.responseMessage = "approvalRequestBO.LoggedInEmpId required!";
                return response;
            }
            if (approvalRequestBO.SearchText == "")
            {
                approvalRequestBO.SearchText = null;
            }
            if (approvalRequestBO.SearchBy == "")
            {
                approvalRequestBO.SearchBy = null;
            }

            SqlParameter[] parameter = {
                new SqlParameter("@SAPCompanyCode", Convert.ToString(approvalRequestBO.SAPCompanyCode)),
                new SqlParameter("@LoggedInEmpId", approvalRequestBO.LoggedInEmpId),
                new SqlParameter("@RequistionNo", Convert.ToString(approvalRequestBO.requistionNo)),
                //new SqlParameter("@CostCentre", Convert.ToString(approvalRequestBO.CostCentre)),
                new SqlParameter("@SearchType", approvalRequestBO.SearchType),
                new SqlParameter("@SearchBy", approvalRequestBO.SearchBy),
                new SqlParameter("@SearchText", approvalRequestBO.SearchText),
                new SqlParameter("@PageNumber", approvalRequestBO.PageNumber),
                new SqlParameter("@RowsOfPage", approvalRequestBO.RowsOfPage),
                new SqlParameter("@SearchCriteria1", Convert.ToString(approvalRequestBO.SearchCriteria1)),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            try
            {
                dsResult = dBConnection.ExecuteDataSet("USP_GetWaitingForApprovalData", parameter, outParameters);

            }
            catch (Exception e)
            {

            }


            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                if (Convert.ToString(approvalRequestBO.SearchType) == "RAISED" || Convert.ToString(approvalRequestBO.SearchType) == "APPROVED" || Convert.ToString(approvalRequestBO.SearchType).ToLower() == "rejected")
                {
                    if (approvalRequestBO.PageNumber != -1 && approvalRequestBO.PageNumber!=0)
                    {
                        OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / approvalRequestBO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
            }

            response.responseCode = 1;
            response.responseMessage = "SUCCESS";

            return response;
        }

        public ResponseClass ApprovalstatusUpdate(ApprovalSatatusUpdateRequestDTO updateRequestDTO)
        {
            ResponseClass response = new ResponseClass();


            if (updateRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "updateRequestDTO required";
                return response;
            }
            if (updateRequestDTO.ApproverId == "")
            {
                response.responseCode = 0;
                response.responseMessage = "ApproverId is required";
                return response;
            }
            if (updateRequestDTO.PRApprovalMatrixID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "MatrixId is required";
                return response;
            }
            if (updateRequestDTO.PurchaseRequistionID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "PurchaseRequistionID is required";
                return response;
            }
            if (updateRequestDTO.ApprovalLevel == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Approval Level is required";
                return response;
            }
            if (updateRequestDTO.ApprovalStatus == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Approval Status is required";
                return response;
            }
            if (updateRequestDTO.Remark == "")
            {
                response.responseCode = 0;
                response.responseMessage = "Remark is required";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                    new SqlParameter("@ApproverId", updateRequestDTO.ApproverId),
                    new SqlParameter("@PRApprovalMatrixID", updateRequestDTO.PRApprovalMatrixID),
                    new SqlParameter("@PurchaseRequistionID", updateRequestDTO.PurchaseRequistionID),
                    new SqlParameter("@ApprovalLevel",updateRequestDTO.ApprovalLevel),
                    new SqlParameter("@ApprovalStatus",updateRequestDTO.ApprovalStatus),
                    new SqlParameter("@Remark",updateRequestDTO.Remark),
                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("PRC_Update_Approval_Status", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

                if (response.responseCode==1)
                {
                    try
                    {
                        EmailManagementDTO emailManagementDTO = new EmailManagementDTO();
                        if (updateRequestDTO.ApprovalStatus==4 || updateRequestDTO.ApprovalStatus == 8)
                        {
                            emailManagementDTO.EmailType = "Approver";
                        }
                        if (updateRequestDTO.ApprovalStatus == 3)
                        {
                            emailManagementDTO.EmailType = "Reject";
                        }
                        if (updateRequestDTO.ApprovalStatus == 2)
                        {
                            emailManagementDTO.EmailType = "Referback";
                        }
                        //emailManagementDTO.RequistionNo = response.responseReturnNo;
                        emailManagementDTO.PRID = Convert.ToString(updateRequestDTO.PurchaseRequistionID);
                        
                        ResponseClass responseEmail = new ResponseClass();
                        responseEmail = _emailManagementBL.GetEmailContent(emailManagementDTO);
                    }
                    catch (Exception)
                    {


                    }
                }
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetPREntity(GetPREntityRequest getPRNotesRequest)
        {
            ResponseClass response = new ResponseClass();

            if (getPRNotesRequest == null)
            {
                response.responseCode = 0;
                response.responseMessage = "getPRNotesRequest required";
                return response;
            }


            if (getPRNotesRequest.PurchaseRequistionID==0)
            {
                response.responseCode = 0;
                response.responseMessage = "getPRNotesRequest.PurchaseRequistionID required!";
                return response;
            }

            SqlParameter[] parameter = {
                new SqlParameter("@PurchaseRequistionID", getPRNotesRequest.PurchaseRequistionID),
                new SqlParameter("@SearchType", getPRNotesRequest.SearchType)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_Get_PREntity", parameter, outParameters);


            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
            }

            response.responseCode = 1;
            response.responseMessage = "SUCCESS";

            return response;
        }

        public ResponseClass GetPRRequistionDataByRequistionNo(PRRequistionDataRequestDTO pRRequistionDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (pRRequistionDataRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "pRRequistionDataRequestDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(pRRequistionDataRequestDTO.LoggedInEmpId))
            {
                response.responseCode = 0;
                response.responseMessage = "pRRequistionDataRequestDTO.LoggedInEmpId required!";
                return response;
            }

            string requistionNo = (Convert.ToString(pRRequistionDataRequestDTO.requistionNo));
            string approvalEmpCode = (Convert.ToString(pRRequistionDataRequestDTO.LoggedInEmpId));

            SqlParameter[] parameter = {
                new SqlParameter("@LoggedInEmpId", approvalEmpCode),
                new SqlParameter("@RequistionNo", requistionNo),
                new SqlParameter("@AppSource",Convert.ToString(pRRequistionDataRequestDTO.AppSource)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("USP_GetPRDataByRequistionNo", parameter, outParameters);
            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
            }

            //response.responseCode = 1;
            //response.responseMessage = "SUCCESS";

            return response;
        }

        public ResponseClass UpdatePRDetail(UpdatePRDetailRequest updatePRDetailRequest)
        {
            ResponseClass response = new ResponseClass();
            string nDate = string.Empty;
            string WSDate = string.Empty;
            string WEDate = string.Empty;

            if (updatePRDetailRequest == null)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest required";
                return response;
            }
            if (updatePRDetailRequest.Action.ToUpper()=="EDIT")
            {
                if (updatePRDetailRequest.PurchaseRequistionDetailID == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePRDetailRequest.PurchaseRequistionDetailID is required";
                    return response;
                }
                if (updatePRDetailRequest.Quantity == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePRDetailRequest.Quantity required";
                    return response;
                }
                if (updatePRDetailRequest.Amount == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePRDetailRequest.Amount is required";
                    return response;
                }
            }
            if (updatePRDetailRequest.Action.ToUpper() == "ADD")
            {
                if (updatePRDetailRequest.PurchaseRequistionID == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePRDetailRequest.PurchaseRequistionID is required";
                    return response;
                }
                if (updatePRDetailRequest.Quantity == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePRDetailRequest.Quantity required";
                    return response;
                }
                if (updatePRDetailRequest.Amount == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePRDetailRequest.Amount is required";
                    return response;
                }
            }
            if (updatePRDetailRequest.Action.ToUpper() == "DELETE")
            {
                if (updatePRDetailRequest.PurchaseRequistionDetailID == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePRDetailRequest.PurchaseRequistionDetailID is required";
                    return response;
                }
                
            }

            if (updatePRDetailRequest.Action.ToUpper() == "ADD" || updatePRDetailRequest.Action.ToUpper() == "EDIT")

            {
                if (!string.IsNullOrEmpty(updatePRDetailRequest.NeededByDate))
                {
                    try
                    {
                        nDate = Convert.ToDateTime(updatePRDetailRequest.NeededByDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion needed by date :" + ex.Message);

                    }
                }

                if (!string.IsNullOrEmpty(updatePRDetailRequest.WarrantyStartDate))
                {
                    try
                    {
                        WSDate = Convert.ToDateTime(updatePRDetailRequest.WarrantyStartDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion warranty start date :" + ex.Message);

                    }
                }

                if (!string.IsNullOrEmpty(updatePRDetailRequest.WarrantyEndDate))
                {
                    try
                    {
                        WEDate = Convert.ToDateTime(updatePRDetailRequest.WarrantyEndDate).ToString("yyyy-MM-dd");
                    }
                    catch (Exception ex)
                    {

                        WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion Warranty end date :" + ex.Message);
                    }
                }
            }

               



            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                    new SqlParameter("@PurchaseRequistionDetailID", updatePRDetailRequest.PurchaseRequistionDetailID),
                    new SqlParameter("@Quantity", updatePRDetailRequest.Quantity),
                    new SqlParameter("@Amount", updatePRDetailRequest.Amount),
                    new SqlParameter("@InsertedBy",Convert.ToString(updatePRDetailRequest.InsertedBy)),
                    new SqlParameter("@InsertedIPAddress",Convert.ToString(updatePRDetailRequest.InsertedIPAddress)),
                    new SqlParameter("@PurchaseRequistionID", updatePRDetailRequest.PurchaseRequistionID),
                    new SqlParameter("@Action", Convert.ToString(updatePRDetailRequest.Action)),
                    new SqlParameter("@MaterialCode", Convert.ToString(updatePRDetailRequest.MaterialCode)),
                    new SqlParameter("@ShortText", Convert.ToString(updatePRDetailRequest.ShortText)),
                    new SqlParameter("@GLCode", Convert.ToString(updatePRDetailRequest.GLCode)),
                    new SqlParameter("@LineComments", Convert.ToString(updatePRDetailRequest.LineComments)),
                    new SqlParameter("@CatalogueDataID", updatePRDetailRequest.CatalogueDataID),
                    new SqlParameter("@WarrantyStartDate", Convert.ToString(WSDate)),
                    new SqlParameter("@WarrantyEndDate", Convert.ToString(WEDate)),
                    new SqlParameter("@NeededByDate", Convert.ToString(nDate)),
                    
                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("PRC_UpdatePRDetails", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

               
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetPRVirtualFlow(PRVirtualFlowRequestDTO prVirtualFlow)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                if (prVirtualFlow == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "prVirtualFlow required";
                    return response;
                }


                if (string.IsNullOrEmpty(prVirtualFlow.CostCenterCode))
                {
                    response.responseCode = 0;
                    response.responseMessage = "prVirtualFlow.CostCenterCode required!";
                    return response;
                }
                if (string.IsNullOrEmpty(prVirtualFlow.PurchaseGroup))
                {
                    response.responseCode = 0;
                    response.responseMessage = "prVirtualFlow.PurchaseGroup required!";
                    return response;
                }

                if (prVirtualFlow.PurchaseTypeID == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "prVirtualFlow.PurchaseTypeID required!";
                    return response;
                }

                if (string.IsNullOrEmpty(prVirtualFlow.CreatorCode))
                {
                    response.responseCode = 0;
                    response.responseMessage = "prVirtualFlow.CreatorCode required!";
                    return response;
                }
                if (prVirtualFlow.TotalAmount == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "prVirtualFlow.TotalAmount required!";
                    return response;
                }

                SqlParameter[] parameter = {
                new SqlParameter("@CostCenterCode", Convert.ToString(prVirtualFlow.CostCenterCode)),
                new SqlParameter("@PurchaseTypeID", prVirtualFlow.PurchaseTypeID),
                new SqlParameter("@PurchaseGroup", Convert.ToString(prVirtualFlow.PurchaseGroup)),
                new SqlParameter("@TotalAmount", prVirtualFlow.TotalAmount),
                new SqlParameter("@CreatorCode", Convert.ToString(prVirtualFlow.CreatorCode)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_Create_Virtual_AppFlow", parameter, outParameters);


                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    dsResult.Tables[0].TableName = "DistinctLevel";
                    dsResult.Tables[1].TableName = "ApprovalData";
                    response.responseJSON = JsonConvert.SerializeObject(dsResult);
                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                errorDTO.ErrorDescription = ex.Message;
                errorDTO.Url = "Approval/GetApprovalLevels";
                response = _ErrorBL.SaveErrorDetails(errorDTO);
                response.responseCode = -1;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass UpdatePRHeaderRequest(UpdatePRRequest request)
        {
            ResponseClass response = new ResponseClass();
            string nDate = string.Empty;
            string WSDate = string.Empty;
            string WEDate = string.Empty;

            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request required";
                return response;
            }
            if (request.PurchaseRequistionID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.PurchaseRequistionID is required";
                return response;
            }
            if (string.IsNullOrEmpty(request.CostCenterCode))
            {
                response.responseCode = 0;
                response.responseMessage = "request.CostCenterCode is required";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                    new SqlParameter("@PurchaseRequistionID", request.PurchaseRequistionID),
                    new SqlParameter("@InsertedBy",Convert.ToString(request.InsertedBy)),
                    new SqlParameter("@InsertedIPAddress",Convert.ToString(request.InsertedIPAddress)),
                    new SqlParameter("@CostCenterCode", Convert.ToString(request.CostCenterCode)),
                    new SqlParameter("@PurchaseTypeCode", Convert.ToString(request.PurchaseTypeCode)),
                    new SqlParameter("@PurchaseGroup", Convert.ToString(request.PurchaseGroup)),
                    new SqlParameter("@PlantCode", Convert.ToString(request.PlantCode)),
                    new SqlParameter("@PurchaseOrganisationCode", Convert.ToString(request.PurchaseOrganisationCode)),
                    new SqlParameter("@VendorCode", Convert.ToString(request.VendorCode)),
                    new SqlParameter("@CurrencyCode", Convert.ToString(request.CurrencyCode)),
                    new SqlParameter("@OnBehalfOf", Convert.ToString(request.OnBehalfOfFlag)),
                    new SqlParameter("@CreatorCode", Convert.ToString(request.CreatorCode)),

                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("PRC_change_pr_header_details", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);


            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass AddPRFiles(PRFilesDTO pRFilesDTO)
        {
            ResponseClass response = new ResponseClass();
            string nDate = string.Empty;
            string WSDate = string.Empty;
            string WEDate = string.Empty;

            if (pRFilesDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request required";
                return response;
            }
            if (pRFilesDTO.PRID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.PurchaseRequistionID is required";
                return response;
            }
            if (string.IsNullOrEmpty(pRFilesDTO.FileName))
            {
                response.responseCode = 0;
                response.responseMessage = "FileName is required";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                    new SqlParameter("@PurchaseRequistionID", pRFilesDTO.PRID),
                    new SqlParameter("@FileName",Convert.ToString(pRFilesDTO.FileName)),
                    new SqlParameter("@Action",Convert.ToString(pRFilesDTO.Action)),
                    new SqlParameter("@FilePath",Convert.ToString(pRFilesDTO.FilePath)),
                    new SqlParameter("@FileContent",Convert.ToString(pRFilesDTO.FileContent)),
                    new SqlParameter("@InsertedEMPCode",Convert.ToString(pRFilesDTO.InsertedEMPCode)),
                    new SqlParameter("@InsertedIPAddress",Convert.ToString(pRFilesDTO.InsertedIPAddress)),

                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("PRC_insertPRFilesEdit", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);


            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

    }
}
