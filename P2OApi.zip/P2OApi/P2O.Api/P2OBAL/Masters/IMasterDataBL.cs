﻿using P2OBAL.Common;

namespace P2OBAL.Masters
{
    public interface IMasterDataBL
    {
        ResponseClass GetCommonEntity(MasterSelectRequestDTO masterSelectRequestDTO);
        ResponseClass GetMasterData(MasterDataRequestDTO masterDataRequestDTO);
        ResponseClass InsertCostCenterConfig(CostConfigInsertRequestDTO configInsertRequestDTO);
        ResponseClass CostConfigGet(CostConfigGetRequestDTO CostCenterRequestDTO);
        ResponseClass DeleteCostCenterRoleConfig(CostConfigGetRequestDTO costCenterRoleDeleteRequestDTO);

        ResponseClass MaterialImagaeManage(MaterialImagaeManageDTO materialImagaeManageDTO);
        ResponseClass GetMenuMaster(MenuMasterDetailsRequestDTO menueMasterRequestDTO);
        ResponseClass GetParentMenuMaster();
        ResponseClass InsertMenuMaster(MenuMasterDetailsInsertDTO masterDetailsInsertDTO);
        ResponseClass DeleteMenuMaster(MenuMasterDetailsRequestDTO menueMasterRequestDTO);
        ResponseClass GetUserTypeMaster();
        ResponseClass GetMenuMasterType(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO);
        ResponseClass GetMenuUserMapping(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO);
        ResponseClass InsertMenuUserMapping(MenuUserMappingInsertDTO userMappingInsertDTO);
        ResponseClass DeleteUserMenuMapping(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO);
        ResponseClass PRSPOCGroupManage(PRSPOCRequestDTO pRSPOCRequestDTO);
        ResponseClass MastersInsert(MastersInsertRequestDTO mastersInsertRequestDTO);
    }
}