﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Masters
{
    public class MasterSelectRequestDTO
    {
        public string EntityName { get; set; }
        public string SearchParameter1 { get; set; }
        public string SearchParameter2 { get; set; }
        public string EmployeeID { get; set; }
        public string SearchAs { get; set; }
        public string CompanyCode { get; set; }
    }
    public class MasterDataRequestDTO
    {
        public string MasterType { get; set; }
        public string CompanyCode { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public string CostCenterSearch { get; set; }
    }

    public class CostConfigInsertRequestDTO
    {
        public int CostCenterConfigID { get; set; }
        public string CostCenterCode { get; set; }
        public int RoleMasterId { get; set; }
        public string RoleEmpCode { get; set; }
        public string Action { get; set; }
    }

    public class CostConfigGetRequestDTO
    {
        public int CostCenterConfigID { get; set; }
        public string CostCenterCode { get; set; }
        public string DeletedBy { get; set; }
    }

    public class MaterialImagaeManageDTO
    {

        public string Action { get; set; }
        public string Type { get; set; }
        public string MatCode { get; set; }
        public string MatImage { get; set; }
        public string InsertedBy { get; set; }
        public string InsetedIPAddresss { get; set; }
    }
    public class MenuMasterDetailsRequestDTO
    {
        public string SerachParm { get; set; }
        public string Action { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public int MenuMasteId { get; set; }
        public int LoggedInEmpId { get; set; }
    }
    public class MenuMasterDetailsInsertDTO
    {
        public string Action { get; set; }
        public int ParentMenuID { get; set; }
        public string MenuName { get; set; }
        public string MenuUrl { get; set; }
        public int LoggedInEmpId { get; set; }
    }

    public class MenuUserMappingDetailsRequestDTO
    {
        public string SerachParm { get; set; }
        public string Action { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public int LoggedInEmpId { get; set; }
        public string UserType { get; set; }
        public int MappingId { get; set; }
    }

    public class MenuUserMappingInsertDTO
    {
        public string Action { get; set; }
        public string UserTypeCode { get; set; }
        public int MenuID { get; set; }
    }

    public class PRSPOCRequestDTO
    {
        public string Action { get; set; }
        public int PRSPOCGroupID { get; set; }
        public string EmployeeID { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public int PRSPOCMemberID { get; set; }
        public string PRSPOCGroupTitle { get; set; }
    }

    public class MastersInsertRequestDTO
    {
        public string Action { get; set; }
        public string CompanyCode { get; set; }
        public string IParam1 { get; set; }
        public string IParam2 { get; set; }
        public string IParam3 { get; set; }
        public string IParam4 { get; set; }
        public string IParam5 { get; set; }
        public string IParam6 { get; set; }
        public string IParam7 { get; set; }
        public string IParam8 { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }
}
