﻿using P2OBAL.Common;

namespace P2OBAL.AppStats
{
    public interface IAppStatsBL
    {
        ResponseClass AppStatInsert(AppStatsBO appStatsBO);
    }
}