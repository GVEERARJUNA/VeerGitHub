﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.AppStats
{
    public class AppStatsBO
    {
       
        public string employee_code { get; set; }
       
        public string employee_name { get; set; }
       
        public string country { get; set; }
       
        public string ip_address { get; set; }
        
        public string page_url { get; set; }
        
        public string module_name { get; set; }
        
        public string page_name { get; set; }
        public int is_active { get; set; }
       
        public string appName { get; set; }
        
        public string applicationCode { get; set; }
        
        public string session_id { get; set; }
       
        public string source { get; set; }
        
        public string medium { get; set; }
       
        public string device_type { get; set; }
       
        public string device_software { get; set; }
        
        public string device_model { get; set; }
    }
}
