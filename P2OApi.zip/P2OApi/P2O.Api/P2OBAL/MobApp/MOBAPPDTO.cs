﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.MobApp
{
    public class MOBAPPRequest
    {
        public string input { get; set; }
    }
    public class MOBAPPDTO
    {
        public string Action { get; set; }
        public string LoginID { get; set; }
        public string CurrentRole { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }

        public string PRID { get; set; }
    }

    public class PRList
    {
        public int PurchaseRequistionID { get; set; }
        public string CostCenterName { get; set; }
        public string GLCode { get; set; }
        public string Company { get; set; }
        public double Amount { get; set; }
        public double Quantity { get; set; }
        public string Vendor { get; set; }
        public string PlantCode { get; set; }
        public string PurchasingOrg { get; set; }
        public string Status { get; set; }
        public string RequistionControlID { get; set; }
        public int ApprovalLevel { get; set; }
        public int PRApprovalMatrixID { get; set; }
        public string Currency { get; set; }

        public string Creator { get; set; }

        public string OnBehalfOfFlag { get; set; }
        public List<PRDetailList> prDetails { get; set; }

        public string PurchaseTypeName { get; set; }
        public string PurchaseGroupName { get; set; }
        public int ApprovalStatus { get; set; }
    }

    public class PRDetailList
    {
        public int SRNo { get; set; }
        public string Material { get; set; }

        public string GLCode { get; set; }
        public string ProductType { get; set; }
        public double Amount { get; set; }
        public double Quantity { get; set; }

        public double NetAmount { get; set; }
        public string UOM { get; set; }
        public string LineComments { get; set; }

        public string MaterialImage { get; set; }



    }

    public class responsePRList
    {
        public int responseCode { get; set; }
        public string responseMessage { get; set; }
        public dynamic responseList { get; set; }

        public object responseJSON { get; set; }

    }

    public class PRCommentsResponse
    {
        public string FullName { get; set; }
        public string StatusText { get; set; }
        public string Remarks { get; set; }
    }

    public class PRCountResponse
    {
        public int TotalCount { get; set; }
        public string RowType { get; set; }
    }

    public class UpdatePRApprovalRequestDTO
    {
        public string ApproverId { get; set; }
        public int PRApprovalMatrixID { get; set; }
        public int PurchaseRequistionID { get; set; }
        public string ApproverDeviceID { get; set; }
        public int ApprovalStatus { get; set; }
        public int ApprovalLevel { get; set; }
        public string Remark { get; set; }
    }

    public class fcmnotificationresponseDTO
    {
        public string EMPID { get; set; }
        public string FCMTitle { get; set; }
        public string FCMBody { get; set; }
    }

    public class getPODetailRequestDTO
    {
        public string PRNumber { get; set; }
    }
    public class getPODetailResponseDTO
    {
        public string PONumber { get; set; }
        public string PODate { get; set; }
        public double TotalPOValue { get; set; }
        public string POCurrency { get; set; }
    }
}
