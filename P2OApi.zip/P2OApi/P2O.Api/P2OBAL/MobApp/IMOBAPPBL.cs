﻿using P2OBAL.Common;

namespace P2OBAL.MobApp
{
    public interface IMOBAPPBL
    {
        responsePRList MOBAPPManage(MOBAPPDTO mOBAPPDTO);

        responsePRList ApprovalstatusUpdate(UpdatePRApprovalRequestDTO updateRequestDTO);
        ResponseClass SendFCMNotification(fcmnotificationresponseDTO fcmnotificationresponseDTO);
        responsePRList getPODetail(getPODetailRequestDTO request);
    }
}