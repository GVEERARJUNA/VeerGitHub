﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;

namespace P2OBAL.Configuration
{
    public class ApplicationConfigBL : IApplicationConfigBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;


        public ApplicationConfigBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass ApplicationConfigSetting(ApplicationConfigDTORequest applicationConfigDTORequest)
        {
            ResponseClass response = new ResponseClass();

            if (applicationConfigDTORequest == null)
            {
                response.responseCode = 0;
                response.responseMessage = "applicationConfigDTORequest required";
                return response;
            }


            if (string.IsNullOrEmpty(applicationConfigDTORequest.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "applicationConfigDTORequest.Action required!";
                return response;
            }

            if (!string.IsNullOrEmpty(applicationConfigDTORequest.PropertyName) && applicationConfigDTORequest.PropertyName.Length > 200)
            {
                response.responseCode = 0;
                response.responseMessage = "applicationConfigDTORequest.PropertyName cannot exceed 200 characters!";
                return response;
            }

            if (!string.IsNullOrEmpty(applicationConfigDTORequest.PropertyValue) && applicationConfigDTORequest.PropertyValue.Length > 200)
            {
                response.responseCode = 0;
                response.responseMessage = "applicationConfigDTORequest.PropertyValue cannot exceed 200 characters!";
                return response;
            }

            if (!string.IsNullOrEmpty(applicationConfigDTORequest.Remarks) && applicationConfigDTORequest.Remarks.Length > 200)
            {
                response.responseCode = 0;
                response.responseMessage = "applicationConfigDTORequest.Remarks cannot exceed 200 characters!";
                return response;
            }

            if (!string.IsNullOrEmpty(applicationConfigDTORequest.InsertdBy) && applicationConfigDTORequest.InsertdBy.Length > 50)
            {
                response.responseCode = 0;
                response.responseMessage = "applicationConfigDTORequest.InsertdBy cannot exceed 50 characters!";
                return response;
            }

            if (!string.IsNullOrEmpty(applicationConfigDTORequest.InsertedIPAddress) && applicationConfigDTORequest.InsertedIPAddress.Length > 50)
            {
                response.responseCode = 0;
                response.responseMessage = "applicationConfigDTORequest.InsertedIPAddress cannot exceed 100 characters!";
                return response;
            }


            SqlParameter[] parameter = {
                new SqlParameter("@ApplicationConfigID", Convert.ToString(applicationConfigDTORequest.ApplicationConfigID)),
                 new SqlParameter("@Action", Convert.ToString(applicationConfigDTORequest.Action)),
                 new SqlParameter("@SearchString", Convert.ToString(applicationConfigDTORequest.SearchString)),
                 new SqlParameter("@PropertyName", Convert.ToString(applicationConfigDTORequest.PropertyName)),
                 new SqlParameter("@PropertyValue", Convert.ToString(applicationConfigDTORequest.PropertyValue)),
                 new SqlParameter("@Remarks", Convert.ToString(applicationConfigDTORequest.Remarks)),
                 new SqlParameter("@InsertdBy", Convert.ToString(applicationConfigDTORequest.InsertdBy)),
                 new SqlParameter("@InsertedIPAddress", Convert.ToString(applicationConfigDTORequest.InsertedIPAddress)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_Application_Setting", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                }
            }



            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;

            return response;
        }

        public ResponseClass ManageCompanyApprovalFlow(ApprovalConfigRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request required";
                return response;
            }

            if (string.IsNullOrEmpty(request.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "Action required!";
                return response;
            }

            if (string.IsNullOrEmpty(request.CompanyCode))
            {
                response.responseCode = 0;
                response.responseMessage = "Company Code required!";
                return response;
            }

            string MatrixXML = string.Empty;

            if (request.Action=="ADD")
            {
                if (request.approvalConfigRequests == null || request.approvalConfigRequests.Count == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "request.approvalConfigRequests required!";
                    return response;
                }

                if (!string.IsNullOrEmpty(request.InsertedBy) && request.InsertedBy.Length > 50)
                {
                    response.responseCode = 0;
                    response.responseMessage = "request.InsertedBy cannot exceed 50 characters!";
                    return response;
                }

                if (!string.IsNullOrEmpty(request.InsertedIPAddress) && request.InsertedIPAddress.Length > 50)
                {
                    response.responseCode = 0;
                    response.responseMessage = "request.InsertedIPAddress cannot exceed 100 characters!";
                    return response;
                }

                MatrixXML = "<ApprovalLevels>";
                foreach (var item in request.approvalConfigRequests)
                {

                    MatrixXML += "<ApprovalLevel>";
                    MatrixXML += "<Level>";
                    MatrixXML += item.Level;
                    MatrixXML += "</Level>";
                    MatrixXML += "<RoleCode>";
                    MatrixXML += item.RoleCode;
                    MatrixXML += "</RoleCode>";

                    MatrixXML += "<AppType>";
                    MatrixXML += item.AppType;
                    MatrixXML += "</AppType>";
                    MatrixXML += "<EMPCode>";
                    MatrixXML += item.EMPCode;
                    MatrixXML += "</EMPCode>";
                    MatrixXML += "<PuchaseTypeID>";
                    MatrixXML += item.PurchaseTypeID;
                    MatrixXML += "</PuchaseTypeID>";
                    MatrixXML += "<PGCategoryCode>";
                    MatrixXML += item.PGCategoryCode;
                    MatrixXML += "</PGCategoryCode>";
                    MatrixXML += "<AmountApplicableFlag>";
                    MatrixXML += item.AmountApplicableFlag;
                    MatrixXML += "</AmountApplicableFlag>";
                    MatrixXML += "<CalculateSymbol>";
                    MatrixXML += item.CalculateSymbol;
                    MatrixXML += "</CalculateSymbol>";

                    MatrixXML += "<FromAmount>";
                    MatrixXML += item.FromAmount;
                    MatrixXML += "</FromAmount>";
                    MatrixXML += "<ToAmount>";
                    MatrixXML += item.ToAmount;
                    MatrixXML += "</ToAmount>";
                    MatrixXML += "</ApprovalLevel>";
                }

                MatrixXML += "</ApprovalLevels>";

            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {

                    new SqlParameter("@Action", Convert.ToString(request.Action)),
                    new SqlParameter("@CompanyCode", Convert.ToString(request.CompanyCode)),
                    new SqlParameter("@Matrix",MatrixXML),
                    new SqlParameter("@InsertedBy", Convert.ToString(request.InsertedBy)),
                    new SqlParameter("@InsertedIPAddress", Convert.ToString(request.InsertedIPAddress)),
                    new SqlParameter("@PrimaryID",SqlDbType.Int,4),
                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_Manage_AppConfigFlow", parameter, outParameters);
                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
                if (Convert.ToString(request.Action) == "GET")
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    }
                }
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass DeleteApprovalFlow(ApprovalConfigRequestDTO approvalConfigRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (approvalConfigRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Input data is required";
                return response;
            }
            if (approvalConfigRequestDTO.PrimaryID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Please select Menu Master";
                return response;
            }
            if (approvalConfigRequestDTO.Action == "" || approvalConfigRequestDTO.Action == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Action is required";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                new SqlParameter("@Action", Convert.ToString(approvalConfigRequestDTO.Action)),
                new SqlParameter("@PrimaryID", approvalConfigRequestDTO.PrimaryID),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                //new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                };

                int result = dBConnection.ExecuteNonQuery("PRC_Manage_AppConfigFlow", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
    }
}
