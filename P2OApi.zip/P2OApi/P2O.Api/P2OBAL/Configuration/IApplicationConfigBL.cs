﻿using P2OBAL.Common;

namespace P2OBAL.Configuration
{
    public interface IApplicationConfigBL
    {
        ResponseClass ApplicationConfigSetting(ApplicationConfigDTORequest applicationConfigDTORequest);
        ResponseClass ManageCompanyApprovalFlow(ApprovalConfigRequestDTO request);
        ResponseClass DeleteApprovalFlow(ApprovalConfigRequestDTO approvalConfigRequestDTO);
    }
}