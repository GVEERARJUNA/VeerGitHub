﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Configuration
{
   public class ApplicationConfigDTORequest
    {
        public int ApplicationConfigID { get; set; }

        public string SearchString { get; set; }
        public string Action { get; set; }
        public string PropertyName { get; set; }
        public string PropertyValue { get; set; }
        public string Remarks { get; set; }
        public string InsertdBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }

    public class ApprovalConfigRequestDTO
    {
        public string Action { get; set; }
        public string CompanyCode { get; set; }
        public List<ApprovalConfigRequest> approvalConfigRequests { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public int PrimaryID { get; set; }
    }

    public class ApprovalConfigRequest
    {

        public int Level { get; set; }

        public string RoleName { get; set; }

        public int RoleCode { get; set; }
        public string EMPCode { get; set; }
        public string AppType { get; set; }
        public int PurchaseTypeID { get; set; }
        public string PGCategoryCode { get; set; }
        public int AmountApplicableFlag { get; set; }
        public string CalculateSymbol { get; set; }
        public double FromAmount { get; set; }
        public double ToAmount { get; set; }
    }
}
