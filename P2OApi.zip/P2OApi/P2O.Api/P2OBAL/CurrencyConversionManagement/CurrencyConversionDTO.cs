﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.CurrencyConversionManagement
{
    public class ManageCurrencyConversionDTO
    {
        public string Action { get; set; }
        public string FromCurrency { get; set; }
        public string ToCurrency { get; set; }
        public double ConversionRate { get; set; }
    }

    public class CurrencyConversionMGTDTO
    {
        public int CurrencyConversionID { get; set; }
        public int ConversionYear { get; set; }
        public int ConversionMonth { get; set; }
        public string Action { get; set; }
        public string FromCurrency { get; set; }
        public string ToCurrency { get; set; }
        public double ConversionRate { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }
}
