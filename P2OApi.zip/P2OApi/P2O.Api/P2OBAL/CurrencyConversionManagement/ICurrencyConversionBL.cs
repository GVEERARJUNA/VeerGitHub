﻿using P2OBAL.Common;

namespace P2OBAL.CurrencyConversionManagement
{
    public interface ICurrencyConversionBL
    {
        ResponseClass CurrencyConversion(CurrencyConversionMGTDTO currencyConversionMGTDTO);
        ResponseClass ManageCurrencyConversion(ManageCurrencyConversionDTO currencyConversionDTO);
    }
}