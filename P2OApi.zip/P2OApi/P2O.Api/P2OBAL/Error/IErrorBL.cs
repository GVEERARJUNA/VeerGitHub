﻿using P2OBAL.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Error
{
    public interface IErrorBL
    {
        ResponseClass SaveErrorDetails(ErrorDTO errorRequestDTO);
    }
}
