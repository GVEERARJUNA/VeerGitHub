﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace P2OBAL.Error
{
    public class ErrorBL : IErrorBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        public ErrorBL(IOptions<IDBConnection> app)
        {
            appSettings = app;
            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }
        public ResponseClass SaveErrorDetails(ErrorDTO errorRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (errorRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "errorRequestDTO required";
                return response;
            }

            if (string.IsNullOrEmpty(errorRequestDTO.ErrorDescription))
            {
                response.responseCode = 0;
                response.responseMessage = "masterDataRequestDTO.MasterType required!";
                return response;
            }
            if (string.IsNullOrEmpty(errorRequestDTO.Url))
            {
                response.responseCode = 0;
                response.responseMessage = "errorRequestDTO.Url required!";
                return response;
            }
            if (string.IsNullOrEmpty(errorRequestDTO.FileName))
            {
                response.responseCode = 0;
                response.responseMessage = "errorRequestDTO.FileName required!";
                return response;
            }
            if (string.IsNullOrEmpty(errorRequestDTO.Source))
            {
                response.responseCode = 0;
                response.responseMessage = "errorRequestDTO.Source required!";
                return response;
            }

            SqlParameter[] parameter = {
                new SqlParameter("@ErrorDescription", Convert.ToString(errorRequestDTO.ErrorDescription)),
                new SqlParameter("@Url", Convert.ToString(errorRequestDTO.Url)),
                new SqlParameter("@Source", Convert.ToString(errorRequestDTO.Source)),
                new SqlParameter("@FileName", Convert.ToString(errorRequestDTO.FileName)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("USP_SaveErrorDetails", parameter, outParameters);
            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;
            return response;
        }
    }
}
