﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2OBAL.MobApp;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;

namespace P2OBAL.EmailMgt
{
    public class EmailManagementBL : IEmailManagementBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        IFireBaseAPICallBL _apiCall;

        public EmailManagementBL(IOptions<IDBConnection> app, IFireBaseAPICallBL apiCall)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
            _apiCall = apiCall;
        }

        public ResponseClass GetEmailContent(EmailManagementDTO emailManagementDTO)
        {
            ResponseClass response = new ResponseClass();
            string GCMEmployeeCode = string.Empty;
            CommonFunction commonFunction = new CommonFunction();
            //int mydetail = Convert.ToInt32("SCVTRE");

            //string encryptCode = "541";
            //encryptCode = commonFunction.Encrypt(encryptCode);

            //string decryptCode = commonFunction.Decrypt(encryptCode);


            //return response;
            try
            {
                if (emailManagementDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "emailManagementDTO required";
                    return response;
                }


                if (string.IsNullOrEmpty(emailManagementDTO.EmailType))
                {
                    response.responseCode = 0;
                    response.responseMessage = "emailManagementDTO.EmailType required!";
                    return response;
                }


                SqlParameter[] parameter = {
                new SqlParameter("@SearchType", Convert.ToString(emailManagementDTO.EmailType)),
                new SqlParameter("@RequistionNo", Convert.ToString(emailManagementDTO.RequistionNo)),
                new SqlParameter("@PRID", Convert.ToString(emailManagementDTO.PRID)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_GetEmailData", parameter, outParameters);




                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

                if (response.responseCode == 1)
                {
                    
                    //List<EmailClass> emailClass = new List<EmailClass>();
                    List<EmailEntity> emailEntity = new List<EmailEntity>();

                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        //string responseEmailClass= JsonConvert.SerializeObject(dsResult.Tables[0]);
                        //emailClass = JsonConvert.DeserializeObject<List<EmailClass>>(responseEmailClass);

                        string responseEmailEntity = JsonConvert.SerializeObject(dsResult.Tables[0]);
                        emailEntity = JsonConvert.DeserializeObject<List<EmailEntity>>(responseEmailEntity);

                        if (emailEntity != null && emailEntity.Count > 0)
                        {
                            foreach (var item in emailEntity)
                            {
                                MailDetails mailDetails = new MailDetails();
                                mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                List<ToList> lstToList = new List<ToList>();

                                if (!string.IsNullOrEmpty(item.EmailTo))
                                {
                                    string[] bccList = item.EmailTo.Split(",");

                                    foreach (string email in bccList)
                                    {
                                        ToList bcc = new ToList();
                                        bcc.EmailAddress = email.ToString();
                                        lstToList.Add(bcc);
                                    }

                                    mailDetails.ToList = lstToList;
                                }

                               



                                if (!string.IsNullOrEmpty(item.EmailCC))
                                {
                                    mailDetails.CcList = item.EmailCC;
                                }

                                //mailDetails.BccList = appSettings.Value.BccList;

                                mailDetails.Sender = appSettings.Value.Sender;
                                mailDetails.SenderName = appSettings.Value.SenderName;
                                item.EmailSubject = item.EmailSubject.Replace("@PRNumber", item.RequistionNo);
                                mailDetails.Subject = item.EmailSubject;
                                List<AtatchmentList> lstAttachment = new List<AtatchmentList>();
                               
                                
                                //mailDetails.Attachment = string.Empty;
                                string emailBody = item.EmailTemplate;

                                List<BCCList> lstBCC = new List<BCCList>();

                                if (!string.IsNullOrEmpty(item.BCCList))
                                {
                                    string[] bccList = item.BCCList.Split(",");

                                    foreach (string email in bccList)
                                    {
                                        BCCList bcc = new BCCList();
                                        bcc.EmailAddress = email.ToString();
                                        lstBCC.Add(bcc);
                                    }

                                    mailDetails.bCCLists = lstBCC;
                                }

                                double PRAmount = Convert.ToDouble(item.POCost);
                                string CurrencyCode = item.CurrencyCode;
                                string POCost = CurrencyConversion.FormatCurrency(CurrencyCode, PRAmount);

                                emailBody = emailBody.Replace("@PRNumber", item.RequistionNo);

                                emailBody = emailBody.Replace("@CostCenterNumber", item.CostCenterCode);
                                emailBody = emailBody.Replace("@CostCenterName", item.CostCenterName);
                                emailBody = emailBody.Replace("@Creator", item.RaisedBy);
                                emailBody = emailBody.Replace("@Material", item.Material);
                                emailBody = emailBody.Replace("@ShortDesc", item.Material);
                                emailBody = emailBody.Replace("@CatalogName", item.CatalogName);
                                emailBody = emailBody.Replace("@POCost", POCost);
                                emailBody = emailBody.Replace("@ApproverName", item.ApprovalName);

                                if (Convert.ToString(emailManagementDTO.EmailType) == "Reject")
                                {
                                    emailBody = emailBody.Replace("@RejectorName", item.ApprovalName);
                                    emailBody = emailBody.Replace("@Comments", item.Comments);
                                }
                                else if (Convert.ToString(emailManagementDTO.EmailType) == "Referback")
                                {
                                    emailBody = emailBody.Replace("@ReferbackName", item.ApprovalName);
                                    emailBody = emailBody.Replace("@Comments", item.Comments);
                                }
                                else
                                {
                                    if (item.EmailType == "Approver")
                                    {


                                        
                                        string requistionNo = item.RequistionNo;
                                        string approvalEmpCode = item.EmailLink;
                                        GCMEmployeeCode = approvalEmpCode;

                                        requistionNo = commonFunction.Encrypt(requistionNo);
                                        approvalEmpCode = commonFunction.Encrypt(approvalEmpCode);

                                        string EmailLink = appSettings.Value.ApproverLink + "UserResponse/Index?requistionNo=" + requistionNo + "&EMPCode=" + approvalEmpCode;

                                        //string EmailLink = appSettings.Value.LinkUrl;

                                        //emailBody = emailBody.Replace("@Link", EmailLink);
                                        emailBody = emailBody.Replace("@Link", EmailLink);
                                        emailBody = emailBody.Replace("@PurchaseType", item.PurchaseType);
                                        emailBody = emailBody.Replace("@Comments", "");


                                    }
                                    else if (item.EmailType == "Requestor")
                                    {
                                        emailBody = emailBody.Replace("@Comments", item.Comments);
                                    }

                                    else if (item.EmailType == "SAPMovement")
                                    {
                                        int ACount = 0;
                                        if (!string.IsNullOrEmpty(item.Atatchments))
                                        {
                                            string filePath = appSettings.Value.FileAccessPath;
                                            string[] attachment = item.Atatchments.Split(",");
                                            foreach (string file in attachment)
                                            {
                                                AtatchmentList myFile = new AtatchmentList();
                                                myFile.Attachment = filePath + file.ToString();
                                                lstAttachment.Add(myFile);
                                                ACount = ACount + 1;
                                            }
                                            mailDetails.Attachment = lstAttachment;
                                        }

                                        emailBody = emailBody.Replace("@ACount", ACount.ToString());
                                    }



                                }

                                

                                mailDetails.MailActualBody = emailBody;
                                string outputResult = string.Empty;

                                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                WriteLogFile.WriteLog("Information", "Email sent successfully : " + DateTime.Now.ToString("yyyy-mm-dd HH:mm:ss"));

                                try
                                {
                                    EmailHistoryRequestDTO emailHistoryRequestDTO = new EmailHistoryRequestDTO();
                                    emailHistoryRequestDTO.ApprovalMatrixID = item.ApprovalMatrixID;
                                    emailHistoryRequestDTO.CCTo = item.EmailCC;
                                    emailHistoryRequestDTO.EmailBody = emailBody;
                                    if (!string.IsNullOrEmpty(item.EmailSubject) && !string.IsNullOrEmpty(item.RequistionNo) && (!item.EmailSubject.Trim().Contains(item.RequistionNo)))
                                        emailHistoryRequestDTO.EmailSubject = item.EmailSubject + " " + item.RequistionNo;
                                    else
                                        emailHistoryRequestDTO.EmailSubject = item.EmailSubject;
                                    
                                    emailHistoryRequestDTO.EmailTo = item.EmailTo;
                                    emailHistoryRequestDTO.EmailStatus = outputResult;
                                    emailHistoryRequestDTO.PurchaseReqID = emailManagementDTO.PRID;

                                    InsertEmailHistory(emailHistoryRequestDTO);
                                }
                                catch (Exception ex)
                                {

                                    WriteLogFile.WriteLog("Exception", "Exception in save email history : " + ex.Message + " ");
                                }

                                /**************** SEND GCM NOTIFICATION *****************/
                                try
                                {
                                    fcmnotificationresponseDTO fcmnotificationresponseDTO = new fcmnotificationresponseDTO();
                                    if (item.EmailType == "Approver")
                                    {
                                        if (!string.IsNullOrEmpty(item.GCMNotifictionTitle) && !string.IsNullOrEmpty(GCMEmployeeCode))
                                        {
                                            fcmnotificationresponseDTO.EMPID = GCMEmployeeCode;
                                            fcmnotificationresponseDTO.FCMTitle = item.GCMNotifictionTitle;
                                            fcmnotificationresponseDTO.FCMBody = item.GCMNotifictionBody;
                                            string gcmrequest = JsonConvert.SerializeObject(fcmnotificationresponseDTO);
                                            WriteLogFile.WriteLog("Information", "GCM Request : " + gcmrequest + " ");
                                            var gcmResponse = SendFCMNotification(fcmnotificationresponseDTO);
                                            WriteLogFile.WriteLog("Information", "GCM Response : " + gcmResponse + " ");
                                        }
                                    }

                                }
                                catch (Exception ex)
                                {
                                    WriteLogFile.WriteLog("Exception", "GCM Response : " + ex.Message + " ");

                                }
                                
                                // now insert email response in DB




                                // response.responseReturnNo = outputResult;
                            }


                        }
                    }

                    
                }
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
                WriteLogFile.WriteLog("Exception", "Exception in sending email : " + ex.Message + " ");
            }
            return response;
        }

        public ResponseClass EmailManagementSetting(EmailMGTRequestDTO emailMGTRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (emailMGTRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "emailMGTRequestDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(emailMGTRequestDTO.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "emailMGTRequestDTO.Action required!";
                return response;
            }

            


            SqlParameter[] parameter = {
                new SqlParameter("@EmailMasterID", Convert.ToString(emailMGTRequestDTO.EmailMasterID)),
                 new SqlParameter("@Action", Convert.ToString(emailMGTRequestDTO.Action)),
                 new SqlParameter("@InsertedBy", Convert.ToString(emailMGTRequestDTO.InsertedBy)),
                 new SqlParameter("@InsertedIPAddress", Convert.ToString(emailMGTRequestDTO.InsertedIPAddress)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_Email_Management", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (Convert.ToString(emailMGTRequestDTO.Action)== "Manage")
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    }
                }
                
            }



            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;

            return response;
        }

        public ResponseClass SendEmailResponse(string FromMailAddress, string ToMailAddress, string htmlString, string password)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                FromMailAddress = "p2o@teamhgs.com";
                password = "Password@123";
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress(FromMailAddress);
                message.To.Add(new MailAddress(ToMailAddress));
                message.Subject = "Test";
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = htmlString;
                smtp.Port = 25;
                smtp.Host = "smtp.office365.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential(FromMailAddress, password);
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;    

        }

        public bool SendEmail(string FromMailAddress, string ToMailAddress, string htmlString, string password)
        {
            try
            {
                FromMailAddress = "p2o@teamhgs.com";
                password = "Password@123";
                MailMessage message = new MailMessage();
                SmtpClient smtp = new SmtpClient();
                message.From = new MailAddress(FromMailAddress);
                message.To.Add(new MailAddress(ToMailAddress));
                message.Subject = "Test";
                message.IsBodyHtml = true; //to make message body as html  
                message.Body = htmlString;
                smtp.Port = 587;
                smtp.Host = "smtp.office365.com"; //for gmail host  
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential(FromMailAddress, password);
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(message);

                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        public void InsertEmailHistory(EmailHistoryRequestDTO emailHistoryRequestDTO)
        {
            List<OutParameter> outParameters = new List<OutParameter>();

            SqlParameter[] parameter = {
                new SqlParameter("@ApprovalMatrixID", Convert.ToInt32(emailHistoryRequestDTO.ApprovalMatrixID)),
                new SqlParameter("@EmailTo", Convert.ToString(emailHistoryRequestDTO.EmailTo)),
                new SqlParameter("@CCTo", Convert.ToString(emailHistoryRequestDTO.CCTo)),
                new SqlParameter("@EmailSubject", Convert.ToString(emailHistoryRequestDTO.EmailSubject)),
                new SqlParameter("@EmailBody", Convert.ToString(emailHistoryRequestDTO.EmailBody)),
                new SqlParameter("@EmailStatus", Convert.ToString(emailHistoryRequestDTO.EmailStatus)),
                new SqlParameter("@RequistionNo", Convert.ToString(emailHistoryRequestDTO.PurchaseReqID)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            int result = dBConnection.ExecuteNonQuery("USP_EmailHistoryInsert", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

        }

        private string ShrinkURL(string strURL)
        {

            string URL;
            URL = "http://tinyurl.com/api-create.php?url=" +
               strURL.ToLower();

            System.Net.HttpWebRequest objWebRequest;
            System.Net.HttpWebResponse objWebResponse;

            System.IO.StreamReader srReader;

            string strHTML;

            objWebRequest = (System.Net.HttpWebRequest)System.Net
               .WebRequest.Create(URL);
            objWebRequest.Method = "GET";

            objWebResponse = (System.Net.HttpWebResponse)objWebRequest
               .GetResponse();
            srReader = new System.IO.StreamReader(objWebResponse
               .GetResponseStream());

            strHTML = srReader.ReadToEnd();

            srReader.Close();
            objWebResponse.Close();
            objWebRequest.Abort();

            return (strHTML);

        }
        public ResponseClass UpdateEmailDetails(EmailMGTUpdateDTO updateRequestDTO)
        {
            ResponseClass response = new ResponseClass();


            if (updateRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Input Data is required";
                return response;
            }
            if (updateRequestDTO.EmailMasterID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "EmailMGTUpdateDTO";
                return response;
            }
            if (updateRequestDTO.EmailSubject == "" || updateRequestDTO.EmailSubject == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Email Subject is required";
                return response;
            }
            if (updateRequestDTO.EmailTemplate == "" || updateRequestDTO.EmailTemplate == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Email Template is required";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                   new SqlParameter("@EmailMasterID", Convert.ToString(updateRequestDTO.EmailMasterID)),
                 new SqlParameter("@Action", Convert.ToString(updateRequestDTO.Action)),
                 new SqlParameter("@InsertedBy", Convert.ToString(updateRequestDTO.InsertedBy)),
                 new SqlParameter("@InsertedIPAddress", Convert.ToString(updateRequestDTO.InsertedIPAddress)),
                 new SqlParameter("@EmailSubject", Convert.ToString(updateRequestDTO.EmailSubject)),
                 new SqlParameter("@EmailTemplate", Convert.ToString(updateRequestDTO.EmailTemplate)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,200,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("PRC_Email_Management", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public string SendFCMNotification(fcmnotificationresponseDTO fcmnotificationresponseDTO)
        {
            string response = string.Empty;
            //FireBaseAPICallBL fireBaseAPICallBL = new FireBaseAPICallBL();
           

            // first get device token
            string deviceTokenQuery = string.Empty;
            string deviceToken = string.Empty;
            deviceTokenQuery = "select FireBaseToken,DeviceId  from FireBaseTokenDetails where EmployeeId ='" + fcmnotificationresponseDTO.EMPID + "' ";
            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteNonQueryInlineMobile(deviceTokenQuery, appSettings.Value.MobileTokenDbConnection);
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                if (dsResult.Tables[0].Rows.Count > 0)
                {
                    deviceToken = Convert.ToString(dsResult.Tables[0].Rows[0]["FireBaseToken"]);
                }
            }

            if (!string.IsNullOrEmpty(deviceToken))
            {
                var fcmResponse = _apiCall.FBCall(deviceToken, Convert.ToString(fcmnotificationresponseDTO.FCMTitle), Convert.ToString(fcmnotificationresponseDTO.FCMBody));
                response = fcmResponse;
            }
            else
            {
                response = "Device Token not found!";
            }
            return response;
        }

        public string SendNotification(fcmnotificationresponseDTO fcmnotificationresponseDTO)
        {
            string response = string.Empty;
            //FireBaseAPICallBL fireBaseAPICallBL = new FireBaseAPICallBL();


            // first get device token
            string deviceTokenQuery = string.Empty;
            string deviceToken = string.Empty;
            deviceTokenQuery = "select FireBaseToken,DeviceId  from FireBaseTokenDetails where EmployeeId ='" + fcmnotificationresponseDTO.EMPID + "' ";
            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteNonQueryInlineMobile(deviceTokenQuery, appSettings.Value.MobileTokenDbConnection);
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                if (dsResult.Tables[0].Rows.Count > 0)
                {
                    deviceToken = Convert.ToString(dsResult.Tables[0].Rows[0]["FireBaseToken"]);
                }
            }

            if (!string.IsNullOrEmpty(deviceToken))
            {
                var fcmResponse = _apiCall.FBCall(deviceToken, Convert.ToString(fcmnotificationresponseDTO.FCMTitle), Convert.ToString(fcmnotificationresponseDTO.FCMBody));
                response = fcmResponse;
            }
            else
            {
                response = "Device Token not found!";
            }
            return response;
        }

        public ResponseClass POGenerateNotification(POGenerateNotificationRequest poGenerateNotification)
        {
            ResponseClass response = new ResponseClass();
            string GCMEmployeeCode = string.Empty;
            CommonFunction commonFunction = new CommonFunction();
           
            try
            {
                if (poGenerateNotification == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "poGenerateNotification required";
                    return response;
                }


                if (string.IsNullOrEmpty(poGenerateNotification.P2OPRNumber))
                {
                    response.responseCode = 0;
                    response.responseMessage = "poGenerateNotification.P2OPRNumber required!";
                    return response;
                }


                SqlParameter[] parameter = {
                new SqlParameter("@P2OPRNumber", Convert.ToString(poGenerateNotification.P2OPRNumber)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_POGenerateNotification", parameter, outParameters);
                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

                if (response.responseCode == 1)
                {

                    //List<EmailClass> emailClass = new List<EmailClass>();
                    List<POGenerateEmailEntity> emailEntity = new List<POGenerateEmailEntity>();

                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        //string responseEmailClass= JsonConvert.SerializeObject(dsResult.Tables[0]);
                        //emailClass = JsonConvert.DeserializeObject<List<EmailClass>>(responseEmailClass);

                        string responseEmailEntity = JsonConvert.SerializeObject(dsResult.Tables[0]);
                        emailEntity = JsonConvert.DeserializeObject<List<POGenerateEmailEntity>>(responseEmailEntity);

                        if (emailEntity != null && emailEntity.Count > 0)
                        {
                            foreach (var item in emailEntity)
                            {
                                MailDetails mailDetails = new MailDetails();
                                mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                List<ToList> lstToList = new List<ToList>();

                                if (!string.IsNullOrEmpty(item.EmailTo))
                                {
                                    string[] bccList = item.EmailTo.Split(",");

                                    foreach (string email in bccList)
                                    {
                                        ToList bcc = new ToList();
                                        bcc.EmailAddress = email.ToString();
                                        lstToList.Add(bcc);
                                    }

                                    mailDetails.ToList = lstToList;
                                }





                                if (!string.IsNullOrEmpty(item.EmailCC))
                                {
                                    mailDetails.CcList = item.EmailCC;
                                }

                                //mailDetails.BccList = appSettings.Value.BccList;

                                mailDetails.Sender = appSettings.Value.Sender;
                                mailDetails.SenderName = appSettings.Value.SenderName;
                                mailDetails.Subject = item.EmailSubject;
                                List<AtatchmentList> lstAttachment = new List<AtatchmentList>();


                                //mailDetails.Attachment = string.Empty;
                                string emailBody = item.EmailTemplate;

                                List<BCCList> lstBCC = new List<BCCList>();

                                if (!string.IsNullOrEmpty(item.BCCList))
                                {
                                    string[] bccList = item.BCCList.Split(",");

                                    foreach (string email in bccList)
                                    {
                                        BCCList bcc = new BCCList();
                                        bcc.EmailAddress = email.ToString();
                                        lstBCC.Add(bcc);
                                    }

                                    mailDetails.bCCLists = lstBCC;
                                }

                               
                                string CurrencyCode = item.CurrencyCode;
                                string POCost = CurrencyConversion.FormatCurrency(CurrencyCode, item.TotalPOValue);

                                emailBody = emailBody.Replace("@PRNumber", poGenerateNotification.P2OPRNumber);

                                emailBody = emailBody.Replace("@PONo", item.SAPPONo);
                                emailBody = emailBody.Replace("@PODate", item.SAPPODate);
                                emailBody = emailBody.Replace("@VendorName", item.VendorCode);
                                emailBody = emailBody.Replace("@POValue", POCost);
                                emailBody = emailBody.Replace("@Material", item.Material);

                                mailDetails.MailActualBody = emailBody;
                                string outputResult = string.Empty;
                                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                WriteLogFile.WriteLog("Information : ", "PO Genetrate Notification : Email send to creator");

                                try
                                {
                                    EmailHistoryRequestDTO emailHistoryRequestDTO = new EmailHistoryRequestDTO();
                                   // emailHistoryRequestDTO.ApprovalMatrixID = item.ApprovalMatrixID;
                                    emailHistoryRequestDTO.CCTo = item.EmailCC;
                                    emailHistoryRequestDTO.EmailBody = emailBody;
                                    if (!string.IsNullOrEmpty(item.EmailSubject) && !string.IsNullOrEmpty(item.SAPPONo) && (!item.EmailSubject.Trim().Contains(item.SAPPONo)))
                                        emailHistoryRequestDTO.EmailSubject = item.EmailSubject + " " + item.SAPPONo;
                                    else
                                        emailHistoryRequestDTO.EmailSubject = item.EmailSubject;
                                    emailHistoryRequestDTO.EmailTo = item.EmailTo;
                                    emailHistoryRequestDTO.EmailStatus = outputResult;
                                    emailHistoryRequestDTO.PurchaseReqID = poGenerateNotification.P2OPRNumber;
                                    InsertEmailHistory(emailHistoryRequestDTO);
                                }
                                catch (Exception ex)
                                {
                                    WriteLogFile.WriteLog("Exception","PO Genetrate Notification : " + ex.Message);

                                }

                               
                            }


                        }
                    }


                }
            }
            catch (Exception ex)
            {
                WriteLogFile.WriteLog("Exception", "PO Genetrate Notification : " + ex.Message);
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass InActiveEmployeeList(POGenerateNotificationRequest poGenerateNotification)
        {
            ResponseClass response = new ResponseClass();
            string GCMEmployeeCode = string.Empty;
            CommonFunction commonFunction = new CommonFunction();

            try
            {
               
                SqlParameter[] parameter = {
               
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_job_inactive_users", parameter, outParameters);
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    List<EmailClass> emailClass = new List<EmailClass>();
                    string responseEmailClass= JsonConvert.SerializeObject(dsResult.Tables[1]);
                    emailClass = JsonConvert.DeserializeObject<List<EmailClass>>(responseEmailClass);

                    string responseEmailEntity = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    List<InactiveUserEmailEntity> emailEntity = new List<InactiveUserEmailEntity>();
                    emailEntity = JsonConvert.DeserializeObject<List<InactiveUserEmailEntity>>(responseEmailEntity);

                    if (emailEntity != null && emailEntity.Count > 0)
                    {
                        foreach (var item in emailClass)
                        {
                            MailDetails mailDetails = new MailDetails();
                            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                            List<ToList> lstToList = new List<ToList>();

                            if (!string.IsNullOrEmpty(emailClass[0].EmailTo))
                            {
                                string[] bccList = emailClass[0].EmailTo.Split(",");

                                foreach (string email in bccList)
                                {
                                    ToList bcc = new ToList();
                                    bcc.EmailAddress = email.ToString();
                                    lstToList.Add(bcc);
                                }

                                mailDetails.ToList = lstToList;
                            }





                            if (!string.IsNullOrEmpty(emailClass[0].EmailCC))
                            {
                                mailDetails.CcList = emailClass[0].EmailCC;
                            }

                            //mailDetails.BccList = appSettings.Value.BccList;

                            mailDetails.Sender = appSettings.Value.Sender;
                            mailDetails.SenderName = appSettings.Value.SenderName;
                            mailDetails.Subject = emailClass[0].EmailSubject;
                            List<AtatchmentList> lstAttachment = new List<AtatchmentList>();


                            //mailDetails.Attachment = string.Empty;
                            string emailBody = emailClass[0].EmailTemplate;

                            List<BCCList> lstBCC = new List<BCCList>();

                            if (!string.IsNullOrEmpty(emailClass[0].BCCList))
                            {
                                string[] bccList = emailClass[0].BCCList.Split(",");

                                foreach (string email in bccList)
                                {
                                    BCCList bcc = new BCCList();
                                    bcc.EmailAddress = email.ToString();
                                    lstBCC.Add(bcc);
                                }

                                mailDetails.bCCLists = lstBCC;
                            }

                            string bodyContent = string.Empty;
                            foreach (var body in emailEntity)
                            {
                                bodyContent += "<tr><td>" + body.MissingType + "</td><td>" + body.MissingPlace + "</td><td>" + body.EmployeeCode + "</td><td>" + body.EmployeeName + "</td></tr>";
                            }
                         
                            emailBody = emailBody.Replace("**List**", bodyContent);

                            mailDetails.MailActualBody = emailBody;
                            string outputResult = string.Empty;
                            outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                            WriteLogFile.WriteLog("Information : ", "Inactive to user");

                            try
                            {
                                EmailHistoryRequestDTO emailHistoryRequestDTO = new EmailHistoryRequestDTO();
                               
                                emailHistoryRequestDTO.CCTo = emailClass[0].EmailCC;
                                emailHistoryRequestDTO.EmailBody = emailBody;
                                if (!string.IsNullOrEmpty(item.EmailSubject) && !string.IsNullOrEmpty(poGenerateNotification.P2OPRNumber) && (!item.EmailSubject.Trim().Contains(poGenerateNotification.P2OPRNumber)))
                                    emailHistoryRequestDTO.EmailSubject = item.EmailSubject + " " + poGenerateNotification.P2OPRNumber;
                                else
                                    emailHistoryRequestDTO.EmailSubject = item.EmailSubject;
                                emailHistoryRequestDTO.EmailTo = emailClass[0].EmailTo;
                                emailHistoryRequestDTO.EmailStatus = outputResult;
                                emailHistoryRequestDTO.PurchaseReqID = poGenerateNotification.P2OPRNumber;
                                InsertEmailHistory(emailHistoryRequestDTO);
                            }
                            catch (Exception ex)
                            {
                                WriteLogFile.WriteLog("Exception", "Inactive to user: " + ex.Message);

                            }


                        }


                    }
                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                WriteLogFile.WriteLog("Exception", "PO Genetrate Notification : " + ex.Message);
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
    }
}
