﻿
using P2OBAL.Common;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace P2OBAL.EmailMgt
{
   public class MailHelper
    {
       
      

        public static string SendMail(MailDetails mailDetail, string isRedirection,string MailRedirectionTo,string MailRedirectionCc)
        {
            string result = string.Empty;
            MailMessage Mail = new MailMessage();
            Mail.From = new MailAddress(mailDetail.Sender, mailDetail.SenderName);
            Mail.Subject = mailDetail.Subject;
            Mail.IsBodyHtml = true;
            //string isRedirection = ConfigurationManager.AppSettings["Mail.Redirection.Enabled"];

            //string isRedirection = "false";

            if (isRedirection == "true")
            {
                //mailDetail.ToList = MailRedirectionTo;
                //mailDetail.CcList = MailRedirectionCc;



                //Mail.To.Add(mailDetail.ToList);
                //Mail.CC.Add(mailDetail.CcList);
               // Mail.Bcc.Add(ConfigurationManager.AppSettings["Mail.Redirection.Bcc"]);
            }
            else
            {
                if (mailDetail.ToList != null && mailDetail.ToList.Count > 0)
                {
                    foreach (var item in mailDetail.ToList)
                    {
                        Mail.To.Add(item.EmailAddress);
                    }
                }

                //if (!string.IsNullOrWhiteSpace(mailDetail.ToList))
                //{
                //    Mail.To.Add(mailDetail.ToList);
                //}
                if (!string.IsNullOrWhiteSpace(mailDetail.CcList))
                {
                    Mail.CC.Add(mailDetail.CcList);
                }

                if (mailDetail.bCCLists!=null && mailDetail.bCCLists.Count>0)
                {
                    foreach (var item in mailDetail.bCCLists)
                    {
                        Mail.Bcc.Add(item.EmailAddress);
                    }
                }

                //if (!string.IsNullOrWhiteSpace(mailDetail.BccList))
                //{
                //    Mail.Bcc.Add(mailDetail.BccList);
                //}
            }

            if (mailDetail.Attachment != null && mailDetail.Attachment.Count > 0)
            {
                try
                {
                    foreach (var item in mailDetail.Attachment)
                    {

                        string fileName = Path.GetFileName(item.Attachment);
                        string path = @item.Attachment;
                        byte[] bytes = File.ReadAllBytes(path);
                        Mail.Attachments.Add(new Attachment(new MemoryStream(bytes), fileName));
                    }
                }
                catch (Exception ex)
                {
                    WriteLogFile.WriteLog("Exception", "Email attach file : " + DateTime.Now.ToString("yyyy-mm-dd HH:mm:ss") + " " + ex.Message);

                }
                
            }

            //HostingEnvironment _hostingEnvironment = new HostingEnvironment();
            //string webRootPath = _hostingEnvironment.WebRootPath;
            AlternateView htmlView = AlternateView.CreateAlternateViewFromString(mailDetail.MailActualBody, null, "text/html");
            try
            {
                string inputFileName = Path.Combine("D:/vsites/P2OAPI/ResourceFile/header-top.jpg");
                LinkedResource logo = new LinkedResource(inputFileName);
                logo.ContentId = "companylogo";
                htmlView.LinkedResources.Add(logo);
            }
            catch (Exception ex)
            {
                WriteLogFile.WriteLog("Exception", "Email attach header top file : " + DateTime.Now.ToString("yyyy-mm-dd HH:mm:ss") + " " + ex.Message);

            }
           
            
            

            //if (!string.IsNullOrWhiteSpace(mailDetail.Attachment))
            //{
            //    Mail.Attachments.Add(new Attachment(mailDetail.Attachment));
            //}






            Mail.AlternateViews.Add(htmlView);





            if (mailDetail.ToList!=null && mailDetail.ToList.Count>0)
            {
                try
                {
                    string FromMailAddress = "P2O@teamhgs.com";
                    string password = "Secure@@123";
                    // SmtpClient SMTP = new SmtpClient(mailDetail.SmtpHostName);
                    SmtpClient smtp = new SmtpClient();
                    smtp.Port = 587;
                    smtp.Host = "smtp.office365.com"; //for gmail host  
                    smtp.EnableSsl = true;
                    smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential(FromMailAddress, password);
                    smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                    smtp.Timeout = 1000000000;
                    smtp.Send(Mail);
                    result = "SUCCESS";

                    //SmtpClient SMTP = new SmtpClient(mailDetail.SmtpHostName);
                    //SMTP.Timeout = 1000000000;

                    //SMTP.Send(Mail);
                    //result = "SUCCESS";
                }
                catch (SmtpException ex) when (ex.StatusCode == SmtpStatusCode.ServiceNotAvailable)
                {
                    SmtpClient SMTP = new SmtpClient(mailDetail.SmtpHostName);
                    SMTP.Timeout = 1000000000;
                    SMTP.Send(Mail);
                    WriteLogFile.WriteLog("Exception", "Email Send : " + ex.Message);
                }
                catch (SmtpException ex) when (ex.StatusCode == SmtpStatusCode.InsufficientStorage)
                {
                    SmtpClient SMTP = new SmtpClient(mailDetail.SmtpHostName);
                    SMTP.Timeout = 1000000000;
                    SMTP.Send(Mail);
                    WriteLogFile.WriteLog("Exception", "Email Send : " + ex.Message);
                }
                catch (SmtpException ex) when (ex.StatusCode == SmtpStatusCode.MailboxUnavailable || ex.StatusCode == SmtpStatusCode.MailboxBusy)
                {
                    result = ex.Message;
                    WriteLogFile.WriteLog("Exception", "Email Send : " + ex.Message);
                    //donothing
                }
                catch (SmtpException ex) when (ex.StatusCode == SmtpStatusCode.GeneralFailure)
                {
                    result = ex.Message;
                    WriteLogFile.WriteLog("Exception", "Email Send : " + ex.Message);
                }
                catch (Exception ex)
                {
                    result = ex.Message;
                    WriteLogFile.WriteLog("Exception", "Email Send : " + ex.Message);
                    //donothing
                }
                finally
                {
                    //donothing
                }
            }

            return result;
        }
    }
}

