﻿using P2OBAL.Common;
using P2OBAL.MobApp;

namespace P2OBAL.EmailMgt
{
    public interface IEmailManagementBL
    {
        ResponseClass GetEmailContent(EmailManagementDTO emailManagementDTO);

        ResponseClass EmailManagementSetting(EmailMGTRequestDTO emailMGTRequestDTO);
        ResponseClass UpdateEmailDetails(EmailMGTUpdateDTO updateRequestDTO);

        string SendNotification(fcmnotificationresponseDTO fcmnotificationresponseDTO);
        ResponseClass POGenerateNotification(POGenerateNotificationRequest poGenerateNotification);
        ResponseClass InActiveEmployeeList(POGenerateNotificationRequest poGenerateNotification);

        ResponseClass SendEmailResponse(string FromMailAddress, string ToMailAddress, string htmlString, string password);
    }
}