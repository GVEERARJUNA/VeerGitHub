﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Xml;

namespace P2OBAL.CatalogueManagement
{
    public class CatalogueManagementBL : ICatalogueManagementBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;


        public CatalogueManagementBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass UploadCatalogue(CatalogueDataUploadRequestDTO catalogueDataUploadRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                if (catalogueDataUploadRequestDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "catalogueDataUploadRequestDTO required";
                    return response;
                }

                if (catalogueDataUploadRequestDTO.catalogueDataUploadRequestLines == null && catalogueDataUploadRequestDTO.catalogueDataUploadRequestLines.Count == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "catalogueDataUploadRequestDTO.catalogueDataUploadRequestLines required";
                    return response;
                }



                XmlDocument xmlDocument = new XmlDocument();


                string MyXML = string.Empty;
                string MyFileXML = string.Empty;
                MyXML = "<detailLines>";
                if (catalogueDataUploadRequestDTO.catalogueDataUploadRequestLines != null && catalogueDataUploadRequestDTO.catalogueDataUploadRequestLines.Count > 0)
                {

                    foreach (var item in catalogueDataUploadRequestDTO.catalogueDataUploadRequestLines)
                    {
                        string slotDateText = string.Empty;
                        string fromTimeText = string.Empty;
                        string ToTimeText = string.Empty;

                        //try
                        //{
                        //    DateTime slotDate = Convert.ToDateTime(item.SlotDate);
                        //    slotDateText = slotDate.ToString("yyyy-MM-dd");
                        //}
                        //catch
                        //{
                        //    response.responseCode = 0;
                        //    response.responseMessage = "Some issue in date format!";
                        //    return response;
                        //}

                        //try
                        //{
                        //    DateTime fromTime = Convert.ToDateTime(item.fromTime);
                        //    fromTimeText = fromTime.ToString("hh:mm tt");
                        //}
                        //catch
                        //{
                        //    response.responseCode = 0;
                        //    response.responseMessage = "Some issue in From Time format!";
                        //    return response;
                        //}


                        MyXML += "<detailLine>";
                        MyXML += "<SupplierCode>" + Convert.ToString(item.SupplierCode) + "</SupplierCode>";
                        MyXML += "<SupplierPartID>" + Convert.ToString(item.SupplierPartID) + "</SupplierPartID>";
                        MyXML += "<MaterialCode>" + Convert.ToString(item.MaterialCode) + "</MaterialCode>";
                        MyXML += "<ItemDescription>" + HttpUtility.HtmlEncode(item.ItemDescription) + "</ItemDescription>";
                        MyXML += "<UnitPrice>" + Convert.ToDouble(item.UnitPrice) + "</UnitPrice>";
                        MyXML += "<ItemUOM>" + Convert.ToString(item.UOM) + "</ItemUOM>";
                        MyXML += "<Currency>" + Convert.ToString(item.Currency) + "</Currency>";
                        MyXML += "<ShortName>" + HttpUtility.HtmlEncode(item.ShortName) + "</ShortName>";
                        MyXML += "<PlantCode>" + Convert.ToString(item.PlantCode) + "</PlantCode>";
                        MyXML += "<Image>" + Convert.ToString(item.Image) + "</Image>";
                        MyXML += "</detailLine>";

                    }

                    MyXML += "</detailLines>";




                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "There is no item added!";
                    return response;
                }


                SqlParameter[] parameter = {

                 new SqlParameter("@CompanyCode", Convert.ToString(catalogueDataUploadRequestDTO.CompanyCode)),
                 new SqlParameter("@InsertedBy", Convert.ToString(catalogueDataUploadRequestDTO.InsertedBy)),
                 new SqlParameter("@InsertedIPAddress", Convert.ToString(catalogueDataUploadRequestDTO.InsertedIPAddress)),

                new SqlParameter("@CatalogueText", (MyXML)),

                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@ErrorLines",SqlDbType.VarChar,5000,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                };

                List<OutParameter> outParameters = new List<OutParameter>();

                int result = dBConnection.ExecuteNonQuery("PRC_Upload_Catalogue_Data", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = resultMessage.ParameterValue;

                if (response.responseCode != 1)
                {
                    OutParameter errorLines = outParameters.Find(x => x.ParameterName == "@ErrorLines");
                    if (!string.IsNullOrEmpty(errorLines.ParameterValue))
                    {
                        //List<ErrorLines> errorLinesList = new List<ErrorLines>();
                        ////response.responseReturnNo = errorLines.ParameterValue;
                        //string[] authorsList = errorLines.ParameterValue.Split(", ");
                        //foreach (string author in authorsList)
                        //{
                        //    errorLinesList.Add(new ErrorLines { LineNo = Convert.ToInt32(author) });
                        //}

                        //response.responseDynamic = errorLinesList;
                    }

                }
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }



            return response;
        }

        public ResponseClass ManageCatalogue(CatalogueManagementSearchRequestDTO catalogueManagementSearchRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (catalogueManagementSearchRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "catalogueManagementSearchRequestDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(catalogueManagementSearchRequestDTO.FromDate))
            {
                response.responseCode = 0;
                response.responseMessage = "catalogueManagementSearchRequestDTO.FromDate required!";
                return response;
            }



            string fRDate = string.Empty;
            try
            {
                DateTime fromdate = Convert.ToDateTime(catalogueManagementSearchRequestDTO.FromDate);
                fRDate = fromdate.ToString("yyyy-MM-dd");
            }
            catch (Exception)
            {

                response.responseCode = 0;
                response.responseMessage = "Invalid format for fromDate!";
                return response;
            }

            string ToDate = string.Empty;

            if (string.IsNullOrEmpty(catalogueManagementSearchRequestDTO.ToDate))
            {
                response.responseCode = 0;
                response.responseMessage = "catalogueManagementSearchRequestDTO.ToDate required!";
                return response;
            }

            if (!string.IsNullOrEmpty(catalogueManagementSearchRequestDTO.ToDate))
            {
                try
                {
                    DateTime todate = Convert.ToDateTime(catalogueManagementSearchRequestDTO.ToDate);
                    ToDate = todate.ToString("yyyy-MM-dd");
                }
                catch (Exception)
                {

                    response.responseCode = 0;
                    response.responseMessage = "Invalid format for ToDate!";
                    return response;
                }
            }
            else
            {
                ToDate = DateTime.Now.ToString("yyyy-MM-dd");
            }

            SqlParameter[] parameter = {
                new SqlParameter("@FromDate", Convert.ToString(fRDate)),
                new SqlParameter("@ToDate", Convert.ToString(ToDate)),
                new SqlParameter("@SupplierCode", Convert.ToString(catalogueManagementSearchRequestDTO.SupplierCode)),
                new SqlParameter("@MaterialCode", Convert.ToString(catalogueManagementSearchRequestDTO.MaterialCode)),
                new SqlParameter("@PlantCode", Convert.ToString(catalogueManagementSearchRequestDTO.PlantCode)),
                new SqlParameter("@PublishStatus", Convert.ToString(catalogueManagementSearchRequestDTO.PublishStatus)),
                new SqlParameter("@PageNumber", catalogueManagementSearchRequestDTO.PageNumber),
                new SqlParameter("@RowsOfPage", catalogueManagementSearchRequestDTO.RowsOfPage),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_ManageCatalogueData", parameter, outParameters);
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                if (catalogueManagementSearchRequestDTO.PageNumber != -1)
                {
                    OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                    decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / catalogueManagementSearchRequestDTO.RowsOfPage));

                    int recordPages = Convert.ToInt32(noOfPages);

                    if (noOfPages > recordPages)
                    {
                        recordPages = recordPages + 1;
                    }

                    response.recordCount = recordPages;
                }
            }
            response.responseCode = 1;
            response.responseMessage = "SUCCESS";

            return response;
        }

        public ResponseClass UpdateCataloguePublishStatus(UpdatePublishStatusRequestDTO updatePublishStatusRequest)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                if (updatePublishStatusRequest == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePublishStatusRequest required";
                    return response;
                }

                if (updatePublishStatusRequest.updatePublishStatusRequestLines == null && updatePublishStatusRequest.updatePublishStatusRequestLines.Count == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "updatePublishStatusRequest.updatePublishStatusRequestLines required";
                    return response;
                }
                string MyXML = string.Empty;
                
                MyXML = "<detailLines>";
                foreach (var item in updatePublishStatusRequest.updatePublishStatusRequestLines)
                {
                    MyXML += "<detailLine>";
                    MyXML += "<CatalogueDataID>" + Convert.ToString(item.CatalogueDataID) + "</CatalogueDataID>";
                    MyXML += "<PublishStatus>" + (item.PublishStatus) + "</PublishStatus>";
                    MyXML += "</detailLine>";
                }
                MyXML += "</detailLines>";

                SqlParameter[] parameter = {

                 
                 new SqlParameter("@InsertedBy", Convert.ToString(updatePublishStatusRequest.InsertedBy)),
                 new SqlParameter("@InsertedIPAddress", Convert.ToString(updatePublishStatusRequest.InsertedIPAddress)),

                new SqlParameter("@CatalogueText", (MyXML)),

                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 
                };

                List<OutParameter> outParameters = new List<OutParameter>();

                int result = dBConnection.ExecuteNonQuery("PRC_Catalogue_update", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = resultMessage.ParameterValue;

            }
            catch(Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass SearchCatalogueData(SearchCatalogueDataRequestDTO searchCatalogueDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (searchCatalogueDataRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "searchCatalogueDataRequestDTO required";
                return response;
            }


            if (searchCatalogueDataRequestDTO.SearchType==0)
            {
                response.responseCode = 0;
                response.responseMessage = "searchCatalogueDataRequestDTO.SearchType required!";
                return response;
            }



            
            SqlParameter[] parameter = {
                
                new SqlParameter("@SearchType", Convert.ToInt32(searchCatalogueDataRequestDTO.SearchType)),
                new SqlParameter("@SearchText", Convert.ToString(searchCatalogueDataRequestDTO.SearchText)),
                new SqlParameter("@CompanyCode", Convert.ToString(searchCatalogueDataRequestDTO.CompanyCode)),
                new SqlParameter("@EmpCode", Convert.ToString(searchCatalogueDataRequestDTO.EmpCode)),
                new SqlParameter("@PageNumber", searchCatalogueDataRequestDTO.PageNumber),
                new SqlParameter("@RowsOfPage", searchCatalogueDataRequestDTO.RowsOfPage),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_Search_Cataloge_Website", parameter, outParameters);
            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;
            if (response.responseCode==1)
            {
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    if (searchCatalogueDataRequestDTO.PageNumber != -1)
                    {
                        OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / searchCatalogueDataRequestDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
            }
           
            return response;
        }
    }
}
