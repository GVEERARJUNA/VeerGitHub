﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace P2OAPI.ServiceConnect
{
    public class MyServiceConnect : IMyServiceConnect
    {
        private readonly IOptions<IDBConnection> appSettings;

        public MyServiceConnect(IOptions<IDBConnection> appSettings)
        {
            this.appSettings = appSettings;
        }

        public string PostConnect(string MethodName, object input)
        {
            string apiUrl = appSettings.Value.WEBAPI + MethodName;
            string inputJson = JsonConvert.SerializeObject(input);
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.UploadString(apiUrl, inputJson);
            return json;

        }
    }
}
