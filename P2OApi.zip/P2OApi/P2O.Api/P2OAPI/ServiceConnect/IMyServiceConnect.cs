﻿namespace P2OAPI.ServiceConnect
{
    public interface IMyServiceConnect
    {
        string PostConnect(string MethodName, object input);
    }
}