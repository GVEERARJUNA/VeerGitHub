﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OAPI.Logging;
using P2OBAL.Common;
using P2OBAL.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class UserManagementController : Controller
    {
        private IUserManagementBL _userManagement;

        private readonly ILogger<UserManagementController> _logger;

        private ILog logging;

        public UserManagementController(IUserManagementBL userManagement, ILogger<UserManagementController> logger, ILog _log)
        {
            _userManagement = userManagement;
            _logger = logger;
            logging = _log;
        }

        [HttpPost]
        public ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO)
        {
            logging.Information("Login Request By :" + loginRequestBO.UserName);
            ResponseClass response = new ResponseClass();
            response = _userManagement.CheckUserLogin(loginRequestBO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDashboardData(DashboardDataRequestBO dashboardDataRequestBO)
        {
            ResponseClass response = new ResponseClass();
            response = _userManagement.GetDashboardData(dashboardDataRequestBO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetRequistionDataCount(GetRequistionDataCountRequest getRequistionDataCountRequest)
        {
            ResponseClass response = new ResponseClass();
            response = _userManagement.GetRequistionDataCount(getRequistionDataCountRequest);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageUser(DashboardDataRequestBO dashboardDataRequestBO)
        {
            ResponseClass response = new ResponseClass();
            response = _userManagement.ManageUser(dashboardDataRequestBO);
            return response;
        }

        [HttpPost]
        public ResponseClass AddUser(AddUserRequestDTO addUserRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _userManagement.AddUser(addUserRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass AddDelegator(AddDelegatorRequestDTO addDelegatorRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _userManagement.AddDelegator(addDelegatorRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDelegationDetails(DelegationGetRequestDTO delegationGetRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _userManagement.GetDelegationDetails(delegationGetRequestDTO.EmployeeId);
            return response;
        }

        [HttpPost]
        public ResponseClass SupplierEmployeeAssign(SupplierEmployeeMappingRequestDTO supplierEmployeeMappingRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _userManagement.SupplierEmployeeAssign(supplierEmployeeMappingRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass ChangeUserType(ChangeUserTypeDTO changeUserTypeDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _userManagement.ChangeUserType(changeUserTypeDTO);
            return response;
        }

        
    }
}
