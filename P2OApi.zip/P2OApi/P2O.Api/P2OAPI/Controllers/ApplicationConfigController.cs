﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OBAL.ApprovalMapping;
using P2OBAL.AppStats;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2OBAL.CurrencyConversionManagement;
using P2OBAL.Error;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ApplicationConfigController : Controller
    {
        private IApplicationConfigBL _ApplicationConfigBL;
        private IApprovalMappingBL _ApprovalMappingBL;
        private IAppStatsBL appStats;
        private readonly ILogger<ApplicationConfigController> _logger;
        private ICurrencyConversionBL _currencyConversionBL;

        public ApplicationConfigController(IApplicationConfigBL ApplicationConfigBL,
            ILogger<ApplicationConfigController> logger, IErrorBL ErrorBL,
            IApprovalMappingBL approvalMappingBL,
            IAppStatsBL app, ICurrencyConversionBL currencyConversionBL
            )
        {
            _ApplicationConfigBL = ApplicationConfigBL;
            _logger = logger;
            _ApprovalMappingBL = approvalMappingBL;
            appStats = app;
            _currencyConversionBL = currencyConversionBL;
        }

        [HttpPost]
        public ResponseClass ApplicationConfigSetting(ApplicationConfigDTORequest applicationConfigDTORequest)
        {
            ResponseClass response = new ResponseClass();
            response = _ApplicationConfigBL.ApplicationConfigSetting(applicationConfigDTORequest);
            return response;
        }

        [HttpPost]
        public ResponseClass ApplicationHierarchyCreate(ApprovalMappingInsertRequestDTO approvalMappingInsertRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _ApprovalMappingBL.ApplicationHierarchyCreate(approvalMappingInsertRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass AppHierarchyManage(AppHierarchyManageRequestDTO appHierarchyManageRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _ApprovalMappingBL.AppHierarchyManage(appHierarchyManageRequestDTO);
            return response;
        }

        [HttpPost]

        public ResponseClass AppStatInsert(AppStatsBO appStatsBO)
        {
            return appStats.AppStatInsert(appStatsBO);
        }

        [HttpGet]
        public ResponseClass ManageCurrencyConversion()
        {
            ResponseClass response = new ResponseClass();

            /*******  GET CURRENCY CONVERSION LIST ********/
            ManageCurrencyConversionDTO currencyConversionDTO = new ManageCurrencyConversionDTO();
            currencyConversionDTO.Action = "L";
            response = _currencyConversionBL.ManageCurrencyConversion(currencyConversionDTO);
            return response;
        }

        [HttpPost]

        public ResponseClass MGTCurrencyConversion(CurrencyConversionMGTDTO currencyConversionMGTDTO)
        {
            return _currencyConversionBL.CurrencyConversion(currencyConversionMGTDTO);
        }

        [HttpPost]
        public ResponseClass ManageCompanyApprovalFlow(ApprovalConfigRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ApplicationConfigBL.ManageCompanyApprovalFlow(request);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteApprovalFlow(ApprovalConfigRequestDTO approvalConfigRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _ApplicationConfigBL.DeleteApprovalFlow(approvalConfigRequestDTO);
            return response;
        }
    }
}
