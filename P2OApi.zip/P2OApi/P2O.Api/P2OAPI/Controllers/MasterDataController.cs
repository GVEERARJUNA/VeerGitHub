﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OBAL.CatalogueManagement;
using P2OBAL.Common;
using P2OBAL.EmailMgt;
using P2OBAL.Error;
using P2OBAL.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class MasterDataController : Controller
    {
        private IMasterDataBL _MasterDataBL;

        private IEmailManagementBL _EmailManagementBL;

        private readonly ILogger<MasterDataController> _logger;

        private ICatalogueManagementBL _CatalogueManagementBL;

        public MasterDataController(IMasterDataBL MasterDataBL, ILogger<MasterDataController> logger,
            IErrorBL ErrorBL,
            IEmailManagementBL emailMGT, ICatalogueManagementBL catalogueManagementBL
            )
        {
            _MasterDataBL = MasterDataBL;
            _logger = logger;
            _EmailManagementBL = emailMGT;
            _CatalogueManagementBL = catalogueManagementBL;
        }

        [HttpPost]
        public ResponseClass GetCommonEntity(MasterSelectRequestDTO masterSelectRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.GetCommonEntity(masterSelectRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetMasterData(MasterDataRequestDTO masterDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.GetMasterData(masterDataRequestDTO);
            return response;
        }


        [HttpPost]
        public ResponseClass InsertCostCenterConfig(CostConfigInsertRequestDTO insertRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.InsertCostCenterConfig(insertRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass CostConfigGet(CostConfigGetRequestDTO CostCenterRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.CostConfigGet(CostCenterRequestDTO);
            return response;
        }


        [HttpPost]
        public ResponseClass DeleteCostCenterRoleConfig(CostConfigGetRequestDTO CostCenterRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.DeleteCostCenterRoleConfig(CostCenterRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass EmailManagementSetting(EmailMGTRequestDTO emailMGTRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _EmailManagementBL.EmailManagementSetting(emailMGTRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetMenuMaster(MenuMasterDetailsRequestDTO menueMasterRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.GetMenuMaster(menueMasterRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetParentMenuMaster()
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.GetParentMenuMaster();
            return response;
        }

        [HttpPost]
        public ResponseClass InsertMenuMaster(MenuMasterDetailsInsertDTO masterDetailsInsertDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.InsertMenuMaster(masterDetailsInsertDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteMenuMaster(MenuMasterDetailsRequestDTO menueMasterRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.DeleteMenuMaster(menueMasterRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass UpdateEmailDetails(EmailMGTUpdateDTO updateRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _EmailManagementBL.UpdateEmailDetails(updateRequestDTO);
            return response;
        }


        [HttpPost]
        public ResponseClass GetUserTypeMaster()
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.GetUserTypeMaster();
            return response;
        }

        [HttpPost]
        public ResponseClass GetMenuMasterType(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.GetMenuMasterType(userMappingDetailsRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetMenuUserMapping(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.GetMenuUserMapping(userMappingDetailsRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertMenuUserMapping(MenuUserMappingInsertDTO userMappingInsertDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.InsertMenuUserMapping(userMappingInsertDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass MaterialImageManage(MaterialImagaeManageDTO materialImagaeManageDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.MaterialImagaeManage(materialImagaeManageDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteUserMenuMapping(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.DeleteUserMenuMapping(userMappingDetailsRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass PRSPOCGroupManage(PRSPOCRequestDTO pRSPOCRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.PRSPOCGroupManage(pRSPOCRequestDTO);
            return response;

        }

        [HttpPost]
        public ResponseClass UploadCatalogue(CatalogueDataUploadRequestDTO catalogueDataUploadRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _CatalogueManagementBL.UploadCatalogue(catalogueDataUploadRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageCatalogue(CatalogueManagementSearchRequestDTO catalogueManagementSearchRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _CatalogueManagementBL.ManageCatalogue(catalogueManagementSearchRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass UpdateCataloguePublishStatus(UpdatePublishStatusRequestDTO updatePublishStatusRequest)
        {
            ResponseClass response = new ResponseClass();
            response = _CatalogueManagementBL.UpdateCataloguePublishStatus(updatePublishStatusRequest);
            return response;
        }

        [HttpPost]
        public ResponseClass SearchCatalogueData(SearchCatalogueDataRequestDTO searchCatalogueDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _CatalogueManagementBL.SearchCatalogueData(searchCatalogueDataRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass MastersInsert(MastersInsertRequestDTO mastersInsertRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterDataBL.MastersInsert(mastersInsertRequestDTO);
            return response;
        }
    }
}
