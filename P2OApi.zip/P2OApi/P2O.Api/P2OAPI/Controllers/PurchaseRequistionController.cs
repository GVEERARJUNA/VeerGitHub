﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OBAL.Common;
using P2OBAL.PurchaseRequistion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class PurchaseRequistionController : Controller
    {
        private IPurchaseRequistionBL _PurchaseRequistionBL;

        private readonly ILogger<PurchaseRequistionController> _logger;

        public PurchaseRequistionController(IPurchaseRequistionBL purchaseRequistionBL, ILogger<PurchaseRequistionController> logger)
        {
            _PurchaseRequistionBL = purchaseRequistionBL;
            _logger = logger;
        }

        [HttpPost]
        public ResponseClass CreatePurchaseRequistion(PurchaseRequistionDTO shoppingCart)
        {
            ResponseClass response = new ResponseClass();
            response = _PurchaseRequistionBL.CreatePurchaseRequistion(shoppingCart);
            return response;
        }
    }
}
