﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;

namespace TLDCBAL.ODPM
{
    public interface IODPMAdminBL
    {
        ResponseClass GetOdpmGeos();
        public ResponseClass InsertEditTrainingWithAssets(addTrainingRequestDTO request);
        public ResponseClass InsertEditProgramWithTrainings(addProgramRequestDTO request);
        public ResponseClass LoadTraingsandPrograms(TrainingProgramDTO request);
        public ResponseClass EditTraining(EditTrainingRequest request);
        public ResponseClass EditProgram(EditProgramRequest request);
        public ResponseClass DeleteTraining(DeleteRequest request);
        public ResponseClass DeleteProgram(DeleteRequest request);
        public ResponseClass GetTrainingsforProgDrop();
        public ResponseClass GetProgTrainingswithTrainId(GetProgTrainswithTridResp req);
        public ResponseClass GetOdpmCategory();
        public ResponseClass GetDeliveryMethods();
        public ResponseClass GetAssetTypes();
        public ResponseClass GetAssetNamesByType(AssetTypeRequest request);
        public ResponseClass GetODPMAdminLookUpData(string lookupType);
    }
}
