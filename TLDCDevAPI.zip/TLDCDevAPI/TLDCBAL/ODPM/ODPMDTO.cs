﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ODPM
{
    public class ODPMDTO
    {
    }

    public class ODPMinput
    {
        public string companycode { get; set; }
        public string loggedinempcode { get; set; }
        public string departmentcode { get; set; }
        public string grade { get; set; }
        public string trainingcode { get; set; }
        public string programcode { get; set; }
        public string citycode { get; set; }

        public string qtr { get; set; }
        public string year { get; set; }
        public string programmanager { get; set; }
        public string status { get; set; }
        public string rolename { get; set; }
        public string tninumber { get; set; }
        public string rowid { get; set; }
        public string stackholder { get; set; }
        public string searchvalue { get; set; }
        public string rejectreason { get; set; }
        public string workshop { get; set; }
        public string trainingname { get; set; }
        public string fromdate { get; set; }
        public string todate { get; set; }
        public string TemplateId { get; set; }
    }

    public class ShareTNIDetails
    {
        public List<string> department { get; set; }
        public List<string> grade { get; set; }
        public List<string> NominateTeamMembers { get; set; }
        public string trainingname { get; set; }
        public string programname { get; set; }
        public string reason { get; set; }
        public string companycode { get; set; }
        public List<string> qtr { get; set; }
        public string qtryear { get; set; }
        public string city { get; set; }
        public string programmanager { get; set; }
        public string efficacy { get; set; }

        public string stakeholder { get; set; }
        public string loggedinid { get; set; }
        public string appstatus { get; set; }
        public string rowId { get; set; }

        public string actiontype { get; set; }
        public string tninumber { get; set; }

    }

    public class schFROMTNI
    {
        //public List<string> schgeo { get; set; }
        public string schgeo { get; set; }
        //public List<string> schdep { get; set;
        public string schdep { get; set; }
        // public List<string> schcity { get; set; }
        public string schcity { get; set; }
        public string schloc { get; set; }

        //public List<string> schgrade { get; set; }
        public string schgrade { get; set; }
        public string schproname { get; set; }
        public string schtrainame { get; set; }
        public List<string> schasslst { get; set; }
        public List<string> allByUser { get; set; }
        public string tradate { get; set; }
        public string tratodate { get; set; }

        public string frmtime { get; set; }
        public string totime { get; set; }
        public string timezone { get; set; }
        public string facilitatorType { get; set; }
        public string facilitator { get; set; }
        public string AddTrainingDetail { get; set; }
        public string DeliveryMode { get; set; }
        public string RemarksforParticipant { get; set; }
        public string RemarksforManager { get; set; }
        public string link { get; set; }
        public string tninumber { get; set; }
        public string rowId { get; set; }
        public string appstatus { get; set; }
        public string actiontype { get; set; }
        public string loggedinempcode { get; set; }
        public string workshopid { get; set; }
        public string workshoptype { get; set; }
        public string oldwrkshp { get; set; }
        public string reshorcancelreason { get; set; }
        public string workshopstatus { get; set; }
        public string frmhr { get; set; }
        public string frmmin { get; set; }
        public string frmampm { get; set; }
        public string tohr { get; set; }
        public string tomin { get; set; }
        public string toampm { get; set; }
        public string serverstartdate { get; set; }
        public string serverstarttime { get; set; }

        public string serverenddate { get; set; }
        public string serverendtime { get; set; }
    }
    public class schDirectFROMTNI
    {

        public List<string> schgeo { get; set; }

        public List<string> schdep { get; set; }

        public string schcity { get; set; }

        public string schloc { get; set; }

        public List<string> schgrade { get; set; }

        public string schproname { get; set; }
        public string schtrainame { get; set; }
        public List<string> schasslst { get; set; }
        public List<string> allByUser { get; set; }
        public string tradate { get; set; }
        public string frmtime { get; set; }
        public string totime { get; set; }
        public string facilitatorType { get; set; }
        public string facilitator { get; set; }
        public string AddTrainingDetail { get; set; }
        public string DeliveryMode { get; set; }
        public string RemarksforParticipant { get; set; }
        public string RemarksforManager { get; set; }
        public string link { get; set; }
        public string tninumber { get; set; }
        public string rowId { get; set; }
        public string appstatus { get; set; }
        public string actiontype { get; set; }
        public string loggedinempcode { get; set; }
        public string workshopid { get; set; }
        public string workshoptype { get; set; }
        public string oldwrkshp { get; set; }
        public string reshorcancelreason { get; set; }
        public string workshopstatus { get; set; }
        public string frmhr { get; set; }
        public string frmmin { get; set; }
        public string frmampm { get; set; }
        public string tohr { get; set; }
        public string tomin { get; set; }
        public string toampm { get; set; }
        public string tratodate { get; set; }
        public string timezone { get; set; }
        public string serverstartdate { get; set; }
        public string serverstarttime { get; set; }

        public string serverenddate { get; set; }
        public string serverendtime { get; set; }
    }
    public class markAttd
    {
        public string employeecode { get; set; }
        public string tradate { get; set; }
        public string ftradate { get; set; }
        public string reason { get; set; }
        public string remarks { get; set; }
        public string markattd { get; set; }
        public string workshopid { get; set; }
        public string loggedinempcode { get; set; }
    }
    public class ODPMProgramAssetLearningMasterDTO
    {
        public string NodeName { get; set; }
        public string ProgramCode { get; set; }
        public string AssetID { get; set; }
        public string LearningCount { get; set; }
    }
    public class ODPMProgramMasterDTO
    {
        public int ProgramMasterId { get; set; }
        public string ProgramName { get; set; }
        public string ProgramDescription { get; set; }
        public string EditAccess { get; set; }
        public string IsMultiDays { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string CreatedIPAddress { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedOn { get; set; }
        public string UpdatedIPAddress { get; set; }
        public string action { get; set; }
        public string CurrentRole { get; set; }
        public string CurrentRoleCompany { get; set; }
        public string ProgramCode { get; set; }
        public string TSequenceNo { get; set; }
        public string DeletedFlag { get; set; }
        public string DeletedBy { get; set; }
        public string DeletedOn { get; set; }
        public string DeletedIPAddress { get; set; }

    }
    public class ODPMProgramAssetDetailsLearningMasterDTO
    {
        public string ProgramName { get; set; }
        public string NodeName { get; set; }
        public string ProgramCode { get; set; }
        public string AssetID { get; set; }
        public string AssetDetailsID { get; set; }
        public string LearningType { get; set; }
        public string LearningName { get; set; }
    }
    public class ODPMinsertEditProgramLearningRequestDTO
    {
        public string ProgrameCode { get; set; }
        public string DayNo { get; set; }
        public string AssetType { get; set; }
        public string AssetID { get; set; }
        public string assetContent { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }
    public class feedback
    {
        public string feedbackddlid { get; set; }
        public string feedbackddlname { get; set; }
        public string feedbackname { get; set; }
        public string startdate { get; set; }
        public string enddate { get; set; }
        public string workshopid { get; set; }
        public string appstatus { get; set; }
        public string loggedinempcode { get; set; }
        public string surveyid { get; set; }
    }

    public class ODPMReportFilterDTO
    {
        public string CurrentRoleName { get; set; }
        public string EmployeeCode { get; set; }
        public string AssignedCompany { get; set; }
        public string PageNumber { get; set; }
        public string RowsOfPage { get; set; }

    }
    //public class savefeedbackDTO
    //{
    //    public int SurveyId { get; set; }
    //    public DateTime StartDate { get; set; }
    //    public DateTime EndDate { get; set; }
    //    public int TemplateId { get; set; }
    //    public string TemplateName { get; set; }
    //    public string LoggedInEmployeeId { get; set; }


    //}
}
