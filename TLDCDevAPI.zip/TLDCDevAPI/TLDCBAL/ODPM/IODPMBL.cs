﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.CourseAdmin;
using TLDCBAL.ProgramManager;

namespace TLDCBAL.ODPM
{
    public interface IODPMBL
    {
        ResponseClass GetGeo();
        ResponseClass GetODPMshareGeo(ODPMinput oDPMinput);
        ResponseClass GetODPMsuggestGeo(ODPMinput oDPMinput);
        ResponseClass GetODPMschGeo(ODPMinput oDPMinput);
        ResponseClass GetQtr();
        ResponseClass GetODPMQtryear();
        ResponseClass GetStakeholder();
        ResponseClass GetProgramManager(ODPMinput oDPMinput);
        ResponseClass GetStatus();
        ResponseClass GetShareTNIList(ODPMinput oDPMinput);
        ResponseClass GetCity(string companycode);
        ResponseClass GetDepartment(ODPMinput oDPMinput);
        ResponseClass GetODPMshareDepartment(ODPMinput oDPMinput);
        ResponseClass GetODPMsuggestDepartment(ODPMinput oDPMinput);
        ResponseClass GetODPMschDepartment(ODPMinput oDPMinput);
        ResponseClass GetGrade(ODPMinput oDPMinput);
        ResponseClass GetODPMShareGrade(ODPMinput oDPMinput);
        ResponseClass GetODPMsuggestGrade(ODPMinput oDPMinput);

        ResponseClass GetODPMschGrade(ODPMinput oDPMinput);
        
        ResponseClass GetNominateTeamMembers(ODPMinput oDPMinput);

        ResponseClass GetODPMShareNominateTeamMembers(ODPMinput oDPMinput);
        ResponseClass GetTrainingName(ODPMinput oDPMinput);
        ResponseClass GetProgramName(ODPMinput oDPMinput);

        ResponseClass GetEfficacy();
        ResponseClass ODPMInsertShareTNI(List<ShareTNIDetails> shareTNIDetails);
        ResponseClass getedit_TNI_Master(ODPMinput oDPMinput);
        ResponseClass getedit_TNI_DepartmentMapping(ODPMinput oDPMinput);
        ResponseClass getedit_TNI_QtrMapping(ODPMinput oDPMinput);
        ResponseClass getedit_TNI_Grade(ODPMinput oDPMinput);
        ResponseClass getedit_TNI_MemberNomination(ODPMinput oDPMinput);
        ResponseClass getedit_TNI_TrainingName(ODPMinput oDPMinput);
        ResponseClass get_EmployeeAutocompleteName(ODPMinput oDPMinput);

        ResponseClass ODPMInsertSuggestTNI(List<ShareTNIDetails> shareTNIDetails);

        ResponseClass GetODPMSuggestTNIList(ODPMinput oDPMinput);

        ResponseClass getedit_SuggestTNI_Master(ODPMinput oDPMinput);
        ResponseClass ApproveShareTNI (ODPMinput oDPMinput);
        ResponseClass RejectShareTNI (ODPMinput oDPMinput);
        ResponseClass GetODPMPMschtraifrmtnilist(ODPMinput oDPMinput);

        ResponseClass ODPMPMSavetrainschedfromtni(List<schFROMTNI> shareTNIDetails);

        ResponseClass PMSavetrainschedfromdirecttni(List<schDirectFROMTNI> shareTNIDetails);
        


        ResponseClass GetODPMdraftlist(ODPMinput oDPMinput);
        ResponseClass getedit_savedraft(ODPMinput oDPMinput);
        ResponseClass GetODPMPMdraftworkshop();
        ResponseClass GetODPMPM360tworkshop();
        
       ResponseClass GetODPMschCity(ODPMinput oDPMinput);
        ResponseClass GetODPMschLocation(ODPMinput oDPMinput);
        ResponseClass Getallocusrcreateschtraining(ODPMinput oDPMinput);
        ResponseClass Geteditschgeo (ODPMinput oDPMinput);
        ResponseClass Geteditschdep(ODPMinput oDPMinput);
        ResponseClass GeteditschCity(ODPMinput oDPMinput);
        ResponseClass Geteditschloc(ODPMinput oDPMinput);
        ResponseClass Geteditschgrade(ODPMinput oDPMinput);
        ResponseClass Geteditschtraname(ODPMinput oDPMinput);
        ResponseClass Geteditschassetlst(ODPMinput oDPMinput);
        ResponseClass GetODPMQtrDur();
        ResponseClass GetODPMNMProgramName(ODPMinput oDPMinput);
        ResponseClass GetODPMNPTrainingName(ODPMinput oDPMinput);
        ResponseClass GetODPMNPAssetName(ODPMinput oDPMinput);
       
        ResponseClass GetODPMNPEditAssetName(ODPMinput oDPMinput);
        ResponseClass GetOldWorkShop();
        ResponseClass GetODPMOldWrkShpCity(ODPMinput oDPMinput);
        ResponseClass GetODPMOldWrkShpLocation(ODPMinput oDPMinput);
        ResponseClass GetODPMOldWrkShpProName(ODPMinput oDPMinput);
        ResponseClass GetODPMOldWrkShpTraingName(ODPMinput oDPMinput);
        ResponseClass GetODPMOldWrkShpAssetName(ODPMinput oDPMinput);
        ResponseClass ODPMPMSavetrainschedoldwrkshp(List<schFROMTNI> shareTNIDetails);
        ResponseClass GetODPM360vwlist(ODPMinput oDPMinput);
        ResponseClass Getwrkshpcancelreason();
        ResponseClass Getwrkshpreschreason();

        ResponseClass ODPMPMSaveReschCancel(List<schFROMTNI> shareTNIDetails);
        ResponseClass GetPMSchTrainingDetails(ODPMinput oDPMinput);
        ResponseClass getPM360statlist(ODPMinput oDPMinput);
        ResponseClass GetODPMmarkattlist(ODPMinput oDPMinput);
        ResponseClass GetPMemployeeattd(ODPMinput oDPMinput);
        ResponseClass ODPMInsertMarkAttd(List<markAttd> markAttds);
        ResponseClass ODPMFinalMarkAttd(List<markAttd> markAttds);
        
        ResponseClass GetODPMPMmarkemployeeattd(ODPMinput oDPMinput);
        ResponseClass GetODPMenabfeedlist(ODPMinput oDPMinput);
        ResponseClass GetODPMfeedworkshop(ODPMinput oDPMinput);
        ResponseClass GetODPMsurveytype(ODPMinput oDPMinput);
        ResponseClass GetODPMsurveyquestion(ODPMinput oDPMinput);
        ResponseClass GetODPMfeedbackdetails(ODPMinput oDPMinput);
        ResponseClass ODPMsavefeedback(List<feedback> feedback);
        // ResponseClass ManageVideoMasterlist(manageVideoMasterrequestDTO request);
        // ResponseClass InsertVideoMaster(addVideoMasterRequestDTO request);
        // ResponseClass EditVideoMaster(deleteVideoMasterRequestDTO request);
        //ResponseClass DeleteVideoMaster(deleteVideoMasterRequestDTO request);
        // ResponseClass ManageCourseMasterlist(manageCourseMasterrequestDTO request);
        // ResponseClass InsertCourseMaster(addEditCourseMasterrequestDTO request);
        //ResponseClass EditCourseMaster(addEditCourseMasterrequestDTO request);
        //ResponseClass DeleteCourseMaster(deleteCourseMasterRequestDTO request);

        //ResponseClass GetProgramMasterList(ODPMProgramMasterDTO request);
        //ResponseClass GetProgramLearningList(ODPMProgramAssetLearningMasterDTO request);
        // ResponseClass InsertEditProgramMaster(ODPMProgramMasterDTO request);
        // ResponseClass GetProgramMasterDataByProgramCode(ODPMProgramMasterDTO request);

        ResponseClass Gettninumbergeo(ODPMinput oDPMinput);
        ResponseClass Gettninumberdepartment(ODPMinput oDPMinput);
        ResponseClass Gettninumbergrade(ODPMinput oDPMinput);
        ResponseClass GettninumberprogramandTraining(ODPMinput oDPMinput);
        ResponseClass Gettninumbercity(ODPMinput oDPMinput);
        
        ResponseClass GetProgramLearningListByPRcodeAndAssetID(ODPMProgramAssetDetailsLearningMasterDTO request);
        ResponseClass GetAllocateAssetDropDownDataByAssetID(ODPMinsertEditProgramLearningRequestDTO request);
        ResponseClass getODPMAllocateEntityDropDownData(getAllocateEntityDropDownDataDTO request);
        ResponseClass getParticipantdiscrianduserinstru(ODPMinput oDPMinput);
        ResponseClass getParticipanttrainingdetails(ODPMinput oDPMinput);
        ResponseClass getODPMMarkGeo(ODPMinput oDPMinput);
        ResponseClass getODPMMarkProgramManager(ODPMinput oDPMinput);
        ResponseClass getODPMPMMarkworkshop(ODPMinput oDPMinput);
    }
}
