﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCDAL;
using TLDCBAL.Service;
using TLDCBAL.CourseAdmin;
using TLDCBAL.ProgramManager;
using TLDCBAL.Qualtrics;
using NpgsqlTypes;
using System.Data.SqlClient;

namespace TLDCBAL.ODPM
{
    public class ODPMAdminBL : IODPMAdminBL
    {
        private readonly IOptions<IDBConnection> appSettings;
        private readonly IServiceConnect _serviceconnect;
        private IQualtricsDataBL _qualtricsBL;
        DBConnection dBConnection;
        public ODPMAdminBL(IOptions<IDBConnection> app,IServiceConnect serviceconnect)
        {
            appSettings = app;
             _serviceconnect = serviceconnect;
            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }
        
        public ResponseClass InsertEditTrainingWithAssets(addTrainingRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            if (request.Action == "ADD")
            {
                try
                {
                    //string gender = string.IsNullOrEmpty(request.Gender) || request.Gender == "select" ? "N" : request.Gender;
                    string targetAudience = string.IsNullOrEmpty(request.TargetAudience) ? "" : request.TargetAudience;
                    string participant = string.IsNullOrEmpty(request.ParticipantPerSession) ? "0" : request.ParticipantPerSession;

                    string trid = string.Empty;
                    string traingCode = string.Empty;
                    int recId = 0;
                    string sqlQuery1 = "SELECT coalesce(max(#tid#),0) as #trid# FROM public.#ODPM_Training_Master#";

                    sqlQuery1 = sqlQuery1.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                    if (npgsqlDataReader1.Read())
                    {
                        trid = npgsqlDataReader1[0].ToString();
                        recId = Convert.ToInt32(trid) + 1;
                        traingCode = "T" + recId;
                    }
                    else
                    {
                        ++recId;
                        traingCode = "T" + recId;
                    }

                    npgsqlCon.Close();

                    //Insert Data to ODPM_Training_Master table 
                    request.Description = request.Description.Replace("'", "''");
                    request.Type = request.Type.Replace('_', ' ');
                    if (!ValidateProgorTrainingExist(CommonFunction.RemoveQuotes(request.TrainingName), "Train"))
                    {
                        string strinsTrainDetais = "CALL public.usp_insert_odpm_trainingdetails(" + recId + ",'" + traingCode + "','" + CommonFunction.RemoveQuotes(request.TrainingName) + "','" +
                            request.Category + "','" + request.Geo + "','" + targetAudience + "','" + participant + "','" +
                            request.Certification + "','" + request.Feedback + "','" + request.DeliveryMethod + "','" + request.TrainingAttachmentPath + "', '" +
                            CommonFunction.RemoveQuotes(request.LearningObjectives) + "','" + CommonFunction.RemoveQuotes(request.Description) + "','" + request.CreatedBy + "','" + request.TimeZone + "')";
                        npgsqlCon.Open();
                        NpgsqlCommand cmd = new NpgsqlCommand(strinsTrainDetais, npgsqlCon);
                        NpgsqlDataReader dataReader = cmd.ExecuteReader();

                        npgsqlCon.Close();
                        NpgsqlConnection.ClearPool(npgsqlCon);
                    }
                    else
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Training Name '"+ CommonFunction.RemoveQuotes(request.TrainingName) + "' is already exist";
                        return response;
                    }
                    //Get Latest Training ID Code
                    string Type = string.Empty;
                    string trinId = string.Empty;

                    string strmaxTrainid = "SELECT max(#tid#) as #TrID# FROM public.#ODPM_Training_Master#";

                    strmaxTrainid = strmaxTrainid.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand2 = new NpgsqlCommand(strmaxTrainid, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader2 = npgsqlCommand2.ExecuteReader();

                    if (npgsqlDataReader2.Read())
                    {
                        trinId = npgsqlDataReader2[0].ToString();
                    }
                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);

                    //Get Latest Training asset Id from
                    string strainAssetID = string.Empty;
                    int trainAssetID = 0;
                    string sqlQuery12 = "SELECT coalesce(max(#tid#),0) as #TrainAssetID# FROM public.#ODPM_Training_Assets_Mapping#";

                    sqlQuery12 = sqlQuery12.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand12 = new NpgsqlCommand(sqlQuery12, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader12 = npgsqlCommand12.ExecuteReader();

                    if (npgsqlDataReader12.Read())
                    {
                        strainAssetID = npgsqlDataReader12[0].ToString();
                        trainAssetID = Convert.ToInt32(strainAssetID) + 1;
                    }
                    else
                    {
                        ++trainAssetID;
                    }
                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);

                    if (request.addTrainingAssets != null && request.addTrainingAssets.Count > 0)
                    {
                        foreach (var item in request.addTrainingAssets)
                        {
                            //Insert Data ODPM_Training_Assets_Mapping
                            if (!string.IsNullOrEmpty(item.AssetTyp))
                            {

                                string strinsTrainAsetsMapping = "CALL public.usp_insert_odpm_training_assets_mappings(" + trainAssetID + ",'" + traingCode + "','" + item.AssetCode + "','" + CommonFunction.RemoveQuotes(item.AssetName) + "','" + item.PreorPost + "','" + item.Mandatory + "','" + item.InterOrExter + "','" + item.AssetTyp + "','" + request.CreatedBy + "')";

                                npgsqlCon.Open();

                                NpgsqlCommand cmd1 = new NpgsqlCommand(strinsTrainAsetsMapping, npgsqlCon);

                                NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();

                                npgsqlCon.Close();
                                ++trainAssetID;
                            }
                        }
                    }

                    
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Add Training", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            else if (request.Action == "EDIT")
            {
                try
                {
                    if (string.IsNullOrEmpty(request.TrainingName))
                    {
                        response.responseMessage = "Please provide traiing assets.";
                    }
                    else
                    {
                        //Update ODPM_Training_Master table
                        string sqlQueryupdateTraining = "CALL public.usp_update_odpm_training_withid(" + request.TorPid + ",'" + 
                            request.Category + "','" + request.TrainingName + "','" + request.Geo + "','" + request.TargetAudience + "','" + 
                            request.ParticipantPerSession + "','" + request.Certification + "','"+ request.Feedback + "','" + request.DeliveryMethod +"','"+
                            request.TrainingAttachmentPath + "','" + CommonFunction.RemoveQuotes(request.LearningObjectives) + "','" + 
                            CommonFunction.RemoveQuotes(request.Description) + "','" + request.UpdatedBy + "','" + request.TimeZone + "')";
                        //string sqlQueryupdateTraining = "UPDATE public.#ODPM_Training_Master# SET #category_code#='" + request.Category + 
                        //    "',#geo_code#='" + request.Geo + "',#target_audience#='" + request.TargetAudience +
                        //    "',#gender_code#='" + request.Gender + "',#participant_per_session#='" + request.ParticipantPerSession +
                        //     "',#certification_require#='" + request.Certification + "',#efficacy#='" + request.Efficacy +
                        //      "',#feedback_enable#='" + request.Feedback + "',#odpm_metrics_linkage#='" + request.ODPMMetricsLinkage +
                        //       "',#delivery_method#='" + request.DeliveryMethod + "',#thumbnail_image_path#='" + request.TrainingAttachmentPath +
                        //        "',#learning_objectives#='" + CommonFunction.RemoveQuotes(request.LearningObjectives) + "',#description#='" + CommonFunction.RemoveQuotes(request.Description) +
                        //        "',#active_status#='" + 1 + "',#modifiedby#='" + request.UpdatedBy +
                        //        "',#modifiedon#=now()" +
                        //    "WHERE #tid# = '" + request.TorPid + "'";

                        //sqlQueryupdateTraining = sqlQueryupdateTraining.Replace('#', '"');
                        npgsqlCon.Open();
                        NpgsqlCommand cmd = new NpgsqlCommand(sqlQueryupdateTraining, npgsqlCon);
                        NpgsqlDataReader dataReader = cmd.ExecuteReader();
                        npgsqlCon.Close();
                        NpgsqlConnection.ClearPool(npgsqlCon);

                        //Update previous ODPM_Training_Assets_Mapping
                        if (request.addTrainingAssets != null && request.addTrainingAssets.Count > 0)
                        {
                            foreach (var item in request.addTrainingAssets)
                            {
                                if (!string.IsNullOrEmpty(item.AssetTyp))
                                {
                                    item.AssetID = string.IsNullOrEmpty(item.AssetID) ? "0" : item.AssetID;
                                    //string sqlQueryupdateAssets = "UPDATE public.#ODPM_Training_Assets_Mapping# SET #asset_code#='" + item.AssetCde + "',#is_mandatory#='" + item.Mandatory + "',#internal_external#='" + item.InterOrExter + "',#asset_type#='" + item.AssetTyp + "',#UpdatedBy#='" + request.UpdatedBy + "',#UpdatedOn#=now() WHERE #tid# = '" + item.AssetID + "'";
                                    string sqlQueryupdateAssets = "CALL public.usp_update_odpm_training_assets_mappings(" + item.AssetID + ",'" + request.TorPCode + "','" + item.AssetCode + "','" + CommonFunction.RemoveQuotes(item.AssetName) + "','" + item.PreorPost + "','" + item.Mandatory + "','" + item.InterOrExter + "','" + item.AssetTyp + "','" + request.CreatedBy + "')";
                                    sqlQueryupdateAssets = sqlQueryupdateAssets.Replace('#', '"');
                                    npgsqlCon.Open();
                                    NpgsqlCommand cmd2 = new NpgsqlCommand(sqlQueryupdateAssets, npgsqlCon);
                                    NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();
                                    npgsqlCon.Close();
                                }
                            }
                        }
                        
                    }
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Edit Training", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            return response;
        }

        private bool ValidateProgorTrainingExist(string name,string Type)
        { 
            bool isExist = false;
            string sqlQuery1 = string.Empty;
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            if(Type == "Prog")
                sqlQuery1 = "SELECT LENGTH(#program_name#) as #trid# FROM public.#ODPM_Program_Master# WHERE #program_name# = '" + name + "'";
            //string sqlQuery1 = "SELECT coalesce(max(#ProgramId#),0) as #ProgramId# FROM public.#ODPM_Program_Master#";
            else
                sqlQuery1 = "SELECT LENGTH(#training_name#) as #trid# FROM public.#ODPM_Training_Master# WHERE #training_name# = '" + name+"'";
            
            sqlQuery1 = sqlQuery1.Replace('#', '"');
            npgsqlCon.Open();
            NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);
            NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

            if (npgsqlDataReader1.Read())
            {
                isExist = Convert.ToInt32(npgsqlDataReader1[0].ToString()) > 0 ? true : false;
            }
            npgsqlCon.Close();

            return isExist;
        }

        public ResponseClass InsertEditProgramWithTrainings(addProgramRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            if (request.Action == "ADD")
            {
                try
                {
                    //ProgramId to incremental value
                    string TypeNo = string.Empty;
                    int progID = 0;
                    string sqlQuery1 = "SELECT coalesce(max(#ProgramId#),0) as #ProgramId# FROM public.#ODPM_Program_Master#";

                    sqlQuery1 = sqlQuery1.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                    if (npgsqlDataReader1.Read())
                    {
                        TypeNo = npgsqlDataReader1[0].ToString();
                        progID = Convert.ToInt32(TypeNo) + 1;
                        request.Prog_Code = "P" + progID;
                    }
                    else
                    {
                        ++progID;
                        request.Type = "P" + progID;
                    }

                    npgsqlCon.Close();

                    //Insert Data VideoMaster
                    request.Description = request.Description.Replace("'", "''");
                    request.Type = request.Type.Replace('_', ' ');
                    if (!ValidateProgorTrainingExist(CommonFunction.RemoveQuotes(request.ProgramName), "Prog"))
                    {
                        string strinsProgdetails = "CALL public.usp_insert_odpm_programdetails(" + progID + ",'" + request.Prog_Code + "','" + CommonFunction.RemoveQuotes(request.ProgramName) + "','" + request.Certification + "','" + request.NoOfProjects + "','" + request.Feedback + "','" + request.ProgramAttachmentPath + "','" + CommonFunction.RemoveQuotes(request.LearningObjectives) + "','" + CommonFunction.RemoveQuotes(request.Description) + "','" + request.CreatedBy + "','" + request.TimeZone + "')";
                        //string sqlQuery = "INSERT INTO public.#ODPM_Program_Master#(#ProgramId#,#program_code#,#program_name#,#certification_require#,#efficacy#,#project_count#,#feedback_enable#,#odpm_metrics_linkage#,#thumbnail_image_path#,#learning_objectives#,#description#,#active_status#,#createdby#,#createdon#)";
                        //sqlQuery = sqlQuery + "VALUES(" + progID +",'" +request.Prog_Code + "', '" + CommonFunction.RemoveQuotes(request.ProgramName) + "', '" + request.Certification + "', '" + request.Efficacy + "', '" + request.NoOfProjects + "', '" + request.Feedback + "', '" + request.ODPMMetricsLinkage + "','"+ request.ProgramAttachmentPath +"','" + CommonFunction.RemoveQuotes(request.LearningObjectives) + "', '" + CommonFunction.RemoveQuotes(request.Description) + "',1, '" + request.CreatedBy + "',now() ";
                        //sqlQuery = sqlQuery + ")";
                        //sqlQuery = sqlQuery.Replace('#', '"');
                        npgsqlCon.Open();
                        NpgsqlCommand cmd = new NpgsqlCommand(strinsProgdetails, npgsqlCon);
                        NpgsqlDataReader dataReader = cmd.ExecuteReader();

                        npgsqlCon.Close();
                        NpgsqlConnection.ClearPool(npgsqlCon);
                    }
                    else
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Program Name '" + CommonFunction.RemoveQuotes(request.ProgramName) + "' is already exist";
                        return response;
                    }
                    //Get Latest Training ID Code
                    string Type = string.Empty;
                    string ProgramId = string.Empty;

                    string sqlQuery2 = "SELECT max(#ProgramId#) as #ProgramId# FROM public.#ODPM_Program_Master#";

                    sqlQuery2 = sqlQuery2.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand2 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader2 = npgsqlCommand2.ExecuteReader();

                    if (npgsqlDataReader2.Read())
                    {
                        ProgramId = npgsqlDataReader2[0].ToString();
                    }
                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);

                    //Get Latest Prog Train Id from
                    string progTrnID = string.Empty;
                    int progTrainID = 0;
                    string sqlQuery12 = "SELECT coalesce(max(#Id#),0) as #ProgTrainID# FROM public.#ODPM_Program_Training_Mapping#";

                    sqlQuery12 = sqlQuery12.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand12 = new NpgsqlCommand(sqlQuery12, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader12 = npgsqlCommand12.ExecuteReader();

                    if (npgsqlDataReader12.Read())
                    {
                        progTrnID = npgsqlDataReader12[0].ToString();
                        progTrainID = Convert.ToInt32(progTrnID) + 1;
                    }
                    else
                    {
                        ++progTrainID;
                    }

                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);


                    if (request.addProgramTrainings != null && request.addProgramTrainings.Count > 0)
                    {
                        foreach (var item in request.addProgramTrainings)
                        {
                            //Insert Data in to add Trainings per Program
                            if (!string.IsNullOrEmpty(item.TrainingName))
                            {
                                //sqlQuery3 = "INSERT INTO public.#ODPM_Program_Training_Mapping#(#Prog_Train_ID#,#Program_Id#,#Training_Id#,#Geo_Code#) " + "VALUES('" + item.TrainingName + "', '" + ProgramId + "', '" + item.Geo + "', '" + item.TargetAudience + "', '" + item.Gender + "', '" + item.ParticipantPerSession + "', '" + ProgramId + "')";
                                //sqlQuery3 = "INSERT INTO public.#ODPM_Program_Training_Mapping#(#Id#,#program_id#,#training_id#,#geo_code#,#createdby#,#createdon#) " + "VALUES("+ progTrainID+",'" + request.Prog_Code + "', '" + item.TrainingName + "', '" + item.Geo + "', '" + request.CreatedBy + "',now())";
                                //sqlQuery3 = sqlQuery3.Replace('#', '"');
                                string strinsProgTrainMappings = "CALL public.usp_insert_odpm_program_training_mappings(" + progTrainID + ",'" + request.Prog_Code + "','" + CommonFunction.RemoveQuotes(item.TrainingName) + "','" + item.Geo + "','" + request.CreatedBy + "')";

                                npgsqlCon.Open();
                                NpgsqlCommand cmd1 = new NpgsqlCommand(strinsProgTrainMappings, npgsqlCon);
                                NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();

                                npgsqlCon.Close();
                                ++progTrainID;
                            }
                        }
                    }
                    
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Add Training", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            else if (request.Action == "EDIT")
            {
                try
                {
                    if (string.IsNullOrEmpty(request.ProgramName))
                    {
                        response.responseMessage = "Please provide traiing assets.";
                    }
                    else
                    {
                        string sqlQueryupdateProgram = "CALL public.usp_update_odpm_program_withid(" + request.ProgId + ",'" + request.ProgramName + "','" + request.Certification + "','" + request.NoOfProjects + "','" + request.Feedback + "','" + request.ProgramAttachmentPath + "','" + CommonFunction.RemoveQuotes(request.LearningObjectives) + "','" + CommonFunction.RemoveQuotes(request.Description) + "','" + request.UpdatedBy + "','" + request.TimeZone + "')";

                        //string sqlQueryupdateProgram = "UPDATE public.#ODPM_Program_Master# SET #certification_require#='" + request.Certification +
                        //    "',#efficacy#='" + request.Efficacy + "',#project_count#='" + request.NoOfProjects +
                        //    "',#feedback_enable#='" + request.Feedback + "',#odpm_metrics_linkage#='" + request.ODPMMetricsLinkage +
                        //     "',#thumbnail_image_path#='" + request.ProgramAttachmentPath + "',#learning_objectives#='" + CommonFunction.RemoveQuotes(request.LearningObjectives) +
                        //      "',#description#='" + CommonFunction.RemoveQuotes(request.Description) + "',#active_status#='" + 1 + "',#modifiedby#='" + request.UpdatedBy +
                        //        "',#modifiedon#=now() WHERE #ProgramId# = " + request.ProgId;

                        //sqlQueryupdateProgram = sqlQueryupdateProgram.Replace('#', '"');
                        npgsqlCon.Open();
                        NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQueryupdateProgram, npgsqlCon);
                        NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();
                        npgsqlCon.Close();
                        NpgsqlConnection.ClearPool(npgsqlCon);
                        //Update previous ODPM_Program_Training_Mapping
                        if (request.addProgramTrainings != null && request.addProgramTrainings.Count > 0)
                        {
                            foreach (var item in request.addProgramTrainings)
                            {
                                if (item.Id == 0 && request.ProgId > 0) item.ProgId = "P" + request.ProgId.ToString();
                                //item.Id = string.IsNullOrEmpty(item.Id) ? "0" : item.AssetID;
                                if (!string.IsNullOrEmpty(item.ProgId))
                                {
                                    //string sqlQueryupdatePogTrain = "UPDATE public.#ODPM_Program_Training_Mapping# SET #training_id#='" + item.TrainingId + "',#geo_code#='" + item.Geo + "', #modifiedby#='" + request.UpdatedBy + "',#modifiedon#=now() WHERE #Id# = " + item.Id + " and #program_id#='"+item.ProgId + "'";
                                    //sqlQueryupdatePogTrain = sqlQueryupdatePogTrain.Replace('#', '"');
                                    string sqlQueryupdatePogTrain = "CALL public.usp_update_odpm_program_training_mappings(" + item.Id + ",'" + item.ProgId + "','" + item.TrainingId + "','" + item.Geo + "','" + request.CreatedBy + "')";
                                    npgsqlCon.Open();
                                    NpgsqlCommand ptmap = new NpgsqlCommand(sqlQueryupdatePogTrain, npgsqlCon);
                                    NpgsqlDataReader dataReader2 = ptmap.ExecuteReader();
                                    npgsqlCon.Close();
                                }
                            }
                        }
                    }
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Edit Training", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            return response;
        }

        public ResponseClass LoadTraingsandPrograms(TrainingProgramDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable trainorprog = new DataTable();
                string selectQuery = string.Empty;
                string torpsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(torpsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_odpm_loadtraingsandprograms(:p_torptype,:p_trainorprog)
                                                                   ", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.Type))
                            cmd.Parameters.AddWithValue("p_torptype", DbType.String).Value = request.Type;
                        else
                            cmd.Parameters.AddWithValue("p_torptype", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.TorPName))
                            cmd.Parameters.AddWithValue("p_trainorprog", DbType.String).Value = request.TorPName.ToLower();
                        else
                            cmd.Parameters.AddWithValue("p_trainorprog", DbType.String).Value = "";


                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(trainorprog);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(trainorprog);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }
                //if (request.Type == "TRN")
                //{
                //    selectQuery = string.Empty;
                //    selectQuery = "select A.#training_code# AS trnorprgid, 'Training' as type,A.#training_name# as trainingname," +
                //        "A.#target_audience# as targetaudience,A.#geo_code# as geo,A.#gender_code# as Gender," +
                //        "A.#certification_require# as certification,A.#feedback_enable# as feedback,A.#efficacy# as efficacy," +
                //        "concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby," +
                //        "TO_CHAR(A.#createdon#, 'dd-Mon-yyyy') as createddate " +
                //        "from #ODPM_Training_Master# A " +
                //        "inner join #EmployeeMaster# EM on A.#createdby# = EM.#EXTERNALDATAREFERENCE# " +
                //        "where A.#active_status# = '1'";
                //    if (!string.IsNullOrEmpty(request.TorPName))
                //        selectQuery = selectQuery + " and  lower(A.#training_name#) like '%" + request.TorPName.ToLower() + "%'";
                //    //if (request.Geo == "Y")
                //    //    selectQuery = selectQuery + " and  lower(A.#geo_code#) = " + request.Geo + ")";
                //    selectQuery = selectQuery + " order by A.#tid# ";
                //}

                //if (request.Type == "PRG")
                //{
                //    selectQuery = string.Empty;
                //    selectQuery = "select A.#program_code# AS trnorprgid, 'Program' as type,A.#program_name# as trainingname," +
                //        "'' as targetaudience,'' as geo,'' as Gender," +
                //        "A.#certification_require# as certification,A.#feedback_enable# as feedback,A.#efficacy# as efficacy," +
                //        "concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby," +
                //        "TO_CHAR(A.#createdon#, 'dd-Mon-yyyy') as createddate from #ODPM_Program_Master# A " +
                //        "inner join #EmployeeMaster# EM on A.#createdby# = EM.#EXTERNALDATAREFERENCE# "+
                //        "where A.#active_status# = '1'"; 
                //    if (!string.IsNullOrEmpty(request.TorPName))
                //        selectQuery = selectQuery + " and  lower(A.#program_name#) like '%" + request.TorPName.ToLower() + "%'";
                //    selectQuery = selectQuery + " order by A.#ProgramId# ";
                //    //if (request.Geo == "Y")
                //    //    selectQuery = selectQuery + " and lower(A.#Geo_code#) = " + request.Geo + ")";
                //}
                //if (request.Type == "ALL")
                //{
                //    selectQuery = string.Empty;

                //    selectQuery = "(select A.#training_code# AS trnorprgid, 'Training' as type,A.#training_name# as trainingname," +
                //        "A.#target_audience# as targetaudience,A.#geo_code# as Geo,A.#gender_code# as gender," +
                //        "A.#certification_require# as certification,A.#feedback_enable# as feedback,A.#efficacy# as efficacy," +
                //        "concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby," +
                //        "TO_CHAR(A.#createdon#, 'dd-Mon-yyyy') as createddate " +
                //        "from #ODPM_Training_Master# A " +
                //        "inner join #EmployeeMaster# EM on A.#createdby# = EM.#EXTERNALDATAREFERENCE# " +
                //        "where A.#active_status# = '1' ";
                //    if (!string.IsNullOrEmpty(request.TorPName))
                //        selectQuery = selectQuery + " and  lower(A.#training_name#) like '%" + request.TorPName.ToLower() + "%'";
                //    if (request.Geo == "Y")
                //        selectQuery = selectQuery + " and lower(A.#geo_code#) = " + request.Geo + ")";
                //    selectQuery = selectQuery + " order by A.#tid# )";


                //    selectQuery = selectQuery + "UNION ";

                //    selectQuery = selectQuery + "(select A.#program_code# AS trnorprgid, 'Program' as type,A.#program_name# as trainingname," +
                //        "'' as targetaudience,'' as Geo,'' as gender," +
                //        "A.#certification_require# as certification,A.#feedback_enable# as feedback,A.#efficacy# as efficacy," +
                //        "concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby," +
                //        "TO_CHAR(A.#createdon#, 'dd-Mon-yyyy') as createddate " +
                //        "from #ODPM_Program_Master# A " +
                //        "inner join #EmployeeMaster# EM on A.#createdby# = EM.#EXTERNALDATAREFERENCE# " +
                //        "where A.#active_status# = '1'";
                //    if (!string.IsNullOrEmpty(request.TorPName))
                //        selectQuery = selectQuery + " and  lower(A.#program_name#) like '%" + request.TorPName.ToLower() + "%'";
                //    selectQuery = selectQuery + " order by A.#ProgramId# )";
                //}

                ////selectQuery = selectQuery + " order by A.#InsertedDateTime# desc";
                //selectQuery = selectQuery.Replace('#', '"');

                //string pgsqlConnection = appSettings.Value.DbConnection;
                //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                //npgsql.Open();

                //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                //dataAdapter.Fill(trainingGroup);
                //npgsql.Close();
                //NpgsqlConnection.ClearPool(npgsql);
                //response.responseCode = 1;
                //CommonFunction function = new CommonFunction();
                //response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("LoadTraingsandPrograms", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass EditTraining(EditTrainingRequest request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingmodel = new DataTable();
                string tgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(tgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_odpm_get_trainingforEdit(:trainid)
                                                                   ", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(request.TorPid))
                            cmd.Parameters.AddWithValue("trainid", DbType.String).Value = request.TorPid;
                        else
                            cmd.Parameters.AddWithValue("trainid", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(trainingmodel);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(trainingmodel);
                        response.responseCode = 1;
                        response.responseJSONSecondary = JsonConvert.SerializeObject(GetTrainingAssetsForEdit(request.TorPid));
                        response.responseMessage = "Success";
                    }
                }

                //string selectQuery = string.Empty;

                //selectQuery = "select tid,training_code,training_name,category_code,geo_code," +
                //    "target_audience,gender_code,participant_per_session,certification_require," +
                //    "efficacy,feedback_enable,odpm_metrics_linkage,delivery_method," +
                //    "thumbnail_image_path,learning_objectives,description " +
                //    "from public.#ODPM_Training_Master# vm " +
                //    "where #active_status# ='1' and #training_code# ='" + request.TorPid + "'";
                //selectQuery = selectQuery.Replace('#', '"');

                //string pgsqlConnection = appSettings.Value.DbConnection;
                //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                //npgsql.Open();

                //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                //dataAdapter.Fill(Trainingmodel);
                //npgsql.Close();
                //NpgsqlConnection.ClearPool(npgsql);
                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(Trainingmodel);
                //response.responseJSONSecondary = JsonConvert.SerializeObject(GetTrainingAssetsForEdit(request.TorPid));

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditTraining", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        
        public DataTable GetTrainingAssetsForEdit(string trainid)
        {
            ResponseClass response = new ResponseClass();
            DataTable trainingAssetsmodel = new DataTable();
            string tgsqlConnection = appSettings.Value.DbConnection;
            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(tgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_odpm_get_assetsfortrainingforEdit(:trainid)
                                                                   ", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(trainid))
                            cmd.Parameters.AddWithValue("trainid", DbType.String).Value = trainid;
                        else
                            cmd.Parameters.AddWithValue("trainid", DbType.String).Value = string.Empty;
                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(trainingAssetsmodel);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(trainingAssetsmodel);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }
                //string selectQuery = string.Empty;
                //selectQuery = "select * from public.#ODPM_Training_Assets_Mapping# vm where #training_id# ='" + trainid + "'";

                //selectQuery = selectQuery.Replace('#', '"');

                //string pgsqlConnection = appSettings.Value.DbConnection;
                //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                //npgsql.Open();

                //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);
                //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                //dataAdapter.Fill(trainingAssetsmodel);
                //npgsql.Close();
                //NpgsqlConnection.ClearPool(npgsql);
                //return trainingAssetsmodel;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("TrainingorProg", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return trainingAssetsmodel;
        }

        public ResponseClass EditProgram(EditProgramRequest request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dtEditProgram = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_odpm_get_programforEdit(:progid)
                                                                   ", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(request.TorPid))
                            cmd.Parameters.AddWithValue("progid", DbType.String).Value = request.TorPid;
                        else
                            cmd.Parameters.AddWithValue("progid", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEditProgram);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEditProgram);
                        response.responseCode = 1;
                        response.responseJSONSecondary = JsonConvert.SerializeObject(GetProgTrainingsForEdit(request.TorPid));
                        response.responseMessage = "Success";
                    }
                }

                //return response;




                //DataTable videoProgram = new DataTable();
                //string selectQuery = string.Empty;

                //selectQuery = "select * from public.#ODPM_Program_Master# vm where #active_status# ='1' and #program_code# ='" + request.TorPid + "'";
                //selectQuery = selectQuery.Replace('#', '"');

                //string pgsqlConnection = appSettings.Value.DbConnection;
                //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                //npgsql.Open();

                //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);
                //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                //dataAdapter.Fill(videoProgram);
                //npgsql.Close();
                //NpgsqlConnection.ClearPool(npgsql);
                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(videoProgram);
                //response.responseJSONSecondary = JsonConvert.SerializeObject(GetProgTrainingsForEdit(request.TorPid));

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditProgram", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public DataTable GetProgTrainingsForEdit(string progId)
        {
            ResponseClass response = new ResponseClass();
            DataTable progTrainingsmodel = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_odpm_getprogtrainingsbyprogid(:progid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(progId))
                        cmd.Parameters.AddWithValue("progid", DbType.String).Value = progId;
                    else
                        cmd.Parameters.AddWithValue("progid", DbType.String).Value = string.Empty;
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(progTrainingsmodel);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(progTrainingsmodel);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return progTrainingsmodel;



            //ResponseClass response = new ResponseClass();

            //DataTable progTrainingsmodel = new DataTable();
            //try
            //{
            //    string selectQuery = string.Empty;
            //    selectQuery = "select ptm.#Id#,ptm.#program_id#,ptm.#training_id# ," +
            //        "tm.#geo_code#,tm.#category_code#,tm.#target_audience#,tm.#gender_code#,tm.#participant_per_session# " +
            //        "from public.#ODPM_Program_Training_Mapping# ptm " +
            //        "join public.#ODPM_Training_Master# tm on ptm.#training_id# = tm.#training_code# " +
            //        "where ptm.#program_id# ='" + progId + "'";

            //    selectQuery = selectQuery.Replace('#', '"');

            //    string pgsqlConnection = appSettings.Value.DbConnection;
            //    NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            //    npgsql.Open();

            //    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);
            //    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            //    dataAdapter.Fill(progTrainingsmodel);
            //    npgsql.Close();
            //    NpgsqlConnection.ClearPool(npgsql);
            //    return progTrainingsmodel;
            //}
            //catch (Exception ex)
            //{
            //    _serviceconnect.LogConnect("TrainingorProg", "1024", ex.Message, "Exception");
            //    response.responseCode = 0;
            //    response.responseMessage = ex.Message;
            //}

            //return progTrainingsmodel;
        }
        public ResponseClass DeleteTraining(DeleteRequest request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            try
            {
                ////Update Program data with active_status =0 by Training Id

                string sqlQuery = "UPDATE public.#ODPM_Training_Master# set #active_status# =0,#modifiedby# ='" + request.ModifiedBy + "',#modifiedon#=now() where #training_code# ='" + request.TorPid + "'";

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();

                npgsqlCon.Close();
                NpgsqlConnection.ClearPool(npgsqlCon);
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Delete Training", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass DeleteProgram(DeleteRequest request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            try
            {
                //Update Program data with active_status =0 by Program id
                string sqlQuery = "UPDATE public.#ODPM_Program_Master# set #active_status# =0,#modifiedby# ='" + request.ModifiedBy + "',#modifiedon#=now() where #program_code# ='" + request.TorPid + "'";

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();

                npgsqlCon.Close();
                NpgsqlConnection.ClearPool(npgsqlCon);
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Delete Program", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetTrainingsforProgDrop()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable trainingsforProgmodel = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_odpm_get_trainingsforprogdrop()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(trainingsforProgmodel);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(trainingsforProgmodel);
                        response.responseCode = 1;
                    }
                }
            }
            //ResponseClass response = new ResponseClass();
            //try
            //{
            //    DataTable trainingsforProgmodel = new DataTable();
            //    string selectQuery = string.Empty;

            //    selectQuery = "select distinct training_code,training_name " +
            //        "from public.#ODPM_Training_Master# vm " +
            //        "where #active_status# ='1' ";
            //    //selectQuery = selectQuery.Replace('#', '"');

            //    string pgsqlConnection = appSettings.Value.DbConnection;
            //    NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            //    npgsql.Open();

            //    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            //    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            //    dataAdapter.Fill(trainingsforProgmodel);
            //    npgsql.Close();
            //    NpgsqlConnection.ClearPool(npgsql);
            //    response.responseCode = 1;
            //    response.responseJSON = JsonConvert.SerializeObject(trainingsforProgmodel);
            //}
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetTrainingsforProgDrop", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetOdpmGeos()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtOdpmGeo = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_geo()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; 
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtOdpmGeo);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtOdpmGeo);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetProgTrainingswithTrainId(GetProgTrainswithTridResp req)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable trainingsforProg = new DataTable();
                string selectQuery = string.Empty;
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_odpm_get_progtrainingswithtrainingcode(:p_traincode)
                                                                   ", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(req.Trid))
                            cmd.Parameters.AddWithValue("p_traincode", DbType.String).Value = req.Trid;
                        else
                            cmd.Parameters.AddWithValue("p_traincode", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(trainingsforProg);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(trainingsforProg);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }
                //selectQuery = "select distinct training_code,category_code,geo_code,target_audience,gender_code,participant_per_session " +
                //    "from public.#ODPM_Training_Master# vm " +
                //    "where #active_status# ='1' and training_code = '" + req.Trid + "'";

                //selectQuery = selectQuery.Replace('#', '"');

                //string pgsqlConnection = appSettings.Value.DbConnection;
                //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                //npgsql.Open();

                //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                //dataAdapter.Fill(trainingsforProgmodel);
                //npgsql.Close();
                //NpgsqlConnection.ClearPool(npgsql);
                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(trainingsforProgmodel);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProgTrainingswithTrainId", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetOdpmCategory()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtCategory = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_odpm_category()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtCategory);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtCategory);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetCategory", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetDeliveryMethods()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtDeliveryMethods = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_odpm_deliverymethods()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtDeliveryMethods);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtDeliveryMethods);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetCategory", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetAssetTypes()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtAssetTypes = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_odpm_assettype()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtAssetTypes);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtAssetTypes);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetCategory", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetAssetNamesByType(AssetTypeRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtAssetNames = new DataTable();
            DataTable dtSurveys = new DataTable();
            DataTable dtAssessments = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_odpm_assetnamebytype(:p_assettype)
                                                                   ", npgsqlConnection))
                {
                    if (request.AssetType.ToLower() == "all" || request.AssetType.ToLower() == "ecourse" || request.AssetType.ToLower() == "video")
                    {
                        cmd.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(request.AssetType))
                            cmd.Parameters.AddWithValue("p_assettype", DbType.String).Value = request.AssetType.ToLower();
                        else
                            cmd.Parameters.AddWithValue("p_assettype", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtAssetNames);
                        npgsqlConnection.Close();
                        if (request.AssetType.ToLower() == "all")
                            dtAssetNames.Merge(GetAssessmentsandSurveys(request));
                        response.responseJSON = JsonConvert.SerializeObject(dtAssetNames);
                    }
                    else
                    {
                        string companycode = string.Empty;
                        if (request.currentRole == "Geo Admin")
                        {
                            DataTable dtCompanies = new DataTable();
                            dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                            if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                            {
                                foreach (DataRow exclude in dtCompanies.Rows)
                                {
                                    companycode = companycode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                                }
                                companycode = companycode.TrimEnd(',');
                            }
                        }

                        //Assessment and Survey from API
                        if (request.AssetType.ToLower() == "survey")
                        {
                            //To Get Surveys 
                            dtSurveys.Columns.Add("assetcode");
                            dtSurveys.Columns.Add("assetname");
                            TLDEnvelope responseData = new TLDEnvelope();
                            string surveyResponse = _serviceconnect.getSurvey(request.Geo, request.EmpCode, request.currentRole, companycode);
                            responseData = JsonConvert.DeserializeObject<TLDEnvelope>(surveyResponse);
                            if (responseData.Status == true && responseData.TotalRecords > 0 && responseData.Data != null)
                            {
                                foreach (var item in responseData.Data.Data)
                                {
                                    dtSurveys.Rows.Add(item.TemplateId, item.TemplateName);
                                }
                            }
                            response.responseJSON = JsonConvert.SerializeObject(dtSurveys);
                        }
                        //To Get Assessments 
                        if (request.AssetType.ToLower() == "assessment")
                        {
                            dtAssessments.Columns.Add("assetcode");
                            dtAssessments.Columns.Add("assetname");

                            assessmentlistresponseData assesslistResponse = new assessmentlistresponseData();
                            string assessmentResponse = _serviceconnect.getAssessment(request.Geo, request.EmpCode, request.currentRole, companycode);
                            assesslistResponse = JsonConvert.DeserializeObject<assessmentlistresponseData>(assessmentResponse);
                            if (assesslistResponse.Data.Data != null && assesslistResponse.Data.Data.Count > 0 && assesslistResponse.ResponseCode == "1")
                            {
                                foreach (var item in assesslistResponse.Data.Data)
                                {
                                    dtAssessments.Rows.Add(item.AssessmentID, item.AssessmentName);
                                }
                            }
                            response.responseJSON = JsonConvert.SerializeObject(dtAssessments);
                        }
                    }
                    //End
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public DataTable GetAssessmentsandSurveys(AssetTypeRequest request)
        {
            DataTable dtAssessments = new DataTable();
            dtAssessments.Columns.Add("assetcode");
            dtAssessments.Columns.Add("assetname");

            //TLDEnvelope responseData = new TLDEnvelope();
            //string surveyResponse = _serviceconnect.getSurvey(request.Geo, request.EmpCode, request.currentRole, request.UserCompany);
            //responseData = JsonConvert.DeserializeObject<TLDEnvelope>(surveyResponse);
            //if (responseData.Status == true && responseData.TotalRecords > 0 && responseData.Data != null)
            //{
            //    foreach (var item in responseData.Data.Data)
            //    {
            //        dtAssessments.Rows.Add(item.TemplateId, item.TemplateName);
            //    }
            //}

            assessmentlistresponseData assesslistResponse = new assessmentlistresponseData();
            string assessmentResponse = _serviceconnect.getAssessment(request.Geo, request.EmpCode, request.currentRole, request.UserCompany);
            assesslistResponse = JsonConvert.DeserializeObject<assessmentlistresponseData>(assessmentResponse);
            if (assesslistResponse.Data.Data != null && assesslistResponse.Data.Data.Count > 0 && assesslistResponse.ResponseCode == "1")
            {
                foreach (var item in assesslistResponse.Data.Data)
                {
                    dtAssessments.Rows.Add(item.AssessmentID, item.AssessmentName);
                }
            }
            return dtAssessments;
        }
        public ResponseClass GetODPMAdminLookUpData(string lookupType)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtODPMAdminLookUpData = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"select * from public.fn_get_odpm_adminlookupdata(:p_lookuptype)", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(lookupType))
                            cmd.Parameters.AddWithValue("p_lookuptype", DbType.String).Value = lookupType.ToLower();
                        else
                            cmd.Parameters.AddWithValue("p_lookuptype", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtODPMAdminLookUpData);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtODPMAdminLookUpData);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetCategory", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
    }
}
