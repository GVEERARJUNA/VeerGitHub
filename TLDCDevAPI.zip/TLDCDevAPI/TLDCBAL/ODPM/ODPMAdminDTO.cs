﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ODPM
{
    public class ODPMAdminDTO
    {
    }
    //Save Training
    public class addTrainingRequestDTO
    {
        public string TorPid { get; set; }
        public string TorPCode { get; set; }
        public string Action { get; set; }
        public string Type { get; set; }
        public string TrainingName { get; set; }
        public string Category { get; set; }
        public string Geo { get; set; }
        public string TargetAudience { get; set; }
        //public string Gender { get; set; }
        public string ParticipantPerSession { get; set; }
        public string Certification { get; set; }
        //public string Efficacy { get; set; }
        public string Feedback { get; set; }
        //public string ODPMMetricsLinkage { get; set; }
        public string DeliveryMethod { get; set; }
        public string LearningObjectives { get; set; }
        public string Description { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public string TrainingAttachmentPath { get; set; }
        public string TimeZone { get; set; }
        public List<addTrainingAssets> addTrainingAssets { get; set; }
        public List<addTrainingAttachments> addTrainingAttachments { get; set; }
        public addTrainingRequestDTO()
        {
            addTrainingAssets = new List<addTrainingAssets>();
            addTrainingAttachments = new List<addTrainingAttachments>();
        }
    }
    public class addTrainingAssets
    {
        public string AssetID { get; set; }
        public string TrainingID { get; set; }
        public string AssetTyp { get; set; }
        public string AssetCode { get; set; }
        public string AssetName { get; set; }
        public string PreorPost { get; set; }
        public string Mandatory { get; set; }
        public string InterOrExter { get; set; }
    }
    public class addTrainingAttachments
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string TrainingThumbnail { get; set; }
        public string FileType { get; set; }
        public string MediaType { get; set; }
    }
    
    //Save or Eidt Program 
    public class addProgramRequestDTO
    {
        public string Type { get; set; }
        public double ProgId { get; set; }
        public string ProgramName { get; set; }
        public string Prog_Code { get; set; }
        public string Certification { get; set; }
        //public string Efficacy { get; set; }
        public string NoOfProjects { get; set; }
        public string Feedback { get; set; }
        //public string ODPMMetricsLinkage { get; set; }
        public string LearningObjectives { get; set; }
        public string Description { get; set; }
        public string Action { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public string ProgramAttachmentPath { get; set; }
        public string TimeZone { get; set; }
        public List<addProgramTrainings> addProgramTrainings { get; set; }
        public List<addProgramAttachments> addProgramAttachments { get; set; }
        public addProgramRequestDTO()
        {
            addProgramTrainings = new List<addProgramTrainings>();
            addProgramAttachments = new List<addProgramAttachments>();
        }
    }
    public class addProgramTrainings
    {
        public double Id { get; set; }
        public string ProgId { get; set; }
        public string Prog_Code { get; set; }
        public string TrainingId { get; set; }
        public string TrainingName { get; set; }
        public string Category { get; set; }
        public string Geo { get; set; }
        public string TargetAudience { get; set; }
        public string Gender { get; set; }
        public string ParticipantPerSession { get; set; }
    }
    public class addProgramAttachments
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string ProgramThumbnail { get; set; }
        public string FileType { get; set; }
        public string MediaType { get; set; }
    }

    public class TrainingProgramDTO
    {
        public string Type { get; set; }
        public string Geo { get; set; }
        public string TorPName { get; set; }
    }

    //Edit Training
    public class EditTrainingRequest
    {
        public string Type { get; set; }
        public string TorPid { get; set; }
        public string TorPCode { get; set; }

        public string TrainingName { get; set; }
        public string Category { get; set; }
        public string Geo { get; set; }
        public string TargetAudience { get; set; }
        public string Gender { get; set; }
        public string ParticipantPerSession { get; set; }
        public string Certification { get; set; }
        public string Efficacy { get; set; }
        public string Feedback { get; set; }
        public string ODPMMetricsLinkage { get; set; }
        public string DeliveryMethod { get; set; }
        public string LearningObjectives { get; set; }
        public string Description { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public List<addTrainingAssets> AddTrainingAssetsList { get; set; }

    }
    //Edit  Program
    public class EditProgramRequest
    {
        public string Type { get; set; }
        public string TorPid { get; set; }
        public string TorPCode { get; set; }
        public string ProgramName { get; set; }
        public string Certification { get; set; }
        public string Efficacy { get; set; }
        public string NoOfProjects { get; set; }
        public string Feedback { get; set; }
        public string ODPMMetricsLinkage { get; set; }
        public string LearningObjectives { get; set; }
        public string Description { get; set; }
        public string Action { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public List<addProgramTrainings> AddProgramTrainingsList { get; set; }
    }

    public class DeleteRequest
    {
        public string Type { get; set; }
        public string TorPid { get; set; }
        public string TorPCode { get; set; }
        public string ModifiedBy { get; set; }
    }

    public class AssetTypeRequest
    {
        public string AssetType { get; set; }
        public string LookupType { get; set; }
        public string Geo { get; set; }
        public string EmpCode { get; set; }
        public string LoginEMPCode { get; set; }
        public string currentRole { get; set; }
        public string UserCompany { get; set; }

    }
    public class GetProgTrainswithTridResp
    {
        public string Trid { get; set; }
        public string CategoryCode { get; set; }
        public string GeoCode { get; set; }
        public string TargetAudience { get; set; }
        public string GenderCode { get; set; }
        public string ParticipantPerSession { get; set; }
    }
}
