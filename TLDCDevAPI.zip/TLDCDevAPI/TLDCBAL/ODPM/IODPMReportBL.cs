﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;

namespace TLDCBAL.ODPM
{
    public interface IODPMReportBL
    {
        ResponseClass ODPMTrainingDetailedReport(ODPMReportFilterDTO request);
        ResponseClass ODPMReportFilterGeoList(ODPMReportFilterDTO request);
        ResponseClass ODPMReportFilterDepartmentList(ODPMReportFilterDTO request);
        ResponseClass ODPMReportFilterCityList(ODPMReportFilterDTO request);
        ResponseClass ODPMReportFilterProgramManagerList(ODPMReportFilterDTO request);
    }
}
