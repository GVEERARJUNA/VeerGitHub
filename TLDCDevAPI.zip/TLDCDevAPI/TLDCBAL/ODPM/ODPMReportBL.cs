﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.ODPM
{
    public class ODPMReportBL : IODPMReportBL
    {

        private readonly IOptions<IDBConnection> appSettings;
        private readonly IServiceConnect _serviceconnect;
        CommonFunction function = new CommonFunction();
        DBConnection dBConnection;

        public ODPMReportBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass ODPMTrainingDetailedReport(ODPMReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_report_training_detailed_report(
                                                                    :p_currentemployee,
                                                                    :p_currentrole,
                                                                    :p_pageno,
                                                                    :p_recordno
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeCode;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }
            }

            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ODPMTrainingDetailedReport", "67", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }
        

            return response;
        }

        public ResponseClass ODPMReportFilterGeoList(ODPMReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_report_training_detailed_report(
                                                                    :p_currentemployee,
                                                                    :p_currentrole
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeCode;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRoleName;
                        
                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }
            }

            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ODPMReportFilterGeoList", "67", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }
        

            return response;
        }
        public ResponseClass ODPMReportFilterDepartmentList(ODPMReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_report_training_detailed_report(
                                                                    :p_currentemployee,
                                                                    :p_currentrole
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeCode;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRoleName;
                        
                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }
            }

            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ODPMReportFilterDepartmentList", "67", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }
        

            return response;
        }
        public ResponseClass ODPMReportFilterCityList(ODPMReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_report_training_detailed_report(
                                                                    :p_currentemployee,
                                                                    :p_currentrole
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeCode;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRoleName;
                        
                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }
            }

            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ODPMReportFilterCityList", "67", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }
        

            return response;
        }
    
        public ResponseClass ODPMReportFilterProgramManagerList(ODPMReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_report_training_detailed_report(
                                                                    :p_currentemployee,
                                                                    :p_currentrole
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeCode;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRoleName;
                        
                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }
            }

            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ODPMReportFilterProgramManagerList", "67", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }
        

            return response;
        }
    }
}
