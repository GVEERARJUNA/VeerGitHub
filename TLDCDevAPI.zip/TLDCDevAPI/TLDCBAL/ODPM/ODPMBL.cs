﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.CourseAdmin;
using TLDCBAL.ProgramManager;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.ODPM
{
    public class ODPMBL : IODPMBL
    {
        private readonly IOptions<IDBConnection> appSettings;
        private readonly IServiceConnect _serviceconnect;
        CommonFunction function = new CommonFunction();
        DBConnection dBConnection;

        public ODPMBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect)
        {
            appSettings = app;
            _serviceconnect = serviceconnect;
            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }
        public string RemoveQuotes(string str)
        {
            string result = string.Empty;
            if (str != null && str != "")
            {
                result = str.Replace("'", "''");
            }
            return result;
        }
        public ResponseClass GetGeo()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_geo()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    //if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                    //    cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = oDPMinput.loggedinempcode;
                    //else
                    //    cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }

        public ResponseClass GetODPMshareGeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_sharegeo(:p_loggedinempcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }



        public ResponseClass GetODPMsuggestGeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_suggestgeo(:p_loggedinempcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }

        

       public ResponseClass GetODPMschGeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_schgeo(:p_loggedinempcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }

        public ResponseClass GetProgramManager(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;


            List<string> p_companycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.companycode))
            {
                p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.companycode = "";
                oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }

            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_programmanager (:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetQtr()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_qtr ()
                                                              ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetODPMQtryear()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_qtryear ()
                                                              ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetStakeholder()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_stakeholder()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetStatus()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_Status
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                                                        //if (!String.IsNullOrEmpty(request.StateName))
                                                        //    cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = request.StateName;
                                                        //else
                                                        //    cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetShareTNIList(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();


            List<string> p_companycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.companycode))
            {
                p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.companycode = "";
                oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_qtr = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.qtr))
            {
                p_qtr = oDPMinput.qtr.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.qtr = "";
                oDPMinput.qtr.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_programmanager = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.programmanager))
            {
                p_programmanager = oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.programmanager = "";
                oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }

            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_sharetnilist (:p_companycode,:p_qtr,:p_programmanager,:p_status,:p_employeecode,:p_role)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;

                    if (!String.IsNullOrEmpty(oDPMinput.qtr))
                        cmd.Parameters.AddWithValue("p_qtr", DbType.Object).Value = p_qtr;
                    else
                        cmd.Parameters.AddWithValue("p_qtr", DbType.Object).Value = p_qtr;

                    if (!String.IsNullOrEmpty(oDPMinput.programmanager))
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.Object).Value = p_programmanager;
                    else
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.Object).Value = p_programmanager;

                    if (!String.IsNullOrEmpty(oDPMinput.status))
                        cmd.Parameters.AddWithValue("p_status", DbType.String).Value = oDPMinput.status;
                    else
                        cmd.Parameters.AddWithValue("p_status", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.rolename))
                        cmd.Parameters.AddWithValue("p_role", DbType.String).Value = oDPMinput.rolename;
                    else
                        cmd.Parameters.AddWithValue("p_role", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    dtEmployees.Columns.Add("encryptedtninumber");
                    if (dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            item["encryptedtninumber"] = function.Encrypt(Convert.ToString(item["tninumber"]));
                        }
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetCity(string companycode)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_City(:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetDepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_department(:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetODPMshareDepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_sharedepartment(:p_companycode,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetODPMsuggestDepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_suggestdepartment(:p_companycode,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }



        public ResponseClass GetODPMschDepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();

            //List<string> p_companycode = new List<string>();
            //if (!String.IsNullOrEmpty(oDPMinput.companycode))
            //{
            //    p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}
            //else
            //{
            //    oDPMinput.companycode = "";
            //    oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}

            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_schdepartment(:p_companycode,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetGrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_Grade(:p_employeecode,:p_departmentcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.String).Value = oDPMinput.departmentcode;
                    else
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetODPMShareGrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            List<string> p_departmentcode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
            {
                p_departmentcode = oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.departmentcode = "";
                oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_sharegrade(:p_employeecode,:p_departmentcode,:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.String).Value = p_departmentcode;
                    else
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.String).Value = p_departmentcode;


                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetODPMsuggestGrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();


           


            List<string> p_departmentcode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
            {
                p_departmentcode = oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.departmentcode = "";
                oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }


            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {

                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_suggestgrade(:p_employeecode,:p_departmentcode,:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.String).Value = p_departmentcode;
                    else
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.String).Value = p_departmentcode;


                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        
    public ResponseClass GetODPMschGrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();





            List<string> p_departmentcode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
            {
                p_departmentcode = oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.departmentcode = "";
                oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }

            //List<string> p_companycode = new List<string>();
            //if (!String.IsNullOrEmpty(oDPMinput.companycode))
            //{
            //    p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}
            //else
            //{
            //    oDPMinput.companycode = "";
            //    oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}

            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {

                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_schgrade(:p_employeecode,:p_departmentcode,:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.String).Value = p_departmentcode;
                    else
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.String).Value = p_departmentcode;


                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value; 



                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetNominateTeamMembers(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;



            List<string> p_departmentcode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
            {
                p_departmentcode = oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.departmentcode = "";
                oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_grade = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.grade))
            {
                p_grade = oDPMinput.grade.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.grade = "";
                oDPMinput.grade.Replace(" ", "").Split(",").ToList();
            }


            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_nominateteammembers(:p_employeecode,:p_departmentcode,:p_gradecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.Object).Value = p_departmentcode;
                    else
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.Object).Value = p_departmentcode;

                    if (!String.IsNullOrEmpty(oDPMinput.grade))
                        cmd.Parameters.AddWithValue("p_gradecode", DbType.Object).Value = p_grade;
                    else
                        cmd.Parameters.AddWithValue("p_gradecode", DbType.Object).Value = p_grade;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetODPMShareNominateTeamMembers(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;



            List<string> p_departmentcode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
            {
                p_departmentcode = oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.departmentcode = "";
                oDPMinput.departmentcode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_grade = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.grade))
            {
                p_grade = oDPMinput.grade.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.grade = "";
                oDPMinput.grade.Replace(" ", "").Split(",").ToList();
            }


            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_sharenominateteammembers(:p_employeecode,:p_departmentcode,:p_gradecode,:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.departmentcode))
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.Object).Value = p_departmentcode;
                    else
                        cmd.Parameters.AddWithValue("p_departmentcode", DbType.Object).Value = p_departmentcode;

                    if (!String.IsNullOrEmpty(oDPMinput.grade))
                        cmd.Parameters.AddWithValue("p_gradecode", DbType.Object).Value = p_grade;
                    else
                        cmd.Parameters.AddWithValue("p_gradecode", DbType.Object).Value = p_grade;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = DBNull.Value; ;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetTrainingName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_trainingname(:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetProgramName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_programname(:p_geo_code,:p_training_id)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_geo_code", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_geo_code", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.trainingcode))
                        cmd.Parameters.AddWithValue("p_training_id", DbType.String).Value = oDPMinput.trainingcode;
                    else
                        cmd.Parameters.AddWithValue("p_training_id", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetEfficacy()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_efficacy
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass ODPMInsertShareTNI(List<ShareTNIDetails> shareTNIDetails)
        {
            ResponseClass response = new ResponseClass();


            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                string tninumber = "";
                string tninumberup = "1";
                foreach (var a in shareTNIDetails)
                {
                    if (a.actiontype == "insert")
                    {

                        string dep = "";
                        string grd = "";
                        string NT = "";
                        string QtrC = "";

                        foreach (var b in a.department)
                        {
                            dep = dep + ',' + b;
                        }
                        foreach (var c in a.grade)
                        {
                            grd = grd + ',' + c;
                        }
                        foreach (var d in a.NominateTeamMembers)
                        {
                            NT = NT + ',' + d;
                        }
                        foreach (var d in a.qtr)
                        {
                            QtrC = QtrC + ',' + d;
                        }

                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_shareTNI
                                                                        ( 
                                                                        :pGeo,
                                                                        :pQTR,
                                                                        :pQTRYear,
                                                                        :pCity,
                                                                        :pProgramManager,
                                                                        :pDepartment,
                                                                        :pGrade,
                                                                        :pNominateTeamMember,
                                                                        :pTrainingName,
                                                                        :pProgramName,
                                                                        
                                                                        :pReasonForTraining,
                                                                        :pstakeholderid,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :ptninumber
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;
                                if (!String.IsNullOrEmpty(a.companycode))
                                    cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = a.companycode;
                                else
                                    cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(QtrC))
                                    cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = QtrC.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.qtryear))
                                    cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = a.qtryear;
                                else
                                    cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.city))
                                    cmd.Parameters.AddWithValue("pCity", DbType.String).Value = a.city;
                                else
                                    cmd.Parameters.AddWithValue("pCity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.programmanager))
                                    cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = a.programmanager;
                                else
                                    cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(dep))
                                    cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = dep.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(grd))
                                    cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = grd.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(NT))
                                    cmd.Parameters.AddWithValue("pNominateTeamMember", DbType.String).Value = NT.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pNominateTeamMember", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.trainingname))
                                    cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = a.trainingname;
                                else
                                    cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.programname))
                                    cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = a.programname;
                                else
                                    cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = string.Empty;
                                //:pEfficacy,
                              //  if (!String.IsNullOrEmpty(a.efficacy))
                                 //   cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = a.efficacy;
                               // else
                                //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.reason))
                                    cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = a.reason;
                                else
                                    cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.stakeholder))
                                    cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = a.stakeholder;
                                else
                                    cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinid))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinid;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = "1";
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(tninumber))
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = tninumber;
                                else
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = string.Empty;

                                npgsqlConnection.Open();

                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                               // tninumber = dtEmployees.Rows[0]["tninumber"].ToString();

                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }
                    }



                    if (a.actiontype == "update")
                    {

                        string dep = "";
                        string grd = "";
                        string NT = "";
                        string QtrC = "";
                        

                        foreach (var b in a.department)
                        {
                            dep = dep + ',' + b;
                        }
                        foreach (var c in a.grade)
                        {
                            grd = grd + ',' + c;
                        }
                        foreach (var d in a.NominateTeamMembers)
                        {
                            NT = NT + ',' + d;
                        }
                        foreach (var d in a.qtr)
                        {
                            QtrC = QtrC + ',' + d;
                        }

                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_Update_shareTNI
                                                                        ( 
                                                                        :pGeo,
                                                                        :pQTR,
                                                                        :pQTRYear,
                                                                        :pCity,
                                                                        :pProgramManager,
                                                                        :pDepartment,
                                                                        :pGrade,
                                                                        :pNominateTeamMember,
                                                                        :pTrainingName,
                                                                        :pProgramName,
                                                                      
                                                                        :pReasonForTraining,
                                                                        :pstakeholderid,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :ptninumber
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;
                                if (!String.IsNullOrEmpty(a.companycode))
                                    cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = a.companycode;
                                else
                                    cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(QtrC))
                                    cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = QtrC.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.qtryear))
                                    cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = a.qtryear;
                                else
                                    cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.city))
                                    cmd.Parameters.AddWithValue("pCity", DbType.String).Value = a.city;
                                else
                                    cmd.Parameters.AddWithValue("pCity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.programmanager))
                                    cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = a.programmanager;
                                else
                                    cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(dep))
                                    cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = dep.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(grd))
                                    cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = grd.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(NT))
                                    cmd.Parameters.AddWithValue("pNominateTeamMember", DbType.String).Value = NT.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pNominateTeamMember", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.trainingname))
                                    cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = a.trainingname;
                                else
                                    cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.programname))
                                    cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = a.programname;
                                else
                                    cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = string.Empty;

                                // :pEfficacy,
                                //if (!String.IsNullOrEmpty(a.efficacy))
                                //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = a.efficacy;
                                //else
                                //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.reason))
                                    cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = a.reason;
                                else
                                    cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.stakeholder))
                                    cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = a.stakeholder;
                                else
                                    cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinid))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinid;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = "1";
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(tninumberup))
                                {
                                    if (!String.IsNullOrEmpty(a.tninumber))
                                        cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = a.tninumber.Replace("#", "");
                                    else
                                        cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = string.Empty;
                                }
                                if (String.IsNullOrEmpty(tninumberup))
                                {
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = string.Empty;
                                }
                                    npgsqlConnection.Open();

                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                                tninumberup = "";
                                //tninumber = dtEmployees.Rows[0]["tninumber"].ToString();

                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }
                    }




                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }
            catch (Exception ex)
            {


                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }


        public ResponseClass getedit_TNI_Master(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getedit_TNI_Master(:p_tninumber)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass getedit_TNI_QtrMapping(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getedit_tni_QtrMapping(:p_tninumber)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;




                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass getedit_TNI_DepartmentMapping(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getedit_tni_DepartmentMapping(:p_tninumber,:p_rowid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.rowid))
                        cmd.Parameters.AddWithValue("p_rowid", DbType.String).Value = oDPMinput.rowid;
                    else
                        cmd.Parameters.AddWithValue("p_rowid", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass getedit_TNI_Grade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getedit_tni_GradeMapping(:p_tninumber,:p_rowid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.rowid))
                        cmd.Parameters.AddWithValue("p_rowid", DbType.String).Value = oDPMinput.rowid;
                    else
                        cmd.Parameters.AddWithValue("p_rowid", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass getedit_TNI_MemberNomination(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getedit_tni_MemberNomination(:p_tninumber,:p_rowid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.rowid))
                        cmd.Parameters.AddWithValue("p_rowid", DbType.String).Value = oDPMinput.rowid;
                    else
                        cmd.Parameters.AddWithValue("p_rowid", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass getedit_TNI_TrainingName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getedit_tni_TrainingName(:p_tninumber,:p_rowid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.rowid))
                        cmd.Parameters.AddWithValue("p_rowid", DbType.String).Value = oDPMinput.rowid;
                    else
                        cmd.Parameters.AddWithValue("p_rowid", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass get_EmployeeAutocompleteName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getemployeeautocompletename(:p_searchvalue)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.searchvalue))
                        cmd.Parameters.AddWithValue("p_searchvalue", DbType.String).Value = oDPMinput.searchvalue;
                    else
                        cmd.Parameters.AddWithValue("p_searchvalue", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }




        public ResponseClass ODPMInsertSuggestTNI(List<ShareTNIDetails> shareTNIDetails)
        {
            ResponseClass response = new ResponseClass();


            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                string tninumber = "";
                string tninumberup = "1";
                foreach (var a in shareTNIDetails)
                {
                    if (a.actiontype == "insert")
                    {

                        string dep = "";
                        string grd = "";

                        string QtrC = "";

                        foreach (var b in a.department)
                        {
                            dep = dep + ',' + b;
                        }
                        foreach (var c in a.grade)
                        {
                            grd = grd + ',' + c;
                        }

                        foreach (var d in a.qtr)
                        {
                            QtrC = QtrC + ',' + d;
                        }

                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_suggesttni
                                                                        ( 
                                                                        :pGeo,
                                                                        :pQTR,
                                                                        :pQTRYear,
                                                                        :pCity,
                                                                        :pProgramManager,
                                                                        :pDepartment,
                                                                        :pGrade,
                                                                        :pTrainingName,
                                                                        :pProgramName,
                                                                      
                                                                        :pReasonForTraining,
                                                                        :pstakeholderid,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :ptninumber
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;
                                if (!String.IsNullOrEmpty(a.companycode))
                                    cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = a.companycode;
                                else
                                    cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(QtrC))
                                    cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = QtrC.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.qtryear))
                                    cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = a.qtryear;
                                else
                                    cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.city))
                                    cmd.Parameters.AddWithValue("pCity", DbType.String).Value = a.city;
                                else
                                    cmd.Parameters.AddWithValue("pCity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.programmanager))
                                    cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = a.programmanager;
                                else
                                    cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(dep))
                                    cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = dep.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(grd))
                                    cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = grd.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.trainingname))
                                    cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = a.trainingname;
                                else
                                    cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.programname))
                                    cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = a.programname;
                                else
                                    cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = string.Empty;

                                //if (!String.IsNullOrEmpty(a.efficacy))
                                //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = a.efficacy;
                                //else
                                //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.reason))
                                    cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = a.reason;
                                else
                                    cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.stakeholder))
                                    cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = a.stakeholder;
                                else
                                    cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinid))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinid;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = "1";
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(tninumber))
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = tninumber;
                                else
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = string.Empty;

                                npgsqlConnection.Open();

                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                                //tninumber = dtEmployees.Rows[0]["tninumber"].ToString();

                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }
                    }



                    if (a.actiontype == "update")
                    {
                        if (a.rowId == "1")
                        {
                            string dep = "";
                            string grd = "";
                            string NT = "";
                            string QtrC = "";

                            foreach (var b in a.department)
                            {
                                dep = dep + ',' + b;
                            }
                            foreach (var c in a.grade)
                            {
                                grd = grd + ',' + c;
                            }

                            foreach (var d in a.qtr)
                            {
                                QtrC = QtrC + ',' + d;
                            }

                            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                            {
                                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_Update_SuggestTNI
                                                                        ( 
                                                                        :pGeo,
                                                                        :pQTR,
                                                                        :pQTRYear,
                                                                        :pCity,
                                                                        :pProgramManager,
                                                                        :pDepartment,
                                                                        :pGrade,
                                                                        :pTrainingName,
                                                                        :pProgramName,
                                                                        
                                                                        :pReasonForTraining,
                                                                        :pstakeholderid,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :ptninumber
                                                                        )", npgsqlConnection))
                                {
                                    cmd.CommandType = CommandType.Text;
                                    if (!String.IsNullOrEmpty(a.companycode))
                                        cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = a.companycode;
                                    else
                                        cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(QtrC))
                                        cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = QtrC.Remove(0, 1);
                                    else
                                        cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = string.Empty;
                                    if (!String.IsNullOrEmpty(a.qtryear))
                                        cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = a.qtryear;
                                    else
                                        cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.city))
                                        cmd.Parameters.AddWithValue("pCity", DbType.String).Value = a.city;
                                    else
                                        cmd.Parameters.AddWithValue("pCity", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.programmanager))
                                        cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = a.programmanager;
                                    else
                                        cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = string.Empty;


                                    if (!String.IsNullOrEmpty(dep))
                                        cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = dep.Remove(0, 1);
                                    else
                                        cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(grd))
                                        cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = grd.Remove(0, 1);
                                    else
                                        cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.trainingname))
                                        cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = a.trainingname;
                                    else
                                        cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.programname))
                                        cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = a.programname;
                                    else
                                        cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = string.Empty;

                                    //if (!String.IsNullOrEmpty(a.efficacy))
                                    //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = a.efficacy;
                                    //else
                                    //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.reason))
                                        cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = a.reason;
                                    else
                                        cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = string.Empty;


                                    if (!String.IsNullOrEmpty(a.stakeholder))
                                        cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = a.stakeholder;
                                    else
                                        cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.loggedinid))
                                        cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinid;
                                    else
                                        cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.appstatus))
                                        cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                    else
                                        cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.rowId))
                                        cmd.Parameters.AddWithValue("prowid", DbType.String).Value = "1";
                                    else
                                        cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;
                                    //if (!String.IsNullOrEmpty(a.tninumber))
                                    //    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = a.tninumber.Replace("#", "");
                                    //else
                                    //    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(tninumberup))
                                    {
                                        if (!String.IsNullOrEmpty(a.tninumber))
                                            cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = a.tninumber.Replace("#", "");
                                        else
                                            cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = string.Empty;
                                    }
                                    if (String.IsNullOrEmpty(tninumberup))
                                    {
                                        cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = tninumberup;
                                    }
                                    npgsqlConnection.Open();

                                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                    dataAdapter.Fill(dtEmployees);
                                    //tninumber = dtEmployees.Rows[0]["tninumber"].ToString();
                                    tninumberup = "";
                                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                                }
                            }
                        }
                        if (a.rowId != "1" && !String.IsNullOrEmpty(a.rowId))
                        {
                            string dep = "";
                            string grd = "";

                            string QtrC = "";

                            foreach (var b in a.department)
                            {
                                dep = dep + ',' + b;
                            }
                            foreach (var c in a.grade)
                            {
                                grd = grd + ',' + c;
                            }

                            foreach (var d in a.qtr)
                            {
                                QtrC = QtrC + ',' + d;
                            }

                            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                            {
                                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_suggesttni
                                                                        ( 
                                                                        :pGeo,
                                                                        :pQTR,
                                                                        :pQTRYear,
                                                                        :pCity,
                                                                        :pProgramManager,
                                                                        :pDepartment,
                                                                        :pGrade,
                                                                        :pTrainingName,
                                                                        :pProgramName,
                                                                      
                                                                        :pReasonForTraining,
                                                                        :pstakeholderid,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :ptninumber
                                                                        )", npgsqlConnection))
                                {
                                    cmd.CommandType = CommandType.Text;
                                    if (!String.IsNullOrEmpty(a.companycode))
                                        cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = a.companycode;
                                    else
                                        cmd.Parameters.AddWithValue("pGeo", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(QtrC))
                                        cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = QtrC.Remove(0, 1);
                                    else
                                        cmd.Parameters.AddWithValue("pQTR", DbType.String).Value = string.Empty;
                                    if (!String.IsNullOrEmpty(a.qtryear))
                                        cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = a.qtryear;
                                    else
                                        cmd.Parameters.AddWithValue("pQTRYear", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.city))
                                        cmd.Parameters.AddWithValue("pCity", DbType.String).Value = a.city;
                                    else
                                        cmd.Parameters.AddWithValue("pCity", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.programmanager))
                                        cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = a.programmanager;
                                    else
                                        cmd.Parameters.AddWithValue("pProgramManager", DbType.String).Value = string.Empty;


                                    if (!String.IsNullOrEmpty(dep))
                                        cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = dep.Remove(0, 1);
                                    else
                                        cmd.Parameters.AddWithValue("pDepartment", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(grd))
                                        cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = grd.Remove(0, 1);
                                    else
                                        cmd.Parameters.AddWithValue("pGrade", DbType.String).Value = string.Empty;


                                    if (!String.IsNullOrEmpty(a.trainingname))
                                        cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = a.trainingname;
                                    else
                                        cmd.Parameters.AddWithValue("pTrainingName", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.programname))
                                        cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = a.programname;
                                    else
                                        cmd.Parameters.AddWithValue("pProgramName", DbType.String).Value = string.Empty;

                                    //if (!String.IsNullOrEmpty(a.efficacy))
                                    //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = a.efficacy;
                                    //else
                                    //    cmd.Parameters.AddWithValue("pEfficacy", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.reason))
                                        cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = a.reason;
                                    else
                                        cmd.Parameters.AddWithValue("pReasonForTraining", DbType.String).Value = string.Empty;


                                    if (!String.IsNullOrEmpty(a.stakeholder))
                                        cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = a.stakeholder;
                                    else
                                        cmd.Parameters.AddWithValue("pstakeholderid", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.loggedinid))
                                        cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinid;
                                    else
                                        cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.appstatus))
                                        cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                    else
                                        cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                    if (!String.IsNullOrEmpty(a.rowId))
                                        cmd.Parameters.AddWithValue("prowid", DbType.String).Value = "1";
                                    else
                                        cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;
                                    if (!String.IsNullOrEmpty(tninumber))
                                        cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = tninumber;
                                    else
                                        cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = string.Empty;

                                    npgsqlConnection.Open();

                                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                    dataAdapter.Fill(dtEmployees);
                                    //tninumber = dtEmployees.Rows[0]["tninumber"].ToString();

                                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                                }
                            }
                        }


                    }




                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }
            catch (Exception ex)
            {


                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetODPMSuggestTNIList(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();


            List<string> p_companycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.companycode))
            {
                p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.companycode = "";
                oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_qtr = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.qtr))
            {
                p_qtr = oDPMinput.qtr.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.qtr = "";
                oDPMinput.qtr.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_stackholder = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.stackholder))
            {
                p_stackholder = oDPMinput.stackholder.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.stackholder = "";
                oDPMinput.stackholder.Replace(" ", "").Split(",").ToList();
            }

            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_suggesttnilist (:p_companycode,:p_qtr,:p_stackholder,:p_status,:p_employeecode,:p_role)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;

                    if (!String.IsNullOrEmpty(oDPMinput.qtr))
                        cmd.Parameters.AddWithValue("p_qtr", DbType.Object).Value = p_qtr;
                    else
                        cmd.Parameters.AddWithValue("p_qtr", DbType.Object).Value = p_qtr;

                    if (!String.IsNullOrEmpty(oDPMinput.stackholder))
                        cmd.Parameters.AddWithValue("p_stackholder", DbType.Object).Value = p_stackholder;
                    else
                        cmd.Parameters.AddWithValue("p_stackholder", DbType.Object).Value = p_stackholder;

                    if (!String.IsNullOrEmpty(oDPMinput.status))
                        cmd.Parameters.AddWithValue("p_status", DbType.String).Value = oDPMinput.status;
                    else
                        cmd.Parameters.AddWithValue("p_status", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.rolename))
                        cmd.Parameters.AddWithValue("p_role", DbType.String).Value = oDPMinput.rolename;
                    else
                        cmd.Parameters.AddWithValue("p_role", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    dtEmployees.Columns.Add("encryptedtninumber");
                    if (dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            item["encryptedtninumber"] = function.Encrypt(Convert.ToString(item["tninumber"]));
                        }
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass getedit_SuggestTNI_Master(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getedit_SuggestTNI_Master(:p_tninumber)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }



        public ResponseClass ApproveShareTNI(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_approvesharetni(:p_tninumber,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass RejectShareTNI(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_rejectsharetni(:p_tninumber,:p_employeecode,:p_rejectreason)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.rejectreason))
                        cmd.Parameters.AddWithValue("p_rejectreason", DbType.String).Value = oDPMinput.rejectreason;
                    else
                        cmd.Parameters.AddWithValue("p_rejectreason", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetODPMPMschtraifrmtnilist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();


            List<string> p_companycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.companycode))
            {
                p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.companycode = "";
                oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_qtr = new List<string>();

            if (!String.IsNullOrEmpty(oDPMinput.qtr))
            {
                p_qtr = oDPMinput.qtr.Replace(" ", "").Split(",").ToList();

            }
            else
            {
                oDPMinput.qtr = "";
                oDPMinput.qtr.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_year = new List<string>();

            if (!String.IsNullOrEmpty(oDPMinput.year))
            {
                p_year = oDPMinput.year.Replace(" ", "").Split(",").ToList();

            }
            else
            {
                oDPMinput.year = "";
                oDPMinput.year.Replace(" ", "").Split(",").ToList();
            }


            List<string> p_stackholder = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.stackholder))
            {
                p_stackholder = oDPMinput.stackholder.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.stackholder = "";
                oDPMinput.stackholder.Replace(" ", "").Split(",").ToList();
            }


            List<string> p_programmanager = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.programmanager))
            {
                p_programmanager = oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.programmanager = "";
                oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }

            //List<string> p_workshop = new List<string>();
            //if (!String.IsNullOrEmpty(oDPMinput.workshop))
            //{
            //    p_workshop = oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            //}
            //else
            //{
            //    oDPMinput.workshop = "";
            //    oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            //}

            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getscheduletrainingtnilist (:p_trainingname,:p_qtr,:p_year,:p_companycode,:p_stackholder,:p_programmanager,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    //:p_workshop,
                    //if (!String.IsNullOrEmpty(oDPMinput.workshop))
                    //    cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;
                    //else
                    //    cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;

                    if (!String.IsNullOrEmpty(oDPMinput.trainingname))
                        cmd.Parameters.AddWithValue("p_trainingname", DbType.String).Value = oDPMinput.trainingname;
                    else
                        cmd.Parameters.AddWithValue("p_trainingname", DbType.String).Value = "NA";

                    if (!String.IsNullOrEmpty(oDPMinput.qtr))
                        cmd.Parameters.AddWithValue("p_qtr", DbType.Object).Value = p_qtr;
                    else
                        cmd.Parameters.AddWithValue("p_qtr", DbType.Object).Value = p_qtr;
                    if (!String.IsNullOrEmpty(oDPMinput.year))
                        cmd.Parameters.AddWithValue("p_year", DbType.Object).Value = p_year;
                    else
                        cmd.Parameters.AddWithValue("p_year", DbType.Object).Value = p_year;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.stackholder))
                        cmd.Parameters.AddWithValue("p_stackholder", DbType.Object).Value = p_stackholder;
                    else
                        cmd.Parameters.AddWithValue("p_stackholder", DbType.Object).Value = p_stackholder;

                    if (!String.IsNullOrEmpty(oDPMinput.programmanager))
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.Object).Value = p_programmanager;
                    else
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.Object).Value = p_programmanager;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    DataTable dt = new DataTable();
                    dataAdapter.Fill(dt);
                    if (!String.IsNullOrEmpty(oDPMinput.trainingname))
                    {
                        dtEmployees = dt.Select("trainingname LIKE  '%" + oDPMinput.trainingname + "%'  ").CopyToDataTable();
                    }
                    else
                    {
                        dtEmployees= dt;
                    }
                    npgsqlConnection.Close();
                    dtEmployees.Columns.Add("encryptedtninumber");
                    CommonFunction function = new CommonFunction();

                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            item["encryptedtninumber"] = function.Encrypt(Convert.ToString(item["tninumber"]));
                        }
                    }

                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass ODPMPMSavetrainschedfromtni(List<schFROMTNI> shareTNIDetails)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                string wrkshopid = "";

                foreach (var a in shareTNIDetails)
                {
                    if (a.actiontype == "insert")
                    {
                        //string schgeo = "";
                        //string schdep = "";
                        //string schcity = "";
                        //string schgrade = "";
                        string allByUser = "";
                        string schasslst = "";


                        //foreach (var g in a.schgeo)
                        //{
                        //    schgeo = schgeo + ',' + g;
                        //}
                        //foreach (var d in a.schdep)
                        //{
                        //    schdep = schdep + ',' + d;
                        //}
                        //foreach (var c in a.schcity)
                        //{
                        //    schcity = schcity + ',' + c;
                        //}
                        //foreach (var l in a.schloc)
                        //{
                        //    schloc = schloc + ',' + l;
                        //}
                        //foreach (var g in a.schgrade)
                        //{
                        //    schgrade = schgrade + ',' + g;
                        //}
                        foreach (var ass in a.schasslst)
                        {
                            schasslst = schasslst + ',' + ass;
                        }
                        foreach (var u in a.allByUser)
                        {
                            allByUser = allByUser + ',' + u;
                        }

                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_fromtnischeduletraining
                                                                        ( 
                                                                        :pgeo,
                                                                        :pdep,
                                                                        :pcity,
                                                                        :ploc,
                                                                        :pgrade,
                                                                        :ptrainame,
                                                                        :pproname,
                                                                        :passlst,
                                                                        :pallByUser,
                                                                        :ptradate,
                                                                        :pfrmtime,
                                                                        :ptotime,
                                                                        :pfacilitatortype,
                                                                        :pfacilitator,
                                                                        :pAddTrainingDetail,
                                                                        :pDeliveryMode,
                                                                        :pRemarksforParticipant,
                                                                        :pRemarksforManager,
                                                                        :plink,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :ptninumber,
                                                                        :pwrkshopid,
                                                                        :pworkshoptype,
                                                                        :pstarthr,
                                                                        :pstartmin,
                                                                        :pstartampm,
                                                                        :pendhr,
                                                                        :pendmin,
                                                                        :pendampm,
                                                                        :ptratodate,
                                                                        :ptimezone,
                                                                        :pserverstartdate,
                                                                        :pserverenddate,
                                                                        :pserverstarttime,
                                                                        :pserverendtime
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;

                                if (!String.IsNullOrEmpty(a.schgeo))
                                    cmd.Parameters.AddWithValue("pgeo", DbType.String).Value = a.schgeo;
                                //schgeo.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pgeo", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schdep))
                                    cmd.Parameters.AddWithValue("pdep", DbType.String).Value = a.schdep; //schdep.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pdep", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schcity))
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = a.schcity; //schcity.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schloc))
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = a.schloc;
                                else
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schgrade))
                                    cmd.Parameters.AddWithValue("pgrade", DbType.String).Value = a.schgrade;
                                //schgrade.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pgrade", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schtrainame))
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = a.schtrainame;
                                else
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schproname))
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = a.schproname;
                                else
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schasslst))
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = schasslst.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(allByUser))
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = allByUser.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tradate))
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = a.tradate;
                                else
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmtime))
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = a.frmtime;
                                else
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.totime))
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = a.totime;
                                else
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitatorType))
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = a.facilitatorType;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitator))
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = a.facilitator;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.AddTrainingDetail))
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = a.AddTrainingDetail;
                                else
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.DeliveryMode))
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = a.DeliveryMode;
                                else
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforParticipant))
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = a.RemarksforParticipant;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforManager))
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = a.RemarksforManager;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.link))
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = a.link;
                                else
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinempcode))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinempcode;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = a.rowId;
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tninumber))
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = a.tninumber;
                                else
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = "0";

                                if (!String.IsNullOrEmpty(wrkshopid))
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = wrkshopid;
                                else
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.workshoptype))
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = a.workshoptype;
                                else
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmhr))
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = a.frmhr;
                                else
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmmin))
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = a.frmmin;
                                else
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmampm))
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = a.frmampm;
                                else
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tohr))
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = a.tohr;
                                else
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.tomin))
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = a.tomin;
                                else
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.toampm))
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = a.toampm;
                                else
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tratodate))
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = a.tratodate;
                                else
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.timezone))
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = a.timezone;
                                else
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = string.Empty;

                                //:pserverstartdate,
                                //                                        :pserverenddate
                                if (!String.IsNullOrEmpty(a.serverstartdate))
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = a.serverstartdate;
                                else
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverenddate))
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = a.serverenddate;
                                else
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverstarttime))
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = a.serverstarttime;
                                else
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverendtime))
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = a.serverendtime;
                                else
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = string.Empty;



                                npgsqlConnection.Open();
                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                                wrkshopid = dtEmployees.Rows[0]["wrkshopid"].ToString();
                                
                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }
                    }



                    if (a.actiontype == "update")
                    {
                        //string schgeo = "";
                        //string schdep = "";
                        //string schcity = "";
                        //string schgrade = "";
                        string allByUser = "";
                        string schasslst = "";


                        //foreach (var g in a.schgeo)
                        //{
                        //    schgeo = schgeo + ',' + g;
                        //}
                        //foreach (var d in a.schdep)
                        //{
                        //    schdep = schdep + ',' + d;
                        //}
                        //foreach (var c in a.schcity)
                        //{
                        //    schcity = schcity + ',' + c;
                        //}
                        //foreach (var l in a.schloc)
                        //{
                        //    schloc = schloc + ',' + l;
                        //}
                        //foreach (var g in a.schgrade)
                        //{
                        //    schgrade = schgrade + ',' + g;
                        //}
                        foreach (var ass in a.schasslst)
                        {
                            schasslst = schasslst + ',' + ass;
                        }
                        foreach (var u in a.allByUser)
                        {
                            allByUser = allByUser + ',' + u;
                        }
                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_update_fromtnischeduletraining
                                                                        ( 
                                                                        :pgeo,
                                                                        :pdep,
                                                                        :pcity,
                                                                        :ploc,
                                                                        :pgrade,
                                                                        :ptrainame,
                                                                        :pproname,
                                                                        :passlst,
                                                                        :pallByUser,
                                                                        :ptradate,
                                                                        :pfrmtime,
                                                                        :ptotime,
                                                                        :pfacilitatortype,
                                                                        :pfacilitator,
                                                                        :pAddTrainingDetail,
                                                                        :pDeliveryMode,
                                                                        :pRemarksforParticipant,
                                                                        :pRemarksforManager,
                                                                        :plink,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :ptninumber,
                                                                        :pwrkshopid,
                                                                        :pworkshoptype,
                                                                        :pstarthr,
                                                                        :pstartmin,
                                                                        :pstartampm,
                                                                        :pendhr,
                                                                        :pendmin,
                                                                        :pendampm,
                                                                        :ptratodate,
                                                                        :ptimezone,
                                                                        :pserverstartdate,
                                                                        :pserverenddate,
                                                                        :pserverstarttime,
                                                                        :pserverendtime
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;

                                if (!String.IsNullOrEmpty(a.schgeo))
                                    cmd.Parameters.AddWithValue("pgeo", DbType.String).Value = a.schgeo;
                                //schgeo.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pgeo", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schdep))
                                    cmd.Parameters.AddWithValue("pdep", DbType.String).Value = a.schdep;
                                // schdep.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pdep", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schcity))
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = a.schcity;
                                //schcity.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schloc))
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = a.schloc;
                                else
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schgrade))
                                    cmd.Parameters.AddWithValue("pgrade", DbType.String).Value = a.schgrade;
                                //schgrade.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pgrade", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schtrainame))
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = a.schtrainame;
                                else
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schproname))
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = a.schproname;
                                else
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schasslst))
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = schasslst.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(allByUser))
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = allByUser.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tradate))
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = a.tradate;
                                else
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmtime))
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = a.frmtime;
                                else
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.totime))
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = a.totime;
                                else
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitatorType))
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = a.facilitatorType;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitator))
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = a.facilitator;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.AddTrainingDetail))
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = a.AddTrainingDetail;
                                else
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.DeliveryMode))
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = a.DeliveryMode;
                                else
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforParticipant))
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = a.RemarksforParticipant;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforManager))
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = a.RemarksforManager;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.link))
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = a.link;
                                else
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinempcode))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinempcode;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = a.rowId;
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tninumber))
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = a.tninumber;
                                else
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = "0";

                                if (!String.IsNullOrEmpty(a.workshopid))
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = a.workshopid;
                                else
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = "0";
                                if (!String.IsNullOrEmpty(a.workshoptype))
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = a.workshoptype;
                                else
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmhr))
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = a.frmhr;
                                else
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmmin))
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = a.frmmin;
                                else
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmampm))
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = a.frmampm;
                                else
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tohr))
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = a.tohr;
                                else
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.tomin))
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = a.tomin;
                                else
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.toampm))
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = a.toampm;
                                else
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.tratodate))
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = a.tratodate;
                                else
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.timezone))
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = a.timezone;
                                else
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.serverstartdate))
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = a.serverstartdate;
                                else
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverenddate))
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = a.serverenddate;
                                else
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverstarttime))
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = a.serverstarttime;
                                else
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverendtime))
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = a.serverendtime;
                                else
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = string.Empty;

                                npgsqlConnection.Open();
                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }

                    }




                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }
            catch (Exception ex)
            {


                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }



        public ResponseClass PMSavetrainschedfromdirecttni(List<schDirectFROMTNI> shareTNIDetails)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                string wrkshopid = "";

                foreach (var a in shareTNIDetails)
                {
                    if (a.actiontype == "insert")
                    {
                        string schgeo = "";
                        string schdep = "";
                        string schcity = "";
                        string schgrade = "";
                        string allByUser = "";
                        string schasslst = "";


                        foreach (var g in a.schgeo)
                        {
                            schgeo = schgeo + ',' + g;
                        }
                        foreach (var d in a.schdep)
                        {
                            schdep = schdep + ',' + d;
                        }
                        //foreach (var c in a.schcity)
                        //{
                        //    schcity = schcity + ',' + c;
                        //}
                        //foreach (var l in a.schloc)
                        //{
                        //    schloc = schloc + ',' + l;
                        //}
                        foreach (var g in a.schgrade)
                        {
                            schgrade = schgrade + ',' + g;
                        }
                        foreach (var ass in a.schasslst)
                        {
                            schasslst = schasslst + ',' + ass;
                        }
                        foreach (var u in a.allByUser)
                        {
                            allByUser = allByUser + ',' + u;
                        }

                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_fromdirecttnischeduletraining
                                                                        ( 
                                                                        :pgeo,
                                                                        :pdep,
                                                                        :pcity,
                                                                        :ploc,
                                                                        :pgrade,
                                                                        :ptrainame,
                                                                        :pproname,
                                                                        :passlst,
                                                                        :pallByUser,
                                                                        :ptradate,
                                                                        :pfrmtime,
                                                                        :ptotime,
                                                                        :pfacilitatortype,
                                                                        :pfacilitator,
                                                                        :pAddTrainingDetail,
                                                                        :pDeliveryMode,
                                                                        :pRemarksforParticipant,
                                                                        :pRemarksforManager,
                                                                        :plink,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :ptninumber,
                                                                        :pwrkshopid,
                                                                        :pworkshoptype,
                                                                        :pstarthr,
                                                                        :pstartmin,
                                                                        :pstartampm,
                                                                        :pendhr,
                                                                        :pendmin,
                                                                        :pendampm,
                                                                        :ptratodate,
                                                                        :ptimezone,
                                                                        :pserverstartdate,
                                                                        :pserverenddate,
                                                                        :pserverstarttime,
                                                                        :pserverendtime
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;

                                if (!String.IsNullOrEmpty(schgeo))
                                    cmd.Parameters.AddWithValue("pgeo", DbType.String).Value = schgeo.Remove(0, 1);
                                //schgeo.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pgeo", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schdep))
                                    cmd.Parameters.AddWithValue("pdep", DbType.String).Value = schdep.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pdep", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schcity))
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = a.schcity;
                                else
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schloc))
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = a.schloc;
                                else
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schgrade))
                                    cmd.Parameters.AddWithValue("pgrade", DbType.String).Value = schgrade.Remove(0, 1); 
                                
                                else
                                    cmd.Parameters.AddWithValue("pgrade", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schtrainame))
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = a.schtrainame;
                                else
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schproname))
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = a.schproname;
                                else
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schasslst))
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = schasslst.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(allByUser))
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = allByUser.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tradate))
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = a.tradate;
                                else
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmtime))
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = a.frmtime;
                                else
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.totime))
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = a.totime;
                                else
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitatorType))
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = a.facilitatorType;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitator))
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = a.facilitator;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.AddTrainingDetail))
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = a.AddTrainingDetail;
                                else
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.DeliveryMode))
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = a.DeliveryMode;
                                else
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforParticipant))
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = a.RemarksforParticipant;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforManager))
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = a.RemarksforManager;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.link))
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = a.link;
                                else
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinempcode))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinempcode;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = a.rowId;
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tninumber))
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = a.tninumber;
                                else
                                    cmd.Parameters.AddWithValue("ptninumber", DbType.String).Value = "0";

                                if (!String.IsNullOrEmpty(wrkshopid))
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = wrkshopid;
                                else
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.workshoptype))
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = a.workshoptype;
                                else
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmhr))
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = a.frmhr;
                                else
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmmin))
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = a.frmmin;
                                else
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmampm))
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = a.frmampm;
                                else
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tohr))
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = a.tohr;
                                else
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.tomin))
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = a.tomin;
                                else
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.toampm))
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = a.toampm;
                                else
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.tratodate))
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = a.tratodate;
                                else
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.timezone))
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = a.timezone;
                                else
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = string.Empty;



                                if (!String.IsNullOrEmpty(a.serverstartdate))
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = a.serverstartdate;
                                else
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverenddate))
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = a.serverenddate;
                                else
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverstarttime))
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = a.serverstarttime;
                                else
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverendtime))
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = a.serverendtime;
                                else
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = string.Empty;


                                npgsqlConnection.Open();
                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                                wrkshopid = dtEmployees.Rows[0]["wrkshopid"].ToString();
                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }
                    }



                   



                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }
            catch (Exception ex)
            {


                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetODPMdraftlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();


            List<string> p_companycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.companycode))
            {
                p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.companycode = "";
                oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_programmanager = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.programmanager))
            {
                p_programmanager = oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.programmanager = "";
                oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_workshop = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.workshop))
            {
                p_workshop = oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.workshop = "";
                oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            }
            string sdate = string.Empty;
            if (!string.IsNullOrEmpty(oDPMinput.fromdate))
            {
                DateTime _sdate = DateTime.ParseExact(oDPMinput.fromdate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                sdate = _sdate.ToString("yyyy-MM-dd");
            }
            else
            {
                DateTime _sdate = DateTime.ParseExact("01-Apr-2000", "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                sdate = _sdate.ToString("yyyy-MM-dd");
            }


            string edate = string.Empty;
            if (!string.IsNullOrEmpty(oDPMinput.todate))
            {
                DateTime _edate = DateTime.ParseExact(oDPMinput.todate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                edate = _edate.ToString("yyyy-MM-dd");
            }
            else
            {
                DateTime _edate = DateTime.ParseExact("05-Apr-2999", "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                edate = _edate.ToString("yyyy-MM-dd");
            }



            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getschtrainsavedraftlist (:p_workshop,:p_companycode,:p_programmanager,:p_fromdate,:p_todate,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = p_companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = p_companycode;



                    if (!String.IsNullOrEmpty(oDPMinput.programmanager))
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.String).Value = p_programmanager;
                    else
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.String).Value = p_programmanager;

                    if (!String.IsNullOrEmpty(oDPMinput.fromdate))
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

                    else
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

                    if (!String.IsNullOrEmpty(oDPMinput.todate))
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;
                    else
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();

                    dtEmployees.Columns.Add("encryptedworkshoptype");
                    dtEmployees.Columns.Add("encryptedworkshopid");
                    dtEmployees.Columns.Add("encryptedtninumber");
                    CommonFunction function = new CommonFunction();
               

                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            if (item["workshoptype"].ToString() == "schTrainNPM")
                            {
                                item["encryptedworkshoptype"] = function.Encrypt(Convert.ToString("2"));
                            }
                            if (item["workshoptype"].ToString() == "schTrainoldwrkshp")
                            {
                                item["encryptedworkshoptype"] = function.Encrypt(Convert.ToString("3"));
                            }
                            item["encryptedworkshopid"] = function.Encrypt(Convert.ToString(item["workshopid"]));
                            item["encryptedtninumber"] = function.Encrypt(Convert.ToString(item["tninumber"]));
                        }
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass getedit_savedraft(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_geteditsavedraft(:p_tninumber,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetODPMPMdraftworkshop()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_draftworkshop()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    //if (!String.IsNullOrEmpty(request.StateName))
                    //    cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = request.StateName;
                    //else
                    //    cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }
        public ResponseClass GetODPMPM360tworkshop()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_360workshop()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    //if (!String.IsNullOrEmpty(request.StateName))
                    //    cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = request.StateName;
                    //else
                    //    cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }


        


        public ResponseClass GetODPMschCity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;



            //List<string> p_companycode = new List<string>();
            //if (!String.IsNullOrEmpty(oDPMinput.companycode))
            //{
            //    p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}
            //else
            //{
            //    oDPMinput.companycode = "";
            //    oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}




            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_schCity(:p_employeecode,:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = oDPMinput.companycode;




                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetODPMschLocation(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;



            //List<string> p_companycode = new List<string>();
            //if (!String.IsNullOrEmpty(oDPMinput.companycode))
            //{
            //    p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}
            //else
            //{
            //    oDPMinput.companycode = "";
            //    oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}

            //List<string> p_citycode = new List<string>();
            //if (!String.IsNullOrEmpty(oDPMinput.citycode))
            //{
            //    p_citycode = oDPMinput.citycode.Replace(" ", "").Split(",").ToList();
            //}
            //else
            //{
            //    oDPMinput.citycode = "";
            //    oDPMinput.citycode.Replace(" ", "").Split(",").ToList();
            //}


            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_schLocation (:p_employeecode,:p_companycode,:p_citycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.citycode))
                        cmd.Parameters.AddWithValue("p_citycode", DbType.Object).Value = oDPMinput.citycode;
                    else
                        cmd.Parameters.AddWithValue("p_citycode", DbType.Object).Value = "";




                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass Getallocusrcreateschtraining(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getallocusrcreateschtraining(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }




        public ResponseClass Geteditschgeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_geteditschgeo(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass Geteditschdep(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_geteditschdep(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GeteditschCity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_geteditschcity(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass Geteditschloc(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_geteditschloc(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass Geteditschgrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_geteditschgrade(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass Geteditschtraname(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_geteditschtraname(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }



        public ResponseClass Geteditschassetlst(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_geteditschassetlst(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetODPMQtrDur()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_qtrdur ()
                                                              ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetODPMNMProgramName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_NMprogramname(:p_geo_code,:p_loggedinempcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_geo_code", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_geo_code", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetODPMNPTrainingName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_NMtrainingname(:p_geo_code,:p_programcode,:p_loggedinempcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_geo_code", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_geo_code", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.programcode))
                        cmd.Parameters.AddWithValue("p_programcode", DbType.String).Value = oDPMinput.programcode;
                    else
                        cmd.Parameters.AddWithValue("p_programcode", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetODPMNPAssetName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_NMassetname(:p_trainingcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //

                    if (!String.IsNullOrEmpty(oDPMinput.trainingcode))
                        cmd.Parameters.AddWithValue("p_trainingcode", DbType.String).Value = oDPMinput.trainingcode;
                    else
                        cmd.Parameters.AddWithValue("p_trainingcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetODPMNPEditAssetName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_NMeditAssetname(:p_workshopid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //


                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = DBNull.Value;
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetOldWorkShop()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_OldWorkShop()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }

        public ResponseClass GetODPMOldWrkShpCity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_OldWrkShpCity(:p_companycode,:p_employeecode,:p_workshopid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetODPMOldWrkShpLocation(ODPMinput oDPMinput)
        {

            List<string> p_citycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.citycode))
            {
                p_citycode = oDPMinput.citycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.citycode = "";
                oDPMinput.citycode.Replace(" ", "").Split(",").ToList();
            }



            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_OldWrkShpLoc(:p_companycode,:p_employeecode,:p_workshopid,:p_citycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.citycode))
                        cmd.Parameters.AddWithValue("p_citycode", DbType.String).Value = p_citycode;
                    else
                        cmd.Parameters.AddWithValue("p_citycode", DbType.String).Value = p_citycode;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetODPMOldWrkShpProName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_OldWrkShpProName(:p_companycode,:p_employeecode,:p_workshopid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GetODPMOldWrkShpTraingName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_OldWrkShpTraingName(:p_companycode,:p_employeecode,:p_workshopid,:p_programcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.programcode))
                        cmd.Parameters.AddWithValue("p_programcode", DbType.String).Value = oDPMinput.programcode;
                    else
                        cmd.Parameters.AddWithValue("p_programcode", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetODPMOldWrkShpAssetName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_OldWrkShpAssetName(:p_companycode,:p_employeecode,:p_workshopid,:p_trainingcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = oDPMinput.companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.trainingcode))
                        cmd.Parameters.AddWithValue("p_trainingcode", DbType.String).Value = oDPMinput.trainingcode;
                    else
                        cmd.Parameters.AddWithValue("p_trainingcode", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass ODPMPMSavetrainschedoldwrkshp(List<schFROMTNI> shareTNIDetails)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                string wrkshopid = "";

                foreach (var a in shareTNIDetails)
                {
                    if (a.actiontype == "insert")
                    {

                        string allByUser = "";
                        string schasslst = "";



                        //foreach (var c in a.schcity)
                        //{
                        //    schcity = schcity + ',' + c;
                        //}

                        foreach (var ass in a.schasslst)
                        {
                            schasslst = schasslst + ',' + ass;
                        }
                        foreach (var u in a.allByUser)
                        {
                            allByUser = allByUser + ',' + u;
                        }

                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_oldwrkshpscheduletraining
                                                                        ( 
                                                                        :poldwrkshp,
                                                                        :pcity,
                                                                        :ploc,
                                                                        :ptrainame,
                                                                        :pproname,
                                                                        :passlst,
                                                                        :ptradate,
                                                                        :pfrmtime,
                                                                        :ptotime,
                                                                        :pfacilitatortype,
                                                                        :pfacilitator,
                                                                        :pAddTrainingDetail,
                                                                        :pDeliveryMode,
                                                                        :pRemarksforParticipant,
                                                                        :pRemarksforManager,
                                                                        :plink,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :pwrkshopid,
                                                                        :pworkshoptype,
                                                                        :pstarthr,
                                                                        :pstartmin,
                                                                        :pstartampm,
                                                                        :pendhr,
                                                                        :pendmin,
                                                                        :pendampm,
                                                                        :ptratodate,
                                                                        :ptimezone,
                                                                        :pallByUser,
                                                                        :pserverstartdate,
                                                                        :pserverenddate,
                                                                        :pserverstarttime,
                                                                        :pserverendtime
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;

                                if (!String.IsNullOrEmpty(a.oldwrkshp))
                                    cmd.Parameters.AddWithValue("poldwrkshp", DbType.String).Value = a.oldwrkshp;
                                else
                                    cmd.Parameters.AddWithValue("poldwrkshp", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.schcity))
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = a.schcity;
                                //schcity.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schloc))
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = a.schloc;
                                else
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schtrainame))
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = a.schtrainame;
                                else
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schproname))
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = a.schproname;
                                else
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schasslst))
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = schasslst.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tradate))
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = a.tradate;
                                else
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmtime))
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = a.frmtime;
                                else
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.totime))
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = a.totime;
                                else
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitatorType))
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = a.facilitatorType;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitator))
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = a.facilitator;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.AddTrainingDetail))
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = a.AddTrainingDetail;
                                else
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.DeliveryMode))
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = a.DeliveryMode;
                                else
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforParticipant))
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = a.RemarksforParticipant;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforManager))
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = a.RemarksforManager;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.link))
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = a.link;
                                else
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinempcode))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinempcode;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = a.rowId;
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(wrkshopid))
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = wrkshopid;
                                else
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.workshoptype))
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = a.workshoptype;
                                else
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmhr))
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = a.frmhr;
                                else
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmmin))
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = a.frmmin;
                                else
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmampm))
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = a.frmampm;
                                else
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tohr))
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = a.tohr;
                                else
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.tomin))
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = a.tomin;
                                else
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.toampm))
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = a.toampm;
                                else
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tratodate))
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = a.tratodate;
                                else
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.timezone))
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = a.timezone;
                                else
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(allByUser))
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = allByUser.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.serverstartdate))
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = a.serverstartdate;
                                else
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverenddate))
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = a.serverenddate;
                                else
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverstarttime))
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = a.serverstarttime;
                                else
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverendtime))
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = a.serverendtime;
                                else
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = string.Empty;


                                npgsqlConnection.Open();
                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                                wrkshopid = dtEmployees.Rows[0]["wrkshopid"].ToString();
                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }
                    }



                    if (a.actiontype == "update")
                    {

                        string allByUser = "";
                        string schasslst = "";



                        //foreach (var c in a.schcity)
                        //{
                        //    schcity = schcity + ',' + c;
                        //}

                        foreach (var ass in a.schasslst)
                        {
                            schasslst = schasslst + ',' + ass;
                        }

                        foreach (var u in a.allByUser)
                        {
                            allByUser = allByUser + ',' + u;
                        }

                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_update_oldwrkshpscheduletraining
                                                                        ( 
                                                                        :poldwrkshp,
                                                                        :pcity,
                                                                        :ploc,
                                                                        :ptrainame,
                                                                        :pproname,
                                                                        :passlst,
                                                                        :ptradate,
                                                                        :pfrmtime,
                                                                        :ptotime,
                                                                        :pfacilitatortype,
                                                                        :pfacilitator,
                                                                        :pAddTrainingDetail,
                                                                        :pDeliveryMode,
                                                                        :pRemarksforParticipant,
                                                                        :pRemarksforManager,
                                                                        :plink,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :pwrkshopid,
                                                                        :pworkshoptype,
                                                                        :pstarthr,
                                                                        :pstartmin,
                                                                        :pstartampm,
                                                                        :pendhr,
                                                                        :pendmin,
                                                                        :pendampm,
                                                                        :ptratodate,
                                                                        :ptimezone,
                                                                        :pallByUser,
                                                                        :pserverstartdate,
                                                                        :pserverenddate,
                                                                        :pserverstarttime,
                                                                        :pserverendtime
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;

                                if (!String.IsNullOrEmpty(a.oldwrkshp))
                                    cmd.Parameters.AddWithValue("poldwrkshp", DbType.String).Value = a.oldwrkshp;
                                else
                                    cmd.Parameters.AddWithValue("poldwrkshp", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schcity))
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = a.schcity;
                                //.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schloc))
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = a.schloc;
                                else
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.schtrainame))
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = a.schtrainame;
                                else
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schproname))
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = a.schproname;
                                else
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schasslst))
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = schasslst.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.tradate))
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = a.tradate;
                                else
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmtime))
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = a.frmtime;
                                else
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.totime))
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = a.totime;
                                else
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitatorType))
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = a.facilitatorType;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitator))
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = a.facilitator;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.AddTrainingDetail))
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = a.AddTrainingDetail;
                                else
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.DeliveryMode))
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = a.DeliveryMode;
                                else
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforParticipant))
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = a.RemarksforParticipant;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforManager))
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = a.RemarksforManager;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.link))
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = a.link;
                                else
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinempcode))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinempcode;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = a.rowId;
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.workshopid))
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = a.workshopid;
                                else
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = "0";
                                if (!String.IsNullOrEmpty(a.workshoptype))
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = a.workshoptype;
                                else
                                    cmd.Parameters.AddWithValue("pworkshoptype", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.frmhr))
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = a.frmhr;
                                else
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmmin))
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = a.frmmin;
                                else
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmampm))
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = a.frmampm;
                                else
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tohr))
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = a.tohr;
                                else
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.tomin))
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = a.tomin;
                                else
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.toampm))
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = a.toampm;
                                else
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tratodate))
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = a.tratodate;
                                else
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.timezone))
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = a.timezone;
                                else
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(allByUser))
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = allByUser.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverstartdate))
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = a.serverstartdate;
                                else
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverenddate))
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = a.serverenddate;
                                else
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverstarttime))
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = a.serverstarttime;
                                else
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverendtime))
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = a.serverendtime;
                                else
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = string.Empty;



                                npgsqlConnection.Open();
                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }

                    }




                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }
            catch (Exception ex)
            {


                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetODPM360vwlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();


            List<string> p_companycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.companycode))
            {
                p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.companycode = "";
                oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_programmanager = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.programmanager))
            {
                p_programmanager = oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.programmanager = "";
                oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_workshop = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.workshop))
            {
                p_workshop = oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.workshop = "";
                oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            }
            string sdate = string.Empty;
            if (!string.IsNullOrEmpty(oDPMinput.fromdate))
            {
                DateTime _sdate = DateTime.ParseExact(oDPMinput.fromdate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                sdate = _sdate.ToString("yyyy-MM-dd");
            }
            else
            {
                DateTime _sdate = DateTime.ParseExact("01-Apr-2000", "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                sdate = _sdate.ToString("yyyy-MM-dd");
            }
            string edate = string.Empty;
            if (!string.IsNullOrEmpty(oDPMinput.todate))
            {
                DateTime _edate = DateTime.ParseExact(oDPMinput.todate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                edate = _edate.ToString("yyyy-MM-dd");
            }
            else
            {
                DateTime _edate = DateTime.ParseExact("01-Apr-2999", "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                edate = _edate.ToString("yyyy-MM-dd");
            }



            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get360vwlist (:p_workshop,:p_companycode,:p_programmanager,:p_fromdate,:p_todate,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = p_companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = p_companycode;



                    if (!String.IsNullOrEmpty(oDPMinput.programmanager))
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.String).Value = p_programmanager;
                    else
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.String).Value = p_programmanager;

                    if (!String.IsNullOrEmpty(oDPMinput.fromdate))
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

                    else
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

                    if (!String.IsNullOrEmpty(oDPMinput.todate))
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;
                    else
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    dtEmployees.Columns.Add("encryptedworkshopid");
                    CommonFunction function = new CommonFunction();

                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            item["encryptedworkshopid"] = function.Encrypt(Convert.ToString(item["workshopid"]));
                        }
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass Getwrkshpcancelreason()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_wrkshpcancelreason()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }
        public ResponseClass Getwrkshpreschreason()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_wrkshpreschreason()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }

        public ResponseClass ODPMPMSaveReschCancel(List<schFROMTNI> shareTNIDetails)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                foreach (var a in shareTNIDetails)
                {

                    if (a.actiontype == "update")
                    {
                        string schgeo = "";
                        string schdep = "";
                        string schcity = "";
                        string schgrade = "";
                        string allByUser = "";
                        string schasslst = "";


                        //foreach (var g in a.schgeo)
                        //{
                        //    schgeo = schgeo + ',' + g;
                        //}
                        //foreach (var d in a.schdep)
                        //{
                        //    schdep = schdep + ',' + d;
                        //}
                        //foreach (var c in a.schcity)
                        //{
                        //    schcity = schcity + ',' + c;
                        //}
                        //foreach (var l in a.schloc)
                        //{
                        //    schloc = schloc + ',' + l;
                        //}
                        //foreach (var g in a.schgrade)
                        //{
                        //    schgrade = schgrade + ',' + g;
                        //}
                        //foreach (var ass in a.schasslst)
                        //{
                        //    schasslst = schasslst + ',' + ass;
                        //}
                        foreach (var u in a.allByUser)
                        {
                            allByUser = allByUser + ',' + u;
                        }
                        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        {
                            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_update_360
                                                                        ( 
                                                                        :pgeo,
                                                                        :pdep,
                                                                        :pcity,
                                                                        :ploc,
                                                                        :pgrade,
                                                                        :ptrainame,
                                                                        :pproname,
                                                                        :passlst,
                                                                        :pallByUser,
                                                                        :ptradate,
                                                                        :pfrmtime,
                                                                        :ptotime,
                                                                        :pfacilitatortype,
                                                                        :pfacilitator,
                                                                        :pAddTrainingDetail,
                                                                        :pDeliveryMode,
                                                                        :pRemarksforParticipant,
                                                                        :pRemarksforManager,
                                                                        :plink,
                                                                        :ploggedinid,
                                                                        :pappstatus,
                                                                        :prowid,
                                                                        :pwrkshopid,
                                                                        :preshorcancelreason,
                                                                        :pworkshopstatus,
                                                                        :pstarthr,
                                                                        :pstartmin,
                                                                        :pstartampm,
                                                                        :pendhr,
                                                                        :pendmin,
                                                                        :pendampm,
                                                                        :ptratodate,
                                                                        :ptimezone,
                                                                        :pserverstartdate,
                                                                        :pserverenddate,
                                                                        :pserverstarttime,
                                                                        :pserverendtime
                                                                        )", npgsqlConnection))
                            {
                                cmd.CommandType = CommandType.Text;

                                if (!String.IsNullOrEmpty(schgeo))
                                    cmd.Parameters.AddWithValue("pgeo", DbType.String).Value = schgeo.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pgeo", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schdep))
                                    cmd.Parameters.AddWithValue("pdep", DbType.String).Value = schdep.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pdep", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schcity))
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = schcity.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pcity", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schloc))
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = a.schloc;
                                else
                                    cmd.Parameters.AddWithValue("ploc", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schgrade))
                                    cmd.Parameters.AddWithValue("pgrade", DbType.String).Value = schgrade.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pgrade", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schtrainame))
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = a.schtrainame;
                                else
                                    cmd.Parameters.AddWithValue("ptrainame", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.schproname))
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = a.schproname;
                                else
                                    cmd.Parameters.AddWithValue("pproname", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(schasslst))
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = schasslst.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("passlst", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(allByUser))
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = allByUser.Remove(0, 1);
                                else
                                    cmd.Parameters.AddWithValue("pallByUser", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tradate))
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = a.tradate;
                                else
                                    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmtime))
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = a.frmtime;
                                else
                                    cmd.Parameters.AddWithValue("pfrmtime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.totime))
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = a.totime;
                                else
                                    cmd.Parameters.AddWithValue("ptotime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitatorType))
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = a.facilitatorType;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitatortype", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.facilitator))
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = a.facilitator;
                                else
                                    cmd.Parameters.AddWithValue("pfacilitator", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.AddTrainingDetail))
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = a.AddTrainingDetail;
                                else
                                    cmd.Parameters.AddWithValue("pAddTrainingDetail", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.DeliveryMode))
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = a.DeliveryMode;
                                else
                                    cmd.Parameters.AddWithValue("pDeliveryMode", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforParticipant))
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = a.RemarksforParticipant;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforParticipant", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.RemarksforManager))
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = a.RemarksforManager;
                                else
                                    cmd.Parameters.AddWithValue("pRemarksforManager", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.link))
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = a.link;
                                else
                                    cmd.Parameters.AddWithValue("plink", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.loggedinempcode))
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinempcode;
                                else
                                    cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.appstatus))
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = a.appstatus;
                                else
                                    cmd.Parameters.AddWithValue("pappstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.rowId))
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = a.rowId;
                                else
                                    cmd.Parameters.AddWithValue("prowid", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.workshopid))
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = a.workshopid;
                                else
                                    cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = "0";

                                if (!String.IsNullOrEmpty(a.reshorcancelreason))
                                    cmd.Parameters.AddWithValue("preshorcancelreason", DbType.String).Value = a.reshorcancelreason;
                                else
                                    cmd.Parameters.AddWithValue("preshorcancelreason", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.workshopstatus))
                                    cmd.Parameters.AddWithValue("pworkshopstatus", DbType.String).Value = a.workshopstatus;
                                else
                                    cmd.Parameters.AddWithValue("pworkshopstatus", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.frmhr))
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = a.frmhr;
                                else
                                    cmd.Parameters.AddWithValue("pstarthr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmmin))
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = a.frmmin;
                                else
                                    cmd.Parameters.AddWithValue("pstartmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.frmampm))
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = a.frmampm;
                                else
                                    cmd.Parameters.AddWithValue("pstartampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tohr))
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = a.tohr;
                                else
                                    cmd.Parameters.AddWithValue("pendhr", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.tomin))
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = a.tomin;
                                else
                                    cmd.Parameters.AddWithValue("pendmin", DbType.String).Value = string.Empty;
                                if (!String.IsNullOrEmpty(a.toampm))
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = a.toampm;
                                else
                                    cmd.Parameters.AddWithValue("pendampm", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.tratodate))
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = a.tratodate;
                                else
                                    cmd.Parameters.AddWithValue("ptratodate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.timezone))
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = a.timezone;
                                else
                                    cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = string.Empty;


                                if (!String.IsNullOrEmpty(a.serverstartdate))
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = a.serverstartdate;
                                else
                                    cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverenddate))
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = a.serverenddate;
                                else
                                    cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverstarttime))
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = a.serverstarttime;
                                else
                                    cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = string.Empty;

                                if (!String.IsNullOrEmpty(a.serverendtime))
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = a.serverendtime;
                                else
                                    cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = string.Empty;



                                npgsqlConnection.Open();
                                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                                dataAdapter.Fill(dtEmployees);
                                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            }
                        }

                    }





                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }
            catch (Exception ex)
            {


                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetPMSchTrainingDetails(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();

            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getpmschtrainingdetails (:p_status,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;


                    if (!String.IsNullOrEmpty(oDPMinput.status))
                        cmd.Parameters.AddWithValue("p_status", DbType.String).Value = oDPMinput.status;
                    else
                        cmd.Parameters.AddWithValue("p_status", DbType.String).Value = DBNull.Value;



                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass getPM360statlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();

            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getpm360statlist (:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;


                    //if (!String.IsNullOrEmpty(oDPMinput.status))
                    //    cmd.Parameters.AddWithValue("p_status", DbType.String).Value = oDPMinput.status;
                    //else
                    //    cmd.Parameters.AddWithValue("p_status", DbType.String).Value = DBNull.Value;



                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetODPMmarkattlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();


            List<string> p_companycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.companycode))
            {
                p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.companycode = "";
                oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_programmanager = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.programmanager))
            {
                p_programmanager = oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.programmanager = "";
                oDPMinput.programmanager.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_workshop = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.workshop))
            {
                p_workshop = oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.workshop = "";
                oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            }
            string sdate = string.Empty;
            if (!string.IsNullOrEmpty(oDPMinput.fromdate))
            {
                DateTime _sdate = DateTime.ParseExact(oDPMinput.fromdate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                sdate = _sdate.ToString("yyyy-MM-dd");
            }
            else
            {
                DateTime _sdate = DateTime.ParseExact("01-Apr-2000", "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                sdate = _sdate.ToString("yyyy-MM-dd");
            }
            string edate = string.Empty;
            if (!string.IsNullOrEmpty(oDPMinput.todate))
            {
                DateTime _edate = DateTime.ParseExact(oDPMinput.todate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                edate = _edate.ToString("yyyy-MM-dd");
            }

            else
            {
                DateTime _edate = DateTime.ParseExact("01-Apr-2099", "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                edate = _edate.ToString("yyyy-MM-dd");
            }


            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getmarkattlist (:p_workshop,:p_companycode,:p_programmanager,:p_fromdate,:p_todate,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;

                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = p_companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = p_companycode;



                    if (!String.IsNullOrEmpty(oDPMinput.programmanager))
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.String).Value = p_programmanager;
                    else
                        cmd.Parameters.AddWithValue("p_programmanager", DbType.String).Value = p_programmanager;

                    if (!String.IsNullOrEmpty(oDPMinput.fromdate))
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

                    else
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

                    if (!String.IsNullOrEmpty(oDPMinput.todate))
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;
                    else
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    dtEmployees.Columns.Add("encryptedworkshopid");
                    dtEmployees.Columns.Add("encryptedattdfinalstatus");
                    
                    CommonFunction function = new CommonFunction();

                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            item["encryptedworkshopid"] = function.Encrypt(Convert.ToString(item["workshopid"]));
                            if(item["attdfinalstatus"].ToString()=="E")
                            {
                                item["encryptedattdfinalstatus"] = function.Encrypt(Convert.ToString("E"));
                            }
                            if (item["attdfinalstatus"].ToString() == "V")
                            {
                                item["encryptedattdfinalstatus"] = function.Encrypt(Convert.ToString("V"));
                            }

                        }
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass GetPMemployeeattd(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            DataTable dt = new DataTable();
            dt.Columns.Add("employeecode", typeof(string));
            dt.Columns.Add("employeename", typeof(string));
           

            DataTable dt1 = new DataTable();
            dt1.Columns.Add("trainingdate", typeof(string));
            //dt1.Columns.Add("employeecode", typeof(string));

            DataTable dt2 = new DataTable();
            dt2.Columns.Add("employeecode", typeof(string));
            dt2.Columns.Add("trainingdate", typeof(string));
            dt2.Columns.Add("markattd", typeof(string));

            DataSet ds = new DataSet();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_employeeattd (:p_workshopid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    //var emp = (from r in dtEmployees.AsEnumerable()
                    //           select r["employeecode"]).Distinct().ToList();

                    DataRow dtr;
                    //body.arrayData.ForEach(row => dt.Rows.Add(row.Cast<object>().ToArray()));
                    foreach (DataRow row in dtEmployees.Rows)
                    {
                        dtr = dt.NewRow();
                        dtr[0] = row["employeecode"];
                        dtr[1] = row["employeename"];
                        dt.Rows.Add(dtr);
                    }

                    DataRow dtfr;
                    foreach (DataRow row in dtEmployees.Rows)
                    {
                        dtfr = dt2.NewRow();
                        dtfr[0] = row["employeecode"];
                        dtfr[1] = row["trainingdate"];
                        dtfr[2] = row["markattd"];
                        dt2.Rows.Add(dtfr);
                    }


                    DataTable distinctTable = dt.DefaultView.ToTable( /*distinct*/ true);

                    var todate = (from r in dtEmployees.AsEnumerable()
                                  select r["trainingdate"]).Distinct().ToList();
                    var employeecode = (from r in dtEmployees.AsEnumerable()
                                        select r["employeecode"]).Distinct().ToList();

                    //var todate =  dtEmployees.AsEnumerable()
                    //.Select(row => new
                    //{
                    //    trainingdate = row.Field<string>("trainingdate"),
                    //    employeecode = row.Field<string>("employeecode")
                    //})
                    //.Distinct();


                  var query3 = todate.Union(employeecode);

                    DataRow dtdr;
                    //foreach (var em in employeecode)
                    //{

                    foreach (var e in todate)
                    {
                        dtdr = dt1.NewRow();
                        dtdr[0] = e;
                        dt1.Rows.Add(dtdr);
                    }

                    //}

                    //foreach (DataRow row in dt1.Rows)
                    //{
                    //    foreach (var em in employeecode)
                    //    {
                    //        //        if (row["employeecode"] != em)
                    //        //        {
                    //        row["employeecode"] = em;
                    //        //            //var itemToRemove = employeecode.Single(r => r == em);
                    //        //            //employeecode.Remove(itemToRemove);
                    //        //        }
                    //    }
                    //}


                    ds.Tables.Add(distinctTable);
                    ds.Tables.Add(dt1);
                    ds.Tables.Add(dt2);



                    response.responseJSON = JsonConvert.SerializeObject(ds);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass ODPMInsertMarkAttd(List<markAttd> markAttds)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                foreach (var a in markAttds)
                {
                    //string tradate = "";
                    //foreach (var g in a.tradate)
                    //{
                    //    tradate = tradate + ',' + g;
                    //}
                    //tradate = tradate.Remove(0, 1);
                    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_markattd
                                                                        ( 
                                                                        :pemployeecode,
                                                                        :ptradate,
                                                                        :preason,
                                                                        :ploggedinid,
                                                                        :pwrkshopid,
                                                                        :premarks,
                                                                        :pmarkattd
                                                                        )", npgsqlConnection))
                        {
                            cmd.CommandType = CommandType.Text;

                            if (!String.IsNullOrEmpty(a.employeecode))
                                cmd.Parameters.AddWithValue("pemployeecode", DbType.String).Value = a.employeecode;
                            else
                                cmd.Parameters.AddWithValue("pemployeecode", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(a.tradate))
                                cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = a.tradate;
                            else
                                cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = string.Empty;

                            //if (!String.IsNullOrEmpty(a.ftradate))
                                //cmd.Parameters.AddWithValue("pftradate", DbType.String).Value = a.ftradate;
                            //else
                             //   cmd.Parameters.AddWithValue("pftradate", DbType.String).Value = string.Empty;
                            if (!String.IsNullOrEmpty(a.reason))
                                cmd.Parameters.AddWithValue("preason", DbType.String).Value = a.reason;
                            else
                                cmd.Parameters.AddWithValue("preason", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(a.loggedinempcode))
                                cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinempcode;
                            else
                                cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(a.workshopid))
                                cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = a.workshopid;
                            else
                                cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(a.remarks))
                                cmd.Parameters.AddWithValue("premarks", DbType.String).Value = a.remarks;
                            else
                                cmd.Parameters.AddWithValue("premarks", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(a.markattd))
                                cmd.Parameters.AddWithValue("pmarkattd", DbType.String).Value = a.markattd;
                            else
                                cmd.Parameters.AddWithValue("pmarkattd", DbType.String).Value = string.Empty;

                            npgsqlConnection.Open();
                            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                            dataAdapter.Fill(dtEmployees);
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            response.responseCode = 1;
                            response.responseMessage = "Success";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass ODPMFinalMarkAttd(List<markAttd> markAttds)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                foreach (var a in markAttds)
                {
                    //string tradate = "";
                    //foreach (var g in a.tradate)
                    //{
                    //    tradate = tradate + ',' + g;
                    //}
                    //tradate = tradate.Remove(0, 1);
                    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_final_markattd
                                                                        ( 
                                                                        :pemployeecode,
                                                                        :ploggedinid,
                                                                        :pwrkshopid,
                                                                        :pmarkattd
                                                                        )", npgsqlConnection))
                        {
                            cmd.CommandType = CommandType.Text;

                            if (!String.IsNullOrEmpty(a.employeecode))
                                cmd.Parameters.AddWithValue("pemployeecode", DbType.String).Value = a.employeecode;
                            else
                                cmd.Parameters.AddWithValue("pemployeecode", DbType.String).Value = string.Empty;

                            //if (!String.IsNullOrEmpty(a.tradate))
                            //    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = a.tradate;
                            //else
                            //    cmd.Parameters.AddWithValue("ptradate", DbType.String).Value = string.Empty;

                            //if (!String.IsNullOrEmpty(a.ftradate))
                            //cmd.Parameters.AddWithValue("pftradate", DbType.String).Value = a.ftradate;
                            //else
                            //   cmd.Parameters.AddWithValue("pftradate", DbType.String).Value = string.Empty;
                            //if (!String.IsNullOrEmpty(a.reason))
                            //    cmd.Parameters.AddWithValue("preason", DbType.String).Value = a.reason;
                            //else
                            //    cmd.Parameters.AddWithValue("preason", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(a.loggedinempcode))
                                cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = a.loggedinempcode;
                            else
                                cmd.Parameters.AddWithValue("ploggedinid", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(a.workshopid))
                                cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = a.workshopid;
                            else
                                cmd.Parameters.AddWithValue("pwrkshopid", DbType.String).Value = string.Empty;

                            //if (!String.IsNullOrEmpty(a.remarks))
                            //    cmd.Parameters.AddWithValue("premarks", DbType.String).Value = a.remarks;
                            //else
                            //    cmd.Parameters.AddWithValue("premarks", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(a.markattd))
                                cmd.Parameters.AddWithValue("pmarkattd", DbType.String).Value = a.markattd;
                            else
                                cmd.Parameters.AddWithValue("pmarkattd", DbType.String).Value = string.Empty;

                            npgsqlConnection.Open();
                            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                            dataAdapter.Fill(dtEmployees);
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            response.responseCode = 1;
                            response.responseMessage = "Success";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        


        public ResponseClass GetODPMPMmarkemployeeattd(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();

            DataTable dt1 = new DataTable();
            dt1.Columns.Add("trainingdate", typeof(string));
            DataSet ds = new DataSet();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_markedemployeeattd (:p_workshopid)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;


                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();

                    var todate = (from r in dtEmployees.AsEnumerable()
                                  select r["trainingdate"]).Distinct().ToList();
                    DataRow dtdr;
                    foreach (var e in todate)
                    {
                        dtdr = dt1.NewRow();
                        dtdr[0] = e;
                        dt1.Rows.Add(dtdr);
                    }
                    ds.Tables.Add(dt1);
                    ds.Tables.Add(dtEmployees);
                    response.responseJSON = JsonConvert.SerializeObject(ds);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass GetODPMenabfeedlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();


            //List<string> p_companycode = new List<string>();
            //if (!String.IsNullOrEmpty(oDPMinput.companycode))
            //{
            //    p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}
            //else
            //{
            //    oDPMinput.companycode = "";
            //    oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            //}

            List<string> p_programcode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.programcode))
            {
                p_programcode = oDPMinput.programcode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.programcode = "";
                oDPMinput.programcode.Replace(" ", "").Split(",").ToList();
            }

            List<string> p_trainingcode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.trainingcode))
            {
                p_trainingcode = oDPMinput.trainingcode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.trainingcode = "";
                oDPMinput.trainingcode.Replace(" ", "").Split(",").ToList();
            }


            List<string> p_workshop = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.workshop))
            {
                p_workshop = oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.workshop = "";
                oDPMinput.workshop.Replace(" ", "").Split(",").ToList();
            }
            string sdate = string.Empty;
            if (!string.IsNullOrEmpty(oDPMinput.fromdate))
            {
                DateTime _sdate = DateTime.ParseExact(oDPMinput.fromdate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                sdate = _sdate.ToString("yyyy-MM-dd");
            }
            else
            {
                DateTime _sdate = DateTime.ParseExact("01-Apr-2000", "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                sdate = _sdate.ToString("yyyy-MM-dd");
            }
            string edate = string.Empty;
            if (!string.IsNullOrEmpty(oDPMinput.todate))
            {
                DateTime _edate = DateTime.ParseExact(oDPMinput.todate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                edate = _edate.ToString("yyyy-MM-dd");
            }
            else
            {
                DateTime _edate = DateTime.ParseExact("01-Apr-2099", "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                edate = _edate.ToString("yyyy-MM-dd");
            }



            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getenabfeedlist (:p_workshop,:p_programname,:p_trainingname,:p_fromdate,:p_todate,:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;

                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.Object).Value = p_workshop;

                    //if (!String.IsNullOrEmpty(oDPMinput.companycode))
                    //    cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = p_companycode;
                    //else
                    //    cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = p_companycode;



                    if (!String.IsNullOrEmpty(oDPMinput.programcode))
                        cmd.Parameters.AddWithValue("p_programname", DbType.String).Value = p_programcode;
                    else
                        cmd.Parameters.AddWithValue("p_programname", DbType.String).Value = p_programcode;

                    if (!String.IsNullOrEmpty(oDPMinput.trainingcode))
                        cmd.Parameters.AddWithValue("p_trainingname", DbType.String).Value = p_trainingcode;
                    else
                        cmd.Parameters.AddWithValue("p_trainingname", DbType.String).Value = p_trainingcode;

                    if (!String.IsNullOrEmpty(oDPMinput.fromdate))
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

                    else
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

                    if (!String.IsNullOrEmpty(oDPMinput.todate))
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;
                    else
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    cmd.CommandTimeout = 0;
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();

                    dtEmployees.Columns.Add("encryptedworkshopid");
                    CommonFunction function = new CommonFunction();

                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            item["encryptedworkshopid"] = function.Encrypt(Convert.ToString(item["workshopid"]));

                        }
                    }





                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }



        public ResponseClass GetODPMfeedworkshop(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_feedworkshop(:p_employeecode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }

        public ResponseClass GetODPMsurveytype(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtsurvey = new DataTable();
            dtsurvey.Columns.Add("templateid");
            dtsurvey.Columns.Add("templatename");
            string surveyResponse = _serviceconnect.getODPMSurvey(oDPMinput.loggedinempcode);
            TLDEnvelope responseData = JsonConvert.DeserializeObject<TLDEnvelope>(surveyResponse);
            if (responseData.Status == true && responseData.TotalRecords > 0 && responseData.Data != null)
            {

                foreach (var item in responseData.Data.Data)
                { 
                    dtsurvey.Rows.Add(item.TemplateId, item.TemplateName);
                }
            }
            

            response.responseJSON = JsonConvert.SerializeObject(dtsurvey);

            response.responseCode = 1;
            response.responseMessage = "SUCCESS";
            return response;
        }


        public ResponseClass GetODPMsurveyquestion(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtsurvey = new DataTable();
            dtsurvey.Columns.Add("TemplateName");
            dtsurvey.Columns.Add("questionId");
            dtsurvey.Columns.Add("question");
            dtsurvey.Columns.Add("responseType");
            dtsurvey.Columns.Add("isQuestionMandatory");
            string surveyResponse = _serviceconnect.GetODPMsurveyquestion(oDPMinput.TemplateId);
            TLDQuesEnvelope responseData = JsonConvert.DeserializeObject<TLDQuesEnvelope>(surveyResponse);
            if (responseData.Status == true && responseData.TotalRecords > 0 && responseData.Data != null)
            {

                foreach (var item in responseData.Data.Data)
                {
                    dtsurvey.Rows.Add(item.TemplateName, item.questionId, item.question,item.responseType,item.isQuestionMandatory);
                }
            }


            response.responseJSON = JsonConvert.SerializeObject(dtsurvey);

            response.responseCode = 1;
            response.responseMessage = "SUCCESS";
            return response;
        }

       public ResponseClass GetODPMfeedbackdetails(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getfeedbackdetails(:p_workshop)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass ODPMsavefeedback(List<feedback> feedback)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            foreach (var a in feedback)
            {
                savefeedbackDTO savefeedbackDTO = new savefeedbackDTO();
                savefeedbackDTO.LoggedInEmployeeId = a.loggedinempcode;
                savefeedbackDTO.SurveyId = Convert.ToInt32(a.surveyid);
                savefeedbackDTO.StartDate = Convert.ToDateTime(a.startdate);
                savefeedbackDTO.EndDate = Convert.ToDateTime(a.enddate);
                savefeedbackDTO.TemplateId = Convert.ToInt32(a.feedbackddlid);
                savefeedbackDTO.TemplateName = a.feedbackddlname;
                string surveyResponse = _serviceconnect.savefeedback(savefeedbackDTO);
                ODPMSurveyDetailsData responseData = JsonConvert.DeserializeObject<ODPMSurveyDetailsData>(surveyResponse);
                var statflag = a.surveyid;
                a.surveyid = responseData.data.SurveyId.ToString();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_feedback
                                                                        ( 
                                                                        :p_workshopid
                                                                        ,:p_surveyid
                                                                        ,:p_startdate
                                                                        ,:p_enddate
                                                                        ,:p_surveystatus
                                                                        ,:p_templateid
                                                                        ,:p_templatename
                                                                        ,:p_feedbackname
                                                                        ,:p_loggedinemployee
                                                                        ,:p_statflag
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(a.workshopid))
                            cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = a.workshopid;
                        else
                            cmd.Parameters.AddWithValue("p_workshopid", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(a.surveyid))
                            cmd.Parameters.AddWithValue("p_surveyid", DbType.String).Value = a.surveyid;
                        else
                            cmd.Parameters.AddWithValue("p_surveyid", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(a.startdate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = a.startdate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(a.enddate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = a.enddate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(a.appstatus))
                            cmd.Parameters.AddWithValue("p_surveystatus", DbType.String).Value = a.appstatus;
                        else
                            cmd.Parameters.AddWithValue("p_surveystatus", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(a.feedbackddlid))
                            cmd.Parameters.AddWithValue("p_templateid", DbType.String).Value = a.feedbackddlid;
                        else
                            cmd.Parameters.AddWithValue("p_templateid", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(a.feedbackddlname))
                            cmd.Parameters.AddWithValue("p_templatename", DbType.String).Value = a.feedbackddlname;
                        else
                            cmd.Parameters.AddWithValue("p_templatename", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(a.feedbackname))
                            cmd.Parameters.AddWithValue("p_feedbackname", DbType.String).Value = a.feedbackname;
                        else
                            cmd.Parameters.AddWithValue("p_feedbackname", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(a.loggedinempcode))
                            cmd.Parameters.AddWithValue("p_loggedinemployee", DbType.String).Value = a.loggedinempcode;
                        else
                            cmd.Parameters.AddWithValue("p_loggedinemployee", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(statflag))
                            cmd.Parameters.AddWithValue("p_statflag", DbType.String).Value = statflag;
                        else
                            cmd.Parameters.AddWithValue("p_statflag", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();
                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        response.responseCode = 1;
                        response.responseMessage = "Success";
                    }
                }

            }
            //DataTable dtEmployees = new DataTable();
            //string pgsqlConnection = appSettings.Value.DbConnection;
            //using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            //{
            //    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getfeedbackdetails(:p_workshop)
            //                                                       ", npgsqlConnection))
            //    {
            //        cmd.CommandType = CommandType.Text;
            //        if (!String.IsNullOrEmpty(oDPMinput.workshop))
            //            cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
            //        else
            //            cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;


            //        npgsqlConnection.Open();
            //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
            //        dataAdapter.Fill(dtEmployees);
            //        npgsqlConnection.Close();
            //        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
            //        response.responseCode = 1;
            //        response.responseMessage = "Success";
            //    }
            //}

            return response;
        }
        //public ResponseClass ManageVideoMasterlist(manageVideoMasterrequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable trainingGroup = new DataTable();

        //        string sdate = string.Empty;
        //        if (!string.IsNullOrEmpty(request.fromDate))
        //        {
        //            DateTime _sdate = DateTime.ParseExact(request.fromDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
        //            sdate = _sdate.ToString("yyyy-MM-dd");
        //        }
        //        else
        //        {
        //            request.fromDate = "01-Apr-2000";
        //            DateTime _sdate = DateTime.ParseExact(request.fromDate, "dd-MMM-yyyy", CultureInfo.InvariantCulture);
        //            sdate = _sdate.ToString("yyyy-MM-dd");
        //        }
        //        string edate = string.Empty;
        //        if (!string.IsNullOrEmpty(request.toDate))
        //        {

        //            DateTime _edate = DateTime.ParseExact(request.toDate, "dd-MMM-yyyy", CultureInfo.InvariantCulture);
        //            edate = _edate.ToString("yyyy-MM-dd");
        //        }
        //        else
        //        {
        //            request.toDate = "01-Apr-2099";
        //            DateTime _edate = DateTime.ParseExact(request.toDate, "dd-MMM-yyyy", CultureInfo.InvariantCulture);
        //            edate = _edate.ToString("yyyy-MM-dd");
        //        }



        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
        //        {
        //            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_VideoMasterlist (:p_fromdate,:p_todate,:p_videoName,:p_employeecode)
        //                                                           ", npgsqlConnection))
        //            {
        //                cmd.CommandType = CommandType.Text;


        //                if (!String.IsNullOrEmpty(request.fromDate))
        //                    cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = sdate;

        //                else
        //                    cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = DBNull.Value;

        //                if (!String.IsNullOrEmpty(request.toDate))
        //                    cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = edate;
        //                else
        //                    cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = DBNull.Value;


        //                if (!String.IsNullOrEmpty(request.videoName))
        //                    cmd.Parameters.AddWithValue("p_videoName", DbType.String).Value = request.videoName;
        //                else
        //                    cmd.Parameters.AddWithValue("p_videoName", DbType.String).Value = "";

        //                if (!String.IsNullOrEmpty(request.LoginEMPCode))
        //                    cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.LoginEMPCode;
        //                else
        //                    cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

        //                npgsqlConnection.Open();
        //                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
        //                cmd.CommandTimeout = 0;
        //                dataAdapter.Fill(trainingGroup);
        //                npgsqlConnection.Close();
        //                trainingGroup.Columns.Add("encryptedID");
        //                CommonFunction function = new CommonFunction();

        //                if (trainingGroup != null && trainingGroup.Rows.Count > 0)
        //                {
        //                    foreach (DataRow item in trainingGroup.Rows)
        //                    {
        //                        item["encryptedID"] = function.Encrypt(Convert.ToString(item["videocode"]));
        //                    }
        //                }
        //                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
        //                response.responseCode = 1;
        //                response.responseMessage = "Success";
        //            }
        //        }


        //        //#region Pagination
        //        //int recordcount = 1;
        //        //if (trainingGroup != null && trainingGroup.Rows.Count > 0)
        //        //{
        //        //    recordcount = trainingGroup.Rows.Count;
        //        //    if (request.PageNumber != -1)
        //        //    {
        //        //        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

        //        //        int recordPages = Convert.ToInt32(noOfPages);

        //        //        if (noOfPages > recordPages)
        //        //        {
        //        //            recordPages = recordPages + 1;
        //        //        }

        //        //        response.recordCount = recordPages;
        //        //    }
        //        //}

        //        //var _trainingGroup = trainingGroup.AsEnumerable().Skip((request.PageNumber - 1) * request.RowsOfPage)
        //        //        .Take(request.RowsOfPage).CopyToDataTable();
        //        //#endregion
        //        //response.responseJSON = JsonConvert.SerializeObject(_trainingGroup);



        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("ManageVideoMaster", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}

        //public ResponseClass InsertVideoMaster(addVideoMasterRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    string pgsqlConnection = appSettings.Value.DbConnection;
        //    NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
        //    if (request.action == "ADD")
        //    {
        //        try
        //        {
        //            //TSequenceNo
        //            string videoCodeNo = string.Empty;
        //            int codeCountNoCount = 0;
        //            string sqlQuery1 = "SELECT coalesce(max(#TSequenceNo#),0) as #TSequenceNo# FROM public.#ODPM_VideoMaster#";

        //            sqlQuery1 = sqlQuery1.Replace('#', '"');

        //            npgsqlCon.Open();

        //            NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

        //            NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

        //            if (npgsqlDataReader1.Read())
        //            {
        //                videoCodeNo = npgsqlDataReader1[0].ToString();
        //                codeCountNoCount = Convert.ToInt32(videoCodeNo) + 1;
        //                request.videoCode = "VD" + codeCountNoCount;
        //            }
        //            else
        //            {
        //                ++codeCountNoCount;
        //                request.videoCode = "VD" + codeCountNoCount;
        //            }

        //            npgsqlCon.Close();

        //            //Insert Data VideoMaster
        //            request.description = request.description.Replace("'", "''");
        //            request.VideoType = request.VideoType.Replace('_', ' ');
        //            string sqlQuery = "INSERT INTO public.#ODPM_VideoMaster#(#VideoCode#,#VideoTitle#,#Description#,#Searchkeywords#,#TSequenceNo#,#InsertedBy#,#InsertedDateTime#,#InsertedIPAddress#,#VideoType#,#status#,#DeletedFlag#,#pointsearned#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(request.videoTitle) + "', '" + RemoveQuotes(request.description) + "', '" + RemoveQuotes(request.serachkeyword) + "', '" + codeCountNoCount + "', '" + request.insertedBy + "', now(), '" + request.insertedIPAddress + "', '" + request.VideoType + "', '" + request.Status + "', '0', '" + request.PointsEarned + "')";

        //            sqlQuery = sqlQuery.Replace('#', '"');

        //            npgsqlCon.Open();

        //            NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

        //            NpgsqlDataReader dataReader = cmd.ExecuteReader();

        //            npgsqlCon.Close();

        //            //Get Latest Video Code
        //            string videoCode = string.Empty;
        //            string videoId = string.Empty;

        //            string sqlQuery2 = "SELECT max(#VideoID#) as #VideoID# FROM public.#ODPM_VideoMaster#";

        //            sqlQuery2 = sqlQuery2.Replace('#', '"');

        //            npgsqlCon.Open();

        //            NpgsqlCommand npgsqlCommand2 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

        //            NpgsqlDataReader npgsqlDataReader2 = npgsqlCommand2.ExecuteReader();

        //            if (npgsqlDataReader2.Read())
        //            {
        //                // videoCode = npgsqlDataReader2[0].ToString();
        //                videoId = npgsqlDataReader2[0].ToString();
        //            }
        //            npgsqlCon.Close();

        //            if (request.addVideoHighlights != null && request.addVideoHighlights.Count > 0)
        //            {
        //                foreach (var item in request.addVideoHighlights)
        //                {
        //                    string sqlQuery3 = string.Empty;
        //                    //Insert Data addVideoHighlights
        //                    if (!string.IsNullOrEmpty(item.HighlightsText))
        //                    {
        //                        sqlQuery3 = "INSERT INTO public.#ODPM_VideoHighlights#(#VideoCode#,#HighlightedText#,#DurationMinute#,#DurationSecond#,#VideoID#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.HighlightsText) + "', '" + RemoveQuotes(item.DurationMinute) + "', '" + RemoveQuotes(item.DurationSecond) + "', '" + videoId + "')";
        //                        sqlQuery3 = sqlQuery3.Replace('#', '"');

        //                        npgsqlCon.Open();

        //                        NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery3, npgsqlCon);

        //                        NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();

        //                        npgsqlCon.Close();
        //                    }
        //                }
        //            }

        //            if (request.addVideoAttachments != null && request.addVideoAttachments.Count > 0)
        //            {
        //                foreach (var item in request.addVideoAttachments)
        //                {
        //                    //Insert Data addVideoAttachments
        //                    string sqlQuery4 = "INSERT INTO public.#ODPM_VideoFile#(#videocode#,#videofilename#,#videofilepath#,#videofiletype#,#mediatype#,#videothumbnail#,#videoid#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.FileName) + "', '" + RemoveQuotes(item.FilePath) + "', '" + item.FileType + "', '" + item.MediaType + "', '" + RemoveQuotes(item.VideoThumbnail) + "', '" + videoId + "')";

        //                    sqlQuery4 = sqlQuery4.Replace('#', '"');

        //                    npgsqlCon.Open();

        //                    NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery4, npgsqlCon);

        //                    NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();

        //                    npgsqlCon.Close();
        //                }
        //            }
        //            response.responseCode = 1;
        //            response.responseMessage = "Success";
        //        }
        //        catch (Exception ex)
        //        {
        //            _serviceconnect.LogConnect("Add Video", "1024", ex.Message, "Exception");
        //            response.responseCode = 0;
        //            response.responseMessage = ex.Message;
        //        }
        //    }
        //    else if (request.action == "EDIT")
        //    {
        //        try
        //        {
        //            if (string.IsNullOrEmpty(request.videoCode))
        //            {
        //                response.responseMessage = "Please provide videocode.";
        //            }
        //            else
        //            {
        //                //Update Video Master

        //                request.VideoType = request.VideoType.Replace('_', ' ');
        //                string sqlQuery = "UPDATE public.#ODPM_VideoMaster# SET #VideoTitle#='" + RemoveQuotes(request.videoTitle) + "',#Description#='" + RemoveQuotes(request.description) + "',#Searchkeywords#='" + RemoveQuotes(request.serachkeyword) + "',#UpdatedBy#='" + request.insertedBy + "',#UpdatedOn#=now(),#UpdatedIPAddress#='" + request.insertedIPAddress + "',#VideoType#='" + request.VideoType + "',#pointsearned#='" + request.PointsEarned + "',#status#='" + request.Status + "' WHERE #VideoCode# = '" + request.videoCode + "'";

        //                sqlQuery = sqlQuery.Replace('#', '"');
        //                npgsqlCon.Open();
        //                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);
        //                NpgsqlDataReader dataReader = cmd.ExecuteReader();
        //                npgsqlCon.Close();

        //                // Delete previous video heightlights
        //                string sqlQuery1 = "DELETE FROM public.#ODPM_VideoHighlights# WHERE #VideoCode# = '" + request.videoCode + "'";

        //                sqlQuery1 = sqlQuery1.Replace('#', '"');
        //                npgsqlCon.Open();
        //                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);
        //                NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();
        //                npgsqlCon.Close();

        //                //Update previous video heightlights
        //                if (request.addVideoHighlights != null && request.addVideoHighlights.Count > 0)
        //                {
        //                    foreach (var item in request.addVideoHighlights)
        //                    {
        //                        if (!string.IsNullOrEmpty(item.HighlightsText))
        //                        {
        //                            string sqlQuery2 = "INSERT INTO public.#ODPM_VideoHighlights#(#VideoCode#,#HighlightedText#,#DurationMinute#,#DurationSecond#,#VideoID#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.HighlightsText) + "', '" + item.DurationMinute + "', '" + item.DurationSecond + "', '" + request.videoID + "')";

        //                            sqlQuery2 = sqlQuery2.Replace('#', '"');

        //                            npgsqlCon.Open();
        //                            NpgsqlCommand cmd2 = new NpgsqlCommand(sqlQuery2, npgsqlCon);
        //                            NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();
        //                            npgsqlCon.Close();
        //                        }
        //                    }
        //                }
        //                if (request.addVideoAttachments != null && request.addVideoAttachments.Count > 0)
        //                {
        //                    foreach (var item in request.addVideoAttachments)
        //                    {
        //                        //Update Data addVideoAttachments
        //                        if (item.MediaType == "Attachment")
        //                        {
        //                            int videoAttachementCount = 0;

        //                            string sqlQuery3 = "SELECT count(#videocode#) FROM public.#ODPM_VideoFile# WHERE mediatype='Attachment' and videocode ='" + request.videoCode + "'";

        //                            sqlQuery3 = sqlQuery3.Replace('#', '"');

        //                            npgsqlCon.Open();
        //                            NpgsqlCommand npgsqlCommand2 = new NpgsqlCommand(sqlQuery3, npgsqlCon);
        //                            NpgsqlDataReader npgsqlDataReader2 = npgsqlCommand2.ExecuteReader();
        //                            if (npgsqlDataReader2.Read())
        //                            {
        //                                videoAttachementCount = Convert.ToInt32(npgsqlDataReader2[0]);
        //                            }
        //                            npgsqlCon.Close();
        //                            if (videoAttachementCount > 0)
        //                            {
        //                                //update
        //                                string sqlQuery5 = string.Empty;
        //                                if (string.IsNullOrEmpty(item.VideoThumbnail))
        //                                {
        //                                    sqlQuery5 = "UPDATE public.#ODPM_VideoFile# SET #videofilename#='" + RemoveQuotes(item.FileName) + "',#videofilepath#='" + RemoveQuotes(item.FilePath) + "',#videofiletype#='" + item.FileType + "',#videoid#='" + request.videoID + "' WHERE mediatype='Attachment' and videocode ='" + request.videoCode + "'";
        //                                }
        //                                else
        //                                {
        //                                    sqlQuery5 = "UPDATE public.#ODPM_VideoFile# SET #videothumbnail#='" + RemoveQuotes(item.VideoThumbnail) + "',#videoid#='" + request.videoID + "' WHERE mediatype='Attachment' and videocode ='" + request.videoCode + "'";
        //                                }

        //                                sqlQuery5 = sqlQuery5.Replace('#', '"');
        //                                npgsqlCon.Open();
        //                                NpgsqlCommand cmd5 = new NpgsqlCommand(sqlQuery5, npgsqlCon);
        //                                NpgsqlDataReader dataReader5 = cmd5.ExecuteReader();
        //                                npgsqlCon.Close();
        //                            }
        //                            else
        //                            {
        //                                //insert
        //                                if (item.MediaType == "Attachment")
        //                                {
        //                                    string sqlQuery6 = "INSERT INTO public.#ODPM_VideoFile#(#videocode#,#videofilename#,#videofilepath#,#videofiletype#,#mediatype#,#videothumbnail#,#videoid#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.FileName) + "', '" + RemoveQuotes(item.FilePath) + "', '" + item.FileType + "', '" + item.MediaType + "', '" + item.VideoThumbnail + "', '" + request.videoID + "')";

        //                                    sqlQuery6 = sqlQuery6.Replace('#', '"');
        //                                    npgsqlCon.Open();
        //                                    NpgsqlCommand cmd6 = new NpgsqlCommand(sqlQuery6, npgsqlCon);
        //                                    NpgsqlDataReader dataReader6 = cmd6.ExecuteReader();
        //                                    npgsqlCon.Close();
        //                                }

        //                            }
        //                        }
        //                        else if (item.MediaType == "Transcript")
        //                        {
        //                            int videoTranscriptCount = 0;

        //                            string sqlQuery7 = "SELECT count(#videocode#) FROM public.#ODPM_VideoFile# WHERE mediatype='Transcript' and videocode ='" + request.videoCode + "'";

        //                            sqlQuery7 = sqlQuery7.Replace('#', '"');

        //                            npgsqlCon.Open();
        //                            NpgsqlCommand npgsqlCommand7 = new NpgsqlCommand(sqlQuery7, npgsqlCon);
        //                            NpgsqlDataReader npgsqlDataReader7 = npgsqlCommand7.ExecuteReader();
        //                            if (npgsqlDataReader7.Read())
        //                            {
        //                                videoTranscriptCount = Convert.ToInt32(npgsqlDataReader7[0]);
        //                            }
        //                            npgsqlCon.Close();
        //                            if (videoTranscriptCount > 0)
        //                            {
        //                                //update
        //                                string sqlQuery8 = string.Empty;
        //                                if (string.IsNullOrEmpty(item.VideoThumbnail))
        //                                {
        //                                    sqlQuery8 = "UPDATE public.#ODPM_VideoFile# SET #videofilename#='" + RemoveQuotes(item.FileName) + "',#videofilepath#='" + RemoveQuotes(item.FilePath) + "',#videofiletype#='" + item.FileType + "',#videoid#='" + request.videoID + "' WHERE mediatype='Transcript' and videocode ='" + request.videoCode + "'";
        //                                }
        //                                else
        //                                {
        //                                    sqlQuery8 = "UPDATE public.#ODPM_VideoFile# SET #videofilename#='" + RemoveQuotes(item.FileName) + "',#videofilepath#='" + RemoveQuotes(item.FilePath) + "',#videofiletype#='" + item.FileType + "',#videothumbnail#='" + RemoveQuotes(item.VideoThumbnail) + "',#videoid#='" + request.videoID + "' WHERE mediatype='Transcript' and videocode ='" + request.videoCode + "'";
        //                                }

        //                                sqlQuery8 = sqlQuery8.Replace('#', '"');
        //                                npgsqlCon.Open();
        //                                NpgsqlCommand cmd8 = new NpgsqlCommand(sqlQuery8, npgsqlCon);
        //                                NpgsqlDataReader dataReader8 = cmd8.ExecuteReader();
        //                                npgsqlCon.Close();
        //                            }
        //                            else
        //                            {
        //                                //insert
        //                                if (item.MediaType == "Transcript")
        //                                {
        //                                    string sqlQuery9 = "INSERT INTO public.#ODPM_VideoFile#(#videocode#,#videofilename#,#videofilepath#,#videofiletype#,#mediatype#,#videothumbnail#,#videoid#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.FileName) + "', '" + RemoveQuotes(item.FilePath) + "', '" + item.FileType + "', '" + item.MediaType + "', '" + item.VideoThumbnail + "', '" + request.videoID + "')";

        //                                    sqlQuery9 = sqlQuery9.Replace('#', '"');
        //                                    npgsqlCon.Open();
        //                                    NpgsqlCommand cmd9 = new NpgsqlCommand(sqlQuery9, npgsqlCon);
        //                                    NpgsqlDataReader dataReader9 = cmd9.ExecuteReader();
        //                                    npgsqlCon.Close();
        //                                }

        //                            }
        //                        }

        //                    }
        //                }
        //            }
        //            response.responseCode = 1;
        //            response.responseMessage = "Success";
        //        }
        //        catch (Exception ex)
        //        {
        //            _serviceconnect.LogConnect("Edit Video", "1024", ex.Message, "Exception");
        //            response.responseCode = 0;
        //            response.responseMessage = ex.Message;
        //        }
        //    }
        //    return response;

        //}
        //public ResponseClass EditVideoMaster(deleteVideoMasterRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable videomodel = new DataTable();

        //        string selectQuery = string.Empty;

        //        selectQuery = "select * from public.#ODPM_VideoMaster# vm where #DeletedFlag# =0 and #VideoCode# ='" + request.videoCode + "'";

        //        selectQuery = selectQuery.Replace('#', '"');

        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(videomodel);
        //        npgsql.Close();


        //        response.responseCode = 1;
        //        response.responseJSON = JsonConvert.SerializeObject(videomodel);
        //        response.responseJSONSecondary = JsonConvert.SerializeObject(VideoHighlightsByVideoCode(request.videoCode));
        //        response.responseJSONThird = JsonConvert.SerializeObject(videofilesByVideoCode(request.videoCode));

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("EditVideoMaster", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}
        public DataTable VideoHighlightsByVideoCode(string videocode)
        {
            ResponseClass response = new ResponseClass();

            DataTable videoHeightlightmodel = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                selectQuery = "select * from public.#ODPM_VideoHighlights# vm where #VideoCode# ='" + videocode + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(videoHeightlightmodel);
                npgsql.Close();
                return videoHeightlightmodel;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditVideoMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return videoHeightlightmodel;
        }
        public DataTable videofilesByVideoCode(string videocode)
        {
            ResponseClass response = new ResponseClass();

            DataTable videofiles = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                selectQuery = "select * from public.#ODPM_VideoFile# vm where #videocode# ='" + videocode + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(videofiles);
                npgsql.Close();
                return videofiles;

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("VideofilesMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return videofiles;
        }

        //public ResponseClass DeleteVideoMaster(deleteVideoMasterRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    string pgsqlConnection = appSettings.Value.DbConnection;
        //    NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
        //    try
        //    {
        //        //Delete Video data by video code

        //        string sqlQuery = "UPDATE public.#ODPM_VideoMaster# set #DeletedFlag# =1,#DeletedBy# ='" + request.deletedBy + "',#DeletedOn#=now(),#DeletedIPAddress# ='" + request.deletedIPAddress + "' where #VideoCode# ='" + request.videoCode + "'";

        //        sqlQuery = sqlQuery.Replace('#', '"');

        //        npgsqlCon.Open();

        //        NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

        //        NpgsqlDataReader dataReader = cmd.ExecuteReader();

        //        npgsqlCon.Close();

        //        response.responseCode = 1;
        //        response.responseMessage = "Success";
        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("Delete Video", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}
        //public ResponseClass ManageCourseMasterlist(manageCourseMasterrequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable trainingGroup = new DataTable();
        //        DateTime dtFrom = new DateTime();
        //        DateTime dtTo = new DateTime();
        //        string fromDate = string.Empty;
        //        string toDate = string.Empty;


        //        if (!string.IsNullOrEmpty(request.FromDate))
        //        {
        //            try
        //            {
        //                dtFrom = Convert.ToDateTime(request.FromDate);
        //                fromDate = Convert.ToDateTime(request.FromDate).ToString("yyyy-MM-dd");
        //            }
        //            catch (Exception ex)
        //            {
        //                _serviceconnect.LogConnect("ManageCourse", "1024", "From Date : " + ex.Message, "Exception");
        //                response.responseCode = 0;
        //                response.responseMessage = "Invalid FromDate";
        //                return response;
        //            }
        //        }
        //        if (!string.IsNullOrEmpty(request.ToDate))
        //        {
        //            try
        //            {
        //                dtTo = Convert.ToDateTime(request.ToDate);
        //                toDate = Convert.ToDateTime(request.ToDate).AddDays(1).ToString("yyyy-MM-dd");
        //            }
        //            catch (Exception ex)
        //            {
        //                _serviceconnect.LogConnect("ManageCourse", "1024", "To Date : " + ex.Message, "Exception");
        //                response.responseCode = 0;
        //                response.responseMessage = "Invalid ToDate";
        //                return response;
        //            }
        //        }

        //        if (dtFrom > dtTo)
        //        {
        //            response.responseCode = 0;
        //            response.responseMessage = "Invalid date range selected!";
        //            return response;
        //        }
        //        TimeSpan difference = dtTo - dtFrom;
        //        if (difference.TotalDays > 60)
        //        {
        //            response.responseCode = 0;
        //            response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
        //            return response;
        //        }


        //        string selectQuery = string.Empty;

        //        selectQuery = "select CM.#CourseID# as courseid, CM.#CourseCode# as coursecode,CM.#CourseName# as coursename,CM.#CourseCategory# as coursecategory,CM.#CourseType# as coursetype,CM.#CourseSize# as coursesize,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,CM.#CreatedBy# as insertedemployeeid,TO_CHAR(CM.#CreatedOn#, 'dd-Mon-yyyy') as createddate,EM.#Company_Name# as companyname from #ODPM_CourseMaster# CM inner join #EmployeeMaster# EM on CM.#CreatedBy# = EM.#EXTERNALDATAREFERENCE#";
        //        //selectQuery = selectQuery + " where (CM.#DeletedFlag#)=0 and (CM.#CreatedOn#::date) >= '" + fromDate + "' and (CM.#CreatedOn#::date) <= '" + toDate + "' and lower(CM.#CourseCode#) like =lower('%" + request.CourseCode + "%') and lower(CM.#CourseName#) like =lower('%" + request.CourseName + "%')";
        //        selectQuery = selectQuery + " where  (CM.#DeletedFlag#)=0 ";
        //        //and (CM.#CreatedOn#::date) >= '" + fromDate + "' and (CM.#CreatedOn#::date) <= '" + toDate + "'
        //        if (!string.IsNullOrEmpty(request.CourseCode))
        //        {
        //            selectQuery = selectQuery + " and lower(CM.#CourseCode#) like lower('%" + request.CourseCode + "%')";
        //        }
        //        if (!string.IsNullOrEmpty(request.CourseName))
        //        {
        //            selectQuery = selectQuery + " and lower(CM.#CourseName#) like lower('%" + request.CourseName + "%')";
        //        }
        //        if (!string.IsNullOrEmpty(request.CourseType) && request.CourseType != "Select")
        //        {
        //            selectQuery = selectQuery + " and lower(CM.#CourseType#)=lower('" + request.CourseType + "')";
        //        }
        //        if (!string.IsNullOrEmpty(request.FromDate) && !string.IsNullOrEmpty(request.ToDate))
        //        {
        //            selectQuery = selectQuery + " and (CM.#CreatedOn#::date) >= '" + fromDate + "' and (CM.#CreatedOn#::date) <= '" + toDate + "'";
        //        }
        //        //string companiestopass = string.Empty;

        //        //if (request.currentRole == "Program Manager")
        //        //{
        //        //    selectQuery = selectQuery + " and CM.#CreatedBy#='" + request.LoginEMPCode + "'";
        //        //}

        //        //if (!string.IsNullOrEmpty(request.CompanyCode))
        //        //{
        //        //    selectQuery = selectQuery + " and EM.#COMPANY_CODE#='" + request.CompanyCode + "'";
        //        //}


        //        selectQuery = selectQuery + "order by CM.#CreatedOn# desc";
        //        selectQuery = selectQuery.Replace('#', '"');

        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(trainingGroup);
        //        npgsql.Close();
        //        response.responseCode = 1;
        //        CommonFunction function = new CommonFunction();
        //        trainingGroup.Columns.Add("encryptedID");
        //        if (trainingGroup != null && trainingGroup.Rows.Count > 0)
        //        {
        //            foreach (DataRow item in trainingGroup.Rows)
        //            {
        //                item["encryptedID"] = function.Encrypt(Convert.ToString(item["courseid"]));
        //            }
        //        }
        //        response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}
        //public ResponseClass InsertCourseMaster(addEditCourseMasterrequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    try
        //    {
        //        DataTable dtEmployees = new DataTable();
        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        string selectQuery = string.Empty;

        //        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
        //        {
        //            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_insert_course_master
        //                                                                ( 
        //                                                                :pcoursename,
        //                                                                :pcoursecategory,
        //                                                                :pcoursetagging,
        //                                                                :pcoursetype,
        //                                                                :pcourseextlink,
        //                                                                :pinsertedby,
        //                                                                :pscormcourseurl,
        //                                                                :paction,
        //                                                                :pcourseid
        //                                                                )", npgsqlConnection))
        //            {
        //                cmd.CommandType = CommandType.Text; //
        //                if (!String.IsNullOrEmpty(request.CourseName))
        //                    cmd.Parameters.AddWithValue("pcoursename", DbType.String).Value = request.CourseName;
        //                else
        //                    cmd.Parameters.AddWithValue("pcoursename", DbType.String).Value = string.Empty;

        //                if (!String.IsNullOrEmpty(request.CourseCategory))
        //                    cmd.Parameters.AddWithValue("pcoursecategory", DbType.String).Value = request.CourseCategory;
        //                else
        //                    cmd.Parameters.AddWithValue("pcoursecategory", DbType.String).Value = string.Empty;

        //                //if (!String.IsNullOrEmpty(request.CourseSize))
        //                //    cmd.Parameters.AddWithValue("pcoursesize", DbType.String).Value = request.CourseSize;
        //                //else
        //                //    cmd.Parameters.AddWithValue("pcoursesize", DbType.String).Value = string.Empty;

        //                if (!String.IsNullOrEmpty(request.CourseTagging))
        //                    cmd.Parameters.AddWithValue("pcoursetagging", DbType.String).Value = request.CourseTagging;
        //                else
        //                    cmd.Parameters.AddWithValue("pcoursetagging", DbType.String).Value = string.Empty;

        //                if (!String.IsNullOrEmpty(request.CourseType))
        //                    cmd.Parameters.AddWithValue("pcoursetype", DbType.String).Value = request.CourseType;
        //                else
        //                    cmd.Parameters.AddWithValue("pcoursetype", DbType.String).Value = string.Empty;

        //                if (!String.IsNullOrEmpty(request.CourseExtLink))
        //                    cmd.Parameters.AddWithValue("pcourseextlink", DbType.String).Value = request.CourseExtLink;
        //                else
        //                    cmd.Parameters.AddWithValue("pcourseextlink", DbType.String).Value = string.Empty;

        //                if (!String.IsNullOrEmpty(request.CreatedUpdatedBy))
        //                    cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.CreatedUpdatedBy;
        //                else
        //                    cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

        //                if (!String.IsNullOrEmpty(request.ScromCourseURL))
        //                    cmd.Parameters.AddWithValue("pscormcourseurl", DbType.String).Value = request.ScromCourseURL;
        //                else
        //                    cmd.Parameters.AddWithValue("pscormcourseurl", DbType.String).Value = string.Empty;

        //                //cmd.Parameters.AddWithValue("pointsearned", DbType.Int32).Value = request.PointsEarned;

        //                if (!String.IsNullOrEmpty(request.Action))
        //                    cmd.Parameters.AddWithValue("paction", DbType.String).Value = request.Action;
        //                else
        //                    cmd.Parameters.AddWithValue("paction", DbType.String).Value = string.Empty;

        //                if (request.CourseID != 0)
        //                    cmd.Parameters.AddWithValue("pcourseid", DbType.Int32).Value = request.CourseID;
        //                else
        //                    cmd.Parameters.AddWithValue("pcourseid", DbType.Int32).Value = 0;

        //                npgsqlConnection.Open();

        //                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
        //                dataAdapter.Fill(dtEmployees);

        //                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
        //            }
        //        }

        //        response.responseCode = 1;
        //        response.responseMessage = "Success";
        //    }
        //    catch (Exception ex)
        //    {

        //        _serviceconnect.LogConnect("InsertCourseMaster", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;


        //}
        //public ResponseClass EditCourseMaster(addEditCourseMasterrequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable coursemodel = new DataTable();

        //        string selectQuery = string.Empty;

        //        selectQuery = "select * from public.#ODPM_CourseMaster# vm where #DeletedFlag# =0 and #CourseID# ='" + request.CourseID + "'";

        //        selectQuery = selectQuery.Replace('#', '"');

        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(coursemodel);
        //        npgsql.Close();
        //        response.responseCode = 1;
        //        response.responseJSON = JsonConvert.SerializeObject(coursemodel);

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("EditCourseMaster", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}

        //public ResponseClass DeleteCourseMaster(deleteCourseMasterRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    string pgsqlConnection = appSettings.Value.DbConnection;
        //    NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
        //    try
        //    {
        //        //Delete Course data by course id

        //        //string sqlQuery = "UPDATE public.#VideoMaster# set #DeletedFlag# =1,#DeletedBy# ='" + request.DeletedBy + "',#DeletedOn#= '" + request.DeletedOn + "',#DeletedIPAddress# ='" + request.deletedIPAddress + "' where #VideoCode# ='" + request.CourseID + "'";
        //        string sqlQuery = "UPDATE public.#ODPM_CourseMaster# set #DeletedFlag# =1,#deletedby# ='" + request.DeletedBy + "',#deletedon#=now() where #CourseID# ='" + request.CourseID + "'";

        //        sqlQuery = sqlQuery.Replace('#', '"');

        //        npgsqlCon.Open();

        //        NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

        //        NpgsqlDataReader dataReader = cmd.ExecuteReader();

        //        npgsqlCon.Close();

        //        response.responseCode = 1;
        //        response.responseMessage = "Success";
        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("Delete Course", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}
        //public ResponseClass GetProgramMasterList(ODPMProgramMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable dt = new DataTable();
        //        string selectQuery = string.Empty;

        //        selectQuery = selectQuery + "select #ProgramCode# as #ProgramCode#, #ProgramName# as #ProgramName#, #IsMultiDays#  as #IsMultiDays# , concat(em.#FIRSTNAME#,' ',em.#LASTNAME#, ' (',em.#EXTERNALDATAREFERENCE#,')') as #CreatedBy#,cast(TO_CHAR(pm.#CreatedOn#, 'dd-Mon-yy') as character varying) as #CreatedOn#, (select count(*) as #AssetsCount#  from public.#ODPM_ProgramAssets# as pa where pa.#ProgramCode# = pm.#ProgramCode# and pa.#isactive# = '1' ) from public.#ODPM_ProgramMaster# as Pm left join public.#EmployeeMaster# em on  pm.#CreatedBy# = em.#EXTERNALDATAREFERENCE# where pm.#DeletedFlag# = '0' ";

               
        //            selectQuery = selectQuery + " and Pm.#CreatedBy#='" + request.CreatedBy + "'";

        //        //and Pm.#CurrentRole#='" + request.CurrentRole + "'
               

        //        selectQuery = selectQuery + "  order by pm.#CreatedOn# desc , pm.#ProgramName#;";
        //        selectQuery = selectQuery.Replace('#', '"');
        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(dt);
        //        npgsql.Close();
        //        response.responseCode = 1;
        //        response.responseJSON = JsonConvert.SerializeObject(dt);

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("GetProgramMasterList", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}

        //public ResponseClass GetProgramLearningList(ODPMProgramAssetLearningMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable dt = new DataTable();
        //        string selectQuery = string.Empty;

        //        selectQuery = selectQuery + "select pm.#IsMultiDays# as #IsMultiple#, pm.#ProgramName# as #ProgramName#, pa.#DayNo# as #NodeName# , pm.#ProgramCode# as #ProgramCode# ,pa.#TID# as #AssetID# ,(select count(*) from #ODPM_ProgramAssetDetails# pad2 where pad2.#ProgramAssetID# = pa.#TID# and pad2.#isactive# = '1') as #LearningCount# from #ODPM_ProgramMaster# pm join #ODPM_ProgramAssets# as pa on pm.#ProgramCode# = pa.#ProgramCode# where pm.#DeletedFlag# = '0' and pa.#isactive# = '1' and pa.#ProgramCode# = '" + request.ProgramCode + "' order by pa.#DayNo# ;";

        //        selectQuery = selectQuery.Replace('#', '"');
        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(dt);
        //        npgsql.Close();
        //        response.responseCode = 1;
        //        response.responseJSON = JsonConvert.SerializeObject(dt);

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("GetProgramLearningList", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}
        //public ResponseClass InsertEditProgramMaster(ODPMProgramMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    string pgsqlConnection = appSettings.Value.DbConnection;
        //    NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
        //    if (request.action == "ADD")
        //    {
        //        try
        //        {
        //            if (!string.IsNullOrWhiteSpace(request.ProgramName))
        //            {
        //                string duplicateQuery = "select 'Yes'  from public.#ODPM_ProgramMaster# where #ProgramName# = '" + request.ProgramName + "' and #DeletedFlag# = '0' limit 1";
        //                string isDuplicate = string.Empty;
        //                duplicateQuery = duplicateQuery.Replace('#', '"');

        //                npgsqlCon.Open();

        //                NpgsqlCommand checkDuplicacyCmd = new NpgsqlCommand(duplicateQuery, npgsqlCon);

        //                NpgsqlDataReader npgsqlDataReaderDupcheck = checkDuplicacyCmd.ExecuteReader();

        //                if (npgsqlDataReaderDupcheck.Read())
        //                {
        //                    isDuplicate = npgsqlDataReaderDupcheck[0].ToString();
        //                }
        //                else
        //                {
        //                    isDuplicate = string.Empty;
        //                }

        //                npgsqlCon.Close();

        //                if (isDuplicate == "Yes")
        //                {
        //                    response.responseCode = 0;
        //                    response.responseMessage = "Program name already exists!";
        //                    return response;
        //                }
        //            }
        //            //TSequenceNo
        //            string programCodeNo = string.Empty;
        //            int codeCountNoCount = 0;
        //            string sqlQuery1 = "SELECT coalesce(max(#TSequenceNo#),0) as #TSequenceNo# FROM public.#ODPM_ProgramMaster#";

        //            sqlQuery1 = sqlQuery1.Replace('#', '"');

        //            npgsqlCon.Open();

        //            NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

        //            NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

        //            if (npgsqlDataReader1.Read())
        //            {
        //                programCodeNo = npgsqlDataReader1[0].ToString();
        //                codeCountNoCount = Convert.ToInt32(programCodeNo) + 1;
        //                request.ProgramCode = "PRG" + codeCountNoCount;
        //            }
        //            else
        //            {
        //                ++codeCountNoCount;
        //                request.ProgramCode = "PRG" + codeCountNoCount;
        //            }

        //            npgsqlCon.Close();

        //            //Insert Data ProgramMaster

        //            string sqlQuery = "INSERT INTO public.#ODPM_ProgramMaster#(#ProgramName#,#ProgramDescription#,#IsMultiDays#,#CreatedBy#,#CreatedOn#,#CreatedIPAddress#,#CurrentRole#,#ProgramCode#,#TSequenceNo#,#CurrentRoleCompany#)";

        //            sqlQuery = sqlQuery + "VALUES('" + request.ProgramName + "', '" + RemoveQuotes(request.ProgramDescription) + "', '" + request.IsMultiDays + "', '" + request.CreatedBy + "', now(), '" + request.CreatedIPAddress + "', '" + request.CurrentRole + "', '" + request.ProgramCode + "', '" + codeCountNoCount + "',";

        //            //if (request.CurrentRole == "Program Manager")
        //            //{
        //               sqlQuery = sqlQuery + "(select #COMPANY_CODE# from #EmployeeMaster# where #EXTERNALDATAREFERENCE#='" + request.CreatedBy + "')";
        //            //}
        //            //else if (request.CurrentRole == "Geo Admin")
        //            //{
        //            //    sqlQuery = sqlQuery + "(select STRING_AGG(#CompanyCode#,',') from #UserCompanyAssignment# where #EmployeeCode#='" + request.CreatedBy + "')";
        //            //}
        //            //else
        //            //{
        //            //    sqlQuery = sqlQuery + "NULL";
        //            //}
        //            sqlQuery = sqlQuery + ")";

        //            sqlQuery = sqlQuery.Replace('#', '"');

        //            npgsqlCon.Open();

        //            NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

        //            NpgsqlDataReader dataReader = cmd.ExecuteReader();

        //            npgsqlCon.Close();
        //            NpgsqlConnection.ClearPool(npgsqlCon);


        //            response.responseCode = 1;
        //            response.responseMessage = "Success";
        //        }
        //        catch (Exception ex)
        //        {
        //            _serviceconnect.LogConnect("Create Program", "1024", ex.Message, "Exception");
        //            response.responseCode = 0;
        //            response.responseMessage = ex.Message;
        //        }
        //    }

        //    if (request.action == "EDIT")
        //    {
        //        try
        //        {
        //            if (!string.IsNullOrWhiteSpace(request.ProgramName))
        //            {
        //                string duplicateQuery = "select 'Yes'  from public.#ODPM_ProgramMaster# where #ProgramName# = '" + request.ProgramName + "' and #ProgramCode# != '" + request.ProgramCode + "' and #DeletedFlag# = '0' limit 1";
        //                string isDuplicate = string.Empty;
        //                duplicateQuery = duplicateQuery.Replace('#', '"');

        //                npgsqlCon.Open();

        //                NpgsqlCommand checkDuplicacyCmd = new NpgsqlCommand(duplicateQuery, npgsqlCon);

        //                NpgsqlDataReader npgsqlDataReaderDupcheck = checkDuplicacyCmd.ExecuteReader();

        //                if (npgsqlDataReaderDupcheck.Read())
        //                {
        //                    isDuplicate = npgsqlDataReaderDupcheck[0].ToString();
        //                }
        //                else
        //                {
        //                    isDuplicate = string.Empty;
        //                }

        //                npgsqlCon.Close();

        //                if (isDuplicate == "Yes")
        //                {
        //                    response.responseCode = 0;
        //                    response.responseMessage = "Program name already exists!";
        //                    return response;
        //                }
        //            }


        //            //update Data ProgramMaster

        //            string sqlQuery = "update public.#ODPM_ProgramMaster# set #ProgramName# = '" + request.ProgramName + "' , #ProgramDescription# ='" + request.ProgramDescription + "' ,#IsMultiDays# = '" + request.IsMultiDays + "', #UpdatedBy# = '" + request.CreatedBy + "' , #UpdatedOn# = 'now()' , #UpdatedIPAddress# = '" + request.CreatedIPAddress + "' where #ProgramCode# = '" + request.ProgramCode + "';";


        //            sqlQuery = sqlQuery.Replace('#', '"');

        //            npgsqlCon.Open();

        //            NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

        //            NpgsqlDataReader dataReader = cmd.ExecuteReader();

        //            npgsqlCon.Close();
        //            NpgsqlConnection.ClearPool(npgsqlCon);


        //            response.responseCode = 1;
        //            response.responseMessage = "Success";
        //        }
        //        catch (Exception ex)
        //        {
        //            _serviceconnect.LogConnect("Update Program", "1024", ex.Message, "Exception");
        //            response.responseCode = 0;
        //            response.responseMessage = ex.Message;
        //        }
        //    }
        //    if (request.action == "DELETE")
        //    {
        //        try
        //        {

        //            //update -delete Data ProgramMaster

        //            string sqlQuery = "update public.#ODPM_ProgramMaster# set #DeletedFlag# = '1', #DeletedBy# = '" + request.DeletedBy + "' , #DeletedOn# = 'now()' , #DeletedIPAddress# = '" + request.DeletedIPAddress + "' where #ProgramCode# = '" + request.ProgramCode + "'; UPDATE #ODPM_ProgramAssets# SET #isactive# = '0' WHERE #ProgramCode# = '" + request.ProgramCode + "'; UPDATE #ODPM_ProgramAssetDetails# AS pasd SET #isactive# = '0' FROM #ODPM_ProgramMaster# AS pm JOIN #ODPM_ProgramAssets# AS pa ON pm.#ProgramCode# = pa.#ProgramCode# WHERE pm.#ProgramCode# = '" + request.ProgramCode + "' AND pa.#TID# = pasd.#ProgramAssetID#; ";


        //            sqlQuery = sqlQuery.Replace('#', '"');

        //            npgsqlCon.Open();

        //            NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

        //            NpgsqlDataReader dataReader = cmd.ExecuteReader();

        //            npgsqlCon.Close();
        //            NpgsqlConnection.ClearPool(npgsqlCon);


        //            response.responseCode = 1;
        //            response.responseMessage = "Success";
        //        }
        //        catch (Exception ex)
        //        {
        //            _serviceconnect.LogConnect("delete Program", "1024", ex.Message, "Exception");
        //            response.responseCode = 0;
        //            response.responseMessage = ex.Message;
        //        }
        //    }

        //    return response;
        //}
        //public ResponseClass GetProgramMasterDataByProgramCode(ODPMProgramMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable dt = new DataTable();

        //        string selectQuery = string.Empty;

        //        selectQuery = "select #ProgramCode# as #ProgramCode#, #ProgramName# as #ProgramName#, #IsMultiDays#  as #IsMultiDays# ,#ProgramDescription#  as #ProgramDescription#,  (select case when count(*)>0 then 'Block' else 'Edit' end as #EditAccess#  from #ODPM_ProgramAssets# pa where pa.#ProgramCode#=pm.#ProgramCode#) from public.#ODPM_ProgramMaster# as Pm where pm.#ProgramCode# = '" + request.ProgramCode + "';";

        //        selectQuery = selectQuery.Replace('#', '"');

        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(dt);
        //        npgsql.Close();
        //        response.responseCode = 1;
        //        response.responseJSON = JsonConvert.SerializeObject(dt);

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("GetEventProcessDetail", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}


        public ResponseClass GetProgramLearningListByPRcodeAndAssetID(ODPMProgramAssetDetailsLearningMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = selectQuery + "select pasd.#TID# as assetdetailid,pm.#IsMultiDays# as #IsMultiple#, pm.#ProgramName#  as #ProgramName# , pa.#DayNo# as #NodeName# , pm.#ProgramCode# as #ProgramCode# ,pa.#TID# as #AssetID#, pasd.#TID# as #AssetDetailsID#,pasd.#AssetType# as #LearningType#, pasd.#AssetName# as #LearningName# from #ODPM_ProgramMaster# pm join #ODPM_ProgramAssets# as pa on pm.#ProgramCode# = pa.#ProgramCode# join #ODPM_ProgramAssetDetails# as pasd on pa.#TID# = pasd.#ProgramAssetID# where pm.#DeletedFlag# = '0' and pa.#isactive# = '1' and pasd.#isactive# = '1'  and pa.#ProgramCode# = '" + request.ProgramCode + "' and pa.#TID# = '" + request.AssetID + "'; ";

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProgramLearningList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }











        public ResponseClass Gettninumbergeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_gettninumbergeo(:p_tninumber)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass Gettninumberdepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_gettninumberdepartment(:p_tninumber)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass Gettninumbergrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_gettninumbergrade(:p_tninumber)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass GettninumberprogramandTraining(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_tninumberprogramandTraining(:p_tninumber)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass Gettninumbercity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_tninumbercity(:p_tninumber)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.tninumber))
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = oDPMinput.tninumber;
                    else
                        cmd.Parameters.AddWithValue("p_tninumber", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }




        public ResponseClass GetAllocateAssetDropDownDataByAssetID(ODPMinsertEditProgramLearningRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = selectQuery + "select #AssetCode# as #ObjectCode# , #AssetName#  as #ObjectType# from #ODPM_ProgramAssetDetails# where #AssetType# = '" + request.AssetType + "' and #ProgramAssetID# = '" + request.AssetID + "' and #isactive# = '1'";

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProgramLearningList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }


        public ResponseClass getODPMAllocateEntityDropDownData(getAllocateEntityDropDownDataDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                assessmentlistresponseData ASResponse = new assessmentlistresponseData();
                string selectQuery = string.Empty;
                if (request.objectType == "Video")
                {
                    selectQuery = "select A.#VideoCode# as objectcode,A.#VideoTitle# as objectname  ";
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
                    }
                    else
                    {
                        selectQuery = selectQuery + " ,0 as assignedContent";

                    }
                    selectQuery = selectQuery + " from #ODPM_VideoMaster# A  inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        selectQuery = selectQuery + " left join #EventContent# B on B.#ContentCode#=A.#VideoCode# and B.#EventCode#='" + request.objectCode + "' ";
                    }
                    selectQuery = selectQuery + " where A.#DeletedFlag#=0 ";

                    string companiestopass = string.Empty;


                    //if (request.currentRole == "Program Manager")
                    //{
                        // selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";

                        selectQuery = selectQuery + " and (A.#InsertedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                       // selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                    //}
                    //else if (request.currentRole == "Geo Admin")
                    //{
                    //    DataTable dtCompanies = new DataTable();
                    //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    //{
                    //    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    //    {
                    //    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    //    }

                    //    //    companiestopass = companiestopass.TrimEnd(',');

                    //    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //    //}

                    //    selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

                    //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    {
                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }

                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }
                    //    }


                    //    selectQuery = selectQuery + " )";
                    //}

                    selectQuery = selectQuery + "  order by A.#InsertedDateTime# desc";

                    selectQuery = selectQuery.Replace('#', '"');
                    string pgsqlConnection = appSettings.Value.DbConnection;
                    NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                    npgsql.Open();

                    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    dataAdapter.Fill(trainingGroup);
                    npgsql.Close();

                    // response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

                }
                else if (request.objectType == "Assessment")
                {
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        // first get existing content
                        selectQuery = "select #ContentCode# from #EventContent# where #EventCode#='" + request.objectCode + "'";
                        selectQuery = selectQuery.Replace('#', '"');
                        string pgsqlConnection = appSettings.Value.DbConnection;
                        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                        npgsql.Open();

                        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                        dataAdapter.Fill(trainingGroup);
                        npgsql.Close();
                    }


                    DataTable dtAssessment = new DataTable();

                    dtAssessment.Columns.Add("objectcode");
                    dtAssessment.Columns.Add("objectname");
                    dtAssessment.Columns.Add("assignedcontent");

                    //request.EmpCode = string.Empty ;
                    string companycode = string.Empty;

                    //if (request.currentRole == "Geo Admin")
                    //{
                    //    DataTable dtCompanies = new DataTable();
                    //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    {
                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            companycode = companycode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                    //        }

                    //        companycode = companycode.TrimEnd(',');

                    //        //selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companycode + ")";

                    //    }
                    //}

                    string assessmentResponse = _serviceconnect.getAssessment(request.Geo, request.EmpCode, request.currentRole, companycode);
                    ASResponse = JsonConvert.DeserializeObject<assessmentlistresponseData>(assessmentResponse);
                    if (ASResponse.Data.Data != null && ASResponse.Data.Data.Count > 0 && ASResponse.ResponseCode == "1")
                    {

                        foreach (var item in ASResponse.Data.Data)
                        {
                            int assign = 0;
                            foreach (DataRow dc in trainingGroup.Rows)
                            {
                                if (Convert.ToString(dc["ContentCode"]) == Convert.ToString(item.AssessmentID))
                                {
                                    assign = 1;
                                }
                            }
                            dtAssessment.Rows.Add(item.AssessmentID, item.AssessmentName, assign);
                        }
                    }
                    if (dtAssessment != null && dtAssessment.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtAssessment.Rows)
                        {
                            item["objectname"] = Convert.ToString(item["objectname"]).Replace(",", " ");
                        }
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtAssessment);
                    response.responseCode = 1;
                    response.responseMessage = "SUCCESS";
                    return response;
                }
                else if (request.objectType == "Course")
                {
                    selectQuery = "select A.#CourseCode# as objectcode,concat(A.#CourseName#,'(',A.#CourseType#,')') as objectname  ";
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
                    }
                    else
                    {
                        selectQuery = selectQuery + " ,0 as assignedContent";

                    }
                    selectQuery = selectQuery + " from #ODPM_CourseMaster# A inner join #EmployeeMaster# EM on A.#CreatedBy# = EM.#EXTERNALDATAREFERENCE# ";
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        selectQuery = selectQuery + " left join #EventContent# B on B.#ContentCode#=A.#CourseCode# and B.#EventCode#='" + request.objectCode + "' ";
                    }
                    selectQuery = selectQuery + " where A.#DeletedFlag#=0 and (coalesce(A.#ScormCourseURL#,'')!='' or coalesce(A.#CourseExtLink#,'')!='')  ";
                    string companiestopass = string.Empty;
                    //if (request.currentRole == "Program Manager")
                    //{
                        // selectQuery = selectQuery + " and A.#CreatedBy#='" + request.LoginEMPCode + "'";

                        selectQuery = selectQuery + " and (A.#CreatedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                        selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                    //}
                    //else if (request.currentRole == "Geo Admin")
                    //{
                    //    DataTable dtCompanies = new DataTable();
                    //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    //{
                    //    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    //    {
                    //    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    //    }

                    //    //    companiestopass = companiestopass.TrimEnd(',');

                    //    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //    //}

                    //    selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

                    //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    {
                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }

                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }
                    //    }

                    //    //selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' ) ";

                    //    //selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + request.UserCompany + "%' ) ";

                    //    selectQuery = selectQuery + " )";
                    //}
                    selectQuery = selectQuery + " and A.#IsPartOfSeed#=0  order by A.#CreatedOn# desc";

                    selectQuery = selectQuery.Replace('#', '"');
                    string pgsqlConnection = appSettings.Value.DbConnection;
                    NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                    npgsql.Open();

                    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    dataAdapter.Fill(trainingGroup);
                    npgsql.Close();

                    //response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
                }
                else if (request.objectType == "Survey")
                {
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        // first get existing content
                        selectQuery = "select #ContentCode# from #EventContent# where #EventCode#='" + request.objectCode + "'";
                        selectQuery = selectQuery.Replace('#', '"');
                        string pgsqlConnection = appSettings.Value.DbConnection;
                        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                        npgsql.Open();

                        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                        dataAdapter.Fill(trainingGroup);
                        npgsql.Close();
                    }


                    DataTable dtAssessment = new DataTable();

                    dtAssessment.Columns.Add("objectcode");
                    dtAssessment.Columns.Add("objectname");
                    dtAssessment.Columns.Add("assignedcontent");
                    TLDEnvelope responseData = new TLDEnvelope();
                    string companycode = string.Empty;
                    //if (request.currentRole == "Geo Admin")
                    //{
                    //    DataTable dtCompanies = new DataTable();
                    //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    {
                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            companycode = companycode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                    //        }

                    //        companycode = companycode.TrimEnd(',');

                    //        //selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companycode + ")";

                    //    }
                    //}
                    // request.EmpCode = string.Empty;
                    string assessmentResponse = _serviceconnect.getSurvey(request.Geo, request.EmpCode, request.currentRole, companycode);
                    responseData = JsonConvert.DeserializeObject<TLDEnvelope>(assessmentResponse);
                    if (responseData.Status == true && responseData.TotalRecords > 0 && responseData.Data != null)
                    {

                        foreach (var item in responseData.Data.Data)
                        {
                            int assign = 0;
                            foreach (DataRow dc in trainingGroup.Rows)
                            {
                                if (Convert.ToString(dc["ContentCode"]) == Convert.ToString(item.TemplateId))
                                {
                                    assign = 1;
                                }
                            }
                            dtAssessment.Rows.Add(item.TemplateId, item.TemplateName, assign);
                        }
                    }
                    if (dtAssessment != null && dtAssessment.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtAssessment.Rows)
                        {
                            item["objectname"] = Convert.ToString(item["objectname"]).Replace(",", " ");
                        }
                    }

                    response.responseJSON = JsonConvert.SerializeObject(dtAssessment);

                    response.responseCode = 1;
                    response.responseMessage = "SUCCESS";
                    return response;
                }
                else if (request.objectType == "Program")
                {
                    selectQuery = "select A.#ProgramCode# as objectcode,A.#ProgramName# as objectname,A.#IsMultiDays# as ismultidays,coalesce(ProgramDay.totaldays,0) programdays,coalesce(ProgramAsset.assettype,0) as hasvideo,coalesce(ProgramAssetAssessment.assettype,0) as hasassessmentsurvey  ";
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
                    }
                    else

                    {
                        selectQuery = selectQuery + " ,0 as assignedContent";

                    }
                    selectQuery = selectQuery + " from #ODPM_ProgramMaster# A left join ( select #ProgramCode#,count(distinct #DayNo#) as totaldays from #ODPM_ProgramAssets# where #isactive#='1' group by #ProgramCode#  ) ProgramDay on ProgramDay.#ProgramCode#=A.#ProgramCode#    inner join #EmployeeMaster# EM on A.#CreatedBy# = EM.#EXTERNALDATAREFERENCE# ";
                    selectQuery = selectQuery + " left join ( ";

                    selectQuery = selectQuery + " select PA.#ProgramCode#,count(PAD.#AssetType#) as assettype ";

                    selectQuery = selectQuery + "  from #ODPM_ProgramAssets# PA ";
                    selectQuery = selectQuery + "  inner join #ODPM_ProgramAssetDetails# PAD on PA.#TID# = PAD.#ProgramAssetID# ";

                    selectQuery = selectQuery + "  where PA.#isactive#='1' and PAD.#isactive# = '1' and PAD.#AssetType# = 'Video' ";

                    selectQuery = selectQuery + "  group by PA.#ProgramCode# ";
                    selectQuery = selectQuery + " ) ProgramAsset on ProgramAsset.#ProgramCode# = A.#ProgramCode#";

                    selectQuery = selectQuery + " left join ( ";

                    selectQuery = selectQuery + " select PA.#ProgramCode#,count(PAD.#AssetType#) as assettype ";

                    selectQuery = selectQuery + "  from #ODPM_ProgramAssets# PA ";
                    selectQuery = selectQuery + "  inner join #ODPM_ProgramAssetDetails# PAD on PA.#TID# = PAD.#ProgramAssetID# ";

                    selectQuery = selectQuery + "  where PAD.#isactive# = '1' and PAD.#AssetType# in  ('Assessment','Survey') ";

                    selectQuery = selectQuery + "  group by PA.#ProgramCode# ";
                    selectQuery = selectQuery + " ) ProgramAssetAssessment on ProgramAssetAssessment.#ProgramCode# = A.#ProgramCode#";

                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        selectQuery = selectQuery + " left join #ODPM_EventContent# B on B.#ContentCode#=A.#ProgramCode# and B.#EventCode#='" + request.objectCode + "' ";
                    }
                    selectQuery = selectQuery + " where A.#DeletedFlag#=0 and coalesce(ProgramDay.totaldays,0)>0 ";

                    string companiestopass = string.Empty;


                    //if (request.currentRole == "Program Manager")
                    //{
                        // selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";

                        selectQuery = selectQuery + " and (A.#CreatedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                    //    selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                    //}
                    //else if (request.currentRole == "Geo Admin")
                    //{
                    //    DataTable dtCompanies = new DataTable();
                    //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    //{
                    //    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    //    {
                    //    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    //    }

                    //    //    companiestopass = companiestopass.TrimEnd(',');

                    //    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //    //}

                    //    selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

                    //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    {
                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }

                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }
                    //    }


                    //    selectQuery = selectQuery + " )";
                    //}

                    selectQuery = selectQuery + "  order by A.#CreatedOn# desc";

                    selectQuery = selectQuery.Replace('#', '"');
                    string pgsqlConnection = appSettings.Value.DbConnection;
                    NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                    npgsql.Open();

                    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    dataAdapter.Fill(trainingGroup);
                    npgsql.Close();



                }
                if (trainingGroup != null && trainingGroup.Rows.Count > 0)
                {
                    foreach (DataRow item in trainingGroup.Rows)
                    {
                        item["objectname"] = Convert.ToString(item["objectname"]).Replace(",", " ");
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getAllocateEntityDropDownData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass getParticipantdiscrianduserinstru(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_Participantdiscrianduserinstru(:p_programcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.programcode))
                        cmd.Parameters.AddWithValue("p_programcode", DbType.String).Value = oDPMinput.programcode;
                    else
                        cmd.Parameters.AddWithValue("p_programcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
        public ResponseClass getParticipanttrainingdetails(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_getParticipanttrainingdetails(:p_programcode,:p_workshop,:p_loggedinempcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text;
                    if (!String.IsNullOrEmpty(oDPMinput.programcode))
                        cmd.Parameters.AddWithValue("p_programcode", DbType.String).Value = oDPMinput.programcode;
                    else
                        cmd.Parameters.AddWithValue("p_programcode", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(oDPMinput.workshop))
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = oDPMinput.workshop;
                    else
                        cmd.Parameters.AddWithValue("p_workshop", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = DBNull.Value;
                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    
                    dataAdapter.Fill(dtEmployees);
                    DataView view = new DataView(dtEmployees);
                    DataView viewpreorpostattd = new DataView(dtEmployees);

                    var valisactive = 0;
                    foreach (DataRow dr1 in dtEmployees.Rows)
                    {
                        if(dr1["acknowledgedstatus"].ToString() == "0" && dr1["isactive"].ToString() == "0" && valisactive == 0)
                        {
                            valisactive = 1;
                            dr1["isactive"] = 1;
                        }

                    }



                        DataTable distinctValues = view.ToTable(true, "trainingname", "trainingid");
                       DataTable preorpostattd = viewpreorpostattd.ToTable(true, "preorpostattd");

                    DataSet ds = new DataSet();
                    ds.Tables.Add(distinctValues);
                    ds.Tables.Add(dtEmployees);

                    foreach (DataRow dr in preorpostattd.Rows)
                    {
                        if (dr["preorpostattd"].ToString() == "Pre")
                        {
                            DataTable preTable = dtEmployees.AsEnumerable()
                             .Where(r => r.Field<string>("preorpostattd") == "Pre")
                             .CopyToDataTable();
                            ds.Tables.Add(preTable);
                        }
                       
                    }
                    foreach (DataRow dr in preorpostattd.Rows)
                    {
                        if (dr["preorpostattd"].ToString() == "Post")
                        {
                            DataTable postTable = dtEmployees.AsEnumerable()
                            .Where(r => r.Field<string>("preorpostattd") == "Post")
                            .CopyToDataTable();
                            ds.Tables.Add(postTable);
                        }
                        
                    }

                   
                    
                   

                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(ds);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }


        public ResponseClass getODPMMarkGeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_schgeo(:p_loggedinempcode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.loggedinempcode))
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = oDPMinput.loggedinempcode;
                    else
                        cmd.Parameters.AddWithValue("p_loggedinempcode", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;

        }

        public ResponseClass getODPMMarkProgramManager(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;


            List<string> p_companycode = new List<string>();
            if (!String.IsNullOrEmpty(oDPMinput.companycode))
            {
                p_companycode = oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }
            else
            {
                oDPMinput.companycode = "";
                oDPMinput.companycode.Replace(" ", "").Split(",").ToList();
            }

            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_programmanager (:p_companycode)
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(oDPMinput.companycode))
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;
                    else
                        cmd.Parameters.AddWithValue("p_companycode", DbType.Object).Value = p_companycode;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }

        public ResponseClass getODPMPMMarkworkshop(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM odpm_fn_get_360workshop()
                                                                   ", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    //if (!String.IsNullOrEmpty(request.StateName))
                    //    cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = request.StateName;
                    //else
                    //    cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = DBNull.Value;


                    npgsqlConnection.Open();
                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
            }

            return response;
        }
    }
}
