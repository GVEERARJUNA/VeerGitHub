﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.EmailManagement;
using TLDCBAL.ProgramManager;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCBAL.UserManagement;
using TLDCDAL;

namespace TLDCBAL.Schedulers
{
    public class SchedulerBL : ISchedulerBL
    {
        private readonly IServiceConnect _serviceconnect;
        private readonly IEmailMGTBL _emailMGT;

        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;
        private IQualtricsDataBL _qualtricsBL;

        DBConnection GamifificationdBConnection;
        DBConnection AssessmentdBConnection;

        DBConnection MobileTokendBConnection;

        IFireBaseAPICallBL _apiCall;

        private IUserManagementBL _usermanagementBL;

        public SchedulerBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IEmailMGTBL emailMGT, IQualtricsDataBL qualtricsBL, IFireBaseAPICallBL apiCall, IUserManagementBL usermanagementBL)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.TLDCSchedulerDbConnection);
            _serviceconnect = serviceconnect;
            _emailMGT = emailMGT;
            _qualtricsBL = qualtricsBL;

            GamifificationdBConnection = new DBConnection(appSettings.Value.GamingDBConnection);
            AssessmentdBConnection = new DBConnection(appSettings.Value.AssessmentDBConnection);
            MobileTokendBConnection = new DBConnection(appSettings.Value.MobileTokenDbConnection);
            _apiCall = apiCall;
            _usermanagementBL = usermanagementBL;
        }


        // to allocate ISAP to new joinee
        public ResponseClass newJoiningAllocation()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = getNewJoineeData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("ISAPNewJoinee", "");


                        _serviceconnect.LogConnect("newJoiningAllocation", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));
                                string sqlQuery = "call prc_allocate_module('" + Convert.ToString(item["EmployeeCode"]) + "','WRNO400','" + Convert.ToDateTime(item["JoinDate"]).ToString("yyyy-MM-dd") + "','" + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + "','NewJoinee')";
                                npgCon.Open();
                                // Define a command to call  procedure
                                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
                                NpgsqlDataReader rdr = cmd.ExecuteReader();
                                npgCon.Close();

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    MailDetails mailDetails = new MailDetails();
                                    mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    // set to list
                                    List<ToList> lstToList = new List<ToList>();
                                    ToList to = new ToList();
                                    to.EmailAddress = Convert.ToString(item["EmailAddress"]);
                                    lstToList.Add(to);
                                    mailDetails.ToList = lstToList;

                                    List<BCCList> lstBCC = new List<BCCList>();

                                    if (!string.IsNullOrEmpty(Convert.ToString(item["BCCList"])))
                                    {
                                        string[] bccList = Convert.ToString(item["BCCList"]).Split(",");

                                        foreach (string email in bccList)
                                        {
                                            BCCList bcc = new BCCList();
                                            bcc.EmailAddress = email.ToString();
                                            lstBCC.Add(bcc);
                                        }

                                        mailDetails.bCCLists = lstBCC;
                                    }

                                    mailDetails.Sender = appSettings.Value.Sender;
                                    mailDetails.SenderName = appSettings.Value.SenderName;
                                    mailDetails.Subject = emailEntity[0].EmailSubject;
                                    string emailBody = string.Empty;
                                    emailBody = emailEntity[0].EmailBody;
                                    emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["EmpName"]));
                                    emailBody = emailBody.Replace("@StartDate@", Convert.ToDateTime(item["JoinDate"]).ToString("dd MMM yyyy"));
                                    emailBody = emailBody.Replace("@EndDate@", Convert.ToDateTime(item["ExpiryDate"]).ToString("dd MMM yyyy"));
                                    emailBody = emailBody.Replace("@CC", ccEmail);
                                    //string emailBody = "Dear " + Convert.ToString(item["EmpName"]) + "<br/><br/> iSAP assessment for you process commenced on " + Convert.ToDateTime(item["JoinDate"]).ToString("yyyy-MM-dd") + " and will remain open until " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + ".You may read the iSAP modules at your convenience and complete the assessment by " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + ". Kindly note the assessment will not be available after " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + " and your next assessment will be due next year";
                                    mailDetails.MailActualBody = emailBody;
                                    string outputResult = string.Empty;
                                    try
                                    {
                                        outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                        _serviceconnect.LogConnect("newJoiningAllocation", "1024", emailBody, "Information");
                                    }
                                    catch (Exception ex)
                                    {

                                        _serviceconnect.LogConnect("newJoiningAllocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    }
                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("newJoiningAllocation", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("newJoiningAllocation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }


        // to allocate ISAP by calender
        public ResponseClass ISAPcalenderAllocation()
        {

            ResponseClass response = new ResponseClass();
            try
            {
                DataSet dsEmployee = new DataSet();
                // get calender data from postgress dB
                DataTable dtcalenderResult = new DataTable();
                dtcalenderResult = getCalenderConfig();
                if (dtcalenderResult != null && dtcalenderResult.Rows.Count > 0)
                {
                    foreach (DataRow item in dtcalenderResult.Rows)
                    {
                        int allocateStatus = 0;
                        int emailStatus = 0;
                        string companyCode = string.Empty;
                        string departmentCode = string.Empty;
                        string subProcess = string.Empty;
                        string departmentname = string.Empty;
                        string ccEmail = string.Empty;

                        int checkAllocateStatus = 0;
                        int checkEmailStatus = 0;

                        DateTime startDate = DateTime.Now;
                        DateTime expiryDate = DateTime.Now;
                        int moduleconfigID = 0;
                        // now get all emplyess of that department
                        companyCode = Convert.ToString(item["CompanyCode"]);
                        departmentCode = Convert.ToString(item["DepartmentCode"]);
                        //subProcess = Convert.ToString(item["SubProcessCode"]);
                        moduleconfigID = Convert.ToInt32(item["ModuleYearlyConfigID"]);
                        startDate = Convert.ToDateTime(item["AssignedDate"]);
                        expiryDate = Convert.ToDateTime(item["ExpiryDate"]);
                        departmentname = Convert.ToString(item["departmentname"]);
                        ccEmail = Convert.ToString(item["ccemail"]);
                        checkAllocateStatus = Convert.ToInt32(item["allocationstatus"]);
                        checkEmailStatus = Convert.ToInt32(item["emailstatus"]);

                        if (checkAllocateStatus == 0)  // if allocates status =0 
                        {
                            // first allocate ISAP
                            string excludeEmployeeList = string.Empty;
                            DataTable dtExcludeemployees = new DataTable();
                            dtExcludeemployees = getExcludeemployees(companyCode, departmentCode, subProcess);

                            if (dtExcludeemployees != null && dtExcludeemployees.Rows.Count > 0)
                            {
                                NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
                                foreach (DataRow dr in dtExcludeemployees.Rows)
                                {

                                    try
                                    {


                                        string sqlQuery = "call prc_allocate_module_calender('" + Convert.ToString(dr["employeecode"]) + "','WRNO400','" + startDate.ToString("yyyy-MM-dd") + "','" + expiryDate.ToString("yyyy-MM-dd") + "','Calender','" + moduleconfigID + "')";
                                        npgCon.Open();
                                        // Define a command to call  procedure
                                        NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
                                        NpgsqlDataReader rdr = cmd.ExecuteReader();
                                        npgCon.Close();
                                        //return response;
                                    }
                                    catch (Exception ex)
                                    {
                                        _serviceconnect.LogConnect("ISAPcalenderAllocation", "1024", ex.Message, "Exception");
                                        response.responseCode = 0;
                                        response.responseMessage = ex.Message;
                                    }
                                    allocateStatus = 1;
                                }
                                // allocateStatus = 1;
                            }

                            if (allocateStatus == 1)
                            {
                                string sb = string.Empty;
                                NpgsqlConnection npgConupdate = new NpgsqlConnection(appSettings.Value.DbConnection);
                                string updateQuery = string.Empty;
                                updateQuery = "update #ModuleYearlyCalenderConfig# set #AllocationStatus#=" + allocateStatus + ",#EmailStatus#=" + emailStatus + " where  #ModuleYearlyConfigID#=" + moduleconfigID + ";";
                                updateQuery = updateQuery.Replace('#', '"');
                                // sb = sb + updateQuery;

                                if (updateQuery.Length > 0)
                                {

                                    npgConupdate.Open();

                                    string sqlQuery = updateQuery;

                                    // Define a command to call  procedure
                                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgConupdate);
                                    NpgsqlDataReader rdr = cmd.ExecuteReader();
                                    npgConupdate.Close();
                                }
                            }
                        }


                        if (checkEmailStatus == 0)  // check email status
                        {
                            DataTable dtEmailList = new DataTable();
                            dtEmailList = getcalenderallocationemail(moduleconfigID.ToString(), departmentCode);
                            if (dtEmailList.Rows.Count > 0)
                            {
                                List<EmailEntity> emailEntity = new List<EmailEntity>();
                                // get email template
                                emailEntity = _emailMGT.getEmailTemplate("ISAPMonthLaunch", "");

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    MailDetails mailDetails = new MailDetails();
                                    mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    mailDetails.Sender = appSettings.Value.Sender;
                                    mailDetails.SenderName = appSettings.Value.SenderName;
                                    mailDetails.Subject = emailEntity[0].EmailSubject;
                                    mailDetails.Subject = mailDetails.Subject.Replace("@departmentname@", departmentname);
                                    string emailBody = string.Empty;
                                    emailBody = emailEntity[0].EmailBody;
                                    emailBody = emailBody.Replace("@departmentname@", departmentname);
                                    emailBody = emailBody.Replace("@StartDate@", startDate.ToString("dd MMM yyyy"));
                                    emailBody = emailBody.Replace("@EndDate@", expiryDate.ToString("dd MMM yyyy"));
                                    emailBody = emailBody.Replace("@CC", ccEmail);

                                    mailDetails.MailActualBody = emailBody;

                                    string toemail = Convert.ToString(dtEmailList.Rows[0]["email_address"]);

                                    List<BCCList> lstBCC = new List<BCCList>();

                                    if (!string.IsNullOrEmpty(Convert.ToString(dtEmailList.Rows[0]["bcclist"])))
                                    {
                                        string[] bccList = Convert.ToString(dtEmailList.Rows[0]["bcclist"]).Split(",");

                                        foreach (string email in bccList)
                                        {
                                            BCCList bcc = new BCCList();
                                            bcc.EmailAddress = email.ToString();
                                            lstBCC.Add(bcc);
                                        }

                                        mailDetails.bCCLists = lstBCC;
                                    }

                                    //string toemail = "deepak.rohilla@teamhgs.com,shamsuddin.ansari@teamhgs.com,Aravind.Anbalagan@teamhgs.com";
                                    List<ToList> lstToList = new List<ToList>();
                                    // set to list
                                    if (!string.IsNullOrEmpty(toemail))
                                    {
                                        toemail = toemail.Replace("{", "");
                                        toemail = toemail.Replace("}", "");
                                        string[] toList = toemail.Split(",");

                                        foreach (string email in toList)
                                        {
                                            mailDetails.ToList = new List<ToList>();
                                            lstToList = new List<ToList>();

                                            ToList bcc = new ToList();
                                            bcc.EmailAddress = email.ToString();
                                            lstToList.Add(bcc);
                                            mailDetails.ToList = lstToList;
                                            try
                                            {
                                                string TooutputResult = string.Empty;
                                                TooutputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                                try
                                                {
                                                    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(dtEmailList.Rows[0]["email_address"]), "", moduleconfigID.ToString(), "3", TooutputResult);
                                                }
                                                catch (Exception ex)
                                                {

                                                    //_serviceconnect.LogConnect("calenderallocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                                }


                                                //  _serviceconnect.LogConnect("calenderallocation", "1024", emailBody, "Information");

                                            }
                                            catch (Exception ex)
                                            {

                                                _serviceconnect.LogConnect("calenderallocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                            }
                                        }

                                        //mailDetails.ToList = lstToList;
                                    }



                                    if (!string.IsNullOrEmpty(Convert.ToString(dtEmailList.Rows[0]["ccToEmail"])))
                                    {
                                        List<ToList> lstToCCList = new List<ToList>();
                                        mailDetails.ToList = new List<ToList>();
                                        lstToList = new List<ToList>();

                                        ToList bcc = new ToList();
                                        bcc.EmailAddress = Convert.ToString(dtEmailList.Rows[0]["ccToEmail"]);
                                        lstToList.Add(bcc);
                                        mailDetails.ToList = lstToList;

                                        //mailDetails.CcList = Convert.ToString(dtEmailList.Rows[0]["ccToEmail"]);

                                        string outputResult = string.Empty;
                                        try
                                        {
                                            outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                            //try
                                            //{
                                            //    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(dtEmailList.Rows[0]["email_address"]), "", moduleconfigID.ToString(), "3", outputResult);
                                            //}
                                            //catch (Exception ex)
                                            //{

                                            //    _serviceconnect.LogConnect("calenderallocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                            //}

                                            emailStatus = 1;
                                            // _serviceconnect.LogConnect("calenderallocation", "1024", emailBody, "Information");

                                        }
                                        catch (Exception ex)
                                        {

                                            _serviceconnect.LogConnect("calenderallocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                        }
                                    }


                                    ////string emailBody = "Dear " + Convert.ToString(item["EmpName"]) + "<br/><br/> iSAP assessment for you process commenced on " + Convert.ToDateTime(item["JoinDate"]).ToString("yyyy-MM-dd") + " and will remain open until " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + ".You may read the iSAP modules at your convenience and complete the assessment by " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + ". Kindly note the assessment will not be available after " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + " and your next assessment will be due next year";

                                    //string outputResult = string.Empty;
                                    //try
                                    //{
                                    //    outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                    //    //try
                                    //    //{
                                    //    //    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(dtEmailList.Rows[0]["email_address"]), "", moduleconfigID.ToString(), "3", outputResult);
                                    //    //}
                                    //    //catch (Exception ex)
                                    //    //{

                                    //    //    _serviceconnect.LogConnect("calenderallocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //    //}

                                    //    emailStatus = 1;
                                    //    _serviceconnect.LogConnect("calenderallocation", "1024", emailBody, "Information");

                                    //}
                                    //catch (Exception ex)
                                    //{

                                    //    _serviceconnect.LogConnect("calenderallocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //}

                                    emailStatus = 1;
                                }
                            }

                            if (emailStatus == 1)
                            {
                                string sb = string.Empty;
                                NpgsqlConnection npgConupdate = new NpgsqlConnection(appSettings.Value.DbConnection);
                                string updateQuery = string.Empty;
                                updateQuery = "update #ModuleYearlyCalenderConfig# set #EmailStatus#=" + emailStatus + " where  #ModuleYearlyConfigID#=" + moduleconfigID + ";";
                                updateQuery = updateQuery.Replace('#', '"');
                                // sb = sb + updateQuery;

                                if (updateQuery.Length > 0)
                                {

                                    npgConupdate.Open();

                                    string sqlQuery = updateQuery;

                                    // Define a command to call  procedure
                                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgConupdate);
                                    NpgsqlDataReader rdr = cmd.ExecuteReader();
                                    npgConupdate.Close();
                                }
                            }


                        }




                    }



                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ISAPcalenderAllocation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }





            return response;
        }

        // get calender allocation email List
        public DataTable getcalenderallocationemail(string companyCode, string departmentcode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {
                //string fromDate = string.Empty;
                //string todate = string.Empty;
                //fromDate = DateTime.Now.AddMonths(-2).Year + "-" + DateTime.Now.AddMonths(-2).Month + "-01";

                //todate = DateTime.Now.ToString("yyyy-MM-dd");
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_security_month_launch
                                                                    (  
                                                                         :p_company,:p_department

                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(companyCode))
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = companyCode;
                        else
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(departmentcode))
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = departmentcode;
                        else
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();


                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getNewJoineeStatusUpdateData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        // update ISAP deactivation after end date
        public ResponseClass updateModuleExpiration()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtCalenderConfig = new DataTable();
            try
            {
                string currentdate = string.Empty;

                currentdate = DateTime.Now.ToString("yyyy-MM-dd");

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_scheduler_isap_inactive
                                                                    ( 
                                                                        :p_date
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(currentdate))
                            cmd.Parameters.AddWithValue("p_date", DbType.String).Value = currentdate;
                        else
                            cmd.Parameters.AddWithValue("p_date", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();


                    }
                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                _serviceconnect.LogConnect("updateModuleExpiration", "1024", ex.Message, "Exception");
            }



            return response;
        }

        // Send ISAP Failure notification to Manager
        public ResponseClass isapFailureNotification()
        {

            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = getISAPFailureNotificationData();
                if (dtEmployees != null)
                {

                    if (dtEmployees.Rows.Count > 0)
                    {
                        _serviceconnect.LogConnect("ISAPAssessmentFailureNotification", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("ISAPAssessmentFailureNotification", "");



                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string mAllocationID = Convert.ToString(item["maalocationid"]);
                                string ccEmail = Convert.ToString(Convert.ToString(item["ccemail"]));


                                if (emailEntity != null && emailEntity.Count > 0 && !string.IsNullOrEmpty(Convert.ToString(item["mgremail"])))
                                {
                                    MailDetails mailDetails = new MailDetails();
                                    mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    // set to list
                                    List<ToList> lstToList = new List<ToList>();
                                    ToList to = new ToList();
                                    to.EmailAddress = Convert.ToString(item["mgremail"]);
                                    lstToList.Add(to);
                                    mailDetails.ToList = lstToList;

                                    List<BCCList> lstBCC = new List<BCCList>();

                                    if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    {
                                        string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                        foreach (string email in bccList)
                                        {
                                            BCCList bcc = new BCCList();
                                            bcc.EmailAddress = email.ToString();
                                            lstBCC.Add(bcc);
                                        }

                                        mailDetails.bCCLists = lstBCC;
                                    }

                                    mailDetails.Sender = appSettings.Value.Sender;
                                    mailDetails.SenderName = appSettings.Value.SenderName;
                                    mailDetails.Subject = emailEntity[0].EmailSubject;
                                    string emailBody = string.Empty;
                                    emailBody = emailEntity[0].EmailBody;
                                    emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["managername"]));
                                    emailBody = emailBody.Replace("@EMPCode", Convert.ToString(item["employeecode"]));
                                    emailBody = emailBody.Replace("@EMPName", Convert.ToString(item["employeename"]));
                                    emailBody = emailBody.Replace("@PRName", Convert.ToString(item["managername"]));
                                    emailBody = emailBody.Replace("@SubProcess", Convert.ToString(item["subprocess"]));
                                    emailBody = emailBody.Replace("@ISAPStatus", Convert.ToString(item["isapstatus"]));
                                    emailBody = emailBody.Replace("@DOJ", Convert.ToDateTime(item["doj"]).ToString("dd MMM yyyy"));
                                    emailBody = emailBody.Replace("@ISAPEndDate", Convert.ToDateTime(item["expirydate"]).ToString("dd MMM yyyy"));
                                    emailBody = emailBody.Replace("@CC", ccEmail);

                                    mailDetails.MailActualBody = emailBody;
                                    string outputResult = string.Empty;
                                    try
                                    {
                                        outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                        int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["mgremail"]), "", mAllocationID, "2", outputResult);
                                        //if (outputResult== "SUCCESS")
                                        //{
                                        //    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["mgremail"]), "", mAllocationID, "2");
                                        //}

                                        _serviceconnect.LogConnect("newJoiningAllocation", "1024", emailBody, "Information");
                                    }
                                    catch (Exception ex)
                                    {

                                        _serviceconnect.LogConnect("newJoiningAllocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    }
                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("newJoiningAllocation", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("newJoiningAllocation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable getCalenderConfig()
        {

            DataTable dtCalenderConfig = new DataTable();
            try
            {
                string currentYear = string.Empty;
                string currentMonth = string.Empty;
                currentYear = DateTime.Now.Year.ToString();
                currentMonth = DateTime.Now.Month.ToString();
                if (currentMonth.Length == 1)
                {
                    currentMonth = "0" + currentMonth;
                }

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_check_yearlycalender_config
                                                                    ( 
                                                                        :p_year,
                                                                        :p_month
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(currentYear))
                            cmd.Parameters.AddWithValue("p_year", DbType.String).Value = currentYear;
                        else
                            cmd.Parameters.AddWithValue("p_year", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(currentMonth))
                            cmd.Parameters.AddWithValue("p_month", DbType.String).Value = currentMonth;
                        else
                            cmd.Parameters.AddWithValue("p_month", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();


                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getCalenderConfig", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable getExcludeemployees(string companyCode, string departmentCode, string subProcess)
        {

            DataTable dtexcludeEmployee = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_isap_excludeemployee
                                                                    ( 
                                                                        :p_company,
                                                                        :p_department,
                                                                        :p_subprocess
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(companyCode))
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = companyCode;
                        else
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(departmentCode))
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = departmentCode;
                        else
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(subProcess))
                            cmd.Parameters.AddWithValue("p_subprocess", DbType.String).Value = subProcess;
                        else
                            cmd.Parameters.AddWithValue("p_subprocess", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtexcludeEmployee);
                        npgsqlConnection.Close();


                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getExcludeemployees", "1024", ex.Message, "Exception");
            }



            return dtexcludeEmployee;
        }

        public DataTable getNewJoineeData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {
                string currentYear = string.Empty;
                string currentMonth = string.Empty;
                currentYear = DateTime.Now.Year.ToString();
                currentMonth = DateTime.Now.Month.ToString();
                if (currentMonth.Length == 1)
                {
                    currentMonth = "0" + currentMonth;
                }

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_new_joinee_employees
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getNewJoineeData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable getISAPFailureNotificationData()
        {
            DataTable dtFailEmployee = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_assessment_failure
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtFailEmployee);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getISAPFailureNotificationData", "1024", ex.Message, "Exception");
            }



            return dtFailEmployee;
        }


        public ResponseClass newjoineestatusupdate()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = getNewJoineeStatusUpdateData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("NewJoineeStatusUpdate", "");


                        _serviceconnect.LogConnect("newjoineestatusupdate", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {
                                string companyCode = string.Empty;
                                string departmentCode = string.Empty;
                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));
                                companyCode = Convert.ToString(Convert.ToString(item["companycode"]));
                                departmentCode = Convert.ToString(Convert.ToString(item["departmentcode"]));
                                DataTable empList = new DataTable();
                                empList = getNewJoineeStatusUpdateDataEmployee(companyCode, departmentCode);
                                if (empList != null && empList.Rows.Count > 0 && emailEntity != null && emailEntity.Count > 0)
                                {
                                    MailDetails mailDetails = new MailDetails();
                                    mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    // set to list
                                    List<ToList> lstToList = new List<ToList>();
                                    ToList to = new ToList();
                                    to.EmailAddress = Convert.ToString(item["EmailAddress"]);
                                    lstToList.Add(to);
                                    mailDetails.ToList = lstToList;

                                    List<BCCList> lstBCC = new List<BCCList>();

                                    if (!string.IsNullOrEmpty(Convert.ToString(item["BCCList"])))
                                    {
                                        string[] bccList = Convert.ToString(item["BCCList"]).Split(",");

                                        foreach (string email in bccList)
                                        {
                                            BCCList bcc = new BCCList();
                                            bcc.EmailAddress = email.ToString();
                                            lstBCC.Add(bcc);
                                        }

                                        mailDetails.bCCLists = lstBCC;
                                    }

                                    mailDetails.Sender = appSettings.Value.Sender;
                                    mailDetails.SenderName = appSettings.Value.SenderName;
                                    mailDetails.Subject = emailEntity[0].EmailSubject;
                                    string emailBody = string.Empty;
                                    emailBody = emailEntity[0].EmailBody;
                                    emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["EmpName"]));
                                    emailBody = emailBody.Replace("@StartDate@", Convert.ToDateTime(item["JoinDate"]).ToString("dd MMM yyyy"));
                                    emailBody = emailBody.Replace("@EndDate@", Convert.ToDateTime(item["ExpiryDate"]).ToString("dd MMM yyyy"));
                                    emailBody = emailBody.Replace("@CC", ccEmail);
                                    //string emailBody = "Dear " + Convert.ToString(item["EmpName"]) + "<br/><br/> iSAP assessment for you process commenced on " + Convert.ToDateTime(item["JoinDate"]).ToString("yyyy-MM-dd") + " and will remain open until " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + ".You may read the iSAP modules at your convenience and complete the assessment by " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + ". Kindly note the assessment will not be available after " + Convert.ToDateTime(item["ExpiryDate"]).ToString("yyyy-MM-dd") + " and your next assessment will be due next year";
                                    mailDetails.MailActualBody = emailBody;
                                    string outputResult = string.Empty;
                                    try
                                    {
                                        // outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                        _serviceconnect.LogConnect("newJoiningAllocation", "1024", emailBody, "Information");
                                    }
                                    catch (Exception ex)
                                    {

                                        _serviceconnect.LogConnect("newJoiningAllocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    }
                                }

                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("newjoineestatusupdate", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }

                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("newJoiningAllocation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable getNewJoineeStatusUpdateData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {
                string fromDate = string.Empty;
                string todate = string.Empty;
                fromDate = DateTime.Now.AddMonths(-2).Year + "-" + DateTime.Now.AddMonths(-2).Month + "-01";

                todate = DateTime.Now.ToString("yyyy-MM-dd");
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_new_joinee_status_update
                                                                    (  
                                                                         :p_fromdate,:p_todate

                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(todate))
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = todate;
                        else
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getNewJoineeStatusUpdateData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }
        public DataTable getNewJoineeStatusUpdateDataEmployee(string companyCode, string departmentCode)
        {
            DataTable dtEmployees = new DataTable();
            try
            {
                string fromDate = string.Empty;
                string todate = string.Empty;
                fromDate = DateTime.Now.AddMonths(-2).Year + "-" + DateTime.Now.AddMonths(-2).Month + "-01";

                todate = DateTime.Now.ToString("yyyy-MM-dd");

                string sqlQuery = string.Empty;

                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                sqlQuery = "A.#EmployeeCode#,concat(B.#FIRSTNAME#,' ',B.#LASTNAME#) as EmployeeName,B.#Manager_Name#,B.#Sub_Process#,";
                sqlQuery = sqlQuery + "cast(TO_CHAR(B.#DOJ#, 'dd Mon  yyyy') as character varying) as DOJ,";
                sqlQuery = sqlQuery + "cast(TO_CHAR(A.#ExpiryDate#, 'dd Mon  yyyy') as character varying) as ExpiryDate,";
                sqlQuery = sqlQuery + "'pending' as isapstatus";
                sqlQuery = sqlQuery + "from #ModuleEmployeeAllocation# A";
                sqlQuery = sqlQuery + "inner join #EmployeeMaster# B on A.#EmployeeCode# = B.#EXTERNALDATAREFERENCE#";
                sqlQuery = sqlQuery + "where B.#DOJ# between '" + fromDate + "' and '" + todate + "'";
                sqlQuery = sqlQuery + "and (A.#CompletionStatus#)=0 and B.#COMPANY_CODE#='" + companyCode + "'";
                sqlQuery = sqlQuery + "and A.#AllocationType#='NewJoinee' and B.#Department_Code#='" + departmentCode + "' and A.#ExpiryDate#>='" + todate + "'";
                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getNewJoineeStatusUpdateData", "1024", ex.Message, "Exception");
            }



            return dtEmployees;
        }


        //public ResponseClass getTreeData(getTreeDataRequest request)
        //{
        //    string htmlData = "";
        //    ResponseClass response = new ResponseClass();
        //    string companiestopass = string.Empty;
        //    if (request.currentRole == "Geo Admin")
        //    {
        //        DataTable dtCompanies = new DataTable();
        //        dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoggedInUser);
        //        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //        {
        //            foreach (DataRow exclude in dtCompanies.Rows)
        //            {
        //                companiestopass = companiestopass + Convert.ToString(exclude["CompanyCode"]) + ",";
        //                //companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
        //            }

        //            companiestopass = companiestopass.TrimEnd(',');

        //        }
        //    }
        //    else if (request.currentRole == "Program Manager")
        //    {
        //        companiestopass = request.requestData;
        //    }
        //    try
        //    {
        //        DataTable dtEmployees = new DataTable();
        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
        //        {
        //            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_tree_data
        //                                                                ( 
        //                                                                    :p_countryname
        //                                                                )", npgsqlConnection))
        //            {
        //                cmd.CommandType = CommandType.Text; //
        //                if (!String.IsNullOrEmpty(companiestopass))
        //                    cmd.Parameters.AddWithValue("p_countryname", DbType.String).Value = companiestopass;
        //                else
        //                    cmd.Parameters.AddWithValue("p_countryname", DbType.String).Value = DBNull.Value;

        //                npgsqlConnection.Open();

        //                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
        //                dataAdapter.Fill(dtEmployees);
        //                npgsqlConnection.Close();

        //                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
        //                {
        //                    DataTable  dtcompany = dtEmployees.DefaultView.ToTable(true, "COMPANY_CODE", "Company_Name");

        //                    DataTable dtdepartment = dtEmployees.DefaultView.ToTable(true, "COMPANY_CODE", "Company_Name", "Department_Code", "DEPARTMENT");

        //                    if (dtcompany!=null && dtcompany.Rows.Count>0)
        //                    {
        //                        foreach (DataRow companies in dtcompany.Rows)
        //                        {
        //                            htmlData = htmlData + "<li data-company='" + Convert.ToString(companies["COMPANY_CODE"]) + "'><input type='checkbox' value='" + Convert.ToString(companies["COMPANY_CODE"]) + "'><label>" + Convert.ToString(companies["Company_Name"]) + " </label>";

        //                            // get department
        //                            string selectQuery = "COMPANY_CODE='" + Convert.ToString(companies["COMPANY_CODE"]) + "'";

        //                            DataRow[] drDepartment = dtdepartment.Select(selectQuery);
        //                            if (drDepartment.Length != 0)
        //                            {
        //                                htmlData = htmlData + "<ul>";
        //                                foreach (DataRow item in drDepartment)
        //                                {
        //                                    htmlData = htmlData + "<li data-department='" + Convert.ToString(item["Department_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(item["Department_Code"]) + "'><label>" + Convert.ToString(item["DEPARTMENT"]) + " </label>";

        //                                    DataRow[] drSubProcess = getSubprocess(dtEmployees, Convert.ToString(item["Department_Code"]));
        //                                    if (drSubProcess.Length != 0)
        //                                    {
        //                                        htmlData = htmlData + "<ul>";
        //                                        foreach (DataRow sub in drSubProcess)
        //                                        {
        //                                            htmlData = htmlData + "<li data-subproces='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><label>" + Convert.ToString(sub["Sub_Process"]) + " </label></li>";
        //                                        }
        //                                        htmlData = htmlData + "</ul>";
        //                                    }

        //                                    htmlData = htmlData + "</li>";

        //                                }
        //                                htmlData = htmlData + "</ul>";
        //                            }

        //                            htmlData = htmlData + "</li>";
        //                        }

        //                    }
        //                    }


        //                    response.responseCode = 1;
        //                    response.responseMessage = "Success";


        //                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
        //            }
        //        }



        //        response.responseCode = 1;
        //        response.responseMessage = htmlData;

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("getTreeData", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;

        //    }



        //    return response;
        //}

        public ResponseClass getTreeData(getTreeDataRequest request)
        {
            string department = string.Empty;
            List<departmentList> lstdepartment = new List<departmentList>();

            string htmlData = "";
            ResponseClass response = new ResponseClass();
            string companiestopass = string.Empty;
            if (request.currentRole == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoggedInUser);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companiestopass = companiestopass + Convert.ToString(exclude["CompanyCode"]) + ",";
                        //companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    }

                    companiestopass = companiestopass.TrimEnd(',');

                }
            }
            else if (request.currentRole == "Program Manager")
            {
                //companiestopass = request.requestData;
                string incccompany = string.Empty;
                DataTable dtEmployees = new DataTable();
                dtEmployees = _usermanagementBL.getassigneddepartmentforprogrammanager(request.LoggedInUser);
                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtEmployees.Rows)
                    {
                        lstdepartment.Add(new departmentList { departmentCode= Convert.ToString(exclude["DepartmentCode"]) });

                         department = department + Convert.ToString(exclude["DepartmentCode"]) + ",";
                    }

                    if (!string.IsNullOrEmpty(Convert.ToString(dtEmployees.Rows[0]["CompanyCode"])))
                    {
                        string[] cccode = Convert.ToString(dtEmployees.Rows[0]["CompanyCode"]).Split(",");
                        foreach (string ccode in cccode)
                        {
                            companiestopass = companiestopass + Convert.ToString(ccode) + ",";
                        }

                        companiestopass = companiestopass.TrimEnd(',');
                    }

                }
                else
                {
                    companiestopass = request.requestData;
                }
            }
            try
            {
                SqlParameter[] parameter = {
                new SqlParameter("@CountryName",companiestopass),

                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_get_tree_data", parameter, outParameters);


                int enableDepartment = 0;


                if (lstdepartment!=null && lstdepartment.Count>0)
                {
                    enableDepartment = 1;
                }

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    //response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    foreach (DataRow companies in dsResult.Tables[0].Rows)
                    {
                        if (enableDepartment==1)
                        {
                            htmlData = htmlData + "<li data-program=" + enableDepartment + " data-company='" + Convert.ToString(companies["COMPANY_CODE"]) + "'><input type='checkbox' value='" + Convert.ToString(companies["COMPANY_CODE"]) + "'><label>" + Convert.ToString(companies["Company_Name"]) + " </label>";
                        }
                        else
                        {
                            htmlData = htmlData + "<li data-company='" + Convert.ToString(companies["COMPANY_CODE"]) + "'><input type='checkbox' value='" + Convert.ToString(companies["COMPANY_CODE"]) + "'><label>" + Convert.ToString(companies["Company_Name"]) + " </label>";
                        }
                       
                        string selectQuery = "COMPANY_CODE='" + Convert.ToString(companies["COMPANY_CODE"]) + "'";
                        // get department
                        DataRow[] drDepartment = dsResult.Tables[1].Select(selectQuery);
                        if (drDepartment.Length != 0)
                        {
                           

                            htmlData = htmlData + "<ul>";
                            foreach (DataRow item in drDepartment)
                            {

                                if (enableDepartment == 1)
                                {
                                    string departmentCode = Convert.ToString(item["Department_Code"]);

                                    var checkDepartment = lstdepartment.Where(x => x.departmentCode == departmentCode).ToList();
                                    if (checkDepartment==null || checkDepartment.Count==0)
                                    {
                                        htmlData = htmlData + "<li data-program=" + enableDepartment + " data-dcompany='" + Convert.ToString(companies["COMPANY_CODE"]) + "' data-department='" + Convert.ToString(item["Department_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(item["Department_Code"]) + "'><label>" + Convert.ToString(item["DEPARTMENT"]) + " </label>";

                                        DataRow[] drSubProcess = getSubprocess(dsResult.Tables[2], Convert.ToString(item["Department_Code"]));
                                        if (drSubProcess.Length != 0)
                                        {
                                            htmlData = htmlData + "<ul>";
                                            foreach (DataRow sub in drSubProcess)
                                            {
                                                htmlData = htmlData + "<li data-program=" + enableDepartment + " data-dcompany='" + Convert.ToString(companies["COMPANY_CODE"]) + "' data-subproces='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><label>" + Convert.ToString(sub["Sub_Process"]) + " </label></li>";
                                            }
                                            htmlData = htmlData + "</ul>";
                                        }

                                        htmlData = htmlData + "</li>";
                                    }
                                    else
                                    {
                                        htmlData = htmlData + "<li data-dcompany='" + Convert.ToString(companies["COMPANY_CODE"]) + "' data-department='" + Convert.ToString(item["Department_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(item["Department_Code"]) + "'><label>" + Convert.ToString(item["DEPARTMENT"]) + " </label>";

                                        DataRow[] drSubProcess = getSubprocess(dsResult.Tables[2], Convert.ToString(item["Department_Code"]));
                                        if (drSubProcess.Length != 0)
                                        {
                                            htmlData = htmlData + "<ul>";
                                            foreach (DataRow sub in drSubProcess)
                                            {
                                                htmlData = htmlData + "<li data-dcompany='" + Convert.ToString(companies["COMPANY_CODE"]) + "' data-subproces='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><label>" + Convert.ToString(sub["Sub_Process"]) + " </label></li>";
                                            }
                                            htmlData = htmlData + "</ul>";
                                        }

                                        htmlData = htmlData + "</li>";
                                    }

                                   
                                }
                                else
                                {
                                    htmlData = htmlData + "<li data-dcompany='" + Convert.ToString(companies["COMPANY_CODE"]) + "' data-department='" + Convert.ToString(item["Department_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(item["Department_Code"]) + "'><label>" + Convert.ToString(item["DEPARTMENT"]) + " </label>";

                                    DataRow[] drSubProcess = getSubprocess(dsResult.Tables[2], Convert.ToString(item["Department_Code"]));
                                    if (drSubProcess.Length != 0)
                                    {
                                        htmlData = htmlData + "<ul>";
                                        foreach (DataRow sub in drSubProcess)
                                        {
                                            htmlData = htmlData + "<li data-dcompany='" + Convert.ToString(companies["COMPANY_CODE"]) + "' data-subproces='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><label>" + Convert.ToString(sub["Sub_Process"]) + " </label></li>";
                                        }
                                        htmlData = htmlData + "</ul>";
                                    }

                                    htmlData = htmlData + "</li>";
                                }

                               

                            }
                            htmlData = htmlData + "</ul>";
                        }

                        htmlData = htmlData + "</li>";
                    }

                }

                response.responseCode = 1;
                response.responseMessage = htmlData;
                response.responseJSON = department.TrimEnd(',');

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getTreeData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }



            return response;
        }

        public DataRow[] getSubprocess(DataTable subprocess, string departmentCode)
        {
            string selectQuery = "Department_Code='" + departmentCode + "'";
            DataRow[] drSubprocess = subprocess.Select(selectQuery);

            return drSubprocess;
        }



        // Monthly launch status update
        public ResponseClass ISAPcalenderStatusUpdate()
        {

            ResponseClass response = new ResponseClass();
            try
            {
                DataSet dsEmployee = new DataSet();
                // get calender data from postgress dB
                DataTable dtModuleConfig = new DataTable();
                CalenderStatusUpdateRequestDTO moduleRequest = new CalenderStatusUpdateRequestDTO();
                dtModuleConfig = getModuleConfig(moduleRequest);
                if (dtModuleConfig != null && dtModuleConfig.Rows.Count > 0)
                {
                    foreach (DataRow module in dtModuleConfig.Rows)
                    {
                        string moduleConfigID = string.Empty;
                        string departmentCode = string.Empty;
                        string departmentname = string.Empty;
                        string ccEmail = string.Empty;
                        DateTime startDate = DateTime.Now;
                        DateTime expiryDate = DateTime.Now;
                        moduleConfigID = Convert.ToString(module["moduleyearlyconfigid"]);
                        departmentCode = Convert.ToString(module["departmentCode"]);
                        departmentname = Convert.ToString(module["departmentname"]);
                        startDate = Convert.ToDateTime(module["AssignedDate"]);
                        expiryDate = Convert.ToDateTime(module["ExpiryDate"]);
                        ccEmail = Convert.ToString(module["ccemail"]);

                        // now get summary Data
                        CalenderStatusUpdateRequestDTO modulesummary = new CalenderStatusUpdateRequestDTO();
                        DataTable summarydata = new DataTable();
                        modulesummary.Param1 = moduleConfigID;
                        summarydata = getSummarySubprocesswise(modulesummary);

                        // now get detail data
                        CalenderStatusUpdateRequestDTO moduledetail = new CalenderStatusUpdateRequestDTO();
                        DataTable detaildata = new DataTable();
                        moduledetail.Param1 = moduleConfigID;
                        detaildata = getEmployeeWiseDetail(moduledetail);

                        DataTable dtEmailList = new DataTable();
                        dtEmailList = getcalenderEmployeeEmail(moduleConfigID, departmentCode);
                        if (dtEmailList.Rows.Count > 0 && detaildata.Rows.Count > 0 && summarydata.Rows.Count > 0)
                        {
                            List<EmailEntity> emailEntity = new List<EmailEntity>();
                            // get email template
                            emailEntity = _emailMGT.getEmailTemplate("CALENDERSTATUSUPDATE", "");

                            if (emailEntity != null && emailEntity.Count > 0)
                            {
                                MailDetails mailDetails = new MailDetails();
                                mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                string toemail = Convert.ToString(dtEmailList.Rows[0]["email_address"]);

                                //string toemail = "deepak.rohilla@teamhgs.com,shamsuddin.ansari@teamhgs.com,Aravind.Anbalagan@teamhgs.com";
                                List<ToList> lstToList = new List<ToList>();
                                // set to list
                                if (!string.IsNullOrEmpty(toemail))
                                {
                                    toemail = toemail.Replace("{", "");
                                    toemail = toemail.Replace("}", "");
                                    string[] toList = toemail.Split(",");

                                    foreach (string email in toList)
                                    {
                                        ToList bcc = new ToList();
                                        bcc.EmailAddress = email.ToString();
                                        lstToList.Add(bcc);
                                    }

                                    mailDetails.ToList = lstToList;
                                }

                                List<BCCList> lstBCC = new List<BCCList>();

                                if (!string.IsNullOrEmpty(Convert.ToString(dtEmailList.Rows[0]["bcclist"])))
                                {
                                    string[] bccList = Convert.ToString(dtEmailList.Rows[0]["bcclist"]).Split(",");

                                    foreach (string email in bccList)
                                    {
                                        BCCList bcc = new BCCList();
                                        bcc.EmailAddress = email.ToString();
                                        lstBCC.Add(bcc);
                                    }

                                    mailDetails.bCCLists = lstBCC;
                                }

                                if (!string.IsNullOrEmpty(Convert.ToString(dtEmailList.Rows[0]["cctoemail"])))
                                {
                                    mailDetails.CcList = Convert.ToString(dtEmailList.Rows[0]["cctoemail"]);
                                }

                                mailDetails.Sender = appSettings.Value.Sender;
                                mailDetails.SenderName = appSettings.Value.SenderName;
                                mailDetails.Subject = emailEntity[0].EmailSubject;
                                mailDetails.Subject = mailDetails.Subject.Replace("@departmentname@", departmentname);
                                string emailBody = string.Empty;
                                emailBody = emailEntity[0].EmailBody;
                                emailBody = emailBody.Replace("**departmentname**", departmentname);
                                emailBody = emailBody.Replace("@StartDate@", startDate.ToString("dd MMM yyyy"));
                                emailBody = emailBody.Replace("@EndDate@", expiryDate.ToString("dd MMM yyyy"));
                                emailBody = emailBody.Replace("@CC", ccEmail);
                                emailBody = emailBody.Replace("@TodayDate@", DateTime.Now.ToString("dd MMM yyyy"));

                                double totalEligible = 0;
                                double totalComplete = 0;
                                double grandTotal = 0.0;
                                string subprocessData = string.Empty;

                                int rowNo = 1;
                                foreach (DataRow subprocessrows in summarydata.Rows)
                                {
                                    subprocessData += "<tr>";
                                    subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + rowNo + "</td>";
                                    subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + Convert.ToString(subprocessrows["subprocess"]) + "</td>";
                                    subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + Convert.ToString(subprocessrows["subprocesshead"]) + "</td>";
                                    subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + Convert.ToString(subprocessrows["totaleligible"]) + "</td>";
                                    subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + Convert.ToString(subprocessrows["complete"]) + "</td>";
                                    subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + String.Format("{0:0.00}", Convert.ToDouble(subprocessrows["completionpercentage"])) + " %</td>";
                                    subprocessData += "</tr>";
                                    totalEligible = totalEligible + Convert.ToDouble(subprocessrows["totaleligible"]);
                                    totalComplete = totalComplete + Convert.ToDouble(subprocessrows["complete"]);
                                    rowNo = rowNo + 1;
                                }

                                emailBody = emailBody.Replace("**subprocessdetail**", subprocessData);

                                try
                                {
                                    grandTotal = (totalComplete / totalEligible) * 100;
                                }
                                catch (Exception ex)
                                {
                                    grandTotal = 0;
                                    _serviceconnect.LogConnect("ISAPcalenderStatusUpdate", "1024", "Grand total division error : " + ex.Message, "Exception");
                                }


                                emailBody = emailBody.Replace("@TotalPercentage@", String.Format("{0:0.00}", grandTotal));

                                mailDetails.MailActualBody = emailBody;
                                string outputResult = string.Empty;

                                // now first create file and send send in attachment
                                bool fileCreation = false;

                                string exportFilename = "Status_Update_" + Convert.ToString(departmentname) + "_" + DateTime.Now.ToString("dddd, dd MMMM yyyy") + ".xls";
                                string savePath = Path.Combine(appSettings.Value.fileAtatchment) + exportFilename;

                                fileCreation = SaveDataTableToExcel(detaildata, savePath);
                                if (fileCreation)
                                {
                                    try
                                    {
                                        List<AtatchmentList> lstAttachment = new List<AtatchmentList>();
                                        string filePath = savePath;
                                        AtatchmentList myFile = new AtatchmentList();
                                        myFile.Attachment = filePath;
                                        lstAttachment.Add(myFile);
                                        mailDetails.Attachment = lstAttachment;
                                    }
                                    catch (Exception ex)
                                    {

                                        _serviceconnect.LogConnect("calenderallocation", "1024", "Error in file attachment : " + ex.Message, "Exception");
                                    }

                                }


                                try
                                {
                                    outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                                    try
                                    {
                                        int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, string.Empty, Convert.ToString(dtEmailList.Rows[0]["email_address"]), "", moduleConfigID, "5", outputResult);
                                    }
                                    catch (Exception ex)
                                    {

                                        _serviceconnect.LogConnect("ISAPcalenderStatusUpdate", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    }


                                    // _serviceconnect.LogConnect("ISAPcalenderStatusUpdate", "1024", emailBody, "Information");

                                }
                                catch (Exception ex)
                                {

                                    _serviceconnect.LogConnect("calenderallocation", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    response.responseCode = 0;
                                    response.responseMessage = ex.Message;
                                    return response;
                                }

                                //now save file

                            }
                        }
                    }
                }




                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ISAPcalenderAllocation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public static bool SaveDataTableToExcel(DataTable table, string savePath)
        {

            //open file
            StreamWriter wr = new StreamWriter(savePath, false, Encoding.Unicode);
            try
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    wr.Write(table.Columns[i].ToString().ToUpper() + "\t");
                }
                wr.WriteLine();
                //write rows to excel file
                for (int i = 0; i < (table.Rows.Count); i++)
                {
                    for (int j = 0; j < table.Columns.Count; j++)
                    {
                        if (table.Rows[i][j] != null)
                        {
                            wr.Write("=\"" + Convert.ToString(table.Rows[i][j]) + "\"" + "\t");
                        }
                        else
                        {
                            wr.Write("\t");
                        }
                    }
                    //go to next line
                    wr.WriteLine();
                }
                //close file
                wr.Close();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public DataTable getModuleConfig(CalenderStatusUpdateRequestDTO request)
        {

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_job_calender_status_update_first
                                                                    ( 
                                                                        :p_param1,
                                                                        :p_param2,:p_param3,:p_param4
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.Param1))
                            cmd.Parameters.AddWithValue("p_param1", DbType.String).Value = request.Param1;
                        else
                            cmd.Parameters.AddWithValue("p_param1", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param2))
                            cmd.Parameters.AddWithValue("p_param2", DbType.String).Value = request.Param2;
                        else
                            cmd.Parameters.AddWithValue("p_param2", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param3))
                            cmd.Parameters.AddWithValue("p_param3", DbType.String).Value = request.Param3;
                        else
                            cmd.Parameters.AddWithValue("p_param3", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param4))
                            cmd.Parameters.AddWithValue("p_param4", DbType.String).Value = request.Param4;
                        else
                            cmd.Parameters.AddWithValue("p_param4", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getModuleConfig", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable getSummarySubprocesswise(CalenderStatusUpdateRequestDTO request)
        {

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_job_calender_status_update_second
                                                                    ( 
                                                                        :p_param1,
                                                                        :p_param2,:p_param3,:p_param4
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.Param1))
                            cmd.Parameters.AddWithValue("p_param1", DbType.String).Value = request.Param1;
                        else
                            cmd.Parameters.AddWithValue("p_param1", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param2))
                            cmd.Parameters.AddWithValue("p_param2", DbType.String).Value = request.Param2;
                        else
                            cmd.Parameters.AddWithValue("p_param2", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param3))
                            cmd.Parameters.AddWithValue("p_param3", DbType.String).Value = request.Param3;
                        else
                            cmd.Parameters.AddWithValue("p_param3", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param4))
                            cmd.Parameters.AddWithValue("p_param4", DbType.String).Value = request.Param4;
                        else
                            cmd.Parameters.AddWithValue("p_param4", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();


                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getCalenderConfig", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable getEmployeeWiseDetail(CalenderStatusUpdateRequestDTO request)
        {

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_job_calender_status_update_third
                                                                    ( 
                                                                        :p_param1,
                                                                        :p_param2,:p_param3,:p_param4
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.Param1))
                            cmd.Parameters.AddWithValue("p_param1", DbType.String).Value = request.Param1;
                        else
                            cmd.Parameters.AddWithValue("p_param1", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param2))
                            cmd.Parameters.AddWithValue("p_param2", DbType.String).Value = request.Param2;
                        else
                            cmd.Parameters.AddWithValue("p_param2", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param3))
                            cmd.Parameters.AddWithValue("p_param3", DbType.String).Value = request.Param3;
                        else
                            cmd.Parameters.AddWithValue("p_param3", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Param4))
                            cmd.Parameters.AddWithValue("p_param4", DbType.String).Value = request.Param4;
                        else
                            cmd.Parameters.AddWithValue("p_param4", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getCalenderConfig", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable getcalenderEmployeeEmail(string companyCode, string departmentcode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_calender_status_update_email
                                                                    (  
                                                                         :p_company,:p_department

                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(companyCode))
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = companyCode;
                        else
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(departmentcode))
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = departmentcode;
                        else
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getcalenderEmployeeEmail", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #region  e-learning pending email

        public ResponseClass ecoursepending()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = getecoursependingdata();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourse", "");


                        //   _serviceconnect.LogConnect("ecoursepending", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");

                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = string.Empty;


                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    MailDetails mailDetails = new MailDetails();
                                    mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    // set to list
                                    List<ToList> lstToList = new List<ToList>();
                                    ToList to = new ToList();
                                    to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    lstToList.Add(to);
                                    mailDetails.ToList = lstToList;

                                    List<BCCList> lstBCC = new List<BCCList>();

                                    if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    {
                                        string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                        foreach (string email in bccList)
                                        {
                                            BCCList bcc = new BCCList();
                                            bcc.EmailAddress = email.ToString();
                                            lstBCC.Add(bcc);
                                        }

                                        mailDetails.bCCLists = lstBCC;
                                    }

                                    mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    mailDetails.SenderName = "HGS HALL Team";
                                    mailDetails.Subject = emailEntity[0].EmailSubject;
                                    string emailBody = string.Empty;
                                    emailBody = emailEntity[0].EmailBody;
                                    emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    emailBody = emailBody.Replace("*assettype*", Convert.ToString(item["assettype"]));
                                    emailBody = emailBody.Replace("*coursename*", Convert.ToString(item["coursename"]));
                                    emailBody = emailBody.Replace("*programmanager*", Convert.ToString(item["programmanager"]));

                                    mailDetails.MailActualBody = emailBody;
                                    string outputResult = string.Empty;
                                    try
                                    {
                                        outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                        int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                        //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    }
                                    catch (Exception ex)
                                    {

                                        _serviceconnect.LogConnect("ecoursepending", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    }


                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("ecoursepending", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ecoursepending", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable getecoursependingdata()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_getecoursependingdata
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getecoursependingdata", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  my to do pending

        public ResponseClass mytodopending()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = getmytodopendingdata();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingToDo", "");


                        //   _serviceconnect.LogConnect("ecoursepending", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");

                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = string.Empty;


                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    MailDetails mailDetails = new MailDetails();
                                    mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    // set to list
                                    List<ToList> lstToList = new List<ToList>();
                                    ToList to = new ToList();
                                    to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    lstToList.Add(to);
                                    mailDetails.ToList = lstToList;

                                    List<BCCList> lstBCC = new List<BCCList>();

                                    if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    {
                                        string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                        foreach (string email in bccList)
                                        {
                                            BCCList bcc = new BCCList();
                                            bcc.EmailAddress = email.ToString();
                                            lstBCC.Add(bcc);
                                        }

                                        mailDetails.bCCLists = lstBCC;
                                    }

                                    mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    mailDetails.SenderName = "HGS HALL Team";
                                    mailDetails.Subject = emailEntity[0].EmailSubject;
                                    string emailBody = string.Empty;
                                    emailBody = emailEntity[0].EmailBody;
                                    emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //emailBody = emailBody.Replace("*assettype*", Convert.ToString(item["assettype"]));
                                    //emailBody = emailBody.Replace("*coursename*", Convert.ToString(item["coursename"]));
                                    //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(item["programmanager"]));

                                    mailDetails.MailActualBody = emailBody;
                                    string outputResult = string.Empty;
                                    try
                                    {
                                        outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                        int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                        //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    }
                                    catch (Exception ex)
                                    {

                                        _serviceconnect.LogConnect("ecoursepending", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    }


                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("ecoursepending", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ecoursepending", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable getmytodopendingdata()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_getmytodopendingdata
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getmytodopendingdata", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region team lead update

        public ResponseClass weeklyteamleadupdate()
        {

            List<EmailEntity> emailEntity = new List<EmailEntity>();
            List<teamleadupdatedataentity> teamLeadData = new List<teamleadupdatedataentity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                teamLeadData = getweellyteamupdatedata();
                if (teamLeadData != null)
                {
                    if (teamLeadData.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("TemLeadUpdate", "");

                        var distinctprogrammanager = teamLeadData.Select(o => new { o.programmanagercode, o.programmanager, o.ppemail }).Distinct().ToList();

                        if (distinctprogrammanager != null)
                        {
                            foreach (var item in distinctprogrammanager)
                            {
                                try
                                {

                                    string ccEmail = string.Empty;


                                    if (emailEntity != null && emailEntity.Count > 0)
                                    {
                                        MailDetails mailDetails = new MailDetails();
                                        mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                        // set to list
                                        List<ToList> lstToList = new List<ToList>();
                                        ToList to = new ToList();
                                        to.EmailAddress = Convert.ToString(item.ppemail);
                                        lstToList.Add(to);
                                        mailDetails.ToList = lstToList;

                                        List<BCCList> lstBCC = new List<BCCList>();

                                        if (!string.IsNullOrEmpty(Convert.ToString(teamLeadData[0].bcclist)))
                                        {
                                            string[] bccList = Convert.ToString(teamLeadData[0].bcclist).Split(",");

                                            foreach (string email in bccList)
                                            {
                                                BCCList bcc = new BCCList();
                                                bcc.EmailAddress = email.ToString();
                                                lstBCC.Add(bcc);
                                            }

                                            mailDetails.bCCLists = lstBCC;
                                        }

                                        mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                        mailDetails.SenderName = "HGS HALL Team";
                                        mailDetails.Subject = emailEntity[0].EmailSubject;
                                        string emailBody = string.Empty;
                                        emailBody = emailEntity[0].EmailBody;
                                        emailBody = emailBody.Replace("@Employee@", Convert.ToString(item.programmanager));

                                        // get employee List

                                        List<teamleadupdatedataentity> employeeData = teamLeadData.Where(x => x.programmanagercode == item.programmanagercode).ToList();
                                        if (employeeData != null && employeeData.Count > 0)
                                        {
                                            string subprocessData = string.Empty;

                                            int rowNo = 1;
                                            foreach (var subprocessrows in employeeData)
                                            {
                                                subprocessData += "<tr>";
                                                subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + rowNo + "</td>";
                                                subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + Convert.ToString(subprocessrows.empcode) + "</td>";
                                                subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + Convert.ToString(subprocessrows.empname) + "</td>";
                                                subprocessData += "<td style='padding: 5px; border: 1px solid #b3d9ff; background-color: #ffffff;'>" + Convert.ToString(subprocessrows.pendingactivity) + "</td>";

                                                subprocessData += "</tr>";

                                                rowNo = rowNo + 1;
                                            }

                                            emailBody = emailBody.Replace("**loopdata**", subprocessData);
                                        }



                                        mailDetails.MailActualBody = emailBody;
                                        string outputResult = string.Empty;
                                        try
                                        {
                                            outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                            int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item.ppemail), "", "", "9", outputResult);

                                            //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                        }
                                        catch (Exception ex)
                                        {

                                            _serviceconnect.LogConnect("ecoursepending", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                        }


                                    }

                                    // send Email To Employee




                                    //return response;
                                }
                                catch (Exception ex)
                                {
                                    _serviceconnect.LogConnect("weeklyteamleadupdate", "1024", ex.Message, "Exception");
                                    response.responseCode = 0;
                                    response.responseMessage = ex.Message;
                                }

                            }
                        }


                        //foreach (DataRow item in dtEmployees.Rows)
                        //{




                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("weeklyteamleadupdate", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public List<teamleadupdatedataentity> getweellyteamupdatedata()
        {
            DataTable dtCalenderConfig = new DataTable();

            List<teamleadupdatedataentity> updateEntity = new List<teamleadupdatedataentity>();

            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_getteamleadupdatependingdata
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                        string responseJSON = JsonConvert.SerializeObject(dtCalenderConfig);

                        updateEntity = JsonConvert.DeserializeObject<List<teamleadupdatedataentity>>(responseJSON);

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getweellyteamupdatedata", "1024", ex.Message, "Exception");
            }



            return updateEntity;
        }

        #endregion

        #region email on publish
        public ResponseClass emailonpublishevent(string objectcode, string objecttype)
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = getemailonpublishevent(objectcode, objecttype);
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            /**************** SEND GCM NOTIFICATION *****************/
                            //try
                            //{
                            //    fcmnotificationresponseDTO fcmnotificationresponseDTO = new fcmnotificationresponseDTO();
                            //    fcmnotificationresponseDTO.EMPID = Convert.ToString(item["empid"]) ;
                            //    fcmnotificationresponseDTO.FCMTitle = "New Asset Allocation!";
                            //    fcmnotificationresponseDTO.FCMBody =Convert.ToString(item["coursename"])) + " is now available.Check the HALL app for the latest courses and updates!";
                            //    string gcmrequest = JsonConvert.SerializeObject(fcmnotificationresponseDTO);
                            //    //  WriteLogFile.WriteLog("Information", "GCM Request : " + gcmrequest + " ");
                            //    var gcmResponse = SendFCMNotification(fcmnotificationresponseDTO);

                            //}
                            //catch (Exception ex)
                            //{
                            //    _serviceconnect.LogConnect("emailonpublishevent", "1024", ex.Message, "Exception");

                            //}

                        }


                        //// get email template
                        //emailEntity = _emailMGT.getEmailTemplate("PendingECourse", "");


                        ////   _serviceconnect.LogConnect("ecoursepending", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");

                        //foreach (DataRow item in dtEmployees.Rows)
                        //{
                        //    try
                        //    {

                        //        string ccEmail = string.Empty;


                        //        if (emailEntity != null && emailEntity.Count > 0)
                        //        {
                        //            MailDetails mailDetails = new MailDetails();
                        //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                        //            // set to list
                        //            List<ToList> lstToList = new List<ToList>();
                        //            ToList to = new ToList();
                        //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                        //            lstToList.Add(to);
                        //            mailDetails.ToList = lstToList;

                        //            List<BCCList> lstBCC = new List<BCCList>();

                                       // int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", Convert.ToString(item["empcode"]), "6", outputResult);

                        //                foreach (string email in bccList)
                        //                {
                        //                    BCCList bcc = new BCCList();
                        //                    bcc.EmailAddress = email.ToString();
                        //                    lstBCC.Add(bcc);
                        //                }

                        //                mailDetails.bCCLists = lstBCC;
                        //            }

                        //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                        //            mailDetails.SenderName = "HGS HALL Team";
                        //            mailDetails.Subject = emailEntity[0].EmailSubject;
                        //            string emailBody = string.Empty;
                        //            emailBody = emailEntity[0].EmailBody;
                        //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                        //            emailBody = emailBody.Replace("*assettype*", Convert.ToString(item["assettype"]));
                        //            emailBody = emailBody.Replace("*coursename*", Convert.ToString(item["coursename"]));
                        //            emailBody = emailBody.Replace("*programmanager*", Convert.ToString(item["programmanager"]));

                        //            mailDetails.MailActualBody = emailBody;
                        //            string outputResult = string.Empty;
                        //            try
                        //            {
                        //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                        //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                        //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                        //            }
                        //            catch (Exception ex)
                        //            {

                        //                _serviceconnect.LogConnect("emailonpublishevent", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                        //            }


                        //        }

                        //        // send Email To Employee




                        //        //return response;
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        _serviceconnect.LogConnect("emailonpublishevent", "1024", ex.Message, "Exception");
                        //        response.responseCode = 0;
                        //        response.responseMessage = ex.Message;
                        //    }
                        //    //finally
                        //    //{
                        //    //    npgCon.Close();
                        //    //}
                        //}



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ecoursepending", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable getemailonpublishevent(string objectcode, string objecttype)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_getemailonpublisheventdata
                                                                    ( 
                                                                       :pobjectcode,
                                                                       :pobjecttype 
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(objectcode))
                            cmd.Parameters.AddWithValue("pobjectcode", DbType.String).Value = objectcode;
                        else
                            cmd.Parameters.AddWithValue("pobjectcode", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(objecttype))
                            cmd.Parameters.AddWithValue("pobjecttype", DbType.String).Value = objecttype;
                        else
                            cmd.Parameters.AddWithValue("pobjecttype", DbType.String).Value = string.Empty;
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getemailonpublishevent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public string SendFCMNotification(fcmnotificationresponseDTO fcmnotificationresponseDTO)
        {
            string response = string.Empty;
            //FireBaseAPICallBL fireBaseAPICallBL = new FireBaseAPICallBL();
            if (fcmnotificationresponseDTO.EMPID=="246420")
            {
                fcmnotificationresponseDTO.EMPID = "232779";
            }

            // first get device token
            string deviceTokenQuery = string.Empty;
            string deviceToken = string.Empty;
            deviceTokenQuery = "select FireBaseToken,DeviceId  from FireBaseTokenDetails where EmployeeId ='" + fcmnotificationresponseDTO.EMPID + "' ";
            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = MobileTokendBConnection.ExecuteDataSetInline(deviceTokenQuery);
            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                if (dsResult.Tables[0].Rows.Count > 0)
                {
                    deviceToken = Convert.ToString(dsResult.Tables[0].Rows[0]["FireBaseToken"]);
                }
            }

            if (!string.IsNullOrEmpty(deviceToken))
            {
                var fcmResponse = _apiCall.FBCall(deviceToken, Convert.ToString(fcmnotificationresponseDTO.FCMTitle), Convert.ToString(fcmnotificationresponseDTO.FCMBody));
                response = fcmResponse;
            }
            else
            {
                response = "Device Token not found!";
            }
            return response;
        }

        #endregion

        #region  FSTL Course

        public ResponseClass AssignFSTLCourse()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignFSTLCourseData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));


                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AssignFSTLCourseEvent(Convert.ToString(item["EmployeeCode"]));
                                    if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    {
                                        try
                                        {

                                            // string ccEmail = string.Empty;
                                            if (emailEntity != null && emailEntity.Count > 0)
                                            {
                                                MailDetails mailDetails = new MailDetails();
                                                mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                                //  set to list
                                                List<ToList> lstToList = new List<ToList>();
                                                ToList to = new ToList();
                                                to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                                lstToList.Add(to);
                                                mailDetails.ToList = lstToList;

                                                List<BCCList> lstBCC = new List<BCCList>();

                                                if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                                {
                                                    string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                                    foreach (string email in bccList)
                                                    {
                                                        BCCList bcc = new BCCList();
                                                        bcc.EmailAddress = email.ToString();
                                                        lstBCC.Add(bcc);
                                                    }

                                                    mailDetails.bCCLists = lstBCC;
                                                }

                                                mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                                mailDetails.SenderName = "HGS HALL Team";
                                                mailDetails.Subject = emailEntity[0].EmailSubject;
                                                string emailBody = string.Empty;
                                                emailBody = emailEntity[0].EmailBody;
                                                emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                                emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                                emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                                //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                                mailDetails.MailActualBody = emailBody;
                                                string outputResult = string.Empty;
                                                try
                                                {
                                                    outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "10", outputResult);

                                                    _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                                }
                                                catch (Exception ex)
                                                {

                                                    _serviceconnect.LogConnect("AssignFSTLCourse", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                                }


                                            }

                                            //  send Email To Employee



                                        }
                                        catch (Exception ex)
                                        {
                                            _serviceconnect.LogConnect("AssignFSTLCourse", "1024", ex.Message, "Exception");
                                            response.responseCode = 0;
                                            response.responseMessage = ex.Message;
                                        }



                                    }
                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignFSTLCourse", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignFSTLCourseData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_fstl_courses
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourseData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AssignFSTLCourseEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_fstl_course
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourseData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public ResponseClass AssignFSTLAssignment()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignFSTLAssessmentData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLAssignment", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AssignFSTLAssessmentEvent(Convert.ToString(item["EmployeeCode"]));
                                    if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    {
                                        foreach (DataRow eventdata in dtCourse.Rows)
                                        {
                                            try
                                            {

                                                //  string ccEmail = string.Empty;
                                                if (emailEntity != null && emailEntity.Count > 0)
                                                {
                                                    MailDetails mailDetails = new MailDetails();
                                                    mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                                    // set to list
                                                    List<ToList> lstToList = new List<ToList>();
                                                    ToList to = new ToList();
                                                    to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                                    lstToList.Add(to);
                                                    mailDetails.ToList = lstToList;

                                                    List<BCCList> lstBCC = new List<BCCList>();

                                                    if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                                    {
                                                        string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                                        foreach (string email in bccList)
                                                        {
                                                            BCCList bcc = new BCCList();
                                                            bcc.EmailAddress = email.ToString();
                                                            lstBCC.Add(bcc);
                                                        }

                                                        mailDetails.bCCLists = lstBCC;
                                                    }

                                                    mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                                    mailDetails.SenderName = "HGS HALL Team";
                                                    mailDetails.Subject = emailEntity[0].EmailSubject;
                                                    string emailBody = string.Empty;
                                                    emailBody = emailEntity[0].EmailBody;
                                                    emailBody = emailBody.Replace("@Employee@", Convert.ToString(eventdata["empname"]));
                                                    emailBody = emailBody.Replace("*assettype*", Convert.ToString(eventdata["assettype"]));
                                                    emailBody = emailBody.Replace("*coursename*", Convert.ToString(eventdata["coursename"]));
                                                    // emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                                    mailDetails.MailActualBody = emailBody;
                                                    string outputResult = string.Empty;
                                                    try
                                                    {
                                                        outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                        int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "10", outputResult);

                                                        //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                                    }
                                                    catch (Exception ex)
                                                    {

                                                        _serviceconnect.LogConnect("AssignFSTLAssignment", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                                        response.responseCode = 0;
                                                        response.responseMessage = ex.Message;
                                                        return response;
                                                    }


                                                }

                                                // send Email To Employee




                                                //return response;
                                            }
                                            catch (Exception ex)
                                            {
                                                _serviceconnect.LogConnect("AssignFSTLAssignment", "1024", ex.Message, "Exception");
                                                response.responseCode = 0;
                                                response.responseMessage = ex.Message;
                                                return response;
                                            }
                                            //finally
                                            //{
                                            //    npgCon.Close();
                                            //}
                                        }
                                    }

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignFSTLAssignment", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                                return response;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignFSTLAssessmentData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_fstl_assessment
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourseData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AssignFSTLAssessmentEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_fstl_assessment
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourseData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public ResponseClass SendFSTLCertificateEmail()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };

                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = GetFSTLCertificateData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("certificateallocation", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    try
                                    {

                                        //  string ccEmail = string.Empty;
                                        if (emailEntity != null && emailEntity.Count > 0)
                                        {
                                            MailDetails mailDetails = new MailDetails();
                                            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                            // set to list
                                            List<ToList> lstToList = new List<ToList>();
                                            ToList to = new ToList();
                                            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                            lstToList.Add(to);
                                            mailDetails.ToList = lstToList;

                                            List<BCCList> lstBCC = new List<BCCList>();

                                            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                            {
                                                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                                foreach (string email in bccList)
                                                {
                                                    BCCList bcc = new BCCList();
                                                    bcc.EmailAddress = email.ToString();
                                                    lstBCC.Add(bcc);
                                                }

                                                mailDetails.bCCLists = lstBCC;
                                            }

                                            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                            mailDetails.SenderName = "HGS HALL Team";
                                            mailDetails.Subject = emailEntity[0].EmailSubject;
                                            string emailBody = string.Empty;
                                            emailBody = emailEntity[0].EmailBody;
                                            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                            emailBody = emailBody.Replace("*certificatename*", Convert.ToString(item["certificatename"]));
                                            emailBody = emailBody.Replace("*certificatedate*", Convert.ToString(item["certificatedate"]));

                                            mailDetails.MailActualBody = emailBody;
                                            string outputResult = string.Empty;
                                            try
                                            {
                                                string ccID = Convert.ToString(item["checkID"]);

                                                // outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", ccID, "11", outputResult);

                                                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                            }
                                            catch (Exception ex)
                                            {

                                                _serviceconnect.LogConnect("SendFSTLCertificateEmail", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                            }


                                        }

                                        // send Email To Employee




                                        //return response;
                                    }
                                    catch (Exception ex)
                                    {
                                        _serviceconnect.LogConnect("SendFSTLCertificateEmail", "1024", ex.Message, "Exception");
                                        response.responseCode = 0;
                                        response.responseMessage = ex.Message;
                                    }

                                }


                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("SendFSTLCertificateEmail", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }

                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("SendFSTLCertificateEmail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable GetFSTLCertificateData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_fstl_certificatedata
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetFSTLCertificateData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }


        public ResponseClass AssignFSTLSurvey()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignFSTLSurveyData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));


                                //string sqlQuery = "call prc_allocate_fstl_course('" + Convert.ToString(item["EmployeeCode"]) + "')";
                                //npgCon.Open();
                                //// Define a command to call  procedure
                                //NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
                                //NpgsqlDataReader rdr = cmd.ExecuteReader();
                                //npgCon.Close();

                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AssignFSTLSurveyEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    foreach (DataRow drrow in dtCourse.Rows)
                                    //    {
                                    //        if (Convert.ToInt32(drrow["assestcode"]) > 0)
                                    //        {
                                    //            try
                                    //            {
                                    //                surveyAllocationRequestDTO srv = new surveyAllocationRequestDTO();
                                    //                surveyAllocationResponseDTO res = new surveyAllocationResponseDTO();
                                    //                srv.LoggedInEmployeeId = "246420";

                                    //                srv.SurveyId = Convert.ToInt32(drrow["assestcode"]);
                                    //                srv.LstEmployeeIds = new List<string>();
                                    //                srv.LstEmployeeIds.Add(Convert.ToString(item["EmployeeCode"]));

                                    //                string resData = _serviceconnect.insertSurveyAllocation(srv);
                                    //                res = JsonConvert.DeserializeObject<surveyAllocationResponseDTO>(resData);
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }
                                    //        }

                                    //    }

                                    //    foreach (DataRow eventdata in dtCourse.Rows)
                                    //    {
                                    //        try
                                    //        {

                                    //            //  string ccEmail = string.Empty;
                                    //            if (emailEntity != null && emailEntity.Count > 0)
                                    //            {
                                    //                MailDetails mailDetails = new MailDetails();
                                    //                mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //                // set to list
                                    //                List<ToList> lstToList = new List<ToList>();
                                    //                ToList to = new ToList();
                                    //                to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //                lstToList.Add(to);
                                    //                mailDetails.ToList = lstToList;

                                    //                List<BCCList> lstBCC = new List<BCCList>();

                                    //                if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //                {
                                    //                    string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                    foreach (string email in bccList)
                                    //                    {
                                    //                        BCCList bcc = new BCCList();
                                    //                        bcc.EmailAddress = email.ToString();
                                    //                        lstBCC.Add(bcc);
                                    //                    }

                                    //                    mailDetails.bCCLists = lstBCC;
                                    //                }

                                    //                mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //                mailDetails.SenderName = "HGS HALL Team";
                                    //                mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //                string emailBody = string.Empty;
                                    //                emailBody = emailEntity[0].EmailBody;
                                    //                emailBody = emailBody.Replace("@Employee@", Convert.ToString(eventdata["empname"]));
                                    //                emailBody = emailBody.Replace("*assettype*", Convert.ToString(eventdata["assettype"]));
                                    //                emailBody = emailBody.Replace("*coursename*", Convert.ToString(eventdata["coursename"]));
                                    //                emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //                mailDetails.MailActualBody = emailBody;
                                    //                string outputResult = string.Empty;
                                    //                try
                                    //                {
                                    //                    outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                    //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //                }
                                    //                catch (Exception ex)
                                    //                {

                                    //                    _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //                }


                                    //            }

                                    //            // send Email To Employee




                                    //            //return response;
                                    //        }
                                    //        catch (Exception ex)
                                    //        {
                                    //            _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", ex.Message, "Exception");
                                    //            response.responseCode = 0;
                                    //            response.responseMessage = ex.Message;
                                    //        }
                                    //        //finally
                                    //        //{
                                    //        //    npgCon.Close();
                                    //        //}
                                    //    }
                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignFSTLSurveyData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_fstl_survey
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLSurveyData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AssignFSTLSurveyEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_fstl_survey
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLSurveyEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public ResponseClass UploadFSTLData()
        {
            ResponseClass response = new ResponseClass();

            DataTable dtEmployees = new DataTable();
            string sb = string.Empty;

            dtEmployees = GetUploadFSTLData();
            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
            {
                foreach (DataRow item in dtEmployees.Rows)
                {
                    DataTable dtResult = new DataTable();
                    DateTime dtCCDate = new DateTime();
                    dtCCDate = Convert.ToDateTime(Convert.ToString(item["CompletionDate"]));
                    dtResult = UploadFSTLCompletionData(Convert.ToString(item["EMPCode"]).Trim(), dtCCDate.ToString("yyyy-MM-dd"));
                }
            }

            return response;
        }

        public DataTable GetUploadFSTLData()
        {
            ResponseClass response = new ResponseClass();

            DataTable trainingGroup = new DataTable();
            string selectQuery = string.Empty;
            selectQuery = "select #EMPCode#,#CompletionDate# from #TempFSTLCourse# TT inner join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=TT.#EMPCode# where  EMP.#Active_Separated# = 'Active' and TT.#OnlyAssessment#=1";
            selectQuery = selectQuery.Replace('#', '"');
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(trainingGroup);
            npgsql.Close();


            return trainingGroup;
        }

        public DataTable UploadFSTLCompletionData(string employeecode, string completionDate)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                if (!string.IsNullOrEmpty(completionDate))
                {

                }
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_projectframework_course_completion
                                                                    ( 
                                                                        :p_employee_code,:p_date
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(completionDate))
                            cmd.Parameters.AddWithValue("p_date", DbType.String).Value = completionDate;
                        else
                            cmd.Parameters.AddWithValue("p_date", DbType.String).Value = string.Empty;
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourseData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  Add pending user to HAll

        public ResponseClass addPendingUserToHall()
        {
            ResponseClass response = new ResponseClass();

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_pending_user_to_hall
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("addPendingUserToHall", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            response.responseCode = 1;
            response.responseMessage = "SUCCESS";
            return response;
        }

        #endregion

        #region  SEED GENERAL

        public ResponseClass AssignSEEDGeneralEvent()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignSEEDGeneralDataEvent();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AssignSEEDGeneralCourseEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    try
                                    //    {

                                    //        //  string ccEmail = string.Empty;
                                    //        if (emailEntity != null && emailEntity.Count > 0)
                                    //        {
                                    //            MailDetails mailDetails = new MailDetails();
                                    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //            // set to list
                                    //            List<ToList> lstToList = new List<ToList>();
                                    //            ToList to = new ToList();
                                    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //            lstToList.Add(to);
                                    //            mailDetails.ToList = lstToList;

                                    //            List<BCCList> lstBCC = new List<BCCList>();

                                    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //            {
                                    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                foreach (string email in bccList)
                                    //                {
                                    //                    BCCList bcc = new BCCList();
                                    //                    bcc.EmailAddress = email.ToString();
                                    //                    lstBCC.Add(bcc);
                                    //                }

                                    //                mailDetails.bCCLists = lstBCC;
                                    //            }

                                    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //            mailDetails.SenderName = "HGS HALL Team";
                                    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //            string emailBody = string.Empty;
                                    //            emailBody = emailEntity[0].EmailBody;
                                    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //            mailDetails.MailActualBody = emailBody;
                                    //            string outputResult = string.Empty;
                                    //            try
                                    //            {
                                    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignSEEDGeneralEvent", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }


                                    //        }

                                    //        // send Email To Employee




                                    //        //return response;
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        _serviceconnect.LogConnect("AssignSEEDGeneralEvent", "1024", ex.Message, "Exception");
                                    //        response.responseCode = 0;
                                    //        response.responseMessage = ex.Message;
                                    //    }


                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignSEEDGeneralEvent", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDGeneralEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignSEEDGeneralDataEvent()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_seed_course_general
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDGeneralDataEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AssignSEEDGeneralCourseEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_seed_general_course
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDGeneralCourseEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  SEED TL

        public ResponseClass AssignSEEDTeamLeadEvent()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignSEEDTeamLeadDataEvent();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AssignSEEDTeamLeadCourseEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    try
                                    //    {

                                    //        //  string ccEmail = string.Empty;
                                    //        if (emailEntity != null && emailEntity.Count > 0)
                                    //        {
                                    //            MailDetails mailDetails = new MailDetails();
                                    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //            // set to list
                                    //            List<ToList> lstToList = new List<ToList>();
                                    //            ToList to = new ToList();
                                    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //            lstToList.Add(to);
                                    //            mailDetails.ToList = lstToList;

                                    //            List<BCCList> lstBCC = new List<BCCList>();

                                    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //            {
                                    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                foreach (string email in bccList)
                                    //                {
                                    //                    BCCList bcc = new BCCList();
                                    //                    bcc.EmailAddress = email.ToString();
                                    //                    lstBCC.Add(bcc);
                                    //                }

                                    //                mailDetails.bCCLists = lstBCC;
                                    //            }

                                    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //            mailDetails.SenderName = "HGS HALL Team";
                                    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //            string emailBody = string.Empty;
                                    //            emailBody = emailEntity[0].EmailBody;
                                    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //            mailDetails.MailActualBody = emailBody;
                                    //            string outputResult = string.Empty;
                                    //            try
                                    //            {
                                    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignSEEDTeamLeadEvent", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }


                                    //        }

                                    //        // send Email To Employee




                                    //        //return response;
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        _serviceconnect.LogConnect("AssignSEEDTeamLeadEvent", "1024", ex.Message, "Exception");
                                    //        response.responseCode = 0;
                                    //        response.responseMessage = ex.Message;
                                    //    }


                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignSEEDTeamLeadEvent", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDTeamLeadEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignSEEDTeamLeadDataEvent()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_seed_course_teamlead
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDTeamLeadDataEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AssignSEEDTeamLeadCourseEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_seed_teamlead_course
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDTeamLeadCourseEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  SEED AGENT

        public ResponseClass AssignSEEDAgentEvent()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignSEEDAgentDataEvent();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AssignSEEDAgentCourseEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    try
                                    //    {

                                    //        //  string ccEmail = string.Empty;
                                    //        if (emailEntity != null && emailEntity.Count > 0)
                                    //        {
                                    //            MailDetails mailDetails = new MailDetails();
                                    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //            // set to list
                                    //            List<ToList> lstToList = new List<ToList>();
                                    //            ToList to = new ToList();
                                    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //            lstToList.Add(to);
                                    //            mailDetails.ToList = lstToList;

                                    //            List<BCCList> lstBCC = new List<BCCList>();

                                    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //            {
                                    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                foreach (string email in bccList)
                                    //                {
                                    //                    BCCList bcc = new BCCList();
                                    //                    bcc.EmailAddress = email.ToString();
                                    //                    lstBCC.Add(bcc);
                                    //                }

                                    //                mailDetails.bCCLists = lstBCC;
                                    //            }

                                    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //            mailDetails.SenderName = "HGS HALL Team";
                                    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //            string emailBody = string.Empty;
                                    //            emailBody = emailEntity[0].EmailBody;
                                    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //            mailDetails.MailActualBody = emailBody;
                                    //            string outputResult = string.Empty;
                                    //            try
                                    //            {
                                    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignSEEDTeamLeadEvent", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }


                                    //        }

                                    //        // send Email To Employee




                                    //        //return response;
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        _serviceconnect.LogConnect("AssignSEEDTeamLeadEvent", "1024", ex.Message, "Exception");
                                    //        response.responseCode = 0;
                                    //        response.responseMessage = ex.Message;
                                    //    }


                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignSEEDTeamLeadEvent", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDTeamLeadEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignSEEDAgentDataEvent()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_seed_course_agent
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDTeamLeadDataEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AssignSEEDAgentCourseEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_seed_agent_course
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDTeamLeadCourseEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  DI Course

        public ResponseClass AssignDICourse()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignDICourseDataEvent();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AllocateDICourseEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    try
                                    //    {

                                    //        //  string ccEmail = string.Empty;
                                    //        if (emailEntity != null && emailEntity.Count > 0)
                                    //        {
                                    //            MailDetails mailDetails = new MailDetails();
                                    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //            // set to list
                                    //            List<ToList> lstToList = new List<ToList>();
                                    //            ToList to = new ToList();
                                    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //            lstToList.Add(to);
                                    //            mailDetails.ToList = lstToList;

                                    //            List<BCCList> lstBCC = new List<BCCList>();

                                    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //            {
                                    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                foreach (string email in bccList)
                                    //                {
                                    //                    BCCList bcc = new BCCList();
                                    //                    bcc.EmailAddress = email.ToString();
                                    //                    lstBCC.Add(bcc);
                                    //                }

                                    //                mailDetails.bCCLists = lstBCC;
                                    //            }

                                    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //            mailDetails.SenderName = "HGS HALL Team";
                                    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //            string emailBody = string.Empty;
                                    //            emailBody = emailEntity[0].EmailBody;
                                    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //            mailDetails.MailActualBody = emailBody;
                                    //            string outputResult = string.Empty;
                                    //            try
                                    //            {
                                    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignDICourse", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }


                                    //        }

                                    //        // send Email To Employee




                                    //        //return response;
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                    //        response.responseCode = 0;
                                    //        response.responseMessage = ex.Message;
                                    //    }


                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignDICourseDataEvent()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_dni_courses
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignDICourseDataEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AllocateDICourseEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_dni_course
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignSEEDTeamLeadCourseEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  DI Assessment

        public ResponseClass AssignDIAssessment()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignDIAssessmentDataEvent();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AllocateDIAssessmentEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    try
                                    //    {

                                    //        //  string ccEmail = string.Empty;
                                    //        if (emailEntity != null && emailEntity.Count > 0)
                                    //        {
                                    //            MailDetails mailDetails = new MailDetails();
                                    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //            // set to list
                                    //            List<ToList> lstToList = new List<ToList>();
                                    //            ToList to = new ToList();
                                    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //            lstToList.Add(to);
                                    //            mailDetails.ToList = lstToList;

                                    //            List<BCCList> lstBCC = new List<BCCList>();

                                    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //            {
                                    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                foreach (string email in bccList)
                                    //                {
                                    //                    BCCList bcc = new BCCList();
                                    //                    bcc.EmailAddress = email.ToString();
                                    //                    lstBCC.Add(bcc);
                                    //                }

                                    //                mailDetails.bCCLists = lstBCC;
                                    //            }

                                    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //            mailDetails.SenderName = "HGS HALL Team";
                                    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //            string emailBody = string.Empty;
                                    //            emailBody = emailEntity[0].EmailBody;
                                    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //            mailDetails.MailActualBody = emailBody;
                                    //            string outputResult = string.Empty;
                                    //            try
                                    //            {
                                    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignDICourse", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }


                                    //        }

                                    //        // send Email To Employee




                                    //        //return response;
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                    //        response.responseCode = 0;
                                    //        response.responseMessage = ex.Message;
                                    //    }


                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignDIAssessmentDataEvent()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_dni_assessment
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignDIAssessmentDataEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AllocateDIAssessmentEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_dni_assessment
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AllocateDIAssessmentEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public ResponseClass SendDNICertificateEmail()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };

                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = GetDNICertificateData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("certificateallocation", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    try
                                    {

                                        //  string ccEmail = string.Empty;
                                        if (emailEntity != null && emailEntity.Count > 0)
                                        {
                                            MailDetails mailDetails = new MailDetails();
                                            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                            // set to list
                                            List<ToList> lstToList = new List<ToList>();
                                            ToList to = new ToList();
                                            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                            lstToList.Add(to);
                                            mailDetails.ToList = lstToList;

                                            List<BCCList> lstBCC = new List<BCCList>();

                                            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                            {
                                                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                                foreach (string email in bccList)
                                                {
                                                    BCCList bcc = new BCCList();
                                                    bcc.EmailAddress = email.ToString();
                                                    lstBCC.Add(bcc);
                                                }

                                                mailDetails.bCCLists = lstBCC;
                                            }

                                            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                            mailDetails.SenderName = "HGS HALL Team";
                                            mailDetails.Subject = emailEntity[0].EmailSubject;
                                            string emailBody = string.Empty;
                                            emailBody = emailEntity[0].EmailBody;
                                            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                            emailBody = emailBody.Replace("*certificatename*", Convert.ToString(item["certificatename"]));
                                            emailBody = emailBody.Replace("*certificatedate*", Convert.ToString(item["certificatedate"]));

                                            mailDetails.MailActualBody = emailBody;
                                            string outputResult = string.Empty;
                                            try
                                            {
                                                string ccID = Convert.ToString(item["checkID"]);

                                                //outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", ccID, "11", outputResult);

                                                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                            }
                                            catch (Exception ex)
                                            {

                                                _serviceconnect.LogConnect("SendDNICertificateEmail", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                            }


                                        }

                                        // send Email To Employee




                                        //return response;
                                    }
                                    catch (Exception ex)
                                    {
                                        _serviceconnect.LogConnect("SendDNICertificateEmail", "1024", ex.Message, "Exception");
                                        response.responseCode = 0;
                                        response.responseMessage = ex.Message;
                                    }

                                }


                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("SendDNICertificateEmail", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }

                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("SendDNICertificateEmail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable GetDNICertificateData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_dni_certificatedata
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetDNICertificateData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        // DNI Upload

        public ResponseClass UploadDNIData()
        {
            ResponseClass response = new ResponseClass();

            DataTable dtEmployees = new DataTable();
            string sb = string.Empty;

            dtEmployees = GetUploadDNIData();
            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
            {
                foreach (DataRow item in dtEmployees.Rows)
                {
                    DataTable dtResult = new DataTable();
                    DateTime dtCCDate = new DateTime();
                    dtCCDate = Convert.ToDateTime(Convert.ToString(item["entered_date"]));
                    dtResult = UploadDNICompletionData(Convert.ToString(item["EMPCode"]).Trim(), dtCCDate.ToString("yyyy-MM-dd"));
                }
            }

            return response;
        }

        public DataTable GetUploadDNIData()
        {
            ResponseClass response = new ResponseClass();

            DataTable trainingGroup = new DataTable();
            string selectQuery = string.Empty;
            //selectQuery = "select #EMPCode#,#CompletionDate# from #TempFSTLCourse#";
            selectQuery = selectQuery + "select TR.empcode,B.entered_date from ";
            selectQuery = selectQuery + "( ";
            selectQuery = selectQuery + " select empcode from #tempFSTLCourseCompletionOld# ";
            selectQuery = selectQuery + " intersect ";
            selectQuery = selectQuery + " select empcode from #tempFSTLAssessmentCompletedOld# ";
            selectQuery = selectQuery + " ) TR ";
            selectQuery = selectQuery + " inner join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE# = TR.empcode ";
            selectQuery = selectQuery + " left join #tempFSTLAssessmentCompletedOld# B on TR.empcode = B.empcode ";
            selectQuery = selectQuery + " where EMP.#Active_Separated# = 'Active' ";
            selectQuery = selectQuery.Replace('#', '"');
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(trainingGroup);
            npgsql.Close();


            return trainingGroup;
        }

        public DataTable UploadDNICompletionData(string employeecode, string completionDate)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                if (!string.IsNullOrEmpty(completionDate))
                {

                }
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_dni_course_completion
                                                                    ( 
                                                                        :p_employee_code,:p_date
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(completionDate))
                            cmd.Parameters.AddWithValue("p_date", DbType.String).Value = completionDate;
                        else
                            cmd.Parameters.AddWithValue("p_date", DbType.String).Value = string.Empty;
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourseData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  Project Framework Course

        public ResponseClass ProjectFrameworkCourse()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = ProjectFrameworkCourseDataEvent();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AllocateProjectFrameworkCourseEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    try
                                    //    {

                                    //        //  string ccEmail = string.Empty;
                                    //        if (emailEntity != null && emailEntity.Count > 0)
                                    //        {
                                    //            MailDetails mailDetails = new MailDetails();
                                    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //            // set to list
                                    //            List<ToList> lstToList = new List<ToList>();
                                    //            ToList to = new ToList();
                                    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //            lstToList.Add(to);
                                    //            mailDetails.ToList = lstToList;

                                    //            List<BCCList> lstBCC = new List<BCCList>();

                                    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //            {
                                    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                foreach (string email in bccList)
                                    //                {
                                    //                    BCCList bcc = new BCCList();
                                    //                    bcc.EmailAddress = email.ToString();
                                    //                    lstBCC.Add(bcc);
                                    //                }

                                    //                mailDetails.bCCLists = lstBCC;
                                    //            }

                                    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //            mailDetails.SenderName = "HGS HALL Team";
                                    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //            string emailBody = string.Empty;
                                    //            emailBody = emailEntity[0].EmailBody;
                                    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //            mailDetails.MailActualBody = emailBody;
                                    //            string outputResult = string.Empty;
                                    //            try
                                    //            {
                                    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignDICourse", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }


                                    //        }

                                    //        // send Email To Employee




                                    //        //return response;
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                    //        response.responseCode = 0;
                                    //        response.responseMessage = ex.Message;
                                    //    }


                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("ProjectFrameworkCourse", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ProjectFrameworkCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable ProjectFrameworkCourseDataEvent()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_projectframework_courses
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ProjectFrameworkCourseDataEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AllocateProjectFrameworkCourseEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_projectframework_course
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AllocateProjectFrameworkCourseEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  Project Framework Assessment

        public ResponseClass ProjectFrameworkAssessment()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignProjectFrameworkAssessmentDataEvent();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AllocateProjectFrameworkAssessmentEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    try
                                    //    {

                                    //        //  string ccEmail = string.Empty;
                                    //        if (emailEntity != null && emailEntity.Count > 0)
                                    //        {
                                    //            MailDetails mailDetails = new MailDetails();
                                    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //            // set to list
                                    //            List<ToList> lstToList = new List<ToList>();
                                    //            ToList to = new ToList();
                                    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //            lstToList.Add(to);
                                    //            mailDetails.ToList = lstToList;

                                    //            List<BCCList> lstBCC = new List<BCCList>();

                                    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //            {
                                    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                foreach (string email in bccList)
                                    //                {
                                    //                    BCCList bcc = new BCCList();
                                    //                    bcc.EmailAddress = email.ToString();
                                    //                    lstBCC.Add(bcc);
                                    //                }

                                    //                mailDetails.bCCLists = lstBCC;
                                    //            }

                                    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //            mailDetails.SenderName = "HGS HALL Team";
                                    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //            string emailBody = string.Empty;
                                    //            emailBody = emailEntity[0].EmailBody;
                                    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //            mailDetails.MailActualBody = emailBody;
                                    //            string outputResult = string.Empty;
                                    //            try
                                    //            {
                                    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignDICourse", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }


                                    //        }

                                    //        // send Email To Employee




                                    //        //return response;
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                    //        response.responseCode = 0;
                                    //        response.responseMessage = ex.Message;
                                    //    }


                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignProjectFrameworkAssessmentDataEvent()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_pf_assessment
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignDIAssessmentDataEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AllocateProjectFrameworkAssessmentEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_pf_assessment
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AllocateDIAssessmentEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region Project Framework Survey

        public ResponseClass AssignPFSurvey()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AssignPFSurveyData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));


                                //string sqlQuery = "call prc_allocate_fstl_course('" + Convert.ToString(item["EmployeeCode"]) + "')";
                                //npgCon.Open();
                                //// Define a command to call  procedure
                                //NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
                                //NpgsqlDataReader rdr = cmd.ExecuteReader();
                                //npgCon.Close();

                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AssignPFSurveyEvent(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    foreach (DataRow drrow in dtCourse.Rows)
                                    //    {
                                    //        if (Convert.ToInt32(drrow["assestcode"]) > 0)
                                    //        {
                                    //            try
                                    //            {
                                    //                surveyAllocationRequestDTO srv = new surveyAllocationRequestDTO();
                                    //                surveyAllocationResponseDTO res = new surveyAllocationResponseDTO();
                                    //                srv.LoggedInEmployeeId = "246420";

                                    //                srv.SurveyId = Convert.ToInt32(drrow["assestcode"]);
                                    //                srv.LstEmployeeIds = new List<string>();
                                    //                srv.LstEmployeeIds.Add(Convert.ToString(item["EmployeeCode"]));

                                    //                string resData = _serviceconnect.insertSurveyAllocation(srv);
                                    //                res = JsonConvert.DeserializeObject<surveyAllocationResponseDTO>(resData);
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }
                                    //        }

                                    //    }

                                    //    foreach (DataRow eventdata in dtCourse.Rows)
                                    //    {
                                    //        try
                                    //        {

                                    //            //  string ccEmail = string.Empty;
                                    //            if (emailEntity != null && emailEntity.Count > 0)
                                    //            {
                                    //                MailDetails mailDetails = new MailDetails();
                                    //                mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //                // set to list
                                    //                List<ToList> lstToList = new List<ToList>();
                                    //                ToList to = new ToList();
                                    //                to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //                lstToList.Add(to);
                                    //                mailDetails.ToList = lstToList;

                                    //                List<BCCList> lstBCC = new List<BCCList>();

                                    //                if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //                {
                                    //                    string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                    foreach (string email in bccList)
                                    //                    {
                                    //                        BCCList bcc = new BCCList();
                                    //                        bcc.EmailAddress = email.ToString();
                                    //                        lstBCC.Add(bcc);
                                    //                    }

                                    //                    mailDetails.bCCLists = lstBCC;
                                    //                }

                                    //                mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //                mailDetails.SenderName = "HGS HALL Team";
                                    //                mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //                string emailBody = string.Empty;
                                    //                emailBody = emailEntity[0].EmailBody;
                                    //                emailBody = emailBody.Replace("@Employee@", Convert.ToString(eventdata["empname"]));
                                    //                emailBody = emailBody.Replace("*assettype*", Convert.ToString(eventdata["assettype"]));
                                    //                emailBody = emailBody.Replace("*coursename*", Convert.ToString(eventdata["coursename"]));
                                    //                emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //                mailDetails.MailActualBody = emailBody;
                                    //                string outputResult = string.Empty;
                                    //                try
                                    //                {
                                    //                    outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                    //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //                }
                                    //                catch (Exception ex)
                                    //                {

                                    //                    _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //                }


                                    //            }

                                    //            // send Email To Employee




                                    //            //return response;
                                    //        }
                                    //        catch (Exception ex)
                                    //        {
                                    //            _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", ex.Message, "Exception");
                                    //            response.responseCode = 0;
                                    //            response.responseMessage = ex.Message;
                                    //        }
                                    //        //finally
                                    //        //{
                                    //        //    npgCon.Close();
                                    //        //}
                                    //    }
                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLSurvey", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AssignPFSurveyData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_pf_survey
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLSurveyData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AssignPFSurveyEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_pf_survey
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLSurveyEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region  Add new joinee in existing event

        public ResponseClass AddNewEmployeeInExisitingEvent()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = AddNewEmployeeInExisitingEventData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        //   emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {
                                DataTable dtCourse = new DataTable();
                                dtCourse = AssignAddNewEmployeeInExisitingEvent(Convert.ToString(item["EmployeeCode"]));


                                // string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                //if (emailEntity != null && emailEntity.Count > 0)
                                //{

                                //    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                //    //{
                                //    //    try
                                //    //    {

                                //    //        //  string ccEmail = string.Empty;
                                //    //        if (emailEntity != null && emailEntity.Count > 0)
                                //    //        {
                                //    //            MailDetails mailDetails = new MailDetails();
                                //    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                //    //            // set to list
                                //    //            List<ToList> lstToList = new List<ToList>();
                                //    //            ToList to = new ToList();
                                //    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                //    //            lstToList.Add(to);
                                //    //            mailDetails.ToList = lstToList;

                                //    //            List<BCCList> lstBCC = new List<BCCList>();

                                //    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                //    //            {
                                //    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                //    //                foreach (string email in bccList)
                                //    //                {
                                //    //                    BCCList bcc = new BCCList();
                                //    //                    bcc.EmailAddress = email.ToString();
                                //    //                    lstBCC.Add(bcc);
                                //    //                }

                                //    //                mailDetails.bCCLists = lstBCC;
                                //    //            }

                                //    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                //    //            mailDetails.SenderName = "HGS HALL Team";
                                //    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                //    //            string emailBody = string.Empty;
                                //    //            emailBody = emailEntity[0].EmailBody;
                                //    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                //    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                //    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                //    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                //    //            mailDetails.MailActualBody = emailBody;
                                //    //            string outputResult = string.Empty;
                                //    //            try
                                //    //            {
                                //    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                //    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                //    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                //    //            }
                                //    //            catch (Exception ex)
                                //    //            {

                                //    //                _serviceconnect.LogConnect("AssignDICourse", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                //    //            }


                                //    //        }

                                //    //        // send Email To Employee




                                //    //        //return response;
                                //    //    }
                                //    //    catch (Exception ex)
                                //    //    {
                                //    //        _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                //    //        response.responseCode = 0;
                                //    //        response.responseMessage = ex.Message;
                                //    //    }


                                //    //}

                                //}

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AddNewEmployeeInExisitingEvent", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AddNewEmployeeInExisitingEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable AddNewEmployeeInExisitingEventData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_exisiting_event
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AddNewEmployeeInExisitingEventData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AssignAddNewEmployeeInExisitingEvent(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_employees_exisiting_event
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignAddNewEmployeeInExisitingEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region   add skill

        public ResponseClass addEmployeeSkills()
        {
            ResponseClass response = new ResponseClass();

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM job_insert_employee_skills
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                        response.responseCode = 1;
                        response.responseMessage = "SUCCESS";

                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                _serviceconnect.LogConnect("AddNewEmployeeInExisitingEventData", "1024", ex.Message, "Exception");
            }



            return response;
        }


        #endregion

        #region   FSTL Report

        public ResponseClass FSTLReportJob()
        {
            ResponseClass response = new ResponseClass();

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM job_insert_fstl_report
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                        response.responseCode = 1;
                        response.responseMessage = "SUCCESS";

                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                _serviceconnect.LogConnect("FSTLReportJob", "1024", ex.Message, "Exception");
            }



            return response;
        }


        #endregion

        #region   ProjectFramework Report

        public ResponseClass ProjectFrameworkReportJob()
        {
            ResponseClass response = new ResponseClass();

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM job_insert_projectframework_report
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                        response.responseCode = 1;
                        response.responseMessage = "SUCCESS";

                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                _serviceconnect.LogConnect("ProjectFrameworkReportJob", "1024", ex.Message, "Exception");
            }



            return response;
        }

        public ResponseClass BOQReportJob()
        {
            ResponseClass response = new ResponseClass();

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM job_insert_boq_course_report
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                        response.responseCode = 1;
                        response.responseMessage = "SUCCESS";

                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                _serviceconnect.LogConnect("BOQReportJob", "1024", ex.Message, "Exception");
            }



            return response;
        }


        #endregion

        #region   Gamification

        public ResponseClass pushDataToGamification(pushDataToGamificationRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                SqlParameter[] parameter = {
                new SqlParameter("@eventcode", request.EventCode),
                new SqlParameter("@eventtype", request.EventType)
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = GamifificationdBConnection.ExecuteDataSet("PRC_Push_eventData", parameter, outParameters);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("pushDataToGamification", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }
            return response;

        }

        public int getParticipantScore(getparticipantgamificationscoreDTO request)
        {
            int response = 0;

            try
            {
                SqlParameter[] parameter = {
                new SqlParameter("@EmployeeID", request.EmployeeCode)
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = GamifificationdBConnection.ExecuteDataSet("Hall_Get_UserGamification_Balance", parameter, outParameters);
                if (dsResult!=null && dsResult.Tables[0].Rows.Count>0)
                {
                    response = Convert.ToInt32(dsResult.Tables[0].Rows[0]["EmployeePointsBalancedRewardPoints"]);
                }
            }
            catch (Exception ex)
            {
                return 0;

            }
            return response;

        }

        public DataTable getAdminGamificationCount(getparticipantgamificationscoreDTO request)
        {
            DataTable response = new DataTable();

            try
            {
                SqlParameter[] parameter = {
                new SqlParameter("@EmployeeID", request.EmployeeCode)
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = GamifificationdBConnection.ExecuteDataSet("PRC_GMN_GetManageGamification", parameter, outParameters);
                return dsResult.Tables[0];
            }
            catch (Exception ex)
            {
                return response;

            }
            

        }

        #endregion

        public ResponseClass PRCAssessessmentSummary()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                SqlParameter[] parameter = {

                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = AssessmentdBConnection.ExecuteDataSet("PRC_Assessment_Summary", parameter, outParameters);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("PRCAssessessmentSummary", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }
            return response;

        }


        #region Email Schedule Report

        public ResponseClass SendScheduleReportEmail()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = ScheduleReportEmailData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("EmailSchedule", "");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["ccemail"]));
                                string scheduleid = Convert.ToString(Convert.ToString(item["scheduleid"]));
                                string primaryid = Convert.ToString(Convert.ToString(item["primary_id"]));
                                string emaillink = Convert.ToString(Convert.ToString(item["emaillink"]));
                                string reportname = Convert.ToString(Convert.ToString(item["reportname"]));
                                string expirydate = Convert.ToString(Convert.ToString(item["expirydate"]));

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    try
                                    {

                                        // string ccEmail = string.Empty;
                                        if (emailEntity != null && emailEntity.Count > 0)
                                        {
                                            MailDetails mailDetails = new MailDetails();
                                            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                            //  set to list
                                            List<ToList> lstToList = new List<ToList>();
                                            ToList to = new ToList();
                                            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                            lstToList.Add(to);
                                            mailDetails.ToList = lstToList;

                                            List<BCCList> lstBCC = new List<BCCList>();

                                            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                            {
                                                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                                foreach (string email in bccList)
                                                {
                                                    BCCList bcc = new BCCList();
                                                    bcc.EmailAddress = email.ToString();
                                                    lstBCC.Add(bcc);
                                                }

                                                mailDetails.bCCLists = lstBCC;
                                            }

                                            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                            mailDetails.SenderName = "HGS HALL Team";
                                            mailDetails.Subject = emailEntity[0].EmailSubject;
                                            string emailBody = string.Empty;
                                            emailBody = emailEntity[0].EmailBody;
                                            string reportLink = string.Empty;
                                            reportLink = appSettings.Value.ApplicationUrl + "KnowledgeBase/ScheduleReport?reporttype=";
                                            reportLink = reportLink + emaillink;
                                            emailBody = emailBody.Replace("@@Link", Convert.ToString(reportLink));
                                            emailBody = emailBody.Replace("**Report**", Convert.ToString(reportname));
                                            emailBody = emailBody.Replace("**ExpireDate**", Convert.ToString(expirydate));
                                            mailDetails.Subject = mailDetails.Subject.Replace("**Report**", Convert.ToString(reportname));
                                            //emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                            //emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                            mailDetails.MailActualBody = emailBody;
                                            string outputResult = string.Empty;
                                            try
                                            {
                                                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                if (outputResult == "SUCCESS")
                                                {
                                                    UpdateScheduleReportStatus(scheduleid, primaryid);
                                                }

                                                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "10", outputResult);

                                                // _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                            }
                                            catch (Exception ex)
                                            {

                                                _serviceconnect.LogConnect("SendScheduleReportEmail", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                            }


                                        }

                                        //  send Email To Employee



                                    }
                                    catch (Exception ex)
                                    {
                                        _serviceconnect.LogConnect("SendScheduleReportEmail", "1024", ex.Message, "Exception");
                                        response.responseCode = 0;
                                        response.responseMessage = ex.Message;
                                    }
                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("SendScheduleReportEmail", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignFSTLCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable ScheduleReportEmailData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_schedule_report_data
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ScheduleReportEmailData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }


        public DataTable UpdateScheduleReportStatus(string scheduleid, string primaryid)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_update_trigger_status
                                                                    ( 
                                                                        :p_scheduleid,:p_primaryid
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(scheduleid))
                            cmd.Parameters.AddWithValue("p_scheduleid", DbType.String).Value = scheduleid;
                        else
                            cmd.Parameters.AddWithValue("p_scheduleid", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(primaryid))
                            cmd.Parameters.AddWithValue("p_primaryid", DbType.String).Value = primaryid;
                        else
                            cmd.Parameters.AddWithValue("p_primaryid", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("UpdateScheduleReportStatus", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region POSH
        public ResponseClass AssignPOSHTONewEmployee()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = GetPOSHNewJoinee();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("POSHINDIA", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AllocatePOSHToNewJoinee(Convert.ToString(item["EmployeeCode"]));

                                    if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    {
                                        try
                                        {

                                            // string ccEmail = string.Empty;
                                            if (emailEntity != null && emailEntity.Count > 0)
                                            {
                                                MailDetails mailDetails = new MailDetails();
                                                mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                                //  set to list
                                                List<ToList> lstToList = new List<ToList>();
                                                ToList to = new ToList();
                                                to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                                lstToList.Add(to);
                                                mailDetails.ToList = lstToList;

                                                List<BCCList> lstBCC = new List<BCCList>();

                                                if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                                {
                                                    string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                                    foreach (string email in bccList)
                                                    {
                                                        BCCList bcc = new BCCList();
                                                        bcc.EmailAddress = email.ToString();
                                                        lstBCC.Add(bcc);
                                                    }

                                                    mailDetails.bCCLists = lstBCC;
                                                }

                                                mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                                mailDetails.SenderName = "HGS HALL Team";
                                                mailDetails.Subject = emailEntity[0].EmailSubject;
                                                string emailBody = string.Empty;
                                                emailBody = emailEntity[0].EmailBody;
                                                emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                                emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                                emailBody = emailBody.Replace("*coursename*", Convert.ToString("POSH - INDIA"));
                                                //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                                mailDetails.MailActualBody = emailBody;
                                                string outputResult = string.Empty;
                                                try
                                                {
                                                    outputResult =MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", Convert.ToString(item["EmployeeCode"]), "10", outputResult);

                                                   // _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                                }
                                                catch (Exception ex)
                                                {

                                                    _serviceconnect.LogConnect("AssignPOSHTONewEmployee", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                                }


                                            }

                                            //  send Email To Employee



                                        }
                                        catch (Exception ex)
                                        {
                                            _serviceconnect.LogConnect("AssignPOSHTONewEmployee", "1024", ex.Message, "Exception");
                                            response.responseCode = 0;
                                            response.responseMessage = ex.Message;
                                        }



                                    }

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignPOSHTONewEmployee", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignPOSHTONewEmployee", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable GetPOSHNewJoinee()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_posh_program
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetPOSHNewJoinee", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AllocatePOSHToNewJoinee(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_posh_event
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AllocatePOSHToNewJoinee", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public ResponseClass PendingPoshEmail()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = GetPOSHPendingEmailData();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("POSHINDIA", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    //  DataTable dtCourse = new DataTable();
                                    //dtCourse = AllocatePOSHToNewJoinee(Convert.ToString(item["EmployeeCode"]));

                                    try
                                    {

                                        // string ccEmail = string.Empty;
                                        if (emailEntity != null && emailEntity.Count > 0)
                                        {
                                            MailDetails mailDetails = new MailDetails();
                                            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                            //  set to list
                                            List<ToList> lstToList = new List<ToList>();
                                            ToList to = new ToList();
                                            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                            lstToList.Add(to);
                                            mailDetails.ToList = lstToList;

                                            List<BCCList> lstBCC = new List<BCCList>();

                                            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                            {
                                                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                                foreach (string email in bccList)
                                                {
                                                    BCCList bcc = new BCCList();
                                                    bcc.EmailAddress = email.ToString();
                                                    lstBCC.Add(bcc);
                                                }

                                                mailDetails.bCCLists = lstBCC;
                                            }

                                            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                            mailDetails.SenderName = "HGS HALL Team";
                                            mailDetails.Subject = emailEntity[0].EmailSubject;
                                            string emailBody = string.Empty;
                                            emailBody = emailEntity[0].EmailBody;
                                            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                            emailBody = emailBody.Replace("*coursename*", Convert.ToString("POSH - INDIA"));
                                            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                            mailDetails.MailActualBody = emailBody;
                                            string outputResult = string.Empty;
                                            try
                                            {
                                                  var result =MailHelper.SendMailAsync(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                  int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", Convert.ToString(item["EmployeeCode"]), "10", result.Result);

                                                // _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                            }
                                            catch (Exception ex)
                                            {

                                                _serviceconnect.LogConnect("PendingPoshEmail", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                            }


                                        }

                                        //  send Email To Employee



                                    }
                                    catch (Exception ex)
                                    {
                                        _serviceconnect.LogConnect("PendingPoshEmail", "1024", ex.Message, "Exception");
                                        response.responseCode = 0;
                                        response.responseMessage = ex.Message;
                                    }

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("PendingPoshEmail", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("PendingPoshEmail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable GetPOSHPendingEmailData()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_posh_program_pending_email
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetPOSHPendingEmailData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region POSH Scheduler run on 1st April
        public ResponseClass AssignPOSHTOExistingEmployee()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = GetPOSHExistingEmployee();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("POSHINDIA", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AllocatePOSHToExistingEmployee(Convert.ToString(item["EmployeeCode"]));
                                    if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    {
                                        try
                                        {

                                            // string ccEmail = string.Empty;
                                            if (emailEntity != null && emailEntity.Count > 0)
                                            {
                                                MailDetails mailDetails = new MailDetails();
                                                mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                                //  set to list
                                                List<ToList> lstToList = new List<ToList>();
                                                ToList to = new ToList();
                                                to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                                lstToList.Add(to);
                                                mailDetails.ToList = lstToList;

                                                List<BCCList> lstBCC = new List<BCCList>();

                                                if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                                {
                                                    string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                                    foreach (string email in bccList)
                                                    {
                                                        BCCList bcc = new BCCList();
                                                        bcc.EmailAddress = email.ToString();
                                                        lstBCC.Add(bcc);
                                                    }

                                                    mailDetails.bCCLists = lstBCC;
                                                }

                                                mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                                mailDetails.SenderName = "HGS HALL Team";
                                                mailDetails.Subject = emailEntity[0].EmailSubject;
                                                string emailBody = string.Empty;
                                                emailBody = emailEntity[0].EmailBody;
                                                emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                                emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                                emailBody = emailBody.Replace("*coursename*", Convert.ToString("POSH - INDIA"));
                                                //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                                mailDetails.MailActualBody = emailBody;
                                                string outputResult = string.Empty;
                                                try
                                                {
                                                    outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                    int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "10", outputResult);

                                                    _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                                }
                                                catch (Exception ex)
                                                {

                                                    _serviceconnect.LogConnect("AssignPOSHTONewEmployee", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                                }


                                            }

                                            //  send Email To Employee



                                        }
                                        catch (Exception ex)
                                        {
                                            _serviceconnect.LogConnect("AssignPOSHTONewEmployee", "1024", ex.Message, "Exception");
                                            response.responseCode = 0;
                                            response.responseMessage = ex.Message;
                                        }



                                    }

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("AssignPOSHTOExistingEmployee", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignPOSHTOExistingEmployee", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable GetPOSHExistingEmployee()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_posh_program_exisitngemployees
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetPOSHExistingEmployee", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AllocatePOSHToExistingEmployee(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_posh_event
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AllocatePOSHToExistingEmployee", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion

        #region POSH Job

        public ResponseClass POSHReportJob()
        {
            ResponseClass response = new ResponseClass();

            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM job_insert_posh_course_report
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                        response.responseCode = 1;
                        response.responseMessage = "SUCCESS";

                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                _serviceconnect.LogConnect("BOQReportJob", "1024", ex.Message, "Exception");
            }



            return response;
        }

        #endregion



        #region  EEDS Columbia Employee

        public ResponseClass AssignEEDSColombiaAllEmployees()
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = EEDSColombiaAllEmployees();
                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("PendingECourseSequence", "");


                        // _serviceconnect.LogConnect("AssignFSTLCourse", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));



                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    DataTable dtCourse = new DataTable();
                                    dtCourse = AllocateEEDSColombiaAllEmployees(Convert.ToString(item["EmployeeCode"]));
                                    //if (dtCourse != null && dtCourse.Rows.Count > 0)
                                    //{
                                    //    try
                                    //    {

                                    //        //  string ccEmail = string.Empty;
                                    //        if (emailEntity != null && emailEntity.Count > 0)
                                    //        {
                                    //            MailDetails mailDetails = new MailDetails();
                                    //            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                    //            // set to list
                                    //            List<ToList> lstToList = new List<ToList>();
                                    //            ToList to = new ToList();
                                    //            to.EmailAddress = Convert.ToString(item["emailaddress"]);
                                    //            lstToList.Add(to);
                                    //            mailDetails.ToList = lstToList;

                                    //            List<BCCList> lstBCC = new List<BCCList>();

                                    //            if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                    //            {
                                    //                string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                    //                foreach (string email in bccList)
                                    //                {
                                    //                    BCCList bcc = new BCCList();
                                    //                    bcc.EmailAddress = email.ToString();
                                    //                    lstBCC.Add(bcc);
                                    //                }

                                    //                mailDetails.bCCLists = lstBCC;
                                    //            }

                                    //            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                    //            mailDetails.SenderName = "HGS HALL Team";
                                    //            mailDetails.Subject = emailEntity[0].EmailSubject;
                                    //            string emailBody = string.Empty;
                                    //            emailBody = emailEntity[0].EmailBody;
                                    //            emailBody = emailBody.Replace("@Employee@", Convert.ToString(item["empname"]));
                                    //            emailBody = emailBody.Replace("*assettype*", Convert.ToString("Course"));
                                    //            emailBody = emailBody.Replace("*coursename*", Convert.ToString("Functional Skills for Team Leaders (FSTL) training course"));
                                    //            //emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                    //            mailDetails.MailActualBody = emailBody;
                                    //            string outputResult = string.Empty;
                                    //            try
                                    //            {
                                    //                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                    //                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["EmailAddress"]), "", "", "6", outputResult);

                                    //                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                    //            }
                                    //            catch (Exception ex)
                                    //            {

                                    //                _serviceconnect.LogConnect("AssignDICourse", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                    //            }


                                    //        }

                                    //        // send Email To Employee




                                    //        //return response;
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        _serviceconnect.LogConnect("AssignDICourse", "1024", ex.Message, "Exception");
                                    //        response.responseCode = 0;
                                    //        response.responseMessage = ex.Message;
                                    //    }


                                    //}

                                }

                                // send Email To Employee




                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("ProjectFrameworkCourse", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                            }
                            //finally
                            //{
                            //    npgCon.Close();
                            //}
                        }



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ProjectFrameworkCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable EEDSColombiaAllEmployees()
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employees_projectframework_courses
                                                                    ( 
                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ProjectFrameworkCourseDataEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        public DataTable AllocateEEDSColombiaAllEmployees(string employeecode)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_projectframework_course
                                                                    ( 
                                                                        :p_employee_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(employeecode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AllocateProjectFrameworkCourseEvent", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }

        #endregion


        #region ChannelVideoNotification
        public ResponseClass ChannelVideoNotification(string videoid, string channelid)
        {


            List<EmailEntity> emailEntity = new List<EmailEntity>();
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            try
            {
                SqlParameter[] parameter = {

            };
                //string employeeCode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string sb = string.Empty;

                dtEmployees = GetChannelSubscribersData(videoid,channelid);

                if (dtEmployees != null)
                {
                    if (dtEmployees.Rows.Count > 0)
                    {
                        // get email template
                        emailEntity = _emailMGT.getEmailTemplate("channelvideonotification", "");


                        // _serviceconnect.LogConnect("AssignFSTLAssignment", "1024", Convert.ToString(dtEmployees.Rows.Count), "Information");
                        foreach (DataRow item in dtEmployees.Rows)
                        {
                            try
                            {

                                //string ccEmail = Convert.ToString(Convert.ToString(item["CCEmail"]));

                                // now first allocate event to employee code

                                if (emailEntity != null && emailEntity.Count > 0)
                                {
                                    try
                                    {

                                        //  string ccEmail = string.Empty;
                                        if (emailEntity != null && emailEntity.Count > 0)
                                        {
                                            MailDetails mailDetails = new MailDetails();
                                            mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;

                                            // set to list
                                            List<ToList> lstToList = new List<ToList>();
                                            ToList to = new ToList();
                                            to.EmailAddress = Convert.ToString(item["empemail"]);
                                            lstToList.Add(to);
                                            mailDetails.ToList = lstToList;

                                            List<BCCList> lstBCC = new List<BCCList>();

                                            //if (!string.IsNullOrEmpty(Convert.ToString(item["bcclist"])))
                                            //{
                                            //    string[] bccList = Convert.ToString(item["bcclist"]).Split(",");

                                            //    foreach (string email in bccList)
                                            //    {
                                            //        BCCList bcc = new BCCList();
                                            //        bcc.EmailAddress = email.ToString();
                                            //        lstBCC.Add(bcc);
                                            //    }

                                            //    mailDetails.bCCLists = lstBCC;
                                            //}

                                            mailDetails.Sender = appSettings.Value.SenderHGSHall;
                                            mailDetails.SenderName = "HGS HALL Team";
                                            mailDetails.Subject = emailEntity[0].EmailSubject;
                                            mailDetails.Subject = mailDetails.Subject.Replace("@channelname@", Convert.ToString(item["channelname"]));

                                            string emailBody = string.Empty;
                                            emailBody = emailEntity[0].EmailBody;
                                            emailBody = emailBody.Replace("@subscribername@", Convert.ToString(item["empname"]));
                                            emailBody = emailBody.Replace("@videotitle@", Convert.ToString(item["videotitle"]));
                                            emailBody = emailBody.Replace("@videodescription@", Convert.ToString(item["videodesc"]));
                                            emailBody = emailBody.Replace("@channelname@", Convert.ToString(item["channelname"]));
                                             
                                            string vdolink = appSettings.Value.ApplicationUrl + "CourseAdmin/WatchVideoChannel?channelcode=" + channelid + "&videocode=" + videoid;
                                            
                                            emailBody = emailBody.Replace("@@Link", vdolink);
                                            // emailBody = emailBody.Replace("*programmanager*", Convert.ToString(eventdata["programmanager"]));

                                            mailDetails.MailActualBody = emailBody;
                                            string outputResult = string.Empty;
                                            try
                                            {
                                                outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);

                                                int saveTransaction = _emailMGT.InsertEmailTransaction(mailDetails.Subject, emailBody, Convert.ToString(item["empemail"]), "", "", "10", outputResult);

                                                //  _serviceconnect.LogConnect("ecoursepending", "1024", emailBody, "Information");
                                            }
                                            catch (Exception ex)
                                            {

                                                _serviceconnect.LogConnect("ChannelVideoNotification", "1024", "Sending Email to Candidate : " + ex.Message, "Exception");
                                                response.responseCode = 0;
                                                response.responseMessage = ex.Message;
                                                return response;
                                            }


                                        }

                                        // send Email To Employee

                                        //return response;
                                    }
                                    catch (Exception ex)
                                    {
                                        _serviceconnect.LogConnect("ChannelVideoNotification", "1024", ex.Message, "Exception");
                                        response.responseCode = 0;
                                        response.responseMessage = ex.Message;
                                        return response;
                                    }

                                }


                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("ChannelVideoNotification", "1024", ex.Message, "Exception");
                                response.responseCode = 0;
                                response.responseMessage = ex.Message;
                                return response;
                            }
                            
                        }

                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ChannelVideoNotification", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable GetChannelSubscribersData(string videoid, string channelid)
        {
            DataTable dtCalenderConfig = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_getchannelsubscribersdata
                                                                    ( 
                                                                        :p_channelcode,
                                                                        :p_videocode
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        cmd.Parameters.AddWithValue("p_channelcode", DbType.String).Value = int.Parse(channelid);
                        cmd.Parameters.AddWithValue("p_videocode", DbType.String).Value = int.Parse(videoid);

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCalenderConfig);
                        npgsqlConnection.Close();

                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetChannelSubscribersData", "1024", ex.Message, "Exception");
            }



            return dtCalenderConfig;
        }
        #endregion
    }

    public class departmentList
    {
        public string departmentCode { get; set; }
    }
}
