﻿using System.Data;
using TLDCBAL.Common;

namespace TLDCBAL.Schedulers
{
    public interface ISchedulerBL
    {
        ResponseClass newJoiningAllocation();
        ResponseClass ISAPcalenderAllocation();
        ResponseClass updateModuleExpiration();
        ResponseClass isapFailureNotification();

        //ResponseClass weeklyInductionEmail();
        ResponseClass newjoineestatusupdate();
        ResponseClass getTreeData(getTreeDataRequest companyCode);

        ResponseClass ISAPcalenderStatusUpdate();

        ResponseClass ecoursepending();

        ResponseClass mytodopending();

        ResponseClass weeklyteamleadupdate();

        ResponseClass emailonpublishevent(string objectcode, string objecttype);

        ResponseClass AssignFSTLCourse();

        ResponseClass AssignFSTLAssignment();

        ResponseClass AssignFSTLSurvey();

        ResponseClass SendFSTLCertificateEmail();

        ResponseClass addPendingUserToHall();

        ResponseClass AssignSEEDGeneralEvent();

        ResponseClass AssignSEEDTeamLeadEvent();

        ResponseClass AssignSEEDAgentEvent();

        ResponseClass AssignDICourse();

        ResponseClass AssignDIAssessment();

        ResponseClass SendDNICertificateEmail();

        ResponseClass UploadFSTLData();

        ResponseClass UploadDNIData();

        ResponseClass ProjectFrameworkCourse();

        ResponseClass ProjectFrameworkAssessment();

        ResponseClass AddNewEmployeeInExisitingEvent();

        ResponseClass addEmployeeSkills();
        ResponseClass FSTLReportJob();

        ResponseClass ProjectFrameworkReportJob();

        ResponseClass AssignPFSurvey();

        ResponseClass pushDataToGamification(pushDataToGamificationRequestDTO request);

        ResponseClass PRCAssessessmentSummary();

        ResponseClass SendScheduleReportEmail();

        ResponseClass AssignPOSHTONewEmployee();

        ResponseClass AssignPOSHTOExistingEmployee();

        ResponseClass PendingPoshEmail();

        ResponseClass BOQReportJob();

        ResponseClass POSHReportJob();

        ResponseClass ChannelVideoNotification(string videoid,string channelid);

        int getParticipantScore(getparticipantgamificationscoreDTO request);

        DataTable getAdminGamificationCount(getparticipantgamificationscoreDTO request);
    }
}