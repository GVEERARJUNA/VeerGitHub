﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Configuration;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.Schedulers
{
   public class SchedulerDTO
    {
        
    }

    public class ISAPCalenderSchedulerDTO
    {
        public string SearchYear { get; set; }
        public string SearchMonth { get; set; }
    }

    public class CalenderStatusUpdateRequestDTO
    {
        public string Param1 { get; set; }
        public string Param2 { get; set; }
        public string Param3 { get; set; }
        public string Param4 { get; set; }
    }

    public class getTreeDataRequest
    {
        public string requestData { get; set; }
        public string currentRole { get; set; }
        public string LoggedInUser { get; set; }
    }

    public class teamleadupdatedataentity
    {
        public string empcode { get; set; }
        public string empname { get; set; }
        public string emailaddress { get; set; }
        public string programmanagercode { get; set; }
        public string programmanager { get; set; }
        public string ppemail { get; set; }
        public string pendingactivity { get; set; }
        public string bcclist { get; set; }

        
    }

    public class pushDataToGamificationRequestDTO
    {

        public string EventCode { get; set; }

        public string EventType { get; set; }
    }

    public class getparticipantgamificationscoreDTO
    {

        public string EmployeeCode { get; set; }

    }

    public class fcmnotificationresponseDTO
    {
        public string EMPID { get; set; }
        public string FCMTitle { get; set; }
        public string FCMBody { get; set; }
    }

    public class publisheventrequestDTO
    {
        public string objectcode { get; set; }
        public string objecttype { get; set; }
    }
}
