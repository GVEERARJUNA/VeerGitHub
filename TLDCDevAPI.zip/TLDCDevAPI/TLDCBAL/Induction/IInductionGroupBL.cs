﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;

namespace TLDCBAL.Induction
{
    public interface IInductionGroupBL
    {
        ResponseClass GetGeoList(InductionGroupDTO request);
        ResponseClass GetCityList(InductionGroupDTO request);
        ResponseClass GetOnboarderList(InductionGroupDTO request);
        ResponseClass GetInductionFacilitatorList(InductionGroupDTO request);
        ResponseClass GetTypeOfSubmissionList(InductionGroupDTO request);
        ResponseClass GetEmployeeListByDOJ(InductionGroupDTO request);
        ResponseClass AddEmployeeDetails(InductionGroupDTO request);
        ResponseClass InsertInductionGroupDetails(InductionGroupDTO request);
        ResponseClass InsertInductionGroupDraftDetails(InductionGroupDTO request);
        ResponseClass GetHRDataList(InductionGroupDTO request);
        ResponseClass GetInductionGroupList(InductionGroupDTO request);
        ResponseClass GetInductionGroupEmployeeList(InductionGroupDTO request);
        ResponseClass GetInductionGroupSearchList(InductionGroupDTO request);
        ResponseClass EditInductionGroupDetails(InductionGroupDTO request);
        ResponseClass InsertInductionGroupFeedbackDetails(InductionGroupDTO request);
        ResponseClass InsertInductionGroupFeedbackDraftDetails(InductionGroupDTO request);
        ResponseClass ChangeGroupStatus(changeGroupStatusRequestDTO request);
        ResponseClass UpdateInductionGroupDraftDetails(InductionGroupDTO request);
        ResponseClass UpdateInductionGroupDetails(InductionGroupDTO request);
        ResponseClass GetInductionFeedbackQuestionList(InductionGroupDTO request);
    }
}
