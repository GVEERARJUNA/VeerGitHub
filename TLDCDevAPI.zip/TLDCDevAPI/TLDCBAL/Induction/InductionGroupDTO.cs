﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace TLDCBAL.Induction
{
    public class InductionGroupDTO
    {
        public string Geo { get; set; }
        public string InductionDate { get; set; }
        public string City { get; set; }
        public string OnboarderEmpCode { get; set; }
        public string OnboarderEmpName { get; set; }
        public string InductionFacilitatorEmpCode { get; set; }
        public string InductionFacilitatorEmpName { get; set; }
        public string ProgramManagerEmpCode { get; set; }
        public string Status { get; set; }
        public string TypeOfSubmission { get; set; }
        public string DateRange { get; set; }
        public string InsertedIPAddress { get; set; }
        public string InsertedBy { get; set; }
        public string EmployeeID { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; }
        public string Country { get; set; }
        public string Grade { get; set; }
        public string SubProcess { get; set; }
        public string DOJ { get; set; }
        public string CompanyCode { get; set; }
        public string HREmployeeID { get; set; }
        public string HREmployeeName { get; set; }
        public string IRNNo { get; set; }
        public string IRNFeedbackFilePath { get; set; }
        public string IRNFeedbackFilePath1 { get; set; }
        public string QuestionCode { get; set; }
        public string FeedbackRating { get; set; }
        public string FeedbackData { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedIPAddress { get; set; }
        public List<EmployeeDetails> EmployeeDetailsList { get; set; }
    }

    public class EmployeeDetails
    {
        public string EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string Department { get; set; }
        public string Country { get; set; }
        public string Grade { get; set; }
        public string DOJ { get; set; }
        public string SubProcess { get; set; }
    }

    public class changeGroupStatusRequestDTO
    {
        public string IRNNo { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }

}
