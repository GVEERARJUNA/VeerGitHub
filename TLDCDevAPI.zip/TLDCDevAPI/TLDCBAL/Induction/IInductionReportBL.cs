﻿using TLDCBAL.Common;

namespace TLDCBAL.Induction
{
    public interface IInductionReportBL
    {
        ResponseClass GetCityCoverageReport(InductionReportRequestDTO request);
        ResponseClass GetDetailedReport(InductionReportRequestDTO request);
        ResponseClass GetStatusReport(InductionReportRequestDTO request);
        ResponseClass GetStatusReportEmployees(InductionReportRequestDTO request);
        ResponseClass GetDepartmentList(InductionReportRequestDTO request);
        ResponseClass GetInductionDashboardIconData(InductionDashboardRequestDTO request);
        ResponseClass GetInductionDashboardChartData(InductionDashboardRequestDTO request);

        ResponseClass GetInductionDashboardDepartmentData(InductionDashboardRequestDTO request);
        
     }
}