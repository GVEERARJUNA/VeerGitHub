﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.Induction
{
   public class InductionReportRequestDTO
    {
        public string InputParam1 { get; set; }
        public string InputParam2 { get; set; }
        public string InputParam3 { get; set; }
        public string InputParam4 { get; set; }
        public string InputParam5 { get; set; }
        public string InputParam6 { get; set; }
        public string InputParam7 { get; set; }
        public string InputParam8 { get; set; }
        public string InputParam9 { get; set; }
        public string InputParam10 { get; set; }
    }

    public class InductionDashboardRequestDTO
    {
        public string GeoName { get; set; }
        public string Action { get; set; }
        public string EmployeeCode { get; set; }
    }
}
