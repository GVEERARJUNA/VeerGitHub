﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Service;

namespace TLDCBAL.Induction
{
    public class InductionReportBL : IInductionReportBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        public InductionReportBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;
        }

        public ResponseClass GetStatusReport(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;


                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();

                string fromDate = string.Empty;
                string toDate = string.Empty;
                if (!string.IsNullOrEmpty(request.InputParam2))
                {
                    try
                    {
                        dtFrom = Convert.ToDateTime(request.InputParam2);
                        fromDate = Convert.ToDateTime(request.InputParam2).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetDetailedReport", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;


                    }
                }
                if (!string.IsNullOrEmpty(request.InputParam3))
                {
                    try
                    {
                        dtTo = Convert.ToDateTime(request.InputParam3);
                        toDate = Convert.ToDateTime(request.InputParam3).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetDetailedReport", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;


                    }
                }

                if (dtFrom > dtTo)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid date range selected!";
                    return response;
                }

                TimeSpan difference = dtTo - dtFrom;

                if (difference.TotalDays > 180)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    return response;
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_induction_status_report
                                                                        ( 
                                                                            :p_inputparam1,
                                                                            :p_inputparam2,
                                                                            :p_inputparam3,
                                                                            :p_inputparam4,
                                                                            :p_inputparam5,
                                                                            :p_inputparam6,
                                                                            :p_loadtime,
                                                                            :p_inputparam8
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.InputParam1))
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = request.InputParam1;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = string.Empty;
                       
                        cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = fromDate;
                        cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = toDate;

                        if (!String.IsNullOrEmpty(request.InputParam4))
                            cmd.Parameters.AddWithValue("p_inputparam4", DbType.String).Value = request.InputParam4;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam4", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InputParam5))
                            cmd.Parameters.AddWithValue("p_inputparam5", DbType.String).Value = request.InputParam5;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam5", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InputParam6))
                            cmd.Parameters.AddWithValue("p_inputparam6", DbType.String).Value = request.InputParam6;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam6", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.InputParam7))
                            cmd.Parameters.AddWithValue("p_loadtime", DbType.String).Value = request.InputParam7;
                        else
                            cmd.Parameters.AddWithValue("p_loadtime", DbType.String).Value = "0";
                        if (!String.IsNullOrEmpty(request.InputParam8))
                            cmd.Parameters.AddWithValue("p_inputparam8", DbType.String).Value = request.InputParam8;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam8", DbType.String).Value = string.Empty;
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        if (dtEmployees.Rows.Count>0)
                        {
                            dtEmployees.Columns.Add("RowNumber");
                            int rowno = 1;
                            foreach (DataRow item in dtEmployees.Rows)
                            {
                                item["RowNumber"] = rowno;

                                rowno = rowno + 1;
                            }
                        }
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetStatusReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass GetStatusReportEmployees(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
              
                string fromDate = string.Empty;
                string toDate = string.Empty;
                if (!string.IsNullOrEmpty(request.InputParam2))
                {
                    try
                    {
                        fromDate = Convert.ToDateTime(request.InputParam2).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetStatusReportEmployees", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;


                    }
                }
                if (!string.IsNullOrEmpty(request.InputParam3))
                {
                    try
                    {
                        toDate = Convert.ToDateTime(request.InputParam3).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetStatusReportEmployees", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;


                    }
                }

                DataTable cityList = new DataTable();
                string selectQuery = string.Empty;
                if (request.InputParam7=="Inducted")
                {
                    selectQuery = "select A.#CITY# as city,A.#DEPARTMENT# as department,A.#EXTERNALDATAREFERENCE# as employeecode,concat(A.#FIRSTNAME#,' ',coalesce(A.#LASTNAME#,'')) as EmployeeName,cast(TO_CHAR(A.#DOJ#, 'dd-Mon-yyyy') as character varying) as doj,cast(TO_CHAR(IG.#InsertedDateTime#, 'dd-Mon-yyyy') as character varying) as inducteddate from #InductionEmployees# IE inner join #InductionGroup# IG on IG.#IRNNo#=IE.#IRNNo# inner join #EmployeeMaster# A on IE.#EmployeeCode#=A.#EXTERNALDATAREFERENCE# where  IG.#GroupStatus#='Completed' and A.#DOJ# between '" + fromDate + "' and '" + toDate + "' and lower(#COUNTRY#) = lower('" + request.InputParam4 + "') and lower(#DEPARTMENT#) = lower('" + request.InputParam6 + "') and lower(#CITY#) =lower('" + request.InputParam5 + "')";
                }
                if (request.InputParam7 == "NotInducted")
                {
                    selectQuery = "select A.#CITY# as city,A.#DEPARTMENT# as department,A.#EXTERNALDATAREFERENCE# as employeecode,concat(A.#FIRSTNAME#,' ',coalesce(A.#LASTNAME#,'')) as EmployeeName,cast(TO_CHAR(A.#DOJ#, 'dd-Mon-yyyy') as character varying) as doj,cast(CURRENT_DATE - A.#DOJ# as character varying) as waitingsince from #EmployeeMaster# A left join  #InductionEmployees# IE on IE.#EmployeeCode#=A.#EXTERNALDATAREFERENCE# left join #InductionGroup# IG on IG.#IRNNo#=IE.#IRNNo# and IG.#GroupStatus#='Completed' where coalesce(IG.#IRNNo#,'')='' and A.#DOJ# between '" + fromDate + "' and '" + toDate + "' and lower(A.#COUNTRY#) = lower('" + request.InputParam4 + "') and lower(A.#DEPARTMENT#) = lower('" + request.InputParam6 + "') and lower(A.#CITY#) =lower('" + request.InputParam5 + "')";
                }

                if (!string.IsNullOrEmpty(request.InputParam1))
                {
                    selectQuery = selectQuery + " and lower(A.#Active_Separated#)=lower('" + request.InputParam1 + "')";
                }
                
                selectQuery = selectQuery.Replace('#', '"');
               
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(cityList);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(cityList);
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetStatusReportEmployees", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass GetCityCoverageReport(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;


                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();

                string fromDate = string.Empty;
                string toDate = string.Empty;
                if (!string.IsNullOrEmpty(request.InputParam2))
                {
                    try
                    {
                        dtFrom = Convert.ToDateTime(request.InputParam2);
                        fromDate = Convert.ToDateTime(request.InputParam2).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetCityCoverageReport", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;


                    }
                }
                if (!string.IsNullOrEmpty(request.InputParam3))
                {
                    try
                    {
                        dtTo = Convert.ToDateTime(request.InputParam3);
                        toDate = Convert.ToDateTime(request.InputParam3).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetCityCoverageReport", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;


                    }
                }

                if (dtFrom > dtTo)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid date range selected!";
                    return response;
                }

                TimeSpan difference = dtTo - dtFrom;

                if (difference.TotalDays > 180)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    return response;
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_city_coverage_report
                                                                        ( 
                                                                            :p_inputparam1,
                                                                            :p_inputparam2,
                                                                            :p_inputparam3,
                                                                            :p_inputparam4,
                                                                            :p_inputparam5,
                                                                            :p_inputparam6,
                                                                            :p_loadtime,:p_inputparam8
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.InputParam1))
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = request.InputParam1;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = fromDate;
                        cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = toDate;

                        if (!String.IsNullOrEmpty(request.InputParam4))
                            cmd.Parameters.AddWithValue("p_inputparam4", DbType.String).Value = request.InputParam4;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam4", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InputParam5))
                            cmd.Parameters.AddWithValue("p_inputparam5", DbType.String).Value = request.InputParam5;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam5", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InputParam6))
                            cmd.Parameters.AddWithValue("p_inputparam6", DbType.String).Value = request.InputParam6;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam6", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.InputParam7))
                            cmd.Parameters.AddWithValue("p_loadtime", DbType.String).Value = request.InputParam7;
                        else
                            cmd.Parameters.AddWithValue("p_loadtime", DbType.String).Value = "0";
                        if (!String.IsNullOrEmpty(request.InputParam8))
                            cmd.Parameters.AddWithValue("p_inputparam8", DbType.String).Value = request.InputParam8;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam8", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        if (dtEmployees.Rows.Count > 0)
                        {
                            dtEmployees.Columns.Add("RowNumber");
                            int rowno = 1;
                            foreach (DataRow item in dtEmployees.Rows)
                            {
                                item["RowNumber"] = rowno;

                                rowno = rowno + 1;
                            }
                        }
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetCityCoverageReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetDetailedReport(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();

                string fromDate = string.Empty;
                string toDate = string.Empty;
                if (!string.IsNullOrEmpty(request.InputParam2))
                {
                    try
                    {
                        dtFrom = Convert.ToDateTime(request.InputParam2);
                        fromDate = Convert.ToDateTime(request.InputParam2).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetDetailedReport", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;


                    }
                }
                if (!string.IsNullOrEmpty(request.InputParam3))
                {
                    try
                    {
                        dtTo = Convert.ToDateTime(request.InputParam3);
                        toDate = Convert.ToDateTime(request.InputParam3).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetDetailedReport", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;


                    }
                }

                if (dtFrom > dtTo)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid date range selected!";
                    return response;
                }

                TimeSpan difference = dtTo - dtFrom;

                if (difference.TotalDays > 180)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    return response;
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_induction_detail_report
                                                                        ( 
                                                                            :p_inputparam1,
                                                                            :p_inputparam2,
                                                                            :p_inputparam3,
                                                                            :p_inputparam4,
                                                                            :p_inputparam5,
                                                                            :p_inputparam6,
                                                                            :p_loadtime,:p_inputparam8
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.InputParam1))
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = request.InputParam1;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = fromDate;
                        cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = toDate;

                        if (!String.IsNullOrEmpty(request.InputParam4))
                            cmd.Parameters.AddWithValue("p_inputparam4", DbType.String).Value = request.InputParam4;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam4", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InputParam5))
                            cmd.Parameters.AddWithValue("p_inputparam5", DbType.String).Value = request.InputParam5;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam5", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InputParam6))
                            cmd.Parameters.AddWithValue("p_inputparam6", DbType.String).Value = request.InputParam6;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam6", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.InputParam7))
                            cmd.Parameters.AddWithValue("p_loadtime", DbType.String).Value = request.InputParam7;
                        else
                            cmd.Parameters.AddWithValue("p_loadtime", DbType.String).Value = "0";
                        if (!String.IsNullOrEmpty(request.InputParam8))
                            cmd.Parameters.AddWithValue("p_inputparam8", DbType.String).Value = request.InputParam8;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam8", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        if (dtEmployees.Rows.Count > 0)
                        {
                            dtEmployees.Columns.Add("RowNumber");
                            int rowno = 1;
                            foreach (DataRow item in dtEmployees.Rows)
                            {
                                item["RowNumber"] = rowno;

                                rowno = rowno + 1;
                            }

                            
                        }
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetDetailedReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;


        }

        public ResponseClass GetDepartmentList(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable cityList = new DataTable();
                string selectQuery = string.Empty;
                selectQuery = "select distinct A.#DEPARTMENT# from #EmployeeMaster# A inner join #CommonMasterValue# CM on lower(A.#COUNTRY#) = lower(CM.#MasterValue#) where CM.#CMValueID# in (" + request.InputParam1 + ") and CM.#MasterCode# = 'M001' order by A.#DEPARTMENT#";
                //selectQuery = "select A.#CMValueID#,A.#MasterValue# from #CommonMasterValue# A where A.#MasterCode#='M003'  and A.#ISActive#=1 and #ParentValueID# in (" + request.Geo + ")";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(cityList);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(cityList);


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetDepartmentList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetInductionDashboardIconData(InductionDashboardRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
               
                if (string.IsNullOrEmpty(request.GeoName))
                {
                    response.responseCode = 0;
                    response.responseMessage = "GeoName required!";
                    return response;
                }
                

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_induction_dashboard_icon_data
                                                                        ( 
                                                                            :p_inputparam1,
                                                                            :p_inputparam2,
                                                                            :p_inputparam3
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.GeoName))
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = request.GeoName;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = request.EmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetInductionDashboardIconData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;


        }

        public ResponseClass GetInductionDashboardChartData(InductionDashboardRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                if (string.IsNullOrEmpty(request.GeoName))
                {
                    response.responseCode = 0;
                    response.responseMessage = "GeoName required!";
                    return response;
                }


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_induction_dashboard_chart_data
                                                                        ( 
                                                                            :p_inputparam1,
 :p_inputparam2,
                                                                            :p_inputparam3
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.GeoName))
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = request.GeoName;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = request.EmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetInductionDashboardIconData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;


        }

        public ResponseClass GetInductionDashboardDepartmentData(InductionDashboardRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                if (string.IsNullOrEmpty(request.GeoName))
                {
                    response.responseCode = 0;
                    response.responseMessage = "GeoName required!";
                    return response;
                }


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_induction_dashboard_department_data
                                                                        ( 
                                                                            :p_inputparam1,
                                                                            :p_inputparam2,
                                                                            :p_inputparam3
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.GeoName))
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = request.GeoName;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam1", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam2", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = request.EmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_inputparam3", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetInductionDashboardIconData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;


        }
    }
}
