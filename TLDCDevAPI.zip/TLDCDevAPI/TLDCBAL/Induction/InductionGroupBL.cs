﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.Induction
{
    public class InductionGroupBL : IInductionGroupBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        public InductionGroupBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;
        }

        public ResponseClass GetCityList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable cityList = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = "select A.#CMValueID#,A.#MasterValue# from #CommonMasterValue# A where A.#MasterCode#='M003'  and A.#ISActive#=1 and #ParentValueID# in (" + request.Geo + ")";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(cityList);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(cityList);

                
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetCityList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetEmployeeListByDOJ(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            string fromDate = string.Empty;
            string toDate = string.Empty;

            if (!string.IsNullOrWhiteSpace(request.DateRange))
            {
                try
                {
                    string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

                    fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                    toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Induction Group Creation", "1024", "From Date : " + ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = "Invalid Date Range";
                    return response;
                }
            }

            try
            {
                DataTable employeeList = new DataTable();

                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery1 = "select #MasterValue# from #CommonMasterValue# where #MasterCode# = 'M001' and #ISActive# = 1 and #CMValueID# = " + Convert.ToInt32(request.Geo);

                sqlQuery1 = sqlQuery1.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                NpgsqlDataReader npgsqlDataReader = npgsqlCommand.ExecuteReader();

                while (npgsqlDataReader.Read())
                {
                    request.Geo = npgsqlDataReader[0].ToString();
                }

                npgsqlCon.Close();

                //string sqlQuery = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#, concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,cast(TO_CHAR(A.#DOJ#, 'dd-Mon-yyyy') as character varying) as dojdisplay,A.#DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#DOJ# >= '" + fromDate + "' and A.#DOJ# <= '" + toDate + "' and A.#Active_Separated# = 'Active' and #COUNTRY# = '" + request.Geo + "' order by A.#DOJ# DESC";

                string sqlQuery = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#, concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,cast(TO_CHAR(A.#DOJ#, 'dd-Mon-yyyy') as character varying) as dojdisplay,A.#DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#DOJ# >= '" + fromDate + "' and A.#DOJ# <= '" + toDate + "' and A.#Active_Separated# = 'Active' and upper(#COUNTRY#) = upper('" + request.Geo + "') order by A.#DOJ# DESC";

                sqlQuery = sqlQuery.Replace('#','"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery,npgsqlCon);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);

                dataAdapter.Fill(employeeList);

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(employeeList);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetGeoList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable geoList = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_InductionGeo(:p_employee)", npgsqlConnection))
                    {
                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            npgsqlCommand.Parameters.AddWithValue("p_employee", DbType.String).Value = request.EmployeeCode;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_employee", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(geoList);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(geoList);

                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetInductionFacilitatorList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable hrList = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery1 = "select #MasterValue# from #CommonMasterValue# where #MasterCode# = 'M001' and #ISActive# = 1 and #CMValueID# = " + Convert.ToInt32(request.Geo);

                sqlQuery1 = sqlQuery1.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                NpgsqlDataReader npgsqlDataReader = npgsqlCommand1.ExecuteReader();

                while (npgsqlDataReader.Read())
                {
                    request.Geo = npgsqlDataReader[0].ToString();
                }

                npgsqlCon.Close();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_inductionHR(:p_geo)", npgsqlConnection))
                    {
                        npgsqlCommand.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(request.Geo))
                            npgsqlCommand.Parameters.AddWithValue("p_geo", DbType.String).Value = request.Geo;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_geo", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(hrList);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(hrList);

                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetOnboarderList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable hrList = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery1 = "select #MasterValue# from #CommonMasterValue# where #MasterCode# = 'M001' and #ISActive# = 1 and #CMValueID# = " + Convert.ToInt32(request.Geo);

                sqlQuery1 = sqlQuery1.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                NpgsqlDataReader npgsqlDataReader = npgsqlCommand1.ExecuteReader();

                while (npgsqlDataReader.Read())
                {
                    request.Geo = npgsqlDataReader[0].ToString();
                }

                npgsqlCon.Close();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_inductionHR(:p_geo)", npgsqlConnection))
                    {
                        npgsqlCommand.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(request.Geo))
                            npgsqlCommand.Parameters.AddWithValue("p_geo", DbType.String).Value = request.Geo;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_geo", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(hrList);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(hrList);

                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetTypeOfSubmissionList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable submissionList = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_TypeOfSubmission()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(submissionList);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(submissionList);

                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass InsertInductionGroupDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                string[] chekEmployeeGroup = request.EmployeeCode.Split(',');
                string checkEmployeeGroupData = string.Empty;
                List<string> employeeList = new List<string>();

                foreach (var empid in chekEmployeeGroup)
                {
                    checkEmployeeGroupData = "'" + empid + "',";
                }

                checkEmployeeGroupData = checkEmployeeGroupData.Substring(0, checkEmployeeGroupData.Length - 1);

                npgsqlCon.Open();

                string checkEmployeeTblGroup = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# IN (" + checkEmployeeGroupData + ") and A.#Active_Separated# = 'Active'";

                checkEmployeeTblGroup = checkEmployeeTblGroup.Replace('#', '"');

                NpgsqlCommand checkEmployeeTblGroupCMD = new NpgsqlCommand(checkEmployeeTblGroup, npgsqlCon);
                NpgsqlDataReader checkEmployeeDataReader = checkEmployeeTblGroupCMD.ExecuteReader();
                while (checkEmployeeDataReader.Read())
                {
                    employeeList.Add(checkEmployeeDataReader[0].ToString());
                }

                npgsqlCon.Close();

                if (employeeList.Count() > 0)
                {
                    //IRN Number
                    string irnNo = string.Empty;
                    int irnCount = 0;
                    string sqlQuery3 = "SELECT max(#IRNSequenceNo#) as #IRNSequenceNo# FROM public.#InductionGroup#";

                    sqlQuery3 = sqlQuery3.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery3, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                    if (npgsqlDataReader1.Read())
                    {
                        irnNo = npgsqlDataReader1[0].ToString();
                        irnCount = Convert.ToInt32(irnNo) + 1;
                        irnNo = "IRN" + irnCount;
                    }
                    else
                    {
                        ++irnCount;
                        irnNo = "IRN" + irnCount;
                    }

                    npgsqlCon.Close();

                    string sqlQuery = "INSERT INTO public.#InductionGroup#(#IRNNo#,#GeoName#,#CityName#,#OnboarderEMPCode#,#InductionFaciliatorEMPCode#,#SubmissionType#,#GroupStatus#,#InsertedDateTime#,#InsertedIPAddress#, #InsertedBy#,#IRNSequenceNo#) VALUES('" + irnNo + "', '" + request.Geo + "', '" + request.City + "', '" + request.OnboarderEmpCode + "', '" + request.InductionFacilitatorEmpCode + "', '" + request.TypeOfSubmission + "', 'Completed', '" + Convert.ToDateTime(request.InductionDate).ToString("yyyy-MM-dd") + "', '" + request.InsertedIPAddress + "', '" + request.InsertedBy + "','" + irnCount + "')";

                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();

                    string[] employeeID = request.EmployeeCode.Split(',');
                    string[] employeeName = request.EmployeeName.Split(',');
                    string[] department = request.Department.Split(',');
                    string[] country = request.Country.Split(',');
                    string[] subProcess = request.SubProcess.Split(',');
                    string[] grade = request.Grade.Split(',');
                    string[] doj = request.DOJ.Split(',');
                    string[] companyCode = request.CompanyCode.Split(',');

                    string employeeCode = string.Empty;

                    for (int i = 0; i < employeeID.Length; i++)
                    {
                        npgsqlCon.Open();

                        string sqlCheckQuery = "SELECT #EmployeeCode# FROM public.#InductionEmployees# WHERE #EmployeeCode# = '" + employeeID[i] + "'";

                        sqlCheckQuery = sqlCheckQuery.Replace('#', '"');

                        NpgsqlCommand chkCommand = new NpgsqlCommand(sqlCheckQuery, npgsqlCon);

                        NpgsqlDataReader chkDataRaeder = chkCommand.ExecuteReader();

                        if (chkDataRaeder.Read())
                        {
                            employeeCode = chkDataRaeder[0].ToString();
                        }

                        npgsqlCon.Close();

                        npgsqlCon.Open();

                        if (string.IsNullOrWhiteSpace(employeeCode))
                        {
                            string sqlQuery2 = "INSERT INTO public.#InductionEmployees#(#IRNNo#, #EmployeeCode#, #EmployeeName#, #Department#, #CompanyCode#, #EmployeeGrade#, #SubProcess#, #DOJ#, #FeedbackRemarks#, #InsertedDateTime#) VALUES('" + irnNo + "','" + employeeID[i] + "','" + employeeName[i] + "','" + department[i] + "','" + companyCode[i] + "','" + grade[i] + "','" + subProcess[i] + "','" + doj[i] + "','',now())";

                            sqlQuery2 = sqlQuery2.Replace('#', '"');

                            NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

                            NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();
                        }

                        npgsqlCon.Close();
                    }

                    response.responseCode = 1;
                    response.responseJSON = JsonConvert.SerializeObject("Success");
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = 1;
                    response.responseJSON = JsonConvert.SerializeObject("Success");
                    response.responseMessage = "Employee alerdy Exist in Induction Group.";
                }



                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject("Success");
                //response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass AddEmployeeDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable employeeDetails = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                npgsqlCon.Open();

                string sqlQuery = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#, concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,cast(TO_CHAR(A.#DOJ#, 'dd-Mon-yyyy') as character varying) as dojdisplay,A.#DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# = '" + request.EmployeeID + "' and A.#Active_Separated# = 'Active'";

                sqlQuery = sqlQuery.Replace('#','"');

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery,npgsqlCon);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);

                dataAdapter.Fill(employeeDetails);

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(employeeDetails);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetHRDataList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();



            return response;
        }

        public ResponseClass InsertInductionGroupDraftDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
                string[] chekEmployeeGroup = request.EmployeeCode.Split(',');
                string checkEmployeeGroupData = string.Empty;
                List<string> employeeList = new List<string>();

                foreach(var empid in chekEmployeeGroup)
                {
                    checkEmployeeGroupData = "'" + empid + "',";
                }

                checkEmployeeGroupData = checkEmployeeGroupData.Substring(0,checkEmployeeGroupData.Length - 1);

                npgsqlCon.Open();

                string checkEmployeeTblGroup = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# IN (" + checkEmployeeGroupData + ") and A.#Active_Separated# = 'Active'";

                checkEmployeeTblGroup = checkEmployeeTblGroup.Replace('#', '"');

                NpgsqlCommand checkEmployeeTblGroupCMD = new NpgsqlCommand(checkEmployeeTblGroup,npgsqlCon);
                NpgsqlDataReader checkEmployeeDataReader = checkEmployeeTblGroupCMD.ExecuteReader();
                while(checkEmployeeDataReader.Read())
                {
                    employeeList.Add(checkEmployeeDataReader[0].ToString());
                }

                npgsqlCon.Close();

                if(employeeList.Count() > 0)
                {
                    //IRN Number
                    string irnNo = string.Empty;
                    int irnCount = 0;
                    string sqlQuery3 = "SELECT max(#IRNSequenceNo#) as #IRNSequenceNo# FROM public.#InductionGroup#";

                    sqlQuery3 = sqlQuery3.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery3, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                    if (npgsqlDataReader1.Read())
                    {
                        irnNo = npgsqlDataReader1[0].ToString();
                        irnCount = Convert.ToInt32(irnNo) + 1;
                        irnNo = "IRN" + irnCount;
                    }
                    else
                    {
                        ++irnCount;
                        irnNo = "IRN" + irnCount;
                    }

                    npgsqlCon.Close();

                    string sqlQuery = "INSERT INTO public.#InductionGroup#(#IRNNo#,#GeoName#,#CityName#,#OnboarderEMPCode#,#InductionFaciliatorEMPCode#,#SubmissionType#,#GroupStatus#,#InsertedDateTime#,#InsertedIPAddress#, #InsertedBy#,#IRNSequenceNo#) VALUES('" + irnNo + "', '" + request.Geo + "', '" + request.City + "', '" + request.OnboarderEmpCode + "', '" + request.InductionFacilitatorEmpCode + "', '" + request.TypeOfSubmission + "', 'Draft', '" + Convert.ToDateTime(request.InductionDate).ToString("yyyy-MM-dd") + "', '" + request.InsertedIPAddress + "', '" + request.InsertedBy + "','" + irnCount + "')";

                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();

                    string[] employeeID = request.EmployeeCode.Split(',');
                    string[] employeeName = request.EmployeeName.Split(',');
                    string[] department = request.Department.Split(',');
                    string[] country = request.Country.Split(',');
                    string[] subProcess = request.SubProcess.Split(',');
                    string[] grade = request.Grade.Split(',');
                    string[] doj = request.DOJ.Split(',');
                    string[] companyCode = request.CompanyCode.Split(',');

                    string employeeCode = string.Empty;

                    for (int i = 0; i < employeeID.Length; i++)
                    {
                        npgsqlCon.Open();

                        string sqlCheckQuery = "SELECT #EmployeeCode# FROM public.#InductionEmployees# WHERE #EmployeeCode# = '" + employeeID[i] + "'";

                        sqlCheckQuery = sqlCheckQuery.Replace('#', '"');

                        NpgsqlCommand chkCommand = new NpgsqlCommand(sqlCheckQuery, npgsqlCon);

                        NpgsqlDataReader chkDataRaeder = chkCommand.ExecuteReader();

                        if (chkDataRaeder.Read())
                        {
                            employeeCode = chkDataRaeder[0].ToString();
                        }

                        npgsqlCon.Close();

                        npgsqlCon.Open();

                        if (string.IsNullOrWhiteSpace(employeeCode))
                        {
                            string sqlQuery2 = "INSERT INTO public.#InductionEmployees#(#IRNNo#, #EmployeeCode#, #EmployeeName#, #Department#, #CompanyCode#, #EmployeeGrade#, #SubProcess#, #DOJ#, #FeedbackRemarks#, #InsertedDateTime#) VALUES('" + irnNo + "','" + employeeID[i] + "','" + employeeName[i] + "','" + department[i] + "','" + companyCode[i] + "','" + grade[i] + "','" + subProcess[i] + "','" + doj[i] + "','',now())";

                            sqlQuery2 = sqlQuery2.Replace('#', '"');

                            NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

                            NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();
                        }

                        npgsqlCon.Close();
                    }

                    response.responseCode = 1;
                    response.responseJSON = JsonConvert.SerializeObject("Success");
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = 1;
                    response.responseJSON = JsonConvert.SerializeObject("Success");
                    response.responseMessage = "Employee alerdy Exist in Induction Group.";
                }

                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject("Success");
                //response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetInductionGroupList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable inductionGroupList = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlConn = new NpgsqlConnection(pgsqlConnection);

                int geoID = 0;

                string fromDate = string.Empty;
                string toDate = string.Empty;

                if(request.DateRange != null)
                {
                    string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);
                    fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                    toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                }
                else
                {
                    fromDate = DateTime.Now.ToString("yyyy-MM-dd");
                    toDate = DateTime.Now.ToString("yyyy-MM-dd");
                }

                npgsqlConn.Open();

                string geoIDQuery = "SELECT #CMValueID# FROM public.#CommonMasterValue# WHERE lower(#MasterValue#) = lower('"+request.Geo+"')";
                geoIDQuery = geoIDQuery.Replace('#','"');

                NpgsqlCommand geoIDCMD = new NpgsqlCommand(geoIDQuery,npgsqlConn);
                NpgsqlDataReader geoIDReader = geoIDCMD.ExecuteReader();
                while(geoIDReader.Read())
                {
                    geoID = Convert.ToInt32(geoIDReader[0].ToString());
                }

                npgsqlConn.Close();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_inductiongroupmanageGeowise("+geoID+",'"+fromDate+"','"+toDate+"')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(inductionGroupList);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(inductionGroupList);

                        npgsqlConnection.Close();
                    }
                }

                //using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                //{
                //    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_inductionGroupManage()", npgsqlConnection))
                //    {
                //        npgsqlConnection.Open();

                //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                //        dataAdapter.Fill(inductionGroupList);
                //        response.responseCode = 1;
                //        response.responseJSON = JsonConvert.SerializeObject(inductionGroupList);

                //        npgsqlConnection.Close();
                //    }
                //}
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetInductionGroupEmployeeList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable inductionGroupEmployeeList = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_inductionGroupManageEmployee(:p_irnno)", npgsqlConnection))
                    {
                        npgsqlCommand.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(request.IRNNo))
                            npgsqlCommand.Parameters.AddWithValue("p_irnno", DbType.String).Value = request.IRNNo;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_irnno", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(inductionGroupEmployeeList);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(inductionGroupEmployeeList);

                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass EditInductionGroupDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable feedback = new DataTable();
                DataTable feedbackEmp = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                string feedbackQuery = "SELECT #GeoName#, #CityName#, #OnboarderEMPCode#, #InductionFaciliatorEMPCode#, #SubmissionType#, #GroupStatus#, #InsertedDateTime# FROM public.#InductionGroup# WHERE #IRNNo# = '" + request.IRNNo + "'";

                feedbackQuery = feedbackQuery.Replace('#','"');

                npgsqlCon.Open();

                NpgsqlCommand feedbackCmd = new NpgsqlCommand(feedbackQuery,npgsqlCon);
                NpgsqlDataAdapter feedbackAdapter = new NpgsqlDataAdapter(feedbackCmd);
                feedbackAdapter.Fill(feedback);

                npgsqlCon.Close();

                string feedbackEmpQuery = "SELECT #EmployeeCode#, #EmployeeName#, #Department#, #CompanyCode#, #EmployeeGrade#, #SubProcess#, #DOJ# FROM public.#InductionEmployees# where #IRNNo# = '" + request.IRNNo + "'";

                feedbackEmpQuery = feedbackEmpQuery.Replace('#','"');

                npgsqlCon.Open();

                NpgsqlCommand feedbackEmpCommand = new NpgsqlCommand(feedbackEmpQuery,npgsqlCon);
                NpgsqlDataAdapter feedbackEmpDataAdapter = new NpgsqlDataAdapter(feedbackEmpCommand);
                feedbackEmpDataAdapter.Fill(feedbackEmp);

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(feedback);
                response.responseJSONSecondary = JsonConvert.SerializeObject(feedbackEmp);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass ChangeGroupStatus(changeGroupStatusRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);

            try
            {
                npgCon.Open();

                string sqlQuery = "call prc_update_group_status('" + request.IRNNo + "','" + request.InsertedBy + "','" + request.InsertedIPAddress + "')";

                // Define a command to call  procedure
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
                NpgsqlDataReader rdr = cmd.ExecuteReader();

                npgCon.Close();

                response.responseCode = 1;
                response.responseMessage = "SUCCESS!";
                return response;

                //response.responseCode = 0;
                //response.responseMessage = "Feature not available!";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ChangeGroupStatus", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass InsertInductionGroupFeedbackDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
                //string[] chekEmployeeGroup = request.EmployeeCode.Split(',');
                var chkfeedbackDatatable = JsonConvert.DeserializeObject<DataTable>(request.FeedbackData);
                string checkEmployeeGroupData = string.Empty;
                List<string> employeeList = new List<string>();
                List<string> dummyEmployeeList = new List<string>();

                if (chkfeedbackDatatable.Rows.Count > 1)
                {
                    for (int j = 0; j <= chkfeedbackDatatable.Rows.Count - 1; j++)
                    {
                        for (int i = chkfeedbackDatatable.Columns.Count - 1; i >= 0; i--)
                        {
                            string columnName = Convert.ToString(chkfeedbackDatatable.Columns[i]);
                            string chkEmployeeID = Convert.ToString(chkfeedbackDatatable.Rows[j][0]);
                            if (string.Equals(columnName, "Employee_ID"))
                            {
                                dummyEmployeeList.Add(chkEmployeeID);
                            }
                        }
                    }
                }

                foreach (var empid in dummyEmployeeList)
                {
                    checkEmployeeGroupData += "'" + empid + "',";
                }

                checkEmployeeGroupData = checkEmployeeGroupData.Substring(0, checkEmployeeGroupData.Length - 1);

                npgsqlCon.Open();

                string checkEmployeeTblGroup = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# IN (" + checkEmployeeGroupData + ") and A.#Active_Separated# = 'Active'";

                checkEmployeeTblGroup = checkEmployeeTblGroup.Replace('#', '"');

                NpgsqlCommand checkEmployeeTblGroupCMD = new NpgsqlCommand(checkEmployeeTblGroup, npgsqlCon);
                NpgsqlDataReader checkEmployeeDataReader = checkEmployeeTblGroupCMD.ExecuteReader();
                while (checkEmployeeDataReader.Read())
                {
                    employeeList.Add(checkEmployeeDataReader[0].ToString());
                }

                npgsqlCon.Close();

                if (employeeList.Count() > 0)
                {
                    //IRN Number
                    string irnNo = string.Empty;
                    int irnCount = 0;
                    string sqlQuery3 = "SELECT max(#IRNSequenceNo#) as #IRNSequenceNo# FROM public.#InductionGroup#";

                    sqlQuery3 = sqlQuery3.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery3, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                    if (npgsqlDataReader1.Read())
                    {
                        irnNo = npgsqlDataReader1[0].ToString();
                        irnCount = Convert.ToInt32(irnNo) + 1;
                        irnNo = "IRN" + irnCount;
                    }
                    else
                    {
                        ++irnCount;
                        irnNo = "IRN" + irnCount;
                    }

                    npgsqlCon.Close();

                    string sqlQuery = "INSERT INTO public.#InductionGroup#(#IRNNo#,#GeoName#,#CityName#,#OnboarderEMPCode#,#InductionFaciliatorEMPCode#,#SubmissionType#,#GroupStatus#,#IRNFeedbackFilePath#,#InsertedDateTime#,#InsertedIPAddress#, #InsertedBy#,#IRNSequenceNo#) VALUES('" + irnNo + "', '" + request.Geo + "', '" + request.City + "', '" + request.OnboarderEmpCode + "', '" + request.InductionFacilitatorEmpCode + "', '" + request.TypeOfSubmission + "', 'Completed', '" + request.IRNFeedbackFilePath + "', '"+ Convert.ToDateTime(request.InductionDate).ToString("yyyy-MM-dd HH:mm:ss") + "', '" + request.InsertedIPAddress + "', '" + request.InsertedBy + "'," + irnCount + ")";

                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();

                    //Insert into Induction Feedback
                    var feedbackDatatable = JsonConvert.DeserializeObject<DataTable>(request.FeedbackData);
                    string comment = string.Empty;
                    string employeeID = string.Empty;

                    string employeeCode = string.Empty;
                    string employeeName = string.Empty;
                    string department = string.Empty;
                    string country = string.Empty;
                    string companyCode = string.Empty;
                    string employeeGrade = string.Empty;
                    string subProcess = string.Empty;
                    string doj = string.Empty;
                    string questionID = string.Empty;
                    string geoData = string.Empty;
                    string tempEmp = string.Empty;

                    if (feedbackDatatable.Rows.Count > 1)
                    {
                        for (int j = 0; j <= feedbackDatatable.Rows.Count - 1; j++)
                        {
                            for (int i = feedbackDatatable.Columns.Count - 1; i >= 0; i--)
                            {
                                string columnName = Convert.ToString(feedbackDatatable.Columns[i]);
                                employeeID = Convert.ToString(feedbackDatatable.Rows[j][0]);
                                comment = Convert.ToString(feedbackDatatable.Rows[j][feedbackDatatable.Columns.Count - 1]);
                                if (!string.Equals(columnName, "Employee_ID") && !string.Equals(columnName, "Comments"))
                                {
                                    string rowValue = Convert.ToString(feedbackDatatable.Rows[j][i]);
                                    string columnValue = Convert.ToString(feedbackDatatable.Columns[i]);

                                    //Insert into Feedback
                                    string tmpemployeeSql = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# = '" + employeeID + "' and A.#Active_Separated# = 'Active'";

                                    tmpemployeeSql = tmpemployeeSql.Replace('#', '"');

                                    npgsqlCon.Open();

                                    NpgsqlCommand tempCmd = new NpgsqlCommand(tmpemployeeSql, npgsqlCon);
                                    NpgsqlDataReader tempreader = tempCmd.ExecuteReader();

                                    while (tempreader.Read())
                                    {
                                        tempEmp = tempreader[0].ToString();
                                    }

                                    npgsqlCon.Close();

                                    if (!string.IsNullOrWhiteSpace(tempEmp))
                                    {
                                        string sqlQuery1 = "select #MasterValue# from #CommonMasterValue# where #MasterCode# = 'M001' and #ISActive# = 1 and #CMValueID# = " + Convert.ToInt32(request.Geo);

                                        sqlQuery1 = sqlQuery1.Replace('#', '"');

                                        npgsqlCon.Open();

                                        NpgsqlCommand npgsqlCommand11 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                                        NpgsqlDataReader npgsqlDataReader11 = npgsqlCommand11.ExecuteReader();

                                        while (npgsqlDataReader11.Read())
                                        {
                                            geoData = npgsqlDataReader11[0].ToString();
                                        }

                                        npgsqlCon.Close();

                                        //Feedback Question ID
                                        npgsqlCon.Open();

                                        string feedbackQuestionIDQuery = "SELECT #tid# FROM public.#Induction_FeedbackQBank# where #questionname# = '" + columnValue + "' and #geoname# = '" + geoData + "'";

                                        feedbackQuestionIDQuery = feedbackQuestionIDQuery.Replace('#', '"');

                                        NpgsqlCommand feedbackQuestionCMD = new NpgsqlCommand(feedbackQuestionIDQuery, npgsqlCon);
                                        NpgsqlDataReader npgsqlDataReader = feedbackQuestionCMD.ExecuteReader();

                                        while (npgsqlDataReader.Read())
                                        {
                                            questionID = npgsqlDataReader[0].ToString();
                                        }

                                        npgsqlCon.Close();

                                        //Insert Feedback question
                                        npgsqlCon.Open();

                                        string feedbackInsertQuery = "INSERT INTO public.#InductionFeedback#(#IRNNo#, #EmployeeCode#, #QuestionCode#, #FeedbackRating#, #InsertedDateTime#) VALUES ('" + irnNo + "', '" + employeeID + "', '" + questionID + "', '" + rowValue + "', now())";

                                        feedbackInsertQuery = feedbackInsertQuery.Replace('#', '"');

                                        NpgsqlCommand feedbackCommand = new NpgsqlCommand(feedbackInsertQuery, npgsqlCon);
                                        NpgsqlDataReader feedbackDataReader = feedbackCommand.ExecuteReader();

                                        npgsqlCon.Close();
                                    }
                                }

                                if (string.Equals(columnName, "Employee_ID"))
                                {
                                    string employeeSql = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# = '" + employeeID + "' and A.#Active_Separated# = 'Active'";

                                    employeeSql = employeeSql.Replace('#', '"');

                                    npgsqlCon.Open();

                                    NpgsqlCommand empCommand = new NpgsqlCommand(employeeSql, npgsqlCon);
                                    NpgsqlDataReader empReader = empCommand.ExecuteReader();

                                    while (empReader.Read())
                                    {
                                        employeeCode = empReader[0].ToString();
                                        employeeName = empReader[1].ToString();
                                        department = empReader[2].ToString();
                                        country = empReader[3].ToString();
                                        employeeGrade = empReader[4].ToString();
                                        subProcess = empReader[5].ToString();
                                        doj = Convert.ToDateTime(empReader[6].ToString()).ToString("yyyy-MM-dd");
                                        companyCode = empReader[7].ToString();
                                    }

                                    npgsqlCon.Close();

                                    if (!string.IsNullOrWhiteSpace(employeeCode))
                                    {
                                        //Insert into Induction Employee
                                        npgsqlCon.Open();

                                        string employeeInsert = "INSERT INTO public.#InductionEmployees#(#IRNNo#, #EmployeeCode#, #EmployeeName#, #Department#, #CompanyCode#, #EmployeeGrade#, #SubProcess#, #DOJ#, #FeedbackRemarks#,#InsertedDateTime#) VALUES ('" + irnNo + "', '" + employeeCode + "', '" + employeeName + "', '" + department + "', '" + companyCode + "', '" + employeeGrade + "', '" + subProcess + "', '" + doj + "', '" + comment + "', now())";

                                        employeeInsert = employeeInsert.Replace('#', '"');

                                        NpgsqlCommand empInsetCommand = new NpgsqlCommand(employeeInsert, npgsqlCon);
                                        NpgsqlDataReader empInsetDataReader = empInsetCommand.ExecuteReader();

                                        npgsqlCon.Close();
                                    }
                                }

                            }
                        }
                    }

                    response.responseCode = 1;
                    response.responseJSON = JsonConvert.SerializeObject("Success");
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = 1;
                    response.responseJSON = JsonConvert.SerializeObject("Success");
                    response.responseMessage = "Employee alerdy exist in Induction Group.";
                }

                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject("Success");
                //response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass InsertInductionGroupFeedbackDraftDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
                //string[] chekEmployeeGroup = request.EmployeeCode.Split(',');
                var chkfeedbackDatatable = JsonConvert.DeserializeObject<DataTable>(request.FeedbackData);
                string checkEmployeeGroupData = string.Empty;
                List<string> employeeList = new List<string>();
                List<string> dummyEmployeeList = new List<string>();

                if(chkfeedbackDatatable.Rows.Count > 1)
                {
                    for(int j = 0; j <= chkfeedbackDatatable.Rows.Count - 1; j++)
                    {
                        for(int i = chkfeedbackDatatable.Columns.Count - 1; i >= 0; i--)
                        {
                            string columnName = Convert.ToString(chkfeedbackDatatable.Columns[i]);
                            string chkEmployeeID = Convert.ToString(chkfeedbackDatatable.Rows[j][0]);
                            if(string.Equals(columnName, "Employee_ID"))
                            {
                                dummyEmployeeList.Add(chkEmployeeID);
                            }
                        }
                    }
                }

                foreach (var empid in dummyEmployeeList)
                {
                    checkEmployeeGroupData += "'" + empid + "',";
                }

                checkEmployeeGroupData = checkEmployeeGroupData.Substring(0, checkEmployeeGroupData.Length - 1);

                npgsqlCon.Open();

                string checkEmployeeTblGroup = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# IN (" + checkEmployeeGroupData + ") and A.#Active_Separated# = 'Active'";

                checkEmployeeTblGroup = checkEmployeeTblGroup.Replace('#','"');

                NpgsqlCommand checkEmployeeTblGroupCMD = new NpgsqlCommand(checkEmployeeTblGroup, npgsqlCon);
                NpgsqlDataReader checkEmployeeDataReader = checkEmployeeTblGroupCMD.ExecuteReader();
                while (checkEmployeeDataReader.Read())
                {
                    employeeList.Add(checkEmployeeDataReader[0].ToString());
                }

                npgsqlCon.Close();

                if(employeeList.Count() > 0)
                {
                    //IRN Number
                    string irnNo = string.Empty;
                    int irnCount = 0;
                    string sqlQuery3 = "SELECT max(#IRNSequenceNo#) as #IRNSequenceNo# FROM public.#InductionGroup#";

                    sqlQuery3 = sqlQuery3.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery3, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                    if (npgsqlDataReader1.Read())
                    {
                        irnNo = npgsqlDataReader1[0].ToString();
                        irnCount = Convert.ToInt32(irnNo) + 1;
                        irnNo = "IRN" + irnCount;
                    }
                    else
                    {
                        ++irnCount;
                        irnNo = "IRN" + irnCount;
                    }

                    npgsqlCon.Close();

                    string sqlQuery = "INSERT INTO public.#InductionGroup#(#IRNNo#,#GeoName#,#CityName#,#OnboarderEMPCode#,#InductionFaciliatorEMPCode#,#SubmissionType#,#GroupStatus#,#IRNFeedbackFilePath#,#InsertedDateTime#,#InsertedIPAddress#, #InsertedBy#,#IRNSequenceNo#) VALUES('" + irnNo + "', '" + request.Geo + "', '" + request.City + "', '" + request.OnboarderEmpCode + "', '" + request.InductionFacilitatorEmpCode + "', '" + request.TypeOfSubmission + "', 'Draft', '" + request.IRNFeedbackFilePath + "', '" + Convert.ToDateTime(request.InductionDate).ToString("yyyy-MM-dd HH:mm:ss") + "', '" + request.InsertedIPAddress + "', '" + request.InsertedBy + "'," + irnCount + ")";

                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();

                    //Insert into Induction Feedback
                    var feedbackDatatable = JsonConvert.DeserializeObject<DataTable>(request.FeedbackData);
                    string comment = string.Empty;
                    string employeeID = string.Empty;

                    string employeeCode = string.Empty;
                    string employeeName = string.Empty;
                    string department = string.Empty;
                    string country = string.Empty;
                    string companyCode = string.Empty;
                    string employeeGrade = string.Empty;
                    string subProcess = string.Empty;
                    string doj = string.Empty;
                    string questionID = string.Empty;
                    string geoData = string.Empty;
                    string tempEmp = string.Empty;

                if (feedbackDatatable.Rows.Count > 1)
                {
                    for(int j = 0; j <= feedbackDatatable.Rows.Count - 1; j++)
                    {
                        employeeCode = string.Empty;
                        employeeName = string.Empty;
                        department = string.Empty;
                        country = string.Empty;
                        companyCode = string.Empty;
                        employeeGrade = string.Empty;
                        subProcess = string.Empty;
                        doj = string.Empty;
                        questionID = string.Empty;
                        geoData = string.Empty;
                        for (int i = 0; i <= feedbackDatatable.Columns.Count - 1; i++)
                        {
                            string columnName = Convert.ToString(feedbackDatatable.Columns[i]);
                            employeeID = Convert.ToString(feedbackDatatable.Rows[j][0]);
                            comment = Convert.ToString(feedbackDatatable.Rows[j][feedbackDatatable.Columns.Count - 1]);
                            if (string.Equals(columnName, "Employee_ID"))
                            {
                                string employeeSql = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# = '" + employeeID + "' and A.#Active_Separated# = 'Active'";

                                employeeSql = employeeSql.Replace('#', '"');

                                npgsqlCon.Open();

                                NpgsqlCommand empCommand = new NpgsqlCommand(employeeSql, npgsqlCon);
                                NpgsqlDataReader empReader = empCommand.ExecuteReader();

                                while (empReader.Read())
                                {
                                    employeeCode = empReader[0].ToString();
                                    employeeName = empReader[1].ToString();
                                    department = empReader[2].ToString();
                                    country = empReader[3].ToString();
                                    employeeGrade = empReader[4].ToString();
                                    subProcess = empReader[5].ToString();
                                    doj = Convert.ToDateTime(empReader[6].ToString()).ToString("yyyy-MM-dd");
                                    companyCode = empReader[7].ToString();
                                }

                                npgsqlCon.Close();

                                if (!string.IsNullOrWhiteSpace(employeeCode))
                                {
                                    //Insert into Induction Employee
                                    npgsqlCon.Open();

                                    string employeeInsert = "INSERT INTO public.#InductionEmployees#(#IRNNo#, #EmployeeCode#, #EmployeeName#, #Department#, #CompanyCode#, #EmployeeGrade#, #SubProcess#, #DOJ#, #FeedbackRemarks#,#InsertedDateTime#) VALUES ('" + irnNo + "', '" + employeeCode + "', '" + employeeName + "', '" + department + "', '" + companyCode + "', '" + employeeGrade + "', '" + subProcess + "', '" + doj + "', '" + comment + "', now())";

                                    employeeInsert = employeeInsert.Replace('#', '"');

                                    NpgsqlCommand empInsetCommand = new NpgsqlCommand(employeeInsert, npgsqlCon);
                                    NpgsqlDataReader empInsetDataReader = empInsetCommand.ExecuteReader();

                                    npgsqlCon.Close();
                                }
                            }
                            if (!string.Equals(columnName, "Employee_ID") && !string.Equals(columnName, "Comments") && !string.IsNullOrWhiteSpace(employeeCode))
                            {
                                string rowValue = Convert.ToString(feedbackDatatable.Rows[j][i]);
                                string columnValue = Convert.ToString(feedbackDatatable.Columns[i]);

                                string sqlQuery1 = "select #MasterValue# from #CommonMasterValue# where #MasterCode# = 'M001' and #ISActive# = 1 and #CMValueID# = " + Convert.ToInt32(request.Geo);

                                sqlQuery1 = sqlQuery1.Replace('#', '"');

                                npgsqlCon.Open();

                                NpgsqlCommand npgsqlCommand11 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                                NpgsqlDataReader npgsqlDataReader11 = npgsqlCommand11.ExecuteReader();

                                while (npgsqlDataReader11.Read())
                                {
                                    geoData = npgsqlDataReader11[0].ToString();
                                }

                                npgsqlCon.Close();

                                //Feedback Question ID
                                npgsqlCon.Open();

                                string feedbackQuestionIDQuery = "SELECT #tid# FROM public.#Induction_FeedbackQBank# where #questionname# = '" + columnValue + "' and #geoname# = '" + geoData + "'";

                                feedbackQuestionIDQuery = feedbackQuestionIDQuery.Replace('#', '"');

                                NpgsqlCommand feedbackQuestionCMD = new NpgsqlCommand(feedbackQuestionIDQuery, npgsqlCon);
                                NpgsqlDataReader npgsqlDataReader = feedbackQuestionCMD.ExecuteReader();

                                while (npgsqlDataReader.Read())
                                {
                                    questionID = npgsqlDataReader[0].ToString();
                                }

                                npgsqlCon.Close();

                                //Insert Feedback question
                                npgsqlCon.Open();

                                string feedbackInsertQuery = "INSERT INTO public.#InductionFeedback#(#IRNNo#, #EmployeeCode#, #QuestionCode#, #FeedbackRating#, #InsertedDateTime#) VALUES ('" + irnNo + "', '" + employeeID + "', '" + questionID + "', '" + rowValue + "', now())";

                                feedbackInsertQuery = feedbackInsertQuery.Replace('#', '"');

                                NpgsqlCommand feedbackCommand = new NpgsqlCommand(feedbackInsertQuery, npgsqlCon);
                                NpgsqlDataReader feedbackDataReader = feedbackCommand.ExecuteReader();

                                npgsqlCon.Close();

                                    //Insert into Feedback
                                    //string tmpemployeeSql = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# = '" + employeeID + "' and A.#Active_Separated# = 'Active'";

                                    //tmpemployeeSql = tmpemployeeSql.Replace('#', '"');

                                    //npgsqlCon.Open();

                                    //NpgsqlCommand tempCmd = new NpgsqlCommand(tmpemployeeSql, npgsqlCon);
                                    //NpgsqlDataReader tempreader = tempCmd.ExecuteReader();

                                    //while (tempreader.Read())
                                    //{
                                    //    tempEmp = tempreader[0].ToString();
                                    //}

                                    //npgsqlCon.Close();

                                    //if (!string.IsNullOrWhiteSpace(tempEmp))
                                    //{
                                    //    string sqlQuery1 = "select #MasterValue# from #CommonMasterValue# where #MasterCode# = 'M001' and #ISActive# = 1 and #CMValueID# = " + Convert.ToInt32(request.Geo);

                                    //    sqlQuery1 = sqlQuery1.Replace('#', '"');

                                    //    npgsqlCon.Open();

                                    //    NpgsqlCommand npgsqlCommand11 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                                    //    NpgsqlDataReader npgsqlDataReader11 = npgsqlCommand11.ExecuteReader();

                                    //    while (npgsqlDataReader11.Read())
                                    //    {
                                    //        geoData = npgsqlDataReader11[0].ToString();
                                    //    }

                                    //    npgsqlCon.Close();

                                    //    //Feedback Question ID
                                    //    npgsqlCon.Open();

                                    //    string feedbackQuestionIDQuery = "SELECT #tid# FROM public.#Induction_FeedbackQBank# where #questionname# = '" + columnValue + "' and #geoname# = '" + geoData + "'";

                                    //    feedbackQuestionIDQuery = feedbackQuestionIDQuery.Replace('#', '"');

                                    //    NpgsqlCommand feedbackQuestionCMD = new NpgsqlCommand(feedbackQuestionIDQuery, npgsqlCon);
                                    //    NpgsqlDataReader npgsqlDataReader = feedbackQuestionCMD.ExecuteReader();

                                    //    while (npgsqlDataReader.Read())
                                    //    {
                                    //        questionID = npgsqlDataReader[0].ToString();
                                    //    }

                                    //    npgsqlCon.Close();

                                    //    //Insert Feedback question
                                    //    npgsqlCon.Open();

                                    //    string feedbackInsertQuery = "INSERT INTO public.#InductionFeedback#(#IRNNo#, #EmployeeCode#, #QuestionCode#, #FeedbackRating#, #InsertedDateTime#) VALUES ('" + irnNo + "', '" + employeeID + "', '" + questionID + "', '" + rowValue + "', now())";

                                    //    feedbackInsertQuery = feedbackInsertQuery.Replace('#', '"');

                                    //    NpgsqlCommand feedbackCommand = new NpgsqlCommand(feedbackInsertQuery, npgsqlCon);
                                    //    NpgsqlDataReader feedbackDataReader = feedbackCommand.ExecuteReader();

                                    //    npgsqlCon.Close();
                                    //}
                                }

                                //if (string.Equals(columnName, "Employee_ID"))
                                //{
                                //    string employeeSql = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#,concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,A.#DOJ# as #DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A left join #InductionEmployees# B on A.#EXTERNALDATAREFERENCE#=B.#EmployeeCode# where coalesce(B.#TID#,0)=0 and A.#EXTERNALDATAREFERENCE# = '" + employeeID + "' and A.#Active_Separated# = 'Active'";

                                //    employeeSql = employeeSql.Replace('#', '"');

                                //    npgsqlCon.Open();

                                //    NpgsqlCommand empCommand = new NpgsqlCommand(employeeSql, npgsqlCon);
                                //    NpgsqlDataReader empReader = empCommand.ExecuteReader();

                                //    while (empReader.Read())
                                //    {
                                //        employeeCode = empReader[0].ToString();
                                //        employeeName = empReader[1].ToString();
                                //        department = empReader[2].ToString();
                                //        country = empReader[3].ToString();
                                //        employeeGrade = empReader[4].ToString();
                                //        subProcess = empReader[5].ToString();
                                //        doj = Convert.ToDateTime(empReader[6].ToString()).ToString("yyyy-MM-dd");
                                //        companyCode = empReader[7].ToString();
                                //    }

                                //    npgsqlCon.Close();

                                //    if (!string.IsNullOrWhiteSpace(employeeCode))
                                //    {
                                //        //Insert into Induction Employee
                                //        npgsqlCon.Open();

                                //        string employeeInsert = "INSERT INTO public.#InductionEmployees#(#IRNNo#, #EmployeeCode#, #EmployeeName#, #Department#, #CompanyCode#, #EmployeeGrade#, #SubProcess#, #DOJ#, #FeedbackRemarks#,#InsertedDateTime#) VALUES ('" + irnNo + "', '" + employeeCode + "', '" + employeeName + "', '" + department + "', '" + companyCode + "', '" + employeeGrade + "', '" + subProcess + "', '" + doj + "', '" + comment + "', now())";

                                //        employeeInsert = employeeInsert.Replace('#', '"');

                                //        NpgsqlCommand empInsetCommand = new NpgsqlCommand(employeeInsert, npgsqlCon);
                                //        NpgsqlDataReader empInsetDataReader = empInsetCommand.ExecuteReader();

                                //        npgsqlCon.Close();
                                //    }
                                //}

                            }
                        }
                    }
                    response.responseCode = 1;
                    response.responseJSON = JsonConvert.SerializeObject("Success");
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = 1;
                    response.responseJSON = JsonConvert.SerializeObject("Success");
                    response.responseMessage = "Employee alerdy exist in Induction Group";
                }

                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject("Success");
                //response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetInductionGroupSearchList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;
            string cityID = string.Empty;
            try
            {
                DataTable inductionGroupSearchList = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlConn = new NpgsqlConnection(pgsqlConnection);
                string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);
                fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");

                //if (!string.IsNullOrEmpty(request.City))
                //{
                //    string[] city = request.City.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                    

                   
                    

                //    foreach (var item in city)
                //    {
                //        npgsqlConn.Open();

                //        string serachCityQuery = "SELECT #CMValueID# FROM public.#CommonMasterValue# WHERE #MasterValue# = " + item;
                //        serachCityQuery = serachCityQuery.Replace('#', '"');
                //        NpgsqlCommand searchCityCommand = new NpgsqlCommand(serachCityQuery, npgsqlConn);
                //        NpgsqlDataReader searchCityReader = searchCityCommand.ExecuteReader();

                //        while (searchCityReader.Read())
                //        {
                //            cityID += searchCityReader[0].ToString() + ",";
                //        }

                //        npgsqlConn.Close();
                //    }

                //    cityID = cityID.Substring(0, cityID.Length - 1);
                //}
                

                //using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                //{
                //    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_inductiongrouplistbysearch('"+fromDate+"','"+toDate+"','"+request.Geo+"','"+cityID+"','"+request.ProgramManagerEmpCode+"','"+request.Status+"','"+request.IRNNo+"')", npgsqlConnection))
                //    {
                //        npgsqlConnection.Open();

                //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                //        dataAdapter.Fill(inductionGroupSearchList);
                //        response.responseCode = 1;
                //        response.responseJSON = JsonConvert.SerializeObject(inductionGroupSearchList);

                //        npgsqlConnection.Close();
                //    }
                //}

                npgsqlConn.Open();

                string searchData = "select * from public.fn_get_inductiongrouplistbysearch('" + fromDate + "','" + toDate + "','" + request.Geo + "','" + request.City + "','" + request.ProgramManagerEmpCode + "','" + request.Status + "','" + request.IRNNo + "')";

                NpgsqlCommand cmd = new NpgsqlCommand(searchData,npgsqlConn);
                NpgsqlDataAdapter nda = new NpgsqlDataAdapter(cmd);
                nda.Fill(inductionGroupSearchList);

                npgsqlConn.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(inductionGroupSearchList);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass UpdateInductionGroupDraftDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                //Updation Induction Group
                string updateGroup = "UPDATE public.#InductionGroup# SET #GeoName#='" + request.Geo + "', #CityName#='" + request.City + "', #OnboarderEMPCode#='" + request.OnboarderEmpCode + "', #InductionFaciliatorEMPCode#='" + request.InductionFacilitatorEmpCode + "', #SubmissionType#='" + request.TypeOfSubmission + "', #GroupStatus#='Draft', #InsertedDateTime#='" + Convert.ToDateTime(request.InductionDate).ToString("yyyy-MM-dd") + "', #UpdatedDateTime#=now(), #UpdatedBy#='" + request.UpdatedBy + "', #UpdatedIPAddress#='" + request.UpdatedIPAddress + "' WHERE #IRNNo# = '" + request.IRNNo + "'";

                updateGroup = updateGroup.Replace('#','"');


                npgsqlCon.Open();

                NpgsqlCommand updateGroupCMD = new NpgsqlCommand(updateGroup,npgsqlCon);
                NpgsqlDataReader updateDataReader = updateGroupCMD.ExecuteReader();

                npgsqlCon.Close();

                //Updation Induction Employee
                string[] employeeID = request.EmployeeCode.Split(',');
                string[] employeeName = request.EmployeeName.Split(',');
                string[] department = request.Department.Split(',');
                string[] country = request.Country.Split(',');
                string[] subProcess = request.SubProcess.Split(',');
                string[] grade = request.Grade.Split(',');
                string[] doj = request.DOJ.Split(',');
                string[] companyCode = request.CompanyCode.Split(',');

                string employeeCode = string.Empty;
                string chkemployeeCode = string.Empty;

                List<string> deleteEmpData = new List<string>();
                string deleteEmployeeCode = string.Empty;

                npgsqlCon.Open();

                string deleteRowChkQuery = "select #EmployeeCode# from public.#InductionEmployees# where #IRNNo# = '" + request.IRNNo + "'";
                deleteRowChkQuery = deleteRowChkQuery.Replace('#','"');
                NpgsqlCommand deleteEmpCMD = new NpgsqlCommand(deleteRowChkQuery,npgsqlCon);
                NpgsqlDataReader deleteEmpRaeder = deleteEmpCMD.ExecuteReader();

                while(deleteEmpRaeder.Read())
                {
                    deleteEmpData.Add(deleteEmpRaeder[0].ToString());
                }

                npgsqlCon.Close();

                if(deleteEmpData.Count != employeeID.Length)
                {
                    var deleteRowEmpCode = deleteEmpData.Except(employeeID);

                    foreach (var empCodeData in deleteRowEmpCode)
                    {
                        npgsqlCon.Open();

                        string deleteRowEmpDataQuery = "DELETE FROM public.#InductionEmployees# WHERE #IRNNo# = '" + request.IRNNo + "' AND #EmployeeCode# = '" + empCodeData + "'";

                        deleteRowEmpDataQuery = deleteRowEmpDataQuery.Replace('#', '"');

                        NpgsqlCommand deleteRowEmpCMD = new NpgsqlCommand(deleteRowEmpDataQuery, npgsqlCon);
                        NpgsqlDataReader deleteRowEmpReader = deleteRowEmpCMD.ExecuteReader();

                        npgsqlCon.Close();

                        if(Convert.ToInt32(request.TypeOfSubmission) == 9)
                        {
                            npgsqlCon.Open();

                            string deleteEmpFeedbackQuery = "DELETE FROM public.#InductionFeedback# where #IRNNo# = '" + request.IRNNo + "' AND #EmployeeCode# = '" + empCodeData + "'";

                            deleteEmpFeedbackQuery = deleteEmpFeedbackQuery.Replace('#','"');
                            NpgsqlCommand deleteEmpFeedbackCMD = new NpgsqlCommand(deleteEmpFeedbackQuery,npgsqlCon);
                            NpgsqlDataReader deleteEmpFeedbackReader = deleteEmpFeedbackCMD.ExecuteReader();

                            npgsqlCon.Close();
                        }
                    }

                    //for(int i = 0; i < deleteEmpData.Count; i++)
                    //{
                    //    if(!deleteEmpData.Contains(employeeID[i]))
                    //    {
                    //        npgsqlCon.Open();

                    //        string deleteRowEmpDataQuery = "DELETE FROM public.#InductionEmployees# WHERE #IRNONo# = '" + request.IRNNo + "' AND #EmployeeCode# = '" + employeeID[i] + "'";

                    //        deleteRowEmpDataQuery = deleteRowEmpDataQuery.Replace('#','"');

                    //        NpgsqlCommand deleteRowEmpCMD = new NpgsqlCommand(deleteRowEmpDataQuery,npgsqlCon);
                    //        NpgsqlDataReader deleteRowEmpReader = deleteRowEmpCMD.ExecuteReader();

                    //        npgsqlCon.Close();
                    //    }
                    //}
                }

                for (int i = 0; i < employeeID.Length; i++)
                {
                    string chkUpdateEmployee = "SELECT #EmployeeCode# FROM public.#InductionEmployees# where #EmployeeCode# = '" + employeeID[i] + "' and #IRNNo# = '" + request.IRNNo + "'";
                    chkUpdateEmployee = chkUpdateEmployee.Replace('#','"');
                    npgsqlCon.Open();
                    NpgsqlCommand chkUpdateEmployeeCMD = new NpgsqlCommand(chkUpdateEmployee,npgsqlCon);
                    NpgsqlDataReader chkUpdateEmpolyeeReader = chkUpdateEmployeeCMD.ExecuteReader();
                    while(chkUpdateEmpolyeeReader.Read())
                    {
                        employeeCode = chkUpdateEmpolyeeReader[0].ToString();
                    }
                    npgsqlCon.Close();

                    if(!string.IsNullOrWhiteSpace(employeeCode))
                    {
                        string updateEmployee = "UPDATE public.#InductionEmployees# SET #EmployeeCode# = '" + employeeID[i] + "', #EmployeeName#='" + employeeName[i] + "', #Department#='" + department[i] + "', #CompanyCode#='" + companyCode[i] + "', #EmployeeGrade#='" + grade[i] + "', #SubProcess#='" + subProcess[i] + "', #DOJ#='" + doj[i] + "' WHERE #IRNNo# = '" + request.IRNNo + "' AND #EmployeeCode# = '" + employeeID[i] + "'";
                        updateEmployee = updateEmployee.Replace('#','"');
                        npgsqlCon.Open();
                        NpgsqlCommand updateEmployeeCMD = new NpgsqlCommand(updateEmployee,npgsqlCon);
                        NpgsqlDataReader updateEmployeeReader = updateEmployeeCMD.ExecuteReader();
                        npgsqlCon.Close();
                    }
                    else
                    {
                        npgsqlCon.Open();

                        string sqlCheckQuery = "SELECT #EmployeeCode# FROM public.#InductionEmployees# WHERE #EmployeeCode# = '" + employeeID[i] + "'";

                        sqlCheckQuery = sqlCheckQuery.Replace('#', '"');

                        NpgsqlCommand chkCommand = new NpgsqlCommand(sqlCheckQuery, npgsqlCon);

                        NpgsqlDataReader chkDataRaeder = chkCommand.ExecuteReader();

                        if (chkDataRaeder.Read())
                        {
                            chkemployeeCode = chkDataRaeder[0].ToString();
                        }

                        npgsqlCon.Close();

                        npgsqlCon.Open();

                        if (string.IsNullOrWhiteSpace(chkemployeeCode))
                        {
                            string sqlQuery2 = "INSERT INTO public.#InductionEmployees#(#IRNNo#, #EmployeeCode#, #EmployeeName#, #Department#, #CompanyCode#, #EmployeeGrade#, #SubProcess#, #DOJ#, #FeedbackRemarks#, #InsertedDateTime#) VALUES('" + request.IRNNo + "','" + employeeID[i] + "','" + employeeName[i] + "','" + department[i] + "','" + companyCode[i] + "','" + grade[i] + "','" + subProcess[i] + "','" + doj[i] + "','',now())";

                            sqlQuery2 = sqlQuery2.Replace('#', '"');

                            NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

                            NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();
                        }

                        npgsqlCon.Close();
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass UpdateInductionGroupDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                //Updation Induction Group
                string updateGroup = "UPDATE public.#InductionGroup# SET #GeoName#='" + request.Geo + "', #CityName#='" + request.City + "', #OnboarderEMPCode#='" + request.OnboarderEmpCode + "', #InductionFaciliatorEMPCode#='" + request.InductionFacilitatorEmpCode + "', #SubmissionType#='" + request.TypeOfSubmission + "', #GroupStatus#='Completed', #InsertedDateTime#='" + Convert.ToDateTime(request.InductionDate).ToString("yyyy-MM-dd") + "', #UpdatedDateTime#=now(), #UpdatedBy#='" + request.UpdatedBy + "', #UpdatedIPAddress#='" + request.UpdatedIPAddress + "' WHERE #IRNNo# = '" + request.IRNNo + "'";

                updateGroup = updateGroup.Replace('#', '"');


                npgsqlCon.Open();

                NpgsqlCommand updateGroupCMD = new NpgsqlCommand(updateGroup, npgsqlCon);
                NpgsqlDataReader updateDataReader = updateGroupCMD.ExecuteReader();

                npgsqlCon.Close();

                //Updation Induction Employee
                string[] employeeID = request.EmployeeCode.Split(',');
                string[] employeeName = request.EmployeeName.Split(',');
                string[] department = request.Department.Split(',');
                string[] country = request.Country.Split(',');
                string[] subProcess = request.SubProcess.Split(',');
                string[] grade = request.Grade.Split(',');
                string[] doj = request.DOJ.Split(',');
                string[] companyCode = request.CompanyCode.Split(',');

                string employeeCode = string.Empty;
                string chkemployeeCode = string.Empty;

                List<string> deleteEmpData = new List<string>();
                string deleteEmployeeCode = string.Empty;

                npgsqlCon.Open();

                string deleteRowChkQuery = "select #EmployeeCode# from public.#InductionEmployees# where #IRNNo# = '" + request.IRNNo + "'";
                deleteRowChkQuery = deleteRowChkQuery.Replace('#', '"');
                NpgsqlCommand deleteEmpCMD = new NpgsqlCommand(deleteRowChkQuery, npgsqlCon);
                NpgsqlDataReader deleteEmpRaeder = deleteEmpCMD.ExecuteReader();

                while (deleteEmpRaeder.Read())
                {
                    deleteEmpData.Add(deleteEmpRaeder[0].ToString());
                }

                npgsqlCon.Close();

                if (deleteEmpData.Count != employeeID.Length)
                {
                    var deleteRowEmpCode = deleteEmpData.Except(employeeID);

                    foreach (var empCodeData in deleteRowEmpCode)
                    {
                        npgsqlCon.Open();

                        string deleteRowEmpDataQuery = "DELETE FROM public.#InductionEmployees# WHERE #IRNNo# = '" + request.IRNNo + "' AND #EmployeeCode# = '" + empCodeData + "'";

                        deleteRowEmpDataQuery = deleteRowEmpDataQuery.Replace('#', '"');

                        NpgsqlCommand deleteRowEmpCMD = new NpgsqlCommand(deleteRowEmpDataQuery, npgsqlCon);
                        NpgsqlDataReader deleteRowEmpReader = deleteRowEmpCMD.ExecuteReader();

                        npgsqlCon.Close();

                        if (Convert.ToInt32(request.TypeOfSubmission) == 9)
                        {
                            npgsqlCon.Open();

                            string deleteEmpFeedbackQuery = "DELETE FROM public.#InductionFeedback# where #IRNNo# = '" + request.IRNNo + "' AND #EmployeeCode# = '" + empCodeData + "'";

                            deleteEmpFeedbackQuery = deleteEmpFeedbackQuery.Replace('#', '"');
                            NpgsqlCommand deleteEmpFeedbackCMD = new NpgsqlCommand(deleteEmpFeedbackQuery, npgsqlCon);
                            NpgsqlDataReader deleteEmpFeedbackReader = deleteEmpFeedbackCMD.ExecuteReader();

                            npgsqlCon.Close();
                        }
                    }

                    //for(int i = 0; i < deleteEmpData.Count; i++)
                    //{
                    //    if(!deleteEmpData.Contains(employeeID[i]))
                    //    {
                    //        npgsqlCon.Open();

                    //        string deleteRowEmpDataQuery = "DELETE FROM public.#InductionEmployees# WHERE #IRNONo# = '" + request.IRNNo + "' AND #EmployeeCode# = '" + employeeID[i] + "'";

                    //        deleteRowEmpDataQuery = deleteRowEmpDataQuery.Replace('#','"');

                    //        NpgsqlCommand deleteRowEmpCMD = new NpgsqlCommand(deleteRowEmpDataQuery,npgsqlCon);
                    //        NpgsqlDataReader deleteRowEmpReader = deleteRowEmpCMD.ExecuteReader();

                    //        npgsqlCon.Close();
                    //    }
                    //}
                }

                for (int i = 0; i < employeeID.Length; i++)
                {
                    string chkUpdateEmployee = "SELECT #EmployeeCode# FROM public.#InductionEmployees# where #EmployeeCode# = '" + employeeID[i] + "' and #IRNNo# = '" + request.IRNNo + "'";
                    chkUpdateEmployee = chkUpdateEmployee.Replace('#', '"');
                    npgsqlCon.Open();
                    NpgsqlCommand chkUpdateEmployeeCMD = new NpgsqlCommand(chkUpdateEmployee, npgsqlCon);
                    NpgsqlDataReader chkUpdateEmpolyeeReader = chkUpdateEmployeeCMD.ExecuteReader();
                    while (chkUpdateEmpolyeeReader.Read())
                    {
                        employeeCode = chkUpdateEmpolyeeReader[0].ToString();
                    }
                    npgsqlCon.Close();

                    if (!string.IsNullOrWhiteSpace(employeeCode))
                    {
                        string updateEmployee = "UPDATE public.#InductionEmployees# SET #EmployeeCode# = '" + employeeID[i] + "', #EmployeeName#='" + employeeName[i] + "', #Department#='" + department[i] + "', #CompanyCode#='" + companyCode[i] + "', #EmployeeGrade#='" + grade[i] + "', #SubProcess#='" + subProcess[i] + "', #DOJ#='" + doj[i] + "' WHERE #IRNNo# = '" + request.IRNNo + "' AND #EmployeeCode# = '" + employeeID[i] + "'";
                        updateEmployee = updateEmployee.Replace('#', '"');
                        npgsqlCon.Open();
                        NpgsqlCommand updateEmployeeCMD = new NpgsqlCommand(updateEmployee, npgsqlCon);
                        NpgsqlDataReader updateEmployeeReader = updateEmployeeCMD.ExecuteReader();
                        npgsqlCon.Close();
                    }
                    else
                    {
                        npgsqlCon.Open();

                        string sqlCheckQuery = "SELECT #EmployeeCode# FROM public.#InductionEmployees# WHERE #EmployeeCode# = '" + employeeID[i] + "'";

                        sqlCheckQuery = sqlCheckQuery.Replace('#', '"');

                        NpgsqlCommand chkCommand = new NpgsqlCommand(sqlCheckQuery, npgsqlCon);

                        NpgsqlDataReader chkDataRaeder = chkCommand.ExecuteReader();

                        if (chkDataRaeder.Read())
                        {
                            chkemployeeCode = chkDataRaeder[0].ToString();
                        }

                        npgsqlCon.Close();

                        npgsqlCon.Open();

                        if (string.IsNullOrWhiteSpace(chkemployeeCode))
                        {
                            string sqlQuery2 = "INSERT INTO public.#InductionEmployees#(#IRNNo#, #EmployeeCode#, #EmployeeName#, #Department#, #CompanyCode#, #EmployeeGrade#, #SubProcess#, #DOJ#, #FeedbackRemarks#, #InsertedDateTime#) VALUES('" + request.IRNNo + "','" + employeeID[i] + "','" + employeeName[i] + "','" + department[i] + "','" + companyCode[i] + "','" + grade[i] + "','" + subProcess[i] + "','" + doj[i] + "','',now())";

                            sqlQuery2 = sqlQuery2.Replace('#', '"');

                            NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

                            NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();
                        }

                        npgsqlCon.Close();
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetInductionFeedbackQuestionList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable inductionFeddbackQuestion = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand questionCmd = new NpgsqlCommand(@"select * from public.fn_get_inductionfeedbackquestion(:p_geo)", npgsqlConnection))
                    {
                        questionCmd.CommandType = CommandType.Text;
                        if (!string.IsNullOrWhiteSpace(request.Geo))
                            questionCmd.Parameters.AddWithValue("p_geo", DbType.Int32).Value = Convert.ToInt32(request.Geo);
                        else
                            questionCmd.Parameters.AddWithValue("p_geo", DbType.Int32).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter questionAdapter = new NpgsqlDataAdapter(questionCmd);
                        questionAdapter.Fill(inductionFeddbackQuestion);

                        npgsqlConnection.Close();
                    }
                }

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(inductionFeddbackQuestion);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            return response;
        }
    }
}
