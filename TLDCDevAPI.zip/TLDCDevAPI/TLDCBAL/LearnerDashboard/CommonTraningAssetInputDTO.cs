﻿namespace TLDCBAL.LearnerDashboard
{
    public class CommonTraningAssetInputDTO
    {
        public string EmployeeID { get; set; }
        public string StrtDate { get; set; }
        public string EndDate { get; set; }
    }
}
