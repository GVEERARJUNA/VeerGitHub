﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.MobApp;
using TLDCBAL.Qualtrics;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;
using TLDCBAL.WebSite;
using TLDCDAL;

namespace TLDCBAL.LearnerDashboard
{
   public class LearnerDashboardBL: ILearnerDashboardBL
    {
        private readonly IServiceConnect _serviceconnect;
        private IQualtricsDataBL _qualtricsBL;
        private ISchedulerBL _scheduleBL;
        DBConnection AssessmentdBConnection;
        DBConnection SurveyDBConnection;
        private readonly IOptions<IDBConnection> appSettings;
        DBConnection dBConnection;

        public LearnerDashboardBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect,
            IQualtricsDataBL qualtricsBL, ISchedulerBL scheduleBL)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.QualtricsDbConnection);
            AssessmentdBConnection = new DBConnection(appSettings.Value.AssessmentDBConnection);
            SurveyDBConnection = new DBConnection(appSettings.Value.SurveyDBConnection);
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
            _scheduleBL = scheduleBL;
        }

        public ResponseClass GetLearnerDashboardCount(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_count
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetLearnerDashboardCount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetTotalTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_total_training_bifurcation
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetTotalTrainingBifurcation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetCompletedTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_completed_training_bifurcation
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetCompletedTrainingBifurcation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetOngoingTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_ongoing_training_bifurcation
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetOngoingTrainingBifurcation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetPendingTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_pending_training_bifurcation
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetPendingTrainingBifurcation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetExpiredTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_expired_training_bifurcation
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetExpiredTrainingBifurcation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetLibraryTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_library_training_bifurcation
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetLibraryTrainingBifurcation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetTotalTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_total_training_assetdetails
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetTotalTrianingAssetDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetOngoingTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_ongoing_training_assetdetails
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetOngoingTrianingAssetDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetCompletedTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_completed_training_assetdetails
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetCompletedTrianingAssetDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetExpiredTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_expired_training_assetdetails
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetExpiredTrianingAssetDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetLibraryTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_library_training_assetdetails
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetExpiredTrianingAssetDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetPendingTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_pending_training_assetdetails
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetPendingTrianingAssetDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetDateWiseTrainingBifurcationforGraph(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learner_dashboard_datewise_training_bifurcation
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_startdate,
                                                                    :p_enddate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;
                       
                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetDateWiseTrainingBifurcationforGraph", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass getCertificateListByDateWise(getEmployeeCertificateRequest request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_certificate_list_by_date
                                                                        ( 
                                                                            :p_username,
                                                                            :p_currentrole,
                                                                            :p_allocationid,
                                                                            :p_startdate,
                                                                            :p_enddate
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.AllocationID))
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = request.AllocationID;
                        else
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.strtDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.strtDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.endDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.endDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getCertificateListByDateWise", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetEmployeeRecentActivities(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {

                DataTable dtCounts = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employee_recent_activity
                                                                ( 
                                                                    :p_employeecode,
                                                                    :p_fromdate,
                                                                    :p_todate
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.StrtDate))
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = request.StrtDate;
                        else
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtCounts);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtCounts);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetEmployeeRecentActivities", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

    }
}
