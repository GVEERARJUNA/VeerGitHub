﻿using TLDCBAL.Common;
using TLDCBAL.WebSite;

namespace TLDCBAL.LearnerDashboard
{
    public interface ILearnerDashboardBL
    {
        ResponseClass GetLearnerDashboardCount(CommonTraningAssetInputDTO request);
        ResponseClass GetTotalTrainingBifurcation(CommonTraningAssetInputDTO request);
        ResponseClass GetCompletedTrainingBifurcation(CommonTraningAssetInputDTO request);
        ResponseClass GetOngoingTrainingBifurcation(CommonTraningAssetInputDTO request);
        ResponseClass GetPendingTrainingBifurcation(CommonTraningAssetInputDTO request);
        ResponseClass GetExpiredTrainingBifurcation(CommonTraningAssetInputDTO request);

        ResponseClass GetLibraryTrainingBifurcation(CommonTraningAssetInputDTO request);
        ResponseClass GetTotalTrianingAssetDetails(CommonTraningAssetInputDTO request);
        ResponseClass GetOngoingTrianingAssetDetails(CommonTraningAssetInputDTO request);
        ResponseClass GetCompletedTrianingAssetDetails(CommonTraningAssetInputDTO request);
        ResponseClass GetExpiredTrianingAssetDetails(CommonTraningAssetInputDTO request);
        ResponseClass GetLibraryTrianingAssetDetails(CommonTraningAssetInputDTO request);

        ResponseClass GetPendingTrianingAssetDetails(CommonTraningAssetInputDTO request);

        ResponseClass GetDateWiseTrainingBifurcationforGraph(CommonTraningAssetInputDTO request);
        ResponseClass getCertificateListByDateWise(getEmployeeCertificateRequest request);
        ResponseClass GetEmployeeRecentActivities(CommonTraningAssetInputDTO request);

    }
}
