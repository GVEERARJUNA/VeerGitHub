﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.KnowledgeBase
{
    public class getassessmentdetailreportDTO
    {
        public string Param1 { get; set; }
        public string Param2 { get; set; }
        public string Param3 { get; set; }
        public string Param4 { get; set; }
        public string Param5 { get; set; }
        public string Param6 { get; set; }
        public string Param7 { get; set; }

        public string ObjectType { get; set; }
        public string ObjectCode { get; set; }
        public string ObjectText { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string assessmentId { get; set; }
        public string creatorId { get; set; }



    }
    //public class getSCORMCoursesProgressReportDTO
    //{
    //    public string CourseName { get; set; }
    //    public string EventName { get; set; }
    //    public string EventStatus { get; set; }

    //}
    public class getSiteUsageReportDTO
    {
        public string EmployeeId { get; set; }
        public string Designation { get; set; }
        public string Role { get; set; }
        public string ReportingAuthority { get; set; }
        public string Location { get; set; }
        public string LoginStartDate { get; set; }
        public string LoginEndDate { get; set; }
        public string IPAddress { get; set; }

    }
    public class BlendedLearnerProgressReportDTO
    {
        public string EmployeeId { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string LearningName { get; set; }
        public string EventName { get; set; }
        public string ClassName { get; set; }
        public string Progress { get; set; }
        public string Status { get; set; }
        public string AssignDate { get; set; }
        public string CompletionDate { get; set; }
        public string LoginStartDate { get; set; }
        public string LoginEndDate { get; set; }
        public string IsExpire { get; set; }

        public string CurrentEmployee { get; set; }

        public string CurrentRole { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

    }
    public class ClassroomAttendanceDetailsReportDTO
    {
        public string ClassName { get; set; }
        public string EventName { get; set; }
        public string SessionName { get; set; }
        public string TrainingDate { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
        public string Venue { get; set; }
        public string EmpName { get; set; }
        public string Attendance { get; set; }
        public string AbsentReason { get; set; }
        public string IndividualRemark { get; set; }
        public string RemarkDay { get; set; }
        public string OverallRemark { get; set; }
        public string LoginStartDate { get; set; }
        public string LoginEndDate { get; set; }
        public string EwsReason { get; set; }
        public string EwsStatus { get; set; }
        public string LearnerRating { get; set; }
        public string creatorId { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

    }
    public class SurveyQuestionSummaryReportDTO
    {
        public string SurveyName { get; set; }
        public string Class { get; set; }
        public string ClassName { get; set; }
        public string EventName { get; set; }
        public string CreationDate { get; set; }
        public string CreatedBy { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Question { get; set; }
        public string OptionText { get; set; }
        public string UserCount { get; set; }
        public string Vote { get; set; }
        public string CreationStartDate { get; set; }
        public string CreationEndDate { get; set; }
        public string SurveyStartDate { get; set; }
        public string SurveyEndDate { get; set; }
        public string CurrentEmployee { get; set; }
        public string CurrentRole { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

    }

    public class SurveySummaryDetailedReportDTO
    {
        public string SurveyName { get; set; }
        public string Class { get; set; }
        public string ClassName { get; set; }
        public string EventName { get; set; }
        public string CreationDate { get; set; }
        public string CreatedBy { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Question { get; set; }
        public string OptionText { get; set; }
        public string UserCount { get; set; }
        public string Vote { get; set; }
        public string CreationStartDate { get; set; }
        public string CreationEndDate { get; set; }
        public string SurveyStartDate { get; set; }
        public string SurveyEndDate { get; set; }
        public string CurrentEmployee { get; set; }
        public string CurrentRole { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

    }
    public class ClassroomAttendanceSummaryReportDTO
    {
        public string ClassName { get; set; }
        public string EventName { get; set; }
        public string SessionName { get; set; }
        public string TrainingDate { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
        public string Venue { get; set; }
        public int CandidateExpected { get; set; }
        public int CandidatePresent { get; set; }
        public int Ewsupdated { get; set; }
        public string LoginStartDate { get; set; }
        public string LoginEndDate { get; set; }
        public string creatorId { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

    }
    public class getAssessmentQuestionsReportDTO
    {
        public string Param1 { get; set; }
        public string QuestionType { get; set; }
        public string AssessmentIds { get; set; }

        public string CurrentRoleName { get; set; }
        public string AssignedCompany { get; set; }
        public string eventcode { get; set; }
        public string classroomcode { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public string creatorId { get; set; }
        public string fromdt { get; set; }
        public string toDate { get; set; }

    }

    public class getBOQAssessmentReportRequestDTO
    {
        public string Param1 { get; set; }
        public string Geo { get; set; }
        public string CurrentRoleName { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string EMPCode { get; set; }

    }


    public class getPOSHReportRequestDTO
    {
        public string Year { get; set; }
        public string Month { get; set; }
        public string CurrentRoleName { get; set; }
        public string EMPCode { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

    }

    public class getAssessmentReportDTO
    {
        public string Param1 { get; set; }
        public string currentRole { get; set; }
        public string classIds { get; set; }
        public string eventIds { get; set; }
        public string assmntIds { get; set; }
        public string creatorId { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public string FromDate { get; set; }
        public string toDate { get; set; }

    }
    public class LearningDistributionReport
    {
        public string ClassName { get; set; }
        public string EventName { get; set; }
        public string LearningName { get; set; }
        public string LearningStartDate { get; set; }
        public string LearningEndDate { get; set; }
        public string AssetType { get; set; }
        public string Blended { get; set; }
        public int Assigned { get; set; }
        public int Completed { get; set; }
        public int Ongoing { get; set; }
        public int NotStarted { get; set; }
        public string CurrentEmployee { get; set; }
        public string CurrentRole { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

    }

    public class getscormcourseprogressreportrequestDTO
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ClassName { get; set; }
        public string EventName { get; set; }
        public string EventStatus { get; set; }
        public string EmployeeCode { get; set; }

        public string CurrentRole { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }

    public class getSurveySummaryReportDTO
    {
        public string EmployeeId { get; set; }
        public string currentRole { get; set; }
        public string classIds { get; set; }
        public string eventIds { get; set; }
        public string assmntIds { get; set; }
        public string surveystartdtstart { get; set; }
        public string surveystartdtend { get; set; }
        public string surveyenddtstart { get; set; }
        public string surveyenddtend { get; set; }
        public string creationdtstart { get; set; }
        public string creationdtend { get; set; }
        public string SurveyName { get; set; }
        public string SurveyCreator { get; set; }
        public string ClassName { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }

    public class getprojectframeworkreportrequestDTO
    {
        public string employeeCode { get; set; }
        public string CurrentRole { get; set; }
        public string picktype { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string searchbyempcode { get; set; }

        public string StartDate { get; set; }

        public string EndDate { get; set; }
    }

    public class getschedulereportrequestdto
    {
        public string ReportCode { get; set; }
        public string ReportName { get; set; }

        public string FromDate { get; set; }
        public string ToDate { get; set; }

        public string Action { get; set; }

        public string employeeCode { get; set; }
        public string CurrentRole { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string callingsource { get; set; }
    }


    public class ReportFilterDTO
    {
        public string CurrentRoleName { get; set; }
        public string EMPCode { get; set; }
        public string AssignedCompany { get; set; }

    }
}
