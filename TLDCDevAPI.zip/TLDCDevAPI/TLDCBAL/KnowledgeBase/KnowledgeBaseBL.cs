﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.EmailManagement;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.KnowledgeBase
{
    public class KnowledgeBaseBL : IKnowledgeBaseBL
    {
        private readonly IServiceConnect _serviceconnect;
        private readonly IEmailMGTBL _emailMGT;

        private readonly IOptions<IDBConnection> appSettings;
       

        DBConnection dBConnection;
        DBConnection SurveyDBConnection;
        private IQualtricsDataBL _qualtricsBL;

        public KnowledgeBaseBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IEmailMGTBL emailMGT, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.AssessmentDBConnection);
            SurveyDBConnection = new DBConnection(appSettings.Value.SurveyDBConnection);
            _serviceconnect = serviceconnect;
            _emailMGT = emailMGT;
            _qualtricsBL = qualtricsBL;
        }
        public string RemoveQuotes(string str)
        {
            string result = string.Empty;
            if (str != null && str != "")
            {
                result = str.Replace("'", "''");
            }
            return result;
        }
        public ResponseClass GetAssessmentQuestionsReport(getAssessmentQuestionsReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            try
            {
                if (request.CurrentRoleName == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.Param1);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            request.AssignedCompany = request.AssignedCompany + "" + "'" + Convert.ToString(exclude["CompanyCode"]) + "'" + ",";
                        }

                        request.AssignedCompany = request.AssignedCompany.TrimEnd(',');


                    }
                }
                SqlParameter[] parameter = {
                new SqlParameter("@UserId", request.Param1),
                new SqlParameter("@QuestionTypes", request.QuestionType),
                new SqlParameter("@Role", request.CurrentRoleName),
                new SqlParameter("@AssessmentId", request.AssessmentIds),
                new SqlParameter("@AssignedCompany", request.AssignedCompany),
                new SqlParameter("@eventcode", request.eventcode),
                new SqlParameter("@classroomcode", request.classroomcode),
                new SqlParameter("@PageNumber", request.PageNumber),
                new SqlParameter("@RowsOfPage", request.RowsOfPage),
                new SqlParameter("@fromdt", request.fromdt),
                new SqlParameter("@toDate", request.toDate),
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();

                

                dsResult = dBConnection.ExecuteDataSet("RPT_HGSHall_GetAssessmentQuestionsReport", parameter, outParameters);


                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                // pagination start
                int recordcount = 1;
                if (dsResult.Tables[0] != null && dsResult.Tables[0].Rows.Count > 0)
                {


                    if (request.PageNumber != -1)
                    {
                        recordcount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["recordcount"]);
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetAssessmentQuestionsReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

        public ResponseClass GetAssessmentSummaryReport(getAssessmentReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            if (String.IsNullOrEmpty(request.classIds))
            {
                request.classIds = "";
            }

            if (String.IsNullOrEmpty(request.eventIds))
            {
                request.eventIds = "";
            }

            if (String.IsNullOrEmpty(request.assmntIds))
            {
                request.assmntIds = "";
            }

            try
            {
                // getting event names with assessment

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_assessment_report_new(                                                                        
                                                                    :p_classid,
                                                                    :p_assmntid,
                                                                    :p_eventid,
                                                                    :p_creatorid,
                                                                    :p_currentemployee,
                                                                    :p_currentrole,
                                                                    :p_fromdate,
                                                                    :p_todate,
                                                                    :p_pageno,
                                                                    :p_recordno
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_classid", DbType.String).Value = !String.IsNullOrEmpty(request.classIds) ? request.classIds : "";
                        cmd.Parameters.AddWithValue("p_assmntid", DbType.String).Value = !String.IsNullOrEmpty(request.assmntIds) ? request.assmntIds : "";
                        cmd.Parameters.AddWithValue("p_eventid", DbType.String).Value = !String.IsNullOrEmpty(request.eventIds) ? request.eventIds : "";
                        cmd.Parameters.AddWithValue("p_creatorid", DbType.String).Value = !String.IsNullOrEmpty(request.creatorId) ? request.creatorId : "";
                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.Param1;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.currentRole;
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = !String.IsNullOrEmpty(request.FromDate) ? request.FromDate : "";
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = !String.IsNullOrEmpty(request.toDate) ? request.toDate : "";
                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                //var list = dtData.AsEnumerable().Select(r => r["contentcode"].ToString());
                //string value = string.Join(",", list);

                // getting assessment data
                //SqlParameter[] parameter = {
                //new SqlParameter("@AssessmentId", value)
                //};

                //List<OutParameter> outParameters = new List<OutParameter>();
                //DataSet dsResult = new DataSet();
                //dsResult = dBConnection.ExecuteDataSet("RPT_HGSHall_GetAssessmentSummaryReport", parameter, outParameters);



                //foreach (DataRow row in dtData.Rows)
                //{
                //    int id = Convert.ToInt32(row["contentcode"]);

                //    DataRow[] matchingRows = dsResult.Tables[0].Select("AssessmentId = '" + id + "'");
                //    if (matchingRows.Length > 0)
                //    {
                //        string max = matchingRows[0]["MaxSocre"].ToString();
                //        string min = matchingRows[0]["MinMarks"].ToString();
                //        string avgMarks = matchingRows[0]["avgmarks"].ToString();
                //        string avgattempt = matchingRows[0]["avgmarks"].ToString();
                //        row["maxscore"] = max;
                //        row["minscore"] = min;
                //        row["avgmarks"] = avgMarks;
                //        row["avgmarks"] = avgattempt;

                //    }
                //    else
                //    {
                //        row["maxscore"] = 0;
                //        row["minscore"] = 0;
                //        row["avgmarks"] = 0;
                //    }
                //}

                // pagination start
                int recordcount = 1;
                if (dtData != null && dtData.Rows.Count > 0)
                {


                    if (request.PageNumber != -1)
                    {
                        recordcount = Convert.ToInt32(dtData.Rows[0]["recordcount"]);
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end

                response.responseJSON = JsonConvert.SerializeObject(dtData);

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetAssessmentSummaryReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

        public ResponseClass GetAssessmentQuestionsType(getAssessmentQuestionsReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            try
            {
                SqlParameter[] parameter = {
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("RPT_HGSHall_GetQuestionsType", parameter, outParameters);


                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetAssessmentQuestionsReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;

        }

        public ResponseClass GetAssessmentNames(getAssessmentQuestionsReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            try
            {
                


                if (request.CurrentRoleName == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.Param1);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            request.AssignedCompany = request.AssignedCompany + "" + "'" + Convert.ToString(exclude["CompanyCode"]) + "'" + ",";
                        }

                        request.AssignedCompany = request.AssignedCompany.TrimEnd(',');


                    }
                }

                SqlParameter[] parameter = {
                    new SqlParameter("@UserId", request.Param1),
                    new SqlParameter("@Role", request.CurrentRoleName),
                    new SqlParameter("@AssignedCompany", request.AssignedCompany),
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("RPT_HGSHall_GetAssesmentNameList", parameter, outParameters);


                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetAssessmentQuestionsReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;

        }
        public ResponseClass GetClassEventNames(getAssessmentQuestionsReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_class_event_names(                                                                        
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtData);

                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetClassEventNames", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;

        }

        public ResponseClass GetAssessmentDetailReport(getassessmentdetailreportDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;
            
            if(request.Param3 == null || request.Param3 == "")
            {
                fromDate = null;
            }
            else
            {
                fromDate = Convert.ToDateTime(request.Param3).ToString("yyyy-MM-dd");
            }


            if (request.Param4 == null || request.Param4 == "")
            {
                toDate = null;
            }
            else
            {
                toDate = Convert.ToDateTime(request.Param4).ToString("yyyy-MM-dd");

            }
            

            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();

            dtFrom = Convert.ToDateTime(request.Param3);
            dtTo = Convert.ToDateTime(request.Param4);

            if (dtFrom > dtTo)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid date range selected!";
                return response;
            }

            TimeSpan difference = dtTo - dtFrom;

            if (difference.TotalDays > 60)
            {
                response.responseCode = 0;
                response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
                return response;
            }

            string companiestopass = string.Empty;
            if (request.Param2 == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.Param1);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        request.Param5 = request.Param5 + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                    }

                    request.Param5 = request.Param5.TrimEnd(',');


                }
            }

            if (!string.IsNullOrEmpty(request.ObjectCode))
            {
                request.ObjectCode = request.ObjectCode.Replace("'","");
                request.ObjectCode = request.ObjectCode.Replace("'", "");
            }

            string classname = string.Empty;
            string eventname = string.Empty;
            if (request.ObjectType=="Event" && !string.IsNullOrEmpty(request.ObjectCode))
            {
                eventname = request.ObjectCode;
            }
            else if (request.ObjectType == "Class" && !string.IsNullOrEmpty(request.ObjectCode))
            {
                classname = request.ObjectCode;
            }

            if(request.assessmentId == null || request.assessmentId == "")
            {
                request.assessmentId = null;
            }

            if(request.ObjectCode == null || request.ObjectCode == "")
            {
                request.ObjectCode = null;
            }

            if(request.ObjectCode == null || request.ObjectCode == "")
            {
                request.ObjectCode = null;
            }

            if(request.ObjectCode == null || request.ObjectCode == "")
            {
                request.ObjectCode = null;
            }

            try
            {
                SqlParameter[] parameter = {
                new SqlParameter("@param1", request.Param1),
                new SqlParameter("@param2", request.Param2),
                new SqlParameter("@param3", fromDate),
                new SqlParameter("@param4", toDate),
                new SqlParameter("@param5", request.Param5),
                new SqlParameter("@PageNumber", request.PageNumber),
                new SqlParameter("@RowsOfPage", request.RowsOfPage),
                new SqlParameter("@eventcode", eventname),
                new SqlParameter("@classroomcode", classname),
                new SqlParameter("@assessmentId",request.assessmentId),
                new SqlParameter("@creatorId", request.creatorId)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("RPT_HGSHall_assessmentdetails", parameter, outParameters);


                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    if (request.PageNumber!=-1)
                    {
                        //foreach (DataRow dr in dsResult.Tables[0].Rows)
                        //{
                        //    dr["sourcename"] = getSourceName(Convert.ToString(dr["TLDCID"]));
                        //}
                        //if (!string.IsNullOrEmpty(request.ObjectCode))
                        //{
                        //    // get allocation id under this event
                        //    DataTable dtallocation = getAlocatedIDs(request.ObjectCode, request.ObjectType);
                        //    if (dtallocation != null && dtallocation.Rows.Count > 0)
                        //    {
                        //        for (int i = dsResult.Tables[0].Rows.Count - 1; i >= 0; i--)
                        //        {
                        //            DataRow dr = dsResult.Tables[0].Rows[i];
                        //            string allocationID = Convert.ToString(dr["TLDCID"]);
                        //            DataRow[] findrow = dtallocation.Select("TID=" + allocationID);
                        //            if (findrow == null || findrow.Length == 0)
                        //            {
                        //                dr.Delete();
                        //            }

                        //        }
                        //        dsResult.AcceptChanges();
                        //    }
                        //    else
                        //    {
                        //        foreach (DataRow dr in dsResult.Tables[0].Rows)
                        //        {
                        //            dr.Delete();
                        //        }
                        //        dsResult.AcceptChanges();
                        //    }
                        //}
                    }
                    
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    // pagination start
                    int recordcount = 1;
                    if (dsResult.Tables[0] != null && dsResult.Tables[0].Rows.Count > 0)
                    {


                        if (request.PageNumber != -1)
                        {
                            recordcount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["recordcount"]);
                            //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                    //pagination end

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetAssessmentDetailReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;


        }

        //public ResponseClass GetAssessmentDetailReport(getassessmentdetailreportDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    string fromDate = string.Empty;
        //    string toDate = string.Empty;

        //    fromDate = Convert.ToDateTime(request.Param3).ToString("yyyy-MM-dd");
        //    toDate = Convert.ToDateTime(request.Param4).ToString("yyyy-MM-dd");

        //    DateTime dtFrom = new DateTime();
        //    DateTime dtTo = new DateTime();

        //    dtFrom = Convert.ToDateTime(request.Param3);
        //    dtTo = Convert.ToDateTime(request.Param4);

        //    if (dtFrom > dtTo)
        //    {
        //        response.responseCode = 0;
        //        response.responseMessage = "Invalid date range selected!";
        //        return response;
        //    }

        //    TimeSpan difference = dtTo - dtFrom;

        //    if (difference.TotalDays > 60)
        //    {
        //        response.responseCode = 0;
        //        response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
        //        return response;
        //    }

        //    string companiestopass = string.Empty;
        //    if (request.Param2 == "Geo Admin")
        //    {
        //        DataTable dtCompanies = new DataTable();
        //        dtCompanies = _qualtricsBL.gtAssignedCompany(request.Param1);
        //        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //        {
        //            foreach (DataRow exclude in dtCompanies.Rows)
        //            {
        //                request.Param5 = request.Param5 + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
        //            }

        //            request.Param5 = request.Param5.TrimEnd(',');



        //        }
        //    }

        //    try
        //    {
        //        SqlParameter[] parameter = {
        //        new SqlParameter("@param1", request.Param1),
        //        new SqlParameter("@param2", request.Param2),
        //        new SqlParameter("@param3", fromDate),
        //        new SqlParameter("@param4", toDate),
        //        new SqlParameter("@param5", request.Param5),
        //    };

        //        List<OutParameter> outParameters = new List<OutParameter>();
        //        DataSet dsResult = new DataSet();
        //        dsResult = dBConnection.ExecuteDataSet("RPT_HGSHall_assessmentdetails", parameter, outParameters);


        //        if (dsResult != null && dsResult.Tables.Count > 0)
        //        {
        //            //foreach (DataRow dr in dsResult.Tables[0].Rows)
        //            //{
        //            //    dr["sourcename"] = getSourceName(Convert.ToString(dr["TLDCID"]));
        //            //}
        //            //if (!string.IsNullOrEmpty(request.ObjectCode))
        //            //{
        //            //    // get allocation id under this event
        //            //    DataTable dtallocation = getAlocatedIDs(request.ObjectCode, request.ObjectType);
        //            //    if (dtallocation != null && dtallocation.Rows.Count > 0)
        //            //    {
        //            //        for (int i = dsResult.Tables[0].Rows.Count - 1; i >= 0; i--)
        //            //        {
        //            //            DataRow dr = dsResult.Tables[0].Rows[i];
        //            //            string allocationID = Convert.ToString(dr["TLDCID"]);
        //            //            DataRow[] findrow = dtallocation.Select("TID=" + allocationID);
        //            //            if (findrow == null || findrow.Length == 0)
        //            //            {
        //            //                dr.Delete();
        //            //            }

        //            //        }
        //            //        dsResult.AcceptChanges();
        //            //    }
        //            //    else
        //            //    {
        //            //        foreach (DataRow dr in dsResult.Tables[0].Rows)
        //            //        {
        //            //            dr.Delete();
        //            //        }
        //            //        dsResult.AcceptChanges();
        //            //    }
        //            //}
        //            response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

        //        }

        //        response.responseCode = 1;
        //        response.responseMessage = "SUCCESS";

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("GetAssessmentDetailReport", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;

        //    }

        //    return response;



        //}

        //public ResponseClass GetAssessmentDetailReport(getassessmentdetailreportDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    string fromDate = string.Empty;
        //    string toDate = string.Empty;

        //    fromDate = Convert.ToDateTime(request.Param3).ToString("yyyy-MM-dd");
        //    toDate = Convert.ToDateTime(request.Param4).ToString("yyyy-MM-dd");

        //    DateTime dtFrom = new DateTime();
        //    DateTime dtTo = new DateTime();

        //    dtFrom = Convert.ToDateTime(request.Param3);
        //    dtTo = Convert.ToDateTime(request.Param4);

        //    if (dtFrom > dtTo)
        //    {
        //        response.responseCode = 0;
        //        response.responseMessage = "Invalid date range selected!";
        //        return response;
        //    }

        //    TimeSpan difference = dtTo - dtFrom;

        //    if (difference.TotalDays > 60)
        //    {
        //        response.responseCode = 0;
        //        response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
        //        return response;
        //    }

        //    string companiestopass = string.Empty;
        //    if (request.Param2 == "Geo Admin")
        //    {
        //        DataTable dtCompanies = new DataTable();
        //        dtCompanies = _qualtricsBL.gtAssignedCompany(request.Param1);
        //        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //        {
        //            foreach (DataRow exclude in dtCompanies.Rows)
        //            {
        //                request.Param5 = request.Param5 + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
        //            }

        //            request.Param5 = request.Param5.TrimEnd(',');



        //        }
        //    }

        //    try
        //    {
        //        SqlParameter[] parameter = {
        //        new SqlParameter("@param1", request.Param1),
        //        new SqlParameter("@param2", request.Param2),
        //        new SqlParameter("@param3", fromDate),
        //        new SqlParameter("@param4", toDate),
        //        new SqlParameter("@param5", request.Param5),
        //    };

        //        List<OutParameter> outParameters = new List<OutParameter>();
        //        DataSet dsResult = new DataSet();
        //        dsResult = dBConnection.ExecuteDataSet("RPT_HGSHall_assessmentdetails", parameter, outParameters);


        //        if (dsResult != null && dsResult.Tables.Count > 0)
        //        {
        //            //foreach (DataRow dr in dsResult.Tables[0].Rows)
        //            //{
        //            //    dr["sourcename"] = getSourceName(Convert.ToString(dr["TLDCID"]));
        //            //}
        //            //if (!string.IsNullOrEmpty(request.ObjectCode))
        //            //{
        //            //    // get allocation id under this event
        //            //    DataTable dtallocation = getAlocatedIDs(request.ObjectCode, request.ObjectType);
        //            //    if (dtallocation != null && dtallocation.Rows.Count > 0)
        //            //    {
        //            //        for (int i = dsResult.Tables[0].Rows.Count - 1; i >= 0; i--)
        //            //        {
        //            //            DataRow dr = dsResult.Tables[0].Rows[i];
        //            //            string allocationID = Convert.ToString(dr["TLDCID"]);
        //            //            DataRow[] findrow = dtallocation.Select("TID=" + allocationID);
        //            //            if (findrow == null || findrow.Length == 0)
        //            //            {
        //            //                dr.Delete();
        //            //            }

        //            //        }
        //            //        dsResult.AcceptChanges();
        //            //    }
        //            //    else
        //            //    {
        //            //        foreach (DataRow dr in dsResult.Tables[0].Rows)
        //            //        {
        //            //            dr.Delete();
        //            //        }
        //            //        dsResult.AcceptChanges();
        //            //    }
        //            //}
        //            response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

        //        }

        //        response.responseCode = 1;
        //        response.responseMessage = "SUCCESS";

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("GetAssessmentDetailReport", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;

        //    }

        //    return response;



        //}

        public string getSourceName(string tldcID)
        {
            ResponseClass response = new ResponseClass();
            DataTable trainingGroup = new DataTable();
            string sourceName = string.Empty;

            try
            {


                string selectQuery = string.Empty;
                selectQuery = "select coalesce(CRM.#ClassRoomTitle#,EMM.#EventName#) as sourcename from #BusinessTrainingEmpLearningDetails# A ";
                selectQuery = selectQuery + " inner join #BusinessTrainingAllocation# B on A.#AllocationID#=B.#TID# ";
                selectQuery = selectQuery + " inner join #EventMaster# EMM on B.#EventCode#=EMM.#EventCode# ";
                selectQuery = selectQuery + " left join #ClassRoomTraining# CRM on B.#ClassRoomCode#=CRM.#ClassRoomCode# ";
                selectQuery = selectQuery + " where A.#TID#=" + tldcID + " ";
                //where B.#EventCode# in ('" + eventnames + "')
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                if (trainingGroup != null && trainingGroup.Rows.Count > 0)
                {
                    sourceName = Convert.ToString(trainingGroup.Rows[0]["sourceName"]);
                }
                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getSourceName", "1024", ex.Message, "Exception");
                // response.responseCode = 0;
                // response.responseMessage = ex.Message;
            }

            return sourceName;
        }

        public DataTable getAlocatedIDs(string eventnames, string etType)
        {
            ResponseClass response = new ResponseClass();
            DataTable trainingGroup = new DataTable();

            try
            {

                string selectQuery = string.Empty;
                selectQuery = "select A.#TID# from #BusinessTrainingEmpLearningDetails# A inner join #BusinessTrainingAllocation# B on A.#AllocationID#=B.#TID#";
                if (etType == "Event")
                {
                    selectQuery = selectQuery + "where B.#EventCode# in (" + eventnames + ")";

                }
                else if (etType == "Class")
                {
                    selectQuery = selectQuery + " where B.#ClassRoomCode# in (" + eventnames + ")";

                }
                //where B.#EventCode# in ('" + eventnames + "')
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getAlocatedIDs", "1024", ex.Message, "Exception");
                // response.responseCode = 0;
                // response.responseMessage = ex.Message;
            }

            return trainingGroup;
        }

        public ResponseClass GetSCORMCoursesProgressReport(getscormcourseprogressreportrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;



            fromDate = Convert.ToDateTime(request.StartDate).ToString("yyyy-MM-dd");
            toDate = Convert.ToDateTime(request.EndDate).ToString("yyyy-MM-dd");



            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();



            dtFrom = Convert.ToDateTime(request.StartDate);
            dtTo = Convert.ToDateTime(request.EndDate);



            if (dtFrom > dtTo)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid date range selected!";
                return response;
            }



            TimeSpan difference = dtTo - dtFrom;



            if (difference.TotalDays > 60)
            {
                response.responseCode = 0;
                response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
                return response;
            }

            try
            {



                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string sqlQuery = string.Empty;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);


                sqlQuery = "select A.#ContentText#,B.#EmployeeCode# as empid,concat(EMP.#FIRSTNAME#,' ',EMP.#LASTNAME#)  as employeename,";
                sqlQuery = sqlQuery + " EMP.#CITY#,coalesce(CT.#ClassRoomTitle#, EM.#EventName#) as etname,";
                sqlQuery = sqlQuery + " case when A.#AcknowledgedStatus# = 0 then 'Pending' when A.#AcknowledgedStatus# = 1 then 'Completed' else '' end as eventstatus,";
                sqlQuery = sqlQuery + " case when (A.#AcknowledgedStatus# = 0 and EM.#AcknowledgeRequired#=1) then 'Pending' when (A.#AcknowledgedStatus# = 1 and EM.#AcknowledgeRequired#=1) then 'Completed' when  EM.#AcknowledgeRequired#=0 then case when sst.#completion_status#='incomplete' then 'Pending' else 'Complete' end    else '' end as eventstatus,";
                sqlQuery = sqlQuery + " coalesce(TO_CHAR((total_time_int || ' second')::interval, 'HH24:MI:SS'),'') as timespent ";

                sqlQuery = sqlQuery + " from #BusinessTrainingEmpLearningDetails# A ";
                sqlQuery = sqlQuery + " inner join #BusinessTrainingAllocation# B on A.#AllocationID# = B.#TID#";
                sqlQuery = sqlQuery + " inner join #EventMaster# EM on EM.#EventCode# = B.#EventCode#";
                sqlQuery = sqlQuery + " left join #ClassRoomTraining# CT on CT.#ClassRoomCode# = B.#ClassRoomCode#";
                sqlQuery = sqlQuery + " inner join #CourseMaster# CM on CM.#CourseCode# = A.#ContentCode#";
                sqlQuery = sqlQuery + " inner join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE# = B.#EmployeeCode#";
                sqlQuery = sqlQuery + " inner join #UserMaster# UM on UM.#EmployeeID#=B.#EmployeeCode# ";
                sqlQuery = sqlQuery + " inner join #scorm_sco_tracking# sst on sst.#user_id#=UM.#UserID# and sst.#course_id#=CM.#CourseID# and sst.#allocation_id#=A.#TID#";
                sqlQuery = sqlQuery + " where (EM.#EventType# = 'Course' or (EM.#EventType# = 'Program' and A.#ContentType#='Course')) and CM.#CourseType# in ('SCORM1.2', 'SCORM1.3')  ";

                if (!string.IsNullOrEmpty(request.EventStatus))
                {
                    sqlQuery = sqlQuery + " and A.#AcknowledgedStatus#=" + request.EventStatus + "";
                }
                sqlQuery = sqlQuery + " and B.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "'";
                if (!string.IsNullOrEmpty(request.EventName))
                {
                    sqlQuery = sqlQuery + " and EM.#EventCode# in (" + request.EventName + ")";
                }
                if (!string.IsNullOrEmpty(request.ClassName))
                {
                    sqlQuery = sqlQuery + " and CT.#ClassRoomCode# in (" + request.ClassName + ")";
                }

                if (!string.IsNullOrEmpty(request.CurrentRole))
                {
                    if (request.CurrentRole == "Geo Admin")
                    {
                        string companies = string.Empty;

                        DataTable dtCompanies = new DataTable();
                        dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeCode);
                        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dtCompanies.Rows)
                            {
                                companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                            }

                            companies = companies.TrimEnd(',');

                        }

                        sqlQuery = sqlQuery + " and EMP.#COMPANY_CODE# in (" + companies + ")";
                    }
                    if (request.CurrentRole == "Program Manager")
                    {
                        sqlQuery = sqlQuery + " and EM.#InsertedBy#='" + request.EmployeeCode + "'";
                    }
                    if (request.CurrentRole == "Participant")
                    {
                        sqlQuery = sqlQuery + " andB.#EmployeeCode#='" + request.EmployeeCode + "'";
                    }
                }

                //sqlQuery = sqlQuery + " GROUP By a.#MAllocationID#,c.#AttemptNo#,c.#ScorePercentage#,c.#StartDate#,c.#EndDate#,a.#AssessmentStatus#,u.#DOJ#, EMP.#Job_Title#,EMP.#FIRSTNAME#,EMP.#LASTNAME#,EMP.#DEPARTMENT#,EMP.#Sub_Process#,EMP.#Manager_Name#,EMP.#Last_Working_Day#,a.#AllocationDate#,a.#ExpiryDate#,a.#AllocationType#,a.#EmployeeCode#,EMP.#DOJ#,ELD.#Reason# ORDER By a.#AllocationDate#";
                sqlQuery = sqlQuery + " order by B.#TID# desc ";
                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();

                response.responseCode = 1;
                #region Pagination
                int recordcount = 1;
                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                {
                    recordcount = dtEmployees.Rows.Count;
                    if (request.PageNumber != -1)
                    {
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                DataTable _dtEmployees = new DataTable();
                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                {
                    _dtEmployees = dtEmployees.AsEnumerable().Skip((request.PageNumber - 1) * request.RowsOfPage)
                        .Take(request.RowsOfPage).CopyToDataTable();
                }
                #endregion*
                if (_dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(_dtEmployees);
                }
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetSCORMCoursesProgressReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetEmployeeDetails(EmployeeNameWithIdDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select concat(EM.#FIRSTNAME# ,' ',EM.#LASTNAME# ,' (',EM.#EXTERNALDATAREFERENCE#,')') as FullName,EM.#EXTERNALDATAREFERENCE# as EmployeeId from public.#EmployeeMaster# EM where EM.#Active_Separated# = 'Active'  and EM.#FIRSTNAME#!=''";

                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and EM.#COUNTRY#='" + request.CountryName + "'";
                }
                //else if (request.CurrentRole == "Participant")
                //{
                //    selectQuery = selectQuery + " and EM.#EXTERNALDATAREFERENCE#='" + request.EmployeeId + "'";
                //}
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by concat(EM.#FIRSTNAME# ,' ',EM.#LASTNAME#)";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEmployeeDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetDesignationDetails(DesignationDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct EM.#Job_Title# as Designation from public.#EmployeeMaster# EM where EM.#Active_Separated# = 'Active' and EM.#COUNTRY#='" + request.CountryName + "' order by EM.#Job_Title#";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetDesignationDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetRoleDetails(RoleDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select RM.#RoleMasterName# as Role from public.#RoleMaster# RM order by RM.#RoleMasterName#";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetRoleDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetReportingAuthorityDetails(ReportingAuthorityDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string companiestopass = string.Empty;
                string selectQuery = string.Empty;

                // selectQuery = "select distinct concat(EM.#FIRSTNAME# ,' ',EM.#LASTNAME# ,' (',EM.#EXTERNALDATAREFERENCE#,')')  as Fullname,EM.#EXTERNALDATAREFERENCE# as EmployeeId from public.#EmployeeMaster# EM where EM.#Active_Separated# = 'Active' and EM.#COUNTRY#='" + request.CountryName + "' and EM.#manager_1# != '' and EM.#FIRSTNAME#!='' ";
                selectQuery = "select distinct concat(EM.#Manager_Name# ,' (',EM.#Manager_ID#,')')  as Fullname,EM.#Manager_ID# as EmployeeId from public.#EmployeeMaster# EM where EM.#Active_Separated# = 'Active' and EM.#Manager_ID# != '' and EM.#Manager_Name#!='' ";
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and EM.#COUNTRY#='" + request.CountryName + "'";
                }
                //else if (request.CurrentRole == "Participant")
                //{
                //    selectQuery = selectQuery + " and EM.#EXTERNALDATAREFERENCE#='" + request.EmployeeId + "'";
                //}
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }

                selectQuery = selectQuery + " order by concat(EM.#Manager_Name# ,' (',EM.#Manager_ID#,')')";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportingAuthorityDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetLocationDetails(LocationDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string companiestopass = string.Empty;
                string selectQuery = string.Empty;

                //selectQuery = "select distinct EM.#Building_Facility_Name# as Location from public.#EmployeeMaster# EM where EM.#Active_Separated# = 'Active' and EM.#COUNTRY#='" + request.CountryName + "' order by EM.#Building_Facility_Name#";
                selectQuery = "select distinct EM.#Building_Facility_Name# as Location from public.#EmployeeMaster# EM where EM.#Active_Separated# = 'Active'";

                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and EM.#COUNTRY#='" + request.CountryName + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }

                selectQuery = selectQuery + " order by EM.#Building_Facility_Name#";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetLocationDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass SiteUsageReport(getSiteUsageReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                List<string> p_employeecode = new List<string>();
                if (!String.IsNullOrEmpty(request.EmployeeId))
                {
                    p_employeecode = request.EmployeeId.Replace(" ", "").Split(",").ToList();
                }
                else
                {
                    p_employeecode.Add("");
                }
                List<string> p_designation = new List<string>();
                if (!String.IsNullOrEmpty(request.Designation))
                {

                    var v_designation = request.Designation.Split(",").ToList();
                    p_designation = v_designation.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_designation.Add("");
                }
                List<string> p_roles = new List<string>();
                if (!String.IsNullOrEmpty(request.Role))
                {

                    var v_role = request.Role.Split(",").ToList();
                    p_roles = v_role.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_roles.Add("");
                }
                List<string> p_repoautho = new List<string>();
                if (!String.IsNullOrEmpty(request.ReportingAuthority))
                {

                    var v_reportauto = request.ReportingAuthority.Split(",").ToList();
                    p_repoautho = v_reportauto.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_repoautho.Add("");
                }
                List<string> p_location = new List<string>();
                if (!String.IsNullOrEmpty(request.Location))
                {

                    var v_location = request.Location.Split(",").ToList();
                    p_location = v_location.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_location.Add("");
                }

                string sdate = string.Empty;
                if (!string.IsNullOrEmpty(request.LoginStartDate))
                {
                    DateTime _sdate = DateTime.ParseExact(request.LoginStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    sdate = _sdate.ToString("yyyy-MM-dd");
                }
                string edate = string.Empty;
                if (!string.IsNullOrEmpty(request.LoginEndDate))
                {
                    DateTime _edate = DateTime.ParseExact(request.LoginEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                }
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_site_usage_report
                                                                        ( 
                                                                        :p_employeecode,
                                                                        :p_designation,
                                                                        :p_role,
                                                                        :p_reportingauthority,
                                                                        :p_location,
                                                                        :p_loginsdate,
                                                                        :p_loginedate,
                                                                        :p_ipaddress
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeId))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.Object).Value = p_employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.Object).Value = p_employeecode;

                        if (!String.IsNullOrEmpty(request.Designation))
                            cmd.Parameters.AddWithValue("p_designation", DbType.Object).Value = p_designation;
                        else
                            cmd.Parameters.AddWithValue("p_designation", DbType.Object).Value = p_designation;

                        if (!String.IsNullOrEmpty(request.Role))
                            cmd.Parameters.AddWithValue("p_role", DbType.Object).Value = p_roles;
                        else
                            cmd.Parameters.AddWithValue("p_role", DbType.Object).Value = p_roles;

                        if (!String.IsNullOrEmpty(request.ReportingAuthority))
                            cmd.Parameters.AddWithValue("p_reportingauthority", DbType.Object).Value = p_repoautho;
                        else
                            cmd.Parameters.AddWithValue("p_reportingauthority", DbType.Object).Value = p_repoautho;

                        if (!String.IsNullOrEmpty(request.Location))
                            cmd.Parameters.AddWithValue("p_location", DbType.Object).Value = p_location;
                        else
                            cmd.Parameters.AddWithValue("p_location", DbType.Object).Value = p_location;

                        if (!String.IsNullOrEmpty(request.LoginStartDate))
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = sdate;
                        else
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.LoginEndDate))
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = edate;
                        else
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.IPAddress))
                            cmd.Parameters.AddWithValue("p_ipaddress", DbType.String).Value = request.IPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_ipaddress", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("SiteUsageReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass GetLearningNameDetails(LearningNameDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;
                string companiestopass = string.Empty;

                //selectQuery = "select distinct BT.#ContentText# as LearningName from public.#BusinessTrainingAllocation# BTA inner join public.#EmployeeMaster# EM on BTA.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE# inner join public.#EventMaster# E on BTA.#EventCode#= E.#EventCode# inner join public.#BusinessTrainingEmpLearningDetails# BT on BTA.#TID#=BT.#AllocationID# where EM.#Active_Separated#='Active'";
                selectQuery = "DROP TABLE IF EXISTS temp_Learning;";
                selectQuery = selectQuery + "CREATE TEMP TABLE temp_Learning (learningname VARCHAR(300),employeeid varchar(300),companycode varchar(300));";
                selectQuery = selectQuery + "insert into temp_Learning(learningname,employeeid,companycode) select distinct BT.#ContentText# as LearningName,E.#InsertedBy# as insertedby,EM.#COMPANY_CODE# from public.#BusinessTrainingAllocation# BTA inner join public.#EmployeeMaster# EM on BTA.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE# inner join public.#EventMaster# E on BTA.#EventCode#= E.#EventCode# inner join public.#BusinessTrainingEmpLearningDetails# BT on BTA.#TID#=BT.#AllocationID# where EM.#Active_Separated#='Active';";
                selectQuery = selectQuery + "insert into temp_Learning(learningname,employeeid,companycode) select distinct PTM.#TrainingName#  as LearningName ,CRT.#InsertedBy#,EM.#COMPANY_CODE# from public.#ClassRoomTraining# CRT inner join public.#ProcessTrainingMaster# PTM on  PTM.#ClassRoomCode#=CRT.#ClassRoomCode# inner join public.#EmployeeMaster# EM on CRT.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# where CRT.#DeletedFlag#=0;";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);
                npgsqlCommand.ExecuteNonQuery();

                selectQuery = string.Empty;
                selectQuery = "select distinct learningname as LearningName from temp_Learning";
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " where #employeeid#='" + request.EmployeeId + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " where #companycode# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by #learningname#";
                selectQuery = selectQuery.Replace('#', '"');
                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(selectQuery, npgsql);
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand1);


                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetLearningNameDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetLearningCreatorNameDetails(LearningNameDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;
                string companiestopass = string.Empty;

                //selectQuery = "select distinct BT.#ContentText# as LearningName from public.#BusinessTrainingAllocation# BTA inner join public.#EmployeeMaster# EM on BTA.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE# inner join public.#EventMaster# E on BTA.#EventCode#= E.#EventCode# inner join public.#BusinessTrainingEmpLearningDetails# BT on BTA.#TID#=BT.#AllocationID# where EM.#Active_Separated#='Active'";
                selectQuery = "DROP TABLE IF EXISTS temp_Learning;";
                selectQuery = selectQuery + "CREATE TEMP TABLE temp_Learning (learningname VARCHAR(300),employeeid varchar(300),companycode varchar(300));";
                selectQuery = selectQuery + "insert into temp_Learning(learningname,employeeid,companycode) select distinct BT.#ContentText# as LearningName,E.#InsertedBy# as insertedby,EM.#COMPANY_CODE# from public.#BusinessTrainingAllocation# BTA inner join public.#EmployeeMaster# EM on BTA.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE# inner join public.#EventMaster# E on BTA.#EventCode#= E.#EventCode# inner join public.#BusinessTrainingEmpLearningDetails# BT on BTA.#TID#=BT.#AllocationID# where EM.#Active_Separated#='Active';";
                selectQuery = selectQuery + "insert into temp_Learning(learningname,employeeid,companycode) select distinct PTM.#TrainingName#  as LearningName ,CRT.#InsertedBy#,EM.#COMPANY_CODE# from public.#ClassRoomTraining# CRT inner join public.#ProcessTrainingMaster# PTM on  PTM.#ClassRoomCode#=CRT.#ClassRoomCode# inner join public.#EmployeeMaster# EM on CRT.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# where CRT.#DeletedFlag#=0;";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);
                npgsqlCommand.ExecuteNonQuery();

                selectQuery = string.Empty;
                selectQuery = "select distinct learningname as LearningName from temp_Learning";
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " where #employeeid#='" + request.EmployeeId + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " where #companycode# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by #learningname#";
                selectQuery = selectQuery.Replace('#', '"');
                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(selectQuery, npgsql);
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand1);


                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetLearningNameDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetEventNameDetails(EventNameDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                //string selectQuery = string.Empty;

                //selectQuery = "select distinct EM.#EventName# as EventName from public.#EventMaster# EM where EM.#DeletedFlag#=0";

                string selectQuery = string.Empty;
                selectQuery = "select A.#EventCode# as eventcode,A.#EventCode# as valuefield,A.#EventName# as displayfield,A.#EventName# as eventname,A.#EventType# as eventtype,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,TO_CHAR(A.#InsertedDateTime#, 'dd Mon yyyy') as createddate,TO_CHAR(A.#EventStartDate#, 'dd-Mon-yyyy') as startDate,TO_CHAR(A.#EventEndDate#, 'dd-Mon-yyyy') as enddate,EXTRACT(HOUR FROM A.#EventStartTime#) as eventstarttimehour,EXTRACT(MINUTE FROM A.#EventStartTime#) as eventstarttimeminute,EXTRACT(HOUR FROM A.#EventEndTime#) as eventendtimehour,EXTRACT(MINUTE FROM A.#EventEndTime#) as eventendtimeminute,A.#IsPublished# as ispublished,case when A.#IsPublished#=1 then 'YES' else 'NO' end as publishedtext,A.#AcknowledgeRequired#,(select count(*) from #EventAllocation# where #ObjectCode#=A.#EventCode# and #ObjectType#='Event') as allocationcount,A.#TimeZone#  as timezone, ";
                selectQuery = selectQuery + "(select count(*) from #BusinessLearningEmployeeActivity# where #EventCode#=A.#EventCode#) as activitycount";
                selectQuery = selectQuery + " from #EventMaster# A inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                selectQuery = selectQuery + " where (A.#DeletedFlag#)=0 and A.#EventSource#='1'   ";

                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and A.#InsertedBy#='" + request.EmployeeId + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by  A.#InsertedDateTime# desc";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEventNameDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetClassNameDetails(ClassNameDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                //string selectQuery = string.Empty;

                //selectQuery = "select distinct EM.#EventName# as EventName from public.#EventMaster# EM where EM.#DeletedFlag#=0";

                string selectQuery = string.Empty;
                selectQuery = "select A.#EventCode# as eventcode,A.#EventCode# as valuefield,A.#EventName# as displayfield,A.#EventName# as eventname,A.#EventType# as eventtype,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,TO_CHAR(A.#InsertedDateTime#, 'dd Mon yyyy') as createddate,TO_CHAR(A.#EventStartDate#, 'dd-Mon-yyyy') as startDate,TO_CHAR(A.#EventEndDate#, 'dd-Mon-yyyy') as enddate,EXTRACT(HOUR FROM A.#EventStartTime#) as eventstarttimehour,EXTRACT(MINUTE FROM A.#EventStartTime#) as eventstarttimeminute,EXTRACT(HOUR FROM A.#EventEndTime#) as eventendtimehour,EXTRACT(MINUTE FROM A.#EventEndTime#) as eventendtimeminute,A.#IsPublished# as ispublished,case when A.#IsPublished#=1 then 'YES' else 'NO' end as publishedtext,A.#AcknowledgeRequired#,(select count(*) from #EventAllocation# where #ObjectCode#=A.#EventCode# and #ObjectType#='Event') as allocationcount,A.#TimeZone#  as timezone, ";
                selectQuery = selectQuery + "(select count(*) from #BusinessLearningEmployeeActivity# where #EventCode#=A.#EventCode#) as activitycount";
                selectQuery = selectQuery + " from #EventMaster# A inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                selectQuery = selectQuery + " where (A.#DeletedFlag#)=0 and A.#EventSource#='1'   ";

                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and A.#InsertedBy#='" + request.EmployeeId + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by  A.#InsertedDateTime# desc";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetClassNameDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass BlendedLearnerProgressReport(BlendedLearnerProgressReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                DataTable dtEmployeesFinal = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                List<string> p_employeecode = new List<string>();
                if (!String.IsNullOrEmpty(request.EmployeeId))
                {
                    p_employeecode = request.EmployeeId.Replace(" ", "").Split(",").ToList();
                }
                else
                {
                    p_employeecode.Add("");
                }
                List<string> p_learningname = new List<string>();
                if (!String.IsNullOrEmpty(request.LearningName))
                {
                    request.LearningName = RemoveQuotes(request.LearningName);
                    var v_Learningname = request.LearningName.Split(",").ToList();
                    p_learningname = v_Learningname.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_learningname.Add("");
                }
                //List<string> p_evanetname = new List<string>();
                //if (!String.IsNullOrEmpty(request.EventName))
                //{

                //    var v_evanetname = request.EventName.Split(",").ToList();
                //    p_evanetname = v_evanetname.Select(x => x.Trim()).ToList();
                //}
                //else
                //{
                //    p_evanetname.Add("");
                //}
                List<string> p_classname = new List<string>();
                if (!String.IsNullOrEmpty(request.ClassName))
                {
                    request.ClassName = RemoveQuotes(request.ClassName);
                    var v_classname = request.ClassName.Split(",").ToList();
                    p_classname = v_classname.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_classname.Add("");
                }
                string sdate = string.Empty;
                if (!string.IsNullOrEmpty(request.LoginStartDate))
                {
                    DateTime _sdate = DateTime.ParseExact(request.LoginStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    sdate = _sdate.ToString("yyyy-MM-dd");
                }
                string edate = string.Empty;
                if (!string.IsNullOrEmpty(request.LoginEndDate))
                {
                    DateTime _edate = DateTime.ParseExact(request.LoginEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                }
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_blended_learner_progress_report
                                                                        ( 
                                                                        :p_employeecode,
                                                                        :p_learningname,
                                                                        :p_eventname,
                                                                        :p_classname,
                                                                        :p_loginsdate,
                                                                        :p_loginedate,:p_currentemployee,:p_currentrole,
                                                                        :p_pageno,:p_recordno
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeId))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.Object).Value = request.EmployeeId;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.Object).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.LearningName))
                            cmd.Parameters.AddWithValue("p_learningname", DbType.Object).Value = request.LearningName;
                        else
                            cmd.Parameters.AddWithValue("p_learningname", DbType.Object).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EventName))
                            cmd.Parameters.AddWithValue("p_eventname", DbType.String).Value = request.EventName;
                        else
                            cmd.Parameters.AddWithValue("p_eventname", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.ClassName))
                            cmd.Parameters.AddWithValue("p_classname", DbType.Object).Value = p_classname;
                        else
                            cmd.Parameters.AddWithValue("p_classname", DbType.Object).Value = p_classname;

                        //if (!String.IsNullOrEmpty(request.Status))
                        //    cmd.Parameters.AddWithValue("p_status", DbType.Int32).Value = request.Status;
                        //else
                        //    cmd.Parameters.AddWithValue("p_status", DbType.Int32).Value = 0;

                        if (!String.IsNullOrEmpty(request.LoginStartDate))
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = sdate;
                        else
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.LoginEndDate))
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = edate;
                        else
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CurrentEmployee))
                            cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.CurrentEmployee;
                        else
                            cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        if (!string.IsNullOrEmpty(request.Status))
                        {
                            var dr = (from a in dtEmployees.AsEnumerable() where a.Field<string>("status") == request.Status select a);
                            dtEmployeesFinal = dtEmployees.Clone();
                            foreach (DataRow sourceRow in dr)
                            {
                                dtEmployeesFinal.ImportRow(sourceRow);
                            }
                            dtEmployeesFinal.AcceptChanges();
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployeesFinal);
                        }
                        else
                        {
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                        
                    }
                }

                //pagination start
                int recordcount = 1;
                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                {
                    recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                    if (request.PageNumber != -1)
                    {
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end


                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                //_serviceconnect.LogConnect("BlendedLearnerProgressReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass GetClassNameForReport(ClassNameReportDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct EM.#ClassRoomTitle# as ClassName from public.#ClassRoomTraining# EM where EM.#DeletedFlag#=0";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetClassNameForReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetEventNameForReport(EventNameReportDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct EM.#EventName# as EventName from public.#EventMaster# EM where EM.#DeletedFlag#=0";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEventNameForReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass LearningDistributionReport(LearningDistributionReport request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                //List<string> P_classname = new List<string>();
                //if (!String.IsNullOrEmpty(request.ClassName))
                //{
                //    P_classname = request.ClassName.Replace(" ", "").Split(",").ToList();
                //}
                //else
                //{
                //    P_classname.Add("");
                //}
                List<string> p_classname = new List<string>();
                if (!String.IsNullOrEmpty(request.ClassName))
                {
                    request.ClassName = RemoveQuotes(request.ClassName);
                    var v_classname = request.ClassName.Split(",").ToList();
                    p_classname = v_classname.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_classname.Add("");
                }
                List<string> p_learningname = new List<string>();
                if (!String.IsNullOrEmpty(request.LearningName))
                {

                    request.LearningName = RemoveQuotes(request.LearningName);
                    var v_learningname = request.LearningName.Split(",").ToList();
                    p_learningname = v_learningname.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_learningname.Add("");
                }
                //List<string> p_eventname = new List<string>();
                //if (!String.IsNullOrEmpty(request.EventName))
                //{

                //    var v_eventname = request.EventName.Split(",").ToList();
                //    p_eventname = v_eventname.Select(x => x.Trim()).ToList();
                //}
                //else
                //{
                //    p_eventname.Add("");
                //}
                //List<string> p_eventtype = new List<string>();
                //if (!String.IsNullOrEmpty(request.Blended))
                //{

                //    var v_eventtype = request.Blended.Split(",").ToList();
                //    p_eventtype = v_eventtype.Select(x => x.Trim()).ToList();
                //}
                //else
                //{
                //    p_eventtype.Add("");
                //}

                string sdate = string.Empty;
                if (!string.IsNullOrEmpty(request.LearningStartDate))
                {
                    DateTime _sdate = DateTime.ParseExact(request.LearningStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    sdate = _sdate.ToString("yyyy-MM-dd");
                }
                string edate = string.Empty;
                if (!string.IsNullOrEmpty(request.LearningEndDate))
                {
                    DateTime _edate = DateTime.ParseExact(request.LearningEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                }
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_learning_distribution_report
                                                                        ( 
                                                                        :p_classname,
                                                                        :p_learningname,
                                                                        :p_eventname,
                                                                        :p_eventtype,
                                                                        :p_loginsdate,
                                                                        :p_loginedate,
                                                                        :p_currentemployee,
                                                                        :p_currentrole,
                                                                        :p_pageno,
                                                                        :p_recordno
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ClassName))
                            cmd.Parameters.AddWithValue("p_classname", DbType.Object).Value = p_classname;
                        else
                            cmd.Parameters.AddWithValue("p_classname", DbType.Object).Value = p_classname;

                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.LearningName))
                            cmd.Parameters.AddWithValue("p_learningname", DbType.Object).Value = p_learningname;
                        else
                            cmd.Parameters.AddWithValue("p_learningname", DbType.Object).Value = p_learningname;

                        if (!String.IsNullOrEmpty(request.EventName))
                            cmd.Parameters.AddWithValue("p_eventname", DbType.String).Value = request.EventName;
                        else
                            cmd.Parameters.AddWithValue("p_eventname", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.Blended))
                            cmd.Parameters.AddWithValue("p_eventtype", DbType.Int32).Value = request.Blended;
                        else
                            cmd.Parameters.AddWithValue("p_eventtype", DbType.Int32).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.LearningStartDate))
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = sdate;
                        else
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.LearningEndDate))
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = edate;
                        else
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CurrentEmployee))
                            cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.CurrentEmployee;
                        else
                            cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.CurrentEmployee;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);


                        //pagination start
                        int recordcount = 1;
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                            if (request.PageNumber != -1)
                            {
                                //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                                decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                                int recordPages = Convert.ToInt32(noOfPages);

                                if (noOfPages > recordPages)
                                {
                                    recordPages = recordPages + 1;
                                }

                                response.recordCount = recordPages;
                            }
                        }
                        //pagination end

                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("SiteUsageReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass GetClassNameAttendance(ClassNameForAttendanceDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct PTM.#TrainingName# as classname from public.#ProcessTrainingMaster# PTM where #DeletedFlag#=0";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetClassNameAttendance", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetEventNameAttendance(EventNameForAttendanceDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct PTM.#ProcessTrainingType# as eventname,case when PTM.#ProcessTrainingType#='ProcessTraining' then 'Process Training'  when PTM.#ProcessTrainingType#='OnJobTraining' then 'On Job Training'  when PTM.#ProcessTrainingType#='RefresherTraining' then 'Refresher Training'  when PTM.#ProcessTrainingType#='PreProcessTraining' then 'PreProcess Training' end  as EventDisplayName from public.#ProcessTrainingMaster# PTM inner join #EmployeeMaster# EM on PTM.#CreatedBy# = EM.#EXTERNALDATAREFERENCE# where PTM.#DeletedFlag#=0";
                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and PTM.#CreatedBy#='" + request.EmployeeId + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by  PTM.#ProcessTrainingType# desc";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEventNameAttendance", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetSessionNameAttendance(SessionNameForAttendanceDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct PTS.#SessionName# as sessionname from public.#ProcessTrainingSession# PTS inner join #EmployeeMaster# EM on PTS.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# where #DeletedFlag#=0";
                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and PTS.#InsertedBy#='" + request.EmployeeId + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by  PTS.#SessionName# desc";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetSessionNameAttendance", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass ClassroomAttendanceDetailsReport(ClassroomAttendanceDetailsReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                List<string> p_classname = new List<string>();
                if (!String.IsNullOrEmpty(request.ClassName))
                {

                    var v_ClassName = request.ClassName.Split(",").ToList();
                    p_classname = v_ClassName.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_classname.Add("");
                }
                List<string> p_evanetname = new List<string>();
                if (!String.IsNullOrEmpty(request.EventName))
                {

                    var v_evanetname = request.EventName.Split(",").ToList();
                    p_evanetname = v_evanetname.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_evanetname.Add("");
                }
                List<string> p_sessionname = new List<string>();
                if (!String.IsNullOrEmpty(request.SessionName))
                {

                    var v_sessionname = request.SessionName.Split(",").ToList();
                    p_sessionname = v_sessionname.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_sessionname.Add("");
                }

                string sdate = string.Empty;
                if (!string.IsNullOrEmpty(request.LoginStartDate))
                {
                    DateTime _sdate = DateTime.ParseExact(request.LoginStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    sdate = _sdate.ToString("yyyy-MM-dd");
                }
                string edate = string.Empty;
                if (!string.IsNullOrEmpty(request.LoginEndDate))
                {
                    DateTime _edate = DateTime.ParseExact(request.LoginEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    //edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                    edate = _edate.ToString("yyyy-MM-dd");
                }
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_classroom_attendance_details_report
                                                                        ( 
                                                                        :p_classname,
                                                                        :p_eventname,
                                                                        :p_sessionname,
                                                                        :p_loginsdate,
                                                                        :p_loginedate,
                                                                        :p_creatorid,
                                                                        :p_pageno,
                                                                        :p_recordno
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ClassName))
                            cmd.Parameters.AddWithValue("p_classname", DbType.Object).Value = p_classname;
                        else
                            cmd.Parameters.AddWithValue("p_classname", DbType.Object).Value = p_classname;

                        if (!String.IsNullOrEmpty(request.EventName))
                            cmd.Parameters.AddWithValue("p_eventname", DbType.Object).Value = p_evanetname;
                        else
                            cmd.Parameters.AddWithValue("p_eventname", DbType.Object).Value = p_evanetname;

                        if (!String.IsNullOrEmpty(request.SessionName))
                            cmd.Parameters.AddWithValue("p_sessionname", DbType.Object).Value = p_sessionname;
                        else
                            cmd.Parameters.AddWithValue("p_sessionname", DbType.Object).Value = p_sessionname;

                        if (!String.IsNullOrEmpty(request.LoginStartDate))
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = sdate;
                        else
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = "";

                        if (!String.IsNullOrEmpty(request.LoginEndDate))
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = edate;
                        else
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = "";

                        cmd.Parameters.AddWithValue("p_creatorid", DbType.String).Value = !String.IsNullOrEmpty(request.creatorId) ? request.creatorId : "";
                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);


                        //pagination start
                        int recordcount = 1;
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                            if (request.PageNumber != -1)
                            {
                                //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                                decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                                int recordPages = Convert.ToInt32(noOfPages);

                                if (noOfPages > recordPages)
                                {
                                    recordPages = recordPages + 1;
                                }

                                response.recordCount = recordPages;
                            }
                        }
                        //pagination end
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ClassroomAttendanceDetailsReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass ClassroomAttendanceSummaryReport(ClassroomAttendanceSummaryReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                List<string> p_classname = new List<string>();
                if (!String.IsNullOrEmpty(request.ClassName))
                {

                    var v_ClassName = request.ClassName.Split(",").ToList();
                    p_classname = v_ClassName.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_classname.Add("");
                }
                List<string> p_evanetname = new List<string>();
                if (!String.IsNullOrEmpty(request.EventName))
                {

                    var v_evanetname = request.EventName.Split(",").ToList();
                    p_evanetname = v_evanetname.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_evanetname.Add("");
                }
                List<string> p_sessionname = new List<string>();
                if (!String.IsNullOrEmpty(request.SessionName))
                {

                    var v_sessionname = request.SessionName.Split(",").ToList();
                    p_sessionname = v_sessionname.Select(x => x.Trim()).ToList();
                }
                else
                {
                    p_sessionname.Add("");
                }

                string sdate = string.Empty;
                if (!string.IsNullOrEmpty(request.LoginStartDate))
                {
                    DateTime _sdate = DateTime.ParseExact(request.LoginStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    sdate = _sdate.ToString("yyyy-MM-dd");
                }
                string edate = string.Empty;
                if (!string.IsNullOrEmpty(request.LoginEndDate))
                {
                    DateTime _edate = DateTime.ParseExact(request.LoginEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    //edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                    edate = _edate.ToString("yyyy-MM-dd");
                }
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_classroom_attendance_summary_report
                                                                        ( 
                                                                        :p_classname,
                                                                        :p_eventname,
                                                                        :p_sessionname,
                                                                        :p_loginsdate,
                                                                        :p_loginedate,
                                                                        :p_creatorid,
                                                                        :p_pageno,
                                                                        :p_recordno
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ClassName))
                            cmd.Parameters.AddWithValue("p_classname", DbType.Object).Value = p_classname;
                        else
                            cmd.Parameters.AddWithValue("p_classname", DbType.Object).Value = p_classname;

                        if (!String.IsNullOrEmpty(request.EventName))
                            cmd.Parameters.AddWithValue("p_eventname", DbType.Object).Value = new List<string>();
                        else
                            cmd.Parameters.AddWithValue("p_eventname", DbType.Object).Value = new List<string>();

                        if (!String.IsNullOrEmpty(request.SessionName))
                            cmd.Parameters.AddWithValue("p_sessionname", DbType.Object).Value = new List<string>();
                        else
                            cmd.Parameters.AddWithValue("p_sessionname", DbType.Object).Value = new List<string>();

                        if (!String.IsNullOrEmpty(request.LoginStartDate))
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = sdate;
                        else
                            cmd.Parameters.AddWithValue("p_loginsdate", DbType.String).Value = "";

                        if (!String.IsNullOrEmpty(request.LoginEndDate))
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = edate;
                        else
                            cmd.Parameters.AddWithValue("p_loginedate", DbType.String).Value = "";

                        cmd.Parameters.AddWithValue("p_creatorid", DbType.String).Value = !String.IsNullOrEmpty(request.creatorId) ? request.creatorId : "";
                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();


                        //pagination start
                        int recordcount = 1;
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                            if (request.PageNumber != -1)
                            {
                                //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                                decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                                int recordPages = Convert.ToInt32(noOfPages);

                                if (noOfPages > recordPages)
                                {
                                    recordPages = recordPages + 1;
                                }

                                response.recordCount = recordPages;
                            }
                        }
                        //pagination end


                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ClassroomAttendanceSummaryReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
       
        public ResponseClass getProjectFrameworkReport(getprojectframeworkreportrequestDTO request)
        {

            ResponseClass response = new ResponseClass();

            string fromDate = string.Empty;
            string toDate = string.Empty;



            fromDate = Convert.ToDateTime(request.StartDate).ToString("yyyy-MM-dd");
            toDate = Convert.ToDateTime(request.EndDate).ToString("yyyy-MM-dd");



            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();



            dtFrom = Convert.ToDateTime(request.StartDate);
            dtTo = Convert.ToDateTime(request.EndDate);



            if (dtFrom > dtTo)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid date range selected!";
                return response;
            }



            TimeSpan difference = dtTo - dtFrom;



            if (difference.TotalDays > 180)
            {
                response.responseCode = 0;
                response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                return response;
            }


            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string companiestopass = string.Empty;
                string teamMembers = string.Empty;
                List<string> p_teammember = new List<string>();

                //if (request.CurrentRole == "Geo Admin")
                //{
                //    DataTable dtCompanies = new DataTable();
                //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.employeeCode);
                //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                //    {
                //        foreach (DataRow exclude in dtCompanies.Rows)
                //        {
                //            companiestopass = companiestopass + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                //        }

                //        companiestopass = companiestopass.TrimEnd(',');



                //    }
                //}
                //else if (request.CurrentRole == "Team Lead")
                //{
                //    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                //    getteam.EmployeeCode = request.employeeCode;
                //    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                //    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                //    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                //    {
                //        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                //        {
                //            teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                //        }

                //        teamMembers = teamMembers.TrimEnd(',');

                //    }

                    

                //}


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_projectframework_report
                                                                        ( 
                                                                            :p_username,
                                                                            :p_current_role,:p_pageno,:p_recordno,:p_company,:p_teammember,:p_fromdate,:p_todate
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.employeeCode))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.employeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_current_role", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_current_role", DbType.String).Value = DBNull.Value;

                      

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        if (!String.IsNullOrEmpty(companiestopass))
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = companiestopass;
                        else
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(teamMembers))
                            cmd.Parameters.AddWithValue("p_teammember", DbType.String).Value = teamMembers;
                        else
                            cmd.Parameters.AddWithValue("p_teammember", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.StartDate))
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = request.StartDate;
                        else
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = string.Empty;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        int recordcount = 1;
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                            if (request.PageNumber != -1)
                            {
                                //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                                decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                                int recordPages = Convert.ToInt32(noOfPages);

                                if (noOfPages > recordPages)
                                {
                                    recordPages = recordPages + 1;
                                }

                                response.recordCount = recordPages;
                            }
                        }

                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getProjectFrameworkReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }


        public ResponseClass getProjectFrameworkReportDashboard(getprojectframeworkreportrequestDTO request)
        {

            ResponseClass response = new ResponseClass();

            //string fromDate = string.Empty;
            //string toDate = string.Empty;



            //fromDate = Convert.ToDateTime(request.StartDate).ToString("yyyy-MM-dd");
            //toDate = Convert.ToDateTime(request.EndDate).ToString("yyyy-MM-dd");



            //DateTime dtFrom = new DateTime();
            //DateTime dtTo = new DateTime();



            //dtFrom = Convert.ToDateTime(request.StartDate);
            //dtTo = Convert.ToDateTime(request.EndDate);



            //if (dtFrom > dtTo)
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "Invalid date range selected!";
            //    return response;
            //}



            //TimeSpan difference = dtTo - dtFrom;



            //if (difference.TotalDays > 180)
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
            //    return response;
            //}


            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string companiestopass = string.Empty;
                string teamMembers = string.Empty;
                List<string> p_teammember = new List<string>();

                //if (request.CurrentRole == "Geo Admin")
                //{
                //    DataTable dtCompanies = new DataTable();
                //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.employeeCode);
                //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                //    {
                //        foreach (DataRow exclude in dtCompanies.Rows)
                //        {
                //            companiestopass = companiestopass + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                //        }

                //        companiestopass = companiestopass.TrimEnd(',');



                //    }
                //}
                //else if (request.CurrentRole == "Team Lead")
                //{
                //    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                //    getteam.EmployeeCode = request.employeeCode;
                //    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                //    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                //    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                //    {
                //        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                //        {
                //            teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                //        }

                //        teamMembers = teamMembers.TrimEnd(',');

                //    }



                //}


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_projectframework_report_dashboard
                                                                        ( 
                                                                            :p_username,
                                                                            :p_current_role,:p_fromdate,:p_todate
                                                                            
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.employeeCode))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.employeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_current_role", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_current_role", DbType.String).Value = DBNull.Value;


                        if (!String.IsNullOrEmpty(request.StartDate))
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = request.StartDate;
                        else
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EndDate))
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = request.EndDate;
                        else
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = string.Empty;

                        

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                       

                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getProjectFrameworkReportDashboard", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        #region Survey Report


        /// <summary>
        /// Survey Summary Report
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public ResponseClass GetSurveySummaryReport(getSurveySummaryReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable reportdata = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                List<string> p_surveyname = new List<string>();
                if (!String.IsNullOrEmpty(request.SurveyName))
                {

                    var v_surveyname = request.SurveyName.Split(",").ToList();
                    p_surveyname = v_surveyname.Select(x => x.Trim()).ToList();
                }

                List<string> p_eventname = new List<string>();
                if (!String.IsNullOrEmpty(request.eventIds))
                {

                    var v_eventname = request.eventIds.Split(",").ToList();
                    p_eventname = v_eventname.Select(x => x.Trim()).ToList();
                }

                List<string> p_classname = new List<string>();
                if (!String.IsNullOrEmpty(request.ClassName))
                {
                    var v_ClassName = request.ClassName.Split(",").ToList();
                    p_classname = v_ClassName.Select(x => x.Trim()).ToList();
                }

                string creationsdate = string.Empty;
                if (!string.IsNullOrEmpty(request.creationdtstart))
                {
                    DateTime _creationsdate = DateTime.ParseExact(request.creationdtstart.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    creationsdate = _creationsdate.ToString("yyyy-MM-dd");
                }
                string creationedate = string.Empty;
                if (!string.IsNullOrEmpty(request.creationdtend))
                {
                    DateTime _creationedate = DateTime.ParseExact(request.creationdtend.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    creationedate = _creationedate.ToString("yyyy-MM-dd");
                }

                string surveystartdtstart = string.Empty;
                if (!string.IsNullOrEmpty(request.surveystartdtstart))
                {
                    DateTime _surveystartdtstart = DateTime.ParseExact(request.surveystartdtstart.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    surveystartdtstart = _surveystartdtstart.ToString("yyyy-MM-dd");
                }
                string surveystartdtend = string.Empty;
                if (!string.IsNullOrEmpty(request.surveystartdtend))
                {
                    DateTime _surveystartdtend = DateTime.ParseExact(request.surveystartdtend.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    surveystartdtend = _surveystartdtend.ToString("yyyy-MM-dd");
                }

                string surveyenddtstart = string.Empty;
                if (!string.IsNullOrEmpty(request.surveyenddtstart))
                {
                    DateTime _surveyenddtstart = DateTime.ParseExact(request.surveyenddtstart.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    surveyenddtstart = _surveyenddtstart.ToString("yyyy-MM-dd");
                }
                string surveyenddtend = string.Empty;
                if (!string.IsNullOrEmpty(request.surveyenddtend))
                {
                    DateTime _surveyenddtend = DateTime.ParseExact(request.surveyenddtend.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    surveyenddtend = _surveyenddtend.ToString("yyyy-MM-dd");
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_survey_summary_report
                                                                        ( 
                                                                        :p_currentemployee,
                                                                        :p_currentrole,
                                                                        :p_surveysdate,
                                                                        :p_surveyedate,
                                                                        :p_classname,
                                                                        :p_eventname,
                                                                        :p_surveyname,
                                                                        :p_surveycreator,
                                                                        :p_pageno,
                                                                        :p_recordno
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; 


                        if (!String.IsNullOrEmpty(request.surveystartdtstart))
                            cmd.Parameters.AddWithValue("p_surveysdate", DbType.String).Value = surveystartdtstart;
                        else
                            cmd.Parameters.AddWithValue("p_surveysdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.surveyenddtend))
                            cmd.Parameters.AddWithValue("p_surveyedate", DbType.String).Value = surveyenddtend;
                        else
                            cmd.Parameters.AddWithValue("p_surveyedate", DbType.String).Value = string.Empty;


                        cmd.Parameters.AddWithValue("p_classname", DbType.String).Value = !String.IsNullOrEmpty(request.classIds) ? request.classIds : "" ;
                        cmd.Parameters.AddWithValue("p_eventname", DbType.String).Value = !String.IsNullOrEmpty(request.eventIds) ? request.eventIds : "";
                        cmd.Parameters.AddWithValue("p_surveyname", DbType.String).Value = !String.IsNullOrEmpty(request.SurveyName) ? request.SurveyName : "";
                        cmd.Parameters.AddWithValue("p_surveycreator", DbType.String).Value = !String.IsNullOrEmpty(request.SurveyCreator) ? request.SurveyCreator : "";
                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.currentRole;
                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(reportdata);

                        npgsqlConnection.Close();
                    }
                }


                //pagination start
                int recordcount = 1;
                if (reportdata != null && reportdata.Rows.Count > 0)
                {
                    recordcount = Convert.ToInt32(reportdata.Rows[0]["recordcount"]);

                    if (request.PageNumber != -1)
                    {
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end


                response.responseJSON = JsonConvert.SerializeObject(reportdata);
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetSurveySummaryReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;



            //if (!String.IsNullOrEmpty(request.CreationEndDate))
            //    cmd.Parameters.AddWithValue("p_creationedate", DbType.String).Value = creationedate;
            //else
            //    cmd.Parameters.AddWithValue("p_creationedate", DbType.String).Value = string.Empty;



            //var dataExist = reportdata.AsEnumerable()
            //                        .Where(
            //                        row => (p_surveyname.Count() == 0 || p_surveyname.Contains(row.Field<String>("surveyname")))
            //                            && (string.IsNullOrEmpty(creationsdate) || Convert.ToDateTime(row.Field<String>("createddate")).Date >= Convert.ToDateTime(creationsdate).Date)
            //                            && (string.IsNullOrEmpty(creationedate) || Convert.ToDateTime(row.Field<String>("createddate")).Date <= Convert.ToDateTime(creationedate).Date)

            //                            && (string.IsNullOrEmpty(surveystartdtstart) || Convert.ToDateTime(row.Field<String>("startdate")).Date >= Convert.ToDateTime(surveystartdtstart).Date)
            //                            && (string.IsNullOrEmpty(surveystartdtend) || Convert.ToDateTime(row.Field<String>("startdate")).Date <= Convert.ToDateTime(surveystartdtend).Date)

            //                            //&& (string.IsNullOrEmpty(surveyenddtstart) || Convert.ToDateTime(row.Field<String>("enddate")).Date >= Convert.ToDateTime(surveyenddtstart).Date)
            //                            //&& (string.IsNullOrEmpty(surveyenddtend) || Convert.ToDateTime(row.Field<String>("enddate")).Date <= Convert.ToDateTime(surveyenddtend).Date)

            //                            && (p_classname.Count == 0 || p_classname.Contains(row.Field<String>("classname")))
            //                            && (p_eventname.Count == 0 || p_eventname.Contains(row.Field<String>("eventname")))
            //                        ).ToList();


            //                var dataExist = reportdata.AsEnumerable()
            //                                        .Where(
            //                                        row => (p_surveyname.Count() == 0 || p_surveyname.Contains(row.Field<String>("surveyname")))
            //&& (string.IsNullOrEmpty(surveystartdtstart) || Convert.ToDateTime(row.Field<String>("startdate")).Date >= Convert.ToDateTime(surveystartdtstart).Date)
            //&& (string.IsNullOrEmpty(surveyenddtend) || Convert.ToDateTime(row.Field<String>("enddate")).Date <= Convert.ToDateTime(surveyenddtend).Date)

            //                                        ).ToList();

            //                if (dataExist != null && dataExist.Count() > 0)
            //                {
            //                    //reportdata = reportdata.AsEnumerable()
            //                    //                .Where(
            //                    //                row => (p_surveyname.Count() == 0 || p_surveyname.Contains(row.Field<String>("surveyname")))
            //                    //                    && (string.IsNullOrEmpty(creationsdate) || Convert.ToDateTime(row.Field<String>("createddate")).Date >= Convert.ToDateTime(creationsdate).Date)
            //                    //                    && (string.IsNullOrEmpty(creationedate) || Convert.ToDateTime(row.Field<String>("createddate")).Date <= Convert.ToDateTime(creationedate).Date)

            //                    //                    && (string.IsNullOrEmpty(surveystartdtstart) || Convert.ToDateTime(row.Field<String>("startdate")).Date >= Convert.ToDateTime(surveystartdtstart).Date)
            //                    //                    && (string.IsNullOrEmpty(surveystartdtend) || Convert.ToDateTime(row.Field<String>("startdate")).Date <= Convert.ToDateTime(surveystartdtend).Date)

            //                    //                    //&& (string.IsNullOrEmpty(surveyenddtstart) || Convert.ToDateTime(row.Field<String>("enddate")).Date >= Convert.ToDateTime(surveyenddtstart).Date)
            //                    //                    //&& (string.IsNullOrEmpty(surveyenddtend) || Convert.ToDateTime(row.Field<String>("enddate")).Date <= Convert.ToDateTime(surveyenddtend).Date)

            //                    //                    && (p_classname.Count == 0 || p_classname.Contains(row.Field<String>("classname")))
            //                    //                    && (p_eventname.Count == 0 || p_eventname.Contains(row.Field<String>("eventname")))
            //                    //                )
            //                    //                .CopyToDataTable();

            //                    reportdata = reportdata.AsEnumerable()
            //                                    .Where(
            //                                    row => (p_surveyname.Count() == 0 || p_surveyname.Contains(row.Field<String>("surveyname")))

            //                                        && (string.IsNullOrEmpty(surveystartdtstart) || Convert.ToDateTime(row.Field<String>("startdate")).Date >= Convert.ToDateTime(surveystartdtstart).Date)
            //&& (string.IsNullOrEmpty(surveyenddtend) || Convert.ToDateTime(row.Field<String>("enddate")).Date <= Convert.ToDateTime(surveyenddtend).Date)

            //                                    )
            //                                    .CopyToDataTable();
            //                }
            //                else
            //                {
            //                    reportdata.Rows.Clear();
            //                }


        }

        public ResponseClass SurveyQuestionSummaryReport(SurveyQuestionSummaryReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                List<string> p_surveyname = new List<string>();
                if (!String.IsNullOrEmpty(request.SurveyName))
                {
                    request.SurveyName = RemoveQuotes(request.SurveyName);
                    var v_surveyname = request.SurveyName.Split(",").ToList();
                    p_surveyname = v_surveyname.Select(x => x.Trim()).ToList();
                }
                //else
                //{
                //    p_surveyname.Add("");
                //}
                List<string> p_classname = new List<string>();
                if (!String.IsNullOrEmpty(request.ClassName))
                {
                    request.ClassName = RemoveQuotes(request.ClassName);
                    var v_ClassName = request.ClassName.Split(",").ToList();
                    p_classname = v_ClassName.Select(x => x.Trim()).ToList();
                }
                //else
                //{
                //    p_classname.Add("");
                //}
                List<string> p_eventname = new List<string>();
                if (!String.IsNullOrEmpty(request.EventName))
                {
                    request.EventName = RemoveQuotes(request.EventName);
                    var v_eventname = request.EventName.Split(",").ToList();
                    p_eventname = v_eventname.Select(x => x.Trim()).ToList();
                }
                string surveysdate = string.Empty;
                if (!string.IsNullOrEmpty(request.SurveyStartDate))
                {
                    DateTime _surveysdate = DateTime.ParseExact(request.SurveyStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    surveysdate = _surveysdate.ToString("yyyy-MM-dd");
                }
                string surveyedate = string.Empty;
                if (!string.IsNullOrEmpty(request.SurveyEndDate))
                {
                    DateTime _surveyedate = DateTime.ParseExact(request.SurveyEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    //edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                    surveyedate = _surveyedate.ToString("yyyy-MM-dd");
                }
                string creationsdate = string.Empty;
                if (!string.IsNullOrEmpty(request.CreationStartDate))
                {
                    DateTime _creationsdate = DateTime.ParseExact(request.CreationStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    creationsdate = _creationsdate.ToString("yyyy-MM-dd");
                }
                string creationedate = string.Empty;
                if (!string.IsNullOrEmpty(request.CreationEndDate))
                {
                    DateTime _creationedate = DateTime.ParseExact(request.CreationEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    //edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                    creationedate = _creationedate.ToString("yyyy-MM-dd");
                }

                // getting survey data
                SqlParameter[] parameter = {
                        new SqlParameter("@surveyname", !String.IsNullOrEmpty(request.SurveyName) ? request.SurveyName : null),
                        new SqlParameter("@classname", !String.IsNullOrEmpty(request.ClassName) ? request.ClassName : null),
                        new SqlParameter("@eventname", !String.IsNullOrEmpty(request.EventName) ? request.EventName : null),
                        new SqlParameter("@surveysdate", !String.IsNullOrEmpty(request.SurveyStartDate) ? request.SurveyStartDate : null),
                        new SqlParameter("@surveyedate", !String.IsNullOrEmpty(request.SurveyEndDate) ? request.SurveyEndDate : null),
                        new SqlParameter("@surveycreator", !String.IsNullOrEmpty(request.CreatedBy) ? request.CreatedBy : null),
                        new SqlParameter("@currentrole", request.CurrentRole),
                        new SqlParameter("@currentemployee", request.CurrentEmployee),
                        new SqlParameter("@pageno", request.PageNumber),
                        new SqlParameter("@recordno", request.RowsOfPage)
                 };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = SurveyDBConnection.ExecuteDataSet("PRC_ESurvey_TLDC_SurveyQuestionSummaryReport", parameter, outParameters);

                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);


                //pagination start
                int recordcount = 1;
                if (dsResult.Tables[0] != null && dsResult.Tables[0].Rows.Count > 0)
                {
                    recordcount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["recordcount"]);

                    if (request.PageNumber != -1)
                    {
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end


                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("SurveyQuestionSummaryReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass SurveySummaryReportDetails(SurveySummaryDetailedReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                List<string> p_surveyname = new List<string>();
                if (!String.IsNullOrEmpty(request.SurveyName))
                {
                    request.SurveyName = RemoveQuotes(request.SurveyName);
                    var v_surveyname = request.SurveyName.Split(",").ToList();
                    p_surveyname = v_surveyname.Select(x => x.Trim()).ToList();
                }
                //else
                //{
                //    p_surveyname.Add("");
                //}
                List<string> p_classname = new List<string>();
                if (!String.IsNullOrEmpty(request.ClassName))
                {
                    request.ClassName = RemoveQuotes(request.ClassName);
                    var v_ClassName = request.ClassName.Split(",").ToList();
                    p_classname = v_ClassName.Select(x => x.Trim()).ToList();
                }
                //else
                //{
                //    p_classname.Add("");
                //}
                List<string> p_eventname = new List<string>();
                if (!String.IsNullOrEmpty(request.EventName))
                {
                    request.EventName = RemoveQuotes(request.EventName);
                    var v_eventname = request.EventName.Split(",").ToList();
                    p_eventname = v_eventname.Select(x => x.Trim()).ToList();
                }
                string surveysdate = string.Empty;
                if (!string.IsNullOrEmpty(request.SurveyStartDate))
                {
                    DateTime _surveysdate = DateTime.ParseExact(request.SurveyStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    surveysdate = _surveysdate.ToString("yyyy-MM-dd");
                }
                string surveyedate = string.Empty;
                if (!string.IsNullOrEmpty(request.SurveyEndDate))
                {
                    DateTime _surveyedate = DateTime.ParseExact(request.SurveyEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    //edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                    surveyedate = _surveyedate.ToString("yyyy-MM-dd");
                }
                string creationsdate = string.Empty;
                if (!string.IsNullOrEmpty(request.CreationStartDate))
                {
                    DateTime _creationsdate = DateTime.ParseExact(request.CreationStartDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    creationsdate = _creationsdate.ToString("yyyy-MM-dd");
                }
                string creationedate = string.Empty;
                if (!string.IsNullOrEmpty(request.CreationEndDate))
                {
                    DateTime _creationedate = DateTime.ParseExact(request.CreationEndDate.Trim(), "dd-MMM-yyyy", CultureInfo.InvariantCulture);
                    //edate = _edate.AddDays(1).ToString("yyyy-MM-dd");
                    creationedate = _creationedate.ToString("yyyy-MM-dd");
                }

                // getting survey details data
                SqlParameter[] parameter = {
                        new SqlParameter("@surveyname", !String.IsNullOrEmpty(request.SurveyName) ? request.SurveyName : null),
                        new SqlParameter("@classname", !String.IsNullOrEmpty(request.ClassName) ? request.ClassName : null),
                        new SqlParameter("@eventname", !String.IsNullOrEmpty(request.EventName) ? request.EventName : null),
                        new SqlParameter("@surveysdate", !String.IsNullOrEmpty(request.SurveyStartDate) ? request.SurveyStartDate : null),
                        new SqlParameter("@surveyedate", !String.IsNullOrEmpty(request.SurveyEndDate) ? request.SurveyEndDate : null),
                        new SqlParameter("@surveycreator", !String.IsNullOrEmpty(request.CreatedBy) ? request.CreatedBy : null),
                        new SqlParameter("@currentrole", request.CurrentRole),
                        new SqlParameter("@currentemployee", request.CurrentEmployee),
                        new SqlParameter("@pageno", request.PageNumber),
                        new SqlParameter("@recordno", request.RowsOfPage)
                 };


                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = SurveyDBConnection.ExecuteDataSet("PRC_ESurvey_TLDC_SurveyDetailedReport", parameter, outParameters);


                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);


                //pagination start
                int recordcount = 1;
                if (dsResult.Tables[0] != null && dsResult.Tables[0].Rows.Count > 0)
                {
                    recordcount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["recordcount"]);

                    if (request.PageNumber != -1)
                    {
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("SurveyQuestionSummaryReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;

        }

        public ResponseClass GetSurveyNameDetails(SurveyNameDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct BTD.#ContentText#  as surveyname,BTD.#ContentCode# as surveyid,E.#EXTERNALDATAREFERENCE# from public.#EventMaster# EM  ";
                selectQuery = selectQuery + " inner join public.#BusinessTrainingAllocation# BTA on EM.#EventCode#=BTA.#EventCode# inner join public.#BusinessTrainingEmpLearningDetails# BTD on BTA.#TID#=BTD.#AllocationID# inner join public.#EmployeeMaster# E on EM.#InsertedBy#=E.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + "where EM.#EventType#='Survey' and EM.#IsPublished#=1 ";
                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and EM.#InsertedBy#='" + request.EmployeeId + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and E.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by BTD.#ContentCode# desc";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();
                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                dataAdapter.Fill(dt);


                var list = dt.AsEnumerable().Select(r => r["surveyid"].ToString());
                string value = string.Join(",", list);


                // getting survey data
                SqlParameter[] parameter = {
                        new SqlParameter("@SurveyIds", value)
                        };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = SurveyDBConnection.ExecuteDataSet("PRC_ESurvey_TLDC_SurveyQuestionSummaryReport", parameter, outParameters);

                DataTable dtData = new DataTable();
                DataTable surveyResponse = new DataTable();
                surveyResponse.Clear();
                surveyResponse.Columns.Add("surveyname");

                foreach (DataRow row in dt.Rows)
                {
                    int id = Convert.ToInt32(row["surveyid"]);

                    DataRow[] matchingRows = dsResult.Tables[0].Select("SurveyId = '" + id + "'");

                    if (matchingRows.Length > 0)
                    {
                        DataRow _dtRow = surveyResponse.NewRow();
                        _dtRow["surveyname"] = matchingRows[0]["SurveyName"].ToString();
                        surveyResponse.Rows.Add(_dtRow);
                    }
                }
                var finalSurveryNames = (from r in surveyResponse.AsEnumerable()
                                         select r["surveyname"]).Distinct().ToList();

                surveyResponse.Clear();
                foreach (var item in finalSurveryNames)
                {
                    DataRow _dtRow = surveyResponse.NewRow();
                    _dtRow["surveyname"] = item;
                    surveyResponse.Rows.Add(_dtRow);
                }

                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(surveyResponse);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEventNameAttendance", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetSurveySummaryReportNameList(getSurveySummaryReportDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct BTD.#ContentText#  as displayfield,BTD.#ContentCode# as surveyid,E.#EXTERNALDATAREFERENCE# from public.#EventMaster# EM  ";
                selectQuery = selectQuery + " inner join public.#BusinessTrainingAllocation# BTA on EM.#EventCode#=BTA.#EventCode# inner join public.#BusinessTrainingEmpLearningDetails# BTD on BTA.#TID#=BTD.#AllocationID# inner join public.#EmployeeMaster# E on EM.#InsertedBy#=E.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " where EM.#EventType#='Survey' and EM.#IsPublished#=1 and EM.#DeletedFlag#=0";
                string companiestopass = string.Empty;
                if (request.currentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and EM.#InsertedBy#='" + request.EmployeeId + "'";
                }
                else if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                selectQuery = selectQuery + " order by BTD.#ContentCode# desc";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();
                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                dataAdapter.Fill(dt);


                var list = dt.AsEnumerable().Select(r => r["surveyid"].ToString());
                string value = string.Join(",", list);


                // getting survey data
                //SqlParameter[] parameter = {
                //        new SqlParameter("@SurveyIds", value)
                //        };

                //List<OutParameter> outParameters = new List<OutParameter>();
                //DataSet dsResult = new DataSet();
                //dsResult = SurveyDBConnection.ExecuteDataSet("PRC_ESurvey_TLDC_SurveyQuestionSummaryReport", parameter, outParameters);

                //DataTable dtData = new DataTable();
                DataTable surveyResponse = new DataTable();
                surveyResponse.Clear();
                surveyResponse.Columns.Add("displayfield");

                //foreach (DataRow row in dt.Rows)
                //{
                //    int id = Convert.ToInt32(row["surveyid"]);

                //    DataRow[] matchingRows = dsResult.Tables[0].Select("SurveyId = '" + id + "'");

                //    if (matchingRows.Length > 0)
                //    {
                //        DataRow _dtRow = surveyResponse.NewRow();
                //        _dtRow["surveyname"] = matchingRows[0]["SurveyName"].ToString();
                //        surveyResponse.Rows.Add(_dtRow);
                //    }
                //}
                var finalSurveryNames = (from r in dt.AsEnumerable()
                                         select r["displayfield"]).Distinct().ToList();

                surveyResponse.Clear();
                foreach (var item in finalSurveryNames)
                {
                    DataRow _dtRow = surveyResponse.NewRow();
                    _dtRow["displayfield"] = item;
                    surveyResponse.Rows.Add(_dtRow);
                }

                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(surveyResponse);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEventNameAttendance", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        #endregion

        #region Schedule Report
        public ResponseClass GetScheduleReportHeader(getschedulereportrequestdto request)
        {

            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_get_reportheader
                                                                        ( 
                                                                            :p_reportcode
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.ReportCode))
                            cmd.Parameters.AddWithValue("p_reportcode", DbType.String).Value = request.ReportCode;
                        else
                            cmd.Parameters.AddWithValue("p_reportcode", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }
                //pagination end

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetScheduleReportHeader", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }
            return response;
        }

        public ResponseClass GetDynamicReport(getschedulereportrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            try
            {

                DateTime fromdate = new DateTime();
                DateTime todate = new DateTime();

                if(!string.IsNullOrEmpty(request.FromDate))
                {
                    fromdate = Convert.ToDateTime(request.FromDate);
                }

                if (!string.IsNullOrEmpty(request.ToDate))
                {
                    todate = Convert.ToDateTime(request.ToDate);
                }

                if (string.IsNullOrEmpty(request.Action))
                {
                    request.Action = "Grid";
                }
                StringBuilder emailBodyText = new StringBuilder();
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string companies = string.Empty;
                if (request.ReportName== "LearnerProgressReport")
                {
                    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_get_learnerprogressreport
                                                                        ( 
                                                                            :p_fromdate,:p_todate,:p_employeecode,:pemployeerole,:p_pageno,:p_recordno
                                                                        )", npgsqlConnection))
                        {
                            cmd.CommandType = CommandType.Text; //

                            if (!String.IsNullOrEmpty(request.FromDate))
                                cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = fromdate.ToString("yyyy-MM-dd");
                            else
                                cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = DBNull.Value;

                            if (!String.IsNullOrEmpty(request.ToDate))
                                cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = todate.ToString("yyyy-MM-dd");
                            else
                                cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = DBNull.Value;

                            if (!String.IsNullOrEmpty(request.employeeCode))
                                cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.employeeCode;
                            else
                                cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                            if (!String.IsNullOrEmpty(request.CurrentRole))
                                cmd.Parameters.AddWithValue("pemployeerole", DbType.String).Value = request.CurrentRole;
                            else
                                cmd.Parameters.AddWithValue("pemployeerole", DbType.String).Value = DBNull.Value;

                            cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                            cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                            npgsqlConnection.Open();

                            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                            dataAdapter.Fill(dtEmployees);
                            npgsqlConnection.Close();
                            
                            if (dtEmployees!=null && dtEmployees.Rows.Count>0)
                            {
                                if (request.callingsource=="Grid")
                                {
                                    emailBodyText.Append("<thead>");
                                    emailBodyText.Append("<tr>");
                                    emailBodyText.Append("<th>#</th>");
                                    foreach (DataColumn item in dtEmployees.Columns)
                                    {
                                        if (item.ColumnName!= "recordcount")
                                        {
                                            emailBodyText.Append("<th>" + item.ColumnName.ToString().ToUpper() + "</th>");
                                        }
                                        
                                    }

                                    emailBodyText.Append("</tr>");
                                    emailBodyText.Append("</thead>");
                                    emailBodyText.Append("<tbody>");
                                    int rowno = 1;
                                    foreach (DataRow item in dtEmployees.Rows)
                                    {
                                        emailBodyText.Append("<tr>");
                                        emailBodyText.Append("<td>" + rowno + "</td>");
                                        foreach (DataColumn dc in dtEmployees.Columns)
                                        {
                                            if (dc.ColumnName != "recordcount")
                                            {
                                                emailBodyText.Append("<td>" + item[dc.ColumnName] + "</td>");
                                            }
                                                
                                        }


                                        emailBodyText.Append("</tr>");
                                        //emailBodyText.Append("<td>" + item.ColumnName + "</td>");

                                        rowno = rowno + 1;
                                    }


                                    emailBodyText.Append("</tbody>");

                                    response.responseJSON = emailBodyText.ToString();
                                }
                                else
                                {
                                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                                }
                                

                                int recordcount = 1;
                                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                                {
                                    recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                                    if (request.PageNumber != -1)
                                    {
                                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                                        int recordPages = Convert.ToInt32(noOfPages);

                                        if (noOfPages > recordPages)
                                        {
                                            recordPages = recordPages + 1;
                                        }

                                        response.recordCount = recordPages;
                                    }
                                }
                            }

                            
                            //response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                    }
                }
                if (request.ReportName == "EmployeeAssessmentSummary")
                {
                    //if (request.CurrentRole == "Geo Admin")
                    //{

                    //}
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.employeeCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companies = companies + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                        }

                        companies = companies.TrimEnd(',');

                    }

                    SqlParameter[] parameter = {
                        new SqlParameter("@FromDate", fromdate.ToString("yyyy-MM-dd")),
                        new SqlParameter("@ToDate", todate.ToString("yyyy-MM-dd")),
                        new SqlParameter("@companycode", companies)

                 };
                    List<OutParameter> outParameters = new List<OutParameter>();
                    DataSet dsResult = new DataSet();
                    dsResult = dBConnection.ExecuteDataSet("Schedule_Report_AssessmentSummaryReport", parameter, outParameters);

                    if (dsResult != null && dsResult.Tables[0].Rows.Count > 0)
                    {
                        emailBodyText.Append("<thead>");
                        emailBodyText.Append("<tr>");
                        emailBodyText.Append("<th>#</th>");
                        foreach (DataColumn item in dsResult.Tables[0].Columns)
                        {
                            emailBodyText.Append("<th>" + item.ColumnName.ToString().ToUpper() + "</th>");
                        }

                        emailBodyText.Append("</tr>");
                        emailBodyText.Append("</thead>");
                        emailBodyText.Append("<tbody>");
                        int rowno = 1;
                        foreach (DataRow item in dsResult.Tables[0].Rows)
                        {
                            emailBodyText.Append("<tr>");
                            emailBodyText.Append("<td>" + rowno + "</td>");
                            foreach (DataColumn dc in dsResult.Tables[0].Columns)
                            {
                                emailBodyText.Append("<td>" + item[dc.ColumnName] + "</td>");
                            }


                            emailBodyText.Append("</tr>");
                            //emailBodyText.Append("<td>" + item.ColumnName + "</td>");

                            rowno = rowno + 1;
                        }


                        emailBodyText.Append("</tbody>");
                    }

                    response.responseJSON = emailBodyText.ToString();
                }
                if (request.ReportName == "SurveyDetailedReport")
                {
                    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_get_surveydetailedreport
                                                                        ( 
                                                                            :p_fromdate,:p_todate,:p_employeecode,:pemployeerole
                                                                        )", npgsqlConnection))
                        {
                            cmd.CommandType = CommandType.Text; //

                            if (!String.IsNullOrEmpty(request.FromDate))
                                cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = fromdate.ToString("yyyy-MM-dd");
                            else
                                cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = DBNull.Value;

                            if (!String.IsNullOrEmpty(request.ToDate))
                                cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = todate.ToString("yyyy-MM-dd");
                            else
                                cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = DBNull.Value;

                            if (!String.IsNullOrEmpty(request.employeeCode))
                                cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.employeeCode;
                            else
                                cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                            if (!String.IsNullOrEmpty(request.CurrentRole))
                                cmd.Parameters.AddWithValue("pemployeerole", DbType.String).Value = request.CurrentRole;
                            else
                                cmd.Parameters.AddWithValue("pemployeerole", DbType.String).Value = DBNull.Value;

                            npgsqlConnection.Open();

                            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                            dataAdapter.Fill(dtEmployees);
                            npgsqlConnection.Close();

                            var list = dtEmployees.AsEnumerable().Select(r => r["surveyid"].ToString());
                            string value = string.Join(",", list);

                            // getting survey data
                            

                            DataTable dtCompanies = new DataTable();
                            dtCompanies = _qualtricsBL.gtAssignedCompany(request.employeeCode);
                            if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                            {
                                foreach (DataRow exclude in dtCompanies.Rows)
                                {
                                    companies = companies + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                                }

                                companies = companies.TrimEnd(',');

                            }
                            SqlParameter[] parameter = {
                                new SqlParameter("@SurveyIds", value),
                                new SqlParameter("@companycode", companies)
                        };
                            List<OutParameter> outParameters = new List<OutParameter>();
                            DataSet dsResult = new DataSet();
                            dsResult = SurveyDBConnection.ExecuteDataSet("PRC_ESurvey_TLDC_SurveyDetailedReport_Scheduler", parameter, outParameters);

                            DataTable dtData = new DataTable();

                            DataTable surveyResponse = new DataTable();
                            surveyResponse.Clear();
                           // surveyResponse.Columns.Add("SurveyId");
                            surveyResponse.Columns.Add("SurveyName");
                            surveyResponse.Columns.Add("QuestionId");
                            surveyResponse.Columns.Add("Question");
                            //surveyResponse.Columns.Add("ResponseTypeId");
                            surveyResponse.Columns.Add("ResponseType");
                            surveyResponse.Columns.Add("ResponseValue");
                            surveyResponse.Columns.Add("Commnets");
                            surveyResponse.Columns.Add("Responsegivendatetime");
                            surveyResponse.Columns.Add("ParticipantId");
                            surveyResponse.Columns.Add("ParticipantName");
                            surveyResponse.Columns.Add("ParticipantDepartmentName");
                            surveyResponse.Columns.Add("ParticipantSubProcessName");
                            surveyResponse.Columns.Add("ParticipantCountryName");
                            surveyResponse.Columns.Add("eventtype");
                            surveyResponse.Columns.Add("eventname");
                            surveyResponse.Columns.Add("createddate");
                            surveyResponse.Columns.Add("createdby");
                            surveyResponse.Columns.Add("startdate");
                            surveyResponse.Columns.Add("enddate");

                            foreach (DataRow row in dtEmployees.Rows)
                            {
                                int id = Convert.ToInt32(row["surveyid"]);

                                DataRow[] matchingRows = dsResult.Tables[0].Select("SurveyId = '" + id + "'");

                                if (matchingRows.Length > 0)
                                {
                                    for (int i = 0; i < matchingRows.Length; i++)
                                    {
                                        DataRow _dtRow = surveyResponse.NewRow();
                                        _dtRow["eventtype"] = row["eventtype"].ToString();
                                        _dtRow["eventname"] = row["etname"].ToString();
                                        _dtRow["createddate"] = row["createddate"].ToString();
                                        _dtRow["createdby"] = row["createdby"].ToString();
                                        _dtRow["startdate"] = row["startdate"].ToString();
                                        _dtRow["enddate"] = row["enddate"].ToString();

                                        _dtRow["SurveyName"] = matchingRows[i]["SurveyName"].ToString();
                                        _dtRow["Question"] = matchingRows[i]["Question"].ToString();
                                        _dtRow["ResponseType"] = matchingRows[i]["ResponseType"].ToString();
                                        _dtRow["ResponseValue"] = matchingRows[i]["ResponseValue"].ToString();
                                        _dtRow["Responsegivendatetime"] = matchingRows[i]["Responsegivendatetime"].ToString() != null ? Convert.ToDateTime(matchingRows[i]["Responsegivendatetime"]).ToString("dd-MMM-yyyy hh:mm tt") : "";
                                        _dtRow["ParticipantName"] = matchingRows[i]["ParticipantName"].ToString();
                                        _dtRow["ParticipantDepartmentName"] = matchingRows[i]["ParticipantDepartmentName"].ToString();
                                        _dtRow["ParticipantSubProcessName"] = matchingRows[i]["ParticipantSubProcessName"].ToString();
                                        _dtRow["ParticipantCountryName"] = matchingRows[i]["ParticipantCountryName"].ToString();
                                        _dtRow["Commnets"] = matchingRows[i]["Commnets"].ToString();
                                        surveyResponse.Rows.Add(_dtRow);
                                    }
                                }
                            }

                            if (surveyResponse != null && surveyResponse.Rows.Count > 0)
                            {
                                emailBodyText.Append("<thead>");
                                emailBodyText.Append("<tr>");
                                emailBodyText.Append("<th>#</th>");
                                foreach (DataColumn item in surveyResponse.Columns)
                                {
                                    emailBodyText.Append("<th>" + item.ColumnName.ToString().ToUpper() + "</th>");
                                }

                                emailBodyText.Append("</tr>");
                                emailBodyText.Append("</thead>");
                                emailBodyText.Append("<tbody>");
                                int rowno = 1;
                                foreach (DataRow item in surveyResponse.Rows)
                                {
                                    emailBodyText.Append("<tr>");
                                    emailBodyText.Append("<td>" + rowno + "</td>");
                                    foreach (DataColumn dc in surveyResponse.Columns)
                                    {
                                        emailBodyText.Append("<td>" + item[dc.ColumnName] + "</td>");
                                    }


                                    emailBodyText.Append("</tr>");
                                    //emailBodyText.Append("<td>" + item.ColumnName + "</td>");

                                    rowno = rowno + 1;
                                }


                                emailBodyText.Append("</tbody>");
                            }

                            response.responseJSON = emailBodyText.ToString();
                            //response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                    }
                }



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetDynamicReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        #endregion



        public ResponseClass GetBOQAssessmentReport(getBOQAssessmentReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            try
            {
                SqlParameter[] parameter2 = {
                new SqlParameter("@Geo", request.Geo),
                new SqlParameter("@PageNumber", request.PageNumber),
                new SqlParameter("@RowsOfPage", request.RowsOfPage)
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("RPT_HGSHall_GetBOQAssessmentReport", parameter2, outParameters);


                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                // pagination start
                int recordcount = 1;
                if (dsResult.Tables[0] != null && dsResult.Tables[0].Rows.Count > 0)
                {


                    if (request.PageNumber != -1)
                    {
                        recordcount = Convert.ToInt32(dsResult.Tables[0].Rows[0]["recordcount"]);
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetBOQAssessmentReport", "3535", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

        public ResponseClass GetBOQCourseReport(getBOQAssessmentReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            if (String.IsNullOrEmpty(request.Geo))
            {
                request.Geo = "";
            }

            try
            {
                // getting event names with assessment

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_boq_course_report(                                                                        
                                                                    :p_geo,
                                                                    :p_pageno,
                                                                    :p_recordno
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_geo", DbType.String).Value = request.Geo;
                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);

                // pagination start
                int recordcount = 1;
                if (dtData != null && dtData.Rows.Count > 0)
                {
                    recordcount = Convert.ToInt32(dtData.Rows[0]["recordcount"]);

                    if (request.PageNumber != -1)
                    {
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetBOQCourseReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

        public ResponseClass GetPOSHCourseReport(getPOSHReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.Month))
            {
                request.Month = "";
            }

            if (String.IsNullOrEmpty(request.Year) || (request.Year != null && request.Year == "0"))
            {
                request.Year = "";
            }

            try
            {
               
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_posh_course_report(                                                                        
                                                                    :p_year,
                                                                    :p_month,
                                                                    :p_pageno,
                                                                    :p_recordno
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_year", DbType.String).Value = request.Year;
                        cmd.Parameters.AddWithValue("p_month", DbType.String).Value = request.Month;
                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);

                // pagination start
                int recordcount = 1;
                if (dtData != null && dtData.Rows.Count > 0)
                {
                    recordcount = Convert.ToInt32(dtData.Rows[0]["recordcount"]);

                    if (request.PageNumber != -1)
                    {
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
                //pagination end

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetPOSHCourseReport", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }
        public ResponseClass GetPOSHReportFilters(getPOSHReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
               
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_posh_course_report_filters(    

                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseJSONSecondary = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetPOSHCourseReport", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }


        public ResponseClass GetReportFilterEventList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_report_filter_event_list(                                                                        
                                                                    :pcurrentemployeeid,
                                                                    :pcurrentemployeerole,
                                                                    :peventtype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.EMPCode;
                        cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = "";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterEventList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

        public ResponseClass GetReportFilterClassroomList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_report_filter_classroom_list(                                                                        
                                                                    :pcurrentemployeeid,
                                                                    :pcurrentemployeerole,
                                                                    :peventtype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.EMPCode;
                        cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = "";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterEventList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }
        public ResponseClass GetReportFilterClassroomCreatorList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_report_filter_classroom_creator_list(                                                                        
                                                                    :pcurrentemployeeid,
                                                                    :pcurrentemployeerole,
                                                                    :peventtype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.EMPCode;
                        cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = "";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterClassroomCreatorList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }
        
        public ResponseClass GetReportFilterEventCreatorList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_report_filter_event_creator_list(                                                                        
                                                                    :pcurrentemployeeid,
                                                                    :pcurrentemployeerole,
                                                                    :peventtype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.EMPCode;
                        cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = "";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterEventCreatorList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }
        public ResponseClass GetReportFilterLearningNameList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_report_filter_event_creator_list(                                                                        
                                                                    :pcurrentemployeeid,
                                                                    :pcurrentemployeerole,
                                                                    :peventtype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.EMPCode;
                        cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = "";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterEventCreatorList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }
        public ResponseClass GetReportFilterLearningCreatorList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_report_filter_event_creator_list(                                                                        
                                                                    :pcurrentemployeeid,
                                                                    :pcurrentemployeerole,
                                                                    :peventtype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.EMPCode;
                        cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = "";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterEventCreatorList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

        public ResponseClass GetReportFilterAssessmentList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {
                if (request.CurrentRoleName == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EMPCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            request.AssignedCompany = request.AssignedCompany + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                        }

                        request.AssignedCompany = request.AssignedCompany.TrimEnd(',');


                    }
                }
                else
                {
                    request.AssignedCompany = "";
                }
                SqlParameter[] parameter = {
                new SqlParameter("@CreatedBy", request.EMPCode),
                new SqlParameter("@CurrentRoleCompanyCode", request.AssignedCompany),
                new SqlParameter("@RoleName", request.CurrentRoleName),
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();



                dsResult = dBConnection.ExecuteDataSet("RPT_HGSall_Assessment_GetAssessmentDataReportFilter", parameter, outParameters);


                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterAssessmentList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

        public ResponseClass GetReportFilterAssessmentCreatorList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                if (request.CurrentRoleName == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EMPCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            request.AssignedCompany = request.AssignedCompany + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                        }

                        request.AssignedCompany = request.AssignedCompany.TrimEnd(',');


                    }
                }
                else
                {
                    request.AssignedCompany = "";
                }

                SqlParameter[] parameter = {
                new SqlParameter("@CreatedBy", request.EMPCode),
                new SqlParameter("@CurrentRoleCompanyCode", request.AssignedCompany),
                new SqlParameter("@RoleName", request.CurrentRoleName),
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();



                dsResult = dBConnection.ExecuteDataSet("PRC_Assessment_GetAssessmentDataAPI", parameter, outParameters);


                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterAssessmentCreatorList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }


        public ResponseClass GetReportFilterSurveyNameList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                DataTable dtData = new DataTable();
                DataTable dtresult = new DataTable();
                DataTable surveyResponse = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_report_filter_survey_name_list(                                                                        
                                                                    :pcurrentemployeeid,
                                                                    :pcurrentemployeerole,
                                                                    :peventtype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.EMPCode;
                        cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = "";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }

                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterSurveyNameList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

        private string RemoveSuffix(string input)
        {
            string suffix = " - Survey";

            // Remove suffix
            if (input.EndsWith(suffix))
            {
                input = input.Substring(0, input.Length - suffix.Length).Trim();
            }

            return input;
        }

        public ResponseClass GetReportFilterSurveyCreatorList(ReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (String.IsNullOrEmpty(request.EMPCode))
            {
                return response;
            }

            if (String.IsNullOrEmpty(request.CurrentRoleName))
            {
                return response;
            }

            try
            {

                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_report_filter_survey_creator_list(                                                                        
                                                                    :pcurrentemployeeid,
                                                                    :pcurrentemployeerole,
                                                                    :peventtype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.EMPCode;
                        cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRoleName;
                        cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = "";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportFilterSurveyCreatorList", "4225", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }

    }
}
