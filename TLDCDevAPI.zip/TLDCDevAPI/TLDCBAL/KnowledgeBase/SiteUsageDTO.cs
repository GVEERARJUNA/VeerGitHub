﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.KnowledgeBase
{
    public class SiteUsageDTO
    {
    }
    public class EmployeeNameWithIdDTO
    {
        public string CountryName { get; set; }
        public string CurrentRole { get; set; }
        public string FullName { get; set; }
        public string EmployeeId { get; set; }
    }
    public class DesignationDTO
    {
        public string CountryName { get; set; }
        public string Designation { get; set; }
    }
    public class RoleDTO
    {
        public string CountryName { get; set; }
        public string Role { get; set; }
    }
    public class ReportingAuthorityDTO
    {
        public string CountryName { get; set; }
        public string CurrentRole { get; set; }
        public string Fullname { get; set; }
        public string EmployeeId { get; set; }
    }
    public class LocationDTO
    {
        public string CountryName { get; set; }
        public string Location { get; set; }
        public string CurrentRole { get; set; }
        public string EmployeeId { get; set; }
    }
}
