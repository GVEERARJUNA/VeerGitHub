﻿using TLDCBAL.Common;

namespace TLDCBAL.KnowledgeBase
{
    public interface IKnowledgeBaseBL
    {
        ResponseClass GetAssessmentDetailReport(getassessmentdetailreportDTO request);
        ResponseClass GetSCORMCoursesProgressReport(getscormcourseprogressreportrequestDTO request);
        ResponseClass GetEmployeeDetails(EmployeeNameWithIdDTO request);
        ResponseClass GetDesignationDetails(DesignationDTO request);
        ResponseClass GetRoleDetails(RoleDTO request);
        ResponseClass GetReportingAuthorityDetails(ReportingAuthorityDTO request);
        ResponseClass GetLocationDetails(LocationDTO request);
        ResponseClass SiteUsageReport(getSiteUsageReportDTO request);
        ResponseClass GetLearningNameDetails(LearningNameDTO request);
        ResponseClass GetEventNameDetails(EventNameDTO request);
        ResponseClass GetClassNameDetails(ClassNameDTO request);
        ResponseClass GetAssessmentQuestionsReport(getAssessmentQuestionsReportDTO request);
        ResponseClass GetAssessmentSummaryReport(getAssessmentReportDTO request);
        ResponseClass GetAssessmentQuestionsType(getAssessmentQuestionsReportDTO request);
        ResponseClass GetAssessmentNames(getAssessmentQuestionsReportDTO request);
        ResponseClass GetClassEventNames(getAssessmentQuestionsReportDTO request);

        ResponseClass BlendedLearnerProgressReport(BlendedLearnerProgressReportDTO request);
        ResponseClass GetClassNameForReport(ClassNameReportDTO request);
        ResponseClass GetEventNameForReport(EventNameReportDTO request);
        ResponseClass LearningDistributionReport(LearningDistributionReport request);

        ResponseClass GetClassNameAttendance(ClassNameForAttendanceDTO request);
        ResponseClass GetEventNameAttendance(EventNameForAttendanceDTO request);
        ResponseClass GetSessionNameAttendance(SessionNameForAttendanceDTO request);
        ResponseClass ClassroomAttendanceDetailsReport(ClassroomAttendanceDetailsReportDTO request);
        ResponseClass ClassroomAttendanceSummaryReport(ClassroomAttendanceSummaryReportDTO request);
        ResponseClass GetSurveyNameDetails(SurveyNameDTO request);
        ResponseClass SurveyQuestionSummaryReport(SurveyQuestionSummaryReportDTO request);
        ResponseClass SurveySummaryReportDetails(SurveySummaryDetailedReportDTO request);
        ResponseClass GetSurveySummaryReport(getSurveySummaryReportDTO request);
        ResponseClass GetSurveySummaryReportNameList(getSurveySummaryReportDTO request);

        ResponseClass getProjectFrameworkReport(getprojectframeworkreportrequestDTO request);

        ResponseClass getProjectFrameworkReportDashboard(getprojectframeworkreportrequestDTO request);

        ResponseClass GetScheduleReportHeader(getschedulereportrequestdto request);

        ResponseClass GetDynamicReport(getschedulereportrequestdto request);
        ResponseClass GetBOQAssessmentReport(getBOQAssessmentReportRequestDTO request);
        ResponseClass GetBOQCourseReport(getBOQAssessmentReportRequestDTO request);
        ResponseClass GetPOSHCourseReport(getPOSHReportRequestDTO request);
        ResponseClass GetPOSHReportFilters(getPOSHReportRequestDTO request);
        ResponseClass GetReportFilterEventList(ReportFilterDTO request);
        ResponseClass GetReportFilterClassroomList(ReportFilterDTO request);
        ResponseClass GetReportFilterAssessmentList(ReportFilterDTO request);
        ResponseClass GetReportFilterAssessmentCreatorList(ReportFilterDTO request);
        ResponseClass GetReportFilterEventCreatorList(ReportFilterDTO request);
        ResponseClass GetReportFilterLearningNameList(ReportFilterDTO request);
        ResponseClass GetReportFilterLearningCreatorList(ReportFilterDTO request);
        ResponseClass GetReportFilterSurveyCreatorList(ReportFilterDTO request);
        ResponseClass GetReportFilterSurveyNameList(ReportFilterDTO request);
        ResponseClass GetReportFilterClassroomCreatorList(ReportFilterDTO request);

    }
}