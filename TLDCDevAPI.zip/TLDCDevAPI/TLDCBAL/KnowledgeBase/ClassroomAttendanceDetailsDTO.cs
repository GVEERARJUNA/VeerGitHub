﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.KnowledgeBase
{
    class ClassroomAttendanceDetailsDTO
    {
    }
    public class ClassNameForAttendanceDTO
    {
        public string CountryName { get; set; }
        public string ClassName { get; set; }
    }
    public class EventNameForAttendanceDTO
    {
        public string CountryName { get; set; }
        public string EventName { get; set; }
        public string EventDisplayName { get; set; }
        public string CurrentRole { get; set; }
        public string EmployeeId { get; set; }
    }
    public class SessionNameForAttendanceDTO
    {
        public string CountryName { get; set; }
        public string SessionName { get; set; }
        public string CurrentRole { get; set; }
        public string EmployeeId { get; set; }
    }
}
