﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.KnowledgeBase
{
    class BlendedLearnerProgressDTO
    {
    }
    public class EmployeeNameDTO
    {
        public string CountryName { get; set; }
        public string FullName { get; set; }
        public string EmployeeId { get; set; }
    }
    public class LearningNameDTO
    {
        public string CountryName { get; set; }
        public string LearningName { get; set; }
        public string CurrentRole { get; set; }
        public string EmployeeId { get; set; }
    }
    public class EventNameDTO
    {
        public string CountryName { get; set; }
        public string EventName { get; set; }
        public string CurrentRole { get; set; }
        public string EmployeeId { get; set; }
    }
    public class ClassNameDTO
    {
        public string CountryName { get; set; }
        public string ClassName { get; set; }
        public string CurrentRole { get; set; }
        public string EmployeeId { get; set; }
    }
    public class SurveyNameDTO
    {
        public string CountryName { get; set; }
        public string SurveyName { get; set; }
        public string CurrentRole { get; set; }
        public string EmployeeId { get; set; }
    }
}
