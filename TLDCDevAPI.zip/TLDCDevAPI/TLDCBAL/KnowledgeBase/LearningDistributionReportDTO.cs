﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.KnowledgeBase
{
    class LearningDistributionReportDTO
    {
    }
    public class ClassNameReportDTO
    {
        public string CountryName { get; set; }
        public string ClassName { get; set; }
    }
    public class EventNameReportDTO
    {
        public string CountryName { get; set; }
        public string EventName { get; set; }
    }
}
