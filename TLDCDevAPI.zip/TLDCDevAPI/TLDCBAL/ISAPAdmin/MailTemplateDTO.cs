﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ISAPAdmin
{
    public class MailTemplateDTO
    {
        public string TemplateName { get; set; }
        public string TemplateText { get; set; }
        public string TemplateCreatedBy { get; set; }
        public string TemplateID { get; set; }
        public string TemplateModifiedBy { get; set; }
        public string TemplateLanguageID { get; set; }
        public List<MailTemplateDTO> TemplateDetails { get; set; }
    }

    public class MailTemplateDeleteDTO
    {
        public string TemplateID { get; set; }
        public string TemplateName { get; set; }
        public string TemplateDeletedBy { get; set; }
    }

    public class MailLanguageDTO
    {
        public string LanguageID { get; set; }
        public string LanguageName { get; set; }
        public string IsActive { get; set; }
    }

}
