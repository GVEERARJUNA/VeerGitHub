﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;

namespace TLDCBAL.ISAPAdmin
{
    public interface IMailTemplateBL
    {
        ResponseClass InsertMailTemplateDetails(MailTemplateDTO request);
        ResponseClass DeleteMailTemplateDetails(MailTemplateDeleteDTO request);
        ResponseClass GetMailTemplateDetails(MailTemplateDTO request);
        ResponseClass ViewISAPMailTemplateDetails(MailTemplateDTO request);
        ResponseClass UpdateISAPMailTemplateDetails(MailTemplateDTO request);
        ResponseClass GetMailLanguage(MailLanguageDTO request);
    }
}
