﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.ISAPAdmin
{
    public class MailTemplateBL : IMailTemplateBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;


        public MailTemplateBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.QualtricsDbConnection);

            _serviceconnect = serviceconnect;
        }

        public ResponseClass InsertMailTemplateDetails(MailTemplateDTO request)
        {
            ResponseClass response = new ResponseClass();
            string templateName = string.Empty;

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery = "SELECT \"TemplateName\" FROM public.\"TemplateMaster\" WHERE \"TemplateName\" = '" + request.TemplateName + "' AND \"IsActive\" = 'Y'";
                npgsqlConnection.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlConnection);

                NpgsqlDataReader dataAdapter = cmd.ExecuteReader();

                if (dataAdapter.Read())
                {
                    templateName = dataAdapter[0].ToString();
                }

                npgsqlConnection.Close();

                if(string.IsNullOrWhiteSpace(templateName))
                {
                    using (NpgsqlConnection npgsqlConnection1 = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"CALL public.prc_inserttemplatetext('" + request.TemplateName + "','" + request.TemplateText + "','Y','" + request.TemplateCreatedBy + "','"+request.TemplateLanguageID+"')", npgsqlConnection1))
                        {
                            npgsqlConnection1.Open();

                            NpgsqlDataReader dataReader = npgsqlCommand.ExecuteReader();

                            response.responseMessage = "Success";
                            response.responseJSON = JsonConvert.SerializeObject("Success");
                        }
                    }

                    response.responseCode = 1;
                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "Template alerdy exist!";
                    response.responseJSON = JsonConvert.SerializeObject("Template alerdy exist!");
                }
                
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ISAP Admin Mail Template Page", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetMailTemplateDetails(MailTemplateDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dtMailTemaplate = new DataTable();

                string pgsqlConnection = appSettings.Value.DbConnection;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_templatetext('')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtMailTemaplate);
                        response.responseJSON = JsonConvert.SerializeObject(dtMailTemaplate);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ISAP Admin Mail Template Page", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass DeleteMailTemplateDetails(MailTemplateDeleteDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"CALL public.prc_delete_templatetext(" + request.TemplateID + ",'" + request.TemplateName + "','" + request.TemplateDeletedBy + "')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataReader dataReader = npgsqlCommand.ExecuteReader();

                        response.responseMessage = "Success";
                        response.responseJSON = JsonConvert.SerializeObject("Success");
                    }
                }

                response.responseCode = 1;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ISAP Admin Mail Template Page", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass ViewISAPMailTemplateDetails(MailTemplateDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtMailTemaplate = new DataTable();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery = "SELECT \"TemplateID\",\"TemplateName\",\"TemplateText\", \"MailLanguageID\" FROM public.\"TemplateMaster\" WHERE \"TemplateID\" = " + request.TemplateID+" AND \"IsActive\" = 'Y'";

                npgsqlConnection.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery,npgsqlConnection);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);

                dataAdapter.Fill(dtMailTemaplate);

                npgsqlConnection.Close();

                response.responseCode = 1;
                response.responseMessage = "Message";
                response.responseJSON = JsonConvert.SerializeObject(dtMailTemaplate);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ISAP Admin Mail Template Page", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass UpdateISAPMailTemplateDetails(MailTemplateDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery = "UPDATE public.\"TemplateMaster\" SET \"TemplateText\" = '" + request.TemplateText + "',\"ModifiedBy\" = '" + request.TemplateModifiedBy + "',\"ModifiedDate\" = now(), \"MailLanguageID\" = '" + request.TemplateLanguageID + "' WHERE \"TemplateID\" = " + request.TemplateID;

                npgsqlConnection.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlConnection);

                NpgsqlDataReader reader = cmd.ExecuteReader();

                npgsqlConnection.Close();

                response.responseCode = 1;
                response.responseMessage = "Template text is updated.";
                response.responseJSON = JsonConvert.SerializeObject("Template text is updated.");
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ISAP Admin Mail Template Page", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetMailLanguage(MailLanguageDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable languageDataTable = new DataTable();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery = "SELECT \"LanguageMasterID\", \"LanguageName\" FROM public.\"LanguageMaster\" WHERE \"IsActive\" = 'Y';";

                npgsqlConnection.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlConnection);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);

                dataAdapter.Fill(languageDataTable);

                npgsqlConnection.Close();

                response.responseCode = 1;
                response.responseMessage = "Message";
                response.responseJSON = JsonConvert.SerializeObject(languageDataTable);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ISAP Admin Mail Template Page", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

    }
}
