﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;

namespace TLDCBAL.Reports
{
   public interface IAssessmentReportBL
    {
        public ResponseClass GetDistinctGeo();
        public ResponseClass GetDistinctAssessment(AssessmentReportRequest request);

        public ResponseClass GetDistinctEvent(AssessmentReportRequest request);
        public ResponseClass GetAssessmentSummaryReportData(AssessmentReportRequest request);

        ResponseClass GetQuickAssessmentDashboardCount(AssessmentReportRequest request);

        ResponseClass GetQuickAssessmentDashboardCountDetail(AssessmentReportRequest request);

        ResponseClass GetDistinctAssessmentDetail(AssessmentReportRequest request);
    }
}
