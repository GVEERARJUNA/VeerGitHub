﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.Reports
{
    public class ISAPReportBL : IISAPReportBL
    {
        private readonly IServiceConnect _serviceconnect;


        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;
        private IQualtricsDataBL _qualtricsBL;

        public ISAPReportBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.QualtricsDbConnection);
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
        }

        public ResponseClass GetISAPCompletionSummary(getISAPCompletionSummaryDTO request)
        {

            ResponseClass response = new ResponseClass();
            if (!string.IsNullOrEmpty(request.UserName))
            {
                // check employee valid
                bool checkValidEmployee;
                checkValidEmployee = _qualtricsBL.checkEmployee(request.CurrentUser, request.CurrentRole, request.UserName);
                if (!checkValidEmployee)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid Employee!";
                    return response;
                }

            }
            else
            {
                if (request.CurrentRole == "Team Lead" && string.IsNullOrEmpty(request.UserName))
                {
                    getTeamMembersRequestDTO getMemberRequest = new getTeamMembersRequestDTO();
                    getMemberRequest.EmployeeCode = request.CurrentUser;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getMemberRequest);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            // request.UserName = request.UserName + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                            request.UserName = request.UserName + Convert.ToString(exclude["EmployeeID"]) + ",";
                        }

                        request.UserName = request.UserName.TrimEnd(',');

                    }
                }
            }

            try
            {
                string fromDate = string.Empty;
                string toDate = string.Empty;
                if (!string.IsNullOrEmpty(request.FromDate))
                {
                    try
                    {
                        fromDate = Convert.ToDateTime(request.FromDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetISAPCompletionSummary", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;


                    }
                }
                if (!string.IsNullOrEmpty(request.ToDate))
                {
                    try
                    {
                        toDate = Convert.ToDateTime(request.ToDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetISAPCompletionSummary", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;


                    }
                }

                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_isap_completionsummary
                                                                        ( 
                                                                            :p_username,
                                                                            :p_currentrole,
                                                                            :p_fromdate,
                                                                            :p_todate
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;
                        cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = fromDate;
                        cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = toDate;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetISAPCompletionSummary", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetISAPStatusReport(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            string sqlQuery = string.Empty;
            int k = 0;
            string departmentList = string.Empty;
            try
            {
                string fromDate = string.Empty;
                string toDate = string.Empty;

                if(!string.IsNullOrWhiteSpace(request.DateRange))
                {
                    try
                    {
                        string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

                        fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                        toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetISAPStatusReport", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid Date Range";
                        return response;


                    }

                    DateTime dtFrom = new DateTime();
                    DateTime dtTo = new DateTime();

                    dtFrom = Convert.ToDateTime(fromDate);
                    dtTo = Convert.ToDateTime(toDate);

                    if (dtFrom > dtTo)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid date range selected!";
                        return response;
                    }

                    //TimeSpan difference = dtTo - dtFrom;

                    //if (difference.TotalDays > 180)
                    //{
                    //    response.responseCode = 0;
                    //    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    //    return response;
                    //}
                }

                string teamMembers = string.Empty;
                if (request.currentRole=="Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.currentEmployee;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }

                    if (string.IsNullOrEmpty(request.Department) || request.Department == "0")
                    {
                        DataSet dsResult = new DataSet();
                        string query = string.Empty;
                        query = "select distinct Department_Code from Qualtrics_Data where COMPANY_CODE='" + request.Company + "' and Active_Separated='Active'";
                        
                        if (!string.IsNullOrEmpty(teamMembers))
                        {
                            query = query + " and ExternalDataReference in (" + teamMembers + ")";
                        }

                        
                       // request.Department = string.Empty;

                        dsResult = dBConnection.ExecuteDataSetInline(query);
                        if (dsResult != null && dsResult.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dsResult.Tables[0].Rows)
                            {
                                departmentList = departmentList + "'" + Convert.ToString(exclude["Department_Code"]) + "',";
                            }

                            departmentList = departmentList.TrimEnd(',');

                        }
                    }
                }

                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                sqlQuery = "select  a.#EmployeeCode# as EmployeeID,concat(EMP.#FIRSTNAME#,' ',EMP.#LASTNAME#)  as EmployeeName,cast(TO_CHAR(EMP.#DOJ#, 'dd-Mon-yy') as character varying) as DOJ,EMP.#Job_Title# as Designation,EMP.#DEPARTMENT# as Department,EMP.#Sub_Process# as Subprocess,7 as ModuleNeedToComplete,count(DISTINCT b.#ModuleCode#) as ModuleComplete,c.#AttemptNo# as AssesstmentAttemptNo,round( CAST(c.#ScorePercentage#  as numeric), 2) as AssesstmentScore,cast(TO_CHAR(a.#AllocationDate#, 'dd-Mon-yy') as character varying) as AssesstmentStartDate,cast(TO_CHAR(a.#ExpiryDate#, 'dd-Mon-yy') as character varying) as AssesstmentEndDate,case when a.#AssessmentStatus#=1 then 'Completed' else case when cast(now() as date)>a.#ExpiryDate# then 'Lapsed' else 'Pending' end end  as AssesstmentStatus,EMP.#Manager_Name# as managername,case when coalesce(cast(EMP.#Last_Working_Day# as character varying),'')!='' then cast(TO_CHAR(EMP.#Last_Working_Day#, 'dd-Mon-yyyy') as character varying) else '' end as resigndate,case when a.#AssessmentStatus#=1 and a.#AllocationType#='NewJoinee' then 'Month of joining' when a.#AssessmentStatus#=1 and a.#AllocationType#='Calender' then 'Month of Assessment' else '-' end as allocationtype,coalesce(ELD.#Reason#,'') as reason,   ";

                sqlQuery = sqlQuery + " cast(TO_CHAR(tm.#assdate#, 'dd-Mon-yyyy') as character varying) as AssessmentDate,";

                sqlQuery = sqlQuery + " tm.#ScoreGrade# as grade";

                //  sqlQuery = sqlQuery + " (select cast(TO_CHAR(#AssessmentDate#, 'dd-Mon-yyyy') as character varying) from #ModuleAssessmentAllocation# where #ModuleAllocationID#=a.#MAllocationID# order by #ModuleAssessmentAllocationID# desc limit 1) as AssessmentDate,";

                //  sqlQuery = sqlQuery + " (select #ScoreGrade# from #ModuleAssessmentAllocation# where #ModuleAllocationID#=a.#MAllocationID# order by #ModuleAssessmentAllocationID# desc limit 1) as grade,";

                sqlQuery = sqlQuery + " from #ModuleEmployeeAllocation# AS a left JOIN #EmployeeCourseLearningDetails# AS b ON a.#MAllocationID# = b.#ModuleAllocationID# and a.#EmployeeCode# = b.#EmployeeCode# and b.#AcknowledgedStatus#=1 left JOIN #ModuleAssessmentAllocation# AS c ON a.#MAllocationID# = c.#ModuleAllocationID# left JOIN #UserMaster# as u ON a.#EmployeeCode# = u.#EmployeeID# left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#EmployeeCode# left join #EmployeeLeaveDetails# ELD on ELD.#ModuleAllocationID#=A.#MAllocationID#";

                sqlQuery = sqlQuery + " left join( ";
                sqlQuery = sqlQuery + "    select PR.#ModuleAllocationID#,PR.MASA,MAS.#ScoreGrade#,MAS.#AssessmentDate# as assDate  from ";

                sqlQuery = sqlQuery + "    (select #ModuleAllocationID#, max(#ModuleAssessmentAllocationID#) as MASA ";
                sqlQuery = sqlQuery + "    from #ModuleAssessmentAllocation# ";
                sqlQuery = sqlQuery + "    group by #ModuleAllocationID#) PR ";
                sqlQuery = sqlQuery + "   inner join #ModuleAssessmentAllocation#  MAS on MAS.#ModuleAssessmentAllocationID# = PR.MASA ";


                sqlQuery = sqlQuery + " ) tm on tm.#ModuleAllocationID# = a.#MAllocationID# ";

                sqlQuery = sqlQuery + " WHERE   EMP.#COMPANY_CODE#='" + request.Company + "'";

                if (request.DOJ == "DOJ")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' and a.#AllocationType#='NewJoinee' ";
                }
                else if (request.DOJ == "SA")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' and a.#AllocationType#='Calender' ";
                }
                else if (request.DOJ == "AC")
                {
                    sqlQuery = sqlQuery + " and a.#AssessmentStatus#=1 and cast(a.#AssessmentCompletionTime# as date) BETWEEN '" + fromDate + "' AND '" + toDate + "' ";
                }
                else if (request.DOJ == "OV")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' ";
                }



                if (!string.IsNullOrEmpty(request.Department) && request.Department != "0")
                {
                    sqlQuery = sqlQuery + " and EMP.#Department_Code#='" + request.Department + "'";
                }
                if (!string.IsNullOrEmpty(departmentList))
                {
                    sqlQuery = sqlQuery + " and EMP.#Department_Code# in (" + departmentList + ")";
                }
                if (!string.IsNullOrEmpty(request.EmpType))
                {

                    if (request.EmpType== "Active")
                    {
                        sqlQuery = sqlQuery + " and EMP.#Active_Separated#='" + request.EmpType + "'";
                    }
                    else
                    {
                        sqlQuery = sqlQuery + " and EMP.#Active_Separated#='" + request.EmpType + "'";
                        //sqlQuery = sqlQuery + " and (EMP.#Active_Separated#='Active' or cast(EMP.#Last_Working_Day# as date)>='" + fromDate + "')";
                    }
                    
                }
                else
                {
                    sqlQuery = sqlQuery + " and (EMP.#Active_Separated#='Active' or cast(EMP.#Last_Working_Day# as date)>='" + fromDate + "')";
                }
                if (!string.IsNullOrEmpty(request.SurveyType) && request.SurveyType!="0")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationType#='" + request.SurveyType + "'";

                }
                if (!string.IsNullOrEmpty(teamMembers))
                {
                    sqlQuery = sqlQuery + " and a.#EmployeeCode# in (" + teamMembers + ")";
                }
                sqlQuery = sqlQuery + " GROUP By a.#MAllocationID#,c.#AttemptNo#,c.#ScorePercentage#,c.#StartDate#,c.#EndDate#,a.#AssessmentStatus#,u.#DOJ#, EMP.#Job_Title#,EMP.#FIRSTNAME#,EMP.#LASTNAME#,EMP.#DEPARTMENT#,EMP.#Sub_Process#,EMP.#Manager_Name#,EMP.#Last_Working_Day#,a.#AllocationDate#,a.#ExpiryDate#,a.#AllocationType#,a.#EmployeeCode#,EMP.#DOJ#,ELD.#Reason#,tm.#assdate#,tm.#ScoreGrade#  ORDER By a.#AllocationDate#";

                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();

                //dtEmployees.Columns.Add("AttemptNo1");
                //dtEmployees.Columns.Add("AttemptNo2");
                //dtEmployees.Columns.Add("AttemptNo3");
                //dtEmployees.Columns.Add("AttemptNo4");

                DataTable dtEmployees1 = dtEmployees.DefaultView.ToTable(true, "EmployeeID", "EmployeeName", "DOJ", "Designation", "ModuleNeedToComplete", "ModuleComplete", "AssesstmentStartDate", "AssesstmentEndDate", "AssesstmentStatus", "department", "subprocess", "AssessmentDate","managername", "resigndate", "grade", "allocationtype","reason");
                dtEmployees1.Columns.Add("AttemptNo1");
                dtEmployees1.Columns.Add("AttemptNo2");
                dtEmployees1.Columns.Add("AttemptNo3");
                dtEmployees1.Columns.Add("AttemptNo4");


                if (dtEmployees.Rows.Count > 0)
                {
                    foreach (DataRow item in dtEmployees1.Rows)
                    {
                        string EmployeeID = string.Empty;
                        
                        string dtAssessmentDate = string.Empty;
                        EmployeeID = Convert.ToString(item["EmployeeID"]);
                        dtAssessmentDate = Convert.ToString(item["AssessmentDate"]);
                        DataRow[] dr = dtEmployees.Select("EmployeeID='" + EmployeeID + "' AND AssessmentDate='" + dtAssessmentDate + "'");

                        if (dr!=null && dr.Length>0)
                        {
                            foreach (DataRow dtr in dr)
                            {
                                //foreach (DataColumn dc in dtEmployees.Columns)
                                //{
                                //    if (dc.ColumnName == "assesstmentattemptno")
                                //    {

                                //    }
                                //}

                                int assessmentNo = Convert.ToInt32(dtr["assesstmentattemptno"]);
                                if (assessmentNo==1)
                                {
                                    item["AttemptNo1"] = dtr["AssesstmentScore"];
                                }
                                else if (assessmentNo == 2)
                                {
                                    item["AttemptNo2"] = dtr["AssesstmentScore"];
                                }
                                else if (assessmentNo == 3)
                                {
                                    item["AttemptNo3"] = dtr["AssesstmentScore"];
                                }
                                else if (assessmentNo == 4)
                                {
                                    item["AttemptNo4"] = dtr["AssesstmentScore"];
                                }
                            }
                        }
                    }

                   
                }

                response.responseJSON = JsonConvert.SerializeObject(dtEmployees1);
                


                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetISAPStatusReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetFinalISAPStatusReport(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            string sqlQuery = string.Empty;
            int k = 0;
            string departmentList = string.Empty;
            try
            {
                string fromDate = string.Empty;
                string toDate = string.Empty;

                if (!string.IsNullOrWhiteSpace(request.DateRange))
                {
                    try
                    {
                        string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

                        fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                        toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetISAPStatusReport", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid Date Range";
                        return response;


                    }

                    DateTime dtFrom = new DateTime();
                    DateTime dtTo = new DateTime();

                    dtFrom = Convert.ToDateTime(fromDate);
                    dtTo = Convert.ToDateTime(toDate);

                    if (dtFrom > dtTo)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid date range selected!";
                        return response;
                    }

                    //TimeSpan difference = dtTo - dtFrom;

                    //if (difference.TotalDays > 180)
                    //{
                    //    response.responseCode = 0;
                    //    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    //    return response;
                    //}
                }

                string teamMembers = string.Empty;
                if (request.currentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.currentEmployee;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }

                    if (string.IsNullOrEmpty(request.Department) || request.Department == "0")
                    {
                        DataSet dsResult = new DataSet();
                        string query = string.Empty;
                        query = "select distinct Department_Code from Qualtrics_Data where COMPANY_CODE='" + request.Company + "' and Active_Separated='Active'";

                        if (!string.IsNullOrEmpty(teamMembers))
                        {
                            query = query + " and ExternalDataReference in (" + teamMembers + ")";
                        }


                        // request.Department = string.Empty;

                        dsResult = dBConnection.ExecuteDataSetInline(query);
                        if (dsResult != null && dsResult.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dsResult.Tables[0].Rows)
                            {
                                departmentList = departmentList + "'" + Convert.ToString(exclude["Department_Code"]) + "',";
                            }

                            departmentList = departmentList.TrimEnd(',');

                        }
                    }
                }

                string allocationID = string.Empty;
                DataTable dtAllocation = new DataTable();
                dtAllocation = getModuleAllocation(request);
                if (dtAllocation != null && dtAllocation.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtAllocation.Rows)
                    {
                        allocationID = allocationID + "" + Convert.ToString(exclude["emp_code"]) + ",";
                    }

                    allocationID = allocationID.TrimEnd(',');

                }

                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                sqlQuery = "select  a.#EmployeeCode# as EmployeeID,concat(EMP.#FIRSTNAME#,' ',EMP.#LASTNAME#) as EmployeeName,case when lower(a.#AllocationType#)='newjoinee' then 'NEWJOINEE' else 'TENURE' end as allocationtype,cast(TO_CHAR(EMP.#DOJ#, 'dd-Mon-yy') as character varying) as DOJ,EMP.#Job_Title# as Designation,EMP.#DEPARTMENT# as Department,EMP.#Sub_Process# as Subprocess,7 as ModuleNeedToComplete,count(DISTINCT b.#ModuleCode#) as ModuleComplete,c.#AttemptNo# as AssesstmentAttemptNo,round( CAST(c.#ScorePercentage#  as numeric), 2) as AssesstmentScore,cast(TO_CHAR(a.#AllocationDate#, 'dd-Mon-yy') as character varying) as AssesstmentStartDate,cast(TO_CHAR(a.#ExpiryDate#, 'dd-Mon-yy') as character varying) as AssesstmentEndDate,case when a.#AssessmentStatus#=1 then 'Completed' else case when cast(now() as date)>a.#ExpiryDate# then 'Lapsed' else 'Pending' end end  as AssesstmentStatus,(select cast(TO_CHAR(#AssessmentDate#, 'dd-Mon-yyyy') as character varying) from #ModuleAssessmentAllocation# where #ModuleAllocationID#=a.#MAllocationID# order by #ModuleAssessmentAllocationID# desc limit 1) as AssessmentDate,(select #ScoreGrade# from #ModuleAssessmentAllocation# where #ModuleAllocationID#=a.#MAllocationID# order by #ModuleAssessmentAllocationID# desc limit 1) as grade,EMP.#Manager_Name# as managername,case when coalesce(cast(EMP.#Last_Working_Day# as character varying),'')!='' then cast(TO_CHAR(EMP.#Last_Working_Day#, 'dd-Mon-yyyy') as character varying) else '' end as resigndate,case when a.#AssessmentStatus#=1 and a.#AllocationType#='NewJoinee' then 'Month of joining' when a.#AssessmentStatus#=1 and a.#AllocationType#='Calender' then 'Month of Assessment' else '-' end as emptype,coalesce(ELD.#Reason#,'') as reason from #ModuleEmployeeAllocation# AS a  left JOIN #EmployeeCourseLearningDetails# AS b ON a.#EmployeeCode# = b.#EmployeeCode# and b.#AcknowledgedStatus#=1 left JOIN #ModuleAssessmentAllocation# AS c ON a.#MAllocationID# = c.#ModuleAllocationID# left JOIN #UserMaster# as u ON a.#EmployeeCode# = u.#EmployeeID# left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#EmployeeCode# left join #EmployeeLeaveDetails# ELD on ELD.#ModuleAllocationID#=A.#MAllocationID# WHERE   EMP.#COMPANY_CODE#='" + request.Company + "' ";
                if (!string.IsNullOrEmpty(allocationID))
                {
                    sqlQuery = sqlQuery + " and a.#MAllocationID# in (" + allocationID + ")";
                }
                //request.DOJ = "OV";

                //if (request.DOJ == "DOJ")
                //{
                //    sqlQuery = sqlQuery + " and a.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' and a.#AllocationType#='NewJoinee' ";
                //}
                //else if (request.DOJ == "SA")
                //{
                //    sqlQuery = sqlQuery + " and a.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' and a.#AllocationType#='Calender' ";
                //}
                //else if (request.DOJ == "AC")
                //{
                //    sqlQuery = sqlQuery + " and a.#AssessmentStatus#=1 and cast(a.#AssessmentCompletionTime# as date) BETWEEN '" + fromDate + "' AND '" + toDate + "' ";
                //}
                //else if (request.DOJ == "OV")
                //{
                //    sqlQuery = sqlQuery + " and a.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' ";
                //}



                if (!string.IsNullOrEmpty(request.Department) && request.Department != "0")
                {
                    sqlQuery = sqlQuery + " and EMP.#Department_Code#='" + request.Department + "'";
                }
                else
                {
                    if (!string.IsNullOrEmpty(departmentList))
                    {
                        sqlQuery = sqlQuery + " and EMP.#Department_Code# in (" + departmentList + ")";
                    }
                }
                if (!string.IsNullOrEmpty(request.SurveyType) && request.SurveyType != "0")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationType#='" + request.SurveyType + "'";
                }
                //if (!string.IsNullOrEmpty(departmentList))
                //{
                //    sqlQuery = sqlQuery + " and EMP.#Department_Code# in (" + departmentList + ")";
                //}
                //if (!string.IsNullOrEmpty(request.EmpType))
                //{

                //    if (request.EmpType == "Active")
                //    {
                //        sqlQuery = sqlQuery + " and EMP.#Active_Separated#='" + request.EmpType + "'";
                //    }
                //    else
                //    {
                //        sqlQuery = sqlQuery + " and (EMP.#Active_Separated#='Active' or cast(EMP.#Last_Working_Day# as date)>='" + fromDate + "')";
                //    }

                //}
                //else
                //{
                //    sqlQuery = sqlQuery + " and (EMP.#Active_Separated#='Active' or cast(EMP.#Last_Working_Day# as date)>='" + fromDate + "')";
                //}
                if (!string.IsNullOrEmpty(teamMembers))
                {
                    sqlQuery = sqlQuery + " and u.#EmployeeID# in (" + teamMembers + ")";
                }
                sqlQuery = sqlQuery + " GROUP By a.#MAllocationID#,c.#AttemptNo#,c.#ScorePercentage#,c.#StartDate#,c.#EndDate#,a.#AssessmentStatus#,u.#DOJ#, EMP.#Job_Title#,EMP.#FIRSTNAME#,EMP.#LASTNAME#,EMP.#DEPARTMENT#,EMP.#Sub_Process#,EMP.#Manager_Name#,EMP.#Last_Working_Day#,a.#AllocationDate#,a.#ExpiryDate#,a.#AllocationType#,a.#EmployeeCode#,EMP.#DOJ#,ELD.#Reason# ORDER By a.#AllocationDate#";

                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                //DataTable dtdistinctEmployees = dtEmployees.DefaultView.ToTable(true, "EmployeeID");

                //if (dtdistinctEmployees.Rows.Count>0)
                //{

                //}


                //DataTable dtExistEmployee = new DataTable();
                //dtExistEmployee.Columns.Add("EmployeeCode");
                //dtExistEmployee.Columns.Add("AssessmentStatus");



                npgsql.Close();

                //dtEmployees.Columns.Add("AttemptNo1");
                //dtEmployees.Columns.Add("AttemptNo2");
                //dtEmployees.Columns.Add("AttemptNo3");
                //dtEmployees.Columns.Add("AttemptNo4");

                DataTable dtEmployees1 = dtEmployees.DefaultView.ToTable(true, "EmployeeID", "EmployeeName", "DOJ", "Designation", "ModuleNeedToComplete", "ModuleComplete", "AssesstmentStartDate", "AssesstmentEndDate", "AssesstmentStatus", "department", "subprocess", "AssessmentDate", "managername", "resigndate", "grade", "allocationtype","reason", "emptype");
                dtEmployees1.Columns.Add("AttemptNo1");
                dtEmployees1.Columns.Add("AttemptNo2");
                dtEmployees1.Columns.Add("AttemptNo3");
                dtEmployees1.Columns.Add("AttemptNo4");


                if (dtEmployees.Rows.Count > 0)
                {
                    foreach (DataRow item in dtEmployees1.Rows)
                    {
                        string EmployeeID = string.Empty;

                        string dtAssessmentDate = string.Empty;
                        EmployeeID = Convert.ToString(item["EmployeeID"]);
                        dtAssessmentDate = Convert.ToString(item["AssessmentDate"]);
                        DataRow[] dr = dtEmployees.Select("EmployeeID='" + EmployeeID + "' AND AssessmentDate='" + dtAssessmentDate + "'");

                        if (dr != null && dr.Length > 0)
                        {
                            foreach (DataRow dtr in dr)
                            {
                                //foreach (DataColumn dc in dtEmployees.Columns)
                                //{
                                //    if (dc.ColumnName == "assesstmentattemptno")
                                //    {

                                //    }
                                //}

                                int assessmentNo = Convert.ToInt32(dtr["assesstmentattemptno"]);
                                if (assessmentNo == 1)
                                {
                                    item["AttemptNo1"] = dtr["AssesstmentScore"];
                                }
                                else if (assessmentNo == 2)
                                {
                                    item["AttemptNo2"] = dtr["AssesstmentScore"];
                                }
                                else if (assessmentNo == 3)
                                {
                                    item["AttemptNo3"] = dtr["AssesstmentScore"];
                                }
                                else if (assessmentNo == 4)
                                {
                                    item["AttemptNo4"] = dtr["AssesstmentScore"];
                                }
                            }
                        }
                    }


                }

                response.responseJSON = JsonConvert.SerializeObject(dtEmployees1);



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetISAPStatusReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public DataTable getModuleAllocation(getISAPStatusReport request)
        {
            DataTable dtResult = new DataTable();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            if (!string.IsNullOrWhiteSpace(request.DateRange))
            {
                try
                {
                    string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

                    fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                    toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("getModuleAllocation", "1024", "From Date : " + ex.Message, "Exception");
                   
                }
            }

            try
            {
               
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;



                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_isap_final_report
                                                                        ( 
                                                                            :p_company,
                                                                            :p_department,:p_fromdate,
                                                                            :p_todate,:p_emptype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.Company))
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = request.Company;
                        else
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.Department))
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = request.Department;
                        else
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(toDate))
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = toDate;
                        else
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EmpType))
                            cmd.Parameters.AddWithValue("p_emptype", DbType.String).Value = request.EmpType;
                        else
                            cmd.Parameters.AddWithValue("p_emptype", DbType.String).Value = string.Empty;
                       



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtResult);
                        npgsqlConnection.Close();

                       
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEmployeeLeaveData", "1024", ex.Message, "Exception");

            }



            return dtResult;

        }

        public ResponseClass GetISAPCSummaryReport(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            string sqlQuery = string.Empty;
            int k = 0;
            string departmentList = string.Empty;
            try
            {
                string fromDate = string.Empty;
                string toDate = string.Empty;

                if (!string.IsNullOrWhiteSpace(request.DateRange))
                {
                    try
                    {
                        string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

                        fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                        toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetISAPCSummaryReport", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid Date Range";
                        return response;


                    }

                    DateTime dtFrom = new DateTime();
                    DateTime dtTo = new DateTime();

                    dtFrom = Convert.ToDateTime(fromDate);
                    dtTo = Convert.ToDateTime(toDate);

                    if (dtFrom > dtTo)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid date range selected!";
                        return response;
                    }

                    //TimeSpan difference = dtTo - dtFrom;

                    //if (difference.TotalDays > 180)
                    //{
                    //    response.responseCode = 0;
                    //    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    //    return response;
                    //}
                }

                string teamMembers = string.Empty;
                if (request.currentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.currentEmployee;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }

                    if (string.IsNullOrEmpty(request.Department) || request.Department == "0")
                    {
                        DataSet dsResult = new DataSet();
                        string query = string.Empty;
                        query = "select distinct Department_Code from Qualtrics_Data where COMPANY_CODE='" + request.Company + "' and Active_Separated='Active'";

                        if (!string.IsNullOrEmpty(teamMembers))
                        {
                            query = query + " and ExternalDataReference in (" + teamMembers + ")";
                        }


                        // request.Department = string.Empty;

                        dsResult = dBConnection.ExecuteDataSetInline(query);
                        if (dsResult != null && dsResult.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dsResult.Tables[0].Rows)
                            {
                                departmentList = departmentList + "'" + Convert.ToString(exclude["Department_Code"]) + "',";
                            }

                            departmentList = departmentList.TrimEnd(',');

                        }
                    }
                }

                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                //sqlQuery = "select  a.#EmployeeCode# as EmployeeID,concat(EMP.#FIRSTNAME#,' ',EMP.#LASTNAME#) as EmployeeName,cast(TO_CHAR(EMP.#DOJ#, 'dd-Mon-yy') as character varying) as DOJ,EMP.#Job_Title# as Designation,EMP.#DEPARTMENT# as Department,EMP.#Sub_Process# as Subprocess,7 as ModuleNeedToComplete,count(DISTINCT b.#ModuleCode#) as ModuleComplete,c.#AttemptNo# as AssesstmentAttemptNo,round( CAST(c.#ScorePercentage#  as numeric), 2) as AssesstmentScore,cast(TO_CHAR(a.#AllocationDate#, 'dd-Mon-yy') as character varying) as AssesstmentStartDate,cast(TO_CHAR(a.#ExpiryDate#, 'dd-Mon-yy') as character varying) as AssesstmentEndDate,case when a.#AssessmentStatus#=1 then 'Completed' else case when cast(now() as date)>a.#ExpiryDate# then 'Lapsed' else 'Pending' end end  as AssesstmentStatus,(select cast(TO_CHAR(#AssessmentDate#, 'dd-Mon-yyyy') as character varying) from #ModuleAssessmentAllocation# where #ModuleAllocationID#=a.#MAllocationID# order by #ModuleAssessmentAllocationID# desc limit 1) as AssessmentDate,(select #ScoreGrade# from #ModuleAssessmentAllocation# where #ModuleAllocationID#=a.#MAllocationID# order by #ModuleAssessmentAllocationID# desc limit 1) as grade,EMP.#Manager_Name# as managername,case when coalesce(cast(EMP.#Date_Of_Resignation# as character varying),'')!='' then cast(TO_CHAR(EMP.#Date_Of_Resignation#, 'dd-Mon-yyyy') as character varying) else '' end as resigndate,case when a.#AssessmentStatus#=1 and a.#AllocationType#='NewJoinee' then 'Month of joining' when a.#AssessmentStatus#=1 and a.#AllocationType#='Calender' then 'Month of Assessment' else '-' end as allocationtype from #ModuleEmployeeAllocation# AS a left JOIN #EmployeeCourseLearningDetails# AS b ON a.#EmployeeCode# = b.#EmployeeCode# left JOIN #ModuleAssessmentAllocation# AS c ON a.#MAllocationID# = c.#ModuleAllocationID# left JOIN #UserMaster# as u ON a.#EmployeeCode# = u.#EmployeeID# left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#EmployeeCode# WHERE   EMP.#COMPANY_CODE#='" + request.Company + "' ";
                sqlQuery = "select PR.Project as project,PR.DTCode,sum(PR.TargetCount) as target,";
                sqlQuery = sqlQuery + " sum(PR.Completed) as completed,";
                sqlQuery = sqlQuery + "sum(PR.TargetCount)-sum(PR.Completed) as notcompleted,";
                sqlQuery = sqlQuery + " case when sum(PR.Completed)> 0 then round(cast(cast(concat(sum(PR.Completed),'.00') as decimal)/ sum(PR.TargetCount) as decimal),5)*100 else 0.00 end as completedpercentage";
                sqlQuery = sqlQuery + " from";
                sqlQuery = sqlQuery + "  (";
                sqlQuery = sqlQuery + " select EM.#DEPARTMENT# as Project,EM.#Department_Code# as DTCode,";
                sqlQuery = sqlQuery + "  1 as TargetCount,";
                if (request.DOJ == "AC")
                {
                    sqlQuery = sqlQuery + " case when(A.#AssessmentStatus# = 1 and cast(A.#AssessmentCompletionTime# as date)  BETWEEN '" + fromDate + "' AND '" + toDate + "') then 1 else 0 end as Completed,";
                  //  sqlQuery = sqlQuery + " case when coalesce(MPA.#ModuleAllocationID#,0)>0 then 1 else 0 end as Completed, ";
                }
                else
                {
                    sqlQuery = sqlQuery + "case when A.#AssessmentStatus# = 1 then 1 else 0 end as Completed,";
                }
                

                sqlQuery = sqlQuery + "case when A.#AssessmentStatus# = 0 then 1 else 0 end as NotCompleted";

                sqlQuery = sqlQuery + " from #ModuleEmployeeAllocation# A";
                sqlQuery = sqlQuery + " inner join #EmployeeMaster# EM on A.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE#";
                //if (request.DOJ == "AC")
                //{
                //    sqlQuery = sqlQuery + " left join #ModuleAssessmentAllocation# MPA on MPA.#ModuleAllocationID#=A.#MAllocationID# AND MPA.#ScoreGrade# >= '50' and A.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "'";
                //}
                sqlQuery = sqlQuery + " where EM.#COMPANY_CODE# = '" + request.Company + "'";
                if (request.DOJ == "DOJ")
                {
                    sqlQuery = sqlQuery + " and A.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' and A.#AllocationType#='NewJoinee' ";
                }
                else if (request.DOJ == "SA")
                {
                    sqlQuery = sqlQuery + " and A.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' and A.#AllocationType#='Calender' ";
                }
                else if (request.DOJ == "AC")
                {
                    sqlQuery = sqlQuery + " and A.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "'";
                  //  sqlQuery = sqlQuery + " and A.#AssessmentStatus#=1 and cast(A.#AssessmentCompletionTime# as date) BETWEEN '" + fromDate + "' AND '" + toDate + "' ";
                }
                else if (request.DOJ == "OV")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' ";
                }
                if (!string.IsNullOrEmpty(request.Department) && request.Department != "0")
                {
                    sqlQuery = sqlQuery + " and EM.#Department_Code#='" + request.Department + "'";
                }
                else if (!string.IsNullOrEmpty(departmentList))
                {
                    sqlQuery = sqlQuery + " and EM.#Department_Code# in (" + departmentList + ")";
                }
                if (!string.IsNullOrEmpty(request.EmpType))
                {
                    sqlQuery = sqlQuery + " and EM.#Active_Separated#='" + request.EmpType + "'";
                    //if (request.EmpType == "Active")
                    //{
                    //    sqlQuery = sqlQuery + " and EM.#Active_Separated#='" + request.EmpType + "'";
                    //}
                    //else
                    //{
                    //    sqlQuery = sqlQuery + " and (EM.#Active_Separated#='Active' or cast(EM.#Last_Working_Day# as date)>='" + fromDate + "')";
                    //}

                }
                else
                {
                  //  sqlQuery = sqlQuery + " and (EM.#Active_Separated#='Active' or cast(EM.#Last_Working_Day# as date)>='" + fromDate + "')";
                }
                if (!string.IsNullOrEmpty(request.SurveyType) && request.SurveyType != "0")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationType#='" + request.SurveyType + "'";

                }
                if (!string.IsNullOrEmpty(teamMembers))
                {
                    sqlQuery = sqlQuery + " and u.#EmployeeID# in (" + teamMembers + ")";
                }
                sqlQuery = sqlQuery + " ) PR";
                sqlQuery = sqlQuery + " group by PR.Project,PR.DTCode";

                
                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();

               
                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetISAPCSummaryReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetISAPCSummaryReportDetail(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            string sqlQuery = string.Empty;
            int k = 0;
            string departmentList = string.Empty;
            try
            {
                string fromDate = string.Empty;
                string toDate = string.Empty;

                if (!string.IsNullOrWhiteSpace(request.DateRange))
                {
                    try
                    {
                        string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

                        fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                        toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("GetISAPCSummaryReport", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid Date Range";
                        return response;


                    }
                }

                string teamMembers = string.Empty;
                if (request.currentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.currentEmployee;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }

                    if (string.IsNullOrEmpty(request.Department) || request.Department == "0")
                    {
                        DataSet dsResult = new DataSet();
                        string query = string.Empty;
                        query = "select distinct Department_Code from Qualtrics_Data where COMPANY_CODE='" + request.Company + "' and Active_Separated='Active'";

                        if (!string.IsNullOrEmpty(teamMembers))
                        {
                            query = query + " and ExternalDataReference in (" + teamMembers + ")";
                        }


                       

                        dsResult = dBConnection.ExecuteDataSetInline(query);
                        if (dsResult != null && dsResult.Tables[0].Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dsResult.Tables[0].Rows)
                            {
                                departmentList = departmentList + "'" + Convert.ToString(exclude["Department_Code"]) + "',";
                            }

                            departmentList = departmentList.TrimEnd(',');

                        }
                    }
                }

                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                
                sqlQuery = "select A.#EmployeeCode# as empcode,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as employeename,";
                sqlQuery = sqlQuery + "cast(TO_CHAR(EM.#DOJ#, 'dd-Mon-yy') as character varying) as doj,EM.#Manager_Name# as managername,EM.#DEPARTMENT# as department,case when lower(A.#AllocationType#)='newjoinee' then 'NEWJOINEE' else 'TENURE' end as allocationtype,cast(TO_CHAR(A.#AllocationDate#, 'dd-Mon-yy') as character varying) as isapassigndate from #ModuleEmployeeAllocation# A ";
                sqlQuery = sqlQuery + " inner join #EmployeeMaster# EM on A.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE# ";
                sqlQuery = sqlQuery + " where EM.#COMPANY_CODE# = '" + request.Company +  "' ";
                
                
                if (request.DOJ == "AC")
                {
                    sqlQuery = sqlQuery + " and (A.#AssessmentStatus# =0 or cast(A.#AssessmentCompletionTime# as date)> '" + toDate + "') ";
                    //  sqlQuery = sqlQuery + " case when coalesce(MPA.#ModuleAllocationID#,0)>0 then 1 else 0 end as Completed, ";
                }
                else
                {
                    sqlQuery = sqlQuery + "and A.#AssessmentStatus#=0";
                }
                if (request.DOJ == "DOJ")
                {
                    sqlQuery = sqlQuery + " and A.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' and A.#AllocationType#='NewJoinee' ";
                }
                else if (request.DOJ == "SA")
                {
                    sqlQuery = sqlQuery + " and A.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' and A.#AllocationType#='Calender' ";
                }
                else if (request.DOJ == "AC")
                {
                    sqlQuery = sqlQuery + " and A.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "'";
                    
                }
                else if (request.DOJ == "OV")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationDate# BETWEEN '" + fromDate + "' AND '" + toDate + "' ";
                }
                if (!string.IsNullOrEmpty(request.Department) && request.Department != "0")
                {
                    sqlQuery = sqlQuery + " and EM.#DEPARTMENT#='" + request.Department + "'";
                }
               
                if (!string.IsNullOrEmpty(request.EmpType))
                {
                    sqlQuery = sqlQuery + " and EM.#Active_Separated#='" + request.EmpType + "'";
                    //if (request.EmpType == "Active")
                    //{
                    //    sqlQuery = sqlQuery + " and EM.#Active_Separated#='" + request.EmpType + "'";
                    //}
                    //else
                    //{
                    //    sqlQuery = sqlQuery + " and (EM.#Active_Separated#='Active' or cast(EM.#Last_Working_Day# as date)>='" + fromDate + "')";
                    //}

                }
                else
                {
                    //sqlQuery = sqlQuery + " and (EM.#Active_Separated#='Active' or cast(EM.#Last_Working_Day# as date)>='" + fromDate + "')";
                }
                if (!string.IsNullOrEmpty(request.SurveyType) && request.SurveyType != "0")
                {
                    sqlQuery = sqlQuery + " and a.#AllocationType#='" + request.SurveyType + "'";

                }

                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();


                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetISAPCSummaryReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        //public ResponseClass GetISAPCompletionSummaryYearly(getISAPCompletionSummaryYearlyDTO request)
        //{

        //    ResponseClass response = new ResponseClass();

        //    string employeeList = string.Empty;
        //    string selectQuery = string.Empty;
        //    string companies = string.Empty;

        //    if (request.EmployeeRole == "Team Lead")
        //    {
        //        getTeamMembersRequestDTO getMemberRequest = new getTeamMembersRequestDTO();
        //        getMemberRequest.EmployeeCode = request.CurrentUser;
        //        var QualtriData = _qualtricsBL.GetTeamMembers(getMemberRequest);
        //        DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
        //        if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
        //        {
        //            foreach (DataRow exclude in QualtricTeamMembers.Rows)
        //            {

        //                employeeList = employeeList + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
        //            }

        //            employeeList = employeeList.TrimEnd(',');

        //        }
        //    }
        //    if (request.EmployeeRole == "Geo Admin")
        //    {
        //        DataTable dtCompanies = new DataTable();
        //        dtCompanies = _qualtricsBL.gtAssignedCompany(request.CurrentUser);
        //        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //        {
        //            foreach (DataRow exclude in dtCompanies.Rows)
        //            {
        //                companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
        //            }

        //            companies = companies.TrimEnd(',');

        //        }
        //    }
        //    try
        //    {
        //        DataTable dtEmployees = new DataTable();
        //        selectQuery = "select MEA.#MAllocationID#,UM.#EXTERNALDATAREFERENCE# as employeeid,UM.#FIRSTNAME# as EmployeeName,UM.#COUNTRY#,cast(TO_CHAR(UM.#DOJ#, 'dd Mon  yyyy') as character varying) as DOJ,cast(TO_CHAR(MEA.#AllocationDate#, 'yyyy-MM-dd') as date) as AssignmentDate,cast(case when MEA.#CompletionStatus# = 1 and MEA.#AssessmentStatus# = 1 then 'Completed' else 'Pending' end as character varying) as CompletionStatus,#AllocationType# as ISAPAllocationCategory from #EmployeeMaster# UM left join #ModuleEmployeeAllocation# MEA on UM.#EXTERNALDATAREFERENCE# = MEA.#EmployeeCode# where date_part('year', MEA.#AllocationDate#) = '" + request.Year + "'";
        //        if (!string.IsNullOrEmpty(employeeList))
        //        {
        //            selectQuery = selectQuery + " and UM.#EXTERNALDATAREFERENCE# in (" + employeeList + ")";
        //        }
        //        if (!string.IsNullOrEmpty(companies))
        //        {
        //            selectQuery = selectQuery + " and UM.#COMPANY_CODE# in (" + companies + ")";
        //        }

        //        //  selectQuery = selectQuery + " group by UM.#COUNTRY#,MEA.#MAllocationID#,UM.#EXTERNALDATAREFERENCE#,EmployeeName,UM.#COUNTRY# ,#DOJ#,#AssignmentDate#,#CompletionStatus#;";

        //        selectQuery = selectQuery.Replace('#', '"');

        //        string pgsqlConnection = appSettings.Value.DbConnection;

        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(dtEmployees);

        //        npgsql.Close();

        //        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);


        //        //string pgsqlConnection = appSettings.Value.DbConnection;
        //        //using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
        //        //{
        //        //    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_isap_completionsummary_yearly
        //        //                                                        (
        //        //                                                            :p_year
        //        //                                                        )", npgsqlConnection))
        //        //    {
        //        //        cmd.CommandType = CommandType.Text; //
        //        //        if (!String.IsNullOrEmpty(request.Year))
        //        //            cmd.Parameters.AddWithValue("p_year", DbType.Double).Value = Convert.ToDouble(request.Year);
        //        //        else
        //        //            cmd.Parameters.AddWithValue("p_year", DbType.Double).Value = DBNull.Value;


        //        //        npgsqlConnection.Open();

        //        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
        //        //        dataAdapter.Fill(dtEmployees);
        //        //        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
        //        //    }
        //        //}

        //        response.responseCode = 1;
        //        response.responseMessage = "Success";
        //    }
        //    catch (Exception ex)
        //    {

        //        _serviceconnect.LogConnect("GetISAPCompletionSummaryYearly", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }
        //    return response;
        //}

        public ResponseClass GetISAPCompletionSummaryYearly(getISAPCompletionSummaryYearlyDTO request)
        {

            ResponseClass response = new ResponseClass();

            string employeeList = string.Empty;
            string selectQuery = string.Empty;
            string companies = string.Empty;

            if (request.EmployeeRole == "Team Lead")
            {
                getTeamMembersRequestDTO getMemberRequest = new getTeamMembersRequestDTO();
                getMemberRequest.EmployeeCode = request.CurrentUser;
                var QualtriData = _qualtricsBL.GetTeamMembers(getMemberRequest);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {

                        employeeList = employeeList + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                    }

                    employeeList = employeeList.TrimEnd(',');

                }
            }
            if (request.EmployeeRole == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.CurrentUser);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    }

                    companies = companies.TrimEnd(',');

                }
            }
            try
            {
                DataTable dtEmployees = new DataTable();
                selectQuery = "select MEA.#MAllocationID#,UM.#EXTERNALDATAREFERENCE# as employeeid,concat(UM.#FIRSTNAME#,' ',UM.#LASTNAME#) as EmployeeName,UM.#COUNTRY#,cast(TO_CHAR(UM.#DOJ#, 'dd Mon  yyyy') as character varying) as DOJ,cast(TO_CHAR(MEA.#AllocationDate#, 'yyyy-MM-dd') as date) as AssignmentDate,cast(case when MEA.#CompletionStatus# = 1 and MEA.#AssessmentStatus# = 1 then 'Completed' else 'Pending' end as character varying) as CompletionStatus,#AllocationType# as ISAPAllocationCategory,UM.#DEPARTMENT# AS department,case when coalesce(MEA.#MAllocationID#,0)>0 then 'Assigned' else 'Not Assigned' end as AssignedStatus from #EmployeeMaster# UM left join #ModuleEmployeeAllocation# MEA on UM.#EXTERNALDATAREFERENCE# = MEA.#EmployeeCode# and date_part('year', MEA.#AllocationDate#) = '" + request.Year + "' where 1=1 ";
                if (!string.IsNullOrEmpty(employeeList))
                {
                    selectQuery = selectQuery + " and UM.#EXTERNALDATAREFERENCE# in (" + employeeList + ")";
                }
                if (!string.IsNullOrEmpty(companies))
                {
                    selectQuery = selectQuery + " and UM.#COMPANY_CODE# in (" + companies + ")";
                }

                

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);

                npgsql.Close();

                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);


               

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetISAPCompletionSummaryYearly", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        //public ResponseClass GetISAPCompletionSummaryYearly(getISAPCompletionSummaryYearlyDTO request)
        //{

        //    ResponseClass response = new ResponseClass();
        //    // check employee valid
        //    //bool checkValidEmployee;
        //    //checkValidEmployee = _qualtricsBL.checkEmployee(request.CurrentUser, request.EmployeeRole, request.EmployeeId);
        //    //if (!checkValidEmployee)
        //    //{
        //    //    response.responseCode = 0;
        //    //    response.responseMessage = "Invalid Employee!";
        //    //    return response;
        //    //}

        //    try
        //    {
        //        DataTable dtEmployees = new DataTable();
        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
        //        {
        //            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_isap_completionsummary_yearly
        //                                                                (
        //                                                                    :p_year
        //                                                                )", npgsqlConnection))
        //            {
        //                cmd.CommandType = CommandType.Text; //
        //                if (!String.IsNullOrEmpty(request.Year))
        //                    cmd.Parameters.AddWithValue("p_year", DbType.Double).Value = Convert.ToDouble(request.Year);
        //                else
        //                    cmd.Parameters.AddWithValue("p_year", DbType.Double).Value = DBNull.Value;


        //                npgsqlConnection.Open();

        //                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
        //                dataAdapter.Fill(dtEmployees);
        //                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
        //            }
        //        }

        //        response.responseCode = 1;
        //        response.responseMessage = "Success";
        //    }
        //    catch (Exception ex)
        //    {

        //        _serviceconnect.LogConnect("GetISAPCompletionSummaryYearly", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }
        //    return response;
        //}

        public ResponseClass getEmployeeISAPExtension(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtResult = new DataTable();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            if (!string.IsNullOrWhiteSpace(request.DateRange))
            {
                try
                {
                    string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

                    fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                    toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("getEmployeeISAPExtension", "1024", "From Date : " + ex.Message, "Exception");

                }
            }

            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;



                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_employee_extension_report
                                                                        ( 
                                                                            :p_company,
                                                                            :p_department,:p_fromdate,
                                                                            :p_todate,:p_emptype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.Company))
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = request.Company;
                        else
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.Department))
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = request.Department;
                        else
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(toDate))
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = toDate;
                        else
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EmpType))
                            cmd.Parameters.AddWithValue("p_emptype", DbType.String).Value = request.EmpType;
                        else
                            cmd.Parameters.AddWithValue("p_emptype", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtResult);
                        npgsqlConnection.Close();

                        response.responseCode = 1;
                        response.responseMessage = "SUCCESS";
                        response.responseJSON = JsonConvert.SerializeObject(dtResult);

                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getEmployeeISAPExtension", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }



            return response;

        }
        public ResponseClass getDepartmentISAPExtension(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtResult = new DataTable();
            string fromDate = string.Empty;
            string toDate = string.Empty;

            if (!string.IsNullOrWhiteSpace(request.DateRange))
            {
                try
                {
                    string[] dateRange = request.DateRange.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);

                    fromDate = Convert.ToDateTime(dateRange[0]).ToString("yyyy-MM-dd");
                    toDate = Convert.ToDateTime(dateRange[1]).ToString("yyyy-MM-dd");
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("getEmployeeISAPExtension", "1024", "From Date : " + ex.Message, "Exception");

                }
            }

            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;



                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_department_extension_report
                                                                        ( 
                                                                            :p_company,
                                                                            :p_department,:p_fromdate,
                                                                            :p_todate,:p_emptype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.Company))
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = request.Company;
                        else
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.Department))
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = request.Department;
                        else
                            cmd.Parameters.AddWithValue("p_department", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(toDate))
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = toDate;
                        else
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EmpType))
                            cmd.Parameters.AddWithValue("p_emptype", DbType.String).Value = request.EmpType;
                        else
                            cmd.Parameters.AddWithValue("p_emptype", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtResult);
                        npgsqlConnection.Close();

                        response.responseCode = 1;
                        response.responseMessage = "SUCCESS";
                        response.responseJSON = JsonConvert.SerializeObject(dtResult);

                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getEmployeeISAPExtension", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }



            return response;

        }

        public ResponseClass checkFSTLReportAccess(checkFSTLReportaccessDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (!string.IsNullOrEmpty(request.EmployeeCode))
            {
                try
                {
                    DataTable FSTLreportaccessdata = new DataTable();
                    string pgsqlConnection = appSettings.Value.DbConnection;
                    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"SELECT * FROM FSTL_Report_AccessCheck
                                                                        ( 
                                                                            :empId,:rpttype
                                                                        )", npgsqlConnection))
                        {
                            npgsqlCommand.CommandType = CommandType.Text; 

                            if (!String.IsNullOrEmpty(request.EmployeeCode))
                                npgsqlCommand.Parameters.AddWithValue("empId", DbType.String).Value = request.EmployeeCode;
                            else
                                npgsqlCommand.Parameters.AddWithValue("empId", DbType.String).Value = string.Empty;

                            if (!String.IsNullOrEmpty(request.ReportType))
                                npgsqlCommand.Parameters.AddWithValue("rpttype", DbType.String).Value = request.ReportType;
                            else
                                npgsqlCommand.Parameters.AddWithValue("rpttype", DbType.String).Value = string.Empty;

                            npgsqlConnection.Open();
                            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                            dataAdapter.Fill(FSTLreportaccessdata);
                            if(FSTLreportaccessdata.Rows.Count>0)
                            {
                                response.responseCode = 1;
                                response.responseJSON = JsonConvert.SerializeObject("Have Access");
                                response.responseMessage = "Success";
                            }
                            else
                            {
                                response.responseCode = 1;
                                response.responseJSON = JsonConvert.SerializeObject("Not Have Access");
                                response.responseMessage = "You are not authorized to access this report";
                            }
                            
                            npgsqlConnection.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("FSTL Summary Report", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                } 
            }
            else
            {
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject("Not Have Access");
                response.responseMessage = "You are not authorized to access this report";
            }
            return response;
        }

        public ResponseClass getFSTLSummaryReport()
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable FSTLreportdata = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from FSTL_Report_count()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(FSTLreportdata);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(FSTLreportdata);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("FSTL Summary Report", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getFSTLReportDetails(getFSTLReportDetails request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable FSTLreportdata = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_FSTL_Report_Details
                                                                            (:p_Geo,
                                                                             :p_Type,
                                                                             :p_Status)", npgsqlConnection))
                    {
                        npgsqlCommand.CommandType = CommandType.Text;
                        if (!String.IsNullOrEmpty(request.geo))
                            npgsqlCommand.Parameters.AddWithValue("p_Geo", DbType.String).Value = request.geo;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_Geo", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.type))
                            npgsqlCommand.Parameters.AddWithValue("p_Type", DbType.String).Value = request.type;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_Type", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.status))
                            npgsqlCommand.Parameters.AddWithValue("p_Status", DbType.String).Value = request.status;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_Status", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(FSTLreportdata);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(FSTLreportdata);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("FSTL Summary Report Details", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getFSTLReportDetailsForExport()
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable FSTLreportdata = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    string selectQuery = "select * from #FSTL_Summary_Report# fsr";
                    selectQuery = selectQuery.Replace('#', '"');
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsqlConnection))
                    {
                        npgsqlCommand.CommandType = CommandType.Text;
                       
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(FSTLreportdata);
                        response.responseCode = 1;
                        response.responseJSON = JsonConvert.SerializeObject(FSTLreportdata);
                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("FSTL Summary Report Details", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
    }
}
