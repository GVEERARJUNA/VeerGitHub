﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.Reports
{
   public class AssessmentReportRequest
    {
        public string Geo { get; set; }
        public string Assessment { get; set; }
        public string Event { get; set; }
        public employeeEntity employee { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string Source { get; set; }
    }

    public class employeeEntity
    {
        public string EmployeeCode { get; set; }

        public string EmployeeRole { get; set; }
    }
}
