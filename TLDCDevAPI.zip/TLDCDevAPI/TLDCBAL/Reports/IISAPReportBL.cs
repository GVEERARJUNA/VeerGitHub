﻿using TLDCBAL.Common;
using TLDCBAL.WebSite;

namespace TLDCBAL.Reports
{
    public interface IISAPReportBL
    {
        ResponseClass GetISAPCompletionSummary(getISAPCompletionSummaryDTO request);
        ResponseClass GetISAPCompletionSummaryYearly(getISAPCompletionSummaryYearlyDTO request);
        ResponseClass GetISAPStatusReport(getISAPStatusReport request);

        ResponseClass GetFinalISAPStatusReport(getISAPStatusReport request);

        ResponseClass GetISAPCSummaryReport(getISAPStatusReport request);
        ResponseClass GetISAPCSummaryReportDetail(getISAPStatusReport request);

        ResponseClass getEmployeeISAPExtension(getISAPStatusReport request);
        ResponseClass getDepartmentISAPExtension(getISAPStatusReport request);
        ResponseClass checkFSTLReportAccess(checkFSTLReportaccessDTO request);
        ResponseClass getFSTLSummaryReport();
        public ResponseClass getFSTLReportDetails(getFSTLReportDetails request);
        public ResponseClass getFSTLReportDetailsForExport();

    }
}