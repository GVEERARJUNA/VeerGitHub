﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.Reports
{
    public class AssessmentReportBL : IAssessmentReportBL
    {
        private readonly IServiceConnect _serviceconnect;


        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;
        private IQualtricsDataBL _qualtricsBL;
        DBConnection AssessmentDBConnection;
        public AssessmentReportBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.QualtricsDbConnection);
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
            AssessmentDBConnection = new DBConnection(appSettings.Value.AssessmentDBConnection);
        }

        public ResponseClass GetDistinctGeo()
        {
            ResponseClass response = new ResponseClass();
            try
            {
                SqlParameter[] parameter = new SqlParameter[100];

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = AssessmentDBConnection.ExecuteDataSetInline("select distinct EmployeeCountry as Geo from Assessment_Summary");

                DataTable dtData = new DataTable();
                dtData.Columns.Add("displayfield");

                foreach (DataRow row in dsResult.Tables[0].Rows)
                {
                    DataRow _dtRow = dtData.NewRow();
                    _dtRow["displayfield"] = row["Geo"].ToString();
                    dtData.Rows.Add(_dtRow);
                }
                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("Assessment Summary Report", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetDistinctAssessment(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtAssessment = new DataTable();
            string teamMembers = string.Empty;
            string companies = string.Empty;
            string assessment = string.Empty;
            if (request.employee.EmployeeRole == "Team Lead")
            {
                getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                getteam.EmployeeCode = request.employee.EmployeeCode;
                var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {
                        teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                    }

                    teamMembers = teamMembers.TrimEnd(',');

                }

            }
            if (request.employee.EmployeeRole == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.employee.EmployeeCode);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companies = companies + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                    }

                    companies = companies.TrimEnd(',');

                }
            }
            if (request.employee.EmployeeRole == "Program Manager")
            {
                
                dtAssessment = getProgramManagerAssessmentDetails(request.employee.EmployeeCode);
                var list = dtAssessment.AsEnumerable().Select(r => r["ContentCode"].ToString());
                assessment = string.Join(",", list);
            }
            if (!string.IsNullOrEmpty(request.employee.EmployeeRole))
            {
                try
                {

                    SqlParameter[] parameter = {
                        new SqlParameter("@Geo", request.Geo),
                        new SqlParameter("@employeecode", request.employee.EmployeeCode),
                        new SqlParameter("@currentrole", request.employee.EmployeeRole),
                        new SqlParameter("@teammember", teamMembers),
                        new SqlParameter("@companycode", companies),
                        new SqlParameter("@assessment", assessment)
                        };

                    List<OutParameter> outParameters = new List<OutParameter>();
                    DataSet dsResult = new DataSet();
                    dsResult = AssessmentDBConnection.ExecuteDataSet("PRC_LoadAssessement", parameter, outParameters);

                    DataTable dtData = new DataTable();
                    dtData.Columns.Add("displayfield");

                    foreach (DataRow row in dsResult.Tables[0].Rows)
                    {
                        DataRow _dtRow = dtData.NewRow();
                        _dtRow["displayfield"] = row["assessment"].ToString();
                        dtData.Rows.Add(_dtRow);
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtData);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {

                    _serviceconnect.LogConnect("Assessment Summary Report", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            //else
            //{
            //    DataTable dtData = new DataTable();
            //    dtData.Columns.Add("displayfield");

            //    foreach (DataRow row in dtAssessment.Rows)
            //    {
            //        DataRow _dtRow = dtData.NewRow();
            //        _dtRow["displayfield"] = row["ContentText"].ToString();
            //        dtData.Rows.Add(_dtRow);
            //    }
            //    response.responseJSON = JsonConvert.SerializeObject(dtData);
            //    response.responseCode = 1;
            //    response.responseMessage = "Success";
            //}
                
            return response;
        }

        public ResponseClass GetDistinctEvent(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtAssessment = new DataTable();
            string teamMembers = string.Empty;
            string companies = string.Empty;
            string assessment = string.Empty;
            //if (request.employee.EmployeeRole == "Team Lead")
            //{
            //    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
            //    getteam.EmployeeCode = request.employee.EmployeeCode;
            //    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
            //    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
            //    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
            //    {
            //        foreach (DataRow exclude in QualtricTeamMembers.Rows)
            //        {
            //            teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
            //        }

            //        teamMembers = teamMembers.TrimEnd(',');

            //    }

            //}
            //if (request.employee.EmployeeRole == "Geo Admin")
            //{
            //    DataTable dtCompanies = new DataTable();
            //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.employee.EmployeeCode);
            //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
            //    {
            //        foreach (DataRow exclude in dtCompanies.Rows)
            //        {
            //            companies = companies + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
            //        }

            //        companies = companies.TrimEnd(',');

            //    }
            //}
            //if (request.employee.EmployeeRole == "Program Manager")
            //{

            //    dtAssessment = getProgramManagerEventDetails(request.employee.EmployeeCode);
            //    var list = dtAssessment.AsEnumerable().Select(r => r["ContentCode"].ToString());
            //    assessment = string.Join(",", list);
            //}
            if (!string.IsNullOrEmpty(request.employee.EmployeeRole))
            {
                try
                {

                    SqlParameter[] parameter = {
                        new SqlParameter("@Geo", request.Geo),
                        new SqlParameter("@employeecode", request.employee.EmployeeCode),
                        new SqlParameter("@currentrole", request.employee.EmployeeRole),
                        new SqlParameter("@teammember", teamMembers),
                        new SqlParameter("@companycode", companies),
                        new SqlParameter("@assessment", assessment)
                        };

                    List<OutParameter> outParameters = new List<OutParameter>();
                    DataSet dsResult = new DataSet();
                    dsResult = AssessmentDBConnection.ExecuteDataSet("PRC_LoadEvent", parameter, outParameters);

                    DataTable dtData = new DataTable();
                    dtData.Columns.Add("displayfield");

                    foreach (DataRow row in dsResult.Tables[0].Rows)
                    {
                        DataRow _dtRow = dtData.NewRow();
                        _dtRow["displayfield"] = row["assessment"].ToString();
                        dtData.Rows.Add(_dtRow);
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtData);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {

                    _serviceconnect.LogConnect("Assessment Summary Report", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            //else
            //{
            //    DataTable dtData = new DataTable();
            //    dtData.Columns.Add("displayfield");

            //    foreach (DataRow row in dtAssessment.Rows)
            //    {
            //        DataRow _dtRow = dtData.NewRow();
            //        _dtRow["displayfield"] = row["ContentText"].ToString();
            //        dtData.Rows.Add(_dtRow);
            //    }
            //    response.responseJSON = JsonConvert.SerializeObject(dtData);
            //    response.responseCode = 1;
            //    response.responseMessage = "Success";
            //}

            return response;
        }

        public ResponseClass GetAssessmentSummaryReportData(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            string teamMembers = string.Empty;
            string companies = string.Empty;
            if (request.employee.EmployeeRole == "Team Lead")
            {
                getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                getteam.EmployeeCode = request.employee.EmployeeCode;
                var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {
                        teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                    }

                    teamMembers = teamMembers.TrimEnd(',');

                }

            }
            if (request.employee.EmployeeRole == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.employee.EmployeeCode);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companies = companies + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                    }

                    companies = companies.TrimEnd(',');

                }
            }
            try
            {

                SqlParameter[] parameter = {
                new SqlParameter("@Geo", request.Geo),
                new SqlParameter("@Assessment", request.Assessment),
                 new SqlParameter("@employeecode", request.employee.EmployeeCode),
                 new SqlParameter("@currentrole", request.employee.EmployeeRole),
                 new SqlParameter("@teammember", teamMembers),
                 new SqlParameter("@companycode", companies)
                 };
                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = AssessmentDBConnection.ExecuteDataSet("PRC_AssessmentSummaryReport", parameter, outParameters);

                DataTable dtData = new DataTable();
                dtData.Columns.Add("EventType");
                dtData.Columns.Add("Eventname");
                dtData.Columns.Add("assessmentname");
                dtData.Columns.Add("EmployeeId");
                dtData.Columns.Add("EmployeeName");
                dtData.Columns.Add("EmployeeEmail");
                dtData.Columns.Add("EmployeeDept");
                dtData.Columns.Add("EmployeeLocation");
                dtData.Columns.Add("AssessmentStartDate");
                dtData.Columns.Add("AssessmentStartTime");
                dtData.Columns.Add("AssessmentEndDate");
                dtData.Columns.Add("AssessmentEndTime");
                dtData.Columns.Add("AverageTimeTaken");
                dtData.Columns.Add("Status");
                dtData.Columns.Add("TotalScore");
                dtData.Columns.Add("MarksObtained");
                dtData.Columns.Add("Percentage");
                dtData.Columns.Add("Result");

                foreach (DataRow row in dsResult.Tables[0].Rows)
                {
                    DataRow _dtRow = dtData.NewRow();
                    _dtRow["EventType"] = row["EventType"].ToString();
                    _dtRow["Eventname"] = row["Eventname"].ToString();
                    _dtRow["assessmentname"] = row["assessmentname"].ToString();
                    _dtRow["EmployeeId"] = row["EmployeeId"].ToString();
                    _dtRow["EmployeeName"] = row["EmployeeName"].ToString();
                    _dtRow["EmployeeEmail"] = row["EmployeeEmail"].ToString();
                    _dtRow["EmployeeDept"] = row["EmployeeDept"].ToString();
                    _dtRow["EmployeeLocation"] = row["EmployeeLocation"].ToString();
                    _dtRow["AssessmentStartDate"] = row["AssessmentStartDate"].ToString()=="" || row["AssessmentStartDate"].ToString()=="01-01-1900 12:00:00 AM" ?"": Convert.ToDateTime(row["AssessmentStartDate"]).ToString("yyyy-MMM-dd");
                    _dtRow["AssessmentStartTime"] = row["AssessmentStartDate"].ToString() == "" || row["AssessmentStartDate"].ToString() == "01-01-1900 12:00:00 AM" ? "": Convert.ToDateTime(row["AssessmentStartDate"]).ToString("hh:mm:ss tt");
                    _dtRow["AssessmentEndDate"] = row["AssessmentEndDate"].ToString() == "" || row["AssessmentEndDate"].ToString() == "01-01-1900 12:00:00 AM" ? "":Convert.ToDateTime(row["AssessmentEndDate"]).ToString("yyyy-MMM-dd");
                    _dtRow["AssessmentEndTime"] = row["AssessmentEndDate"].ToString() == "" || row["AssessmentEndDate"].ToString() == "01-01-1900 12:00:00 AM" ?"": Convert.ToDateTime(row["AssessmentEndDate"]).ToString("hh:mm:ss tt");
                    _dtRow["AverageTimeTaken"] = row["AverageTimeTaken"].ToString();
                    _dtRow["Status"] = row["Status"].ToString();
                    _dtRow["TotalScore"] = row["TotalScore"].ToString();
                    _dtRow["MarksObtained"] = row["MarksObtained"].ToString();
                    _dtRow["Percentage"] = row["Percentage"].ToString();
                    _dtRow["Result"] = row["Result"].ToString();
                    dtData.Rows.Add(_dtRow);
                }
                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("Assessment Summary Report", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable getProgramManagerAssessmentDetails(string EmployeeCode)
        {
            DataTable trainingGroup = new DataTable();

            try
            {
                
                string selectQuery = string.Empty;

                selectQuery = "select distinct A.#ContentCode#,A.#ContentText# from #EventContent# A inner join #EventMaster# B on A.#EventCode#=B.#EventCode# where B.#EventType#='Assessment' and B.#InsertedBy#='" + EmployeeCode + "' and B.#IsPublished#=1";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
               
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEntityNames", "1024", ex.Message, "Exception");
               
            }

            return trainingGroup;
        }

        public DataTable getProgramManagerEventDetails(string EmployeeCode)
        {
            DataTable trainingGroup = new DataTable();

            try
            {

                string selectQuery = string.Empty;

                selectQuery = "select distinct A.#EventName# as ContentCode,A.#EventName# from #EventContent# A  where B.#EventType#='Assessment' and B.#InsertedBy#='" + EmployeeCode + "' and B.#IsPublished#=1";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getProgramManagerEventDetails", "1024", ex.Message, "Exception");

            }

            return trainingGroup;
        }

        public ResponseClass GetQuickAssessmentDashboardCount(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            string teamMembers = string.Empty;
            string companies = string.Empty;
            if (request.employee.EmployeeRole == "Team Lead")
            {
                getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                getteam.EmployeeCode = request.employee.EmployeeCode;
                var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {
                        teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                    }

                    teamMembers = teamMembers.TrimEnd(',');

                }

            }
            if (request.employee.EmployeeRole == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.employee.EmployeeCode);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companies = companies + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                    }

                    companies = companies.TrimEnd(',');

                }
            }
            try
            {

                SqlParameter[] parameter = {
                new SqlParameter("@Geo", request.Geo),
                new SqlParameter("@Assessment", request.Assessment),
                 new SqlParameter("@employeecode", request.employee.EmployeeCode),
                 new SqlParameter("@currentrole", request.employee.EmployeeRole),
                 new SqlParameter("@teammember", teamMembers),
                 new SqlParameter("@companycode", companies),
                 new SqlParameter("@EventName", request.Event)
                 };
                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = AssessmentDBConnection.ExecuteDataSet("RPT_HGSHall_GetQuickAssessmentReport", parameter, outParameters);

                if (dsResult.Tables.Count>0)
                {
                    dsResult.Tables[0].TableName = "PercentageCount";
                    dsResult.Tables[1].TableName = "PercentageWiseCount";
                }
                
                response.responseJSON = JsonConvert.SerializeObject(dsResult);
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetQuickAssessmentDashboardCount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetQuickAssessmentDashboardCountDetail(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            string teamMembers = string.Empty;
            string companies = string.Empty;
            //if (request.employee.EmployeeRole == "Team Lead")
            //{
            //    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
            //    getteam.EmployeeCode = request.employee.EmployeeCode;
            //    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
            //    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
            //    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
            //    {
            //        foreach (DataRow exclude in QualtricTeamMembers.Rows)
            //        {
            //            teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
            //        }

            //        teamMembers = teamMembers.TrimEnd(',');

            //    }

            //}
            //if (request.employee.EmployeeRole == "Geo Admin")
            //{
            //    DataTable dtCompanies = new DataTable();
            //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.employee.EmployeeCode);
            //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
            //    {
            //        foreach (DataRow exclude in dtCompanies.Rows)
            //        {
            //            companies = companies + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
            //        }

            //        companies = companies.TrimEnd(',');

            //    }
            //}
            try
            {

                SqlParameter[] parameter = {
                new SqlParameter("@Geo", request.Geo),
                new SqlParameter("@Assessment", request.Assessment),
                 new SqlParameter("@employeecode", request.employee.EmployeeCode),
                 new SqlParameter("@currentrole", request.employee.EmployeeRole),
                 new SqlParameter("@teammember", teamMembers),
                 new SqlParameter("@companycode", companies),
                 new SqlParameter("@EventName", request.Event),
                 new SqlParameter("@PageNumber", request.PageNumber),
                new SqlParameter("@RowsOfPage", request.RowsOfPage),
                new SqlParameter("@Source",request.Source)
                 };
                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = AssessmentDBConnection.ExecuteDataSet("RPT_HGSHall_GetQuickAssessmentReportDetail", parameter, outParameters);

                //if (dsResult.Tables.Count > 0)
                //{
                //    dsResult.Tables[0].TableName = "PercentageCount";
                //    dsResult.Tables[1].TableName = "PercentageWiseCount";
                //}
                if (dsResult.Tables.Count > 0)
                {

                    if (request.Source=="Grid")
                    {
                        StringBuilder emailBodyText = new StringBuilder();
                        emailBodyText.Append("<thead>");
                        emailBodyText.Append("<tr>");
                        emailBodyText.Append("<th class='text-center' width='40'>#</th>");
                        emailBodyText.Append("<th>Emp Id</th>");
                        emailBodyText.Append("<th>Emp Name</th>");
                        emailBodyText.Append("<th>Emp Dept</th>");
                        emailBodyText.Append("<th>Emp Geo</th>");
                        emailBodyText.Append("<th width='200'>Score</th>");
                        emailBodyText.Append("<th>Started On</th>");
                        emailBodyText.Append("<th>Finished On</th>");
                        emailBodyText.Append("<th>Time</th>");
                        DataTable dtcolumncount = new DataTable();

                        dtcolumncount = dsResult.Tables[1];
                        if (dtcolumncount != null && dtcolumncount.Rows.Count > 0)
                        {
                            int assetno = 1;
                            foreach (DataRow item in dtcolumncount.Rows)
                            {
                                string cctext = string.Empty;
                                //cctext = Convert.ToString(item["ContentText"]);
                                emailBodyText.Append("<th class='text-center' style='width:50px;'><div>" + assetno + "</div>" + string.Format("{0:0.##}", Convert.ToString(item["averagecorrect"])) + "%</th>");

                                assetno = assetno + 1;

                            }
                        }

                        //  emailBodyText.Append("<th class='text-center'>Overall Progress</th>");
                        emailBodyText.Append("</tr>");
                        emailBodyText.Append("</thead>");

                        emailBodyText.Append("<tbody>");
                        int rowno = 1;
                        DataTable dtresult = new DataTable();
                        dtresult = dsResult.Tables[2];
                        foreach (DataRow item in dsResult.Tables[0].Rows)
                        {
                            int progress = Convert.ToInt32(item["employeepercentage"]);
                            string progressbar = string.Empty;

                            if (progress > 0)
                            {
                                string texttoshowintitle=progress + "% (" +  Convert.ToInt32(item["employeemark"]) + "/" + Convert.ToInt32(item["assessmentmark"]) + ")";
                                progressbar = "<div class='progress border'><div class='progress-bar assesment-progress progress-bar-striped progress-bar-animated' role ='progressbar' title='" + texttoshowintitle + "'  style='width: " + progress + "%;aria-valuenow=" + progress + " aria-valuemin='0' aria-valuemax='100'><span><i>" + progress + "%</i> &nbsp;(" + Convert.ToInt32(item["employeemark"]) + "/" + Convert.ToInt32(item["assessmentmark"]) + ")</span> </div></div >";
                            }
                            else
                            {
                                progressbar = "<div class='progress border'><div class='progress-bar assesment-progress progress-bar-striped progress-bar-animated' role ='progressbar' style='width: " + progress + "%;aria-valuenow=" + progress + " aria-valuemin='0' aria-valuemax='100'><span><i>" + progress + " %</i></span> </div></div >";
                            }
                            string empcode = Convert.ToString(item["employeeid"]);
                            emailBodyText.Append("<tr>");
                            emailBodyText.Append("<td class='text-center'>" + rowno + "</td>");

                            emailBodyText.Append("<td>" + item["employeeid"] + "</td>");
                            emailBodyText.Append("<td>" + item["employeename"] + "</td>");
                            emailBodyText.Append("<td>" + item["employeedepartment"] + "</td>");
                            emailBodyText.Append("<td>" + item["employeegeo"] + "</td>");
                            emailBodyText.Append("<td class='text-center'>" + progressbar + "</td>");
                            emailBodyText.Append("<td>" + item["startedtime"] + "</td>");
                            emailBodyText.Append("<td>" + item["endtime"] + "</td>");
                            emailBodyText.Append("<td>" + item["assessmenttimetaken"] + "</td>");


                            if (dtresult != null && dtresult.Rows.Count > 0)
                            {
                                if (dtcolumncount != null && dtcolumncount.Rows.Count > 0)
                                {
                                    foreach (DataRow asset in dtcolumncount.Rows)
                                    {
                                        if (Convert.ToString(asset["QuestionType"]) != "Free Text")
                                        {
                                            DataRow[] result = dtresult.Select("EmployeeId='" + empcode + "' and QuestionId=" + Convert.ToString(asset["QuestionId"]) + "");
                                            if (result != null && result.Length > 0)
                                            {
                                                foreach (DataRow row in result)
                                                {
                                                    string popuptext = string.Empty;
                                                    //popuptext = "<div class='pop-table'><div class='pop-table-row'><div class='pop-table-cell wid90'>Answer Given</div><div class='pop-table-cell'>: Delhi</div></div><div class='pop-table-row table-success'><div class='pop-table-cell'>Correct Answer</div><div class='pop-table-cell'> : <span class='correct'>Delhi</span></div></div><div class='pop-table-row'><div class='pop-table-cell'>Question Status</div><div class='pop-table-cell'> : <span class='correct'>Correct</span></div></div></div>";
                                                    popuptext = "<div class='pop-table'></div>";
                                                    string popup = string.Empty;

                                                    // popup= "<i class='fa-solid fa-circle-check font-18 text-success' data-bs-toggle='popover' data-bs-placement='right' data-bs-custom-class='question-popover' data-bs-title='What is Capital of India?' data-bs-content='<div class='pop-table'><div class='pop-table-row'></div></div>'</i>";
                                                    //popup = popup + "<div class='pop-table-row'>";
                                                    //popup = popup + "<div class='pop-table-cell wid90'>Answer Given</div>";
                                                    //popup = popup + "<div class='pop-table-cell'>: Delhi</div>";
                                                    //popup = popup + "</div>";
                                                    //popup = popup + "<div class='pop-table-row table-success'>";
                                                    //popup = popup + "<div class='pop-table-cell'>Correct Answer</div>";
                                                    //popup = popup + "<div class='pop-table-cell'> : <span class='correct'>Delhi</span> </div>";
                                                    //popup = popup + "</div>";
                                                    //popup = popup + "<div class='pop-table-row'>";
                                                    //popup = popup + "<div class='pop-table-cell'>Question Status</div>";
                                                    //popup = popup + "<div class='pop-table-cell'> : <span class='correct'>Correct</span></div>";
                                                    //popup = popup + "</div>";
                                                    //popup = popup + "</div>'></i>";
                                                    int acknowledgedstatus = 0;
                                                    acknowledgedstatus = Convert.ToInt32(row["ResponseStatus"]);
                                                    string dependencytext = string.Empty;

                                                    dependencytext = "<ul class='PopULlist'>";
                                                    dependencytext = dependencytext + "<li>Deepak Rohilla</li>";
                                                    dependencytext = dependencytext + "</ul>";
                                                    if (acknowledgedstatus == 1)
                                                    {
                                                        emailBodyText.Append("<td class='text-center'><div class='fa-solid fa-circle-check font-18 text-success' data-bs-toggle='popover' data-bs-placement='left' data-bs-custom-class='assisment-popover' data-bs-title='" + row["Question"] + "' data-bs-content='" + row["popuptext"] + "'></div></td>");
                                                    }
                                                    else
                                                    {
                                                        emailBodyText.Append("<td class='text-center'><div class='fa-solid fa-circle-xmark font-18 text-danger' data-bs-toggle='popover' data-bs-placement='left' data-bs-custom-class='assisment-popover' data-bs-title='" + row["Question"] + "' data-bs-content='" + row["popuptext"] + "'></div></td>");
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                emailBodyText.Append("<td class='text-center'>NS</td>");
                                            }
                                        }
                                        else
                                        {
                                            emailBodyText.Append("<td class='text-center'>NS</td>");
                                        }

                                    }
                                }


                            }

                            //emailBodyText.Append("<td class='text-center'>" + progressbar + "</td>");
                            emailBodyText.Append("</tr>");

                            rowno = rowno + 1;


                        }
                        emailBodyText.Append("</tbody>");
                        response.responseJSON = emailBodyText.ToString();
                    }
                    else
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                        //DataTable dtcolumncount = new DataTable();
                        //dtcolumncount = dsResult.Tables[1];
                        //if (dtcolumncount != null && dtcolumncount.Rows.Count > 0)
                        //{
                        //    int assetno = 1;
                        //    foreach (DataRow item in dtcolumncount.Rows)
                        //    {
                        //        dsResult.Tables[0].Columns.Add(Convert.ToString(item["Question"]));


                        //        string cctext = string.Empty;
                        //        //cctext = Convert.ToString(item["ContentText"]);
                        //       // emailBodyText.Append("<th class='text-center' style='width:50px;'><div>" + assetno + "</div>" + string.Format("{0:0.##}", Convert.ToString(item["averagecorrect"])) + "%</th>");

                        //        assetno = assetno + 1;

                        //    }
                        //}

                        //foreach (DataRow item in dsResult.Tables[0].Rows)
                        //{
                        //    //int rowno = 1;
                        //    DataTable dtresult = new DataTable();
                        //    dtresult = dsResult.Tables[2];
                        //    string empcode = Convert.ToString(item["employeeid"]);
                        //    if (dtresult != null && dtresult.Rows.Count > 0)
                        //    {
                        //        if (dtcolumncount != null && dtcolumncount.Rows.Count > 0)
                        //        {
                        //            foreach (DataRow asset in dtcolumncount.Rows)
                        //            {
                        //                if (Convert.ToString(asset["QuestionType"]) != "Free Text")
                        //                {
                        //                    DataRow[] result = dtresult.Select("EmployeeId='" + empcode + "' and QuestionId=" + Convert.ToString(asset["QuestionId"]) + "");
                        //                    if (result != null && result.Length > 0)
                        //                    {
                        //                        foreach (DataRow row in result)
                        //                        {
                        //                            string answer = string.Empty;
                        //                            if (Convert.ToInt32(row["ResponseStatus"])==1)
                        //                            {
                        //                                answer = "Correct";
                        //                            }
                        //                            else
                        //                            {
                        //                                answer = "InCorrect";
                        //                            }

                        //                            item[Convert.ToString(asset["Question"])] = answer;


                        //                        }
                        //                    }
                        //                    else
                        //                    {
                        //                        item[Convert.ToString(asset["Question"])] = "NA";
                        //                        // emailBodyText.Append("<td class='text-center'></td>");
                        //                    }
                        //                }
                        //                else
                        //                {
                        //                    item[Convert.ToString(asset["Question"])] = "NA";
                        //                    //emailBodyText.Append("<td class='text-center'></td>");
                        //                }

                        //            }
                        //        }


                        //    }

                        //}



                    }



                }

                
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetQuickAssessmentDashboardCount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetDistinctAssessmentDetail(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtAssessment = new DataTable();
            string teamMembers = string.Empty;
            string companies = string.Empty;
            string assessment = string.Empty;
            if (request.employee.EmployeeRole == "Team Lead")
            {
                getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                getteam.EmployeeCode = request.employee.EmployeeCode;
                var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {
                        teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                    }

                    teamMembers = teamMembers.TrimEnd(',');

                }

            }
            if (request.employee.EmployeeRole == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.employee.EmployeeCode);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companies = companies + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                    }

                    companies = companies.TrimEnd(',');

                }
            }
            if (request.employee.EmployeeRole == "Program Manager")
            {

                dtAssessment = getProgramManagerAssessmentDetails(request.employee.EmployeeCode);
                var list = dtAssessment.AsEnumerable().Select(r => r["ContentCode"].ToString());
                assessment = string.Join(",", list);
            }
            if (!string.IsNullOrEmpty(request.employee.EmployeeRole))
            {
                try
                {

                    SqlParameter[] parameter = {
                        new SqlParameter("@Geo", request.Geo),
                        new SqlParameter("@employeecode", request.employee.EmployeeCode),
                        new SqlParameter("@currentrole", request.employee.EmployeeRole),
                        new SqlParameter("@teammember", teamMembers),
                        new SqlParameter("@companycode", companies),
                        new SqlParameter("@assessment", assessment)
                        };

                    List<OutParameter> outParameters = new List<OutParameter>();
                    DataSet dsResult = new DataSet();
                    dsResult = AssessmentDBConnection.ExecuteDataSet("PRC_LoadAssessementDetail", parameter, outParameters);

                    DataTable dtData = new DataTable();
                    dtData.Columns.Add("displayfield");

                    foreach (DataRow row in dsResult.Tables[0].Rows)
                    {
                        DataRow _dtRow = dtData.NewRow();
                        _dtRow["displayfield"] = row["assessment"].ToString();
                        dtData.Rows.Add(_dtRow);
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtData);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {

                    _serviceconnect.LogConnect("Assessment Summary Report", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            
            return response;
        }
    }
}
