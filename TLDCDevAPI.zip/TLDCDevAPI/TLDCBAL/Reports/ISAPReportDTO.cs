﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.Reports
{
    public class getISAPCompletionSummaryDTO
    {
        public string CurrentUser { get; set; }
        public string UserName { get; set; }
        public string CurrentRole { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }

    public class getISAPStatusReport
    {
        public string currentRole { get; set; }
        public string currentEmployee { get; set; }
        public string Company { get; set; }
        public string Department { get; set; }
        public string DOJ { get; set; }
        public string DateRange { get; set; }
        public string EmpType { get; set; }
        public string EmployeeID { get; set; }
        public string DepartmentCode { get; set; }

        public string SurveyType { get; set; }
    }

    public class getISAPCompletionSummaryYearlyDTO
    {
        public string EmployeeId { get; set; }
        public string EmployeeRole { get; set; }
        public string Year { get; set; }
        public string CurrentUser { get; set; }
    }

    public class getResponseISAPStatusReportDTO
    {
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string DOJ { get; set; }
        public string Desg { get; set; }
        public string Dept { get; set; }
        public string SubPrecess { get; set; }
        public string ModuleNeedToComplete { get; set; }
        public string ModuleComplete { get; set; }
        public string AssesstmentStartDate { get; set; }
        public string AssesstmentEndDate { get; set; }
        public string AssesstmentStatus { get; set; }
        public string AttemptScore1 { get; set; }
        public string AttemptScore2 { get; set; }
        public string AttemptScore3 { get; set; }
        public string AttemptScore4 { get; set; }
        public string AttemptNo1 { get; set; }
        public string AttemptNo2 { get; set; }
        public string AttemptNo3 { get; set; }
        public string AttemptNo4 { get; set; }
        public string PRReason { get; set; }
        public string Relaunch { get; set; }
    }
    public class checkFSTLReportaccessDTO
    {
        public string EmployeeCode { get; set; }

        public string ReportType { get; set; }
    }
    public class getFSTLReportDetails
    {
        public string geo { get; set; }
        public string type { get; set; }
        public string status { get; set; }
    }
    }
