﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCBAL.WebSite;
using TLDCDAL;

namespace TLDCBAL.UserManagement
{
    public class UserManagementBL : IUserManagementBL
    {
        private readonly IServiceConnect _serviceconnect;
        private readonly IOptions<IDBConnection> appSettings;
        private IQualtricsDataBL _qualtricsBL;

        DBConnection dBConnection;
        DBConnection tpadBConnection;
        DBConnection assessmentadBConnection;

        public UserManagementBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect,IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.QualtricsDbConnection);
            tpadBConnection = new DBConnection(appSettings.Value.TPADBConnection);
            assessmentadBConnection = new DBConnection(appSettings.Value.AssessmentDBConnection);
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
        }

        public ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_authenticate_user
                                                                        ( 
                                                                            :p_username
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(loginRequestBO.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = loginRequestBO.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        
                        //response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        if (dtEmployees!=null && dtEmployees.Rows.Count>0)
                        {
                            //if (Convert.ToInt32())
                            //{

                            //}

                            int checkActiveSession = 0;

                            checkActiveSession = Convert.ToInt32(dtEmployees.Rows[0]["checkactivesession"]);

                            if (checkActiveSession==1)
                            {
                                response.responseCode = 0;
                                response.responseMessage = "User already login.Please log out from all other sessions!";
                                response.recordCount = 99;
                                return response;
                            }

                            //dtEmployees.Columns.Add("Photo");
                            //dtEmployees.Rows[0]["Photo"] = "https://hgsconnect.teamhgs.com/PurchaseToOrder/assets/images/no_image.jpg";
                            DataTable dtRoles = new DataTable();
                            string FirstName = string.Empty;
                            string LastName = string.Empty;
                            string RoleName = string.Empty;
                            string doj = string.Empty;
                            string designation = string.Empty;
                            FirstName = Convert.ToString(dtEmployees.Rows[0]["FirstName"]);
                            LastName = Convert.ToString(dtEmployees.Rows[0]["LastName"]);
                            RoleName = Convert.ToString(dtEmployees.Rows[0]["RoleName"]);
                            doj = Convert.ToString(dtEmployees.Rows[0]["DOJ"]);
                            designation = Convert.ToString(dtEmployees.Rows[0]["Designation"]);
                            dtRoles = CheckLoginPostTLDC(loginRequestBO.UserName, FirstName, LastName, RoleName, doj, designation);
                            response.responseJSONSecondary = JsonConvert.SerializeObject(dtRoles);

                            response.responseCode = 1;
                            response.responseMessage = "Success";
                        }
                        else
                        {
                            response.responseCode = 0;
                            response.responseMessage ="Invalid user!";
                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

              //  response.responseCode = 1;
              //  response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("CheckUserLogin", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        //public ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO)
        //{
        //    ResponseClass response = new ResponseClass();
        //    try
        //    {

        //        if (loginRequestBO == null)
        //        {
        //            response.responseCode = 0;
        //            response.responseMessage = "loginRequestBO required";
        //            return response;
        //        }


        //        if (string.IsNullOrEmpty(loginRequestBO.UserName))
        //        {
        //            response.responseCode = 0;
        //            response.responseMessage = "loginRequestBO.UserName required!";
        //            return response;
        //        }


        //        SqlParameter[] parameter = {
        //        new SqlParameter("@UserName", loginRequestBO.UserName),

        //         new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
        //         new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
        //    };

        //        List<OutParameter> outParameters = new List<OutParameter>();
        //        DataSet dsResult = new DataSet();
        //        dsResult = dBConnection.ExecuteDataSet("TLDC_user_authentication", parameter, outParameters);

        //        OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
        //        OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

        //        if (resultrcode.ParameterValue == "1")
        //        {
        //            if (dsResult != null && dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0)
        //            {
        //                dsResult.Tables[0].Columns.Add("Photo");
        //                dsResult.Tables[0].Rows[0]["Photo"] = "https://hgsconnect.teamhgs.com/PurchaseToOrder/assets/images/no_image.jpg";

        //                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
        //                try
        //                {
        //                    DataTable dtRoles = new DataTable();
        //                    string FirstName = string.Empty;
        //                    string LastName = string.Empty;
        //                    string RoleName = string.Empty;
        //                    string doj = string.Empty;
        //                    string designation = string.Empty;
        //                    FirstName = Convert.ToString(dsResult.Tables[0].Rows[0]["FirstName"]);
        //                    LastName = Convert.ToString(dsResult.Tables[0].Rows[0]["LastName"]);
        //                    RoleName = Convert.ToString(dsResult.Tables[0].Rows[0]["RoleName"]);
        //                    doj = Convert.ToString(dsResult.Tables[0].Rows[0]["DOJ"]);
        //                    designation = Convert.ToString(dsResult.Tables[0].Rows[0]["Designation"]);
        //                    dtRoles = CheckLoginPostTLDC(loginRequestBO.UserName, FirstName, LastName, RoleName, doj, designation);
        //                    response.responseJSONSecondary = JsonConvert.SerializeObject(dtRoles);
        //                }
        //                catch (Exception)
        //                {


        //                }



        //            }

        //        }

        //        response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
        //        response.responseMessage = resultMessage.ParameterValue;
        //    }
        //    catch (Exception ex)
        //    {

        //        _serviceconnect.LogConnect("CheckUserLogin", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }
        //    return response;
        //}

        //public ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO)
        //{
        //    ResponseClass response = new ResponseClass();
        //    try
        //    {

        //        if (loginRequestBO == null)
        //        {
        //            response.responseCode = 0;
        //            response.responseMessage = "loginRequestBO required";
        //            return response;
        //        }


        //        if (string.IsNullOrEmpty(loginRequestBO.UserName))
        //        {
        //            response.responseCode = 0;
        //            response.responseMessage = "loginRequestBO.UserName required!";
        //            return response;
        //        }


        //        SqlParameter[] parameter = {
        //        new SqlParameter("@UserName", loginRequestBO.UserName),

        //         new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
        //         new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
        //    };

        //        List<OutParameter> outParameters = new List<OutParameter>();
        //        DataSet dsResult = new DataSet();
        //        dsResult = dBConnection.ExecuteDataSet("TLDC_user_authentication", parameter, outParameters);

        //        OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
        //        OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

        //        if (resultrcode.ParameterValue == "1")
        //        {
        //            if (dsResult != null && dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0)
        //            {
        //                dsResult.Tables[0].Columns.Add("Photo");
        //                dsResult.Tables[0].Rows[0]["Photo"] = "https://hgsconnect.teamhgs.com/PurchaseToOrder/assets/images/no_image.jpg";

        //                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
        //                try
        //                {
        //                    DataTable dtRoles = new DataTable();
        //                    string FirstName = string.Empty;
        //                    string LastName = string.Empty;
        //                    string RoleName = string.Empty;
        //                    string doj = string.Empty;
        //                    string designation = string.Empty;
        //                    FirstName = Convert.ToString(dsResult.Tables[0].Rows[0]["FirstName"]);
        //                    LastName = Convert.ToString(dsResult.Tables[0].Rows[0]["LastName"]);
        //                    RoleName = Convert.ToString(dsResult.Tables[0].Rows[0]["RoleName"]);
        //                    doj = Convert.ToString(dsResult.Tables[0].Rows[0]["DOJ"]);
        //                    designation = Convert.ToString(dsResult.Tables[0].Rows[0]["Designation"]);
        //                    dtRoles = CheckLoginPostTLDC(loginRequestBO.UserName, FirstName, LastName, RoleName, doj, designation);
        //                    response.responseJSONSecondary = JsonConvert.SerializeObject(dtRoles);
        //                }
        //                catch (Exception)
        //                {


        //                }



        //            }

        //        }

        //        response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
        //        response.responseMessage = resultMessage.ParameterValue;
        //    }
        //    catch (Exception ex)
        //    {

        //        _serviceconnect.LogConnect("CheckUserLogin", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }
        //    return response;
        //}

        //public ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO)
        //{
        //    ResponseClass response = new ResponseClass();
        //    try
        //    {
        //        //var app = new PowerPoint.Application();
        //        //var presentation = app.Presentations.Open("https://hgsconnect-hgs.s3.ap-south-1.amazonaws.com/hgsuat/tldc-scorm/18082023025939746UK P2O to SAP edit option.pptx", MsoTriState.msoTrue, MsoTriState.msoTrue, MsoTriState.msoFalse);
        //        //var jpgName = Path.GetFileNameWithoutExtension(sourceFileName) + ".pdf";
        //        //var uploads = Path.Combine(_hostingEnvironment.WebRootPath, "assets\\documents\\ManageCourse\\");
        //        //var filePath = Path.Combine(uploads, jpgName);
        //        //presentation.SaveCopyAs(filePath, PowerPoint.PpSaveAsFileType.ppSaveAsPDF, MsoTriState.msoTrue);
        //        //return filePath;

        //        if (loginRequestBO == null)
        //    {
        //        response.responseCode = 0;
        //        response.responseMessage = "loginRequestBO required";
        //        return response;
        //    }


        //    if (string.IsNullOrEmpty(loginRequestBO.UserName))
        //    {
        //        response.responseCode = 0;
        //        response.responseMessage = "loginRequestBO.UserName required!";
        //        return response;
        //    }


        //    SqlParameter[] parameter = {
        //        new SqlParameter("@UserName", loginRequestBO.UserName),

        //         new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
        //         new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
        //    };

        //    List<OutParameter> outParameters = new List<OutParameter>();
        //    DataSet dsResult = new DataSet();
        //    dsResult = dBConnection.ExecuteDataSet("TLDC_user_authentication", parameter, outParameters);

        //    OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
        //    OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

        //    if (resultrcode.ParameterValue=="1")
        //    {
        //        if (dsResult != null && dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0)
        //        {
        //            dsResult.Tables[0].Columns.Add("Photo");
        //                dsResult.Tables[0].Rows[0]["Photo"] = "https://hgsconnect.teamhgs.com/PurchaseToOrder/assets/images/no_image.jpg";
        //                //string photo = GetEmployeePhoto(Convert.ToString(dsResult.Tables[0].Rows[0]["EmployeeId"]), Convert.ToString(dsResult.Tables[0].Rows[0]["CompanyCode"]));
        //                //bool fileExist = false;
        //                //fileExist = CheckFileExist(photo);
        //                //if (fileExist)
        //                //{
        //                //    dsResult.Tables[0].Rows[0]["Photo"] = photo;

        //                //}
        //                //else
        //                //{
        //                //    dsResult.Tables[0].Rows[0]["Photo"] = "https://hgsconnect.teamhgs.com/PurchaseToOrder/assets/images/no_image.jpg";
        //                //}
        //                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
        //            try
        //            {
        //                DataTable dtRoles = new DataTable();
        //                string FirstName = string.Empty;
        //                string LastName = string.Empty;
        //                string RoleName = string.Empty;
        //                string doj = string.Empty;
        //                string designation = string.Empty;
        //                FirstName = Convert.ToString(dsResult.Tables[0].Rows[0]["FirstName"]);
        //                LastName = Convert.ToString(dsResult.Tables[0].Rows[0]["LastName"]);
        //                RoleName = Convert.ToString(dsResult.Tables[0].Rows[0]["RoleName"]);
        //                doj = Convert.ToString(dsResult.Tables[0].Rows[0]["DOJ"]);
        //                designation = Convert.ToString(dsResult.Tables[0].Rows[0]["Designation"]);
        //                dtRoles =CheckLoginPostTLDC(loginRequestBO.UserName, FirstName, LastName, RoleName, doj, designation);
        //                response.responseJSONSecondary = JsonConvert.SerializeObject(dtRoles);
        //            }
        //            catch (Exception)
        //            {


        //            }



        //        }

        //    }

        //      response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
        //      response.responseMessage = resultMessage.ParameterValue;
        //    }
        //    catch (Exception ex)
        //    {

        //        _serviceconnect.LogConnect("CheckUserLogin", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }
        //    return response;
        //}

        private string GetEmployeePhoto(string employeeId, string companyCode)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(employeeId) || string.IsNullOrWhiteSpace(companyCode))
                {
                    return string.Empty;
                }


                var employeeProfilePhotoUrl = appSettings.Value.EmployeePhoto;
                if (string.IsNullOrWhiteSpace(employeeProfilePhotoUrl))
                {
                    return string.Empty;
                }

                return employeeProfilePhotoUrl
                        .Replace("{CompanyCode}", companyCode)
                        .Replace("{EmployeeId}", employeeId);
            }
            catch
            {

                return string.Empty;
            }
        }
        private bool CheckFileExist(string fileName)
        {
            try
            {
                HttpWebRequest httpReq = (HttpWebRequest)WebRequest.Create(fileName);

                HttpWebResponse httpRes = (HttpWebResponse)httpReq.GetResponse(); // Error 404 right here,

                if (httpRes.StatusCode == HttpStatusCode.NotFound)
                {
                    return false;
                }

                // Close the response.
                httpRes.Close();
                return true;
            }
            catch (Exception)
            {

                return false;
            }


        }

        public DataTable CheckLoginPostTLDC(string UserName,string FirstName,string LastName,
            string RoleName,string DOJ,string Designation)
        {
           // _serviceconnect.LogConnect("ADDUSERINTLDC", "1024", "Exception", "Exception");
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string dbDOJ = string.Empty;
            if (!string.IsNullOrEmpty(DOJ))
            {
                try
                {
                    dbDOJ = Convert.ToDateTime(DOJ).ToString("yyyy-MM-dd");

                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("ADDUSERINTLDC", "1024", "DOJ : " + ex.Message, "Exception");
                   
                }
            }
            try
            {
                
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_check_user
                                                                    ( 
                                                                        :p_username,
                                                                        :p_firstname,
                                                                        :p_lastname,
                                                                        :p_rolename,
                                                                        :p_doj,
                                                                        :p_designation
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(FirstName))
                            cmd.Parameters.AddWithValue("p_firstname", DbType.String).Value = FirstName;
                        else
                            cmd.Parameters.AddWithValue("p_firstname", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(LastName))
                            cmd.Parameters.AddWithValue("p_lastname", DbType.String).Value = LastName;
                        else
                            cmd.Parameters.AddWithValue("p_lastname", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(RoleName))
                            cmd.Parameters.AddWithValue("p_rolename", DbType.String).Value = RoleName;
                        else
                            cmd.Parameters.AddWithValue("p_rolename", DbType.String).Value = DBNull.Value;
                        cmd.Parameters.AddWithValue("p_doj", DbType.String).Value = dbDOJ;
                        if (!String.IsNullOrEmpty(Designation))
                            cmd.Parameters.AddWithValue("p_designation", DbType.String).Value = Designation;
                        else
                            cmd.Parameters.AddWithValue("p_designation", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ADDUSERINTLDC", "1024",ex.Message, "Exception");

            }
            

            return dtEmployees;
        }

        public ResponseClass getUserRoles(UserRoleRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {


                if (request == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "request required";
                    return response;
                }


                if (string.IsNullOrEmpty(request.EmployeeCode))
                {
                    response.responseCode = 0;
                    response.responseMessage = "request.EmployeeCode required!";
                    return response;
                }

                string sqlQuery = string.Empty;
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                sqlQuery = "select #MappingID#,#EmployeeID#,#RoleMasterName# from #UserRoleMap# where #EmployeeID#='" + request.EmployeeCode + "'";

                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getUserRoles", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass deleteRole(UserRoleRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request is required";
                return response;
            }
            //if (string.IsNullOrEmpty(request.EmployeeCode))
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "EmployeeCode required";
            //    return response;
            //}
            //if (string.IsNullOrEmpty(request.EmployeeRole))
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "EmployeeRole required";
            //    return response;
            //}
            //if (string.IsNullOrEmpty(request.Action))
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "Action required";
            //    return response;
            //}
            if (request.Action == "ADD")
            {
                if (string.IsNullOrEmpty(request.EmployeeCode))
                {
                    response.responseCode = 0;
                    response.responseMessage = "employeecode required!";
                    return response;
                }
                if (string.IsNullOrEmpty(request.EmployeeRole))
                {
                    response.responseCode = 0;
                    response.responseMessage = "employee role required!";
                    return response;
                }
            }
            if (request.Action == "DELETE")
            {
                if (string.IsNullOrEmpty(request.MappingID))
                {
                    response.responseCode = 0;
                    response.responseMessage = "MappingID required!";
                    return response;
                }
            }
            DataTable dtEmployees = new DataTable();

            string pgsqlConnection = appSettings.Value.DbConnection;
            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_manage_user_role
                                                                    ( 
                                                                        :p_action,
                                                                        :p_employeecode,
                                                                        :p_employeerole,
                                                                        :p_mappingid
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EmployeeRole))
                            cmd.Parameters.AddWithValue("p_employeerole", DbType.String).Value = request.EmployeeRole;
                        else
                            cmd.Parameters.AddWithValue("p_employeerole", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.MappingID))
                            cmd.Parameters.AddWithValue("p_mappingid", DbType.String).Value = request.MappingID;
                        else
                            cmd.Parameters.AddWithValue("p_mappingid", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();

                        response.responseCode = 1;
                        response.responseMessage = "Success";
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("deleteRole", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

            //NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);

            //try
            //{
            //    npgCon.Open();

            //    string sqlQuery = "call manage_user_role('" + request.Action + "','" + request.EmployeeCode + "','" + request.EmployeeRole + "','" + request.MappingID + "')";

            //    // Define a command to call  procedure
            //    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
            //    NpgsqlDataReader rdr = cmd.ExecuteReader();
            //    response.responseCode = 1;
            //    response.responseMessage = "Success";
            //    return response;
            //}
            //catch (Exception ex)
            //{
            //    _serviceconnect.LogConnect("deleteRole", "1024", ex.Message, "Exception");
            //    response.responseCode = 0;
            //    response.responseMessage = ex.Message;
            //}
            //finally
            //{
            //    npgCon.Close();
            //}
            //return response;


        }

        public ResponseClass addVisitSummary(UserVisitSummaryRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery = string.Empty;

                npgsql.Open();

                sqlQuery = "insert into #AdminPageVisitSummary#(#EmployeeID#,#PageName#,#RoleName#)values('" + request.EmployeeID + "','" + request.PageName + "','" + request.RoleName + "');";
                sqlQuery = sqlQuery.Replace('#', '"');
                // Define a command to call  procedure
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsql);
                NpgsqlDataReader rdr = cmd.ExecuteReader();

                npgsql.Close();


                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception)
            {

                
            }
            

            return response;

        }

        public ResponseClass setDefaultRole(setDefaultRole request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                string sqlQuery = string.Empty;

                npgsql.Open();
                sqlQuery = "update #UserMaster# set #DefaultRole#='" +  request.RoleName + "' where #EmployeeID#='" + request.EmployeeID + "';";
               
                sqlQuery = sqlQuery.Replace('#', '"');
                // Define a command to call  procedure
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsql);
                NpgsqlDataReader rdr = cmd.ExecuteReader();

                npgsql.Close();


                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            return response;

        }

        public ResponseClass InsertSiteLoginData(insertSiteDataRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

               
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_site_login_data
                                                                        ( 
                                                                            :p_employee_code,
                                                                            :prolemastername,:pplatform,
                                                                            :pinsertedipaddress,:pbrowser,
                                                                            :psessionid,
                                                                            :paction
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = request.EmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_employee_code", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.RoleMasterName))
                            cmd.Parameters.AddWithValue("prolemastername", DbType.String).Value = request.RoleMasterName;
                        else
                            cmd.Parameters.AddWithValue("prolemastername", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.Platform))
                            cmd.Parameters.AddWithValue("pplatform", DbType.String).Value = request.Platform;
                        else
                            cmd.Parameters.AddWithValue("pplatform", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.IPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.IPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.Browser))
                            cmd.Parameters.AddWithValue("pbrowser", DbType.String).Value = request.Browser;
                        else
                            cmd.Parameters.AddWithValue("pbrowser", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.SessionID))
                            cmd.Parameters.AddWithValue("psessionid", DbType.String).Value = request.SessionID;
                        else
                            cmd.Parameters.AddWithValue("psessionid", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("paction", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("paction", DbType.String).Value = "Login";

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                        }
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditExpressEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass updateProfilePIC(profilepicrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_update_user_profile_pic
                                                                        ( 
                                                                            :p_emplyeecode,
                                                                            :p_picpath
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            cmd.Parameters.AddWithValue("p_emplyeecode", DbType.String).Value = request.EmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_emplyeecode", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.PICPath))
                            cmd.Parameters.AddWithValue("p_picpath", DbType.String).Value = request.PICPath;
                        else
                            cmd.Parameters.AddWithValue("p_picpath", DbType.String).Value = string.Empty;


                        
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                        }
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("updateProfilePIC", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass getAllowEmailDetails()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dtAllowEmail = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_UserEmailMasterDetails()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtAllowEmail);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtAllowEmail);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("allowEmailDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass addAllowEmail(allowEmailDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                int chkCount = 0;
                //List<string> geoAdminCompanyCode = new List<string>();
                //geoAdminCompanyCode = request.UserCompanyCode.Split(',').ToList();

                if (string.IsNullOrWhiteSpace(request.EmailID))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Allow Email required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.RequestedBy))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Request By required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.RequestedDate))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Requested Date required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.EmailRemarks))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Email Remarks required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.AccessExpireOn))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Access Expire required!";
                    return response;
                }

                NpgsqlConnection conn = new NpgsqlConnection(pgsqlConnection);
                conn.Open();
                string sqlQuery = "select * from public.fn_check_UserEmailAssign('" + request.EmailID + "')";
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery,conn);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    chkCount = Convert.ToInt32(reader["emailcount"].ToString());
                }
                conn.Close();

                if(chkCount == 0)
                {
                    NpgsqlConnection conn1 = new NpgsqlConnection(pgsqlConnection);
                    conn1.Open();
                    string sqlQuery1 = "call usp_insert_useremailmasterdetails('" + request.EmailID + "','" + request.RequestedBy + "','" + request.AccessExpireOn + "','" + request.RequestedDate + "','" + request.EmailRemarks + "','" + request.CreatedBy + "')";
                    NpgsqlCommand cmd2 = new NpgsqlCommand(sqlQuery1,conn1);
                    NpgsqlDataReader reader1 = cmd2.ExecuteReader();
                    conn1.Close();

                    //Insert into User RoleMap
                    conn1.Open();
                    string sqlQuery2 = "CALL public.usp_insert_userdetails('" + request.EmailID + "','','','','" + request.UserEmailRoleName + "','','" + request.RequestedBy + "')";
                    NpgsqlCommand cmd3 = new NpgsqlCommand(sqlQuery2,conn1);
                    NpgsqlDataReader reader2 = cmd3.ExecuteReader();
                    conn1.Close();

                    ////TPA Database Entry
                    //SqlParameter[] sqlParameters = {
                    //    new SqlParameter("@EmpID", Convert.ToString(request.EmailID)),
                    //    new SqlParameter("@UserName", Convert.ToString(request.EmailID))
                    //};

                    //List<OutParameter> outParameters = new List<OutParameter>();

                    //int tparesult = tpadBConnection.ExecuteNonQuery("PRC_create_TPAAccess", sqlParameters, outParameters);

                    //Assessment Guest User Entry
                    //SqlParameter[] sqlParameters1 = {
                    //    new SqlParameter("@USERNAME", Convert.ToString(request.EmailID)),
                    //    new SqlParameter("@USERPASS", ""),
                    //    new SqlParameter("@USERCREATEDBY", Convert.ToString(request.CreatedBy))
                    //};

                    //List<OutParameter> outParameters1 = new List<OutParameter>();
                    //int assessmentResult = assessmentadBConnection.ExecuteNonQuery("PRC_Assessment_InsertGuestUserData", sqlParameters1,outParameters1);

                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "User Already Exist!";
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("addallowEmail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass deleteAllowEmail(allowEmailDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;

                if(string.IsNullOrWhiteSpace(request.UserEmailId))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Email ID required!";
                    return response;
                }

                long userEmailD = long.Parse(request.UserEmailId);
                string userAllowEmail = string.Empty;

                NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);
                string sqlQuery = "call usp_delete_useremailmasterdetails(" + userEmailD + ",'" + request.ModifiedBy + "')";
                npgsqlConnection.Open();
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery,npgsqlConnection);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                npgsqlConnection.Close();

                //delete from Assessment Guest User
                //string sqlQuery1 = "select * from public.fn_get_useremail('" + request.UserEmailId + "')";
                //npgsqlConnection.Open();
                //NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery1, npgsqlConnection);
                //NpgsqlDataReader reader1 = cmd1.ExecuteReader();

                //while(reader1.Read())
                //{
                //    userAllowEmail = reader1["employeeidcount"].ToString();
                //}

                //npgsqlConnection.Close();

                //if(!string.IsNullOrWhiteSpace(userAllowEmail))
                //{
                //    SqlParameter[] sqlParameters1 = {
                //        new SqlParameter("@USERNAME", Convert.ToString(userAllowEmail)),
                //        new SqlParameter("@USERMODIFIEDBY", Convert.ToString(request.ModifiedBy))
                //    };

                //    List<OutParameter> outParameters1 = new List<OutParameter>();
                //    int assessmentResult = assessmentadBConnection.ExecuteNonQuery("PRC_Assessment_DeleteGuestUserData", sqlParameters1, outParameters1);
                //}

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("deleteallowEmail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getEditAllowEmailDetails(allowEmailDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtAllowEmail = new DataTable();

                if (string.IsNullOrWhiteSpace(request.UserEmailId))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Email ID required!";
                    return response;
                }

                long userEmailD = long.Parse(request.UserEmailId);
                NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);
                string sqlQuery = "select * from public.fn_get_edituseremailmasterdetails(" + userEmailD + ")";

                npgsqlConnection.Open();
                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery,npgsqlConnection);
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                dataAdapter.Fill(dtAllowEmail);
                npgsqlConnection.Close();

                response.responseJSON = JsonConvert.SerializeObject(dtAllowEmail);
                response.responseCode = 1;

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("editallowEmail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass updateEditAllowEmailDetails(allowEmailDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                string userAllowEmail = string.Empty;

                if (string.IsNullOrWhiteSpace(request.EmailID))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Allow Email required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.RequestedBy))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Request By required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.RequestedDate))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Requested Date required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.EmailRemarks))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Email Remarks required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.AccessExpireOn))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Access Expire required!";
                    return response;
                }

                NpgsqlConnection conn = new NpgsqlConnection(pgsqlConnection);
                long userEmailID = long.Parse(request.UserEmailId);
                conn.Open();

                string sqlQuery = "CALL usp_update_useremailmasterdetails('" + request.EmailID + "','" + request.RequestedBy + "','" + request.AccessExpireOn + "','" + request.RequestedDate + "','" + request.EmailRemarks + "','" + request.RequestedBy + "','" + userEmailID + "')";

                NpgsqlCommand command = new NpgsqlCommand(sqlQuery,conn);
                NpgsqlDataReader dataReader = command.ExecuteReader();

                conn.Close();

                //Assessment Edit Guest User

                //string sqlQuery1 = "select * from public.fn_get_useremail('" + request.UserEmailId + "')";
                //conn.Open();
                //NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery1, conn);
                //NpgsqlDataReader reader1 = cmd1.ExecuteReader();

                //while (reader1.Read())
                //{
                //    userAllowEmail = reader1["employeeidcount"].ToString();
                //}

                //conn.Close();
                //SqlParameter[] sqlParameters1 = {
                //        new SqlParameter("@USERNAME", Convert.ToString(userAllowEmail)),
                //        new SqlParameter("@USERMODIFIEDBY", Convert.ToString(request.ModifiedBy)),
                //        new SqlParameter("@UPDATEUSERNAME", Convert.ToString(request.EmailID))
                //    };

                //List<OutParameter> outParameters1 = new List<OutParameter>();
                //int assessmentResult = assessmentadBConnection.ExecuteNonQuery("PRC_Assessment_UpdateGuestUserData", sqlParameters1, outParameters1);

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("updateallowEmail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getLMSRoleDetails()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtLmsRole = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_LMSRole()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtLmsRole);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtLmsRole);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getLMSRoe", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getJobRoleDetails()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtJobRole = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_JobRole()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtJobRole);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtJobRole);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getLMSRoe", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass addUserDetails(addUserDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                int chkCount = 0;
                string roleName = string.Empty;
                List<string> companyCodeList = new List<string>();
                List<string> roleNameList = new List<string>();

                if(string.IsNullOrWhiteSpace(request.EmployeeID))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee ID required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.EmployeeFullName))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee Name required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.EmployeeDesgination))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee Desgination required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.EmployeeRoleId))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee Role required!";
                    return response;
                }

                roleNameList = request.EmployeeRoleId.Split(',').ToList();

                foreach(var b in roleNameList)
                {
                    NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);

                    npgsqlConnection.Open();
                    string sqlQuery11 = "select #RoleMasterName# from public.#RoleMaster# WHERE #RoleMasterID# = " + b;
                    sqlQuery11 = sqlQuery11.Replace('#', '"');
                    NpgsqlCommand command11 = new NpgsqlCommand(sqlQuery11, npgsqlConnection);
                    NpgsqlDataReader reader11 = command11.ExecuteReader();
                    while (reader11.Read())
                    {
                        roleName = reader11["RoleMasterName"].ToString();
                    }
                    npgsqlConnection.Close();

                    if (roleName == "Geo Admin")
                    {
                        companyCodeList = request.EmployeeRoleNameCompanyCode.Split(',').ToList();
                        if (companyCodeList.Count() == 0)
                        {
                            response.responseCode = 0;
                            response.responseMessage = "Company Code required for Geo Admin!";
                            return response;
                        }
                    }

                    npgsqlConnection.Open();
                    string sqlQuery = "select * from public.fn_check_UserRoleAssign('" + request.EmployeeID + "','" + roleName + "')";
                    NpgsqlCommand command = new NpgsqlCommand(sqlQuery, npgsqlConnection);
                    NpgsqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        chkCount = int.Parse(reader["employeeidcount"].ToString());
                    }
                    npgsqlConnection.Close();

                    if (chkCount == 0)
                    {
                        var employeeName = request.EmployeeFullName.Split(' ');

                        if(employeeName.Count() > 1)
                        {
                            request.EmployeeFName = employeeName[0].Replace("'", " ");
                            request.EmployeeLName = employeeName[1].Replace("'", " ");
                        }
                        else
                        {
                            request.EmployeeFName = employeeName[0].Replace("'", " ");
                        }

                        //request.EmployeeFName = employeeName[0].Replace("'", " ");
                        //if(!string.IsNullOrWhiteSpace(employeeName[1]))
                        //{
                        //    request.EmployeeLName = employeeName[1].Replace("'", " ");
                        //}
                        

                        string sqlQuery1 = "CALL public.usp_insert_userdetails('" + request.EmployeeID + "','" + request.EmployeeFName + "','" + request.EmployeeLName + "','" + request.EmployeeDesgination + "','" + roleName + "','" + b + "','" + request.EmployeeCreatedBy + "')";
                        npgsqlConnection.Open();
                        NpgsqlCommand command1 = new NpgsqlCommand(sqlQuery1, npgsqlConnection);
                        NpgsqlDataReader reader1 = command1.ExecuteReader();
                        npgsqlConnection.Close();

                        if (roleName == "Geo Admin")
                        {
                            foreach (var a in companyCodeList)
                            {
                                string sqlQuery2 = "CALL public.usp_insert_geoadmincompanydetails('" + request.EmployeeID + "','" + a + "')";
                                npgsqlConnection.Open();
                                NpgsqlCommand command2 = new NpgsqlCommand(sqlQuery2, npgsqlConnection);
                                NpgsqlDataReader reader2 = command2.ExecuteReader();
                                npgsqlConnection.Close();
                            }
                        }

                        //TPA Database Entry
                        //SqlParameter[] sqlParameters = {
                        //    new SqlParameter("@EmpID", Convert.ToString(request.EmployeeID)),
                        //    new SqlParameter("@UserName", Convert.ToString(request.EmployeeFullName))
                        //};

                        //List<OutParameter> outParameters = new List<OutParameter>();

                        //int tparesult = tpadBConnection.ExecuteNonQuery("PRC_create_TPAAccess", sqlParameters, outParameters);
                    }

                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("addUserDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getManageUserDetails()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtManageUser = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_usermanagemasterdetails()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtManageUser);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtManageUser);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("manageUserDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass deleteManageUser(addUserDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection connection = new NpgsqlConnection(pgsqlConnection);

                if(string.IsNullOrWhiteSpace(request.EmployeeMapId))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee Map ID required!";
                    return response;
                }

                connection.Open();

                //string sqlQuery = "select * from public.fn_delete_UserRoleAssign('" + request.EmployeeMapId + "')";
                string sqlQuery = "select * from public.fn_delete_UserRoleAssign('" + request.EmployeeMapId + "','" + request.EmployeeCreatedBy + "')";
                NpgsqlCommand command = new NpgsqlCommand(sqlQuery,connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                connection.Close();

                response.responseMessage = "Success";
                response.responseCode = 1;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("manageUserDelete", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass editUserDetails(addUserDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtManageUser = new DataTable();
                DataTable dtGeoCompanyCode = new DataTable();
                string roleName = string.Empty;

                NpgsqlConnection npgsqlConnection1 = new NpgsqlConnection(pgsqlConnection);
                npgsqlConnection1.Open();
                string sqlQuery = "select #RoleMasterName# from #UserRoleMap# where #MappingID# = " + request.EmployeeMapId + " order by 1 desc";
                sqlQuery = sqlQuery.Replace('#','"');
                NpgsqlCommand command11 = new NpgsqlCommand(sqlQuery, npgsqlConnection1);
                NpgsqlDataReader reader11 = command11.ExecuteReader();
                while (reader11.Read())
                {
                    roleName = reader11["RoleMasterName"].ToString();
                }
                npgsqlConnection1.Close();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_update_usermanagemasterdetails('" + request.EmployeeMapId + "')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtManageUser);

                        npgsqlConnection.Close();

                        
                    }
                }

                if (roleName == "Geo Admin")
                {
                    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_update_usermanagemasterdetailsgeoadmin('" + request.EmployeeMapId + "')", npgsqlConnection))
                        {
                            npgsqlConnection.Open();

                            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                            dataAdapter.Fill(dtGeoCompanyCode);

                            npgsqlConnection.Close();
                        }
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtManageUser);
                response.responseJSONSecondary = JsonConvert.SerializeObject(dtGeoCompanyCode);
                response.responseCode = 1;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("editmanageUser", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass updateUserDetails(addUserDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                List<string> geoCompanyCodeList = new List<string>();
                if (string.IsNullOrWhiteSpace(request.EmployeeID))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee ID required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.EmployeeFullName))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee Name required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.EmployeeDesgination))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee Desgination required!";
                    return response;
                }
                if (string.IsNullOrWhiteSpace(request.EmployeeRoleName))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Employee Role required!";
                    return response;
                }

                if (request.EmployeeRoleName == "Geo Admin")
                {
                    geoCompanyCodeList = request.EmployeeRoleNameCompanyCode.Split(',').ToList();
                    if(geoCompanyCodeList.Count() == 0)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Company Code required for Geo Admin!";
                        return response;
                    }
                }

                var employeeName = request.EmployeeFullName.Split(' ');
                //request.EmployeeFName = employeeName[0].Replace("'", " ");
                //request.EmployeeLName = employeeName[1].Replace("'", " ");

                if(employeeName.Length > 1)
                {
                    request.EmployeeFName = employeeName[0].Replace("'", " ");
                    request.EmployeeLName = employeeName[1].Replace("'", " ");
                }
                else
                {
                    request.EmployeeFName = employeeName[0].Replace("'", " ");
                }

                NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);
                npgsqlConnection.Open();

                string sqlQuery1 = "CALL public.usp_update_userdetails('" + request.EmployeeID + "','" + request.EmployeeFName + "','" + request.EmployeeLName + "','" + request.EmployeeDesgination + "','" + request.EmployeeRoleName + "','" + request.EmployeeRoleId + "','" + request.EmployeeMapId + "')";

                NpgsqlCommand command1 = new NpgsqlCommand(sqlQuery1, npgsqlConnection);
                NpgsqlDataReader reader1 = command1.ExecuteReader();

                npgsqlConnection.Close();

                if(request.EmployeeRoleName == "Geo Admin")
                {
                    geoCompanyCodeList = request.EmployeeRoleNameCompanyCode.Split(',').ToList();
                    List<string> assignedCompanyCode = new List<string>();

                    npgsqlConnection.Open();
                    string sqlQuery3 = "select * from public.fn_get_userassignmentcompanycodedetails('" + request.EmployeeID + "')";
                    NpgsqlCommand command3 = new NpgsqlCommand(sqlQuery3, npgsqlConnection);
                    NpgsqlDataReader reader3 = command3.ExecuteReader();
                    while(reader3.Read())
                    {
                        assignedCompanyCode.Add(reader3["companycode"].ToString());
                    }
                    npgsqlConnection.Close();

                    var removeAssignCompanyCode = assignedCompanyCode.Except(geoCompanyCodeList).ToList();

                    if(removeAssignCompanyCode.Count() > 0)
                    {
                        foreach(var a in removeAssignCompanyCode)
                        {
                            npgsqlConnection.Open();
                            string sqlQuery4 = "UPDATE public.#UserCompanyAssignment# SET #ActiveStatus# = 0 WHERE #EmployeeCode# = '" + request.EmployeeID + "' AND #CompanyCode# = '" + a + "'";
                            sqlQuery4 = sqlQuery4.Replace('#','"');
                            NpgsqlCommand command4 = new NpgsqlCommand(sqlQuery4, npgsqlConnection);
                            NpgsqlDataReader reader4 = command4.ExecuteReader();
                            npgsqlConnection.Close();
                        }
                    }

                    foreach(var a in geoCompanyCodeList)
                    {
                        string sqlQuery2 = "CALL public.usp_insert_geoadmincompanydetails('" + request.EmployeeID + "','" + a + "')";
                        npgsqlConnection.Open();
                        NpgsqlCommand command2 = new NpgsqlCommand(sqlQuery2, npgsqlConnection);
                        NpgsqlDataReader reader2 = command2.ExecuteReader();
                        npgsqlConnection.Close();
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("updatemanageUser", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getSearchManageUserDetails(searchUserDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtManageUser = new DataTable();

                string empName = string.Empty;
                string empLoginID = string.Empty;
                string empEmailID = string.Empty;
                string empCity = string.Empty;

                //Emp Login ID
                List<string> empLoginIDList = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.EmployeeLoginID))
                {
                    empLoginIDList = request.EmployeeLoginID.Split(",").ToList();
                }
                else
                {
                    empLoginIDList.Add("");
                }

                //Emp Name
                List<string> empFName = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.EmployeeFullName))
                {
                    empFName = request.EmployeeFullName.Replace(" ", "").Split(",").ToList();
                }
                else
                {
                    empFName.Add("");
                }

                //Emp Email ID
                List<string> empEmailIDList = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.EmployeeEmailID))
                {
                    empEmailIDList = request.EmployeeEmailID.Split(",").ToList();
                }
                else
                {
                    empEmailIDList.Add("");
                }

                //Emp City
                List<string> empCityList = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.EmployeeCity))
                {
                    empCityList = request.EmployeeCity.Split(",").ToList();
                }
                else
                {
                    empCityList.Add("");
                }

                string teamMembers = string.Empty;
                string companiestopass = string.Empty;
                if (request.currentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.currentEmployee;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }


                }


                List<string> empTeamList = new List<string>();
                if (!string.IsNullOrWhiteSpace(teamMembers))
                {
                    empTeamList = teamMembers.Split(",").ToList();
                }
                else
                {
                    empTeamList.Add("");
                }

                List<string> empCompanyList = new List<string>();
                if (string.IsNullOrEmpty(request.CompanyCode) || request.CompanyCode == "0")
                {
                    if (request.currentRole == "Geo Admin")
                    {
                        DataTable dtCompanies = new DataTable();
                        dtCompanies = _qualtricsBL.gtAssignedCompany(request.currentEmployee);
                        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dtCompanies.Rows)
                            {
                                companiestopass = companiestopass + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                            }

                            companiestopass = companiestopass.TrimEnd(',');



                        }
                    }

                    if (request.currentRole == "Program Manager")
                    {
                        DataTable dtCompanies = new DataTable();
                        dtCompanies = _qualtricsBL.getProgramManagerAssignedCompanies(request.currentEmployee);
                        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                        {
                            string companyNames = string.Empty;

                            companyNames = Convert.ToString(dtCompanies.Rows[0]["CompanyCode"]);

                            string[] authorsList = companyNames.Split(",");
                            foreach (string author in authorsList)
                            {
                                companiestopass = companiestopass + "" + Convert.ToString(author) + ",";

                            }

                            companiestopass = companiestopass.TrimEnd(',');



                        }
                    }


                    if (!string.IsNullOrWhiteSpace(companiestopass))
                    {
                        empCompanyList = companiestopass.Split(",").ToList();
                    }
                    else
                    {
                        empCompanyList.Add("");
                    }
                }
                else
                {
                    if (!string.IsNullOrWhiteSpace(request.CompanyCode))
                    {
                        empCompanyList = request.CompanyCode.Split(",").ToList();
                    }
                    else
                    {
                        empCompanyList.Add("");
                    }
                }



                List<string> empDepartmentList = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.DepartmentCode))
                {
                    empDepartmentList = request.DepartmentCode.Split(",").ToList();
                }
                else
                {
                    empDepartmentList.Add("");
                }

                companiestopass = string.Empty;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_searchusermanagemasterdetails(:p_city,:p_emailid,:p_empid,:p_empfname,:p_team,:pcompany,:pdepartment)", npgsqlConnection))
                    {
                        npgsqlCommand.CommandType = CommandType.Text;
                        if (!string.IsNullOrWhiteSpace(request.EmployeeCity))
                            npgsqlCommand.Parameters.AddWithValue("p_city", DbType.Object).Value = empCityList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_city", DbType.Object).Value = empCityList;

                        if (!string.IsNullOrWhiteSpace(request.EmployeeEmailID))
                            npgsqlCommand.Parameters.AddWithValue("p_emailid", DbType.Object).Value = empEmailIDList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_emailid", DbType.Object).Value = empEmailIDList;

                        if (!string.IsNullOrWhiteSpace(request.EmployeeLoginID))
                            npgsqlCommand.Parameters.AddWithValue("p_empid", DbType.Object).Value = empLoginIDList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_empid", DbType.Object).Value = empLoginIDList;

                        if (!string.IsNullOrWhiteSpace(request.EmployeeFullName))
                            npgsqlCommand.Parameters.AddWithValue("p_empfname", DbType.Object).Value = empFName;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_empfname", DbType.Object).Value = empFName;

                        if (!String.IsNullOrEmpty(request.currentEmployee))
                            npgsqlCommand.Parameters.AddWithValue("p_team", DbType.String).Value = empTeamList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_team", DbType.String).Value = empTeamList;

                        if (!String.IsNullOrEmpty(request.currentRole))
                            npgsqlCommand.Parameters.AddWithValue("pcompany", DbType.Object).Value = empCompanyList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("pcompany", DbType.Object).Value = empCompanyList;

                        if (!String.IsNullOrEmpty(request.DepartmentCode))
                            npgsqlCommand.Parameters.AddWithValue("pdepartment", DbType.Object).Value = empDepartmentList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("pdepartment", DbType.Object).Value = empDepartmentList;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtManageUser);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtManageUser);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("manageUserDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        //public ResponseClass getSearchManageUserDetails(searchUserDTO request)
        //{

        //    ResponseClass response = new ResponseClass();
        //    try
        //    {


        //        DataTable dtEmployees = new DataTable();
        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        string companiestopass = string.Empty;
        //        string teamMembers = string.Empty;
        //        List<string> p_teammember = new List<string>();

        //        if (request.currentRole == "Geo Admin")
        //        {
        //            DataTable dtCompanies = new DataTable();
        //            dtCompanies = _qualtricsBL.gtAssignedCompany(request.currentEmployee);
        //            if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //            {
        //                foreach (DataRow exclude in dtCompanies.Rows)
        //                {
        //                    companiestopass = companiestopass + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
        //                }

        //                companiestopass = companiestopass.TrimEnd(',');



        //            }
        //        }
        //        else if (request.currentRole == "Team Lead")
        //        {
        //            getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
        //            getteam.EmployeeCode = request.currentEmployee;
        //            var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
        //            DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
        //            if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
        //            {
        //                foreach (DataRow exclude in QualtricTeamMembers.Rows)
        //                {
        //                    teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
        //                }

        //                teamMembers = teamMembers.TrimEnd(',');

        //            }


        //        }


        //        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
        //        {
        //            using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"SELECT * FROM fn_get_searchusermanagemasterdetails_paging
        //                                                                ( 
        //                                                                    :p_username,
        //                                                                    :p_current_role,:p_searchempcode,:p_pageno,:p_recordno,:p_company,:p_teammember

        //                                                                )", npgsqlConnection))
        //            {
        //                //cmd.CommandType = CommandType.Text; //
        //                //if (!String.IsNullOrEmpty(request.employeeCode))
        //                //    cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.employeeCode;
        //                //else
        //                //    cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;

        //                //if (!String.IsNullOrEmpty(request.CurrentRole))
        //                //    cmd.Parameters.AddWithValue("p_current_role", DbType.String).Value = request.CurrentRole;
        //                //else
        //                //    cmd.Parameters.AddWithValue("p_current_role", DbType.String).Value = DBNull.Value;

        //                //if (!String.IsNullOrEmpty(request.searchbyempcode))
        //                //    cmd.Parameters.AddWithValue("p_searchempcode", DbType.String).Value = request.searchbyempcode;
        //                //else
        //                //    cmd.Parameters.AddWithValue("p_searchempcode", DbType.String).Value = string.Empty;

        //                //cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
        //                //cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

        //                //if (!String.IsNullOrEmpty(companiestopass))
        //                //    cmd.Parameters.AddWithValue("p_company", DbType.String).Value = companiestopass;
        //                //else
        //                //    cmd.Parameters.AddWithValue("p_company", DbType.String).Value = string.Empty;

        //                //if (!String.IsNullOrEmpty(teamMembers))
        //                //    cmd.Parameters.AddWithValue("p_teammember", DbType.String).Value = teamMembers;
        //                //else
        //                //    cmd.Parameters.AddWithValue("p_teammember", DbType.String).Value = string.Empty;


        //                npgsqlCommand.CommandType = CommandType.Text;
        //                if (!string.IsNullOrWhiteSpace(request.EmployeeCity))
        //                    npgsqlCommand.Parameters.AddWithValue("p_city", DbType.String).Value =request.EmployeeCity;
        //                else
        //                    npgsqlCommand.Parameters.AddWithValue("p_city", DbType.String).Value = string.Empty;

        //                if (!string.IsNullOrWhiteSpace(request.EmployeeEmailID))
        //                    npgsqlCommand.Parameters.AddWithValue("p_emailid", DbType.String).Value = request.EmployeeEmailID;
        //                else
        //                    npgsqlCommand.Parameters.AddWithValue("p_emailid", DbType.String).Value = string.Empty;

        //                if (!string.IsNullOrWhiteSpace(request.EmployeeLoginID))
        //                    npgsqlCommand.Parameters.AddWithValue("p_empid", DbType.String).Value = request.EmployeeLoginID;
        //                else
        //                    npgsqlCommand.Parameters.AddWithValue("p_empid", DbType.String).Value = string.Empty;

        //                if (!string.IsNullOrWhiteSpace(request.EmployeeFullName))
        //                    npgsqlCommand.Parameters.AddWithValue("p_empfname", DbType.String).Value = request.EmployeeFullName;
        //                else
        //                    npgsqlCommand.Parameters.AddWithValue("p_empfname", DbType.String).Value = string.Empty;

        //                if (!String.IsNullOrEmpty(request.currentEmployee))
        //                    npgsqlCommand.Parameters.AddWithValue("p_team", DbType.String).Value = request.currentEmployee;
        //                else
        //                    npgsqlCommand.Parameters.AddWithValue("p_team", DbType.String).Value = string.Empty;

        //                if (!String.IsNullOrEmpty(request.currentRole))
        //                    npgsqlCommand.Parameters.AddWithValue("pcompany", DbType.String).Value = request.currentRole;
        //                else
        //                    npgsqlCommand.Parameters.AddWithValue("pcompany", DbType.String).Value = string.Empty;

        //                npgsqlCommand.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
        //                npgsqlCommand.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;


        //                npgsqlConnection.Open();

        //                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
        //                dataAdapter.Fill(dtEmployees);
        //                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
        //                int recordcount = 1;
        //                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
        //                {
        //                    recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

        //                    if (request.PageNumber != -1)
        //                    {
        //                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

        //                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

        //                        int recordPages = Convert.ToInt32(noOfPages);

        //                        if (noOfPages > recordPages)
        //                        {
        //                            recordPages = recordPages + 1;
        //                        }

        //                        response.recordCount = recordPages;
        //                    }
        //                }

        //            }
        //        }

        //        response.responseCode = 1;
        //        response.responseMessage = "Success";
        //    }
        //    catch (Exception ex)
        //    {

        //        _serviceconnect.LogConnect("GetAgntHomePage", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }
        //    return response;
        //}

        public ResponseClass getLMSRoleCompanyDetails()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtLmsRole = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_LMSRoleCompanyCode()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtLmsRole);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtLmsRole);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getLMSRoeCompnay", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getPMProxyDeatils(addPMProxyUser request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtProxyDetails = new DataTable();
                DataTable dtProxyDetails1 = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_proxy_userpmcardviewsearch('"+request.ProxyBy+"')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtProxyDetails);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtProxyDetails);
                    }
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_proxy_userpmdetailcardviewsearch('" + request.ProxyBy + "')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtProxyDetails1);

                        npgsqlConnection.Close();

                        response.responseJSONSecondary = JsonConvert.SerializeObject(dtProxyDetails1);
                        
                    }
                }
                response.responseCode = 1;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getPMProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass deletePMProxyDeatils(addPMProxyUser request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection connection = new NpgsqlConnection(pgsqlConnection);
                connection.Open();

                string sqlQuery = "call public.usp_delete_userproxydetails('" + long.Parse(request.PUMID) + "','" + request.ProxyModifiedBy + "')";
                NpgsqlCommand command = new NpgsqlCommand(sqlQuery,connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                connection.Close();

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("deletePMProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass addPMProxyDeatils(addPMProxyUser request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                long checkCount = 0;
                string addUserGeo = string.Empty;
                List<string> addUserRole = new List<string>();
                NpgsqlConnection connection = new NpgsqlConnection(pgsqlConnection);

                connection.Open();
                string sqlQuery1 = "select * from public.fn_get_proxy_checkuserpmcardviewsearch('" + request.ProxyFor + "','" + request.ProxyBy + "')";
                NpgsqlCommand command1 = new NpgsqlCommand(sqlQuery1,connection);
                NpgsqlDataReader reader1 = command1.ExecuteReader();
                while(reader1.Read())
                {
                    checkCount = long.Parse(reader1["pumid"].ToString());
                }
                connection.Close();

                if(checkCount == 0)
                {
                    connection.Open();
                    string sqlQuery11 = "select * from public.fn_get_proxy_checkuserrolenamepmcardviewsearch('" + request.ProxyBy + "')";
                    NpgsqlCommand command11 = new NpgsqlCommand(sqlQuery11, connection);
                    NpgsqlDataReader reader11 = command11.ExecuteReader();
                    while (reader11.Read())
                    {
                        addUserRole.Add(reader11["proxygeo"].ToString());
                    }
                    connection.Close();

                    if(!addUserRole.Contains("program manager") && !addUserRole.Contains("global admin") && !addUserRole.Contains("geo admin"))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "You can not add proxy for " + addUserRole.FirstOrDefault() + "!";
                        return response;
                    }


                    if (request.ProxyByRoleName == "Program Manager")
                    {
                        connection.Open();
                        string sqlQuery2 = "select * from public.fn_get_proxy_checkusergeopmcardviewsearch('" + request.ProxyFor + "')";
                        NpgsqlCommand command2 = new NpgsqlCommand(sqlQuery2, connection);
                        NpgsqlDataReader reader2 = command2.ExecuteReader();
                        while (reader2.Read())
                        {
                            addUserGeo = reader2["proxygeo"].ToString();
                        }
                        connection.Close();

                        if (addUserGeo != request.ProxyGeo.ToLower())
                        {
                            response.responseCode = 0;
                            response.responseMessage = "You can not add other geo user!";
                            return response;
                        }
                    }

                    if (request.ProxyByRoleName == "Geo Admin")
                    {
                        List<string> geoList = new List<string>();

                        connection.Open();
                        string sqlQuery3 = "select * from public.fn_get_proxy_checkusergeolistpmcardviewsearch('" + request.ProxyBy + "')";
                        NpgsqlCommand command3 = new NpgsqlCommand(sqlQuery3, connection);
                        NpgsqlDataReader reader3 = command3.ExecuteReader();
                        while (reader3.Read())
                        {
                            geoList.Add(reader3["proxygeo"].ToString().ToLower());
                        }
                        connection.Close();

                        connection.Open();
                        string sqlQuery2 = "select * from public.fn_get_proxy_checkusergeopmcardviewsearch('" + request.ProxyFor + "')";
                        NpgsqlCommand command2 = new NpgsqlCommand(sqlQuery2, connection);
                        NpgsqlDataReader reader2 = command2.ExecuteReader();
                        while (reader2.Read())
                        {
                            addUserGeo = reader2["proxygeo"].ToString();
                        }
                        connection.Close();

                        if (!geoList.Contains(addUserGeo))
                        {
                            response.responseCode = 0;
                            response.responseMessage = "You can not add other geo user!";
                            return response;
                        }
                    }
                }

                if(checkCount == 0)
                {
                    connection.Open();

                    string sqlQuery = "call public.usp_insert_userproxydetails('" + request.ProxyFor + "','" + request.ProxyBy + "','" + request.ProxyCraetedBy + "')";
                    NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);
                    NpgsqlDataReader reader = command.ExecuteReader();

                    connection.Close();

                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "User Already Exist!";
                }
                
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("insertPMProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getLogProxyDeatils()
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtProxyDetails = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_proxy_userlogdetails()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtProxyDetails);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtProxyDetails);
                    }
                }

                response.responseCode = 1;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getLogProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getSearchLogProxyDeatils(ProxyUserLog request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtProxyDetails = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_proxy_searchuserlogdetails('"+request.ProxyFor+"')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtProxyDetails);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtProxyDetails);
                    }
                }

                response.responseCode = 1;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getLogSearchProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass addLogProxyDeatils(ProxyUserLog request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection);
                string currentDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                npgsqlConnection.Open();

                string sqlQuery = "call public.usp_insert_userproxylogdetails('" + request.ProxyFor + "','" + request.ProxyBy + "','" + currentDateTime + "','" + request.ProxyBy + "')";

                NpgsqlCommand command = new NpgsqlCommand(sqlQuery,npgsqlConnection);
                NpgsqlDataReader reader = command.ExecuteReader();

                npgsqlConnection.Close();

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("addLogProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getAdminProxyDeatils(addPMProxyUser request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtProxyDetails = new DataTable();
                DataTable dtProxyDetails1 = new DataTable();

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_proxy_useradmincardviewsearch('" + request.ProxyBy + "')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtProxyDetails);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtProxyDetails);
                    }
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_get_proxy_useradmindetailcardviewsearch('" + request.ProxyBy + "')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtProxyDetails1);

                        npgsqlConnection.Close();

                        response.responseJSONSecondary = JsonConvert.SerializeObject(dtProxyDetails1);

                    }
                }
                response.responseCode = 1;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getPMProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass deleteAdminProxyDeatils(addPMProxyUser request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection connection = new NpgsqlConnection(pgsqlConnection);
                connection.Open();

                string sqlQuery = "call public.usp_delete_userproxydetails('" + long.Parse(request.PUMID) + "','" + request.ProxyModifiedBy + "')";
                NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);
                NpgsqlDataReader reader = command.ExecuteReader();

                connection.Close();

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("deletePMProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass addAdminProxyDeatils(addPMProxyUser request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                long checkCount = 0;
                List<string> addUserRole = new List<string>();
                NpgsqlConnection connection = new NpgsqlConnection(pgsqlConnection);

                connection.Open();
                string sqlQuery1 = "select * from public.fn_get_proxy_checkuserpmcardviewsearch('" + request.ProxyFor + "','" + request.ProxyBy + "')";
                NpgsqlCommand command1 = new NpgsqlCommand(sqlQuery1, connection);
                NpgsqlDataReader reader1 = command1.ExecuteReader();
                while (reader1.Read())
                {
                    checkCount = long.Parse(reader1["pumid"].ToString());
                }
                connection.Close();

                if (checkCount == 0)
                {
                    connection.Open();
                    string sqlQuery11 = "select * from public.fn_get_proxy_checkuserrolenamepmcardviewsearch('" + request.ProxyBy + "')";
                    NpgsqlCommand command11 = new NpgsqlCommand(sqlQuery11, connection);
                    NpgsqlDataReader reader11 = command11.ExecuteReader();
                    while (reader11.Read())
                    {
                        addUserRole.Add(reader11["proxygeo"].ToString());
                    }
                    connection.Close();

                    if (!addUserRole.Contains("program manager") && !addUserRole.Contains("global admin") && !addUserRole.Contains("geo admin"))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "You can not add proxy for this user!";
                        return response;
                    }

                    connection.Open();

                    string sqlQuery = "call public.usp_insert_userproxydetails('" + request.ProxyFor + "','" + request.ProxyBy + "','" + request.ProxyCraetedBy + "')";
                    NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);
                    NpgsqlDataReader reader = command.ExecuteReader();

                    connection.Close();

                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "User Already Exist!";
                }

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("deletePMProxyDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass ManageUserPrivilege(searchUserDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                DataTable dtManageUser = new DataTable();

                string empName = string.Empty;
                string empLoginID = string.Empty;
                string empEmailID = string.Empty;
                string empCity = string.Empty;

                //Emp Login ID
                List<string> empLoginIDList = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.EmployeeLoginID))
                {
                    empLoginIDList = request.EmployeeLoginID.Split(",").ToList();
                }
                else
                {
                    empLoginIDList.Add("");
                }

                //Emp Name
                List<string> empFName = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.EmployeeFullName))
                {
                    empFName = request.EmployeeFullName.Replace(" ", "").Split(",").ToList();
                }
                else
                {
                    empFName.Add("");
                }

                //Emp Email ID
                List<string> empEmailIDList = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.EmployeeEmailID))
                {
                    empEmailIDList = request.EmployeeEmailID.Split(",").ToList();
                }
                else
                {
                    empEmailIDList.Add("");
                }

                //Emp City
                List<string> empCityList = new List<string>();
                if (!string.IsNullOrWhiteSpace(request.EmployeeCity))
                {
                    empCityList = request.EmployeeCity.Split(",").ToList();
                }
                else
                {
                    empCityList.Add("");
                }

                string teamMembers = string.Empty;
                string companiestopass = string.Empty;
                if (request.currentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.currentEmployee;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }


                }
                else if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.currentEmployee);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                        }

                        companiestopass = companiestopass.TrimEnd(',');



                    }
                }

                List<string> empTeamList = new List<string>();
                if (!string.IsNullOrWhiteSpace(teamMembers))
                {
                    empTeamList = teamMembers.Split(",").ToList();
                }
                else
                {
                    empTeamList.Add("");
                }

                //List<string> empCompanyList = new List<string>();
                //if (!string.IsNullOrWhiteSpace(companiestopass))
                //{
                //    empCompanyList = companiestopass.Split(",").ToList();
                //}
                //else
                //{
                //    empCompanyList.Add("");
                //}

                companiestopass = string.Empty;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand npgsqlCommand = new NpgsqlCommand(@"select * from public.fn_search_manage_privilige(:p_city,:p_emailid,:p_empid,:p_empfname,:p_team,:pcompany,:pdepartment)", npgsqlConnection))
                    {
                        npgsqlCommand.CommandType = CommandType.Text;
                        if (!string.IsNullOrWhiteSpace(request.EmployeeCity))
                            npgsqlCommand.Parameters.AddWithValue("p_city", DbType.Object).Value = empCityList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_city", DbType.Object).Value = empCityList;

                        if (!string.IsNullOrWhiteSpace(request.EmployeeEmailID))
                            npgsqlCommand.Parameters.AddWithValue("p_emailid", DbType.Object).Value = empEmailIDList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_emailid", DbType.Object).Value = empEmailIDList;

                        if (!string.IsNullOrWhiteSpace(request.EmployeeLoginID))
                            npgsqlCommand.Parameters.AddWithValue("p_empid", DbType.Object).Value = empLoginIDList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_empid", DbType.Object).Value = empLoginIDList;

                        if (!string.IsNullOrWhiteSpace(request.EmployeeFullName))
                            npgsqlCommand.Parameters.AddWithValue("p_empfname", DbType.Object).Value = empFName;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_empfname", DbType.Object).Value = empFName;

                        if (!String.IsNullOrEmpty(request.currentEmployee))
                            npgsqlCommand.Parameters.AddWithValue("p_team", DbType.String).Value = empTeamList;
                        else
                            npgsqlCommand.Parameters.AddWithValue("p_team", DbType.String).Value = empTeamList;

                        if (!String.IsNullOrEmpty(request.CompanyCode))
                            npgsqlCommand.Parameters.AddWithValue("pcompany", DbType.String).Value = request.CompanyCode;
                        else
                            npgsqlCommand.Parameters.AddWithValue("pcompany", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.DepartmentCode))
                            npgsqlCommand.Parameters.AddWithValue("pdepartment", DbType.String).Value = request.DepartmentCode;
                        else
                            npgsqlCommand.Parameters.AddWithValue("pdepartment", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);
                        dataAdapter.Fill(dtManageUser);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtManageUser);
                        response.responseCode = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageUserPrivilege", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass assignroletouser(assignroletouserrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_user_privilege
                                                                        ( 
                                                                            :p_assignedid,:p_empcode,:p_action,:p_companycode,:p_createdby,:p_ipaddress
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.AssignedID))
                            cmd.Parameters.AddWithValue("p_assignedid", DbType.String).Value = request.AssignedID;
                        else
                            cmd.Parameters.AddWithValue("p_assignedid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_empcode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_empcode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CompanyCodes))
                            cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = request.CompanyCodes;
                        else
                            cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CreatedBy))
                            cmd.Parameters.AddWithValue("p_createdby", DbType.String).Value = request.CreatedBy;
                        else
                            cmd.Parameters.AddWithValue("p_createdby", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CreatedIPAddress))
                            cmd.Parameters.AddWithValue("p_ipaddress", DbType.String).Value = request.CreatedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_ipaddress", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("assignroletouser", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetUserPrivilege(assignroletouserrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

                string companycode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_user_privilege
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;




                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();


                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetUserPrivilege", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass AssignProgramManagerAccess(UserAccessMasterRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                string rigthdata = string.Empty;

                if (request.RightDetail!=null && request.RightDetail.Count>0)
                {
                    foreach (var item in request.RightDetail)
                    {
                        if (rigthdata == "")
                        {
                            rigthdata = item.empcode + ":" + item.formid + ":" + item.rightid;
                        }
                        else
                        {
                            rigthdata = rigthdata + "," + item.empcode + ":" + item.formid + ":" + item.rightid;
                        }
                    
                    }

                   
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_program_manager_access
                                                                        ( 
                                                                            :p_access_id,:p_employeecode,:p_accessmode,:pinsertedby,:pinsertedipaddress,:pprogrammanager,:paction,:p_companycode,:p_rightdetail
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.AccessID))
                            cmd.Parameters.AddWithValue("p_access_id", DbType.String).Value = request.AccessID;
                        else
                            cmd.Parameters.AddWithValue("p_access_id", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.AccessMode))
                            cmd.Parameters.AddWithValue("p_accessmode", DbType.String).Value = request.AccessMode;
                        else
                            cmd.Parameters.AddWithValue("p_accessmode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.ProgramManagerEmployeeCode))
                            cmd.Parameters.AddWithValue("pprogrammanager", DbType.String).Value = request.ProgramManagerEmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("pprogrammanager", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("paction", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("paction", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(rigthdata))
                            cmd.Parameters.AddWithValue("p_rightdetail", DbType.String).Value = rigthdata;
                        else
                            cmd.Parameters.AddWithValue("p_rightdetail", DbType.String).Value = DBNull.Value;



                        if (!String.IsNullOrEmpty(request.CompanyCode))
                            cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = request.CompanyCode;
                        else
                            cmd.Parameters.AddWithValue("p_companycode", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees!=null && dtEmployees.Rows.Count>0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);
                        }
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignProgramManagerAccess", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetFormRightData(assignroletouserrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

                string companycode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_form_right_data
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.ProgramManagerEmployeeCode))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.ProgramManagerEmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;




                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();


                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        StringBuilder emailBodyText = new StringBuilder();

                        if (dtEmployees!=null && dtEmployees.Rows.Count>0)
                        {
                            emailBodyText.Append("<thead>");
                            emailBodyText.Append("<tr>");
                            emailBodyText.Append("<th class='text-center' width='40' rowspan='2'>#</th>");
                            emailBodyText.Append("<th class='text-center' rowspan='2'>PM Name</th>");
                            foreach (DataRow item in dtEmployees.Rows)
                            {
                                if (Convert.ToString(item["entitytype"])=="Form")
                                {
                                    emailBodyText.Append("<th colspan='3' class='text-center'>" + Convert.ToString(item["entityname"]) + "</th>");

                                   
                                }
                            }
                            emailBodyText.Append("</tr>");
                            emailBodyText.Append("<tr>");
                            foreach (DataRow item in dtEmployees.Rows)
                            {
                                if (Convert.ToString(item["entitytype"]) == "Form")
                                {
                                  

                                    foreach (DataRow drright in dtEmployees.Rows)
                                    {
                                        
                                        if (Convert.ToString(drright["entitytype"]) == "Right")
                                        {
                                            emailBodyText.Append("<th class='text-center'>" + Convert.ToString(drright["entityname"]) + "</th>");
                                        }
                                        
                                    }
                                }
                            }
                            emailBodyText.Append("</tr>");

                            emailBodyText.Append("</thead>");

                            emailBodyText.Append("<tbody>");

                           

                            int serialno = 1;
                            foreach (DataRow drright in dtEmployees.Rows)
                            {

                                

                                if (Convert.ToString(drright["entitytype"]) == "EMP")
                                {
                                    emailBodyText.Append("<tr>");
                                    emailBodyText.Append("<td class='text-center'>" + serialno + "</td>");

                                    emailBodyText.Append("<td class='text-center'>" + Convert.ToString(drright["entityname"]) + "</td>");


                                    foreach (DataRow drform in dtEmployees.Rows)
                                    {
                                        if (Convert.ToString(drform["entitytype"]) == "Form")
                                        {


                                            foreach (DataRow dredit in dtEmployees.Rows)
                                            {

                                                if (Convert.ToString(dredit["entitytype"]) == "Right")
                                                {
                                                    string chkBoxID = "CHK_" + Convert.ToString(drright["entityid"]) + "_" + Convert.ToString(drform["entityid"]) + "_" + Convert.ToString(dredit["entityid"]);

                                                    DataRow[] result = dtEmployees.Select("entitytype ='RIGHTDETAIL' AND entityid = '" + Convert.ToString(drright["entityid"]) + "' AND entityname = '" + Convert.ToString(drform["entityid"]) + "' AND rightid = '" + Convert.ToString(dredit["entityid"]) + "'");
                                                    if (result!=null && result.Length>0)
                                                    {
                                                        foreach (DataRow row in result)
                                                        {
                                                            if (Convert.ToString(dredit["entityname"]) == "View")
                                                            {
                                                                emailBodyText.Append("<td class='text-center'><input class='form-check-input' checked disabled type='checkbox' value='' id='" + chkBoxID + "'></td>");
                                                            }
                                                            else
                                                            {
                                                                emailBodyText.Append("<td class='text-center'><input class='form-check-input' checked type='checkbox' value='' id='" + chkBoxID + "'></td>");
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (Convert.ToString(dredit["entityname"]) == "View")
                                                        {
                                                            emailBodyText.Append("<td class='text-center'><input class='form-check-input' checked disabled type='checkbox' value='' id='" + chkBoxID + "'></td>");
                                                        }
                                                        else
                                                        {
                                                            emailBodyText.Append("<td class='text-center'><input class='form-check-input' type='checkbox' value='' id='" + chkBoxID + "'></td>");
                                                        }
                                                    }


                                                    

                                                    

                                                    
                                                }

                                            }
                                        }
                                    }

                                    emailBodyText.Append("</tr>");

                                    serialno = serialno + 1;
                                }

                                

                            }

                           
                            emailBodyText.Append("</tbody>");

                            response.responseJSONSecondary = emailBodyText.ToString();
                        }
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetFormRightData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }


        public ResponseClass UserRoleManage(userrolemanagerequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            
            DataTable dtEmployees = new DataTable();

            string pgsqlConnection = appSettings.Value.DbConnection;
            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_remove_user_role
                                                                    ( 
                                                                        :p_action,
                                                                        :p_employeecode,
                                                                        :p_employeerole,
                                                                        :p_actionby,:p_actionipaddress
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.employeecode))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.rolename))
                            cmd.Parameters.AddWithValue("p_employeerole", DbType.String).Value = request.rolename;
                        else
                            cmd.Parameters.AddWithValue("p_employeerole", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.actionby))
                            cmd.Parameters.AddWithValue("p_actionby", DbType.String).Value = request.actionby;
                        else
                            cmd.Parameters.AddWithValue("p_actionby", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.actionipaddress))
                            cmd.Parameters.AddWithValue("p_actionipaddress", DbType.String).Value = request.actionipaddress;
                        else
                            cmd.Parameters.AddWithValue("p_actionipaddress", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                        }

                        npgsqlConnection.Close();

                        //response.responseCode = 1;
                        //response.responseMessage = "Success";
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("UserRoleManage", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

            
        }

        public ResponseClass GetUserProgramManagerData(assignroletouserrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

                string companycode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_userprogrammanager_data
                                                                        ( 
                                                                            :p_employeecode,
                                                                            :p_action
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;




                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();


                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetUserProgramManagerData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable getassigneddepartmentforprogrammanager(string EmpId)
        {
            DataTable dtResult = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                selectQuery = "select A.#DepartmentCode#,B.#CompanyCode# from #UserAccessDetails# A inner join #UserAccessMaster# B on A.#AccessID#=B.#AccessID# where B.#AccessMode#=4 and A.#DeletedFlag#=0 and B.#DeletedFlag#=0 and B.#EmployeeCode#='" + EmpId + "' and #DepartmentCode# is not null;";
                selectQuery = selectQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getassigneddepartmentforprogrammanager", "1024", ex.Message, "Exception");

            }



            return dtResult;

        }


    }
}
