﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.UserManagement
{
    public class LoginRequestBO
    {
        public string UserName { get; set; }
    }

    public class UserRoleRequestDTO
    {
        public string MappingID { get; set; }
        public string Action { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeRole { get; set; }
    }

    public class UserVisitSummaryRequestDTO
    {
        public string EmployeeID { get; set; }
        public string PageName { get; set; }
        public string RoleName { get; set; }
    }

    public class setDefaultRole
    {
        public string RoleName { get; set; }
        public string EmployeeID { get; set; }
    }

    public class insertSiteDataRequestDTO
    {
        public string EmployeeCode { get; set; }
        public string RoleMasterName { get; set; }
        public string Platform { get; set; }
        public string Browser { get; set; }
        public string IPAddress { get; set; }
        public string SessionID { get; set; }
        public string Action { get; set; }
    }

    public class profilepicrequestDTO
    {
        public string EmployeeCode { get; set; }
        public string PICPath { get; set; }
    }

    public class allowEmailDTO
    {
        public string EmailID { get; set; }
        public string RequestedBy { get; set; }
        public string RequestedDate { get; set; }
        public string EmailRemarks { get; set; }
        public string AccessExpireOn { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string UserEmailId { get; set; }
        public string UserEmailRoleName { get; set; }
        public string UserCompanyCode { get; set; }
        public string EmailFirstName { get; set; }
        public string EmailLastName { get; set; }
    }

    public class addUserDTO
    {
        public string LMSRoleID { get; set; }
        public string LMSRoleName { get; set; }
        public string EmployeeID { get; set; }
        public string EmployeeFName { get; set; }
        public string EmployeeLName { get; set; }
        public string EmployeeFullName { get; set; }
        public string EmployeeDesgination { get; set; }
        public string EmployeeRoleName { get; set; }
        public string EmployeeRoleNameCompanyCode { get; set; }
        public string EmployeeRoleId { get; set; }
        public string EmployeeRoleMasterId { get; set; }
        public string EmployeeMapId { get; set; }
        public string EmployeeCreatedBy { get; set; }
    }

    public class searchUserDTO
    {
        public string EmployeeFullName { get; set; }
        public string EmployeeLoginID { get; set; }
        public string EmployeeEmailID { get; set; }
        public string EmployeeCity { get; set; }
        public string currentRole { get; set; }
        public string currentEmployee { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public string CompanyCode { get; set; }

        public string DepartmentCode { get; set; }
    }

    public class addPMProxyUser
    {
        public string ProxyBy { get; set; }
        public string ProxyGeo { get; set; }
        public string ProxyByRoleName { get; set; }
        public string ProxyFor { get; set; }
        public string PUMID { get; set; }
        public string ProxyCraetedBy { get; set; }
        public string ProxyModifiedBy { get; set; }
    }

    public class ProxyUserLog
    {
        public string ProxyBy { get; set; }
        public string ProxyFor { get; set; }
        public string ProxyDate { get; set; }
    }

    public class assignroletouserrequestDTO
    {
        public string AssignedID { get; set; }
        public string EmployeeID { get; set; }

        public string Action { get; set; }

        public string CompanyCodes { get; set; }

        public string CreatedBy { get; set; }

        public string CreatedIPAddress { get; set; }

        public string ProgramManagerEmployeeCode { get; set; }
    }

    public class   UserAccessMasterRequestDTO
    {
        public string AccessID { get; set; }
        public string EmployeeCode { get; set; }
        public string AccessMode { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

        public string CompanyCode { get; set;}

        public string ProgramManagerEmployeeCode { get; set; }

        public string Action { get; set; }

        public List<RightList> RightDetail { get; set; }
    }

    public class UserAccessDetail
    {
        public string AccessID { get; set; }
        public string ProgramManagerEmployeeCode { get; set; }
        public string InsertedBy { get; set; }
       
    }

    public class RightList
    {
        public string empcode { get; set; }

        public string formid { get; set; }

        public string rightid { get; set; }
    }

    public class userrolemanagerequestDTO
    {
        public string action { get; set; }
        public string employeecode { get; set; }

        public string rolename { get; set; }
        public string actionby { get; set; }
        public string actionipaddress { get; set; }
    }
}
