﻿using System.Data;
using TLDCBAL.Common;

namespace TLDCBAL.UserManagement
{
    public interface IUserManagementBL
    {
        ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO);
        ResponseClass getUserRoles(UserRoleRequestDTO request);
        ResponseClass deleteRole(UserRoleRequestDTO request);
        ResponseClass addVisitSummary(UserVisitSummaryRequestDTO request);

        ResponseClass setDefaultRole(setDefaultRole request);
        ResponseClass InsertSiteLoginData(insertSiteDataRequestDTO request);
        ResponseClass updateProfilePIC(profilepicrequestDTO request);


        ResponseClass getAllowEmailDetails();
        ResponseClass addAllowEmail(allowEmailDTO request);
        ResponseClass deleteAllowEmail(allowEmailDTO request);
        ResponseClass getEditAllowEmailDetails(allowEmailDTO request);
        ResponseClass updateEditAllowEmailDetails(allowEmailDTO request);

        ResponseClass getLMSRoleDetails();
        ResponseClass getJobRoleDetails();
        ResponseClass addUserDetails(addUserDTO request);
        ResponseClass getManageUserDetails();
        ResponseClass deleteManageUser(addUserDTO request);
        ResponseClass editUserDetails(addUserDTO request);
        ResponseClass updateUserDetails(addUserDTO request);
        ResponseClass getSearchManageUserDetails(searchUserDTO request);
        ResponseClass getLMSRoleCompanyDetails();

        ResponseClass getPMProxyDeatils(addPMProxyUser request);
        ResponseClass deletePMProxyDeatils(addPMProxyUser request);
        ResponseClass addPMProxyDeatils(addPMProxyUser request);
        ResponseClass getLogProxyDeatils();
        ResponseClass getSearchLogProxyDeatils(ProxyUserLog request);
        ResponseClass addLogProxyDeatils(ProxyUserLog request);
        ResponseClass getAdminProxyDeatils(addPMProxyUser request);
        ResponseClass deleteAdminProxyDeatils(addPMProxyUser request);
        ResponseClass addAdminProxyDeatils(addPMProxyUser request);

        ResponseClass ManageUserPrivilege(searchUserDTO request);

        ResponseClass assignroletouser(assignroletouserrequestDTO request);

        ResponseClass GetUserPrivilege(assignroletouserrequestDTO request);

        ResponseClass AssignProgramManagerAccess(UserAccessMasterRequestDTO request);

        ResponseClass GetFormRightData(assignroletouserrequestDTO request);

        ResponseClass UserRoleManage(userrolemanagerequestDTO request);

        ResponseClass GetUserProgramManagerData(assignroletouserrequestDTO request);

        DataTable getassigneddepartmentforprogrammanager(string EmpId);
    }
}