﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.MobApp
{
    public class getuserprofileDetailsRequestDTO
    {
        public string EmployeeID { get; set; }
        public string Action { get; set; }
        public string ModuleID { get; set; }
        public string EventCode { get; set; }
    }

    public class updatemoduleacknowledgestatusrequestDTO
    {
        public string parentmoduleid { get; set; }
        public string childmoduleid { get; set; }
        public string UserName { get; set; }
        
        public string Action { get; set; }
        public string LearningStartDate { get; set; }
        public string LearningEndDate { get; set; }
        public int TotalDurationSecond { get; set; }
    }

    public class requestencryptdecrypt
    {
        public string inputstring { get; set; }
    }
}
