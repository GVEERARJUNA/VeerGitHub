﻿using TLDCBAL.Common;
using TLDCBAL.ProgramManager;

namespace TLDCBAL.MobApp
{
    public interface IMOBAPPBL
    {
        ResponseClass GetUserProfile(getuserprofileDetailsRequestDTO request);
        ResponseClass GetUserTaskCount(getuserprofileDetailsRequestDTO request);

        ResponseClass GetUserTaskList(getuserprofileDetailsRequestDTO request);

        ResponseClass GetModuleDetails(getuserprofileDetailsRequestDTO request);

        ResponseClass UpdateModuleAcknowledgeStatus(updatemoduleacknowledgestatusrequestDTO request);

        ResponseClass PushSurveyResult(pushSurveyResultrequestDTO request);
    }
}