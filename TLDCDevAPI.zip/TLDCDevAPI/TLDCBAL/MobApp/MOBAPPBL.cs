﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.ProgramManager;
using TLDCBAL.Qualtrics;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.MobApp
{
    public class MOBAPPBL : IMOBAPPBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> _appSettings;

        private ISchedulerBL _scheduleBL;

        

        public MOBAPPBL(IServiceConnect serviceconnect, IOptions<IDBConnection> appSettings, ISchedulerBL scheduleBL)
        {
            _serviceconnect = serviceconnect;
            _appSettings = appSettings;
            _scheduleBL = scheduleBL;
            
        }

        public ResponseClass GetUserProfile(getuserprofileDetailsRequestDTO request)
        {

            ResponseClass response = new ResponseClass();

            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = _appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM mob_get_user_profile
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetUserProfile-MobileAPI", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetUserTaskCount(getuserprofileDetailsRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = _appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM mob_get_task_count
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetUserTaskCount-MobileAPI", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetUserTaskList(getuserprofileDetailsRequestDTO request)
        {

            ResponseClass response = new ResponseClass();

            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            if (string.IsNullOrEmpty(request.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "action required!";
                return response;
            }

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = _appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM mob_get_task_list
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetUserTaskList-MobileAPI", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetModuleDetails(getuserprofileDetailsRequestDTO request)
        {

            ResponseClass response = new ResponseClass();

            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            if (string.IsNullOrEmpty(request.ModuleID))
            {
                response.responseCode = 0;
                response.responseMessage = "module id required!";
                return response;
            }

            if (string.IsNullOrEmpty(request.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "action required!";
                return response;
            }

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = _appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM mob_get_module_details
                                                                        ( 
                                                                            :p_username,:p_eventcode,:p_moduleid,:p_action

                                                                            
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.ModuleID))
                            cmd.Parameters.AddWithValue("p_moduleid", DbType.String).Value = request.ModuleID;
                        else
                            cmd.Parameters.AddWithValue("p_moduleid", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetModuleDetails-MobileAPI", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass UpdateModuleAcknowledgeStatus(updatemoduleacknowledgestatusrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtResult = new DataTable();
            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request is required";
                return response;
            }
            if (string.IsNullOrEmpty(request.UserName))
            {
                response.responseCode = 0;
                response.responseMessage = "UserName required";
                return response;
            }
            if (string.IsNullOrEmpty(request.parentmoduleid))
            {
                response.responseCode = 0;
                response.responseMessage = "parentmoduleid required";
                return response;
            }
            if (string.IsNullOrEmpty(request.childmoduleid))
            {
                response.responseCode = 0;
                response.responseMessage = "childmoduleid required";
                return response;
            }
            if (string.IsNullOrEmpty(request.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "Action required";
                return response;
            }
           
            if (string.IsNullOrEmpty(request.LearningStartDate))
            {
                response.responseCode = 0;
                response.responseMessage = "LearningStartDate required";
                return response;
            }
            if (string.IsNullOrEmpty(request.LearningEndDate))
            {
                response.responseCode = 0;
                response.responseMessage = "LearningEndDate required";
                return response;
            }

            string learningstartDate = string.Empty;
            string learningendDate = string.Empty;
            try
            {
                learningstartDate = Convert.ToDateTime(request.LearningStartDate).ToString("yyyy-MM-dd HH:mm:ss");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("UpdateModuleAcknowledgeStatus-MobileAPI", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid AssessmentStartDate";
                return response;


            }

            try
            {
                learningendDate = Convert.ToDateTime(request.LearningEndDate).ToString("yyyy-MM-dd HH:mm:ss");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("UpdateModuleAcknowledgeStatus-MobileAPI", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid Assessment";
                return response;


            }


            string pgsqlConnection = _appSettings.Value.DbConnection;

            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {

                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM mob_update_module_acknowledgestatus
                                                                    ( 
                                                                        :p_parentmoduleid,
                                                                        :p_childmoduleid,
                                                                        :p_employeecode,
                                                                        :p_action,
                                                                      
                                                                        :p_startdate,
                                                                        :p_enddate,
                                                                        :p_totalduration
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.parentmoduleid))
                            cmd.Parameters.AddWithValue("p_parentmoduleid", DbType.String).Value = request.parentmoduleid;
                        else
                            cmd.Parameters.AddWithValue("p_parentmoduleid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.childmoduleid))
                            cmd.Parameters.AddWithValue("p_childmoduleid", DbType.String).Value = request.childmoduleid;
                        else
                            cmd.Parameters.AddWithValue("p_childmoduleid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        

                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                       

                        if (!String.IsNullOrEmpty(learningstartDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = learningstartDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(learningendDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = learningendDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_totalduration", DbType.String).Value = request.TotalDurationSecond;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtResult);
                        npgsqlConnection.Close();
                       
                        response.responseJSON = JsonConvert.SerializeObject(dtResult);

                        if (dtResult.Rows.Count > 0 && dtResult != null)
                        {
                            try
                            {
                                var scResponse = _scheduleBL.AssignFSTLAssignment();
                            }
                            catch (Exception)
                            {


                            }

                            try
                            {
                                var scResponse = _scheduleBL.AssignDIAssessment();
                            }
                            catch (Exception)
                            {


                            }

                            try
                            {
                                var scResponse = _scheduleBL.ProjectFrameworkAssessment();
                            }
                            catch (Exception)
                            {


                            }


                        }
                    }
                }


                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
                return response;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("UpdateModuleAcknowledgeStatus-MobileAPI", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                // LogException.Log(ex.Message);
                return response;
            }




        }

        public ResponseClass PushSurveyResult(pushSurveyResultrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (string.IsNullOrEmpty(request.AllocationID))
            {
                response.responseCode = 0;
                response.responseMessage = "Allocation id required!";
            }

            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = _appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                string learningstartDate = string.Empty;
                string learningendDate = string.Empty;

                if (!string.IsNullOrEmpty(request.SurveyStartDate))
                {
                    try
                    {
                        learningstartDate = Convert.ToDateTime(request.SurveyStartDate).ToString("yyyy-MM-dd HH:mm:ss");

                    }
                    catch (Exception)
                    {


                    }
                }
                if (!string.IsNullOrEmpty(request.SurveyEndDate))
                {
                    try
                    {
                        learningendDate = Convert.ToDateTime(request.SurveyEndDate).ToString("yyyy-MM-dd HH:mm:ss");

                    }
                    catch (Exception)
                    {


                    }
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM update_event_survey_result_mobile
                                                                        ( 
                                                                            :p_allocationid,
                                                                            :p_completionstatus,:p_startdate,:p_enddate,:p_totalquestion,:p_totalsubmitted
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.AllocationID))
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = request.AllocationID;
                        else
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = string.Empty;


                        cmd.Parameters.AddWithValue("p_completionstatus", DbType.Int32).Value = Convert.ToInt32(request.completionStatus);

                        if (!String.IsNullOrEmpty(learningstartDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = learningstartDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(learningendDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = learningendDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_totalquestion", DbType.String).Value = request.TotalQuestion;
                        cmd.Parameters.AddWithValue("p_totalsubmitted", DbType.String).Value = request.TotalSubmitted;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                            if (response.responseCode == 1)
                            {
                                try
                                {
                                    var scResponse = _scheduleBL.SendFSTLCertificateEmail();
                                }
                                catch (Exception ex)
                                {

                                    _serviceconnect.LogConnect("PushSurveyResult", "1024", ex.Message, "Exception");
                                }
                            }


                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("PushSurveyResult", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            return response;
        }
    }
}
