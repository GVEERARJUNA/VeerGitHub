﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.Common
{
   public class LogWrite
    {
        public string ApplicationName { get; set; }
        public string PageName { get; set; }
        public string LogCode { get; set; }
        public string LogMessage { get; set; }
        public string LogDate { get; set; }
        public string LogCategory { get; set; }         //"LogDate":"2019-04-19 10:33:15", "LogCategory":"Exception"
    }

    public class getAssessmentListRequestDTO
    {
        public string Geo { get; set; }
        public string EmpCode { get; set; }
        public string RoleName { get; set; }
        public string CompanyCode { get; set; }
    }
    public class getSurveyListRequestDTO
    {
        public string Geo { get; set; }
        public string LoggedInEmployeeId { get; set; }
        public string RoleName { get; set; }
        public string CompanyCode { get; set; }
        public string TemplateId { get; set; }
    }
}
