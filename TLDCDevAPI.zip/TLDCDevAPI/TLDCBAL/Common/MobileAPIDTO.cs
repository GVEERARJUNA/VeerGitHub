﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.Common
{
    public class MOBAPPRequest
    {
        public string input { get; set; }
    }
    public class ResponseClassMobile
    {
        public string output { get; set; }
    }
}
