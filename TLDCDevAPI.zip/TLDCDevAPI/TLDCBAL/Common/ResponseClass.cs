﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace TLDCBAL.Common
{
   public class ResponseClass
    {
        public int responseCode { get; set; }
        public string responseMessage { get; set; }

        public object responseJSON { get; set; }

        public object responseJSONSecondary { get; set; }

        public object responseJSONThird { get; set; }

        public DataTable dtresponse { get; set; }

        public int recordCount { get; set; }

        public string responseReturnNo { get; set; }

    }
}
