﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace TLDCBAL.Common
{
    public static class EncryptDecryptAES
    {
        public static string EncryptStringAES(string plaintext)
        {

            string key = "2806354984092123";
            //string key = "7588133853096069";
            TripleDESCryptoServiceProvider desProvider = new TripleDESCryptoServiceProvider();
            MD5CryptoServiceProvider md5Provider = new MD5CryptoServiceProvider();

            desProvider.Key = md5Provider.ComputeHash(Encoding.Unicode.GetBytes(key));
            desProvider.Mode = CipherMode.ECB;

            ICryptoTransform desEncrypt = desProvider.CreateEncryptor();
            byte[] buffer = Encoding.Unicode.GetBytes(plaintext);

            byte[] tdesBytes = desEncrypt.TransformFinalBlock(buffer, 0, buffer.Length);
            string finalString = Convert.ToBase64String(tdesBytes);

            return finalString;
        }

        public static string DecryptStringAES(string encodedText)
        {
            string key = "2806354984092123";
            TripleDESCryptoServiceProvider desCryptoProvider = new TripleDESCryptoServiceProvider();
            MD5CryptoServiceProvider hashMD5Provider = new MD5CryptoServiceProvider();

            byte[] byteHash;
            byte[] byteBuff;

            byteHash = hashMD5Provider.ComputeHash(Encoding.Unicode.GetBytes(key));
            //byteHash = hashMD5Provider.ComputeHash(Encoding.UTF8.GetBytes(key));
            desCryptoProvider.Key = byteHash;
            desCryptoProvider.Mode = CipherMode.ECB; //CBC, CFB
            string _encodedText = HttpUtility.UrlDecode(encodedText).Replace(" ", "+");
            byteBuff = Convert.FromBase64String(_encodedText);
            // byteBuff = Convert.FromBase64String(encodedText);

            string plaintext = Encoding.Unicode.GetString(desCryptoProvider.CreateDecryptor().TransformFinalBlock(byteBuff, 0, byteBuff.Length));
            return plaintext;
        }

        public static DateTime ConvertTimeZone(DateTime Time, string Zone)
        {

            if (Zone == "EST")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                // DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }
            else if (Zone == "UTC")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time");
                // DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }
            else if (Zone == "PST")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("W. Australia Standard Time");
                //DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }
            else if (Zone == "COT")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("SA Pacific Standard Time");
                // DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }
            else if (Zone == "CST")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
                //DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }
            else if (Zone == "IST")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                //DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }

            else if (Zone == "EDT")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("SA Western Standard Time");
                //  DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }

            else if (Zone == "CDT")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("SA Pacific Standard Time");
                // DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }

            else if (Zone == "MDT")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("Central America Standard Time");
                //DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }
            else if (Zone == "MST")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("US Mountain Standard Time");
                //DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }

            else if (Zone == "PDT")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time");
                //DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }

            else if (Zone == "AST")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("Hawaiian Standard Time");
                //DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);
                DateTime newTime = TimeZoneInfo.ConvertTimeToUtc(Time, timeZone1);

                return newTime;
            }
            else
            {
                return Time;
            }
            //DateTime timeUtc = Convert.ToDateTime(Time);

        }

    }
}
