﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;
using static TLDCBAL.Module.ModuleDTO;

namespace TLDCBAL.Module
{
    public interface IModuleBL
    {

        ResponseClass GetMasterBusinessType();

        ResponseClass GetMasterModuleOnBusinessTypeCode(ModuleBusinssType response);
        ResponseClass GetJoiningConfig(ModuleJoiningConfigFilters request);
        ResponseClass InsertJoiningConfig(ModuleSaveJoiningConfig request);
        ResponseClass ValidateUploadFile(ValidateData request);
        ResponseClass InsertYearConfig(ModuleSaveYearDepartmentConfig request);
        ResponseClass GetUploadConfigData(FiltersforUploadDataConfig request);
        public ResponseClass GetManualUploadConfig(FiltersforManualUploadDataConfig request);
    }
}
