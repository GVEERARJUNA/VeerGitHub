﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.Module
{
    public class ModuleDTO
    {
        public class ModuleBusinssType
        {
            public string BusinessTypeCode { get; set; }
        }

        public class ModuleJoiningConfigFilters
        {
            public string ModuleCode { get; set; }
            public string DepartmentCode { get; set; }
            public string CompanyCode { get; set; }

        }
        public class ModuleSaveJoiningConfig
        {
            public string[] ModuleCode { get; set; }
            public string[] DepartmentCode { get; set; }
            public string[] CompanyCode { get; set; }
            public string[] PostJoiningDays { get; set; }
            public string[] ExpiryDays { get; set; }
            public string[] ModuleConfigID { get; set; }

            public int[] PostJoiningDaysint { get; set; }
            public int[] ExpiryDaysint { get; set; }
            public int[] ModuleConfigIDint { get; set; }

            public string CreatedBy { get; set; }
            public DateTime CreatedOn { get; set; }
            public string CreatedIpAddress { get; set; }
        }


        public class ValidateData
        {
            public string CompanyCode { get; set; }
            public string ModuleCode { get; set; }
            public string[] DepartmentCode { get; set; }
            public string[] Year { get; set; }
            public string[] SubProcessCode { get; set; }
            public string[] StartDates { get; set; }
            public string[] EndDates { get; set; }
        }

        public class ModuleSaveYearDepartmentConfig
        {
            public string[] DepartmentCode { get; set; }
            public string[] Year { get; set; }
            public string[] SubProcessCode { get; set; }
            public string[] CompanyCode { get; set; }
            public string[] ModuleCode { get; set; }
            public string[] StartDate { get; set; }
            public string[] EndDate { get; set; }
            public string CreatedBy { get; set; }
            public DateTime CreatedOn { get; set; }
            public string CreatedIpAddress { get; set; }
    

        }
        public class FiltersforUploadDataConfig
        {
            public string ModuleCode { get; set; }
            public string DepartmentCode { get; set; }
            public string CompanyCode { get; set; }

        }

        public class FiltersforManualUploadDataConfig
        {
            public string ModuleCode { get; set; }

            public string CompanyCode { get; set; }
            public string DepartmentCode { get; set; }
            public string SubprocessCode { get; set; }
            public string Year { get; set; }


        }


    }
}
