﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCDAL;
using static TLDCBAL.Module.ModuleDTO;

namespace TLDCBAL.Module
{
    public class ModuleBL : IModuleBL
    {
        private readonly IOptions<IDBConnection> appSettings;
        private readonly IServiceConnect _serviceconnect;
        private IQualtricsDataBL _qualtricsBL;
        DBConnection dBConnection;

        public ModuleBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass GetMasterBusinessType()
        {
            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();
            try
            {


                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_businesstype
                                                                    ( 
                                                                       
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);
                        response.responseJSON = JsonConvert.SerializeObject(dtData);

                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";

                
            }
            catch(Exception ex)
            {
                _serviceconnect.LogConnect("GetMasterBusinessType", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }




        public ResponseClass GetMasterModuleOnBusinessTypeCode(ModuleBusinssType request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();
            try
            {


               
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_modulemaster
                                                                    ( 
                                                                       :p_business_type_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.BusinessTypeCode))
                            cmd.Parameters.AddWithValue("p_business_type_code", DbType.String).Value = request.BusinessTypeCode;
                        else
                            cmd.Parameters.AddWithValue("p_business_type_code", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);
                        response.responseJSON = JsonConvert.SerializeObject(dtData);
                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch(Exception ex)
            {
                _serviceconnect.LogConnect("GetMasterModuleOnBusinessTypeCode", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetJoiningConfig(ModuleJoiningConfigFilters request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();
            try
            {



                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM get_joiners_module_config
                                                                    ( 
                                                                       :module_code,
:company_code,
:department_code
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ModuleCode))
                            cmd.Parameters.AddWithValue("module_code", DbType.String).Value = request.ModuleCode;
                        else
                            cmd.Parameters.AddWithValue("module_code", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CompanyCode))
                            cmd.Parameters.AddWithValue("company_code", DbType.String).Value = request.CompanyCode;
                        else
                            cmd.Parameters.AddWithValue("company_code", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.DepartmentCode))
                            cmd.Parameters.AddWithValue("department_code", DbType.String).Value = request.DepartmentCode;
                        else
                            cmd.Parameters.AddWithValue("department_code", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);
                        response.responseJSON = JsonConvert.SerializeObject(dtData);
                        DataTable DepTable = _qualtricsBL.GetDepartmentDataTable(request.CompanyCode,request.DepartmentCode);

                        // assuming your first DataTable is named "dt1" and second DataTable is named "dt2"
                        // creating a new DataTable to hold the merged results
                        DataTable dtResult = new DataTable();
                        // adding columns to the merged DataTable
                        dtResult.Columns.Add("ModuleConfigId", typeof(int));
                        dtResult.Columns.Add("ModuleCode", typeof(string));
                        dtResult.Columns.Add("CompanyCode", typeof(string));
                        dtResult.Columns.Add("DepartmentCode", typeof(string));
                        dtResult.Columns.Add("CompanyName", typeof(string));
                        dtResult.Columns.Add("DepartmentName", typeof(string));
                        dtResult.Columns.Add("ExpiryDays", typeof(string));
                        dtResult.Columns.Add("PostJoiningDays", typeof(string));

                        // assuming "some other columns" have same names in both tables, add them here too

                        // iterating over the rows of the first DataTable
                        foreach (DataRow dr1 in dtData.Rows)
                        {
                            // finding the matching row from the second DataTable based on CompanyCode and DepartmentCode
                            DataRow[] matchingRows = DepTable.Select("COMPANY_CODE = '" + dr1["CompanyCode"] + "' AND Department_Code = '" + dr1["DepartmentCode"] + "'");
                            // iterating over the matching rows and adding them to the merged DataTable
                            foreach (DataRow dr2 in matchingRows)
                            {
                                DataRow drResult = dtResult.NewRow();
                                drResult["ModuleConfigId"] = dr1["ModuleConfigId"];
                                drResult["ModuleCode"] = dr1["ModuleCode"];
                                drResult["CompanyCode"] = dr1["CompanyCode"];
                                drResult["DepartmentCode"] = dr1["DepartmentCode"];
                                drResult["CompanyName"] = dr2["Company_Name"];
                                drResult["DepartmentName"] = dr2["DEPARTMENT"];
                                drResult["ExpiryDays"] = dr1["ExpiryDays"];
                                drResult["PostJoiningDays"] = dr1["PostJoiningDays"];

                                // assuming "some other columns" have same names in both tables, add them here too
                                dtResult.Rows.Add(drResult);
                            }
                        }

                        // iterating over the rows of the second DataTable to find the rows that didn't have matches in the first DataTable
                        foreach (DataRow dr2 in DepTable.Rows)
                        {
                            DataRow[] matchingRows = dtData.Select("CompanyCode = '" + dr2["COMPANY_CODE"] + "' AND DepartmentCode = '" + dr2["Department_Code"] + "'");
                            // if there are no matching rows in the first DataTable, add a new row to the merged DataTable
                            if (matchingRows.Length == 0)
                            {
                                DataRow drResult = dtResult.NewRow();
                                drResult["ModuleConfigId"] = 0;
                                drResult["ModuleCode"] = request.ModuleCode; // assuming you want to use DepartmentCode as ModuleCode for unmatched rows
                                drResult["CompanyCode"] = dr2["COMPANY_CODE"];
                                drResult["DepartmentCode"] = dr2["Department_Code"];
                                drResult["CompanyName"] = dr2["Company_Name"];
                                drResult["DepartmentName"] = dr2["DEPARTMENT"];
                                drResult["ExpiryDays"] =0;
                                drResult["PostJoiningDays"] = 0;
                                // assuming "some other columns" have same names in both tables, add them here too
                                dtResult.Rows.Add(drResult);
                            }
                        }

                        // the merged DataTable is now ready, you can use it as needed

                        response.responseJSON = JsonConvert.SerializeObject(dtResult);



                    }
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetMasterModuleOnBusinessTypeCode", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass InsertJoiningConfig(ModuleSaveJoiningConfig request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();

            try
            {
                if (!ValidateInput(request,out string errmsg))
                {

                    response.responseCode = 0;
                    response.responseMessage = errmsg;
                    return response;
                }
                for (int i = request.ModuleConfigID.Length - 1; i >= 0; i--)
                {
                    if (request.ExpiryDays[i] == "0")
                    {
                        // remove element from all arrays at index i
                        request.ModuleCode = request.ModuleCode.Take(i).Concat(request.ModuleCode.Skip(i + 1)).ToArray();
                        request.DepartmentCode = request.DepartmentCode.Take(i).Concat(request.DepartmentCode.Skip(i + 1)).ToArray();
                        request.CompanyCode = request.CompanyCode.Take(i).Concat(request.CompanyCode.Skip(i + 1)).ToArray();
                        request.PostJoiningDays = request.PostJoiningDays.Take(i).Concat(request.PostJoiningDays.Skip(i + 1)).ToArray();
                        request.ExpiryDays = request.ExpiryDays.Take(i).Concat(request.ExpiryDays.Skip(i + 1)).ToArray();
                        request.ModuleConfigID = request.ModuleConfigID.Take(i).Concat(request.ModuleConfigID.Skip(i + 1)).ToArray();

                    }
                }
                request.PostJoiningDaysint= request.PostJoiningDays.Select(s => int.TryParse(s, out int result) ? result : 0).ToArray();
                request.ExpiryDaysint = request.ExpiryDays.Select(s => int.TryParse(s, out int result) ? result : 0).ToArray();
                request.ModuleConfigIDint = request.ModuleConfigID.Select(s => int.TryParse(s, out int result) ? result : 0).ToArray();

                string pgsqlConnection = appSettings.Value.DbConnection;







                string functionCall = "SELECT fn_insert_JoiningConfig(@ModuleCode, @ModuleConfigID, @CompanyCode, @DepartmentCode, @PostJoiningDays, @ExpiryDays, @CreatedOn, @CreatedBy, @CreatedIPAddress)";

                // Define the connection string

                // Define the parameters
               

                // Create a connection to the database
                using (var connection = new NpgsqlConnection(pgsqlConnection))
                {
                    connection.Open();

                    // Create a command to execute the function call
                    using (var command = new NpgsqlCommand(functionCall, connection))
                    {
                        // Add the parameters to the command
                        command.Parameters.AddWithValue("ModuleCode", request.ModuleCode.FirstOrDefault().ToString());
                        command.Parameters.AddWithValue("ModuleConfigID", request.ModuleConfigIDint);
                        command.Parameters.AddWithValue("CompanyCode", request.CompanyCode);
                        command.Parameters.AddWithValue("DepartmentCode", request.DepartmentCode);
                        command.Parameters.AddWithValue("PostJoiningDays", request.PostJoiningDaysint);
                        command.Parameters.AddWithValue("ExpiryDays", request.ExpiryDaysint);
                        command.Parameters.AddWithValue("CreatedOn", request.CreatedOn);
                        command.Parameters.AddWithValue("CreatedBy", request.CreatedBy);
                        command.Parameters.AddWithValue("CreatedIPAddress", request.CreatedIpAddress);

                        // Execute the function call
                        command.ExecuteNonQuery();
                    }
                    connection.Close();

                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch(Exception ex)
            {
                _serviceconnect.LogConnect("InsertJoiningConfig", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public bool ValidateInput(ModuleSaveJoiningConfig request,out string errormessage)
        {

            if (request.ExpiryDays.Length == 0)
            {
                errormessage = "ExpiryDays error.";
                return false;
            }
            if (request.ModuleCode.Length == 0)
            {
                errormessage = "ModuleCode error.";
                return false;
            }
            if (request.DepartmentCode.Length == 0)
            {
                errormessage = "DepartmentCode error.";
                return false;
            }
            if (request.CompanyCode.Length == 0)
            {
                errormessage = "CompanyCode error.";
                return false;
            }
            if (request.PostJoiningDays.Length == 0)
            {
                errormessage = "PostJoiningDays error.";
                return false;
            }
            if (request.ModuleConfigID.Length == 0)
            {
                errormessage = "ModuleConfigID error.";
                return false;
            }
            if (string.IsNullOrEmpty(request.CreatedBy))
            {
                errormessage = "CreatedBy error.";
                return false;
            }
          
         
            errormessage = "";
            return true;

        }


        public ResponseClass ValidateUploadFile(ValidateData request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable DtTable = new DataTable();
                DataTable RDataTable = new DataTable();
                DtTable = _qualtricsBL.GetDepartmentDataTable(request.CompanyCode,null);
                RDataTable.Columns.Add("Department", typeof(string));
                RDataTable.Columns.Add("DepartmentCode", typeof(string));
                RDataTable.Columns.Add("SubProcess", typeof(string));
                RDataTable.Columns.Add("SubProcessCode", typeof(string));
                RDataTable.Columns.Add("Year", typeof(string));
                RDataTable.Columns.Add("ModuleCode", typeof(string));
                RDataTable.Columns.Add("CompanyCode", typeof(string));
                RDataTable.Columns.Add("StartDate", typeof(string));
                RDataTable.Columns.Add("EndDate", typeof(string));


                for (int i = 0; i < request.DepartmentCode.Length; i++)
                {
                    // Check if the Department exists in the data table
                    DataRow[] rows = DtTable.Select("Department_Code = '" + request.DepartmentCode[i] + "' AND Sub_Process_Code = '" + request.SubProcessCode[i] + "'");
                    if (rows.Length > 0)
                    {
                        // Get the Department code from the data table
                        string departmentName = rows[0]["DEPARTMENT"].ToString();
                        string subprocessname = rows[0]["Sub_Process"].ToString();

                        // Add the row to the data table
                        DataRow row = RDataTable.NewRow();
                        row["Department"] = departmentName;
                        row["DepartmentCode"] = request.DepartmentCode[i];
                        row["Year"] = request.Year[i];
                        row["SubProcess"] = subprocessname;
                        row["SubProcessCode"] = request.SubProcessCode[i];
                        row["ModuleCode"] = request.ModuleCode;
                        row["CompanyCode"] = request.CompanyCode;
                        DateTime dateValue;

                        if (DateTime.TryParseExact(request.StartDates[i], "dd-MMM-yyyy",
                            CultureInfo.InvariantCulture,
                            DateTimeStyles.None,
                            out dateValue) && (DateTime.TryParseExact(request.EndDates[i], "dd-MMM-yyyy",
                            CultureInfo.InvariantCulture,
                            DateTimeStyles.None,
                            out dateValue)) )
                        {



                            row["StartDate"] = DateTime.ParseExact(request.StartDates[i], "dd-MMM-yyyy", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");
                            row["EndDate"] = DateTime.ParseExact(request.EndDates[i], "dd-MMM-yyyy", CultureInfo.InvariantCulture).ToString("dd/MM/yyyy");

                            RDataTable.Rows.Add(row);
                        }

                       
                    }
                }
                response.responseJSON = JsonConvert.SerializeObject(RDataTable);


                response.responseCode = 1;
                response.responseMessage = "Success";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("InsertJoiningConfig", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass InsertYearConfig(ModuleSaveYearDepartmentConfig request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                if (!ValidateUploadData(request,out string errmsg))
                {
                    response.responseMessage = errmsg;
                    response.responseCode = 0;
                    return response;
                }
                List<string> depList = new List<string>(request.DepartmentCode);
                //List<string> subpList = new List<string>(request.SubProcessCode);
                List<string> yearList = new List<string>(request.Year);
                //List<DateTime> FromDate = request.StartDate.Select(date => DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture)).ToList();
                //List<DateTime> ToDate = request.EndDate.Select(date => DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture)).ToList();
                List<string> FromDate = new List<string>(request.StartDate);
                List<string> ToDate = new List<string>(request.EndDate);


                for (int i = depList.Count - 1; i >= 0; i--)
                {
                    if (depList[i] == null)
                    {
                        depList.RemoveAt(i);
                       // subpList.RemoveAt(i);
                        yearList.RemoveAt(i);
                        FromDate.RemoveAt(i);
                        ToDate.RemoveAt(i);

                    }
                }
                //for (int i = subpList.Count - 1; i >= 0; i--)
                //{
                //    if (subpList[i] == null)
                //    {
                //        depList.RemoveAt(i);
                //        subpList.RemoveAt(i);
                //        yearList.RemoveAt(i);
                //        FromDate.RemoveAt(i);
                //        ToDate.RemoveAt(i);

                //    }
                //}
                request.DepartmentCode = depList.ToArray();
                request.Year = yearList.ToArray();
                //request.SubProcessCode = subpList.ToArray();
                request.StartDate = FromDate.ToArray();
                request.EndDate = ToDate.ToArray();

                //List<int> monthsList = new List<int>();

                //for (int i = 0; i < request.Month.Length; i++)
                //{
                //    int monthAsNumber;
                //    if (DateTime.TryParseExact(request.Month[i], "MMM", null, System.Globalization.DateTimeStyles.None, out DateTime date))
                //    {
                //        monthAsNumber = date.Month;
                //        monthsList.Add(monthAsNumber);
                //    }
                //}
                //int[] monthsArray = monthsList.ToArray();
                List<int> yearsList = new List<int>();
                for (int i = 0; i < request.Year.Length; i++)
                {
                    int year;
                    if (int.TryParse(request.Year[i], out year))
                    {
                        yearsList.Add(year);
                    }
                }
                int[] yearsArray = yearsList.ToArray();
                //if(request.SubProcessCode.Length!=request.DepartmentCode.Length && request.SubProcessCode.Length!= yearsArray.Length && request.StartDate.Length!= request.SubProcessCode.Length && request.EndDate.Length!= request.SubProcessCode.Length)
                //{
                //    response.responseMessage = errmsg;
                //    response.responseCode = 0;
                //    return response;
                //}

                string pgsqlConnection = appSettings.Value.DbConnection;


                string[] StartDate = request.StartDate.ToArray();
                string[] EndDate = request.EndDate.ToArray();





                string functionCall = "SELECT fn_insertupdateYearlyCalenderConfig(@module_code, @company_code, @department_codes, @allocation_years,  @created_on, @created_by, @created_ip_address,@startdate,@enddate)";

                // Define the connection string

                // Define the parameters


                // Create a connection to the database
                using (var connection = new NpgsqlConnection(pgsqlConnection))
                {
                    connection.Open();

                    // Create a command to execute the function call
                    using (var command = new NpgsqlCommand(functionCall, connection))
                    {
                        // Add the parameters to the command
                        command.Parameters.AddWithValue("module_code", request.ModuleCode.FirstOrDefault().ToString());
                        command.Parameters.AddWithValue("company_code", request.CompanyCode.FirstOrDefault().ToString());
                        command.Parameters.AddWithValue("department_codes", request.DepartmentCode);
                        command.Parameters.AddWithValue("allocation_years", yearsArray);
                        //command.Parameters.AddWithValue("subprocess_codes", request.SubProcessCode);
                        command.Parameters.AddWithValue("created_on", request.CreatedOn);
                        command.Parameters.AddWithValue("created_by", request.CreatedBy);
                        command.Parameters.AddWithValue("created_ip_address", request.CreatedIpAddress);
                        command.Parameters.AddWithValue("startdate", StartDate);
                        command.Parameters.AddWithValue("enddate", EndDate);

                        // Execute the function call
                        command.ExecuteNonQuery();
                    }
                    connection.Close();
                }

                response.responseCode = 1;
                response.responseMessage = "Success";


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("InsertJoiningConfig", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public bool ValidateUploadData(ModuleSaveYearDepartmentConfig request, out string errormessage)
        {
            if (request.DepartmentCode.Length == 0)
            {
                errormessage = "DepartmentCode Error";
                return false;
            }
            if (request.CompanyCode.Length == 0)
            {
                errormessage = "CompanyCode Error";
                return false;
            }
            //if (request.SubProcessCode.Length == 0)
            //{
            //    errormessage = "Month Error";
            //    return false;
            //}
            if (request.Year.Length == 0)
            {
                errormessage = "Year Error";
                return false;
            }
            if (request.ModuleCode.Length == 0)
            {
                errormessage = "ModuleCode Error";
                return false;
            }
            if(request.DepartmentCode.Length!= request.Year.Length)
            {
                errormessage = "Error";
                return false;
            }
            errormessage = "";
            return true;
        }




        public ResponseClass GetUploadConfigData(FiltersforUploadDataConfig request)
        {

            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();
            try
            {


                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM get_Uploadmodule_configData
                                                                    ( 
                                                                                                                                             :input_module_code,
:input_company_code,
:input_year,
:input_subprocess,
:input_department_code_csv
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.CompanyCode))
                            cmd.Parameters.AddWithValue("input_company_code", DbType.String).Value = request.CompanyCode;
                        else
                            cmd.Parameters.AddWithValue("input_company_code", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.ModuleCode))
                            cmd.Parameters.AddWithValue("input_module_code", DbType.String).Value = request.ModuleCode;
                        else
                            cmd.Parameters.AddWithValue("input_module_code", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.DepartmentCode))
                            cmd.Parameters.AddWithValue("input_department_code_csv", DbType.String).Value = request.DepartmentCode;
                        else
                            cmd.Parameters.AddWithValue("input_department_code_csv", DbType.String).Value = DBNull.Value;

                            cmd.Parameters.AddWithValue("input_year", DbType.String).Value = DBNull.Value;

                            cmd.Parameters.AddWithValue("input_subprocess", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                    }
                }
                DataTable RDataTable = new DataTable();
                DataTable DtTable = new DataTable();

                DtTable = _qualtricsBL.GetDepartmentDataTable(request.CompanyCode, null);
                RDataTable.Columns.Add("Department", typeof(string));
                RDataTable.Columns.Add("DepartmentCode", typeof(string));
                RDataTable.Columns.Add("Year", typeof(string));
                RDataTable.Columns.Add("SubProcessCode", typeof(string));
                RDataTable.Columns.Add("SubProcess", typeof(string));
                RDataTable.Columns.Add("ModuleCode", typeof(string));
                RDataTable.Columns.Add("CompanyCode", typeof(string));
                RDataTable.Columns.Add("StartDate", typeof(string));
                RDataTable.Columns.Add("EndDate", typeof(string));


                for (int i = 0; i < dtData.Rows.Count; i++)
                {
                    // Check if the Department exists in the data table
                    DataRow[] rows = DtTable.Select("Department_Code = '" + dtData.Rows[i].Field<string>("DepartmentCode") + "' AND Sub_Process_Code='" + dtData.Rows[i].Field<string>("SubProcessCode") + "' ");
                    if (rows.Length > 0)
                    {
                        // Get the Department code from the data table
                        string departmentCode = rows[0]["Department_Code"].ToString();
                        string subprocessname = rows[0]["Sub_Process"].ToString();

                        // Add the row to the data table
                        DataRow row = RDataTable.NewRow();
                        row["Department"] = rows.FirstOrDefault().Field<string>("DEPARTMENT");
                        row["DepartmentCode"] = departmentCode;
                        row["SubProcess"] = subprocessname;

                        row["Year"] = dtData.Rows[i].Field<int>("AllocationYear");
                        row["SubProcessCode"] = dtData.Rows[i].Field<string>("SubProcessCode");
                        row["ModuleCode"] = request.ModuleCode;
                        row["CompanyCode"] = request.CompanyCode;
                        //5/1/2023 12:00:00 AM}
                        row["StartDate"] = dtData.Rows[i].Field<DateTime?>("AssignedDate")?.ToString("dd/MM/yyyy");
                        row["EndDate"] = dtData.Rows[i].Field<DateTime?>("ExpiryDate")?.ToString("dd/MM/yyyy");
                        RDataTable.Rows.Add(row);
                    }
                }
                response.responseJSON = JsonConvert.SerializeObject(RDataTable);
                response.responseCode = 1;
                response.responseMessage = "Success";


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetUploadConfigData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;


        }

        public ResponseClass GetManualUploadConfig(FiltersforManualUploadDataConfig request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();
            try
            {

                //request.DepartmentCode = request.DepartmentCode.Replace("'","");
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM get_Uploadmodule_configData
                                                                    ( 
                                                                       :input_module_code,
:input_company_code,
:input_year,
:input_subprocess,
:input_department_code_csv

                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.CompanyCode))
                            cmd.Parameters.AddWithValue("input_company_code", DbType.String).Value = request.CompanyCode;
                        else
                            cmd.Parameters.AddWithValue("input_company_code", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.ModuleCode))
                            cmd.Parameters.AddWithValue("input_module_code", DbType.String).Value = request.ModuleCode;
                        else
                            cmd.Parameters.AddWithValue("input_module_code", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.DepartmentCode))
                            cmd.Parameters.AddWithValue("input_department_code_csv", DbType.String).Value = request.DepartmentCode.Replace("'", "");
                        else
                            cmd.Parameters.AddWithValue("input_department_code_csv", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Year))
                            cmd.Parameters.AddWithValue("input_year", DbType.String).Value = request.Year;
                        else
                            cmd.Parameters.AddWithValue("input_year", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.SubprocessCode))
                            cmd.Parameters.AddWithValue("input_subprocess", DbType.String).Value = request.SubprocessCode;
                        else
                            cmd.Parameters.AddWithValue("input_subprocess", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                    }
                }

               

                DataTable RDataTable = new DataTable();
                DataTable DtTable = new DataTable();

                DtTable = _qualtricsBL.GetDepartmentDataTable(request.CompanyCode, request.DepartmentCode);
                
                RDataTable.Columns.Add("Department", typeof(string));
                RDataTable.Columns.Add("DepartmentCode", typeof(string));
                RDataTable.Columns.Add("Year", typeof(string));
              //  RDataTable.Columns.Add("SubProcessCode", typeof(string));
              //  RDataTable.Columns.Add("SubProcess", typeof(string));
                RDataTable.Columns.Add("ModuleCode", typeof(string));
                RDataTable.Columns.Add("CompanyCode", typeof(string));
                RDataTable.Columns.Add("CompanyName", typeof(string));

                RDataTable.Columns.Add("StartDate", typeof(string));
                RDataTable.Columns.Add("EndDate", typeof(string));

                //DataTable rows = DtTable.Select("Department_Code = '" + request.DepartmentCode + "'").CopyToDataTable();

                for(int i = 0; i < DtTable.Rows.Count; i++)
                {
                    DataRow row = RDataTable.NewRow();
                    row["CompanyName"] = DtTable.Rows[i].Field<string>("Company_Name");
                    row["Department"] = DtTable.Rows[i].Field<string>("DEPARTMENT");
                   // row["SubProcess"] = DtTable.Rows[i].Field<string>("Sub_Process");
                    row["DepartmentCode"] = DtTable.Rows[i].Field<string>("Department_Code");
                   // row["SubProcessCode"] = DtTable.Rows[i].Field<string>("Sub_Process_Code");
                    if (dtData.Rows.Count > 0)
                    {
                        try
                        {
                            DataRow[] Uploadrows = dtData.Select("DepartmentCode = '" + DtTable.Rows[i].Field<string>("Department_Code") + "'  AND  AllocationYear='" + request.Year + "'");
                            if (Uploadrows.Length > 0)
                            {
                                row["StartDate"] = Uploadrows[0].Field<DateTime?>("AssignedDate")?.ToString("dd/MM/yyyy")
        ;
                                row["EndDate"] = Uploadrows[0].Field<DateTime?>("ExpiryDate")?.ToString("dd/MM/yyyy")
        ;
                            }
                            else
                            {
                                row["StartDate"] = DateTime.Now.ToString("dd/MM/yyyy");
                                row["EndDate"] = DateTime.Now.ToString("dd/MM/yyyy");
                            }
                        }
                        catch (Exception)
                        {


                        }
                    }


                    row["ModuleCode"] = request.ModuleCode;
                    row["CompanyCode"] = request.CompanyCode;
                    row["Year"] = request.Year;
                    RDataTable.Rows.Add(row);
                    //            if (request.SubprocessCode != null)
                    //            {
                    //                var SubprCodes = request.SubprocessCode.Split(',');
                    //                if (SubprCodes.Contains(DtTable.Rows[i].Field<string>("Sub_Process_Code")))
                    //                {
                    //                    DataRow[] Uploadrows = dtData.Select("DepartmentCode = '" + DtTable.Rows[i].Field<string>("Department_Code") + "' AND SubProcessCode='" + dtData.Rows[i].Field<string>("Sub_Process_Code") + "' AND  AllocationYear='" + request.Year + "'");
                    //                    //DataRow[] rows = DtTable.Select("Department_Code = '" + request.DepartmentCode[i] + "' AND Sub_Process_Code = '" + request.SubProcessCode[i] + "'");

                    //                    var kk = DtTable.Rows[i].Field<string>("Department_Code");
                    //                    var lk = DtTable.Rows[i].Field<string>("Sub_Process_Code");

                    //                    DataRow row = RDataTable.NewRow();

                    //                    row["CompanyName"] = DtTable.Rows[i].Field<string>("Company_Name");
                    //                    row["Department"] = DtTable.Rows[i].Field<string>("DEPARTMENT");
                    //                    row["SubProcess"] = DtTable.Rows[i].Field<string>("Sub_Process");
                    //                    row["DepartmentCode"] = DtTable.Rows[i].Field<string>("Department_Code");
                    //                    row["SubProcessCode"] = DtTable.Rows[i].Field<string>("Sub_Process_Code");
                    //                    row["ModuleCode"] = request.ModuleCode;
                    //                    row["CompanyCode"] = request.CompanyCode;
                    //                    row["Year"] = request.Year;

                    //                    if (Uploadrows.Length > 0)
                    //                    {
                    //                        row["StartDate"] = Uploadrows[0].Field<DateTime?>("AssignedDate")?.ToString("dd/MM/yyyy")
                    //;
                    //                        row["EndDate"] = Uploadrows[0].Field<DateTime?>("ExpiryDate")?.ToString("dd/MM/yyyy")
                    //;
                    //                    }
                    //                    else
                    //                    {
                    //                        row["StartDate"] = DateTime.Now.ToString("dd/MM/yyyy");
                    //                        row["EndDate"] = DateTime.Now.ToString("dd/MM/yyyy");
                    //                    }



                    //                    RDataTable.Rows.Add(row);
                    //                }

                    //            }
                    //            else
                    //            {

                    //                //DataRow[] rows = DtTable.Select("Department_Code = '" + request.DepartmentCode[i] + "' AND Sub_Process_Code = '" + request.SubProcessCode[i] + "'");

                    //                var kk = dtData.Rows[i].Field<string>("Department_Code");
                    //                var lk = dtData.Rows[i].Field<string>("Sub_Process_Code");

                    //                DataRow row = RDataTable.NewRow();

                    //                row["CompanyName"] = dtData.Rows[i].Field<string>("Company_Name");
                    //                row["Department"] = dtData.Rows[i].Field<string>("DEPARTMENT");
                    //                row["SubProcess"] = dtData.Rows[i].Field<string>("Sub_Process");
                    //                row["DepartmentCode"] = dtData.Rows[i].Field<string>("Department_Code");
                    //                row["SubProcessCode"] = dtData.Rows[i].Field<string>("Sub_Process_Code");
                    //                row["ModuleCode"] = request.ModuleCode;
                    //                row["CompanyCode"] = request.CompanyCode;
                    //                row["Year"] = request.Year;

                    //                try
                    //                {
                    //                    DataRow[] Uploadrows = dtData.Select("DepartmentCode = '" + dtData.Rows[i].Field<string>("Department_Code") + "' AND SubProcessCode='" + dtData.Rows[i].Field<string>("Sub_Process_Code") + "' AND  AllocationYear='" + request.Year + "'");
                    //                    if (Uploadrows.Length > 0)
                    //                    {
                    //                        row["StartDate"] = Uploadrows[0].Field<DateTime?>("AssignedDate")?.ToString("dd/MM/yyyy")
                    //;
                    //                        row["EndDate"] = Uploadrows[0].Field<DateTime?>("ExpiryDate")?.ToString("dd/MM/yyyy")
                    //;
                    //                    }
                    //                    else
                    //                    {
                    //                        row["StartDate"] = DateTime.Now.ToString("dd/MM/yyyy");
                    //                        row["EndDate"] = DateTime.Now.ToString("dd/MM/yyyy");
                    //                    }
                    //                }
                    //                catch (Exception)
                    //                {


                    //                }




                    //                RDataTable.Rows.Add(row);
                    //            }

                }
                response.responseJSON = JsonConvert.SerializeObject(RDataTable);
                response.responseCode = 1;
                response.responseMessage = "Success";


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetManualUploadConfig", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }


    }
}
