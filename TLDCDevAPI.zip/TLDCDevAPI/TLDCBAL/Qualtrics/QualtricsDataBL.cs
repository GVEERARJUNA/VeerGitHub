﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.ProgramManager;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.Qualtrics
{
    public class QualtricsDataBL : IQualtricsDataBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        private readonly IServiceConnect _serviceconnect;

        public QualtricsDataBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.QualtricsDbConnection);

            _serviceconnect = serviceconnect;
        }

        //public ResponseClass GetTeamMembers(getTeamMembersRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    try
        //    {
        //        SqlParameter[] parameter = {
        //        new SqlParameter("@PARENTID", request.EmployeeCode),

        //    };

        //        List<OutParameter> outParameters = new List<OutParameter>();
        //        DataSet dsResult = new DataSet();
        //        dsResult = dBConnection.ExecuteDataSet("TLDC_Get_TeamMember", parameter, outParameters);

        //        if (dsResult != null && dsResult.Tables.Count > 0)
        //        {
        //            response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

        //        }

        //        response.responseCode = 1;
        //        response.responseMessage = "SUCCESS";

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("GetTeamMembers", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;

        //    }

        //    return response;



        //}
        public ResponseClass GetTeamMembers(getTeamMembersRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                SqlParameter[] parameter = {
                new SqlParameter("@PARENTID", request.EmployeeCode),

            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_Employee_Data_hierarchy_VERTICALDOWN", parameter, outParameters);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetTeamMembers", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }

            return response;



        }
        public ResponseClass GetComapny(getCompanyRequest request)
        {
            ResponseClass response = new ResponseClass();
            string companies = string.Empty;
            string teamMembers= string.Empty;

            if (request.currentRole == "Team Lead")
            {
                getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                getteam.EmployeeCode = request.currentEmployee;
                var QualtriData = GetTeamMembers(getteam);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {
                        teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                    }

                    teamMembers = teamMembers.TrimEnd(',');

                }

            }

            if (request.currentRole=="Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = gtAssignedCompany(request.currentEmployee);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    }

                    companies = companies.TrimEnd(',');

                }
            }

            if (request.currentRole == "Program Manager")
            {
                

                DataTable dtPMAssignedCompanies = new DataTable();
                dtPMAssignedCompanies= getProgramManagerAssignedCompanies(request.currentEmployee);
                if (dtPMAssignedCompanies != null && dtPMAssignedCompanies.Rows.Count > 0)
                {
                    string companyNames = string.Empty;

                    companyNames = Convert.ToString(dtPMAssignedCompanies.Rows[0]["CompanyCode"]);

                    string[] authorsList = companyNames.Split(",");
                    foreach (string author in authorsList)
                    {
                        companies = companies + "'" + Convert.ToString(author) + "',";

                    }
                       
                    

                }
                else
                {
                    companies = "'" + request.currentCompanyCode + "',";
                }

                companies = companies.TrimEnd(',');

            }

            if (request.currentRole == "Participant")
            {
                companies = "'" + request.currentCompanyCode + "'";
            }

            try
            {
                DataSet dsResult = new DataSet();
                string query = string.Empty;
                query = "select distinct COMPANY_CODE,concat(Company_Name,'(',COMPANY_CODE,')') as Company_Name from Qualtrics_Data where Active_Separated='Active'";
                if (!string.IsNullOrEmpty(companies))
                {
                    query = query + " and COMPANY_CODE in (" + companies + ")";
                }
                else
                {
                    query = query + " and COMPANY_CODE in ('2700','2100','1010','1100','2000','7100','C050','6600','XW3','6100')";
                }
                if (!string.IsNullOrEmpty(teamMembers))
                {
                    query = query + " and ExternalDataReference in (" + teamMembers + ")";
                }
                query = query + " order by Company_Name";
                dsResult = dBConnection.ExecuteDataSetInline(query);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch(Exception ex)
            {
                _serviceconnect.LogConnect("GetComapny", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }

        public DataTable getProgramManagerAssignedCompanies(string EmpId)
        {
            DataTable dtResult = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                selectQuery = "select #CompanyCode# from #UserAccessMaster# where #DeletedFlag#=0 and #EmployeeCode#='" + EmpId + "';";
                selectQuery = selectQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getProgramManagerAssignedCompanies", "1024", ex.Message, "Exception");

            }



            return dtResult;

        }

        public ResponseClass GetComapnyForCertificate(getCompanyRequest request)
        {
            ResponseClass response = new ResponseClass();
            string companies = string.Empty;
            string teamMembers= string.Empty;

            if (request.currentRole == "Team Lead")
            {
                getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                getteam.EmployeeCode = request.currentEmployee;
                var QualtriData = GetTeamMembers(getteam);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {
                        teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                    }

                    teamMembers = teamMembers.TrimEnd(',');

                }

            }

            if (request.currentRole == "Program Manager")
            {

                companies = "'" + Convert.ToString(request.currentCompanyCode) + "'";

            }

            if (request.currentRole=="Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = gtAssignedCompany(request.currentEmployee);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    }

                    companies = companies.TrimEnd(',');

                }
            }

            try
            {
                DataSet dsResult = new DataSet();
                string query = string.Empty;
                query = "select distinct COMPANY_CODE,concat(Company_Name,'(',COMPANY_CODE,')') as Company_Name from Qualtrics_Data where Active_Separated='Active'";
                if (!string.IsNullOrEmpty(companies))
                {
                    query = query + " and COMPANY_CODE in (" + companies + ")";
                }
                else
                {
                    query = query + " and COMPANY_CODE in ('2700','2100','1010','1100','2000')";
                }
                if (!string.IsNullOrEmpty(teamMembers))
                {
                    query = query + " and ExternalDataReference in (" + teamMembers + ")";
                }
                query = query + " order by Company_Name";
                dsResult = dBConnection.ExecuteDataSetInline(query);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch(Exception ex)
            {
                _serviceconnect.LogConnect("GetComapny", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }

        public ResponseClass GetDepartment(getDepartmentRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string companies = string.Empty;
            string teamMembers = string.Empty;
            try
            {
                if (request.currentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.currentEmployee;
                    var QualtriData = GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }

                }

                if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = gtAssignedCompany(request.currentEmployee);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companies = companies.TrimEnd(',');

                    }
                }

                DataSet dsResult = new DataSet();
                string query = string.Empty;
                query = "select distinct concat(DEPARTMENT,'(',Department_Code,')') as DEPARTMENT,Department_Code,COMPANY_CODE,Company_Name from Qualtrics_Data where COMPANY_CODE='" + request.CompanyCode + "' and Active_Separated='Active'";
                if (!string.IsNullOrEmpty(companies))
                {
                    query = query + " and COMPANY_CODE in (" + companies + ")";
                }
                if (!string.IsNullOrEmpty(teamMembers))
                {
                    query = query + " and ExternalDataReference in (" + teamMembers + ")";
                }

                query = query + " order by DEPARTMENT";


                dsResult = dBConnection.ExecuteDataSetInline(query);
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetDepartment", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }
        public ResponseClass GetDepartmentCertificate(getDepartmentRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string companies = string.Empty;
            string teamMembers = string.Empty;
            try
            {
                if (request.currentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.currentEmployee;
                    var QualtriData = GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }

                }

                if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = gtAssignedCompany(request.currentEmployee);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companies = companies.TrimEnd(',');

                    }
                }

                DataSet dsResult = new DataSet();
                string query = string.Empty;
                query = "select distinct concat(DEPARTMENT,'(',Department_Code,')') as DEPARTMENT,Department_Code,COMPANY_CODE,Company_Name from Qualtrics_Data where COMPANY_CODE IN (" + request.CompanyCode + ") and Active_Separated='Active'";
                if (!string.IsNullOrEmpty(companies))
                {
                    query = query + " and COMPANY_CODE in (" + companies + ")";
                }
                if (!string.IsNullOrEmpty(teamMembers))
                {
                    query = query + " and ExternalDataReference in (" + teamMembers + ")";
                }

                query = query + " order by DEPARTMENT";


                dsResult = dBConnection.ExecuteDataSetInline(query);
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetDepartment", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }
        public DataTable GetDepartmentDataTable(string ComanyCode,string DepartmentCode)
        {
            DataTable DtTable = new DataTable();
            try
            {
                DataSet dsResult = new DataSet();
                if (DepartmentCode == null || DepartmentCode == "0")
                {
                    dsResult = dBConnection.ExecuteDataSetInline("select distinct DEPARTMENT,Department_Code,COMPANY_CODE,Company_Name,Sub_Process,Sub_Process_Code from Qualtrics_Data where COMPANY_CODE='" + ComanyCode + "' and Active_Separated='Active'");

                }
                else
                {
                    string query = string.Empty;
                    query = "select distinct DEPARTMENT,Department_Code,COMPANY_CODE,Company_Name from Qualtrics_Data where COMPANY_CODE='" + ComanyCode + "' and Department_Code in (" + DepartmentCode + ") and Active_Separated='Active' order by DEPARTMENT";
                    //query = "select distinct DEPARTMENT,Department_Code,COMPANY_CODE,Company_Name,Sub_Process,Sub_Process_Code from Qualtrics_Data where COMPANY_CODE='" + ComanyCode + "' and Department_Code in (" + DepartmentCode + ") and Active_Separated='Active'";
                    //dsResult = dBConnection.ExecuteDataSetInline("select distinct DEPARTMENT,Department_Code,COMPANY_CODE,Company_Name,Sub_Process,Sub_Process_Code from Qualtrics_Data where COMPANY_CODE='" + ComanyCode + "' and Department_Code='"+DepartmentCode+ "' and Active_Separated='Active'");
                    dsResult = dBConnection.ExecuteDataSetInline(query);
                }


                DtTable = dsResult.Tables[0];

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetComapny", "1024", ex.Message, "Exception");
               
            }
            return DtTable;

        }
        public DataTable GetEmpDetails(string EmpId)
        {
            DataTable DtTable = new DataTable();
            try
            {
                DataSet dsResult = new DataSet();

                    dsResult = dBConnection.ExecuteDataSetInline("select FIRSTNAME,LASTNAME,FIRSTNAME+' '+LASTNAME as FullName,Manager_Name,Manager_ID from Qualtrics_Data where EXTERNALDATAREFERENCE='" + EmpId + "' and Active_Separated='Active'");

               


                DtTable = dsResult.Tables[0];

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEmpDetails", "1024", ex.Message, "Exception");

            }
            return DtTable;
        }

        public bool checkEmployee(string EmpId,string currentRole,string empSearch)
        {
            bool checkValidEmployee = true;

            if (currentRole == "Team Lead")
            {
                getTeamMembersRequestDTO request = new getTeamMembersRequestDTO();
                request.EmployeeCode = EmpId;
                var QualtriData = GetTeamMembers(request);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    DataRow[] result = QualtricTeamMembers.Select("EmployeeID= '" + empSearch + "' ");

                    if (result == null || result.Length == 0)
                    {
                        checkValidEmployee= false;
                    }
                }
                else
                {
                    checkValidEmployee = false;
                }
            }
            else if (currentRole == "Geo Admin")
            {
                // get assigned Company
                DataTable dtCompanies = new DataTable();
                dtCompanies = gtAssignedCompany(EmpId);
                if (dtCompanies==null || dtCompanies.Rows.Count==0)
                {
                    checkValidEmployee = false;
                }
                else
                {
                    try
                    {
                        DataSet dsResult = new DataSet();
                        dsResult = dBConnection.ExecuteDataSetInline("select distinct ExternalDataReference,COMPANY_CODE,Company_Name from Qualtrics_Data where ExternalDataReference='" + empSearch + "' and Active_Separated='Active'");

                        if (dsResult != null && dsResult.Tables[0].Rows.Count > 0)
                        {
                            int checkCondition = 0;
                            //checkValidEmployee = false;
                            foreach (DataRow item in dtCompanies.Rows)
                            {
                                if (Convert.ToString(dsResult.Tables[0].Rows[0]["COMPANY_CODE"]) == Convert.ToString(item["CompanyCode"]))
                                {
                                    //checkValidEmployee = true;
                                    checkCondition = 1;
                                    break;
                                }
                            }
                            if (checkCondition==0)
                            {
                                checkValidEmployee = false;
                            }
                        }
                        else
                        {
                            checkValidEmployee = false;
                        }

                       
                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("checkEmployee", "1024", ex.Message, "Exception");
                        
                    }
                }
            }


                return checkValidEmployee;
        }

        public DataTable gtAssignedCompany(string EmpId)
        {
            DataTable dtResult = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                selectQuery = "select #CompanyCode# from #UserCompanyAssignment# where #ActiveStatus#=1 and #EmployeeCode#='" + EmpId + "';";
                selectQuery = selectQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
            }
            catch (Exception ex)
            { 
                _serviceconnect.LogConnect("GetEmployeeLeaveData", "1024", ex.Message, "Exception");
                
            }
            


            return dtResult;

        }

        public ResponseClass GetSubProcess(string DepartmentCode)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSetInline("select distinct concat(Sub_Process,'(',Sub_Process_Code,')') as Sub_Process,Sub_Process_Code from Qualtrics_Data where Department_Code='" + DepartmentCode + "' and Active_Separated='Active' order by Sub_Process");

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetDepartment", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }

        //public ResponseClass GetRequistionNo(getrequistionnorequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    string selectQuery = string.Empty;
        //    string companies = string.Empty;

        //    selectQuery = "select RMS_Requisition_Id as reqno,count(EXTERNALDATAREFERENCE) as membercount from Qualtrics_Data";
        //    selectQuery = selectQuery + " where  Active_Separated = 'Active'";
        //    selectQuery = selectQuery + " and(RMS_Requisition_Id is not null and RMS_Requisition_Id != '' and RMS_Requisition_Id != '0')";
        //    selectQuery = selectQuery + " and DOJ>= DATEADD(month, -4, cast(getdate() as date)) group by RMS_Requisition_Id";
        //    if (request.currentrole=="Program Manager" || request.currentrole == "Course")
        //    {
        //        selectQuery = selectQuery + " and COMPANY_CODE='" + request.CompanyCode + "'";
        //    }
        //    if (request.currentrole == "Geo Admin")
        //    {
        //        DataTable dtCompanies = new DataTable();
        //        dtCompanies = gtAssignedCompany(request.employeeID);
        //        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //        {
        //            foreach (DataRow exclude in dtCompanies.Rows)
        //            {
        //                companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
        //            }

        //            companies = companies.TrimEnd(',');

        //        }
        //    }
        //    if (!string.IsNullOrEmpty(companies))
        //    {
        //        selectQuery = selectQuery + " and COMPANY_CODE in (" + companies + ")";
        //    }
        //    selectQuery = selectQuery + " order by RMS_Requisition_Id";
        //    try
        //    {
        //        DataSet dsResult = new DataSet();
        //        dsResult = dBConnection.ExecuteDataSetInline(selectQuery);

        //        if (dsResult != null && dsResult.Tables.Count > 0)
        //        {
        //            response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

        //        }

        //        response.responseCode = 1;
        //        response.responseMessage = "SUCCESS";
        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("GetDepartment", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }
        //    return response;

        //}

        public ResponseClass GetRequistionNo(getrequistionnorequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string selectQuery = string.Empty;
            string companies = string.Empty;

            selectQuery = "select #RMS_Requisition_Id# as reqno,count(#EXTERNALDATAREFERENCE#) as membercount from #EmployeeMaster#";
            selectQuery = selectQuery + " where  #Active_Separated# = 'Active'";
            selectQuery = selectQuery + " and(#RMS_Requisition_Id# is not null and #RMS_Requisition_Id# != '' and #RMS_Requisition_Id# != '0')";
          //  selectQuery = selectQuery + " and #DOJ#>= cast(now() - interval '4 month' as date)  ";
            if (request.currentrole == "Program Manager" || request.currentrole == "Course")
            {
                selectQuery = selectQuery + " and #COMPANY_CODE#='" + request.CompanyCode + "'";
            }
            //if (request.currentrole == "Geo Admin")
            //{
            //    DataTable dtCompanies = new DataTable();
            //    dtCompanies = gtAssignedCompany(request.employeeID);
            //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
            //    {
            //        foreach (DataRow exclude in dtCompanies.Rows)
            //        {
            //            companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
            //        }

            //        companies = companies.TrimEnd(',');

            //    }
            //}
            if (request.currentrole == "Global Admin")
            {
                //DataTable dtCompanies = new DataTable();
                //dtCompanies = gtAssignedCompany(request.employeeID);
                //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                //{
                //    foreach (DataRow exclude in dtCompanies.Rows)
                //    {
                //        companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                //    }

                //    companies = companies.TrimEnd(',');

                //}

                selectQuery = selectQuery + " and #COMPANY_CODE# in ('2100','2000','7100')";
            }
            if (!string.IsNullOrEmpty(companies))
            {
                
            }
            selectQuery = selectQuery + " group by #RMS_Requisition_Id# order by #RMS_Requisition_Id#";

            selectQuery = selectQuery.Replace('#', '"');

            try
            {
                DataSet dsResult = new DataSet();

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dsResult);
                npgsql.Close();

                //DataSet dsResult = new DataSet();
                //dsResult = dBConnection.ExecuteDataSetInline(selectQuery);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetDepartment", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }

        public ResponseClass GetCompanyPostgress(getCompanyRequest request)
        {
            ResponseClass response = new ResponseClass();
            string selectQuery = string.Empty;
            string companies = string.Empty;
            string teamMembers = string.Empty;

            if (request.currentRole == "Team Lead")
            {
                getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                getteam.EmployeeCode = request.currentEmployee;
                var QualtriData = GetTeamMembers(getteam);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {
                        teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                    }

                    teamMembers = teamMembers.TrimEnd(',');

                }

            }

            if (request.currentRole == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = gtAssignedCompany(request.currentEmployee);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    }

                    companies = companies.TrimEnd(',');

                }
            }

            selectQuery = "select distinct #COMPANY_CODE#,concat(#Company_Name#,'(',#COMPANY_CODE#,')') as Company_Name from #EmployeeMaster# where #Active_Separated#='Active'";
            if (!string.IsNullOrEmpty(companies))
            {
                selectQuery = selectQuery + " and #COMPANY_CODE# in (" + companies + ")";
            }
            else
            {
                selectQuery = selectQuery + " and #COMPANY_CODE# in ('2700','2100','1010','1100','2000')";
            }
            if (!string.IsNullOrEmpty(teamMembers))
            {
                selectQuery = selectQuery + " and #EXTERNALDATAREFERENCE# in (" + teamMembers + ")";
            }
            selectQuery = selectQuery + " order by #COMPANY_CODE#,#Company_Name#";

            //selectQuery = "select #RMS_Requisition_Id# as reqno,count(#EXTERNALDATAREFERENCE#) as membercount from #EmployeeMaster#";
            //selectQuery = selectQuery + " where  #Active_Separated# = 'Active'";
            //selectQuery = selectQuery + " and(#RMS_Requisition_Id# is not null and #RMS_Requisition_Id# != '' and #RMS_Requisition_Id# != '0')";

            //if (request.currentrole == "Program Manager" || request.currentrole == "Course")
            //{
            //    selectQuery = selectQuery + " and #COMPANY_CODE#='" + request.CompanyCode + "'";
            //}

            //if (request.currentrole == "Global Admin")
            //{
            //    //DataTable dtCompanies = new DataTable();
            //    //dtCompanies = gtAssignedCompany(request.employeeID);
            //    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
            //    //{
            //    //    foreach (DataRow exclude in dtCompanies.Rows)
            //    //    {
            //    //        companies = companies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
            //    //    }

            //    //    companies = companies.TrimEnd(',');

            //    //}

            //    selectQuery = selectQuery + " and #COMPANY_CODE# in ('2100','2000','7100')";
            //}
            //if (!string.IsNullOrEmpty(companies))
            //{

            //}
            //selectQuery = selectQuery + " group by #RMS_Requisition_Id# order by #RMS_Requisition_Id#";

            //selectQuery = selectQuery.Replace('#', '"');

            try
            {
                DataSet dsResult = new DataSet();

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dsResult);
                npgsql.Close();

                //DataSet dsResult = new DataSet();
                //dsResult = dBConnection.ExecuteDataSetInline(selectQuery);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetCompanyPostgress", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }

        

    }
}
