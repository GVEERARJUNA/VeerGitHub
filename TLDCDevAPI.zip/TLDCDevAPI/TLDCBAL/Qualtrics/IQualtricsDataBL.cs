﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.ProgramManager;

namespace TLDCBAL.Qualtrics
{
    public interface IQualtricsDataBL
    {
        ResponseClass GetTeamMembers(getTeamMembersRequestDTO request);
        ResponseClass GetComapny(getCompanyRequest request);
        ResponseClass GetDepartment(getDepartmentRequestDTO request);
        ResponseClass GetDepartmentCertificate(getDepartmentRequestDTO request);
        DataTable GetDepartmentDataTable(string ComanyCode, string DepartmentCode);
        public DataTable GetEmpDetails(string EmpId);
        bool checkEmployee(string EmpId, string currentRole, string empSearch);

        DataTable getProgramManagerAssignedCompanies(string EmpId);

        DataTable gtAssignedCompany(string EmpId);
        public ResponseClass GetSubProcess(string DepartmentCode);
        ResponseClass GetRequistionNo(getrequistionnorequestDTO request);

        ResponseClass GetComapnyForCertificate(getCompanyRequest request);

        ResponseClass GetCompanyPostgress(getCompanyRequest request);

    }
}
