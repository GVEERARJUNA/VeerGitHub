﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.Qualtrics
{
  public class getTeamMembersRequestDTO
    {
        public string EmployeeCode { get; set; }
    }

    public class getDepartmentRequestDTO
    {
        public string currentEmployee { get; set; }
        public string currentRole { get; set; }
        public string CompanyCode { get; set; }
    }
    public class getSubProcessRequestDTO
    {
        public string DepartmentCode { get; set; }
    }

    public class  getCompanyRequest
    {
        public string currentEmployee { get; set; }
        public string currentRole { get; set; }
        public string currentCompanyCode { get; set; }
    }


}
