﻿using TLDCBAL.ProgramManager;

namespace TLDCBAL.Service
{
    public interface IServiceConnect
    {
        string LogConnect(string PageName, string LogCode, string LogMessage, string LogCategory);
        string getAssessment(string Geo, string EmpCode, string currentrole, string companycode);
        string getSurvey(string Geo, string EmpCode, string currentrole, string companycode);
        string insertSurveyAllocation(surveyAllocationRequestDTO request);

        string insertSurveyInsert(SurveyInsertRequestDTO request);

        string getODPMSurvey(string EmpCode);
        string GetODPMsurveyquestion(string TemplateId);
        string savefeedback(savefeedbackDTO request);
    }
}