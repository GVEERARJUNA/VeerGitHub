﻿namespace TLDCBAL.Service
{
    public interface IFireBaseAPICallBL
    {
        string FBCall(string devicetoken, string title, string body);
    }
}