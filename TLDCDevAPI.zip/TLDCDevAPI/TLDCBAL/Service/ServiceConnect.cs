﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.EmailManagement;
using TLDCBAL.ProgramManager;

namespace TLDCBAL.Service
{
    public class ServiceConnect : IServiceConnect
    {
        private readonly IOptions<IDBConnection> appSettings;

        public ServiceConnect(IOptions<IDBConnection> appSettings)
        {
            this.appSettings = appSettings;
        }

        public string LogConnect(string PageName, string LogCode, string LogMessage, string LogCategory)
        {
            try
            {
                //LogWrite logWrite = new LogWrite();
                //logWrite.LogCategory = LogCategory;
                //logWrite.ApplicationName = "TLDC";
                //logWrite.LogCode = LogCode;
                //logWrite.LogMessage = LogMessage;
                //logWrite.PageName = PageName;
                //logWrite.LogDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                //string apiUrl = appSettings.Value.LogAPIPath;
                //string inputJson = JsonConvert.SerializeObject(logWrite);
                //WebClient client = new WebClient();
                //client.Headers["Content-type"] = "application/json";
                //client.Encoding = Encoding.UTF8;
                //string json = client.UploadString(apiUrl, inputJson);
                string outputResult = string.Empty;
                string json = string.Empty;

                try
                {
                    if (LogCategory== "Exception")
                    {
                        MailDetails mailDetails = new MailDetails();
                        mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;
                        List<ToList> lstToList = new List<ToList>();
                        ToList to = new ToList();
                        to.EmailAddress = Convert.ToString(appSettings.Value.BccList);
                        lstToList.Add(to);
                        mailDetails.ToList = lstToList;
                        mailDetails.Subject = "Exception in TLDC apllication";
                        string emailbody = string.Empty;
                        emailbody = "Exception occured in TLDC application and Method : " + PageName + "  : " + LogMessage;
                        mailDetails.MailActualBody = emailbody;
                        mailDetails.SmtpHostName = appSettings.Value.SmtpHostName;
                        mailDetails.Sender = appSettings.Value.Sender;
                        mailDetails.SenderName = appSettings.Value.SenderName;
                        outputResult = MailHelper.SendMail(mailDetails, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
                    }
                   
                }
                catch (Exception)
                {

                   
                }
                return json;
            }
            catch (Exception ex)
            { 

                return "Exception";
            }
           

        }

        public string getAssessment(string Geo, string EmpCode,string currentrole,string companycode)
        {
            try
            {
                getAssessmentListRequestDTO logWrite = new getAssessmentListRequestDTO();
                logWrite.EmpCode = EmpCode;
                logWrite.Geo = Geo;
                logWrite.CompanyCode = companycode;
                logWrite.RoleName = currentrole;

                string apiUrl = appSettings.Value.GetAssessmentListAPIPath;
                string inputJson = JsonConvert.SerializeObject(logWrite);
                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;
                string json = client.UploadString(apiUrl, inputJson);
                return json;
            }
            catch (Exception ex)
            {

                return "Exception";
            }


        }

        public string getSurvey(string Geo, string EmpCode, string currentrole, string companycode)
        {
            try
            {
                getSurveyListRequestDTO logWrite = new getSurveyListRequestDTO();
                logWrite.LoggedInEmployeeId = EmpCode;
                logWrite.Geo = Geo;
                logWrite.CompanyCode = companycode;
                logWrite.RoleName = currentrole;

                string apiUrl = appSettings.Value.GetSurveyListAPIPath;
                string inputJson = JsonConvert.SerializeObject(logWrite);
                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;
                string json = client.UploadString(apiUrl, inputJson);
                return json;
            }
            catch (Exception)
            {

                return "Exception";
            }


        }

        public string insertSurveyAllocation(surveyAllocationRequestDTO request)
        {
            try
            {
                string apiUrl = appSettings.Value.SurveyAllocation;
                string inputJson = JsonConvert.SerializeObject(request);
                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;
                string json = client.UploadString(apiUrl, inputJson);
                return json;
            }
            catch (Exception)
            {

                return "Exception";
            }


        }

        public string insertSurveyInsert(SurveyInsertRequestDTO request)
        {
            try
            {
                string apiUrl = appSettings.Value.SurveyInsert;
                string inputJson = JsonConvert.SerializeObject(request);
                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;
                string json = client.UploadString(apiUrl, inputJson);
                return json;
            }
            catch (Exception)
            {

                return "Exception";
            }


        }

        public string getODPMSurvey(string EmpCode)
        {
            try
            {
                getSurveyListRequestDTO logWrite = new getSurveyListRequestDTO();
                logWrite.LoggedInEmployeeId = EmpCode;
                

                string apiUrl = appSettings.Value.GetTLDCSurveyListAPIPath;
                string inputJson = JsonConvert.SerializeObject(logWrite);
                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;
                string json = client.UploadString(apiUrl, inputJson);
                return json;
            }
            catch (Exception)
            {

                return "Exception";
            }


        }
        public string GetODPMsurveyquestion(string TemplateId)
        {
            try
            {
                getSurveyListRequestDTO logWrite = new getSurveyListRequestDTO();
                logWrite.TemplateId = TemplateId;


                string apiUrl = appSettings.Value.GetTLDQuestionsListAPIPath;
                string inputJson = JsonConvert.SerializeObject(logWrite);
                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;
                string json = client.UploadString(apiUrl, inputJson);
                return json;
            }
            catch (Exception)
            {

                return "Exception";
            }


        }
        public string savefeedback(savefeedbackDTO request)
        {
            try
            {
                string apiUrl = appSettings.Value.TLDCSurveyInsert;
                string inputJson = JsonConvert.SerializeObject(request);
                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;
                string json = client.UploadString(apiUrl, inputJson);
                return json;
            }
            catch (Exception)
            {

                return "Exception";
            }


        }


    }
}
