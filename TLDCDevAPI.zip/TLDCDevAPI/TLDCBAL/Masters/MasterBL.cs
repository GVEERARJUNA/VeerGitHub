﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.Masters
{
    public class MasterBL : IMasterBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        private readonly IServiceConnect _serviceconnect;

        DBConnection dBConnection;

        public MasterBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);

            _serviceconnect = serviceconnect;
        }

        public ResponseClass GetMasterData(MasterSelectInsertDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_state
                                                                    ( 
                                                                        :p_statename
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.StateName))
                        cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = request.StateName;
                    else
                        cmd.Parameters.AddWithValue("p_statename", DbType.String).Value = DBNull.Value;

                  
                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                }
            }
          
            return response;
        }

        public ResponseClass InsertStateMaster(StateMasterInsertDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request is required";
                return response;
            }
            if (string.IsNullOrEmpty(request.StateName))
            {
                response.responseCode = 0;
                response.responseMessage = "StateName required";
                return response;
            }

            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);

            try
            {
                npgCon.Open();

                string sqlQuery = "call insert_state('" + request.StateName + "')";
                
                // Define a command to call  procedure
                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
                NpgsqlDataReader rdr = cmd.ExecuteReader();

                return response;
            }
            catch (Exception ex)
            {
               // LogException.Log(ex.Message);
                return response;
            }
            finally
            {
                npgCon.Close();
            }


          
        }

        public ResponseClass GetCommonEntity(getcommonentityrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_common_entity
                                                                    ( 
                                                                        :p_entitycode,:p_searchparam1,
                                                                        :p_searchparam2,:p_searchparam3,
                                                                        :p_searchparam4,:p_searchparam5,:p_searchparam6
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EntityCode))
                            cmd.Parameters.AddWithValue("p_entitycode", DbType.String).Value = request.EntityCode;
                        else
                            cmd.Parameters.AddWithValue("p_entitycode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.SearchParam1))
                            cmd.Parameters.AddWithValue("p_searchparam1", DbType.String).Value = request.SearchParam1;
                        else
                            cmd.Parameters.AddWithValue("p_searchparam1", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.SearchParam2))
                            cmd.Parameters.AddWithValue("p_searchparam2", DbType.String).Value = request.SearchParam2;
                        else
                            cmd.Parameters.AddWithValue("p_searchparam2", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.SearchParam3))
                            cmd.Parameters.AddWithValue("p_searchparam3", DbType.String).Value = request.SearchParam3;
                        else
                            cmd.Parameters.AddWithValue("p_searchparam3", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.SearchParam4))
                            cmd.Parameters.AddWithValue("p_searchparam4", DbType.String).Value = request.SearchParam4;
                        else
                            cmd.Parameters.AddWithValue("p_searchparam4", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.SearchParam5))
                            cmd.Parameters.AddWithValue("p_searchparam5", DbType.String).Value = request.SearchParam5;
                        else
                            cmd.Parameters.AddWithValue("p_searchparam5", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.SearchParam6))
                            cmd.Parameters.AddWithValue("p_searchparam6", DbType.String).Value = request.SearchParam6;
                        else
                            cmd.Parameters.AddWithValue("p_searchparam6", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (request.EntityCode== "EMPDETAIL")
                        {
                            if (dtEmployees!=null && dtEmployees.Rows.Count>0)
                            {
                                response.responseReturnNo = Convert.ToString(dtEmployees.Rows[0]["valuefield"]);
                            }
                            
                        }


                    }
                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetCommonEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            
            

            return response;
        }
    }
}
