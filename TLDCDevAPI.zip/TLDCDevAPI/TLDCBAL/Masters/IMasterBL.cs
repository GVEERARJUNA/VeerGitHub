﻿using TLDCBAL.Common;

namespace TLDCBAL.Masters
{
    public interface IMasterBL
    {
        ResponseClass GetMasterData(MasterSelectInsertDTO request);
        ResponseClass InsertStateMaster(StateMasterInsertDTO request);

        ResponseClass GetCommonEntity(getcommonentityrequestDTO request);
    }
}