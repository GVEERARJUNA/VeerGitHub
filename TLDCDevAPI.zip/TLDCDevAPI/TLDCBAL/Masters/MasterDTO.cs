﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.Masters
{
    public class MasterSelectInsertDTO
    {
        public string StateName { get; set; }
    }

    public class StateMasterInsertDTO
    {
        public string StateName { get; set; }
    }

    public class getcommonentityrequestDTO
    {
        public string EntityCode { get; set; }
        public string SearchParam1 { get; set; }
        public string SearchParam2 { get; set; }
        public string SearchParam3 { get; set; }
        public string SearchParam4 { get; set; }
        public string SearchParam5 { get; set; }
        public string SearchParam6 { get; set; }
    }
}
