﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCDAL;
using static TLDCBAL.EmployeeLeave.EmployeeLeaveDTO;


namespace TLDCBAL.EmployeeLeave
{
    public class EmployeeLeaveBL : IEmployeeLeaveBL
    {
        private readonly IOptions<IDBConnection> appSettings;
        private readonly IServiceConnect _serviceconnect;
        private IQualtricsDataBL _qualtricsBL;
        DBConnection dBConnection;


        public EmployeeLeaveBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass InsertUpdateEmployeeLeave(EmployeeLeaveInsertUpdateModel request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();

            try
            {
                if (!ValidateEmployeeLeave(request, out string errmsg))
                {

                    response.responseCode = 0;
                    response.responseMessage = errmsg;
                    return response;
                }
                DataTable EmpDetails = _qualtricsBL.GetEmpDetails(request.EmployeeId);
                var EmpName = "";
                var manager = "";
                if (EmpDetails.Rows.Count == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "No Data Found For Employee "+request.EmployeeId+".";
                    return response;
                }
                else
                {
                    EmpName = EmpDetails.Rows[0]["FullName"].ToString();
                    manager= EmpDetails.Rows[0]["Manager_Name"].ToString();
                }

                string pgsqlConnection = appSettings.Value.DbConnection;
                string functionCall = "SELECT upsert_employee_leave_details(@p_moduleallocationid, @p_employeeid, @p_employeename, @p_manager, @p_returndate, @p_reason, @p_createdon, @p_createdby,@p_ipaddress)";

                // Define the connection string

                // Define the parameters


                // Create a connection to the database
                using (var connection = new NpgsqlConnection(pgsqlConnection))
                {
                    connection.Open();

                    // Create a command to execute the function call
                    using (var command = new NpgsqlCommand(functionCall, connection))
                    {
                        // Add the parameters to the command
                        command.Parameters.AddWithValue("p_moduleallocationid", request.moduleallocationid);
                        command.Parameters.AddWithValue("p_employeeid", request.EmployeeId);
                        command.Parameters.AddWithValue("p_employeename", EmpName);
                        command.Parameters.AddWithValue("p_manager", manager);
                        command.Parameters.AddWithValue("p_returndate", request.ReturnDate);
                        command.Parameters.AddWithValue("p_reason", request.Reason);
                        command.Parameters.AddWithValue("p_CreatedOn", request.CreatedOn);
                        command.Parameters.AddWithValue("p_CreatedBy", request.CreatedBy);
                        command.Parameters.AddWithValue("p_IpAddress", request.IpAddress);

                        // Execute the function call
                        command.ExecuteNonQuery();
                    }
                    connection.Close();

                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("InsertUpdateEmployeeLeave", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public bool ValidateEmployeeLeave(EmployeeLeaveInsertUpdateModel model,out string errormsg)
        {
            if (string.IsNullOrEmpty(model.EmployeeId))
            {
                errormsg = "EmployeeId error";
                return false;
            }
            if (string.IsNullOrEmpty(model.Reason))
            {
                errormsg = "Reason error";
                return false;
            }
            //if (!(model.EndDate >= model.StartDate))
            //{
            //    errormsg = "Date error";
            //    return false;
            //}
            errormsg = "";
            return true;









        }


        public ResponseClass GetEmployeeLeaveData(EmployeeLeaveFilter request)
        {

            ResponseClass response = new ResponseClass();
            DataTable dtData = new DataTable();
            string selectQuery = string.Empty;
            try
            {
                getTeamMembersRequestDTO getTeamMembersRequestDTO = new getTeamMembersRequestDTO();
                getTeamMembersRequestDTO.EmployeeCode = request.TLId;

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                

                DataTable dtEmployees = new DataTable();
                if (request.CurrentRole=="Team Lead")
                {
                    var QualtriData = _qualtricsBL.GetTeamMembers(getTeamMembersRequestDTO);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    List<string> qualtriEmpCodes = QualtricTeamMembers.AsEnumerable().Select(r => r.Field<string>("EmployeeID")).ToList();

                    string teamMembers = string.Empty;
                    if (qualtriEmpCodes != null)
                    {
                        foreach (var item in qualtriEmpCodes)
                        {
                            teamMembers = teamMembers  + "'" + item +"',";
                        }
                    }
                    teamMembers = teamMembers.TrimEnd(',');

                    selectQuery = "select A.#MAllocationID# as moduleallocationid,A.#EmployeeCode#,concat(EMP.#FIRSTNAME#,' ',Coalesce(EMP.#LASTNAME#,'')) as EmployeeName,EMP.#Manager_Name# as Manager,TO_CHAR(A.#AllocationDate#, 'dd Mon  yyyy') as StartDate,TO_CHAR(A.#ExpiryDate#, 'dd Mon  yyyy') as EndDate,EMP.#DEPARTMENT# as Department,EMP.#Sub_Process# as Subprocess,A.#AllocationType# as EmployeeType,COALESCE(B.#Reason#,'') as reason,COALESCE(TO_CHAR(B.#ExpectedReturnDate#, 'dd Mon  yyyy'),'') as returndate   from #ModuleEmployeeAllocation# A left join #EmployeeLeaveDetails# B on A.#MAllocationID#=B.#ModuleAllocationID#  left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#EmployeeCode# where A.#AllocationStatus#='Active' and (A.#CompletionStatus#=0 or A.#AssessmentStatus#=0 ) and cast(A.#ExpiryDate# as date)>=cast(now() as date) and A.#EmployeeCode# in ( ";
                    selectQuery = selectQuery + teamMembers + ")";
                    selectQuery = selectQuery.Replace('#', '"');
                    npgsql.Open();

                    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    dataAdapter.Fill(dtEmployees);

                    //if (dtEmployees!=null && dtEmployees.Rows.Count>0)
                    //{
                    //    foreach (DataRow item in dtEmployees.Rows)
                    //    {
                    //        string employeeCode = Convert.ToString(item["EmployeeCode"]);

                    //        DataRow[] result = QualtricTeamMembers.Select("EmployeeID= '" + employeeCode + "' ");

                    //        if (result!=null && result.Length>0)
                    //        {
                    //            item["EmployeeName"] = result[0]["EmployeeName"];
                    //            item["Manager"] = result[0]["ReportingTo"];
                    //        }

                    //    }
                    //}

                    npgsql.Close();
                }
                if (request.CurrentRole == "Global Admin")
                {
                    selectQuery = "select A.#MAllocationID# as moduleallocationid,A.#EmployeeCode#,concat(EMP.#FIRSTNAME#,' ',Coalesce(EMP.#LASTNAME#,'')) as EmployeeName,EMP.#Manager_Name# as Manager,TO_CHAR(A.#AllocationDate#, 'dd Mon  yyyy') as StartDate,TO_CHAR(A.#ExpiryDate#, 'dd Mon  yyyy') as EndDate,EMP.#DEPARTMENT# as Department,EMP.#Sub_Process# as Subprocess,A.#AllocationType# as EmployeeType,COALESCE(B.#Reason#,'') as reason,COALESCE(TO_CHAR(B.#ExpectedReturnDate#, 'dd Mon  yyyy'),'') as returndate   from #ModuleEmployeeAllocation# A left join #EmployeeLeaveDetails# B on A.#MAllocationID#=B.#ModuleAllocationID#  left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#EmployeeCode# where A.#AllocationStatus#='Active' and (A.#CompletionStatus#=0 or A.#AssessmentStatus#=0 ) and cast(A.#ExpiryDate# as date)>=cast(now() as date)";
                   
                    selectQuery = selectQuery.Replace('#', '"');
                    npgsql.Open();

                    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    dataAdapter.Fill(dtEmployees);

                   
                    npgsql.Close();

                }
                if (request.CurrentRole == "Geo Admin")
                {
                    string assignedcompanies = string.Empty;
                    DataTable dtCompanies = new DataTable();
                    dtCompanies =_qualtricsBL.gtAssignedCompany(request.TLId);
                    if (dtCompanies != null && dtCompanies.Rows.Count>0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            assignedcompanies = assignedcompanies + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        assignedcompanies = assignedcompanies.TrimEnd(',');
                    }
                    else
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Please assign companies to Geo Admin!";
                        return response;
                    }

                    selectQuery = "select A.#MAllocationID# as moduleallocationid,A.#EmployeeCode#,concat(EMP.#FIRSTNAME#,' ',Coalesce(EMP.#LASTNAME#,'')) as EmployeeName,EMP.#Manager_Name# as Manager,TO_CHAR(A.#AllocationDate#, 'dd Mon  yyyy') as StartDate,TO_CHAR(A.#ExpiryDate#, 'dd Mon  yyyy') as EndDate,EMP.#DEPARTMENT# as Department,EMP.#Sub_Process# as Subprocess,A.#AllocationType# as EmployeeType,COALESCE(B.#Reason#,'') as reason,COALESCE(TO_CHAR(B.#ExpectedReturnDate#, 'dd Mon  yyyy'),'') as returndate   from #ModuleEmployeeAllocation# A left join #EmployeeLeaveDetails# B on A.#MAllocationID#=B.#ModuleAllocationID#  left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#EmployeeCode# where A.#AllocationStatus#='Active' and (A.#CompletionStatus#=0 or A.#AssessmentStatus#=0 ) and cast(A.#ExpiryDate# as date)>=cast(now() as date)";
                    if (!string.IsNullOrEmpty(assignedcompanies))
                    {
                        selectQuery = selectQuery + " and EMP.#COMPANY_CODE# in (" + assignedcompanies + ")";
                    }
                    selectQuery = selectQuery.Replace('#', '"');
                    npgsql.Open();

                    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    dataAdapter.Fill(dtEmployees);


                    npgsql.Close();

                }
                    //using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    //{
                    //    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_GetEmployeeLeaveDetails
                    //                                                    ( 
                    //                                                        :empid,
                    //                                                        :fromDate,
                    //                                                        :toDate
                    //                                                    )", npgsqlConnection))
                    //    {
                    //        cmd.CommandType = CommandType.Text; //
                    //        if (!String.IsNullOrEmpty(request.EmpId))
                    //            cmd.Parameters.AddWithValue("empid", DbType.String).Value = request.EmpId;
                    //        else
                    //            cmd.Parameters.AddWithValue("empid", DbType.String).Value = DBNull.Value;

                    //        cmd.Parameters.AddWithValue("fromDate", DbType.String).Value = request.FromDate;
                    //        cmd.Parameters.AddWithValue("toDate", DbType.String).Value = request.ToDate;



                    //        npgsqlConnection.Open();

                    //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    //        dataAdapter.Fill(dtData);

                    //    }
                    //}
                    // Get the list of employee codes present in qualtri table
                    //List<string> qualtriEmpCodes = QualtricTeamMembers.AsEnumerable().Select(r => r.Field<string>("EmployeeID")).ToList();

                    //// Loop through each row in leaveupd table
                    //for (int i = dtData.Rows.Count - 1; i >= 0; i--)
                    //{
                    //    DataRow row = dtData.Rows[i];
                    //    string empCode = row.Field<string>("EmployeeId");

                    //    // Check if the employee code is not present in the qualtri table
                    //    if (!qualtriEmpCodes.Contains(empCode))
                    //    {
                    //        // If not present, delete the row from leaveupd table
                    //        dtData.Rows.RemoveAt(i);
                    //    }
                    //}

                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                response.responseCode = 1;
                response.responseMessage = "Success";


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEmployeeLeaveData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;


        }


    }
}
