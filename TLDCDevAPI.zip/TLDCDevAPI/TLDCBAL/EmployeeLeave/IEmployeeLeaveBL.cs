﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;
using static TLDCBAL.EmployeeLeave.EmployeeLeaveDTO;

namespace TLDCBAL.EmployeeLeave
{
    public interface IEmployeeLeaveBL
    {
        public ResponseClass InsertUpdateEmployeeLeave(EmployeeLeaveInsertUpdateModel request);
        public ResponseClass GetEmployeeLeaveData(EmployeeLeaveFilter request);





    }
}
