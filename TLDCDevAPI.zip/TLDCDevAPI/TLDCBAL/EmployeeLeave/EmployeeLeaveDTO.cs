﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.EmployeeLeave
{
    public class EmployeeLeaveDTO
    {
        public class EmployeeLeaveInsertUpdateModel
        {
            public int moduleallocationid { get; set; }
            public string EmployeeId { get; set; }
            public string EmployeeName { get; set; }
            public string EmployeeManager { get; set; }

            public DateTime ReturnDate { get; set; }
            public string Reason { get; set; }
            public DateTime CreatedOn { get; set; }
            public string CreatedBy { get; set; }
            public string IpAddress { get; set; }




        }


        public class EmployeeLeaveFilter
        {
            public string EmpId { get; set; }
            public DateTime FromDate { get; set; }
            public DateTime ToDate { get; set; }
            public string TLId { get; set; }

            public string CurrentEMPID { get; set; }
            public string CurrentRole { get; set; }
        }
    }
}
