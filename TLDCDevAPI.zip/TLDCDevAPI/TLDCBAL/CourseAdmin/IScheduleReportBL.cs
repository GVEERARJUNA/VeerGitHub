﻿using TLDCBAL.Common;

namespace TLDCBAL.CourseAdmin
{
    public interface IScheduleReportBL
    {
        ResponseClass GetReportNames(getreportnamesrequestDTO request);

        ResponseClass GetReportSchedule(getreportnamesrequestDTO request);

        ResponseClass AddEditScheduleReport(addnewscheduleRequestDTO request);

        ResponseClass GetScheduleDataForEdit(geteditdatarequestDTO request);

        ResponseClass DeleteScheduleReport(deleteschedulereportrequestDTO request);

        ResponseClass GetSchedulePageData(getschedulepagelistDTO request);
    }
}