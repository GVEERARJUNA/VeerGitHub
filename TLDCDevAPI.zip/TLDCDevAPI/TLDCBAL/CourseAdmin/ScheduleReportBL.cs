﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;

namespace TLDCBAL.CourseAdmin
{
    public class ScheduleReportBL : IScheduleReportBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;
        private IQualtricsDataBL _qualtricsBL;
        private ISchedulerBL _scheduleBL;

        public ScheduleReportBL(IServiceConnect serviceconnect, IOptions<IDBConnection> app, IQualtricsDataBL qualtricsBL, ISchedulerBL scheduleBL)
        {
            _serviceconnect = serviceconnect;
            appSettings = app;
            _qualtricsBL = qualtricsBL;
            _scheduleBL = scheduleBL;
        }

        public ResponseClass GetReportNames(getreportnamesrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_get_reportnames
                                                                        ( 
                                                                            :p_employeecode
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.EmplopyeeCode))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmplopyeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetReportNames", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetReportSchedule(getreportnamesrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_get_report_schedule
                                                                        ( 
                                                                            :p_searchid,:p_searchaction,:p_pageno,:p_rowno,:p_employeecode,:p_employeerole
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.SearchID))
                            cmd.Parameters.AddWithValue("p_searchid", DbType.String).Value = request.SearchID;
                        else
                            cmd.Parameters.AddWithValue("p_searchid", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.SearchAction))
                            cmd.Parameters.AddWithValue("p_searchaction", DbType.String).Value = request.SearchAction;
                        else
                            cmd.Parameters.AddWithValue("p_searchaction", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_rowno", DbType.String).Value = request.RowsOfPage;

                        if (!String.IsNullOrEmpty(request.EmplopyeeCode))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmplopyeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EmplopyeeRole))
                            cmd.Parameters.AddWithValue("p_employeerole", DbType.String).Value = request.EmplopyeeRole;
                        else
                            cmd.Parameters.AddWithValue("p_employeerole", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        int recordcount = 1;
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                            if (request.PageNumber != 0)
                            {
                                //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                                decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                                int recordPages = Convert.ToInt32(noOfPages);

                                if (noOfPages > recordPages)
                                {
                                    recordPages = recordPages + 1;
                                }

                                response.recordCount = recordPages;
                            }

                            dtEmployees.Columns.Add("encryptedID");
                            CommonFunction function = new CommonFunction();
                            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                            {
                                foreach (DataRow item in dtEmployees.Rows)
                                {
                                    item["encryptedID"] = function.Encrypt(Convert.ToString(item["primaryid"]));
                                }
                            }
                        }
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetReportNames", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass AddEditScheduleReport(addnewscheduleRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_insert_edit
                                                                        ( 
                                                                            :p_primaryid,:p_reportid,:p_displayname,:p_reportfor,
                                                                            :p_emailto,
                                                                            :p_recurrencefrequency,:p_emptyflag,
                                                                            :p_createdby,:p_createdipaddress,
                                                                            :p_startdate,:p_recurrencetime,:p_recurrencetimezone,
                                                                            :p_endafterrecurrence,:p_enddate,
                                                                            :p_repeateverydaycount,:p_repeateveryweekcount,:p_repeateverymonthcount,:p_repeateveryyearcount,
                                                                            :p_repeatweekdays,:p_repeatmonthname,:p_repeatmonthdate,:p_repeatyearmonth,:p_repeatyearmonthdate,
                                                                            :p_dailymode,:p_monthmode,:p_yearmode,
                                                                            :p_serverstartdatetime
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.PrimaryID))
                            cmd.Parameters.AddWithValue("p_primaryid", DbType.String).Value = request.PrimaryID;
                        else
                            cmd.Parameters.AddWithValue("p_primaryid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.ReportID))
                            cmd.Parameters.AddWithValue("p_reportid", DbType.String).Value = request.ReportID;
                        else
                            cmd.Parameters.AddWithValue("p_reportid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.DisplayName))
                            cmd.Parameters.AddWithValue("p_displayname", DbType.String).Value = request.DisplayName;
                        else
                            cmd.Parameters.AddWithValue("p_displayname", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.RunReportFor))
                            cmd.Parameters.AddWithValue("p_reportfor", DbType.String).Value = request.RunReportFor;
                        else
                            cmd.Parameters.AddWithValue("p_reportfor", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EmailTo))
                            cmd.Parameters.AddWithValue("p_emailto", DbType.String).Value = request.EmailTo;
                        else
                            cmd.Parameters.AddWithValue("p_emailto", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.RecurrenceFrequency))
                            cmd.Parameters.AddWithValue("p_recurrencefrequency", DbType.String).Value = request.RecurrenceFrequency;
                        else
                            cmd.Parameters.AddWithValue("p_recurrencefrequency", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_emptyflag", DbType.String).Value = request.EmptyFlag;

                        if (!String.IsNullOrEmpty(request.CreatedBy))
                            cmd.Parameters.AddWithValue("p_createdby", DbType.String).Value = request.CreatedBy;
                        else
                            cmd.Parameters.AddWithValue("p_createdby", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CreatedIPAddress))
                            cmd.Parameters.AddWithValue("p_createdipaddress", DbType.String).Value = request.CreatedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_createdipaddress", DbType.String).Value = DBNull.Value;


                        if (!String.IsNullOrEmpty(request.StartDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = request.StartDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.RecurrenceTime))
                            cmd.Parameters.AddWithValue("p_recurrencetime", DbType.String).Value = request.RecurrenceTime;
                        else
                            cmd.Parameters.AddWithValue("p_recurrencetime", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.RecurrenceTimeZone))
                            cmd.Parameters.AddWithValue("p_recurrencetimezone", DbType.String).Value = request.RecurrenceTimeZone;
                        else
                            cmd.Parameters.AddWithValue("p_recurrencetimezone", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_endafterrecurrence", DbType.String).Value = request.EndAfterRecurrence;

                        if (!String.IsNullOrEmpty(request.RecurrenceEndDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = request.RecurrenceEndDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_repeateverydaycount", DbType.String).Value = request.RepeatEveryDayCount;
                        cmd.Parameters.AddWithValue("p_repeateveryweekcount", DbType.String).Value = request.RepeatEveryWeekCount;
                        cmd.Parameters.AddWithValue("p_repeateverymonthcount", DbType.String).Value = request.RepeatEveryMonthCount;
                        cmd.Parameters.AddWithValue("p_repeateveryyearcount", DbType.String).Value = request.RepeatEveryYearCount;

                        if (!String.IsNullOrEmpty(request.RepeatWeekDays))
                            cmd.Parameters.AddWithValue("p_repeatweekdays", DbType.String).Value = request.RepeatWeekDays;
                        else
                            cmd.Parameters.AddWithValue("p_repeatweekdays", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.RepeatMonthName))
                            cmd.Parameters.AddWithValue("p_repeatmonthname", DbType.String).Value = request.RepeatMonthName;
                        else
                            cmd.Parameters.AddWithValue("p_repeatmonthname", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.RepeatMonthDate))
                            cmd.Parameters.AddWithValue("p_repeatmonthdate", DbType.String).Value = request.RepeatMonthDate;
                        else
                            cmd.Parameters.AddWithValue("p_repeatmonthdate", DbType.String).Value = DBNull.Value;


                        if (!String.IsNullOrEmpty(request.RepeatYearMonth))
                            cmd.Parameters.AddWithValue("p_repeatyearmonth", DbType.String).Value = request.RepeatYearMonth;
                        else
                            cmd.Parameters.AddWithValue("p_repeatyearmonth", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_repeatyearmonthdate", DbType.String).Value = request.RepeatYearMonthDate;


                        if (!String.IsNullOrEmpty(request.DailyMode))
                            cmd.Parameters.AddWithValue("p_dailymode", DbType.String).Value = request.DailyMode;
                        else
                            cmd.Parameters.AddWithValue("p_dailymode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.MonthMode))
                            cmd.Parameters.AddWithValue("p_monthmode", DbType.String).Value = request.MonthMode;
                        else
                            cmd.Parameters.AddWithValue("p_monthmode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.YearlyMode))
                            cmd.Parameters.AddWithValue("p_yearmode", DbType.String).Value = request.YearlyMode;
                        else
                            cmd.Parameters.AddWithValue("p_yearmode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.ServerStartDateTime))
                            cmd.Parameters.AddWithValue("p_serverstartdatetime", DbType.String).Value = request.ServerStartDateTime;
                        else
                            cmd.Parameters.AddWithValue("p_serverstartdatetime", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AddEditScheduleReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetScheduleDataForEdit(geteditdatarequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_get_editdata
                                                                        ( 
                                                                            :p_scheduleid
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.ScheduleID))
                            cmd.Parameters.AddWithValue("p_scheduleid", DbType.String).Value = request.ScheduleID;
                        else
                            cmd.Parameters.AddWithValue("p_scheduleid", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetScheduleDataForEdit", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass DeleteScheduleReport(deleteschedulereportrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_report_delete
                                                                        ( 
                                                                            :p_scheduleid,:p_createdby,:p_createdipaddress
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.ScheduleID))
                            cmd.Parameters.AddWithValue("p_scheduleid", DbType.String).Value = request.ScheduleID;
                        else
                            cmd.Parameters.AddWithValue("p_scheduleid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CreatedBy))
                            cmd.Parameters.AddWithValue("p_createdby", DbType.String).Value = request.CreatedBy;
                        else
                            cmd.Parameters.AddWithValue("p_createdby", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CreatedIPAddress))
                            cmd.Parameters.AddWithValue("p_createdipaddress", DbType.String).Value = request.CreatedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_createdipaddress", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);
                        }
                    }
                }

                
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("DeleteScheduleReport", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetSchedulePageData(getschedulepagelistDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;
                dtFrom = Convert.ToDateTime(request.fromdate);
                fromDate = Convert.ToDateTime(request.fromdate).ToString("yyyy-MM-dd");

                dtTo = Convert.ToDateTime(request.todate);
                toDate = Convert.ToDateTime(request.todate).ToString("yyyy-MM-dd");

                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM schedule_getdetail_for_schedule_page
                                                                        ( 
                                                                            :p_fromdate,:p_todate
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("p_fromdate", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(toDate))
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = toDate;
                        else
                            cmd.Parameters.AddWithValue("p_todate", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                       
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetReportNames", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }



    }
}
