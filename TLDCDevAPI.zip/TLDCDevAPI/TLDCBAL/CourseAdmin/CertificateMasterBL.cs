﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.EmailManagement;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;

namespace TLDCBAL.CourseAdmin
{
    public class CertificateMasterBL : ICertificateMasterBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;
        private IQualtricsDataBL _qualtricsBL;

        public CertificateMasterBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
        }

        public ResponseClass AddCertificate(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                // certificate number
                //sequence number

                int sequenceNo = 0;
                string seqQuery = "SELECT coalesce(max(#SequenceNo#),0) as #SequenceNo# FROM public.#CertificateMaster#";

                seqQuery = seqQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(seqQuery, npgsqlCon);

                NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                if (npgsqlDataReader1.Read())
                {
                    sequenceNo = Convert.ToInt32(npgsqlDataReader1[0]) + 1;

                    request.CertificateNumber = "C" + string.Format("{0:000}", sequenceNo);
                    request.SequenceNo = sequenceNo;
                }
                else
                {
                    ++sequenceNo;
                    request.SequenceNo = sequenceNo;
                    request.CertificateNumber = "C" + string.Format("{0:000}", sequenceNo);
                }

                npgsqlCon.Close();

                // Save certificate

                DataTable dtData = new DataTable();
                request.IsDeleted = 0;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_certificate_master(                                                                        
                                                                    :p_action,
                                                                    :employeeid,
                                                                    :certificatenumber,
                                                                    :templatename,
                                                                    :filepath,
                                                                    :isdeleted,
                                                                    :sequenceno,
                                                                    :department,
                                                                    :geo
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = "ADD";
                        cmd.Parameters.AddWithValue("employeeid", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("certificatenumber", DbType.String).Value = request.CertificateNumber;
                        cmd.Parameters.AddWithValue("templatename", DbType.String).Value = request.TemplateName;
                        cmd.Parameters.AddWithValue("filepath", DbType.String).Value = request.FilePath;
                        cmd.Parameters.AddWithValue("isdeleted", DbType.Int32).Value = request.IsDeleted;
                        cmd.Parameters.AddWithValue("sequenceno", DbType.Int32).Value = request.SequenceNo;
                        cmd.Parameters.AddWithValue("department", DbType.Int32).Value = request.Department;
                        cmd.Parameters.AddWithValue("geo", DbType.Int32).Value = request.Geo;
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);
                        npgsqlConnection.Close();

                    }
                }

                //Send email to HTML developer
                //SendCertificateManil(request);

                response.responseCode = 1;
                response.responseMessage = "Success";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        private void SendCertificateManil(CertificateMasterDTO certificate)
        {
            try
            {
                string outputResult = string.Empty;
                MailDetails request = new MailDetails();
                request.Subject = "New Certificate Request";
                request.MailActualBody = "We got new certificate template to convert in HTML";

                // set to list
                List<ToList> lstToList = new List<ToList>();
                ToList to = new ToList();
                to.EmailAddress = "gaurav.singh@teamhgs.com";
                lstToList.Add(to);
                request.ToList = lstToList;

                // set to list
                List<BCCList> lstBccList = new List<BCCList>();
                BCCList obj = new BCCList();
                obj.EmailAddress = "shamsuddin.ansari@teamhgs.com";
                lstBccList.Add(obj);
                request.bCCLists = lstBccList;
                request.Subject = "Certificate Template " + certificate.CertificateNumber;
                request.MailActualBody = "New Template has been stored.";
                request.Sender = "anil.gorule@teamhgs.com";
                request.SenderName = "Anil Gorule";

                outputResult = MailHelper.SendMail(request, appSettings.Value.Redirection, appSettings.Value.MailRedirectionTo, appSettings.Value.MailRedirectionCc);
            }
            catch(Exception ex)
            {
                // log 
            }
            
        }

        public ResponseClass EditCertificate(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            DataTable dtData = new DataTable();

            try
            {   

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_certificate_master(                                                                        
                                                                    :p_action,
                                                                    :employeeid,
                                                                    :certificatenumber,
                                                                    :templatename,
                                                                    :filepath,
                                                                    :isdeleted,
                                                                    :sequenceno,
                                                                    :department,
                                                                    :geo
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = "EDIT";
                        cmd.Parameters.AddWithValue("employeeid", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("certificatenumber", DbType.String).Value = request.CertificateNumber;
                        cmd.Parameters.AddWithValue("templatename", DbType.String).Value = request.TemplateName;
                        cmd.Parameters.AddWithValue("filepath", DbType.String).Value = request.FilePath;
                        cmd.Parameters.AddWithValue("isdeleted", DbType.Int32).Value = request.IsDeleted;
                        cmd.Parameters.AddWithValue("sequenceno", DbType.Int32).Value = request.SequenceNo;
                        cmd.Parameters.AddWithValue("department", DbType.Int32).Value = request.Department;
                        cmd.Parameters.AddWithValue("geo", DbType.Int32).Value = request.Geo;
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);
                        npgsqlConnection.Close();
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass DeleteCertificate(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                // Save certificate

                DataTable dtData = new DataTable();
                request.IsDeleted = 1;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_certificate_master(                                                                        
                                                                    :p_action,
                                                                    :employeeid,
                                                                    :certificatenumber,
                                                                    :templatename,
                                                                    :filepath,
                                                                    :isdeleted,
                                                                    :sequenceno,
                                                                    :department,
                                                                    :geo
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = "DELETE";
                        cmd.Parameters.AddWithValue("employeeid", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("certificatenumber", DbType.String).Value = request.CertificateNumber;
                        cmd.Parameters.AddWithValue("templatename", DbType.String).Value = "";
                        cmd.Parameters.AddWithValue("filepath", DbType.String).Value = "";
                        cmd.Parameters.AddWithValue("isdeleted", DbType.Int32).Value = 1;
                        cmd.Parameters.AddWithValue("sequenceno", DbType.Int32).Value = 0;
                        cmd.Parameters.AddWithValue("department", DbType.Int32).Value = "";
                        cmd.Parameters.AddWithValue("geo", DbType.Int32).Value = "";
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);
                        npgsqlConnection.Close();
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass CertificateNameList(CertificateListDTO request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                // certificate list

                DataTable dtData = new DataTable();

                string seqQuery = "select a.#CertificateNumber#, a.#TemplateName# from #CertificateMaster# a " +
                    "left join #CertificateAllocation# b on b.#CertificateNumber# = a.#CertificateNumber# " +
                    "where a.#IsDeleted# = 0 group by a.#CertificateNumber#,a.#TemplateName# " +
                    "order by a.#CertificateNumber# desc";

                seqQuery = seqQuery.Replace("@CerNumber", request.CertificateNumber);
                seqQuery = seqQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(seqQuery, npgsqlCon);

                NpgsqlDataAdapter npgsqlDataReader1 = new NpgsqlDataAdapter(npgsqlCommand1);

                npgsqlDataReader1.Fill(dtData);

                npgsqlCon.Close();
                response.responseCode = 1;
                response.responseMessage = "Success";
                response.responseJSON = JsonConvert.SerializeObject(dtData);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }


        public ResponseClass CertificateList(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                // certificate list

                DataTable dtData = new DataTable();

                string seqQuery = "select a.#CertificateNumber#, a.#TemplateName#, STRING_AGG(b.#GEO# :: text,',') as geo " +
                    "from #CertificateMaster# a left join  #CertificateAllocation# b on b.#CertificateNumber# = a.#CertificateNumber# " +
                    "where a.#IsDeleted# = 0 ";

                string companiestopass = string.Empty;
                if (request.CurrentRoleName == "Program Manager")
                {
                    seqQuery = seqQuery + " and b.#GEO#='" + request.CountryName + "'" + " and a.#CreatedBy# = " + "'" + request.EmployeeId + "'";
                    
                }
                else if (request.CurrentRoleName == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmployeeId);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        seqQuery = seqQuery + " and b.#GEO# in (" + companiestopass + ")";

                    }
                }

                if(request.CertificateNumber != null && request.CertificateNumber != "")
                {
                    seqQuery = seqQuery + " and a.#CertificateNumber# = '" + request.CertificateNumber + "'";
                }
                if (request.TemplateName != null && request.TemplateName != "")
                {
                    seqQuery = seqQuery + " and a.#CertificateNumber# = '" + request.TemplateName + "'";
                }
                //if (request.CountryName != null && request.CountryName != "")
                //{
                //    seqQuery = seqQuery + " and b.#GEO# = " + request.CountryName + " ";
                //}

                seqQuery = seqQuery + " group by a.#CertificateNumber#,a.#TemplateName# order by a.#CertificateNumber# desc;";
                
                seqQuery = seqQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(seqQuery, npgsqlCon);

                NpgsqlDataAdapter npgsqlDataReader1 = new NpgsqlDataAdapter(npgsqlCommand1);

                npgsqlDataReader1.Fill(dtData);

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseMessage = "Success";
                response.responseJSON = JsonConvert.SerializeObject(dtData);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        //public ResponseClass CertificateList(CertificateMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    string pgsqlConnection = appSettings.Value.DbConnection;
        //    NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

        //    try
        //    {
        //        // Save certificate

        //        DataTable dtData = new DataTable();
        //        request.IsDeleted = 0;

        //        using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
        //        {
        //            using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_certificate_master_list(                                                                        
                                                                   
        //                                                            )", npgsqlConnection))
        //            {
        //                cmd.CommandType = CommandType.Text;

        //                //cmd.Parameters.AddWithValue("p_action", DbType.String).Value = "ADD";

        //                npgsqlConnection.Open();

        //                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
        //                dataAdapter.Fill(dtData);
        //            }
        //        }

        //        response.responseCode = 1;
        //        response.responseMessage = "Success";
        //        response.responseJSON = JsonConvert.SerializeObject(dtData);

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}
        public ResponseClass GetCertificate(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                // certificate number
                //sequence number

                int sequenceNo = 0;
                string seqQuery = "SELECT * FROM public.#CertificateMaster# where #CertificateNumber# = '@CerNumber'";

                seqQuery = seqQuery.Replace("@CerNumber", request.CertificateNumber);
                seqQuery = seqQuery.Replace('#', '"');

                npgsqlCon.Open();


                DataTable dtData = new DataTable();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(seqQuery, npgsqlCon);

                NpgsqlDataAdapter npgsqlDataReader1 = new NpgsqlDataAdapter(npgsqlCommand1);

                npgsqlDataReader1.Fill(dtData);
                //npgsqlCon.Close();

                seqQuery = "select * from #CertificateAllocation#  where #CertificateNumber# = '@CerNumber'";

                seqQuery = seqQuery.Replace("@CerNumber", request.CertificateNumber);
                seqQuery = seqQuery.Replace('#', '"');

                DataTable dtAllocation = new DataTable();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(seqQuery, npgsqlCon);

                NpgsqlDataAdapter npgsqlDataReader = new NpgsqlDataAdapter(npgsqlCommand);

                npgsqlDataReader.Fill(dtAllocation);

                npgsqlCon.Close();

                response.responseJSON = JsonConvert.SerializeObject(dtData);
                response.responseJSONSecondary = JsonConvert.SerializeObject(dtAllocation);
                response.responseCode = 1;
                response.responseMessage = "Success";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }


    }
}
