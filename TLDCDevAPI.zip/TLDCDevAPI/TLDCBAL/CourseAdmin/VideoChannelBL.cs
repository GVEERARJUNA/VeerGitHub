﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;

namespace TLDCBAL.CourseAdmin
{
    public class VideoChannelBL : IVideoChannelBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        private readonly IServiceConnect _serviceconnect;
        private ISchedulerBL _scheduleBL;

        public VideoChannelBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, ISchedulerBL scheduleBL)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;
            _scheduleBL = scheduleBL;
        }

        public ResponseClass GetVideoChannelList(ChannelReuest request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_get_videochannellist(
                                                                    :p_currentemployee,
                                                                    :p_currentrole
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.currentRole;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetVideoChannelList", "61", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass EditVideoChannel(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_editvideochannel(
                                                                    :p_employeeId,
                                                                    :p_channelId
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                //get video data
                DataTable dtvData = new DataTable();
                string pgsqlConnection2 = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection2 = new NpgsqlConnection(pgsqlConnection2))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_get_channelvideos(
                                                                    :p_employeeId,
                                                                    :p_channelId
                                                                    )", npgsqlConnection2))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);

                        npgsqlConnection2.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtvData);

                        npgsqlConnection2.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseJSONSecondary = JsonConvert.SerializeObject(dtvData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("EditVideoChannel", "102", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetWatchVideoChannel(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_watchvideochannel(
                                                                    :p_employeeId,
                                                                    :p_videocode,
                                                                    :p_channelId
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_videocode", DbType.String).Value = int.Parse(request.videocode);
                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                //get video data
                DataTable dtvData = new DataTable();
                string pgsqlConnection2 = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection2 = new NpgsqlConnection(pgsqlConnection2))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_get_channelvideos(
                                                                    :p_employeeId,
                                                                    :p_channelId
                                                                    )", npgsqlConnection2))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);

                        npgsqlConnection2.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtvData);

                        npgsqlConnection2.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseJSONSecondary = JsonConvert.SerializeObject(dtvData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("EditVideoChannel", "102", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass CreateChannelVideoViewCount(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_updateViewCount(
                                                                    :p_employeeId,
                                                                    :p_videocode,
                                                                    :p_channelId
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_videocode", DbType.String).Value = int.Parse(request.videocode);
                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                
                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("CreateChannelVideoViewCount", "102", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass ViewChannel(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_viewchannel(
                                                                    :p_employeeId,
                                                                    :p_channelId
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                //get video data
                DataTable dtvData = new DataTable();
                string pgsqlConnection2 = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection2 = new NpgsqlConnection(pgsqlConnection2))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_get_channelvideos(
                                                                    :p_employeeId,
                                                                    :p_channelId
                                                                    )", npgsqlConnection2))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);

                        npgsqlConnection2.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtvData);

                        npgsqlConnection2.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseJSONSecondary = JsonConvert.SerializeObject(dtvData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("EditVideoChannel", "102", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass InsertEditVideoChannel(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                List<string> strvdolist = new List<string>();
                if(request.videoList != null && request.videoList.Count > 0)
                {
                    string strvdo = string.Empty;
                    foreach (ChannelVideoDTO item in request.videoList)
                    {
                        strvdo = item.videotitle; //1
                        strvdo = strvdo + ":::" + item.videoNumber; //2
                        strvdo = strvdo + ":::" + item.videoThumbnailName; //3
                        strvdo = strvdo + ":::" + item.thumbnailpath; //4
                        strvdo = strvdo + ":::" + item.videopath; //5
                        strvdo = strvdo + ":::" + item.videoFileName; //6
                        strvdo = strvdo + ":::" + item.duration; //7
                        strvdo = strvdo + ":::" + item.videoDesc; //8

                        if (!string.IsNullOrEmpty(strvdo))
                        {
                            strvdolist.Add(strvdo);
                        }
                    }
                }


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_inserteditvideochannel(
                                                                    :p_employeeId,
                                                                    :p_currentrole,
                                                                    :p_title,
                                                                    :p_about,
                                                                    :p_description,
                                                                    :p_thumbnailpath,
                                                                    :p_strvdolist
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.currentRole;
                        cmd.Parameters.AddWithValue("p_title", DbType.String).Value = request.title;
                        cmd.Parameters.AddWithValue("p_about", DbType.String).Value = request.about;
                        cmd.Parameters.AddWithValue("p_description", DbType.String).Value = request.description;
                        cmd.Parameters.AddWithValue("p_thumbnailpath", DbType.String).Value = request.thumbnailpath;
                        cmd.Parameters.AddWithValue("p_strvdolist", DbType.Object).Value = strvdolist;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditVideoChannel", "104", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass editVideoChanneldata(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;

                List<string> strvdolist = new List<string>();
                if(request.videoList != null && request.videoList.Count > 0)
                {
                    string strvdo = string.Empty;
                    foreach (ChannelVideoDTO item in request.videoList)
                    {
                        strvdo = item.videotitle; //1
                        strvdo = strvdo + ":::" + item.videoNumber; //2
                        strvdo = strvdo + ":::" + item.videoThumbnailName; //3
                        strvdo = strvdo + ":::" + item.thumbnailpath; //4
                        strvdo = strvdo + ":::" + item.videopath; //5
                        strvdo = strvdo + ":::" + item.videoFileName; //6
                        strvdo = strvdo + ":::" + item.duration; //7
                        strvdo = strvdo + ":::" + item.videoDesc; //8

                        if (!string.IsNullOrEmpty(strvdo))
                        {
                            strvdolist.Add(strvdo);
                        }
                    }
                }


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_editvideochanneldata(
                                                                    :p_employeeId,
                                                                    :p_currentrole,
                                                                    :p_title,
                                                                    :p_about,
                                                                    :p_description,
                                                                    :p_thumbnailpath,
                                                                    :p_channelid
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.currentRole;
                        cmd.Parameters.AddWithValue("p_title", DbType.String).Value = request.title;
                        cmd.Parameters.AddWithValue("p_about", DbType.String).Value = request.about;
                        cmd.Parameters.AddWithValue("p_description", DbType.String).Value = request.description;
                        cmd.Parameters.AddWithValue("p_thumbnailpath", DbType.String).Value = request.thumbnailpath !=null ? request.thumbnailpath  : "";
                        cmd.Parameters.AddWithValue("p_channelid", DbType.String).Value = int.Parse(request.channelId);

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("editVideoChanneldata", "104", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass UploadVideotoChannel(ChannelVideoDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_uploadvideo(
                                                                    :p_videotitle,
                                                                    :p_videopath,
                                                                    :p_videoFileName,
                                                                    :p_thumbnailpath,
                                                                    :p_videoThumbnailName,
                                                                    :p_duration,
                                                                    :p_description,
                                                                    :p_EmployeeId,
                                                                    :p_videoNumber,
                                                                    :p_currentrole,
                                                                    :p_channelid
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_videotitle", DbType.String).Value = request.videotitle;
                        cmd.Parameters.AddWithValue("p_videopath", DbType.String).Value = request.videopath;
                        cmd.Parameters.AddWithValue("p_videoFileName", DbType.String).Value = request.videoFileName;
                        cmd.Parameters.AddWithValue("p_thumbnailpath", DbType.String).Value = request.thumbnailpath;
                        cmd.Parameters.AddWithValue("p_videoThumbnailName", DbType.String).Value = request.videoThumbnailName;
                        cmd.Parameters.AddWithValue("p_duration", DbType.String).Value = request.duration;
                        cmd.Parameters.AddWithValue("p_description", DbType.String).Value = request.videoDesc;
                        cmd.Parameters.AddWithValue("p_EmployeeId", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("p_videoNumber", DbType.String).Value = request.videoNumber;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        cmd.Parameters.AddWithValue("p_channelid", DbType.String).Value = int.Parse(request.channelid);

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        if (dtData != null && dtData.Rows.Count > 0 )
                        {
                            try
                            {
                                var scResponse = _scheduleBL.ChannelVideoNotification(dtData.Rows[0].ItemArray[0].ToString(),request.channelid);
                            }
                            catch (Exception)
                            {


                            }
                        }

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditVideoChannel", "104", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass SubscribeChannel(SubscribeChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_channelsubscription(
                                                                    :p_employeeid,
                                                                    :p_channelid,
                                                                    :p_action
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeid", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("p_channelid", DbType.String).Value = int.Parse(request.ChannelId);
                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("SubscribeChannel", "145", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass DeleteChannelVideo(VideoLikeDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_deletechannel(
                                                                    :p_employeeid,
                                                                    :p_channelid,
                                                                    :p_action
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeid", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("p_channelid", DbType.String).Value = int.Parse(request.ChannelId);
                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = "delete";
                        
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("DeleteChannelVideo", "145", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass DeleteMyChannelVideo(VideoLikeDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_deletechannelvideo(
                                                                    :p_employeeid,
                                                                    :p_videoid,
                                                                    :p_action
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeid", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("p_videoid", DbType.String).Value = int.Parse(request.VideoId);
                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = "delete";
                        
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("DeleteChannelVideo", "145", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass UpdateLikes(VideoLikeDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_updatelikes(
                                                                    :p_employeeid,
                                                                    :p_channelid,
                                                                    :p_videoId,
                                                                    :p_action
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_employeeid", DbType.String).Value = request.EmployeeId;
                        cmd.Parameters.AddWithValue("p_channelid", DbType.String).Value = int.Parse(request.ChannelId);
                        cmd.Parameters.AddWithValue("p_videoId", DbType.String).Value = int.Parse(request.VideoId);
                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("UpdateLikes", "145", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass searchProgramManager(allocateEmployeeRequest request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_searchProgramManager(
                                                                    :p_currentRole,
                                                                    :p_currentcompany,
                                                                    :p_EmployeeID,
                                                                    :p_LoginEMPCode
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_currentRole", DbType.String).Value = request.currentRole;
                        cmd.Parameters.AddWithValue("p_currentcompany", DbType.String).Value = request.currentcompany;
                        cmd.Parameters.AddWithValue("p_EmployeeID", DbType.String).Value =request.EmployeeID;
                        cmd.Parameters.AddWithValue("p_LoginEMPCode", DbType.String).Value =request.LoginEMPCode;
                        
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("UpdateLikes", "145", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass AssignUserAccess(ChannelAccessDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_assignuseraccess(
                                                                    :p_channelId,
                                                                    :p_employeeId,
                                                                    :p_accessGivenBy,
                                                                    :p_action
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);
                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_accessGivenBy", DbType.String).Value = request.accessGivenBy;
                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = dtData.Rows[0].ItemArray[1].ToString();
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignUserAccess", "145", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass UpdateAccessList(ChannelAccessDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtData = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_getassignuseraccess(
                                                                    :p_channelId,
                                                                    :p_employeeId,
                                                                    :p_accessGivenBy,
                                                                    :p_action
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("p_channelId", DbType.String).Value = int.Parse(request.channelId);
                        cmd.Parameters.AddWithValue("p_employeeId", DbType.String).Value = request.employeeId;
                        cmd.Parameters.AddWithValue("p_accessGivenBy", DbType.String).Value = request.accessGivenBy;
                        cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtData);

                        npgsqlConnection.Close();
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(dtData); 
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("AssignUserAccess", "145", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
    }
}
