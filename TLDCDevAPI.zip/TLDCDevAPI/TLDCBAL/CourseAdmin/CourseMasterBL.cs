﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using System.Linq;
using System.Reflection;

namespace TLDCBAL.CourseAdmin
{
    public class CourseMasterBL : ICourseMasterBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;
        private IQualtricsDataBL _qualtricsBL;

        public CourseMasterBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
        }
        public ResponseClass ManageCourseMaster(manageCourseMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;


                if (!string.IsNullOrEmpty(request.FromDate))
                {
                    try
                    {
                        dtFrom = Convert.ToDateTime(request.FromDate);
                        fromDate = Convert.ToDateTime(request.FromDate).ToString("yyyy-MM-dd");
                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("ManageCourse", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;
                    }
                }
                if (!string.IsNullOrEmpty(request.ToDate))
                {
                    try
                    {
                        dtTo = Convert.ToDateTime(request.ToDate);
                        toDate = Convert.ToDateTime(request.ToDate).AddDays(1).ToString("yyyy-MM-dd");
                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("ManageCourse", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;
                    }
                }

                if (dtFrom > dtTo)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid date range selected!";
                    return response;
                }
                TimeSpan difference = dtTo - dtFrom;
                if (difference.TotalDays > 60)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
                    return response;
                }


                string selectQuery = string.Empty;

                selectQuery = "select CM.#CourseID# as courseid, CM.#CourseCode# as coursecode,CM.#CourseName# as coursename,CM.#CourseCategory# as coursecategory,CM.#CourseType# as coursetype,CM.#CourseSize# as coursesize,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,CM.#CreatedBy# as insertedemployeeid,TO_CHAR(CM.#CreatedOn#, 'dd-Mon-yyyy') as createddate,EM.#Company_Name# as companyname from #CourseMaster# CM inner join #EmployeeMaster# EM on CM.#CreatedBy# = EM.#EXTERNALDATAREFERENCE#";
                //selectQuery = selectQuery + " where (CM.#DeletedFlag#)=0 and (CM.#CreatedOn#::date) >= '" + fromDate + "' and (CM.#CreatedOn#::date) <= '" + toDate + "' and lower(CM.#CourseCode#) like =lower('%" + request.CourseCode + "%') and lower(CM.#CourseName#) like =lower('%" + request.CourseName + "%')";
                selectQuery = selectQuery + " where  (CM.#DeletedFlag#)=0 ";
                //and (CM.#CreatedOn#::date) >= '" + fromDate + "' and (CM.#CreatedOn#::date) <= '" + toDate + "'
                if (!string.IsNullOrEmpty(request.CourseCode))
                {
                    selectQuery = selectQuery + " and lower(CM.#CourseCode#) like lower('%" + request.CourseCode + "%')";
                }
                if (!string.IsNullOrEmpty(request.CourseName))
                {
                    selectQuery = selectQuery + " and lower(CM.#CourseName#) like lower('%" + request.CourseName + "%')";
                }
                if (request.CourseType != "Select")
                {
                    selectQuery = selectQuery + " and lower(CM.#CourseType#)=lower('" + request.CourseType + "')";
                }

                string companiestopass = string.Empty;

                if (request.currentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and (CM.#CreatedBy#='" + request.LoginEMPCode + "' or CM.#CurrentRole#='Global Admin' ";

                    selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";

                }
                else if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //{
                    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    {
                    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    }

                    //    companiestopass = companiestopass.TrimEnd(',');

                    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //}

                    //DataTable dtCompanies = new DataTable();
                    //dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);

                    selectQuery = selectQuery + " and (CM.#CurrentRole#='Global Admin' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    //  selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )";



                    selectQuery = selectQuery + " )";

                }
                if (!string.IsNullOrEmpty(request.CompanyCode))
                {
                    selectQuery = selectQuery + " and EM.#COMPANY_CODE#='" + request.CompanyCode + "'";
                }


                selectQuery = selectQuery + "order by CM.#CourseID# desc";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);
                response.responseCode = 1;
                CommonFunction function = new CommonFunction();
                trainingGroup.Columns.Add("encryptedID");
                if (trainingGroup != null && trainingGroup.Rows.Count > 0)
                {
                    foreach (DataRow item in trainingGroup.Rows)
                    {
                        item["encryptedID"] = function.Encrypt(Convert.ToString(item["courseid"]));
                    }
                }

                #region Pagination
                int recordcount = 1;
                if (trainingGroup != null && trainingGroup.Rows.Count > 0)

                {

                    recordcount = trainingGroup.Rows.Count;

                    if (request.PageNumber != -1)

                    {

                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)

                        {

                            recordPages = recordPages + 1;

                        }

                        response.recordCount = recordPages;

                    }

                }

                var _trainingGroup = trainingGroup.AsEnumerable().Skip((request.PageNumber - 1) * request.RowsOfPage)

                        .Take(request.RowsOfPage).CopyToDataTable();

                #endregion

                response.responseJSON = JsonConvert.SerializeObject(_trainingGroup);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass ManageCourseMasterPaging(manageCourseMasterrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();

              
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_manage_course
                                                                        ( 
                                                                            :pcurrentemployeeid,
                                                                            :pcurrentemployeerole,:pcoursecode,:pcoursetype,:pusercompany,
                                                                            :p_pageno,:p_recordno,:psearchcompany,:pcoursename,:pobjectcode
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.LoginEMPCode))
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.LoginEMPCode;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.currentRole))
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.currentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CourseCode))
                            cmd.Parameters.AddWithValue("pcoursecode", DbType.String).Value = request.CourseCode;
                        else
                            cmd.Parameters.AddWithValue("pcoursecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CourseType))
                            cmd.Parameters.AddWithValue("pcoursetype", DbType.String).Value = request.CourseType;
                        else
                            cmd.Parameters.AddWithValue("pcoursetype", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.UserCompany))
                            cmd.Parameters.AddWithValue("pusercompany", DbType.String).Value = request.UserCompany;
                        else
                            cmd.Parameters.AddWithValue("pusercompany", DbType.String).Value = DBNull.Value;

                      

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                       

                        if (!String.IsNullOrEmpty(request.CompanyCode))
                            cmd.Parameters.AddWithValue("psearchcompany", DbType.String).Value = request.CompanyCode;
                        else
                            cmd.Parameters.AddWithValue("psearchcompany", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CourseName))
                            cmd.Parameters.AddWithValue("pcoursename", DbType.String).Value = request.CourseName;
                        else
                            cmd.Parameters.AddWithValue("pcoursename", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.objectCode))
                            cmd.Parameters.AddWithValue("pobjectcode", DbType.String).Value = request.objectCode;
                        else
                            cmd.Parameters.AddWithValue("pobjectcode", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {


                            dtEmployees.Columns.Add("encryptedID");
                            CommonFunction function = new CommonFunction();

                            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                            {
                                foreach (DataRow item in dtEmployees.Rows)
                                {
                                    item["encryptedID"] = function.Encrypt(Convert.ToString(item["courseid"]));
                                }
                            }
                        }

                        if (request.GetMode == 0)
                        {
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                        else
                        {
                            response.dtresponse = dtEmployees;
                        }
                    }
                }


                if (dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    int recordcount = 1;
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                        if (request.PageNumber>0)
                        {


                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                }



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ManageCourseMasterPaging", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass InsertEditCourseMaster(addEditCourseMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_course_master
                                                                        ( 
                                                                        :pcoursename,
                                                                        :pcoursecategory,
                                                                        :pcoursesize,
                                                                        :pcoursetagging,
                                                                        :pcoursetype,
                                                                        :pcourseextlink,
                                                                        :pinsertedby,
                                                                        :pscormcourseurl,
                                                                        :pointsearned,
                                                                        :paction,
                                                                        :pcourseid,
                                                                        :pispartofseed,
                                                                        :pseedtype,:pcurrentrole
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.CourseName))
                            cmd.Parameters.AddWithValue("pcoursename", DbType.String).Value = request.CourseName;
                        else
                            cmd.Parameters.AddWithValue("pcoursename", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CourseCategory))
                            cmd.Parameters.AddWithValue("pcoursecategory", DbType.String).Value = request.CourseCategory;
                        else
                            cmd.Parameters.AddWithValue("pcoursecategory", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CourseSize))
                            cmd.Parameters.AddWithValue("pcoursesize", DbType.String).Value = request.CourseSize;
                        else
                            cmd.Parameters.AddWithValue("pcoursesize", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CourseTagging))
                            cmd.Parameters.AddWithValue("pcoursetagging", DbType.String).Value = request.CourseTagging;
                        else
                            cmd.Parameters.AddWithValue("pcoursetagging", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CourseType))
                            cmd.Parameters.AddWithValue("pcoursetype", DbType.String).Value = request.CourseType;
                        else
                            cmd.Parameters.AddWithValue("pcoursetype", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CourseExtLink))
                            cmd.Parameters.AddWithValue("pcourseextlink", DbType.String).Value = request.CourseExtLink;
                        else
                            cmd.Parameters.AddWithValue("pcourseextlink", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CreatedUpdatedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.CreatedUpdatedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.ScromCourseURL))
                            cmd.Parameters.AddWithValue("pscormcourseurl", DbType.String).Value = request.ScromCourseURL;
                        else
                            cmd.Parameters.AddWithValue("pscormcourseurl", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("pointsearned", DbType.Int32).Value = request.PointsEarned;

                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("paction", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("paction", DbType.String).Value = string.Empty;

                        if (request.CourseID != 0)
                            cmd.Parameters.AddWithValue("pcourseid", DbType.Int32).Value = request.CourseID;
                        else
                            cmd.Parameters.AddWithValue("pcourseid", DbType.Int32).Value = 0;

                        cmd.Parameters.AddWithValue("pispartofseed", DbType.Int32).Value = request.IsPartOfdSeed;

                        if (!String.IsNullOrEmpty(request.SeedType))
                            cmd.Parameters.AddWithValue("pseedtype", DbType.String).Value = request.SeedType;
                        else
                            cmd.Parameters.AddWithValue("pseedtype", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("pcurrentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentrole", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        NpgsqlConnection.ClearPool(npgsqlConnection);
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditCourseMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass DeleteCourse(deleteCourseMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            //NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            try
            {
                //Delete Course data by course id

                //string sqlQuery = "UPDATE public.#VideoMaster# set #DeletedFlag# =1,#DeletedBy# ='" + request.DeletedBy + "',#DeletedOn#= '" + request.DeletedOn + "',#DeletedIPAddress# ='" + request.deletedIPAddress + "' where #VideoCode# ='" + request.CourseID + "'";
                ////string sqlQuery = "UPDATE public.#CourseMaster# set #DeletedFlag# =1,#deletedby# ='" + request.DeletedBy + "',#deletedon#=now() where #CourseID# ='" + request.CourseID + "'";

                ////sqlQuery = sqlQuery.Replace('#', '"');

                ////npgsqlCon.Open();

                ////NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                ////NpgsqlDataReader dataReader = cmd.ExecuteReader();

                ////npgsqlCon.Close();
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_delete_course_master
                                                                        ( 
                                                                            :p_courseid,
                                                                            :p_deletedby
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.CourseID))
                            cmd.Parameters.AddWithValue("p_courseid", DbType.String).Value = request.CourseID;
                        else
                            cmd.Parameters.AddWithValue("p_courseid", DbType.String).Value = "0";


                        if (!String.IsNullOrEmpty(request.DeletedBy))
                            cmd.Parameters.AddWithValue("p_deletedby", DbType.String).Value = request.DeletedBy;
                        else
                            cmd.Parameters.AddWithValue("p_deletedby", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        NpgsqlConnection.ClearPool(npgsqlConnection);
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);


                        }
                    }
                }

                //response.responseCode = 1;
                //response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Delete Course", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
       
        public ResponseClass EditCourse(addEditCourseMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable coursemodel = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select * from public.#CourseMaster# vm where #DeletedFlag# =0 and #CourseID# ='" + request.CourseID + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(coursemodel);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(coursemodel);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass IsCourseAssign(CheckCourseAssign request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable coursemodel = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select count(*) as count from public.#CourseMaster# where #CourseID#=" + request.CourseID;

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(coursemodel);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(coursemodel);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditCourse", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
    }
}
