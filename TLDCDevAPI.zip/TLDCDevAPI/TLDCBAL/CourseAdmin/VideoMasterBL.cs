﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using System.Linq;
using TLDCBAL.ProgramManager;

namespace TLDCBAL.CourseAdmin
{
    public class VideoMasterBL : IVideoMasterBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        private IQualtricsDataBL _qualtricsBL;

        public VideoMasterBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;

            _qualtricsBL = qualtricsBL;
        }
        public string RemoveQuotes(string str)
        {
            string result = string.Empty;
            if (str != null && str != "")
            {
                result = str.Replace("'", "''");
            }
            return result;
        }
        public ResponseClass ManageVideoMaster(manageVideoMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;

                if (string.IsNullOrEmpty(request.videoCode))
                {
                    if (!string.IsNullOrEmpty(request.fromDate))
                    {
                        try
                        {
                            dtFrom = Convert.ToDateTime(request.fromDate);
                            fromDate = Convert.ToDateTime(request.fromDate).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("ManageTrainingGroup", "1024", "From Date : " + ex.Message, "Exception");
                            response.responseCode = 0;
                            response.responseMessage = "Invalid FromDate";
                            return response;


                        }
                    }
                    if (!string.IsNullOrEmpty(request.toDate))
                    {
                        try
                        {
                            dtTo = Convert.ToDateTime(request.toDate);
                            toDate = Convert.ToDateTime(request.toDate).AddDays(1).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("ManageTrainingGroup", "1024", "To Date : " + ex.Message, "Exception");
                            response.responseCode = 0;
                            response.responseMessage = "Invalid ToDate";
                            return response;


                        }
                    }

                    if (dtFrom > dtTo)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid date range selected!";
                        return response;
                    }

                    TimeSpan difference = dtTo - dtFrom;

                    if (difference.TotalDays > 60)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
                        return response;
                    }
                }


                string selectQuery = string.Empty;

                selectQuery = "select VF.#videothumbnail# as videothumbnail,VF.#videofilepath# as videofilepath,A.#status# as status,A.#VideoType# as videotype,A.#Description# as description,A.#VideoID# as videoid,A.#VideoCode# as videocode,A.#VideoTitle# as videotitle,A.#VideoType# as videotype,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,A.#InsertedBy# as insertedemployeeid,TO_CHAR(A.#InsertedDateTime#, 'dd-Mon-yyyy') as createddate,TO_CHAR(A.#UpdatedOn#, 'dd-Mon-yyyy') as updateddate,EM.#Company_Name# as companyname from #VideoMaster# A inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# left outer join #VideoFile# VF on A.#VideoCode# = VF.videocode and (VF.#mediatype#)='Attachment'";

                //and (A.#InsertedDateTime#::date) >= '" + fromDate + "' and (A.#InsertedDateTime#::date) <= '" + toDate + "'
                selectQuery = selectQuery + " where  (A.#DeletedFlag#)=0  and lower(A.#VideoTitle#) like lower('%" + request.videoName + "%')";
                //if (request.videoStatus != "Select")
                //{
                //    selectQuery = selectQuery + " and A.#status#='" + request.videoStatus + "'";
                //}
                if (request.videoType != "Select")
                {
                    selectQuery = selectQuery + " and A.#VideoType# = '" + request.videoType + "'";
                }
                //selectQuery = selectQuery + " where (A.#DeletedFlag#)=0 and (A.#InsertedDateTime#) >= '" + fromDate + "' and (A.#InsertedDateTime#) <= '" + toDate + "'";
                if (string.IsNullOrEmpty(request.videoCode))
                {
                    //selectQuery = selectQuery + " and cast(A.#InsertedDateTime# as date) between '" + request.fromDate + "' and  '" + request.toDate + "'";
                    //if (!string.IsNullOrEmpty(request.videoCode))
                    //{
                    //    selectQuery = selectQuery + " and  A.#VideoCode#='" + request.videoCode + "'";
                    //}
                    //if (!string.IsNullOrEmpty(request.videoTitle))
                    //{
                    //    selectQuery = selectQuery + " and  A.#VideoTitle#='" + request.videoTitle + "'";
                    //}
                }
                else
                {
                    selectQuery = selectQuery + " and  A.#VideoID#=" + request.videoID + "";
                }

                string companiestopass = string.Empty;


                if (request.currentRole == "Program Manager")
                {
                    //selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";
                    selectQuery = selectQuery + " and (A.#InsertedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                    selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                }
                else if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //{
                    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    {
                    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    }

                    //    companiestopass = companiestopass.TrimEnd(',');

                    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //}

                    selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                   
                    selectQuery = selectQuery + " )";
                }
                if (!string.IsNullOrEmpty(request.CompanyCode))
                {
                    selectQuery = selectQuery + " and EM.#COMPANY_CODE#='" + request.CompanyCode + "'";
                }

                selectQuery = selectQuery + " order by A.#InsertedDateTime# desc";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);
                response.responseCode = 1;
                trainingGroup.Columns.Add("encryptedID");
                CommonFunction function = new CommonFunction();

                if (trainingGroup != null && trainingGroup.Rows.Count > 0)
                {
                    foreach (DataRow item in trainingGroup.Rows)
                    {
                        item["encryptedID"] = function.Encrypt(Convert.ToString(item["videocode"]));
                    }
                }
                #region Pagination
                int recordcount = 1;
                if (trainingGroup != null && trainingGroup.Rows.Count > 0)
                {
                    recordcount = trainingGroup.Rows.Count;
                    if (request.PageNumber != -1)
                    {
                        //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }

                var _trainingGroup = trainingGroup.AsEnumerable().Skip((request.PageNumber - 1) * request.RowsOfPage)
                        .Take(request.RowsOfPage).CopyToDataTable();
                #endregion
                response.responseJSON = JsonConvert.SerializeObject(_trainingGroup);

               

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageVideoMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass ManageVideoMasterPaging(manageVideoMasterrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();

                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;

                if (string.IsNullOrEmpty(request.videoCode))
                {
                    if (!string.IsNullOrEmpty(request.fromDate))
                    {
                        try
                        {
                            dtFrom = Convert.ToDateTime(request.fromDate);
                            fromDate = Convert.ToDateTime(request.fromDate).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("ManageVideoMasterPaging", "1024", "From Date : " + ex.Message, "Exception");
                            response.responseCode = 0;
                            response.responseMessage = "Invalid FromDate";
                            return response;


                        }
                    }
                    if (!string.IsNullOrEmpty(request.toDate))
                    {
                        try
                        {
                            dtTo = Convert.ToDateTime(request.toDate);
                            toDate = Convert.ToDateTime(request.toDate).AddDays(1).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("ManageVideoMasterPaging", "1024", "To Date : " + ex.Message, "Exception");
                            response.responseCode = 0;
                            response.responseMessage = "Invalid ToDate";
                            return response;


                        }
                    }

                    if (dtFrom > dtTo)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid date range selected!";
                        return response;
                    }

                    TimeSpan difference = dtTo - dtFrom;

                    if (difference.TotalDays > 60)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
                        return response;
                    }
                }

                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_manage_video
                                                                        ( 
                                                                            :pcurrentemployeeid,
                                                                            :pcurrentemployeerole,:pvideocode,:pvideotype,:pusercompany,:pvideoid,
                                                                            :p_pageno,:p_recordno,:pfromdate,:ptodate,:psearchcompany,:pvideoname,:pobjectcode
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.LoginEMPCode))
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.LoginEMPCode;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.currentRole))
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.currentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.videoCode))
                            cmd.Parameters.AddWithValue("pvideocode", DbType.String).Value = request.videoCode;
                        else
                            cmd.Parameters.AddWithValue("pvideocode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.videoType))
                            cmd.Parameters.AddWithValue("pvideotype", DbType.String).Value = request.videoType;
                        else
                            cmd.Parameters.AddWithValue("pvideotype", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.UserCompany))
                            cmd.Parameters.AddWithValue("pusercompany", DbType.String).Value = request.UserCompany;
                        else
                            cmd.Parameters.AddWithValue("pusercompany", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("pvideoid", DbType.String).Value = request.videoID;

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("pfromdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("pfromdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(toDate))
                            cmd.Parameters.AddWithValue("ptodate", DbType.String).Value = toDate;
                        else
                            cmd.Parameters.AddWithValue("ptodate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CompanyCode))
                            cmd.Parameters.AddWithValue("psearchcompany", DbType.String).Value = request.CompanyCode;
                        else
                            cmd.Parameters.AddWithValue("psearchcompany", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.videoName))
                            cmd.Parameters.AddWithValue("pvideoname", DbType.String).Value = request.videoName;
                        else
                            cmd.Parameters.AddWithValue("pvideoname", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.objectCode))
                            cmd.Parameters.AddWithValue("pobjectcode", DbType.String).Value = request.objectCode;
                        else
                            cmd.Parameters.AddWithValue("pobjectcode", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {

                            
                            dtEmployees.Columns.Add("encryptedID");
                            CommonFunction function = new CommonFunction();

                            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                            {
                                foreach (DataRow item in dtEmployees.Rows)
                                {
                                    item["encryptedID"] = function.Encrypt(Convert.ToString(item["videocode"]));
                                }
                            }
                        }

                        if (request.GetMode==0)
                        {
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                        else
                        {
                            response.dtresponse = dtEmployees;
                        }

                        
                    }
                }


                if (dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    int recordcount = 1;
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                        if (request.PageNumber >0)
                        {


                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                }



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ManageVideoMasterPaging", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public DataTable getGroupSubProcess(manageTrainingGrouprequestDTO request)
        {
            DataTable dtSubprocess = new DataTable();

            string selectQuery = string.Empty;

            selectQuery = "select A.#Subprocess# as subprocess from #TrainingGroupMembers# A inner join #TrainingGroup# B on A.#TrainingGroupCode# = B.#TrainingGroupCode# where #TrainingGroupID# = " + request.groupID + "";

            selectQuery = selectQuery.Replace('#', '"');


            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(dtSubprocess);
            npgsql.Close();
            NpgsqlConnection.ClearPool(npgsql);
            return dtSubprocess;

        }

        public ResponseClass InsertEditVideoMasterOLD(addVideoMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;



                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_video_master
                                                                        ( 
                                                                            :pvideotitle,
                                                                            :pdescription,
                                                                            :pinsertedby,
                                                                            :pinsertedipaddress,
                                                                           
                                                                            :p_action,:p_video_code,:pkeywords,
                                                                            :p_currentrole
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.videoTitle))
                            cmd.Parameters.AddWithValue("pvideotitle", DbType.String).Value = request.videoTitle;
                        else
                            cmd.Parameters.AddWithValue("pvideotitle", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.description))
                            cmd.Parameters.AddWithValue("pdescription", DbType.String).Value = request.description;
                        else
                            cmd.Parameters.AddWithValue("pdescription", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.insertedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.insertedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.insertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.insertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.videoCode))
                            cmd.Parameters.AddWithValue("p_video_code", DbType.String).Value = request.videoCode;
                        else
                            cmd.Parameters.AddWithValue("p_video_code", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.keywords))
                            cmd.Parameters.AddWithValue("pkeywords", DbType.String).Value = request.keywords;
                        else
                            cmd.Parameters.AddWithValue("pkeywords", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        NpgsqlConnection.ClearPool(npgsqlConnection);
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditTrainingGrup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass InsertEditVideoMaster(addVideoMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            if (request.action == "ADD")
            {
                try
                {
                    //TSequenceNo
                    string videoCodeNo = string.Empty;
                    int codeCountNoCount = 0;
                    string sqlQuery1 = "SELECT coalesce(max(#TSequenceNo#),0) as #TSequenceNo# FROM public.#VideoMaster#";

                    sqlQuery1 = sqlQuery1.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                    if (npgsqlDataReader1.Read())
                    {
                        videoCodeNo = npgsqlDataReader1[0].ToString();
                        codeCountNoCount = Convert.ToInt32(videoCodeNo) + 1;
                        request.videoCode = "VD" + codeCountNoCount;
                    }
                    else
                    {
                        ++codeCountNoCount;
                        request.videoCode = "VD" + codeCountNoCount;
                    }

                    npgsqlCon.Close();

                    //Insert Data VideoMaster
                    request.description = request.description.Replace("'", "''");
                    request.VideoType = request.VideoType.Replace('_', ' ');
                    string sqlQuery = "INSERT INTO public.#VideoMaster#(#VideoCode#,#VideoTitle#,#Description#,#Searchkeywords#,#TSequenceNo#,#InsertedBy#,#InsertedDateTime#,#InsertedIPAddress#,#VideoType#,#status#,#DeletedFlag#,#pointsearned#,#CurrentRole#,#CurrentRoleCompany#)";

                    sqlQuery = sqlQuery + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(request.videoTitle) + "', '" + RemoveQuotes(request.description) + "', '" + RemoveQuotes(request.serachkeyword) + "', '" + codeCountNoCount + "', '" + request.insertedBy + "', now(), '" + request.insertedIPAddress + "', '" + request.VideoType + "', '" + request.Status + "', '0', '" + request.PointsEarned + "', '" + request.CurrentRole + "',";

                    if (request.CurrentRole == "Program Manager")
                    {
                        sqlQuery = sqlQuery + "(select #COMPANY_CODE# from #EmployeeMaster# where #EXTERNALDATAREFERENCE#='" + request.insertedBy + "')";
                    }
                    else if (request.CurrentRole == "Geo Admin")
                    {
                        sqlQuery = sqlQuery + "(select STRING_AGG(#CompanyCode#,',') from #UserCompanyAssignment# where #ActiveStatus#=1 and #EmployeeCode#='" + request.insertedBy + "')";
                    }
                    else
                    {
                        sqlQuery = sqlQuery + "NULL";
                    }
                    sqlQuery = sqlQuery + ")";

                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);
                    ////Insert data video master start
                    //try
                    //{
                    //    DataTable dtEmployees = new DataTable();
                    //    string selectQuery = string.Empty;

                    //    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    //    {
                    //        using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_Edit_Video_Master
                    //                                                    ( 
                    //                                                    :pvideocode,
                    //                                                 :pvideotitle,
                    //                                                 :pdescription,
                    //                                                 :psearchkeywords,
                    //                                                 :ptsequenceno,
                    //                                                 :pinsertedby,
                    //                                                 :pinsertedipaddress,
                    //                                                 :pvideotype,
                    //                                                 :pstatus,
                    //                                                 :ppointsearned,
                    //                                                 :paction
                    //                                                    )", npgsqlConnection))
                    //        {
                    //            cmd.CommandType = CommandType.Text; //
                    //            if (!String.IsNullOrEmpty(request.videoCode))
                    //                cmd.Parameters.AddWithValue("pvideocode", DbType.String).Value = request.videoCode;
                    //            else
                    //                cmd.Parameters.AddWithValue("pvideocode", DbType.String).Value = string.Empty;

                    //            if (!String.IsNullOrEmpty(request.videoTitle))
                    //                cmd.Parameters.AddWithValue("pvideotitle", DbType.String).Value = request.videoTitle;
                    //            else
                    //                cmd.Parameters.AddWithValue("pvideotitle", DbType.String).Value = string.Empty;

                    //            if (!String.IsNullOrEmpty(request.description))
                    //                cmd.Parameters.AddWithValue("pdescription", DbType.String).Value = request.description;
                    //            else
                    //                cmd.Parameters.AddWithValue("pdescription", DbType.String).Value = string.Empty;

                    //            if (!String.IsNullOrEmpty(request.serachkeyword))
                    //                cmd.Parameters.AddWithValue("psearchkeywords", DbType.String).Value = request.serachkeyword;
                    //            else
                    //                cmd.Parameters.AddWithValue("psearchkeywords", DbType.String).Value = string.Empty;

                    //            if (codeCountNoCount != 0)
                    //                cmd.Parameters.AddWithValue("ptsequenceno", DbType.Int32).Value = codeCountNoCount;
                    //            else
                    //                cmd.Parameters.AddWithValue("ptsequenceno", DbType.Int32).Value = string.Empty;

                    //            if (!String.IsNullOrEmpty(request.insertedBy))
                    //                cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.insertedBy;
                    //            else
                    //                cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                    //            if (!String.IsNullOrEmpty(request.insertedIPAddress))
                    //                cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.insertedIPAddress;
                    //            else
                    //                cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;

                    //            if (!String.IsNullOrEmpty(request.VideoType))
                    //                cmd.Parameters.AddWithValue("pvideotype", DbType.String).Value = request.VideoType;
                    //            else
                    //                cmd.Parameters.AddWithValue("pvideotype", DbType.String).Value = string.Empty;

                    //            if (!String.IsNullOrEmpty(request.Status))
                    //                cmd.Parameters.AddWithValue("pstatus", DbType.String).Value = request.Status;
                    //            else
                    //                cmd.Parameters.AddWithValue("pstatus", DbType.String).Value = string.Empty;

                    //            cmd.Parameters.AddWithValue("ppointsearned", DbType.Int32).Value = request.PointsEarned;

                    //            if (!String.IsNullOrEmpty(request.action))
                    //                cmd.Parameters.AddWithValue("paction", DbType.String).Value = request.action;
                    //            else
                    //                cmd.Parameters.AddWithValue("paction", DbType.String).Value = string.Empty;

                    //            npgsqlConnection.Open();
                    //            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    //            dataAdapter.Fill(dtEmployees);
                    //            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    //        }
                    //    }

                    //    response.responseCode = 1;
                    //    response.responseMessage = "Success";
                    //}
                    //catch (Exception ex)
                    //{

                    //    _serviceconnect.LogConnect("InsertEditVideoMaster", "1024", ex.Message, "Exception");
                    //    response.responseCode = 0;
                    //    response.responseMessage = ex.Message;
                    //}
                    ////Insert data video master end
                    //Get Latest Video Code
                    string videoCode = string.Empty;
                    string videoId = string.Empty;

                    string sqlQuery2 = "SELECT max(#VideoID#) as #VideoID# FROM public.#VideoMaster#";

                    sqlQuery2 = sqlQuery2.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand2 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader2 = npgsqlCommand2.ExecuteReader();

                    if (npgsqlDataReader2.Read())
                    {
                        // videoCode = npgsqlDataReader2[0].ToString();
                        videoId = npgsqlDataReader2[0].ToString();
                    }
                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);
                    if (request.addVideoHighlights != null && request.addVideoHighlights.Count > 0)
                    {
                        foreach (var item in request.addVideoHighlights)
                        {
                            string sqlQuery3 = string.Empty;
                            //Insert Data addVideoHighlights
                            if (!string.IsNullOrEmpty(item.HighlightsText))
                            {
                                sqlQuery3 = "INSERT INTO public.#VideoHighlights#(#VideoCode#,#HighlightedText#,#DurationMinute#,#DurationSecond#,#VideoID#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.HighlightsText) + "', '" + RemoveQuotes(item.DurationMinute) + "', '" + RemoveQuotes(item.DurationSecond) + "', '" + videoId + "')";
                                sqlQuery3 = sqlQuery3.Replace('#', '"');

                                npgsqlCon.Open();

                                NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery3, npgsqlCon);

                                NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();

                                npgsqlCon.Close();
                            }
                        }
                    }

                    if (request.addVideoAttachments != null && request.addVideoAttachments.Count > 0)
                    {
                        foreach (var item in request.addVideoAttachments)
                        {
                            //Insert Data addVideoAttachments
                            string sqlQuery4 = "INSERT INTO public.#VideoFile#(#videocode#,#videofilename#,#videofilepath#,#videofiletype#,#mediatype#,#videothumbnail#,#videoid#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.FileName) + "', '" + RemoveQuotes(item.FilePath) + "', '" + item.FileType + "', '" + item.MediaType + "', '" + RemoveQuotes(item.VideoThumbnail) + "', '" + videoId + "')";

                            sqlQuery4 = sqlQuery4.Replace('#', '"');

                            npgsqlCon.Open();

                            NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery4, npgsqlCon);

                            NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();

                            npgsqlCon.Close();
                            NpgsqlConnection.ClearPool(npgsqlCon);
                        }
                    }
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Add Video", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            else if (request.action == "EDIT")
            {
                try
                {
                    if (string.IsNullOrEmpty(request.videoCode))
                    {
                        response.responseMessage = "Please provide videocode.";
                    }
                    else
                    {
                        //Update Video Master

                        request.VideoType = request.VideoType.Replace('_', ' ');
                        string sqlQuery = "UPDATE public.#VideoMaster# SET #VideoTitle#='" + RemoveQuotes(request.videoTitle) + "',#Description#='" + RemoveQuotes(request.description) + "',#Searchkeywords#='" + RemoveQuotes(request.serachkeyword) + "',#UpdatedBy#='" + request.insertedBy + "',#UpdatedOn#=now(),#UpdatedIPAddress#='" + request.insertedIPAddress + "',#VideoType#='" + request.VideoType + "',#pointsearned#='" + request.PointsEarned + "',#status#='" + request.Status + "' WHERE #VideoCode# = '" + request.videoCode + "'";

                        sqlQuery = sqlQuery.Replace('#', '"');
                        npgsqlCon.Open();
                        NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);
                        NpgsqlDataReader dataReader = cmd.ExecuteReader();
                        npgsqlCon.Close();//Insert data video master start
                        NpgsqlConnection.ClearPool(npgsqlCon);
                        //try
                        //{
                        //    DataTable dtEmployees = new DataTable();
                        //    string selectQuery = string.Empty;

                        //    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                        //    {
                        //        using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_Edit_Video_Master
                        //                                                ( 
                        //                                                :pvideocode,
                        //                                             :pvideotitle,
                        //                                             :pdescription,
                        //                                             :psearchkeywords,
                        //                                             :ptsequenceno,
                        //                                             :pinsertedby,
                        //                                             :pinsertedipaddress,
                        //                                             :pvideotype,
                        //                                             :pstatus,
                        //                                             :ppointsearned,
                        //                                             :paction
                        //                                                )", npgsqlConnection))
                        //        {
                        //            cmd.CommandType = CommandType.Text; //
                        //            if (!String.IsNullOrEmpty(request.videoCode))
                        //                cmd.Parameters.AddWithValue("pvideocode", DbType.String).Value = request.videoCode;
                        //            else
                        //                cmd.Parameters.AddWithValue("pvideocode", DbType.String).Value = string.Empty;

                        //            if (!String.IsNullOrEmpty(request.videoTitle))
                        //                cmd.Parameters.AddWithValue("pvideotitle", DbType.String).Value = request.videoTitle;
                        //            else
                        //                cmd.Parameters.AddWithValue("pvideotitle", DbType.String).Value = string.Empty;

                        //            if (!String.IsNullOrEmpty(request.description))
                        //                cmd.Parameters.AddWithValue("pdescription", DbType.String).Value = request.description;
                        //            else
                        //                cmd.Parameters.AddWithValue("pdescription", DbType.String).Value = string.Empty;

                        //            if (!String.IsNullOrEmpty(request.serachkeyword))
                        //                cmd.Parameters.AddWithValue("psearchkeywords", DbType.String).Value = request.serachkeyword;
                        //            else
                        //                cmd.Parameters.AddWithValue("psearchkeywords", DbType.String).Value = string.Empty;

                        //            cmd.Parameters.AddWithValue("ptsequenceno", DbType.Int32).Value = 0;

                        //            if (!String.IsNullOrEmpty(request.insertedBy))
                        //                cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.insertedBy;
                        //            else
                        //                cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        //            if (!String.IsNullOrEmpty(request.insertedIPAddress))
                        //                cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.insertedIPAddress;
                        //            else
                        //                cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;

                        //            if (!String.IsNullOrEmpty(request.VideoType))
                        //                cmd.Parameters.AddWithValue("pvideotype", DbType.String).Value = request.VideoType;
                        //            else
                        //                cmd.Parameters.AddWithValue("pvideotype", DbType.String).Value = string.Empty;

                        //            if (!String.IsNullOrEmpty(request.Status))
                        //                cmd.Parameters.AddWithValue("pstatus", DbType.String).Value = request.Status;
                        //            else
                        //                cmd.Parameters.AddWithValue("pstatus", DbType.String).Value = string.Empty;

                        //            cmd.Parameters.AddWithValue("ppointsearned", DbType.Int32).Value = request.PointsEarned;

                        //            if (!String.IsNullOrEmpty(request.action))
                        //                cmd.Parameters.AddWithValue("paction", DbType.String).Value = request.action;
                        //            else
                        //                cmd.Parameters.AddWithValue("paction", DbType.String).Value = string.Empty;

                        //            npgsqlConnection.Open();
                        //            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        //            dataAdapter.Fill(dtEmployees);
                        //            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        //        }
                        //    }

                        //    response.responseCode = 1;
                        //    response.responseMessage = "Success";
                        //}
                        //catch (Exception ex)
                        //{

                        //    _serviceconnect.LogConnect("InsertEditVideoMaster", "1024", ex.Message, "Exception");
                        //    response.responseCode = 0;
                        //    response.responseMessage = ex.Message;
                        //}
                        ////Edit data video master end
                        // Delete previous video heightlights
                        string sqlQuery1 = "DELETE FROM public.#VideoHighlights# WHERE #VideoCode# = '" + request.videoCode + "'";

                        sqlQuery1 = sqlQuery1.Replace('#', '"');
                        npgsqlCon.Open();
                        NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);
                        NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();
                        npgsqlCon.Close();
                        NpgsqlConnection.ClearPool(npgsqlCon);
                        //Update previous video heightlights
                        if (request.addVideoHighlights != null && request.addVideoHighlights.Count > 0)
                        {
                            foreach (var item in request.addVideoHighlights)
                            {
                                if (!string.IsNullOrEmpty(item.HighlightsText))
                                {
                                    string sqlQuery2 = "INSERT INTO public.#VideoHighlights#(#VideoCode#,#HighlightedText#,#DurationMinute#,#DurationSecond#,#VideoID#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.HighlightsText) + "', '" + item.DurationMinute + "', '" + item.DurationSecond + "', '" + request.videoID + "')";

                                    sqlQuery2 = sqlQuery2.Replace('#', '"');

                                    npgsqlCon.Open();
                                    NpgsqlCommand cmd2 = new NpgsqlCommand(sqlQuery2, npgsqlCon);
                                    NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();
                                    npgsqlCon.Close();
                                    NpgsqlConnection.ClearPool(npgsqlCon);
                                }
                            }
                        }
                        if (request.addVideoAttachments != null && request.addVideoAttachments.Count > 0)
                        {
                            foreach (var item in request.addVideoAttachments)
                            {
                                //Update Data addVideoAttachments
                                if (item.MediaType == "Attachment")
                                {
                                    int videoAttachementCount = 0;

                                    string sqlQuery3 = "SELECT count(#videocode#) FROM public.#VideoFile# WHERE mediatype='Attachment' and videocode ='" + request.videoCode + "'";

                                    sqlQuery3 = sqlQuery3.Replace('#', '"');

                                    npgsqlCon.Open();
                                    NpgsqlCommand npgsqlCommand2 = new NpgsqlCommand(sqlQuery3, npgsqlCon);
                                    NpgsqlDataReader npgsqlDataReader2 = npgsqlCommand2.ExecuteReader();
                                    if (npgsqlDataReader2.Read())
                                    {
                                        videoAttachementCount = Convert.ToInt32(npgsqlDataReader2[0]);
                                    }
                                    npgsqlCon.Close();
                                    NpgsqlConnection.ClearPool(npgsqlCon);
                                    if (videoAttachementCount > 0)
                                    {
                                        //update
                                        string sqlQuery5 = string.Empty;
                                        if (string.IsNullOrEmpty(item.VideoThumbnail))
                                        {
                                            sqlQuery5 = "UPDATE public.#VideoFile# SET #videofilename#='" + RemoveQuotes(item.FileName) + "',#videofilepath#='" + RemoveQuotes(item.FilePath) + "',#videofiletype#='" + item.FileType + "',#videoid#='" + request.videoID + "' WHERE mediatype='Attachment' and videocode ='" + request.videoCode + "'";
                                        }
                                        else
                                        {
                                            sqlQuery5 = "UPDATE public.#VideoFile# SET #videothumbnail#='" + RemoveQuotes(item.VideoThumbnail) + "',#videoid#='" + request.videoID + "' WHERE mediatype='Attachment' and videocode ='" + request.videoCode + "'";
                                        }

                                        sqlQuery5 = sqlQuery5.Replace('#', '"');
                                        npgsqlCon.Open();
                                        NpgsqlCommand cmd5 = new NpgsqlCommand(sqlQuery5, npgsqlCon);
                                        NpgsqlDataReader dataReader5 = cmd5.ExecuteReader();
                                        npgsqlCon.Close();
                                        NpgsqlConnection.ClearPool(npgsqlCon);
                                    }
                                    else
                                    {
                                        //insert
                                        if (item.MediaType == "Attachment")
                                        {
                                            string sqlQuery6 = "INSERT INTO public.#VideoFile#(#videocode#,#videofilename#,#videofilepath#,#videofiletype#,#mediatype#,#videothumbnail#,#videoid#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.FileName) + "', '" + RemoveQuotes(item.FilePath) + "', '" + item.FileType + "', '" + item.MediaType + "', '" + item.VideoThumbnail + "', '" + request.videoID + "')";

                                            sqlQuery6 = sqlQuery6.Replace('#', '"');
                                            npgsqlCon.Open();
                                            NpgsqlCommand cmd6 = new NpgsqlCommand(sqlQuery6, npgsqlCon);
                                            NpgsqlDataReader dataReader6 = cmd6.ExecuteReader();
                                            npgsqlCon.Close();
                                            NpgsqlConnection.ClearPool(npgsqlCon);
                                        }

                                    }
                                }
                                else if (item.MediaType == "Transcript")
                                {
                                    int videoTranscriptCount = 0;

                                    string sqlQuery7 = "SELECT count(#videocode#) FROM public.#VideoFile# WHERE mediatype='Transcript' and videocode ='" + request.videoCode + "'";

                                    sqlQuery7 = sqlQuery7.Replace('#', '"');

                                    npgsqlCon.Open();
                                    NpgsqlCommand npgsqlCommand7 = new NpgsqlCommand(sqlQuery7, npgsqlCon);
                                    NpgsqlDataReader npgsqlDataReader7 = npgsqlCommand7.ExecuteReader();
                                    if (npgsqlDataReader7.Read())
                                    {
                                        videoTranscriptCount = Convert.ToInt32(npgsqlDataReader7[0]);
                                    }
                                    npgsqlCon.Close();
                                    NpgsqlConnection.ClearPool(npgsqlCon);
                                    if (videoTranscriptCount > 0)
                                    {
                                        //update
                                        string sqlQuery8 = string.Empty;
                                        if (string.IsNullOrEmpty(item.VideoThumbnail))
                                        {
                                            sqlQuery8 = "UPDATE public.#VideoFile# SET #videofilename#='" + RemoveQuotes(item.FileName) + "',#videofilepath#='" + RemoveQuotes(item.FilePath) + "',#videofiletype#='" + item.FileType + "',#videoid#='" + request.videoID + "' WHERE mediatype='Transcript' and videocode ='" + request.videoCode + "'";
                                        }
                                        else
                                        {
                                            sqlQuery8 = "UPDATE public.#VideoFile# SET #videofilename#='" + RemoveQuotes(item.FileName) + "',#videofilepath#='" + RemoveQuotes(item.FilePath) + "',#videofiletype#='" + item.FileType + "',#videothumbnail#='" + RemoveQuotes(item.VideoThumbnail) + "',#videoid#='" + request.videoID + "' WHERE mediatype='Transcript' and videocode ='" + request.videoCode + "'";
                                        }

                                        sqlQuery8 = sqlQuery8.Replace('#', '"');
                                        npgsqlCon.Open();
                                        NpgsqlCommand cmd8 = new NpgsqlCommand(sqlQuery8, npgsqlCon);
                                        NpgsqlDataReader dataReader8 = cmd8.ExecuteReader();
                                        npgsqlCon.Close();
                                        NpgsqlConnection.ClearPool(npgsqlCon);
                                    }
                                    else
                                    {
                                        //insert
                                        if (item.MediaType == "Transcript")
                                        {
                                            string sqlQuery9 = "INSERT INTO public.#VideoFile#(#videocode#,#videofilename#,#videofilepath#,#videofiletype#,#mediatype#,#videothumbnail#,#videoid#) " + "VALUES('" + request.videoCode + "', '" + RemoveQuotes(item.FileName) + "', '" + RemoveQuotes(item.FilePath) + "', '" + item.FileType + "', '" + item.MediaType + "', '" + item.VideoThumbnail + "', '" + request.videoID + "')";

                                            sqlQuery9 = sqlQuery9.Replace('#', '"');
                                            npgsqlCon.Open();
                                            NpgsqlCommand cmd9 = new NpgsqlCommand(sqlQuery9, npgsqlCon);
                                            NpgsqlDataReader dataReader9 = cmd9.ExecuteReader();
                                            npgsqlCon.Close();
                                            NpgsqlConnection.ClearPool(npgsqlCon);
                                        }

                                    }
                                }

                            }
                        }
                    }
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Edit Video", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            return response;
        }
        public ResponseClass DeleteVideo(deleteVideoMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            //NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            try
            {
                //Delete Video data by video code

                //string sqlQuery = "UPDATE public.#VideoMaster# set #DeletedFlag# =1,#DeletedBy# ='" + request.deletedBy + "',#DeletedOn#=now(),#DeletedIPAddress# ='" + request.deletedIPAddress + "' where #VideoCode# ='" + request.videoCode + "'";

                //sqlQuery = sqlQuery.Replace('#', '"');

                //npgsqlCon.Open();

                //NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                //NpgsqlDataReader dataReader = cmd.ExecuteReader();

                //npgsqlCon.Close();
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_delete_video_master
                                                                        ( 
                                                                            :p_videoCode,
                                                                            :p_deletedby,
                                                                            :p_deletedipaddress
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.videoCode))
                            cmd.Parameters.AddWithValue("p_videoCode", DbType.String).Value = request.videoCode;
                        else
                            cmd.Parameters.AddWithValue("p_videoCode", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.deletedBy))
                            cmd.Parameters.AddWithValue("p_deletedby", DbType.String).Value = request.deletedBy;
                        else
                            cmd.Parameters.AddWithValue("p_deletedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.deletedIPAddress))
                            cmd.Parameters.AddWithValue("p_deletedipaddress", DbType.String).Value = request.deletedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_deletedipaddress", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        NpgsqlConnection.ClearPool(npgsqlConnection);
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);


                        }
                    }
                }
                //response.responseCode = 1;
                //response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Delete Video", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass EditVideo(deleteVideoMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable videomodel = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select * from public.#VideoMaster# vm where #DeletedFlag# =0 and #VideoCode# ='" + request.videoCode + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(videomodel);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);
                ////   addVideoMasterRequestDTO model = new addVideoMasterRequestDTO();
                //var model = videomodel.AsEnumerable().Select(x => new addVideoMasterRequestDTO
                //{
                //    videoID = Convert.ToString(x.Field<int>("VideoID")),
                //    videoCode = x.Field<string>("VideoCode"),
                //    videoTitle = x.Field<string>("VideoTitle")
                //});

                response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(model, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
                response.responseJSON = JsonConvert.SerializeObject(videomodel);
                response.responseJSONSecondary = JsonConvert.SerializeObject(VideoHighlightsByVideoCode(request.videoCode));
                response.responseJSONThird = JsonConvert.SerializeObject(videofilesByVideoCode(request.videoCode));

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditVideoMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public DataTable VideoHighlightsByVideoCode(string videocode)
        {
            ResponseClass response = new ResponseClass();

            DataTable videoHeightlightmodel = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                selectQuery = "select * from public.#VideoHighlights# vm where #VideoCode# ='" + videocode + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(videoHeightlightmodel);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);
                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(videoHeightlightmodel);
                return videoHeightlightmodel;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditVideoMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return videoHeightlightmodel;
        }
        public DataTable videofilesByVideoCode(string videocode)
        {
            ResponseClass response = new ResponseClass();

            DataTable videofiles = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                selectQuery = "select * from public.#VideoFile# vm where #videocode# ='" + videocode + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(videofiles);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);
                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(videofiles);
                return videofiles;

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("VideofilesMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return videofiles;
        }

    }
}
