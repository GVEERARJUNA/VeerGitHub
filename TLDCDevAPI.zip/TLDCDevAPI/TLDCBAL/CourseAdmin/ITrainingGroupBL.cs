﻿using TLDCBAL.Common;

namespace TLDCBAL.CourseAdmin
{
    public interface ITrainingGroupBL
    {
        ResponseClass ManageTrainingGroup(manageTrainingGrouprequestDTO request);

        ResponseClass ManageTrainingGroupPaging(manageTrainingGrouprequestDTO request);
        ResponseClass InsertEditTrainingGrup(addTrainingGroupRequestDTO request);

        ResponseClass AddEmployeeToAllocation(allocateEmployeeRequest request);
        ResponseClass searchEmployee(allocateEmployeeRequest request);

        ResponseClass addMultiEmployee(allocateEmployeeRequest request);
    }
}