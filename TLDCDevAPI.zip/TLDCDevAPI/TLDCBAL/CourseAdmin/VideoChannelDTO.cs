﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.CourseAdmin
{
    public class ChannelReuest
    {
        public string currentRole { get; set; }
        public string CompanyCode { get; set; }
        public string EmployeeId { get; set; }
    }
    public class CreateChannelDTO
    {
        public string channelId { get; set; }
        public string title { get; set; }
        public string about { get; set; }
        public string description { get; set; }
        public string thumbnailpath { get; set; }
        public string videocode { get; set; }
        public string employeeId { get; set; }
        public string currentRole { get; set; }
        public List<ChannelVideoDTO> videoList { get; set; }
        public List<ChannelAccessDTO> accessList { get; set; }
    }


    public class ChannelVideoDTO
    {
        public string videoNumber { get; set; }
        public string videoFileName { get; set; }
        public string videoThumbnailName { get; set; }
        public string videotitle { get; set; }
        public string videoDesc { get; set; }
        public string description { get; set; }
        public string thumbnailpath { get; set; }
        public string videopath { get; set; }
        public string duration { get; set; }
        public string EmployeeId { get; set; }
        public string channelid { get; set; }
        public string CurrentRole { get; set; }
    }

    public class ChannelAccessDTO
    {
        public string employeeId { get; set; }
        public string employeeName { get; set; }
        public string accessGivenBy { get; set; }
        public string accessGivenOn { get; set; }
        public string channelId { get; set; }
        public string status { get; set; }
        public string Action { get; set; }
    }


    public class SubscribeChannelDTO
    {
        public string ChannelId { get; set; }
        public string EmployeeId { get; set; }
        public string Action { get; set; }
    }

    public class VideoLikeDTO
    {
        public string ChannelId { get; set; }
        public string VideoId { get; set; }
        public string EmployeeId { get; set; }
        public string Action { get; set; }
    }
}
