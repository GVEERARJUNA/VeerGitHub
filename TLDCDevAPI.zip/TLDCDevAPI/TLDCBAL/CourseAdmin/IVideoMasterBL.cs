﻿using System.Data;
using TLDCBAL.Common;

namespace TLDCBAL.CourseAdmin
{
    public interface IVideoMasterBL
    {
        DataTable getGroupSubProcess(manageTrainingGrouprequestDTO request);
        ResponseClass InsertEditVideoMaster(addVideoMasterRequestDTO request);
        ResponseClass ManageVideoMaster(manageVideoMasterrequestDTO request);

        ResponseClass ManageVideoMasterPaging(manageVideoMasterrequestDTO request);
        ResponseClass DeleteVideo(deleteVideoMasterRequestDTO request);
        ResponseClass EditVideo(deleteVideoMasterRequestDTO request);
        
    }
}