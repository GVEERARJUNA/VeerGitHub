﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.CourseAdmin
{
    public class manageCourseMasterrequestDTO
    {

        public int CourseID { get; set; }
        public string CourseCode { get; set; }
        public string CourseName { get; set; }
        public string CourseCategory { get; set; }
        public string CourseSize { get; set; }
        public string CourseType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string LoginEMPCode { get; set; }
        public string currentRole { get; set; }
        public string CompanyCode { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string UserCompany { get; set; }

        public int GetMode { get; set; }

        public string objectCode { get; set; }
    }
    public class addEditCourseMasterrequestDTO
    {
        public int CourseID { get; set; }
        public string CourseCode { get; set; }
        public string CourseName { get; set; }
        public string CourseCategory { get; set; }
        public string CourseSize { get; set; }
        public string CourseTagging { get; set; }
        public string CourseType { get; set; }
        public string CourseExtLink { get; set; }
        public string CreatedUpdatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string Action { get; set; }
        public string ScromCourseURL { get; set; }
        public int PointsEarned { get; set; }
        public int IsPartOfdSeed { get; set; }
        public string SeedType { get; set; }

        public string CurrentRole { get; set; }
        public List<CourseAttachementRequestDTO> addEditCourseAttachments { get; set; }
        public addEditCourseMasterrequestDTO()
        {
            addEditCourseAttachments = new List<CourseAttachementRequestDTO>();
        }
    }
    public class CourseAttachementRequestDTO
    {
        public int TID { get; set; }
        public string CourseID { get; set; }
        public string FileName { get; set; }
        public string FileSize { get; set; }
        public string FilePath { get; set; }
        public string filetype { get; set; }
    }
    public class deleteCourseMasterRequestDTO
    {
        public string CourseID { get; set; }
        public string DeletedBy { get; set; }
        public string DeletedOn { get; set; }
    }
    public class CheckCourseAssign
    {
        public int CourseID { get; set; }
        public int IsCourseAssignCount { get; set; }
    }
}
