﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.ProgramManager;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCBAL.UserManagement;

namespace TLDCBAL.CourseAdmin
{
    public class TrainingGroupBL : ITrainingGroupBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;
        private IQualtricsDataBL _qualtricsBL;

        private IUserManagementBL _usermanagementBL;

        public TrainingGroupBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL, IUserManagementBL usermanagementBL)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
            _usermanagementBL= usermanagementBL;
        }
        public ResponseClass ManageTrainingGroup(manageTrainingGrouprequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            CommonFunction function = new CommonFunction();
            try
            {
                DataTable trainingGroup = new DataTable();
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;

                if (request.groupID == 0)
                {
                    if (!string.IsNullOrEmpty(request.fromDate))
                    {
                        try
                        {
                            dtFrom = Convert.ToDateTime(request.fromDate);
                            fromDate = Convert.ToDateTime(request.fromDate).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("ManageTrainingGroup", "1024", "From Date : " + ex.Message, "Exception");
                            response.responseCode = 0;
                            response.responseMessage = "Invalid FromDate";
                            return response;


                        }
                    }
                    if (!string.IsNullOrEmpty(request.toDate))
                    {
                        try
                        {
                            dtTo = Convert.ToDateTime(request.toDate);
                            toDate = Convert.ToDateTime(request.toDate).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("ManageTrainingGroup", "1024", "To Date : " + ex.Message, "Exception");
                            response.responseCode = 0;
                            response.responseMessage = "Invalid ToDate";
                            return response;


                        }
                    }

                    if (dtFrom > dtTo)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid date range selected!";
                        return response;
                    }

                    //TimeSpan difference = dtTo - dtFrom;

                    //if (difference.TotalDays > 60)
                    //{
                    //    response.responseCode = 0;
                    //    response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
                    //    return response;
                    //}
                }
                
                
                string selectQuery = string.Empty;
                selectQuery = "select A.#Description# as description,A.#TrainingGroupID#,A.#TrainingGroupCode# as traininggroupcode,A.#TrainingGroupName# as traininggroupname,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,EM.#EXTERNALDATAREFERENCE# as createdbyid,TO_CHAR(A.#InsertedDateTime#, 'dd-Mon-yyyy') as createddate,fn_get_tgroup_memebercount(A.#TrainingGroupCode#) as memebercount,EM.#Company_Name# as companyname from #TrainingGroup# A inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                selectQuery = selectQuery + "  where  (A.#DeletedFlag#)=0";
                if (request.groupID==0)
                {
                   // selectQuery = selectQuery + " and cast(A.#InsertedDateTime# as date) between '" + request.fromDate + "' and  '" + request.toDate + "'";
                    if (!string.IsNullOrEmpty(request.groupCode))
                    {
                        selectQuery = selectQuery + " and  A.#TrainingGroupCode#='" + request.groupCode + "'";
                    }
                    if (!string.IsNullOrEmpty(request.groupName))
                    {
                        selectQuery = selectQuery + " and  A.#TrainingGroupName#='" + request.groupName + "'";
                    }
                }
                else
                {
                    selectQuery = selectQuery + " and  A.#TrainingGroupID#=" + (request.groupID) + "";
                }
                string companiestopass = string.Empty;

                if (request.currentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";
                }
                else if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                if (!string.IsNullOrEmpty(request.CompanyCode))
                {
                    selectQuery = selectQuery + " and EM.#COMPANY_CODE#='" + request.CompanyCode + "'";
                }

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
               
                response.responseCode = 1;
                
                //trainingGroup.Columns.Add("encryptedID");
                //if (trainingGroup != null && trainingGroup.Rows.Count > 0)
                //{
                //    foreach (DataRow item in trainingGroup.Rows)
                //    {
                //        item["encryptedID"] = function.Encrypt(Convert.ToString(item["TrainingGroupID"]));
                //    }
                //}
                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
                if (request.groupID != 0)
                {
                    response.responseJSONSecondary = JsonConvert.SerializeObject(getGroupSubProcess(request));
                }


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageTrainingGroup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass ManageTrainingGroupPaging(manageTrainingGrouprequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();

                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;

                if (request.groupID==0)
                {
                    if (!string.IsNullOrEmpty(request.fromDate))
                    {
                        try
                        {
                            dtFrom = Convert.ToDateTime(request.fromDate);
                            fromDate = Convert.ToDateTime(request.fromDate).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("ManageTrainingGroupPaging", "1024", "From Date : " + ex.Message, "Exception");
                            response.responseCode = 0;
                            response.responseMessage = "Invalid FromDate";
                            return response;


                        }
                    }
                    if (!string.IsNullOrEmpty(request.toDate))
                    {
                        try
                        {
                            dtTo = Convert.ToDateTime(request.toDate);
                            toDate = Convert.ToDateTime(request.toDate).AddDays(1).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("ManageTrainingGroupPaging", "1024", "To Date : " + ex.Message, "Exception");
                            response.responseCode = 0;
                            response.responseMessage = "Invalid ToDate";
                            return response;


                        }
                    }

                    //if (dtFrom > dtTo)
                    //{
                    //    response.responseCode = 0;
                    //    response.responseMessage = "Invalid date range selected!";
                    //    return response;
                    //}

                    //TimeSpan difference = dtTo - dtFrom;

                    //if (difference.TotalDays > 60)
                    //{
                    //    response.responseCode = 0;
                    //    response.responseMessage = "Maximum date range should be 60 days(2 Months)!";
                    //    return response;
                    //}
                }

                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_manage_traininggroup
                                                                        ( 
                                                                            :pcurrentemployeeid,
                                                                            :pcurrentemployeerole,:pgroupcode,:pusercompany,:pgroupid,
                                                                            :p_pageno,:p_recordno,:psearchcompany,:pgroupname
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.LoginEMPCode))
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.LoginEMPCode;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.currentRole))
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.currentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.groupCode))
                            cmd.Parameters.AddWithValue("pgroupcode", DbType.String).Value = request.groupCode;
                        else
                            cmd.Parameters.AddWithValue("pgroupcode", DbType.String).Value = DBNull.Value;

                        //if (!String.IsNullOrEmpty(request.videoType))
                        //    cmd.Parameters.AddWithValue("pvideotype", DbType.String).Value = request.videoType;
                        //else
                        //    cmd.Parameters.AddWithValue("pvideotype", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.UserCompany))
                            cmd.Parameters.AddWithValue("pusercompany", DbType.String).Value = request.UserCompany;
                        else
                            cmd.Parameters.AddWithValue("pusercompany", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("pgroupid", DbType.String).Value = request.groupID;

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        //if (!String.IsNullOrEmpty(fromDate))
                        //    cmd.Parameters.AddWithValue("pfromdate", DbType.String).Value = fromDate;
                        //else
                        //    cmd.Parameters.AddWithValue("pfromdate", DbType.String).Value = DBNull.Value;

                        //if (!String.IsNullOrEmpty(toDate))
                        //    cmd.Parameters.AddWithValue("ptodate", DbType.String).Value = toDate;
                        //else
                        //    cmd.Parameters.AddWithValue("ptodate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CompanyCode))
                            cmd.Parameters.AddWithValue("psearchcompany", DbType.String).Value = request.CompanyCode;
                        else
                            cmd.Parameters.AddWithValue("psearchcompany", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.groupName))
                            cmd.Parameters.AddWithValue("pgroupname", DbType.String).Value = request.groupName;
                        else
                            cmd.Parameters.AddWithValue("pgroupname", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        

                        if (request.GetMode == 0)
                        {
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                        else
                        {
                            response.dtresponse = dtEmployees;
                        }


                    }
                }


                if (dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    int recordcount = 1;
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                        if (request.PageNumber > 0)
                        {


                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                }



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ManageTrainingGroupPaging", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public DataTable getGroupSubProcess(manageTrainingGrouprequestDTO request)
        {
            DataTable dtSubprocess = new DataTable();

            string selectQuery = string.Empty;

            selectQuery = "select A.#TGroupMemberID# as recordid,coalesce(A.#Subprocess#,'') as subprocess,coalesce(VS.#Department_Code#,'') as department,coalesce(VS.#COMPANY_CODE#,'') as companycode,coalesce(A.#EmployeeCode#,'') as employees,coalesce(EM.#FIRSTNAME#,'') as firstname,coalesce(EM.#Official_Email#,'') as email from #TrainingGroupMembers# A inner join #TrainingGroup# B on A.#TrainingGroupCode# = B.#TrainingGroupCode# left join vw_subprocess VS on VS.#Sub_Process_Code#=A.#Subprocess# ";
            selectQuery = selectQuery + " left join #EmployeeMaster# EM on EM.#EXTERNALDATAREFERENCE#=A.#EmployeeCode#";
            selectQuery = selectQuery + " where #TrainingGroupID# = " + request.groupID + "";
            selectQuery = selectQuery.Replace('#', '"');


            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(dtSubprocess);
            npgsql.Close();

            return dtSubprocess;

        }

        public ResponseClass InsertEditTrainingGrup(addTrainingGroupRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;



                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_training_group
                                                                        ( 
                                                                            :ptraininggroupname,
                                                                            :pdescription,
                                                                            :pinsertedby,
                                                                            :pinsertedipaddress,
                                                                            :psubprocess,
                                                                            :pemployeecode,
                                                                            :p_action,:p_group_id,:pcurrentrole
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.groupName))
                            cmd.Parameters.AddWithValue("ptraininggroupname", DbType.String).Value = request.groupName;
                        else
                            cmd.Parameters.AddWithValue("ptraininggroupname", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.description))
                            cmd.Parameters.AddWithValue("pdescription", DbType.String).Value = request.description;
                        else
                            cmd.Parameters.AddWithValue("pdescription", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.insertedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.insertedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.insertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.insertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.subprocesses))
                            cmd.Parameters.AddWithValue("psubprocess", DbType.String).Value = request.subprocesses;
                        else
                            cmd.Parameters.AddWithValue("psubprocess", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.employeecodes))
                            cmd.Parameters.AddWithValue("pemployeecode", DbType.String).Value = request.employeecodes;
                        else
                            cmd.Parameters.AddWithValue("pemployeecode", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.groupID))
                            cmd.Parameters.AddWithValue("p_group_id", DbType.String).Value = request.groupID;
                        else
                            cmd.Parameters.AddWithValue("p_group_id", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("pcurrentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentrole", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditTrainingGrup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass AddEmployeeToAllocation(allocateEmployeeRequest request)
        {
            ResponseClass response = new ResponseClass();
            string companiestopass = string.Empty;
            try
            {
                DataTable employeeDetails = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                npgsqlCon.Open();

                string sqlQuery = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#, concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,cast(TO_CHAR(A.#DOJ#, 'dd-Mon-yyyy') as character varying) as dojdisplay,A.#DOJ#,A.#COMPANY_CODE# as #CompanyCode#,coalesce(A.#FIRSTNAME#,'') as firstname,coalesce(A.#Official_Email#,'') as email from #EmployeeMaster# A  where  A.#EXTERNALDATAREFERENCE# = '" +  request.EmployeeID + "' and A.#Active_Separated# = 'Active'";

                //if (request.CallingSource=="Upload")
                //{

                //}
                if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        sqlQuery = sqlQuery + " and #COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                else if (request.currentRole == "Program Manager")
                {
                    string incccompany = string.Empty;
                    DataTable dtEmployees = new DataTable();
                    dtEmployees = _usermanagementBL.getassigneddepartmentforprogrammanager(request.LoginEMPCode);
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtEmployees.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["DepartmentCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        sqlQuery = sqlQuery + " and #Department_Code# in (" + companiestopass + ")";

                        if (!string.IsNullOrEmpty(Convert.ToString(dtEmployees.Rows[0]["CompanyCode"])))
                        {


                            string[] cccode = Convert.ToString(dtEmployees.Rows[0]["CompanyCode"]).Split(",");
                            foreach (string ccode in cccode)
                            {
                                incccompany = incccompany + "'" + Convert.ToString(ccode) + "',";
                            }

                            incccompany = incccompany.TrimEnd(',');
                        }

                        sqlQuery = sqlQuery + " and #COMPANY_CODE# in (" + incccompany + ")";

                    }
                    else
                    {
                        sqlQuery = sqlQuery + " and #COMPANY_CODE#='" + request.currentcompany + "'";
                    }
                }
                else if (request.currentRole == "Team Lead")
                {
                    string teamMembers = string.Empty;

                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.LoginEMPCode;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }
                    if (!string.IsNullOrEmpty(teamMembers))
                    {
                        sqlQuery = sqlQuery + " and A.#EXTERNALDATAREFERENCE# in (" + teamMembers + ")";
                    }


                }

                sqlQuery = sqlQuery.Replace('#', '"');

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);

                dataAdapter.Fill(employeeDetails);

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(employeeDetails);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("Induction Group Creation", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass searchEmployee(allocateEmployeeRequest request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable employeeDetails = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

                npgsqlCon.Open();
                string sqlQuery = "select A.#EXTERNALDATAREFERENCE# as EmployeeID,concat(A.#FIRSTNAME#,' ',A.#LASTNAME#) as EmployeeName from #EmployeeMaster# A  where  (lower(A.#EXTERNALDATAREFERENCE#)";
                sqlQuery = sqlQuery + " like lower('%" + request.EmployeeID  + "%') or lower(A.#FIRSTNAME#) like lower('%" + request.EmployeeID + "%') or lower(A.#LASTNAME#) like lower('%" + request.EmployeeID + "%') or lower(concat(A.#FIRSTNAME#,' ',A.#LASTNAME#)) like lower('%" + request.EmployeeID + "%') ) and A.#Active_Separated# = 'Active' ";
                // string sqlQuery = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#, concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,cast(TO_CHAR(A.#DOJ#, 'dd-Mon-yyyy') as character varying) as dojdisplay,A.#DOJ#,A.#COMPANY_CODE# as #CompanyCode# from #EmployeeMaster# A  where  A.#EXTERNALDATAREFERENCE# = '" + request.EmployeeID + "' and A.#Active_Separated# = 'Active'";
                string companiestopass = string.Empty;

                if (request.currentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        sqlQuery = sqlQuery + " and #COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                else if (request.currentRole == "Program Manager")
                {

                    string incccompany = string.Empty;
                    DataTable dtEmployees = new DataTable();
                    dtEmployees = _usermanagementBL.getassigneddepartmentforprogrammanager(request.LoginEMPCode);
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtEmployees.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["DepartmentCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        sqlQuery = sqlQuery + " and #Department_Code# in (" + companiestopass + ")";

                        if (!string.IsNullOrEmpty(Convert.ToString(dtEmployees.Rows[0]["CompanyCode"])))
                        {
                           

                            string[] cccode = Convert.ToString(dtEmployees.Rows[0]["CompanyCode"]).Split(",");
                            foreach (string ccode in cccode)
                            {
                                incccompany = incccompany + "'" + Convert.ToString(ccode) + "',";
                            }

                            incccompany = incccompany.TrimEnd(',');
                        }

                        sqlQuery = sqlQuery + " and #COMPANY_CODE# in (" + incccompany + ")";

                    }
                    else
                    {
                        sqlQuery = sqlQuery + " and #COMPANY_CODE#='" + request.currentcompany + "'";
                    }
                }
                else if (request.currentRole == "Team Lead")
                {
                    string teamMembers = string.Empty;

                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.LoginEMPCode;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }
                    if (!string.IsNullOrEmpty(teamMembers))
                    {
                        sqlQuery = sqlQuery + " and A.#EXTERNALDATAREFERENCE# in (" + teamMembers + ")";
                    }

                  
                }

              //  sqlQuery = sqlQuery + " and A.#EXTERNALDATAREFERENCE#!='" + request.LoginEMPCode + "'";

                sqlQuery = sqlQuery.Replace('#', '"');

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);

                dataAdapter.Fill(employeeDetails);

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(employeeDetails);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("searchEmployee", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass addMultiEmployee(allocateEmployeeRequest request)
        {
            ResponseClass response = new ResponseClass();

            string companiestopass = string.Empty;

            if (!string.IsNullOrEmpty(request.EmployeeID))
            {
                request.EmployeeID = request.EmployeeID.Replace("\n","");
            }

            try
            {
                DataTable trainingGroup = new DataTable();
                string employeeCode = string.Empty;

                string[] empArray = request.EmployeeID.Split(",");
                if (empArray.Length>0 && empArray!=null)
                {
                    foreach (var empCode in empArray)
                    {
                        if (employeeCode.Length > 0)
                        {
                            employeeCode = employeeCode + "'" + Convert.ToString(empCode) + "',";
                            //employeeCode = employeeCode + empCode + ",";
                        }
                        else
                        {
                            employeeCode = "'" + Convert.ToString(empCode) + "',";
                        }
                    }

                    employeeCode=employeeCode.TrimEnd(',');

                    string sqlQuery = "select A.#EXTERNALDATAREFERENCE# as #EmployeeID#, concat(A.#FIRSTNAME#,'',A.#LASTNAME#) as #EmployeeName#,A.#DEPARTMENT# as #Department#,A.#COUNTRY# as #Country#,A.#GRADE# as #Grade#,A.#Sub_Process# as #SubProcess#,cast(TO_CHAR(A.#DOJ#, 'dd-Mon-yyyy') as character varying) as dojdisplay,A.#DOJ#,A.#COMPANY_CODE# as #CompanyCode#,coalesce(A.#FIRSTNAME#,'') as firstname,coalesce(A.#Official_Email#,'') as email from #EmployeeMaster# A   ";
                    if (employeeCode.Length > 0)
                    {
                        sqlQuery = sqlQuery + " where A.#EXTERNALDATAREFERENCE# in (" + employeeCode + ")";
                    }
                    sqlQuery = sqlQuery + " and A.#Active_Separated# = 'Active' ";

                    if (request.currentRole == "Geo Admin")
                    {
                        DataTable dtCompanies = new DataTable();
                        dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dtCompanies.Rows)
                            {
                                companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                            }

                            companiestopass = companiestopass.TrimEnd(',');

                            sqlQuery = sqlQuery + " and #COMPANY_CODE# in (" + companiestopass + ")";

                        }
                    }
                    else if (request.currentRole == "Program Manager")
                    {
                        string incccompany = string.Empty;
                        DataTable dtEmployees = new DataTable();
                        dtEmployees = _usermanagementBL.getassigneddepartmentforprogrammanager(request.LoginEMPCode);
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dtEmployees.Rows)
                            {
                                companiestopass = companiestopass + "'" + Convert.ToString(exclude["DepartmentCode"]) + "',";
                            }

                            companiestopass = companiestopass.TrimEnd(',');

                            sqlQuery = sqlQuery + " and #Department_Code# in (" + companiestopass + ")";

                            if (!string.IsNullOrEmpty(Convert.ToString(dtEmployees.Rows[0]["CompanyCode"])))
                            {


                                string[] cccode = Convert.ToString(dtEmployees.Rows[0]["CompanyCode"]).Split(",");
                                foreach (string ccode in cccode)
                                {
                                    incccompany = incccompany + "'" + Convert.ToString(ccode) + "',";
                                }

                                incccompany = incccompany.TrimEnd(',');
                            }

                            sqlQuery = sqlQuery + " and #COMPANY_CODE# in (" + incccompany + ")";

                        }
                        else
                        {
                            sqlQuery = sqlQuery + " and #COMPANY_CODE#='" + request.currentcompany + "'";
                        }
                    }
                    else if (request.currentRole == "Team Lead")
                    {
                        string teamMembers = string.Empty;

                        getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                        getteam.EmployeeCode = request.LoginEMPCode;
                        var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                        DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                        if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                        {
                            foreach (DataRow exclude in QualtricTeamMembers.Rows)
                            {
                                teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                            }

                            teamMembers = teamMembers.TrimEnd(',');

                        }
                        if (!string.IsNullOrEmpty(teamMembers))
                        {
                            sqlQuery = sqlQuery + " and A.#EXTERNALDATAREFERENCE# in (" + teamMembers + ")";
                        }


                    }

                    sqlQuery = sqlQuery.Replace('#', '"');
                    string pgsqlConnection = appSettings.Value.DbConnection;
                    NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                    npgsql.Open();

                    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    dataAdapter.Fill(trainingGroup);
                    npgsql.Close();
                    
                    response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
                }

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";




            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageAllocateEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
    }
}
