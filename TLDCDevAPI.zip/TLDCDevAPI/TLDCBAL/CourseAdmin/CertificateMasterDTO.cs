﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.CourseAdmin
{
    public class CertificateMasterDTO
    {
        public string EmployeeId { get; set; }
        public string CertificateNumber { get; set; }
        public string TemplateName { get; set; }
        public string FilePath { get; set; }
        public int IsDeleted { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedOn { get; set; }
        public string DeletedBy { get; set; }
        public string DeletedOn { get; set; }
        public int SequenceNo { get; set; }
        public string Department { get; set; }
        public string Geo { get; set; }
        public string CurrentRoleName { get; set; }
        public string CountryName { get; set; }

    }

    public class CertificateListDTO
    {
        public string EmployeeId { get; set; }
        public string CertificateNumber { get; set; }
        public string TemplateName { get; set; }
        public string Geo { get; set; }
        public string CurrentRoleName { get; set; }

    }
}
