﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;

namespace TLDCBAL.CourseAdmin
{
    public interface IVideoChannelBL
    {
        public ResponseClass GetVideoChannelList(ChannelReuest request);
        public ResponseClass InsertEditVideoChannel(CreateChannelDTO request);
        public ResponseClass editVideoChanneldata(CreateChannelDTO request);
        public ResponseClass UploadVideotoChannel(ChannelVideoDTO request);
        public ResponseClass EditVideoChannel(CreateChannelDTO request);
        public ResponseClass GetWatchVideoChannel(CreateChannelDTO request);
        public ResponseClass CreateChannelVideoViewCount(CreateChannelDTO request);
        public ResponseClass ViewChannel(CreateChannelDTO request);
        public ResponseClass SubscribeChannel(SubscribeChannelDTO request);
        public ResponseClass searchProgramManager(allocateEmployeeRequest request);
        public ResponseClass AssignUserAccess(ChannelAccessDTO request);
        public ResponseClass UpdateAccessList(ChannelAccessDTO request);
        public ResponseClass UpdateLikes(VideoLikeDTO request);
        public ResponseClass DeleteChannelVideo(VideoLikeDTO request);
        public ResponseClass DeleteMyChannelVideo(VideoLikeDTO request);

    }
}
