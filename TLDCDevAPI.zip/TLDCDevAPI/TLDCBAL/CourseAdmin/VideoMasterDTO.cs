﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.CourseAdmin
{
    public class manageVideoMasterrequestDTO
    {
        public int videoID { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string videoName { get; set; }
        public string videoType { get; set; }
        public string videoStatus { get; set; }
        public string videoCode { get; set; }
        public string videoFilePath { get; set; }
        public string LoginEMPCode { get; set; }
        public string currentRole { get; set; }
        public string CompanyCode { get; set; }

        public string UserCompany { get; set; }

        public int PageNumber { get; set; }

        public int RowsOfPage { get; set; }

        public int GetMode { get; set; }

        public string objectCode { get; set; }
    }
    public class addVideoMasterRequestDTO
    {
        public string videoID { get; set; }
        public string videoCode { get; set; }
        public string videoTitle { get; set; }
        public string description { get; set; }
        public string serachkeyword { get; set; }
        public string insertedBy { get; set; }

        public string CurrentRole { get; set; }
        public string insertedIPAddress { get; set; }
        public string VideoType { get; set; }
        public string Status { get; set; }
        public string action { get; set; }
        public string keywords { get; set; }
        public int PointsEarned { get; set; }
        public List<addVideoHighlights> addVideoHighlights { get; set; }
        public List<addVideoAttachments> addVideoAttachments { get; set; }
        public addVideoMasterRequestDTO()
        {
            addVideoHighlights = new List<addVideoHighlights>();
            addVideoAttachments = new List<addVideoAttachments>();
        }
    }

    public class addVideoHighlights
    {
        public string HighlightsText { get; set; }
        public string DurationMinute { get; set; }
        public string DurationSecond { get; set; }
    }
    public class addVideoAttachments
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string VideoThumbnail { get; set; }
        public string FileType { get; set; }
        public string MediaType { get; set; }
    }
    public class deleteVideoMasterRequestDTO
    {
        public string videoCode { get; set; }
        public string deletedBy { get; set; }
        public string deletedOn { get; set; }
        public string deletedIPAddress { get; set; }
    }
}
