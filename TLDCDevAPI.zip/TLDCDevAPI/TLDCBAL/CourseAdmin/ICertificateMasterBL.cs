﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;

namespace TLDCBAL.CourseAdmin
{
    public interface ICertificateMasterBL
    {
        ResponseClass AddCertificate(CertificateMasterDTO request);
        ResponseClass CertificateList(CertificateMasterDTO request);
        ResponseClass CertificateNameList(CertificateListDTO request);
        ResponseClass DeleteCertificate(CertificateMasterDTO request);
        ResponseClass GetCertificate(CertificateMasterDTO request);
        ResponseClass EditCertificate(CertificateMasterDTO request);
    }
}
