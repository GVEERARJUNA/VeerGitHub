﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.CourseAdmin
{
    public class manageTrainingGrouprequestDTO
    {
        public int groupID { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string groupCode { get; set; }
        public string groupName { get; set; }

        public string LoginEMPCode { get; set; }
        public string currentRole { get; set; }
        public string CompanyCode { get; set; }

        public int PageNumber { get; set; }

        public int RowsOfPage { get; set; }
        public int GetMode { get; set; }

        public string UserCompany { get; set; }
    }
    public class addTrainingGroupRequestDTO
    {
        public string groupID { get; set; }
        public string groupCode { get; set; }
        public string groupName { get; set; }
        public string description { get; set; }
        public string insertedBy { get; set; }
        public string insertedIPAddress { get; set; }
        public string subprocesses { get; set; }
        public string employeecodes { get; set; }
        public string action { get; set; }
        public string CurrentRole { get; set; }
    }
    public class deleteTrainingGroupRequestDTO
    {
        public string groupID { get; set; }
    }

    public class allocateEmployeeRequest
    {
        public string EmployeeID { get; set; }
        public string LoginEMPCode { get; set; }
        public string currentRole { get; set; }
        public string currentcompany { get; set; }

        public string CallingSource { get; set; }
    }


}
