﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;

namespace TLDCBAL.CourseAdmin
{
    public interface ICourseMasterBL
    {
        ResponseClass ManageCourseMaster(manageCourseMasterrequestDTO request);

        ResponseClass ManageCourseMasterPaging(manageCourseMasterrequestDTO request);
        ResponseClass InsertEditCourseMaster(addEditCourseMasterrequestDTO request);
        ResponseClass DeleteCourse(deleteCourseMasterRequestDTO request);
        ResponseClass EditCourse(addEditCourseMasterrequestDTO request);
        ResponseClass IsCourseAssign(CheckCourseAssign request);
    }
}
