﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.CourseAdmin
{
    public class getreportnamesrequestDTO
    {
        public string EmplopyeeCode { get; set; }

        public string EmplopyeeRole { get; set; }

        public string SearchID { get; set; }

        public string SearchAction { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }

    public class addnewscheduleRequestDTO
    {
        public string PrimaryID { get; set; }
        public string ReportID { get; set; }

        public string DisplayName { get; set; }

        public string RunReportFor { get; set; }

        public int EmptyFlag { get; set; }

        public string EmailTo { get; set; }

        public string RecurrenceFrequency { get; set; }

        public string RecurrenceTime { get; set; }
        public string RecurrenceTimeZone { get; set; }

        public string StartDate { get; set; }

        // days related
        public int RepeatEveryDayCount { get; set; }


        // week related
        public int RepeatEveryWeekCount { get; set; }
        public string RepeatWeekDays { get; set; }

        // month related
        public int RepeatEveryMonthCount { get; set; }

        public string RepeatMonthName { get; set; }

        public string RepeatMonthDate { get; set; }
        // year related
        public int RepeatEveryYearCount { get; set; }

        public string RepeatYearMonth { get; set; }

        public int RepeatYearMonthDate { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedIPAddress { get; set; }

        public int EndAfterRecurrence { get; set; }

        public string RecurrenceEndDate { get; set; }

        public string DailyMode { get; set; }

        public string MonthMode { get; set; }

        public string YearlyMode { get; set; }

        public string ServerStartDateTime { get; set; }
    }

    public class geteditdatarequestDTO
    {
        public string ScheduleID { get; set; }
    }

    public class deleteschedulereportrequestDTO
    {
        public string ScheduleID { get; set; }

        public string CreatedBy { get; set; }
        public string CreatedIPAddress { get; set; }
    }

    public class getschedulepagelistDTO
    {
        public string fromdate { get; set; }

        public string todate { get; set; }
    }

}
