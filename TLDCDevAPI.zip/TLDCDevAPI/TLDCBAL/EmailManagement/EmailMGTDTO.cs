﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.EmailManagement
{
    public class MailDetails
    {
        public string Sender { get; set; }
        public string SenderName { get; set; }
        public string Subject { get; set; }
        // public string ToList { get; set; }
        public string CcList { get; set; }
        public string BccList { get; set; }
        public List<AtatchmentList> Attachment { get; set; }
        public string ImagePathHeader { get; set; }
        public string SmtpHostName { get; set; }
        public string MailActualBody { get; set; }

        public List<BCCList> bCCLists { get; set; }
        public List<ToList> ToList { get; set; }



    }
    public class AtatchmentList
    {
        public string Attachment { get; set; }
    }

    public class ToList
    {
        public string EmailAddress { get; set; }
    }

    public class BCCList
    {
        public string EmailAddress { get; set; }
    }

    public class EmailEntity
    {
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }

        public int EmailType { get; set; }
    }
}
