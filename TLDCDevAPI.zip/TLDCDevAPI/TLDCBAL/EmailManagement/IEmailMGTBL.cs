﻿using System.Collections.Generic;

namespace TLDCBAL.EmailManagement
{
    public interface IEmailMGTBL
    {
        List<EmailEntity> getEmailTemplate(string templateName, string language);
        int InsertEmailTransaction(string EmailSubject, string EmailBody, string EmaillTo, string EmailCC, string CheckID, string EmailType, string EmailStatus);
    }
}