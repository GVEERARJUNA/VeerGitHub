﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.EmailManagement
{
    public class EmailMGTBL : IEmailMGTBL
    {
        private readonly IServiceConnect _serviceconnect;
        private readonly IOptions<IDBConnection> appSettings;
        DBConnection dBConnection;
        private IQualtricsDataBL _qualtricsBL;

        public EmailMGTBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;
            dBConnection = new DBConnection(appSettings.Value.QualtricsDbConnection);
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
        }

        public List<EmailEntity> getEmailTemplate(string templateName, string language)
        {
            List<EmailEntity> emailEntity = new List<EmailEntity>();
            try
            {

                DataTable dtEmailDetails = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_email_template_bysubject
                                                                        ( 
                                                                            :p_subject,
                                                                            :p_language
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(templateName))
                            cmd.Parameters.AddWithValue("p_subject", DbType.String).Value = templateName;
                        else
                            cmd.Parameters.AddWithValue("p_subject", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(language))
                            cmd.Parameters.AddWithValue("p_language", DbType.String).Value = language;
                        else
                            cmd.Parameters.AddWithValue("p_language", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmailDetails);
                        string responseJSON = JsonConvert.SerializeObject(dtEmailDetails);
                        emailEntity = JsonConvert.DeserializeObject<List<EmailEntity>>(responseJSON);
                        //response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getEmailTemplate", "1024", ex.Message, "Exception");

            }
            return emailEntity;
        }

        public int InsertEmailTransaction(string EmailSubject,string EmailBody,string EmaillTo,string EmailCC,string CheckID,string EmailType,string EmailStatus)
        {
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_emailtransaction
                                                                        ( 
                                                                            :p_emailsubject,
                                                                            :p_emailbody,:p_emailto,
                                                                            :p_emailcc,:p_checkid,:p_emailtype,:p_emailstatus
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(EmailSubject))
                            cmd.Parameters.AddWithValue("p_emailsubject", DbType.String).Value = EmailSubject;
                        else
                            cmd.Parameters.AddWithValue("p_emailsubject", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(EmailBody))
                            cmd.Parameters.AddWithValue("p_emailbody", DbType.String).Value = EmailBody;
                        else
                            cmd.Parameters.AddWithValue("p_emailbody", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(EmaillTo))
                            cmd.Parameters.AddWithValue("p_emailto", DbType.String).Value = EmaillTo;
                        else
                            cmd.Parameters.AddWithValue("p_emailto", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(EmailCC))
                            cmd.Parameters.AddWithValue("p_emailcc", DbType.String).Value = EmailCC;
                        else
                            cmd.Parameters.AddWithValue("p_emailcc", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(CheckID))
                            cmd.Parameters.AddWithValue("p_checkid", DbType.String).Value = CheckID;
                        else
                            cmd.Parameters.AddWithValue("p_checkid", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(EmailType))
                            cmd.Parameters.AddWithValue("p_emailtype", DbType.String).Value = EmailType;
                        else
                            cmd.Parameters.AddWithValue("p_emailtype", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(EmailStatus))
                            cmd.Parameters.AddWithValue("p_emailstatus", DbType.String).Value = EmailStatus;
                        else
                            cmd.Parameters.AddWithValue("p_emailstatus", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                       
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEmailTransaction", "1024", ex.Message, "Exception");
               
            }

            //try
            //{
            //    NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);
            //    //EmailBody = "";
            //    string sqlQuery = "call prc_insert_emailtransaction('" + EmailSubject + "','" + EmailBody + "','" + EmaillTo + "','" + EmailCC + "','" + CheckID + "','" + EmailType + "','" + EmailStatus + "')";
            //    npgCon.Open();
            //    // Define a command to call  procedure
            //    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
            //    NpgsqlDataReader rdr = cmd.ExecuteReader();
            //    npgCon.Close();
            //}
            //catch (Exception ex)
            //{

            //    _serviceconnect.LogConnect("InsertEmailTransaction", "1024", "SAVE EMAIL TRANSACTION : " + ex.Message, "Exception");
            //}

            return 1;
        }
    }
}
