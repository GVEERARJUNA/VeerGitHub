﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ProgramManager
{
    public class ProcessSessionDTO
    {
        public class manageProcessSession
        {
            public int TID { get; set; }
            public string SessionID { get; set; }
            public string ProcessTrainingCode { get; set; }
            public string SessionName { get; set; }
            public string InsertUpdatedBy { get; set; }
            public int deletedflag { get; set; }
        }
        public class addupdateProcessSession
        {
            public int TID { get; set; }
            public string SessionID { get; set; }
            public string ProcessTrainingCode { get; set; }
            public string SessionName { get; set; }
            public string InsertUpdatedBy { get; set; }
            public int deletedflag { get; set; }
            public string Action { get; set; }
            public string AttendanceLevel { get; set; }
            public string AttendanceRequired { get; set; }
            public List<ProcessSessionCalendor> ProcessSessionCalendorList { get; set; }
            public addupdateProcessSession()
            {
                ProcessSessionCalendorList = new List<ProcessSessionCalendor>();
            }
        }
        public class ProcessSessionCalendor
        {
            public int TID { get; set; }
            public string SessionID { get; set; }
            public string StartDate { get; set; }
            public string EndDate { get; set; }
            public string StartTime { get; set; }
            public string EndTime { get; set; }
            public string TimeZone { get; set; }
            public string Venue { get; set; }
            public string FacilitatorType { get; set; }
            public string FacilitatorName { get; set; }
            public string InsertUpdatedBy { get; set; }
            public int DeletedFlag { get; set; }
        }

        public class deleteProcessSessiom
        {
            public string SessionID { get; set; }
            public string DeletedBy { get; set; }
            public string DeletedIPAddress { get; set; }
        }
        public class VenueDTO
        {
            public string BuildingFacilityName { get; set; }
            public string UserCompanyName { get; set; }
        }
        public class FacilitatorTypeDTO
        {
            public int FacilitatorTypeId { get; set; }
            public string FacilitatorType { get; set; }
        }
        public class FacilitatorNameDTO
        {
            public string FacilitatorType { get; set; }
            public string ProcessTrainingCode { get; set; }
            public string EmployeeId { get; set; }
            public string FacilitatorName { get; set; }
        }
        public class SessionCount
        {
            public int TotalSession { get; set; }
            public int TotalSessionWIP { get; set; }
            public int TotalSessionCompleted { get; set; }
            public int TotalSessionNotStarted { get; set; }
            public string ProcessTrainingCode { get; set; }
        }
    }
}
