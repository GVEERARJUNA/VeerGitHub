﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.CourseAdmin;
using TLDCBAL.Qualtrics;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;

namespace TLDCBAL.ProgramManager
{
    public class ExpressEventBL : IExpressEventBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;
        private IQualtricsDataBL _qualtricsBL;
        private ISchedulerBL _schedulerBL;

        private IVideoMasterBL _videomasterBL;

        private ICourseMasterBL _coursemasterBL;

        private IProgramMasterBL _programmasterBL;

        private IClassRoomTrainingBL _classroomtrainingBL;

        private ITrainingGroupBL _traininggroupBL;

        public ExpressEventBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, 
            IQualtricsDataBL qualtricsBL, ISchedulerBL schedulerBL, IVideoMasterBL videomasterBL, ICourseMasterBL coursemasterBL, IProgramMasterBL programmasterBL,
            IClassRoomTrainingBL classroomtrainingBL, ITrainingGroupBL traininggroupBL

            )
        {
            appSettings = app;
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
            _schedulerBL = schedulerBL;
            _videomasterBL = videomasterBL;
            _coursemasterBL = coursemasterBL;
            _programmasterBL = programmasterBL;
            _classroomtrainingBL = classroomtrainingBL;
            _traininggroupBL = traininggroupBL;
        }

        public ResponseClass ManageExpressEvent(manageEventrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable expressEvent = new DataTable();
                string selectQuery = string.Empty;
                selectQuery = "select A.#HideSeekBar# as hideseekbar,A.#EventFrequency# as eventfrequency,A.#InsertedBy#,A.#EventCode# as eventcode,A.#EventCode# as valuefield,A.#EventName# as displayfield,A.#EventName# as eventname,A.#EventType# as eventtype,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,TO_CHAR(A.#InsertedDateTime#, 'dd Mon yyyy') as createddate,TO_CHAR(A.#EventStartDate#, 'dd-Mon-yyyy') as startDate,TO_CHAR(A.#EventEndDate#, 'dd-Mon-yyyy') as enddate,EXTRACT(HOUR FROM A.#EventStartTime#) as eventstarttimehour,EXTRACT(MINUTE FROM A.#EventStartTime#) as eventstarttimeminute,EXTRACT(HOUR FROM A.#EventEndTime#) as eventendtimehour,EXTRACT(MINUTE FROM A.#EventEndTime#) as eventendtimeminute,A.#IsPublished# as ispublished,case when A.#IsPublished#=1 then 'YES' else 'NO' end as publishedtext,A.#AcknowledgeRequired#,(select count(*) from #EventAllocation# where #ObjectCode#=A.#EventCode# and #ObjectType#='Event') as allocationcount,A.#TimeZone#  as timezone,A.#IsPublishonApp# as ispublishedonapp,A.#EEDSSubcategory# as eedssubcategory,A.#AllocationCategory# as allocationcategory, ";
                selectQuery = selectQuery + "(select count(*) from #BusinessLearningEmployeeActivity# where #EventCode#=A.#EventCode#) as activitycount";
                selectQuery = selectQuery + " from #EventMaster# A inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                selectQuery = selectQuery + " where (A.#DeletedFlag#)=0 and A.#EventSource#='1'   ";
                // and A.#EventEndDate#>=cast(now() as date)
                if (!string.IsNullOrEmpty(request.eventCode))
                {
                    selectQuery = selectQuery + " and  A.#EventCode#='" + request.eventCode + "'";
                }
                else
                {
                    if (!string.IsNullOrEmpty(request.searchKey))
                    {
                        
                        selectQuery = selectQuery + " and  (lower(A.#EventName#) like lower('%" + request.searchKey + "%')  or A.#EventCode#='" + request.searchKey + "')";
                    }
                }
                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                     selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";

                   // selectQuery = selectQuery + " and (A.#InsertedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                   // selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //{
                    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    {
                    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    }

                    //    companiestopass = companiestopass.TrimEnd(',');

                    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //}

                    selectQuery = selectQuery + " and (A.#CurrentRole#='200009' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    selectQuery = selectQuery + " )";
                }
                else if (request.CurrentRole == "Participant")
                {
                    selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";
                }

                if (request.CallingSource=="Report")
                {
                    selectQuery = selectQuery + " and A.#IsPublished#=1 ";
                }

                if (!string.IsNullOrEmpty(request.EventType))
                {
                    //selectQuery = selectQuery + " and A.#EventType#='" + request.EventType + "'";
                    //if (request.EventType == "ScormCourse")
                    //{
                    //    selectQuery = selectQuery + " and A.#EventType#='Course' and A.#EventCode# in ";
                    //    selectQuery = selectQuery + "  (select A.#EventCode# from #EventContent# A ";
                    //    selectQuery = selectQuery + "   inner join #CourseMaster# CM on CM.#CourseCode# = A.#ContentCode# ";
                    //    selectQuery = selectQuery + "  where CM.#CourseType# in ('SCORM1.2', 'SCORM1.3') )";

                    //    //selectQuery = selectQuery + " and A.#ClassRoomCode# in (select A.#ClassRoomCode# ";
                    //    //selectQuery = selectQuery + "  from #ClassRoomEntityDetails# A ";
                    //    //selectQuery = selectQuery + " inner join #CourseMaster# CM on A.#EntityCode# = CM.#CourseCode# ";
                    //    //selectQuery = selectQuery + "  where #EntityType# = 'Course' and CM.#CourseType# in ('SCORM1.2', 'SCORM1.3') ";
                    //    //selectQuery = selectQuery + "  and A.#IsPublished# = 1)";
                    //}
                    //else
                    //{
                    //    selectQuery = selectQuery + " and A.#EventType#='" + request.EventType + "'";
                    //}
                    if (request.EventType=="ScormCourse")
                    {
                        request.EventType = "Course";
                    }
                    selectQuery = selectQuery + " and (A.#EventType#='" + request.EventType + "' or A.#EventType#='Program')";

                }

                selectQuery = selectQuery + " order by  A.#InsertedDateTime# desc";

                //if (request.PageNumber!=-1)
                //{
                //    selectQuery = selectQuery + " limit  " +  request.RowsOfPage + "  offset(" + request.PageNumber + " - 1) * " + request.RowsOfPage + " ";
                //}

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(expressEvent);
                npgsql.Close();
                response.responseCode = 1;

                if (expressEvent != null && expressEvent.Rows.Count > 0)
                {
                    
                    if (Convert.ToString(expressEvent.Rows[0]["eventstarttimehour"]).Length == 1)
                    {
                        expressEvent.Rows[0]["eventstarttimehour"] = '0' + Convert.ToString(expressEvent.Rows[0]["eventstarttimehour"]);
                    }
                    if (Convert.ToString(expressEvent.Rows[0]["eventstarttimeminute"]).Length == 1)
                    {
                        expressEvent.Rows[0]["eventstarttimeminute"] = '0' + Convert.ToString(expressEvent.Rows[0]["eventstarttimeminute"]);
                    }
                    if (Convert.ToString(expressEvent.Rows[0]["eventendtimehour"]).Length == 1)
                    {
                        expressEvent.Rows[0]["eventendtimehour"] = '0' + Convert.ToString(expressEvent.Rows[0]["eventendtimehour"]);
                    }
                    if (Convert.ToString(expressEvent.Rows[0]["eventendtimeminute"]).Length == 1)
                    {
                        expressEvent.Rows[0]["eventendtimeminute"] = '0' + Convert.ToString(expressEvent.Rows[0]["eventendtimeminute"]);
                    }

                    expressEvent.Columns.Add("encryptedID");
                    CommonFunction function = new CommonFunction();

                    if (expressEvent != null && expressEvent.Rows.Count > 0)
                    {
                        foreach (DataRow item in expressEvent.Rows)
                        {
                            item["encryptedID"] = function.Encrypt(Convert.ToString(item["eventcode"]));
                        }
                    }
                }
                response.responseJSON = JsonConvert.SerializeObject(expressEvent);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageExpressEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetExpressEventListView(manageEventrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_manage_event
                                                                        ( 
                                                                            :pcurrentemployeeid,
                                                                            :pcurrentemployeerole,:psearchkey,:peventcode,:peventtype,
                                                                            :p_pageno,:p_recordno
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.LoginEMPCode))
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.LoginEMPCode;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.searchKey))
                            cmd.Parameters.AddWithValue("psearchkey", DbType.String).Value = request.searchKey;
                        else
                            cmd.Parameters.AddWithValue("psearchkey", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.eventCode))
                            cmd.Parameters.AddWithValue("peventcode", DbType.String).Value = request.eventCode;
                        else
                            cmd.Parameters.AddWithValue("peventcode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EventType))
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = request.EventType;
                        else
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {

                            if (Convert.ToString(dtEmployees.Rows[0]["eventstarttimehour"]).Length == 1)
                            {
                                dtEmployees.Rows[0]["eventstarttimehour"] = '0' + Convert.ToString(dtEmployees.Rows[0]["eventstarttimehour"]);
                            }
                            if (Convert.ToString(dtEmployees.Rows[0]["eventstarttimeminute"]).Length == 1)
                            {
                                dtEmployees.Rows[0]["eventstarttimeminute"] = '0' + Convert.ToString(dtEmployees.Rows[0]["eventstarttimeminute"]);
                            }
                            if (Convert.ToString(dtEmployees.Rows[0]["eventendtimehour"]).Length == 1)
                            {
                                dtEmployees.Rows[0]["eventendtimehour"] = '0' + Convert.ToString(dtEmployees.Rows[0]["eventendtimehour"]);
                            }
                            if (Convert.ToString(dtEmployees.Rows[0]["eventendtimeminute"]).Length == 1)
                            {
                                dtEmployees.Rows[0]["eventendtimeminute"] = '0' + Convert.ToString(dtEmployees.Rows[0]["eventendtimeminute"]);
                            }

                            dtEmployees.Columns.Add("encryptedID");
                            CommonFunction function = new CommonFunction();

                            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                            {
                                foreach (DataRow item in dtEmployees.Rows)
                                {
                                    item["encryptedID"] = function.Encrypt(Convert.ToString(item["eventcode"]));
                                }
                            }
                        }

                        if (request.GetMode==0)
                        {
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                        else
                        {
                            response.dtresponse = dtEmployees;
                        }

                        
                    }
                }


                if (dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    int recordcount = 1;
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                        if (request.PageNumber >0)
                        {


                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                }



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("eventdashboarddetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass InsertEditExpressEvent(insertEditEventRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;
                if (!string.IsNullOrEmpty(request.EventStartDate))
                {
                    try
                    {
                        dtFrom = Convert.ToDateTime(request.EventStartDate);
                        fromDate = Convert.ToDateTime(request.EventStartDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("InsertEditExpressEvent", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;


                    }
                }
                if (!string.IsNullOrEmpty(request.EventEndDate))
                {
                    try
                    {
                        dtTo = Convert.ToDateTime(request.EventEndDate);
                        toDate = Convert.ToDateTime(request.EventEndDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("InsertEditExpressEvent", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;


                    }
                }

                //if (dtFrom > dtTo)
                //{
                //    response.responseCode = 0;
                //    response.responseMessage = "Invalid start time and end time!";
                //    return response;
                //}

                //DateTime needstarttime = new DateTime();
                //DateTime needendtime = new DateTime();

                //needstarttime = Convert.ToDateTime(request.serverstartdate + " " + request.serverstarttime);
                //needendtime = Convert.ToDateTime(request.serverenddate + " " + request.serverendtime);

                //if (!string.IsNullOrEmpty(request.EventStartTime) && Convert.ToString(request.EventStartTime) != "0")
                //{
                //    needstarttime = Convert.ToDateTime(dtFrom.ToString("yyyy-MM-dd") + " " + Convert.ToString(request.EventStartTime));
                //}
                //else
                //{
                //    needstarttime = Convert.ToDateTime(dtFrom.ToString("yyyy-MM-dd") + " 12:00 AM");
                //}

                //if (!string.IsNullOrEmpty(Convert.ToString(request.EventEndTime)) && Convert.ToString(request.EventEndTime) != "0")
                //{
                //    needendtime = Convert.ToDateTime(dtTo.ToString("yyyy-MM-dd") + " " + Convert.ToString(request.EventEndTime));
                //}
                //else
                //{
                //    needendtime = Convert.ToDateTime(dtTo.ToString("yyyy-MM-dd") + " 11:59 PM");
                //}

                //TimeSpan difference = dtTo - dtFrom;

                //if (difference.TotalDays > 60)
                //{
                //    response.responseCode = 0;
                //    response.responseMessage = "Maximum date range should be 30 days(1 Months)!";
                //    return response;
                //}

                //if (dtFrom < DateTime.Now)
                //{
                //    response.responseCode = 0;
                //    response.responseMessage = "Start time cannot be less that today date!";
                //    return response;
                //}

                //if (dtTo < DateTime.Now)
                //{
                //    response.responseCode = 0;
                //    response.responseMessage = "End time cannot be less that today date!";
                //    return response;
                //}


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_express_event
                                                                        ( 
                                                                            :p_event_code,
                                                                            :peventname,:peventtype,
                                                                            :peventstartdate,:peventenddate,
                                                                            :peventstarttime,:peventendtime,
                                                                            
                                                                            :pinsertedby,
                                                                            :pinsertedipaddress,
                                                                            :pevent_content,:p_action,:ispublished,:p_eventsource,:p_acknowledgerequire,:pserverstartdate,:pserverenddate,:ptimezone,:pserverstarttime,:pserverendtime,:pcurrentrole,:peventfrequency,:peventdays,:ishideseekbar,:ispublishonapp,:p_eedssubcategory,:p_allocationcategory
                                                                           

                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_event_code", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_event_code", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.EventName))
                            cmd.Parameters.AddWithValue("peventname", DbType.String).Value = request.EventName;
                        else
                            cmd.Parameters.AddWithValue("peventname", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.EventType))
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = request.EventType;
                        else
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("peventstartdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("peventstartdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(toDate))
                            cmd.Parameters.AddWithValue("peventenddate", DbType.String).Value = toDate;
                        else
                            cmd.Parameters.AddWithValue("peventenddate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EventStartTime) && request.EventStartTime != "0")
                            cmd.Parameters.AddWithValue("peventstarttime", DbType.String).Value = request.EventStartTime;
                        else
                            cmd.Parameters.AddWithValue("peventstarttime", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EventEndTime) && request.EventEndTime != "0")
                            cmd.Parameters.AddWithValue("peventendtime", DbType.String).Value = request.EventEndTime;
                        else
                            cmd.Parameters.AddWithValue("peventendtime", DbType.String).Value = DBNull.Value;



                        //cmd.Parameters.AddWithValue("peventstartdate", DbType.String).Value = request.EventStartDate;
                        //cmd.Parameters.AddWithValue("peventenddate", DbType.String).Value = request.EventEndDate;
                        //cmd.Parameters.AddWithValue("peventstarttime", DbType.String).Value = request.EventStartTime;
                        //cmd.Parameters.AddWithValue("peventendtime", DbType.String).Value = request.EventEndTime;


                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EventContent))
                            cmd.Parameters.AddWithValue("pevent_content", DbType.String).Value = request.EventContent;
                        else
                            cmd.Parameters.AddWithValue("pevent_content", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("ispublished", DbType.String).Value = request.IsPublished;

                        if (!String.IsNullOrEmpty(request.EventSource))
                            cmd.Parameters.AddWithValue("p_eventsource", DbType.String).Value = request.EventSource;
                        else
                            cmd.Parameters.AddWithValue("p_eventsource", DbType.String).Value = "1";

                        cmd.Parameters.AddWithValue("p_acknowledgerequire", DbType.String).Value = request.AcknowledgeRequired;
                        if (!String.IsNullOrEmpty(request.serverstartdate))
                            cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = request.serverstartdate;
                        else
                            cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.serverenddate))
                            cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = request.serverenddate;
                        else
                            cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = string.Empty;

                        
                        

                        if (!String.IsNullOrEmpty(request.TimeZone))
                            cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = request.TimeZone;
                        else
                            cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.serverstarttime))
                            cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = request.serverstarttime;
                        else
                            cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.serverendtime))
                            cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = request.serverendtime;
                        else
                            cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("pcurrentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentrole", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.EventFrequency))
                            cmd.Parameters.AddWithValue("peventfrequency", DbType.String).Value = request.EventFrequency;
                        else
                            cmd.Parameters.AddWithValue("peventfrequency", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EventDays))
                            cmd.Parameters.AddWithValue("peventdays", DbType.String).Value = request.EventDays;
                        else
                            cmd.Parameters.AddWithValue("peventdays", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("ishideseekbar", DbType.String).Value = request.HideSeekBar;

                        cmd.Parameters.AddWithValue("ispublishonapp", DbType.String).Value = request.IsPublishOnApp;

                        cmd.Parameters.AddWithValue("p_eedssubcategory", DbType.String).Value = request.EEDSSubcategory;

                        cmd.Parameters.AddWithValue("p_allocationcategory", DbType.String).Value = request.AllocationCategory;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();


                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                            

                            if (response.responseCode == 1 && request.action== "PUBLISH")
                            {
                                DataTable dtSurveyContent = new DataTable();

                                string EventType = string.Empty;

                                EventType = getEventType(request.EventCode);

                                if (EventType!="Program")
                                {
                                    dtSurveyContent = insertSurvey(request);
                                }
                                else
                                {
                                    
                                    dtSurveyContent = insertProgramSurvey(request);
                                }

                                
                                
                                DataTable employeeData = new DataTable();

                                employeeData= allocateBusinessTraining("Event", request.EventCode);

                                if (appSettings.Value.IsGamificationEnable=="1")
                                {
                                    try
                                    {
                                        pushDataToGamificationRequestDTO pushGamification = new pushDataToGamificationRequestDTO();
                                        pushGamification.EventCode = request.EventCode;
                                        var scResponse = _schedulerBL.pushDataToGamification(pushGamification);
                                    }
                                    catch (Exception ex)
                                    {
                                        _serviceconnect.LogConnect("InsertEditExpressEvent", "1024", ex.Message, "Exception");

                                    }
                                }

                                

                                // commeting out this code because now allocation done from survey portal
                                // 24-Jan-2024
                                //if (employeeData != null && employeeData.Rows.Count > 0)
                                //{

                                //    //dtSurveyContent=insertSurvey(request);
                                //    if (dtSurveyContent != null || dtSurveyContent.Rows.Count > 0)
                                //    {
                                //        foreach (DataRow drrow in dtSurveyContent.Rows)
                                //        {
                                //            if (Convert.ToInt32(drrow["SurveyID"]) > 0)
                                //            {
                                //                try
                                //                {
                                //                    surveyAllocationRequestDTO srv = new surveyAllocationRequestDTO();
                                //                    surveyAllocationResponseDTO res = new surveyAllocationResponseDTO();
                                //                    srv.LoggedInEmployeeId = request.InsertedBy;

                                //                    srv.SurveyId = Convert.ToInt32(drrow["SurveyID"]);
                                //                    srv.LstEmployeeIds = new List<string>();
                                //                    foreach (DataRow item in employeeData.Rows)
                                //                    {

                                //                        srv.LstEmployeeIds.Add(Convert.ToString(item["empcode"]));

                                //                    }

                                //                    string resData = _serviceconnect.insertSurveyAllocation(srv);
                                //                    res = JsonConvert.DeserializeObject<surveyAllocationResponseDTO>(resData);
                                //                }
                                //                catch (Exception)
                                //                {


                                //                }
                                //            }

                                //        }
                                //    }

                                //}


                                try
                                {
                                    _schedulerBL.emailonpublishevent(request.EventCode, "Event");
                                }
                                catch (Exception)
                                {

                                   
                                }
                                
                            }
                        }
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditExpressEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public DataTable allocateBusinessTraining(string objecttype,string objectCode)
        {
            //DataTable response = new DataTable();
            DataTable dtEmployees = new DataTable();
            try
            {
                
                string pgsqlConnection = appSettings.Value.DbConnection;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_business_training
                                                                        ( 
                                                                            :p_objecttype,
                                                                            :p_objectcode
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(objecttype))
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = objecttype;
                        else
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(objectCode))
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = objectCode;
                        else
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = string.Empty;


                        

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                       // response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        //if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        //{
                        //    response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                        //    response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);


                        //}
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("allocateBusinessTraining", "1024", ex.Message, "Exception");
                //response.responseCode = 0;
                //response.responseMessage = ex.Message;
            }

            return dtEmployees;
        }

        public ResponseClass InsertEditEventbyClassRoom(insertEditEventRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;
                if (!string.IsNullOrEmpty(request.EventStartDate))
                {
                    try
                    {
                        dtFrom = Convert.ToDateTime(request.EventStartDate);
                        fromDate = Convert.ToDateTime(request.EventStartDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("InsertEditEventbyClassRoom", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;


                    }
                }
                if (!string.IsNullOrEmpty(request.EventEndDate))
                {
                    try
                    {
                        dtTo = Convert.ToDateTime(request.EventEndDate);
                        toDate = Convert.ToDateTime(request.EventEndDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("InsertEditEventbyClassRoom", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;


                    }
                }

                //if (dtFrom > dtTo)
                //{
                //    response.responseCode = 0;
                //    response.responseMessage = "Invalid start time and end time!";
                //    return response;
                //}

              
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_event_classroom
                                                                        ( 
                                                                            :p_event_code,
                                                                            :peventname,:peventtype,
                                                                            :peventstartdate,:peventenddate,
                                                                            :peventstarttime,:peventendtime,
                                                                            
                                                                            :pinsertedby,
                                                                            :pinsertedipaddress,
                                                                            :pevent_content,:p_classroom_code,:p_acknowledgerequire,:pserverstartdate,:pserverenddate,:ptimezone,:pserverstarttime,:pserverendtime,:ishideseekbar,:ispublishonapp,:p_eedssubcategory

                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_event_code", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_event_code", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.EventName))
                            cmd.Parameters.AddWithValue("peventname", DbType.String).Value = request.EventName;
                        else
                            cmd.Parameters.AddWithValue("peventname", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.EventType))
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = request.EventType;
                        else
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("peventstartdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("peventstartdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(toDate))
                            cmd.Parameters.AddWithValue("peventenddate", DbType.String).Value = toDate;
                        else
                            cmd.Parameters.AddWithValue("peventenddate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EventStartTime) && request.EventStartTime != "0")
                            cmd.Parameters.AddWithValue("peventstarttime", DbType.String).Value = request.EventStartTime;
                        else
                            cmd.Parameters.AddWithValue("peventstarttime", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EventEndTime) && request.EventEndTime != "0")
                            cmd.Parameters.AddWithValue("peventendtime", DbType.String).Value = request.EventEndTime;
                        else
                            cmd.Parameters.AddWithValue("peventendtime", DbType.String).Value = DBNull.Value;



                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EventContent))
                            cmd.Parameters.AddWithValue("pevent_content", DbType.String).Value = request.EventContent;
                        else
                            cmd.Parameters.AddWithValue("pevent_content", DbType.String).Value = string.Empty;

                      

                        if (!String.IsNullOrEmpty(request.ClassRoomCode))
                            cmd.Parameters.AddWithValue("p_classroom_code", DbType.String).Value = request.ClassRoomCode;
                        else
                            cmd.Parameters.AddWithValue("p_classroom_code", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("p_acknowledgerequire", DbType.String).Value = request.AcknowledgeRequired;

                        if (!String.IsNullOrEmpty(request.serverstartdate))
                            cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = request.serverstartdate;
                        else
                            cmd.Parameters.AddWithValue("pserverstartdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.serverenddate))
                            cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = request.serverenddate;
                        else
                            cmd.Parameters.AddWithValue("pserverenddate", DbType.String).Value = string.Empty;




                        if (!String.IsNullOrEmpty(request.TimeZone))
                            cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = request.TimeZone;
                        else
                            cmd.Parameters.AddWithValue("ptimezone", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.serverstarttime))
                            cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = request.serverstarttime;
                        else
                            cmd.Parameters.AddWithValue("pserverstarttime", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.serverendtime))
                            cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = request.serverendtime;
                        else
                            cmd.Parameters.AddWithValue("pserverendtime", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("ishideseekbar", DbType.String).Value = request.HideSeekBar;

                        cmd.Parameters.AddWithValue("ispublishonapp", DbType.String).Value = request.IsPublishOnApp;

                        cmd.Parameters.AddWithValue("p_eedssubcategory", DbType.String).Value = request.EEDSSubcategory;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                            if (response.responseCode==1 && request.EventType=="Survey")
                            {
                                request.EventCode = response.responseMessage;
                                DataTable dtSurveyContent = new DataTable();
                                request.EventCode = response.responseMessage;
                                dtSurveyContent = insertSurvey(request);


                            }
                           
                        }
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditEventbyClassRoom", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public DataTable insertSurvey(insertEditEventRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable expressEvent = new DataTable();

            try
            {
                
                string selectQuery = string.Empty;
                
                selectQuery = "select A.#ContentCode#,A.#ContentText#,B.#ServerStartDate# as EventStartDate,B.#ServerEndDate# as EventEndDate,B.#ServerStartTime# as EventStartTime,B.#ServerEndTime# as EventEndTime from #EventContent# A inner join #EventMaster# B on A.#EventCode#=B.#EventCode# where B.#EventType#='Survey' and B.#EventCode#='" + request.EventCode + "'   ";

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(expressEvent);
                npgsql.Close();

                if (expressEvent!=null && expressEvent.Rows.Count>0)
                {
                    //get survey ID
                    expressEvent.Columns.Add("SurveyID");
                    foreach (DataRow item in expressEvent.Rows)
                    {
                        // call API
                        SurveyInsertRequestDTO srv = new SurveyInsertRequestDTO();
                        SurveyDetailsData res = new SurveyDetailsData();
                        srv.LoggedInEmployeeId = request.InsertedBy;
                        srv.TemplateId = Convert.ToString(item["ContentCode"]);
                        srv.TemplateName = Convert.ToString(item["ContentText"]);
                        DateTime fromDt = Convert.ToDateTime(item["EventStartDate"]);
                        DateTime toDt = Convert.ToDateTime(item["EventEndDate"]);


                        if (!string.IsNullOrEmpty(Convert.ToString(item["EventStartTime"])) && Convert.ToString(item["EventStartTime"]) != "0")
                        {
                            fromDt = Convert.ToDateTime(fromDt.ToString("yyyy-MM-dd") + " " + Convert.ToString(item["EventStartTime"]));

                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(item["EventEndTime"])) && Convert.ToString(item["EventEndTime"]) != "0")
                        {
                            fromDt = Convert.ToDateTime(fromDt.ToString("yyyy-MM-dd") + " " + Convert.ToString(item["EventEndTime"]));
                        }

                        srv.StartDate = fromDt;
                        srv.EndDate = toDt;

                        // srv.StartDate
                        string resData = _serviceconnect.insertSurveyInsert(srv);
                        res = JsonConvert.DeserializeObject<SurveyDetailsData>(resData);

                        if (res.status==true)
                        {
                            try
                            {
                                string sqlQuery = string.Empty;

                                npgsql.Open();
                                if (!string.IsNullOrEmpty(request.ClassRoomCode))
                                {
                                    sqlQuery = "update #EventContent# set #SurveyID#='" + res.data.SurveyId + "' where #EventCode#='" + request.EventCode + "' and #ContentCode#='" + srv.TemplateId + "';update #ClassRoomEntityDetails# set #EntityCode#='" + res.data.SurveyId + "' where #ClassRoomCode#='" + request.ClassRoomCode + "' and #EntityCode#='" + srv.TemplateId + "' and #EntityType#='Survey'; ";
                                }
                                else
                                {
                                    sqlQuery = "update #EventContent# set #SurveyID#='" + res.data.SurveyId + "' where #EventCode#='" + request.EventCode + "' and #ContentCode#='" + srv.TemplateId + "'";
                                }

                              //  sqlQuery = "update #EventContent# set #SurveyID#='" + res.data.SurveyId + "' where #EventCode#='" + request.EventCode + "' and #ContentCode#='" + srv.TemplateId + "'";

                                sqlQuery = sqlQuery.Replace('#', '"');
                                // Define a command to call  procedure
                                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsql);
                                NpgsqlDataReader rdr = cmd.ExecuteReader();

                                npgsql.Close();

                                item["SurveyID"] = Convert.ToString(res.data.SurveyId);
                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("UpdateSurveyID", "1024", ex.Message, "Exception");
                               // return response;
                            }
                        }

                        


                    }

                    response.responseCode = 1;
                    response.responseMessage = "SUCCESS";
                }

               
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageExpressEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            return expressEvent;
        }

        public ResponseClass GetAdminDashboardcount(getadmindashboardcount request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

                string companycode = string.Empty;
                DataTable dtEmployees = new DataTable();
                DataTable dtCompanies = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_program_manager_count
                                                                        ( 
                                                                            :p_username,
                                                                            :p_currentrole
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        if (dtEmployees != null || dtEmployees.Rows.Count > 0)
                        {
                            try
                            {
                                

                                if (request.CurrentRole == "Geo Admin")
                                {
                                    
                                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.UserName);
                                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                                    {
                                        foreach (DataRow exclude in dtCompanies.Rows)
                                        {
                                            companycode = companycode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                                        }

                                        companycode = companycode.TrimEnd(',');

                                        

                                    }
                                }

                                assessmentlistresponseData ASResponse = new assessmentlistresponseData();
                                //  request.UserName = string.Empty;
                                string assessmentResponse = _serviceconnect.getAssessment(request.Geo, request.UserName,request.CurrentRole, companycode);
                                ASResponse = JsonConvert.DeserializeObject<assessmentlistresponseData>(assessmentResponse);
                                if (ASResponse.Data.Data != null && ASResponse.Data.Data.Count > 0 && ASResponse.ResponseCode == "1")
                                {
                                    dtEmployees.Rows[0]["totalassessment"] = Convert.ToInt32(ASResponse.Data.Data.Count);
                                }
                            }
                            catch (Exception)
                            {

                               
                            }

                            try
                            {
                                //string ccCode = string.Empty;
                                //if (request.CurrentRole == "Geo Admin")
                                //{
                                //   // DataTable dtCompanies = new DataTable();
                                //  //  dtCompanies = _qualtricsBL.gtAssignedCompany(request.UserName);
                                //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                                //    {
                                //        foreach (DataRow exclude in dtCompanies.Rows)
                                //        {
                                //            ccCode = ccCode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                                //        }

                                //        ccCode = ccCode.TrimEnd(',');



                                //    }
                                //}
                                TLDEnvelope responseData = new TLDEnvelope();
                                string surveyResponse = _serviceconnect.getSurvey(request.Geo, request.UserName, request.CurrentRole, companycode);
                                responseData = JsonConvert.DeserializeObject<TLDEnvelope>(surveyResponse);
                                if (responseData.Status == true && responseData.TotalRecords > 0 && responseData.Data != null)
                                {
                                    dtEmployees.Rows[0]["totalsurvey"] = Convert.ToInt32(responseData.Data.Data.Count);
                                }
                            }
                            catch (Exception)
                            {

                                
                            }
                           
                            
                        }

                        dtEmployees.Columns.Add("teamleadcount");
                        try
                        {
                            if (request.CurrentRole == "Team Lead")
                            {
                                getTeamMembersRequestDTO rec = new getTeamMembersRequestDTO();
                                rec.EmployeeCode = request.UserName;
                                var QualtriData = _qualtricsBL.GetTeamMembers(rec);
                                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                                {
                                    dtEmployees.Rows[0]["teamleadcount"] = QualtricTeamMembers.Rows.Count;
                                }
                                else
                                {
                                    dtEmployees.Rows[0]["teamleadcount"] = 0;
                                }
                            }
                            else if (request.CurrentRole == "Geo Admin" || request.CurrentRole == "Global Admin")
                            {
                                var memberreponse = getMembers(request);
                                if (memberreponse != null && memberreponse.Rows.Count > 0)
                                {
                                    dtEmployees.Rows[0]["teamleadcount"] = Convert.ToInt32(memberreponse.Rows[0]["membercount"]);
                                }
                            }
                            else
                            {
                                dtEmployees.Rows[0]["teamleadcount"] = 0;
                            }
                        }
                        catch (Exception ex)
                        {

                            _serviceconnect.LogConnect("GetAdminDashboardcount", "1024", ex.Message, "Exception");
                        }

                        try
                        {
                            dtEmployees.Rows[0]["totalpendingactivities"] = 0;

                            if (request.CurrentRole == "Team Lead" || request.CurrentRole == "Geo Admin" || request.CurrentRole == "Global Admin")
                            {
                                TeamLeadPendingTaskDTO requestnew = new TeamLeadPendingTaskDTO();
                                requestnew.CurrentRole = request.CurrentRole;
                                requestnew.employeeCode = request.UserName;
                                requestnew.picktype = "count";
                                var responsependingList = GetTotalPendingActivity(requestnew);
                                if (responsependingList.responseCode==1)
                                {
                                    if (responsependingList.dtresponse!=null && responsependingList.dtresponse.Rows.Count>0)
                                    {
                                        dtEmployees.Rows[0]["totalpendingactivities"] = Convert.ToInt32(responsependingList.dtresponse.Rows[0]["totalpendingtask"]);
                                    }
                                }
                            }
                            
                        }
                        catch (Exception ex)
                        {

                            _serviceconnect.LogConnect("GetAdminDashboardcount", "1024", ex.Message, "Exception");
                        }

                        // get count of course

                        int courseCount = 0;

                        //courseCount = getCourseCount(request.CurrentRole, request.UserName, request.UserCompany, dtCompanies);

                        manageCourseMasterrequestDTO requestCourse = new manageCourseMasterrequestDTO();

                        requestCourse.UserCompany = request.UserCompany;

                        requestCourse.PageNumber = 0;

                        requestCourse.LoginEMPCode = request.UserName;

                        requestCourse.currentRole = request.CurrentRole;

                        requestCourse.GetMode = 1;

                        DataTable dtCourseCount = new DataTable();

                        ResponseClass responseCourse = new ResponseClass();


                        responseCourse = _coursemasterBL.ManageCourseMasterPaging(requestCourse);

                        if (responseCourse.responseCode == 1)
                        {
                            dtCourseCount = responseCourse.dtresponse;

                            courseCount = dtCourseCount.Rows.Count;
                        }

                        dtEmployees.Rows[0]["totalcourse"] = courseCount;


                        // get count of video

                        int videoCount = 0;

                        // videoCount = getVideoCount(request.CurrentRole, request.UserName, request.UserCompany, dtCompanies);

                        //videoCount=

                        manageVideoMasterrequestDTO requestVideo = new manageVideoMasterrequestDTO();

                        requestVideo.UserCompany= request.UserCompany;

                        requestVideo.PageNumber = 0;

                        requestVideo.LoginEMPCode= request.UserName;

                        requestVideo.currentRole   = request.CurrentRole;

                        requestVideo.GetMode = 1;

                        DataTable dtVideoCount = new DataTable();

                        ResponseClass responseVideo = new ResponseClass();


                        responseVideo = _videomasterBL.ManageVideoMasterPaging(requestVideo);

                        if (responseVideo.responseCode==1)
                        {
                            dtVideoCount = responseVideo.dtresponse;

                            videoCount = dtVideoCount.Rows.Count;
                        }




                        dtEmployees.Rows[0]["totalvideo"] = videoCount;

                       // response.responseJSON = JsonConvert.SerializeObject(dtEmployees);


                        // get count of program

                        int programCount = 0;

                        ProgramMasterDTO requestProgram = new ProgramMasterDTO();

                        requestProgram.CurrentRoleCompany = request.UserCompany;

                        requestProgram.PageNumber = 0;

                        requestProgram.CreatedBy = request.UserName;

                        requestProgram.CurrentRole = request.CurrentRole;

                        requestProgram.GetMode = 1;

                        DataTable dtProgramCount = new DataTable();

                        ResponseClass responseProgram = new ResponseClass();


                        responseProgram = _programmasterBL.ManageProgramMasterPaging(requestProgram);

                        if (responseProgram.responseCode == 1)
                        {
                            dtProgramCount = responseProgram.dtresponse;

                            programCount = dtProgramCount.Rows.Count;
                        }

                        //programCount = getProgramCount(request.CurrentRole, request.UserName, request.UserCompany, dtCompanies);

                        dtEmployees.Rows[0]["totalmanageprogram"] = programCount;

                        //response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        // get count of expressevent

                        int eventCount = 0;

                        //eventCount = getExpressEventCount(request.CurrentRole, request.UserName, request.UserCompany, dtCompanies);

                        manageEventrequestDTO requestEvent = new manageEventrequestDTO();

                        requestEvent.UserCompany = request.UserCompany;

                        requestEvent.PageNumber = 0;

                        requestEvent.LoginEMPCode = request.UserName;

                        requestEvent.CurrentRole = request.CurrentRole;

                        requestEvent.GetMode = 1;

                        DataTable dtEventCount = new DataTable();

                        ResponseClass responseEvent = new ResponseClass();


                        responseEvent = GetExpressEventListView(requestEvent);

                        if (responseEvent.responseCode == 1)
                        {
                            dtEventCount = responseEvent.dtresponse;

                            eventCount = dtEventCount.Rows.Count;
                        }

                        dtEmployees.Rows[0]["totalexpressevent"] = eventCount;


                        // get count of classroom

                        int classroomCount = 0;

                        manageClassRoomrequestDTO requestClassRoom = new manageClassRoomrequestDTO();

                        requestClassRoom.UserCompany = request.UserCompany;

                        requestClassRoom.PageNumber = 0;

                        requestClassRoom.LoginEMPCode = request.UserName;

                        requestClassRoom.LoginEMPRole = request.CurrentRole;

                        requestClassRoom.GetMode = 1;

                        DataTable dtClassRoomCount = new DataTable();

                        ResponseClass responseClassRoom = new ResponseClass();


                        responseClassRoom = _classroomtrainingBL.GetClassRoomListView(requestClassRoom);

                        if (responseClassRoom.responseCode == 1)
                        {
                            dtClassRoomCount = responseClassRoom.dtresponse;

                            classroomCount = dtClassRoomCount.Rows.Count;
                        }

                        //classroomCount = getClassRoomCount(request.CurrentRole, request.UserName, request.UserCompany, dtCompanies);

                        dtEmployees.Rows[0]["totalclassroom"] = classroomCount;


                        // total training group

                        // totaltraininggroup

                        int traininggroupCount = 0;

                        // videoCount = getVideoCount(request.CurrentRole, request.UserName, request.UserCompany, dtCompanies);

                        //videoCount=

                        manageTrainingGrouprequestDTO requesttraininggroup = new manageTrainingGrouprequestDTO();

                        requesttraininggroup.UserCompany = request.UserCompany;

                        requesttraininggroup.PageNumber = 0;

                        requesttraininggroup.LoginEMPCode = request.UserName;

                        requesttraininggroup.currentRole = request.CurrentRole;

                        requesttraininggroup.GetMode = 1;

                        DataTable dtTrainingGroupCount = new DataTable();

                        ResponseClass responseTrainingGroup = new ResponseClass();


                        responseTrainingGroup = _traininggroupBL.ManageTrainingGroupPaging(requesttraininggroup);

                        if (responseTrainingGroup.responseCode == 1)
                        {
                            dtTrainingGroupCount = responseTrainingGroup.dtresponse;

                            traininggroupCount = dtTrainingGroupCount.Rows.Count;
                        }




                        dtEmployees.Rows[0]["totaltraininggroup"] = traininggroupCount;



                        dtEmployees.Columns.Add("totalgamification");
                        dtEmployees.Columns.Add("totalvisitgamification");
                        dtEmployees.Columns.Add("totalaveragegamification");
                        try
                        {
                            if (request.CurrentRole == "Geo Admin")
                            {
                                getparticipantgamificationscoreDTO getCount = new getparticipantgamificationscoreDTO();
                                getCount.EmployeeCode = request.UserName;

                               
                                DataTable dtgamificationcount = new DataTable();

                                dtgamificationcount = _schedulerBL.getAdminGamificationCount(getCount);
                                if (dtgamificationcount!=null && dtgamificationcount.Rows.Count>0)
                                {
                                    dtEmployees.Rows[0]["totalgamification"] = Convert.ToInt32(dtgamificationcount.Rows[0]["creationCount"]);
                                    dtEmployees.Rows[0]["totalvisitgamification"] = Convert.ToInt32(dtgamificationcount.Rows[0]["total_visits"]);
                                    dtEmployees.Rows[0]["totalaveragegamification"] = Convert.ToInt32(dtgamificationcount.Rows[0]["avg_visits_per_day"]);
                                }
                            }
                            else
                            {
                                dtEmployees.Rows[0]["totalgamification"] = Convert.ToInt32(0);
                                dtEmployees.Rows[0]["totalvisitgamification"] = Convert.ToInt32(0);
                                dtEmployees.Rows[0]["totalaveragegamification"] = Convert.ToInt32(0);
                            }
                        }
                        catch (Exception)
                        {

                            
                        }
                        


                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAdminDashboardcount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetProgramManagerToDo(getadmindashboardcount request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

                string companycode = string.Empty;
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_program_manager_todo
                                                                        ( 
                                                                            :p_username,
                                                                            :p_currentrole
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();


                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetProgramManagerToDo", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetEntityDescription(getEntityDescription request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                string selectQuery = string.Empty;
                selectQuery = "select #ClassRoomTitle# as entityname from #CourseMaster#  where #CourseCode#='" + request.entityCode + "'  ";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEntityDescription", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public static DateTime ConvertTimeZone(DateTime Time, string Zone)
        {
            // Jamaica - EST
            // USA - EST
            // Canada - EST
            // Philipines - EST
            // Colombia - COT
            // India - EST
            // W. Australia Standard Time
            Zone = "EST";
            if (Zone == "EST")
            {
                TimeZoneInfo timeZone2 = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                TimeZoneInfo timeZone1 = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                DateTime newTime = TimeZoneInfo.ConvertTime(Time, timeZone1, timeZone2);

                //var utc = DateTime.UtcNow;
                //TimeZoneInfo ist = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                //DateTime istTime = TimeZoneInfo.ConvertTime(Time, ist);
                return newTime;
            }
            else if (Zone == "PST")
            {
                var utc = DateTime.UtcNow;
                TimeZoneInfo easternZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                DateTime easternTime = TimeZoneInfo.ConvertTime(Time, easternZone);
                return easternTime;
            }
            else if (Zone == "COT")
            {
                var utc = DateTime.UtcNow;
                TimeZoneInfo easternZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                DateTime istTime = TimeZoneInfo.ConvertTime(Time, easternZone);
                return istTime;
            }
            else
            {
                return Time;
            }
            //DateTime timeUtc = Convert.ToDateTime(Time);

        }

        public ResponseClass GetReportEvent(manageEventrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable expressEvent = new DataTable();
                string selectQuery = string.Empty;
                //selectQuery = "select A.#EventCode# as valuefield,A.#EventName# as displayfield ";

                //selectQuery = selectQuery + " from #EventMaster# A inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                //selectQuery = selectQuery + " where (A.#DeletedFlag#)=0 and A.#EventSource#='1'   ";

                selectQuery = selectQuery + " select PR.*from(  ";
                selectQuery = selectQuery + "  select A.#EventCode# as valuefield, A.#EventName# as displayfield, A.#InsertedDateTime# as createddate, A.#InsertedBy# as createdby,EM.#COMPANY_CODE# as cccode ";


                selectQuery = selectQuery + "  from #EventMaster# A  ";


                selectQuery = selectQuery + "  inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE#  ";


                selectQuery = selectQuery + "  where(A.#DeletedFlag#) = 0 and A.#EventSource# = '1' and A.#IsPublished#=1 ";


                selectQuery = selectQuery + "   union all  ";


                selectQuery = selectQuery + "   select A.#ProcessTrainingCode# as valuefield, A.#TrainingName# as displayfield, A.#CreatedOn# as createddate, A.#CreatedBy# as createdby,EM.#COMPANY_CODE# as cccode ";


                selectQuery = selectQuery + "   from #ProcessTrainingMaster# A  ";


                selectQuery = selectQuery + "   inner join #EmployeeMaster# EM on A.#CreatedBy# = EM.#EXTERNALDATAREFERENCE#  ";


                selectQuery = selectQuery + "    where(A.#DeletedFlag#) = 0  ";
                selectQuery = selectQuery + "  ) PR  ";



                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                    selectQuery = selectQuery + " where PR.#createdby#='" + request.LoginEMPCode + "'";
                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " where PR.#cccode# in (" + companiestopass + ")";

                    }
                }
                //else if (request.CurrentRole == "Participant")
                //{
                //    selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";
                //}

                //if (request.CallingSource == "Report")
                //{
                //    selectQuery = selectQuery + " and A.#IsPublished#=1 ";
                //}

               

              //  selectQuery = selectQuery + " order by  A.#InsertedDateTime# desc";

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(expressEvent);
                npgsql.Close();
                response.responseCode = 1;

               
                response.responseJSON = JsonConvert.SerializeObject(expressEvent);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetReportEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }


        #region  DASHBOARD COUNT
        public ResponseClass eventdashboardCount(eventdashboardCountrequetDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_event_dashboard_count
                                                                        ( 
                                                                            :p_eventcode,
                                                                            :p_eventtype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.EventType))
                            cmd.Parameters.AddWithValue("p_eventtype", DbType.String).Value = request.EventType;
                        else
                            cmd.Parameters.AddWithValue("p_eventtype", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("eventdashboardCount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass eventtaskProgress(eventdashboardCountrequetDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_event_task_progress
                                                                        ( 
                                                                            :p_eventcode,
                                                                            :p_eventtype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.EventType))
                            cmd.Parameters.AddWithValue("p_eventtype", DbType.String).Value = request.EventType;
                        else
                            cmd.Parameters.AddWithValue("p_eventtype", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                            
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("eventdashboardCount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass eventdashboarddetails(eventdashboardCountrequetDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
               // string selectQuery = string.Empty;
                if (request.EventType == "Video")
                {
                    //selectQuery = "select concat(C.#FIRSTNAME#,'(',B.#EmployeeCode#,')') as employeecode,C.#DEPARTMENT# AS department,C.#GRADE# AS grade,A.#AcknowledgedStatus# as acknowledgedstatus,A.#ContentText# as contentname,COALESCE((select COALESCE(#WIPStatus#,0) as wipstatus from #BusinessLearningEmployeeActivity# where #LearningDetailID#=A.#TID# and #WIPStatus#=1),0) as wipstatus from #BusinessTrainingEmpLearningDetails# A inner join #BusinessTrainingAllocation# B on B.#TID#=A.#AllocationID#  inner join #EmployeeMaster# C on B.#EmployeeCode#=C.#EXTERNALDATAREFERENCE#  where B.#EventCode#='" + request.EventCode + "'";
                }
                if (request.EventType == "Survey")
                {
                    //selectQuery = "select concat(C.#FIRSTNAME#,'(',B.#EmployeeCode#,')') as employeecode,C.#DEPARTMENT# AS department,C.#GRADE# AS grade,A.#AcknowledgedStatus# as acknowledgedstatus,A.#ContentText# as contentname,COALESCE((select COALESCE(#WIPStatus#,0) as wipstatus from #BusinessLearningEmployeeActivity# where #LearningDetailID#=A.#TID# and #WIPStatus#=1),0) as wipstatus,cast(TO_CHAR(B.#StartDate#, 'dd-Mon-yy') as character varying) as startdate,cast(TO_CHAR(B.#EndDate#, 'dd-Mon-yy') as character varying) as enddate, (cast(A.#LearningEndDate# as timestamp) - cast(A.#LearningStartDate# as timestamp)) AS difference,A.#TotalQuestion# as totalquestion,A.#TotalSubmitted# as totalsubmitted  from #BusinessTrainingEmpLearningDetails# A inner join #BusinessTrainingAllocation# B on B.#TID#=A.#AllocationID#  inner join #EmployeeMaster# C on B.#EmployeeCode#=C.#EXTERNALDATAREFERENCE#  where B.#EventCode#='" + request.EventCode + "'";
                }
                if (request.EventType == "Assessment")
                {
                    //selectQuery = selectQuery + " select PR.*,";
                    //selectQuery = selectQuery + "(select count(*) from #EmployeeAssessmentResultDetails# ";
                    //selectQuery = selectQuery + "  where #AssessmentScheduleID# = PR.#AssessmentScheduleID# and #ESource#='BT') ";
                    //selectQuery = selectQuery + "  as totalquestions, ";
                    //selectQuery = selectQuery + "  (select count(*) from #EmployeeAssessmentResultDetails# ";
                    //selectQuery = selectQuery + "   where #AssessmentScheduleID# = PR.#AssessmentScheduleID# and #isCorrect# = 1 and #ESource#='BT') ";
                    //selectQuery = selectQuery + "  as totalcorrect ";
                    //selectQuery = selectQuery + "  from ";

                    //selectQuery = selectQuery + "  (select concat(C.#FIRSTNAME#, '(', B.#EmployeeCode#, ')') as employeecode, ";
                    //selectQuery = selectQuery + "  C.#DEPARTMENT# AS department, C.#GRADE# AS grade, ";
                    //selectQuery = selectQuery + "   A.#AcknowledgedStatus# as acknowledgedstatus,A.#IsLastAttempt# as failedattempt, ";
                    //selectQuery = selectQuery + "  A.#ContentText# as contentname, ";
                    //selectQuery = selectQuery + "  COALESCE((select COALESCE(#WIPStatus#, 0) as wipstatus from #BusinessLearningEmployeeActivity# where #LearningDetailID# = A.#TID# and #WIPStatus# = 1), 0) as wipstatus, ";
                    //selectQuery = selectQuery + "  (select #AssessmentScheduleID# from #ModuleAssessmentAllocationBusiness# ";
                    //selectQuery = selectQuery + "   where #ModuleAllocationID# = A.#TID# order by #ModuleAssessmentAllocationID# desc limit 1) ";
                    //selectQuery = selectQuery + "  from #BusinessTrainingEmpLearningDetails# A ";
                    //selectQuery = selectQuery + "  inner join #BusinessTrainingAllocation# B on B.#TID# = A.#AllocationID# ";
                    //selectQuery = selectQuery + " inner join #EmployeeMaster# C on B.#EmployeeCode# = C.#EXTERNALDATAREFERENCE# ";
                    //selectQuery = selectQuery + "  where B.#EventCode# = '" + request.EventCode + "') PR ";
                    
                }
                if (request.EventType == "Course")
                {
                   // selectQuery = "select concat(C.#FIRSTNAME#,'(',B.#EmployeeCode#,')') as employeecode,C.#DEPARTMENT# AS department,C.#GRADE# AS grade,A.#AcknowledgedStatus# as acknowledgedstatus,A.#ContentText# as contentname,COALESCE((select COALESCE(#WIPStatus#,0) as wipstatus from #BusinessLearningEmployeeActivity# where #LearningDetailID#=A.#TID# and #WIPStatus#=1),0) as wipstatus,cast(TO_CHAR(B.#StartDate#, 'dd-Mon-yy') as character varying) as startdate,case when A.#AcknowledgedStatus#=1 then coalesce(TO_CHAR(cast(A.#LearningEndDate# as date), 'dd-Mon-yy'),TO_CHAR(cast(A.#AcknowledgedTime# as date), 'dd-Mon-yy')) else '' end as enddate from #BusinessTrainingEmpLearningDetails# A inner join #BusinessTrainingAllocation# B on B.#TID#=A.#AllocationID#  inner join #EmployeeMaster# C on B.#EmployeeCode#=C.#EXTERNALDATAREFERENCE#  where B.#EventCode#='" + request.EventCode + "'";
                    
                }




                // selectQuery = selectQuery.Replace('#', '"');

                //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                //npgsql.Open();

                //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                //dataAdapter.Fill(dtEmployees);

                // npgsql.Close();

                if (request.EventType == "Video" ||  request.EventType == "Course" || request.EventType == "Survey")
                {
                    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_event_dashboard_detail_video
                                                                        ( 
                                                                            :p_eventcode,
                                                                            :p_eventtype,:p_pageno,:p_recordno
                                                                        )", npgsqlConnection))
                        {
                            cmd.CommandType = CommandType.Text; //
                            if (!String.IsNullOrEmpty(request.EventCode))
                                cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                            else
                                cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;
                            if (!String.IsNullOrEmpty(request.EventType))
                                cmd.Parameters.AddWithValue("p_eventtype", DbType.String).Value = request.EventType;
                            else
                                cmd.Parameters.AddWithValue("p_eventtype", DbType.String).Value = DBNull.Value;

                            cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                            cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;


                            npgsqlConnection.Open();

                            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                            dataAdapter.Fill(dtEmployees);
                            npgsqlConnection.Close();

                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                    }
                }
                
                else if (request.EventType == "Assessment")
                {
                    using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                    {
                        using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_event_dashboard_detail_assessment
                                                                        ( 
                                                                            :p_eventcode,
                                                                            :p_eventtype,:p_pageno,:p_recordno
                                                                        )", npgsqlConnection))
                        {
                            cmd.CommandType = CommandType.Text; //
                            if (!String.IsNullOrEmpty(request.EventCode))
                                cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                            else
                                cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;
                            if (!String.IsNullOrEmpty(request.EventType))
                                cmd.Parameters.AddWithValue("p_eventtype", DbType.String).Value = request.EventType;
                            else
                                cmd.Parameters.AddWithValue("p_eventtype", DbType.String).Value = DBNull.Value;

                            cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                            cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;


                            npgsqlConnection.Open();

                            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                            dataAdapter.Fill(dtEmployees);
                            npgsqlConnection.Close();

                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                    }
                }

               

                if (dtEmployees!=null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    int recordcount = 1;
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                        if (request.PageNumber != -1)
                        {
                            

                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                }

                

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("eventdashboarddetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass eventdashboarddetailsassessment(eventdashboardCountrequetDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_event_assessment_dashboard_list
                                                                    ( 
                                                                        :p_eventcode,:p_pageno,:p_recordno
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.EventCode))
                        cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                    else
                        cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;

                    cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                    cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;


                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                   
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null)
                        {
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                            int recordcount = 1;
                            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                            {
                                recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                                if (request.PageNumber != -1)
                                {


                                    decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                                    int recordPages = Convert.ToInt32(noOfPages);

                                    if (noOfPages > recordPages)
                                    {
                                        recordPages = recordPages + 1;
                                    }

                                    response.recordCount = recordPages;
                                }
                            }
                        }
                    }
                    
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

        public ResponseClass insertWIPrequest(insertWIPrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {
                if (string.IsNullOrEmpty(request.PrimaryID))
                {
                    response.responseCode = 0;
                    response.responseMessage = "PrimaryID required!";
                    return response;
                }

                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_employee_learning_activity
                                                                        ( 
                                                                            :p_primary
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.PrimaryID))
                            cmd.Parameters.AddWithValue("p_primary", DbType.String).Value = request.PrimaryID;
                        else
                            cmd.Parameters.AddWithValue("p_primary", DbType.String).Value = DBNull.Value;
                       
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        if (dtEmployees!=null && dtEmployees.Rows.Count>0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);
                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

               
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertWIPrequest", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass insertWIPOptedrequest(insertWIPrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_employee_learning_opted
                                                                ( 
                                                                    :p_primary,:p_eventcode,:p_employeecode,
                                                                    :p_action
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.PrimaryID))
                            cmd.Parameters.AddWithValue("p_primary", DbType.String).Value = request.PrimaryID;
                        else
                            cmd.Parameters.AddWithValue("p_primary", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EmployeeCode))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertWIPrequest", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        #endregion

        public ResponseClass GetTeamLeadPendingTask(TeamLeadPendingTaskDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

                string teamMembers = string.Empty;
                DataTable dtEmployees = new DataTable();
                
                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                string selectQuery = string.Empty;

                // first get team member

                getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                getteam.EmployeeCode = request.employeeCode;
                var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                {
                    foreach (DataRow exclude in QualtricTeamMembers.Rows)
                    {
                        teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                    }

                    teamMembers = teamMembers.TrimEnd(',');

                }

                selectQuery = "select EM.#EXTERNALDATAREFERENCE# AS empcode,";
                selectQuery = selectQuery + " concat(EM.#FIRSTNAME#, ' ', EM.#LASTNAME#) as empname,coalesce(pending.pendingcount,0) as totalpendingtask,EM.#Manager_1# as prcode,EM.#Manager_1_Name# as prname,";
                selectQuery = selectQuery + " coalesce(UM.#ProfilePIC#, '') as profilepic";
                selectQuery = selectQuery + " from #EmployeeMaster# EM";
                selectQuery = selectQuery + " left join #UserMaster# UM on UM.#EmployeeID# =EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " left join";
                selectQuery = selectQuery + " (";
                selectQuery = selectQuery + "   select BTA.#EmployeeCode#,count(BTAD.#TID#) as pendingcount";
                selectQuery = selectQuery + "    from #BusinessTrainingAllocation# BTA";
                selectQuery = selectQuery + "    inner join #BusinessTrainingEmpLearningDetails# BTAD on BTA.#TID# = BTAD.#AllocationID#";
                selectQuery = selectQuery + "    inner join #EventMaster# EM on EM.#EventCode# = BTA.#EventCode#";
                selectQuery = selectQuery + "   where (BTAD.#AcknowledgedStatus# = 0 and BTAD.#IsLastAttempt#=0) and  cast(concat(BTA.#ServerStartDate#,' ',coalesce(BTA.#ServerStartTime#,'00:00:00')) as timestamp)<=now()";

                selectQuery = selectQuery + " and cast(concat(BTA.#ServerEndDate#,' ',coalesce(BTA.#ServerEndTime#, '23:59:59')) as timestamp)>= now()";

                selectQuery = selectQuery + " and EM.#AcknowledgeRequired# = 1";
               // selectQuery = selectQuery + "   and(cast(concat(BTA.#ServerStartDate#, ' ', coalesce(BTA.#ServerStartTime#, '01:01:01')) as timestamp) <= now()";
               // selectQuery = selectQuery + "   and cast(concat(BTA.#ServerEndDate#, ' ', coalesce(BTA.#ServerEndTime#, '23:59:59')) as timestamp) >= now())";
                selectQuery = selectQuery + "   group by BTA.#EmployeeCode#";


                selectQuery = selectQuery + " )pending on pending.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE#";
                if (!string.IsNullOrEmpty(teamMembers))
                {
                    selectQuery = selectQuery + " where EM.#EXTERNALDATAREFERENCE# in (" + teamMembers + ")";
                }

                selectQuery = selectQuery + " order by EM.#FIRSTNAME#";

                selectQuery = selectQuery.Replace('#', '"');

                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();


                response.responseCode = 1;
                response.responseMessage = "Success";
                if (dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetTeamLeadPendingTask", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetTeamLeadEmployeePendingTaskList(TeamLeadPendingTaskDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

                string teamMembers = string.Empty;
                DataTable dtEmployees = new DataTable();

                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                string selectQuery = string.Empty;

                selectQuery = selectQuery + " select concat(C.#FIRSTNAME#,' (',BTA.#EmployeeCode#,')') as employeecode,";
                selectQuery = selectQuery + "  case when BTA.#ClassRoomCode# is not null then 'Class' else 'Event' end as LearningType,";
                selectQuery = selectQuery + "  case when BTA.#ClassRoomCode# is not null then CRM.#ClassRoomTitle# else EM.#EventName# end as ccname,";
                selectQuery = selectQuery + "  EM.#EventType# as eventtype,BTAD.#ContentText# as assetname,";
                selectQuery = selectQuery + "  case when (BTAD.#AcknowledgedStatus# = 1 or BTAD.#IsLastAttempt#=1) then 'Completed' else 'Pending' end as asseststatus,";
                selectQuery = selectQuery + "  case when cast(concat(BTA.#ServerEndDate#,' ',coalesce(BTA.#ServerEndTime#,'23:59:59')) as timestamp)<now() then 'Yes' else 'No' end as expired";
                selectQuery = selectQuery + "  from #BusinessTrainingAllocation# BTA";
                selectQuery = selectQuery + "  inner join #BusinessTrainingEmpLearningDetails# BTAD on BTA.#TID# = BTAD.#AllocationID#";
                selectQuery = selectQuery + "  inner join #EmployeeMaster# C on BTA.#EmployeeCode# = C.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + "  inner join #EventMaster# EM on EM.#EventCode# = BTA.#EventCode#";
                selectQuery = selectQuery + "  left join #ClassRoomTraining# CRM on CRM.#ClassRoomCode# = BTA.#ClassRoomCode#";
                selectQuery = selectQuery + "  where";
                selectQuery = selectQuery + "    EM.#AcknowledgeRequired# = 1 and BTA.#EmployeeCode# = '" + request.employeeCode + "' order by BTA.#ServerEndDate# desc";

                //and (cast(concat(BTA.#ServerStartDate#,' ',coalesce(BTA.#ServerStartTime#,'00:00:00')) as timestamp)<=now() and cast(concat(BTA.#ServerEndDate#,' ',coalesce(BTA.#ServerEndTime#, '23:59:59')) as timestamp)>= now()) and



                selectQuery = selectQuery.Replace('#', '"');

                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();


                response.responseCode = 1;
                response.responseMessage = "Success";
                if (dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetTeamLeadEmployeePendingTaskList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetTotalPendingActivity(TeamLeadPendingTaskDTO request)
        {

            ResponseClass response = new ResponseClass();

            //if (pRReportRequestDTO.PageNumber == 0)
            //{
            //    pRReportRequestDTO.PageNumber = 1;
            //}

            //if (pRReportRequestDTO.RowsOfPage == 0)
            //{
            //    pRReportRequestDTO.PageNumber = 20;
            //}

            try
            {

                string teamMembers = string.Empty;
                DataTable dtEmployees = new DataTable();

                string pgsqlConnection = appSettings.Value.DbConnection;

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                string selectQuery = string.Empty;
                if (request.picktype != "count")
                {
                    selectQuery = selectQuery + " select concat(C.#FIRSTNAME#,' (',BTA.#EmployeeCode#,')') as employeecode,";
                    selectQuery = selectQuery + "  case when BTA.#ClassRoomCode# is not null then 'Class' else 'Event' end as LearningType,";
                    selectQuery = selectQuery + "  case when BTA.#ClassRoomCode# is not null then CRM.#ClassRoomTitle# else EM.#EventName# end as ccname,";
                    selectQuery = selectQuery + "  EM.#EventType# as eventtype,BTAD.#ContentText# as assetname,";
                    selectQuery = selectQuery + "  case when (BTAD.#AcknowledgedStatus# = 1 or BTAD.#IsLastAttempt#=1) then 'Completed' else 'Pending' end as asseststatus,";
                    selectQuery = selectQuery + "  case when cast(concat(BTA.#ServerEndDate#,' ',coalesce(BTA.#ServerEndTime#,'23:59:59')) as timestamp)<now() then 'Yes' else 'No' end as expired";
                }
                else
                {
                    selectQuery = " select count(*) as totalpendingtask";
                }
               
                
                selectQuery = selectQuery + "  from #BusinessTrainingAllocation# BTA";
                selectQuery = selectQuery + "  inner join #BusinessTrainingEmpLearningDetails# BTAD on BTA.#TID# = BTAD.#AllocationID#";
                selectQuery = selectQuery + "  inner join #EmployeeMaster# C on BTA.#EmployeeCode# = C.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + "  inner join #EventMaster# EM on EM.#EventCode# = BTA.#EventCode#";
                selectQuery = selectQuery + "  left join #ClassRoomTraining# CRM on CRM.#ClassRoomCode# = BTA.#ClassRoomCode#";
                selectQuery = selectQuery + "  where";
                selectQuery = selectQuery + "  EM.#AcknowledgeRequired# = 1  and (BTAD.#AcknowledgedStatus# = 0 and BTAD.#IsLastAttempt#=0)";

                if (!string.IsNullOrEmpty(request.searchbyempcode))
                {
                    selectQuery = selectQuery + " and BTA.#EmployeeCode#='" + request.searchbyempcode + "'";
                }

                //and (cast(concat(BTA.#ServerStartDate#,' ',coalesce(BTA.#ServerStartTime#,'00:00:00')) as timestamp)<=now() and cast(concat(BTA.#ServerEndDate#,' ',coalesce(BTA.#ServerEndTime#, '23:59:59')) as timestamp)>= now()) and

                string companiestopass = string.Empty;
                if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.employeeCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        selectQuery = selectQuery + " and C.#COMPANY_CODE# in (" + companiestopass + ")";

                    }
                }
                else if (request.CurrentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.employeeCode;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }

                    if (!string.IsNullOrEmpty(teamMembers))
                    {
                        selectQuery = selectQuery + " and C.#EXTERNALDATAREFERENCE# in (" + teamMembers + ")";
                    }
                }

           
                if (request.picktype != "count")
                {
                    selectQuery = selectQuery + " order by BTA.#EmployeeCode#,BTA.#ServerEndDate# desc";


                }
                    
                selectQuery = selectQuery.Replace('#', '"');

                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();


                response.responseCode = 1;
                response.responseMessage = "Success";
                if (dtEmployees != null)
                {
                    if (request.picktype!="count")
                    {
                        //if (request.PageNumber != -1)
                        //{
                           

                        //    decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / pRReportRequestDTO.RowsOfPage));

                        //    int recordPages = Convert.ToInt32(noOfPages);

                        //    if (noOfPages > recordPages)
                        //    {
                        //        recordPages = recordPages + 1;
                        //    }

                        //    response.recordCount = recordPages;
                        //}

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                    else
                    {
                        response.dtresponse = dtEmployees;
                    }
                    
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetTotalPendingActivity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public DataTable getMembers(getadmindashboardcount request)
        {
            DataTable dtmembers = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;

            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

            string selectQuery = string.Empty;

            string companiestopass = string.Empty;

            selectQuery = "select count(*) as membercount from #EmployeeMaster# where #Active_Separated#='Active'";

            if (request.CurrentRole=="Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.UserName);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    }

                    companiestopass = companiestopass.TrimEnd(',');

                    selectQuery = selectQuery + " and #COMPANY_CODE# in (" + companiestopass + ")";

                }
            }
           

            selectQuery = selectQuery.Replace('#', '"');

            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(dtmembers);
            npgsql.Close();

            return dtmembers;

        }

        public ResponseClass GetTotalPendingActivityPaging(TeamLeadPendingTaskDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string companiestopass = string.Empty;
                string teamMembers = string.Empty;
                List<string> p_teammember = new List<string>();

                if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.employeeCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                       

                    }
                }
                else if (request.CurrentRole == "Team Lead")
                {
                    getTeamMembersRequestDTO getteam = new getTeamMembersRequestDTO();
                    getteam.EmployeeCode = request.employeeCode;
                    var QualtriData = _qualtricsBL.GetTeamMembers(getteam);
                    DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                    if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in QualtricTeamMembers.Rows)
                        {
                            teamMembers = teamMembers + "" + Convert.ToString(exclude["EmployeeID"]) + ",";
                        }

                        teamMembers = teamMembers.TrimEnd(',');

                    }

                    //if (!string.IsNullOrEmpty(teamMembers))
                    //{
                        
                    //    if (!String.IsNullOrEmpty(teamMembers))
                    //    {

                    //        var v_role = teamMembers.Split(",").ToList();
                    //        p_teammember = v_role.Select(x => x.Trim()).ToList();
                    //    }
                    //    else
                    //    {
                    //        p_teammember.Add("");
                    //    }
                    //}
                    
                }


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_total_pending_task
                                                                        ( 
                                                                            :p_username,
                                                                            :p_current_role,:p_searchempcode,:p_pageno,:p_recordno,:p_company,:p_teammember
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.employeeCode))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.employeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_current_role", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_current_role", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.searchbyempcode))
                            cmd.Parameters.AddWithValue("p_searchempcode", DbType.String).Value = request.searchbyempcode;
                        else
                            cmd.Parameters.AddWithValue("p_searchempcode", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        if (!String.IsNullOrEmpty(companiestopass))
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = companiestopass;
                        else
                            cmd.Parameters.AddWithValue("p_company", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(teamMembers))
                            cmd.Parameters.AddWithValue("p_teammember", DbType.String).Value = teamMembers;
                        else
                            cmd.Parameters.AddWithValue("p_teammember", DbType.String).Value = string.Empty;

                       



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        int recordcount = 1;
                        if (dtEmployees!=null && dtEmployees.Rows.Count>0)
                        {
                            recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                            if (request.PageNumber != -1)
                            {
                                //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                                decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                                int recordPages = Convert.ToInt32(noOfPages);

                                if (noOfPages > recordPages)
                                {
                                    recordPages = recordPages + 1;
                                }

                                response.recordCount = recordPages;
                            }
                        }
                        
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAgntHomePage", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetRequisitionUsers(RequestionDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtmembers = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;

            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

            string selectQuery = string.Empty;

            string companiestopass = string.Empty;

            selectQuery = "select #EXTERNALDATAREFERENCE#,#FIRSTNAME#,#LASTNAME#,#Official_Email#,#DEPARTMENT#,#Company_Name# from #EmployeeMaster# where #Active_Separated#='Active' and #RMS_Requisition_Id# = '@RMS_Requisition_Id' order by #FIRSTNAME# ";

            selectQuery = selectQuery.Replace("@RMS_Requisition_Id", request.RequisitionNumber);
            selectQuery = selectQuery.Replace('#', '"');

            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(dtmembers);
            npgsql.Close();

            response.responseJSON = JsonConvert.SerializeObject(dtmembers);
            response.responseCode = 1;
            response.responseMessage = "Success";

            return response;

        }

        public string getEventType(string eventCode)
        {
            string EventType = string.Empty;

            //ResponseClass response = new ResponseClass();
            DataTable dtmembers = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;

            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

            string selectQuery = string.Empty;

            string companiestopass = string.Empty;

            selectQuery = "select #EventType# from #EventMaster# where  #EventCode# ='" + eventCode + "'";

            //selectQuery = selectQuery.Replace("@RMS_Requisition_Id", request.RequisitionNumber);
            selectQuery = selectQuery.Replace('#', '"');

            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(dtmembers);
            if (dtmembers!=null && dtmembers.Rows.Count>0)
            {
                EventType = Convert.ToString(dtmembers.Rows[0]["EventType"]);
            }
            npgsql.Close();

          //  response.responseJSON = JsonConvert.SerializeObject(dtmembers);
           // response.responseCode = 1;
           // response.responseMessage = "Success";

            return EventType;

        }

        public DataTable insertProgramSurvey(insertEditEventRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable expressEvent = new DataTable();

            try
            {

                string selectQuery = string.Empty;

                //  selectQuery = "select A.#ContentCode#,A.#ContentText#,B.#ServerStartDate# as EventStartDate,B.#ServerEndDate# as EventEndDate,B.#ServerStartTime# as EventStartTime,B.#ServerEndTime# as EventEndTime from #EventContent# A inner join #EventMaster# B on A.#EventCode#=B.#EventCode# where B.#EventType#='Survey' and B.#EventCode#='" + request.EventCode + "'   ";
                selectQuery = "select A.#AssetDetailID#,A.#ContentCode# as ContentCode,A.#ContentText#,B.#ServerStartDate# as EventStartDate,B.#ServerEndDate# as EventEndDate,B.#ServerStartTime# as EventStartTime,B.#ServerEndTime# as EventEndTime from #EventProgramSurvey# A inner join #EventMaster# B on A.#EventCode#=B.#EventCode# where  A.#EventCode#='" + request.EventCode + "'";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(expressEvent);
                npgsql.Close();

                if (expressEvent != null && expressEvent.Rows.Count > 0)
                {
                    //get survey ID
                    expressEvent.Columns.Add("SurveyID");
                    foreach (DataRow item in expressEvent.Rows)
                    {
                        // call API
                        SurveyInsertRequestDTO srv = new SurveyInsertRequestDTO();
                        SurveyDetailsData res = new SurveyDetailsData();
                        srv.LoggedInEmployeeId = request.InsertedBy;
                        srv.TemplateId = Convert.ToString(item["ContentCode"]);
                        srv.TemplateName = Convert.ToString(item["ContentText"]);
                        DateTime fromDt = Convert.ToDateTime(item["EventStartDate"]);
                        DateTime toDt = Convert.ToDateTime(item["EventEndDate"]);


                        if (!string.IsNullOrEmpty(Convert.ToString(item["EventStartTime"])) && Convert.ToString(item["EventStartTime"]) != "0")
                        {
                            fromDt = Convert.ToDateTime(fromDt.ToString("yyyy-MM-dd") + " " + Convert.ToString(item["EventStartTime"]));

                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(item["EventEndTime"])) && Convert.ToString(item["EventEndTime"]) != "0")
                        {
                            fromDt = Convert.ToDateTime(fromDt.ToString("yyyy-MM-dd") + " " + Convert.ToString(item["EventEndTime"]));
                        }

                        srv.StartDate = fromDt;
                        srv.EndDate = toDt;

                        // srv.StartDate
                        string resData = _serviceconnect.insertSurveyInsert(srv);
                        res = JsonConvert.DeserializeObject<SurveyDetailsData>(resData);

                        if (res.status == true)
                        {
                            try
                            {
                                string sqlQuery = string.Empty;

                                npgsql.Open();
                                sqlQuery = "update #EventProgramSurvey# set #SurveyID#='" + res.data.SurveyId + "' where #EventCode#='" + request.EventCode + "' and #ContentCode#='" + srv.TemplateId + "' and #AssetDetailID#='" + Convert.ToString(item["AssetDetailID"]) + "'";
                                

                                sqlQuery = sqlQuery.Replace('#', '"');
                                // Define a command to call  procedure
                                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsql);
                                NpgsqlDataReader rdr = cmd.ExecuteReader();

                                npgsql.Close();

                                item["SurveyID"] = Convert.ToString(res.data.SurveyId);
                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("insertProgramSurvey", "1024", ex.Message, "Exception");
                                // return response;
                            }
                        }




                    }

                    response.responseCode = 1;
                    response.responseMessage = "SUCCESS";
                }


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("insertProgramSurvey", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            return expressEvent;
        }

        public int getCourseCount(string userRole,string userEMPCode,string userCompany,DataTable dtCompanies)
        {
            int resultCount = 0;
            DataTable dtResult = new DataTable();

            string selectQuery = string.Empty;

            try
            {
                selectQuery = "select count(CM.#CourseID#) as coursecount from #CourseMaster# CM inner join #EmployeeMaster# EM on CM.#CreatedBy# = EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " where  (CM.#DeletedFlag#)=0 ";
                if (userRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and (CM.#CreatedBy#='" + userEMPCode + "' or CM.#CurrentRole#='Global Admin' ";

                    selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + userCompany + "%' )) ";

                }
                else if (userRole == "Geo Admin")
                {
                    selectQuery = selectQuery + " and (CM.#CurrentRole#='Global Admin' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    selectQuery = selectQuery + " )";

                }

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);

                if (dtResult != null && dtResult.Rows.Count > 0)
                {

                    resultCount = Convert.ToInt32(dtResult.Rows[0]["coursecount"]);
                }
            }
            catch (Exception ex)
            {

                resultCount = 0;
            }

            return resultCount;

        }

        public int getVideoCount(string userRole, string userEMPCode, string userCompany, DataTable dtCompanies)
        {
            int resultCount = 0;
            DataTable dtResult = new DataTable();

            string selectQuery = string.Empty;

            try
            {
                selectQuery = "select count(CM.#VideoID#) as coursecount from #VideoMaster#  CM inner join #EmployeeMaster# EM on CM.#InsertedBy# = EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " where  (CM.#DeletedFlag#)=0 ";
                if (userRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and (CM.#InsertedBy#='" + userEMPCode + "' or CM.#CurrentRole#='Global Admin' ";

                    selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + userCompany + "%' )) ";

                }
                else if (userRole == "Geo Admin")
                {
                    selectQuery = selectQuery + " and (CM.#CurrentRole#='Global Admin' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    selectQuery = selectQuery + " )";

                }

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);

                if (dtResult != null && dtResult.Rows.Count > 0)
                {

                    resultCount = Convert.ToInt32(dtResult.Rows[0]["coursecount"]);
                }
            }
            catch (Exception ex)
            {

                resultCount = 0;
            }

            return resultCount;

        }

        public int getProgramCount(string userRole, string userEMPCode, string userCompany, DataTable dtCompanies)
        {
            int resultCount = 0;
            DataTable dtResult = new DataTable();

            string selectQuery = string.Empty;

            try
            {
                selectQuery = "select count(CM.#ProgramCode#) as coursecount from #ProgramMaster# CM inner join #EmployeeMaster# EM on CM.#CreatedBy# = EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " where  (CM.#DeletedFlag#)=0 ";
                if (userRole == "Program Manager")
                {
                      selectQuery = selectQuery + " and (CM.#CreatedBy#='" + userEMPCode + "' or CM.#CurrentRole#='Global Admin' ";

                    selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + userCompany + "%' )) ";
                    //selectQuery = selectQuery + " and CM.#CreatedBy#='" + userEMPCode + "' and CM.#CurrentRole#='" + userRole + "'";
                }
                else if (userRole == "Geo Admin")
                {
                    selectQuery = selectQuery + " and (CM.#CurrentRole#='Global Admin' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    selectQuery = selectQuery + " )";

                }

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);

                if (dtResult != null && dtResult.Rows.Count > 0)
                {

                    resultCount = Convert.ToInt32(dtResult.Rows[0]["coursecount"]);
                }
            }
            catch (Exception ex)
            {

                resultCount = 0;
            }

            return resultCount;

        }

        public int getExpressEventCount(string userRole, string userEMPCode, string userCompany, DataTable dtCompanies)
        {
            int resultCount = 0;
            DataTable dtResult = new DataTable();

            string selectQuery = string.Empty;

            try
            {
                selectQuery = "select count(CM.#EventCode#) as coursecount from #EventMaster#   CM inner join #EmployeeMaster# EM on CM.#InsertedBy# = EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " where  (CM.#DeletedFlag#)=0  and CM.#EventSource#='1'";
                if (userRole == "Program Manager")
                {
                    //  selectQuery = selectQuery + " and (CM.#InsertedBy#='" + userEMPCode + "' or CM.#CurrentRole#='Global Admin' ";

                    // selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + userCompany + "%' )) ";
                    selectQuery = selectQuery + " and CM.#InsertedBy#='" + userEMPCode + "' and #CurrentRole#='Program Manager'";
                }
                else if (userRole == "Geo Admin")
                {
                    selectQuery = selectQuery + " and (CM.#CurrentRole#='200009' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    selectQuery = selectQuery + " )";

                }

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);

                if (dtResult != null && dtResult.Rows.Count > 0)
                {

                    resultCount = Convert.ToInt32(dtResult.Rows[0]["coursecount"]);
                }
            }
            catch (Exception ex)
            {

                resultCount = 0;
            }

            return resultCount;

        }

        public int getClassRoomCount(string userRole, string userEMPCode, string userCompany, DataTable dtCompanies)
        {
            int resultCount = 0;
            DataTable dtResult = new DataTable();

            string selectQuery = string.Empty;

            try
            {
                selectQuery = "select count(*) as coursecount from #ClassRoomTraining#   CM inner join #EmployeeMaster# EM on CM.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                selectQuery = selectQuery + " where  (CM.#DeletedFlag#)=0 ";
                if (userRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and CM.#InsertedBy#='" + userEMPCode + "'";

                    // selectQuery = selectQuery + " and (CM.#InsertedBy#='" + userEMPCode + "' or CM.#CurrentRole#='Global Admin' ";

                    // selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + userCompany + "%' )) ";

                }
                else if (userRole == "Geo Admin")
                {
                    selectQuery = selectQuery + " and (CM.#CurrentRole#='200009' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Geo Admin' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    selectQuery = selectQuery + " )";

                }

                selectQuery = selectQuery + " or CM.#ClassRoomCode# in (select distinct PTB.#ClassRoomCode# from #ProcessTrainingInstructor# PTI inner join #ProcessTrainingMaster# PTB on PTB.#ProcessTrainingCode# = PTI.#ProcessTrainingCode# and PTB.#DeletedFlag# = 0 and PTI.#InstructorEmpCode#='" + userEMPCode + "')";

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
                npgsql.Close();
                NpgsqlConnection.ClearPool(npgsql);

                if (dtResult != null && dtResult.Rows.Count > 0)
                {

                    resultCount = Convert.ToInt32(dtResult.Rows[0]["coursecount"]);
                }
            }
            catch (Exception ex)
            {

                resultCount = 0;
            }

            return resultCount;

        }


        public ResponseClass EventPermanantDelete(eventdeleterequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_delete_event_data
                                                                        ( 
                                                                            :p_eventcode,:p_insertedby,:p_insertedipaddress
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertWIPrequest", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetEventAllocationCount(eventdeleterequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_event_employee_count
                                                                        ( 
                                                                            :p_objectcode,:p_objecttype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.ObjectType))
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = request.ObjectType;
                        else
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = DBNull.Value;

                       

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertWIPrequest", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }


        public ResponseClass GetProgramDashboardCount(getprogramdashboardcountrequestdto request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_program_dashboard_top
                                                                        ( 
                                                                            :p_eventcode,:p_employeecode
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EmplopyeeCode))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmplopyeeCode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                      

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertWIPrequest", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass getEventDays(getprogramdashboardcountrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_program_dashboard_eventdays
                                                                    ( 
                                                                        :p_eventcode
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.EventCode))
                        cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                    else
                        cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();

                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

        public ResponseClass ProgramDashboardDetailData(getprogramdashboardcountrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_program_dashboard_list
                                                                    ( 
                                                                        :p_eventcode,:p_programdate,:p_pageno,:p_rowno,:p_assettype
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.EventCode))
                        cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                    else
                        cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(request.ProgramDate))
                        cmd.Parameters.AddWithValue("p_programdate", DbType.String).Value = request.ProgramDate;
                    else
                        cmd.Parameters.AddWithValue("p_programdate", DbType.String).Value = DBNull.Value;
                    cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                    cmd.Parameters.AddWithValue("p_rowno", DbType.String).Value = request.RowsOfPage;
                    if (!String.IsNullOrEmpty(request.AssetType))
                        cmd.Parameters.AddWithValue("p_assettype", DbType.String).Value = request.AssetType;
                    else
                        cmd.Parameters.AddWithValue("p_assettype", DbType.String).Value = DBNull.Value;

                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    int recordcount = 1;
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                        if (request.PageNumber != -1)
                        {
                            //  OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

    }
}
