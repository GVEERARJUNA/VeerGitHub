﻿using TLDCBAL.Common;

namespace TLDCBAL.ProgramManager
{
    public interface IProgramMasterBL
    {
        ResponseClass InsertEditProgramMaster(ProgramMasterDTO request);
        ResponseClass DeleteAssetLearningDetails(DeleteAssetLearningDetailsSTO request);
        ResponseClass DeleteAssetDay(DeleteAssetDayDTO request);
        ResponseClass GetProgramMasterList(ProgramMasterDTO request);

        ResponseClass ManageProgramMasterPaging(ProgramMasterDTO request);
        ResponseClass GetProgramLearningList(ProgramAssetLearningMasterDTO request);
        ResponseClass GetProgramLearningListByPRcodeAndAssetID(ProgramAssetDetailsLearningMasterDTO request);
        ResponseClass GetAllocateAssetDropDownDataByAssetID(insertEditProgramLearningRequestDTO request);
        ResponseClass GetProgramMasterDataByProgramCode(ProgramMasterDTO request);
        ResponseClass InsertEditProgramAsset(insertEditProgramLearningRequestDTO request);

        ResponseClass insertProgramDependency(inserteditprogramdependencyrequestDTO request);

        ResponseClass GetProgramDependencyList(ProgramAssetDetailsLearningMasterDTO request);

    }
}
