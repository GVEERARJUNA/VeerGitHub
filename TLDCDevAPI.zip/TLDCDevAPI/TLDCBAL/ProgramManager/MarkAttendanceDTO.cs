﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ProgramManager
{
    public class MarkAttendanceDTO
    {
        public class AddUpdatePTSAttendance
        {
            public string SessionID { get; set; }
            public string AttendanceDate { get; set; }
            public string InsertUpdatedBy { get; set; }

            public string DayRemarks { get; set; }
            public string OverAllRemarks { get; set; }
            public string ClassRoomCode { get; set; }
            public string ProcessTrainingCode { get; set; }

            public List<ProcessTrainingSessionAttendance> ptsAttendanceList { get; set; }
            public AddUpdatePTSAttendance()
            {
                ptsAttendanceList = new List<ProcessTrainingSessionAttendance>();
            }
            //public ProcessTrainingSessionRemarks ptsRemarks { get; set; }
        }
        public class ProcessTrainingSessionAttendance
        {
            public int TID { get; set; }
            public string SessionID { get; set; }
            public string AttendanceDate { get; set; }
            public string ParticipantEmpCode { get; set; }
            public string IsPresent { get; set; }
            public string AbsenceReason { get; set; }
            public string EWSReasonCode { get; set; }
            public string EWSStatus { get; set; }
            public string LearnerRating { get; set; }
            public string Remark { get; set; }
            public string InsertUpdatedBy { get; set; }
            public int DeletedFlag { get; set; }
        }
        //public class ProcessTrainingSessionRemarks
        //{
        //    public int TID { get; set; }
        //    public string SessionID { get; set; }
        //    public string DayRemarks { get; set; }
        //    public string OverAllRemarks { get; set; }
        //    public int DeletedFlag { get; set; }
        //}
        public class AttendanceDates
        {
            public string SessionID { get; set; }
            public string AttendanceLevel { get; set; }
            public List<AttendanceDatesList> attendanceDatesList { get; set; }
            public AttendanceDates()
            {
                attendanceDatesList = new List<AttendanceDatesList>();
            }
        }
        public class AttendanceDatesList
        {
            public string Date { get; set; }
        }
        public class AttendanceEmployees
        {
            public string EmployeeCode { get; set; }
        }
        public class EWSReasonSession
        {
            public int TID { get; set; }
            public string EWSReason { get; set; }
        }
        public class EWSStatusSession
        {
            public int TID { get; set; }
            public string EWSReason { get; set; }
            public string EWSStatus { get; set; }
        }
        public class AttendanceAbsentReasonSession
        {
            public int TID { get; set; }
            public string AttendanceAbsentReason { get; set; }
        }
    }
}
