﻿using TLDCBAL.Common;

namespace TLDCBAL.ProgramManager
{
    public interface IAllocateEntityBL
    {
        ResponseClass InsertEditAllocateEntity(AllocateEntityInsertRequestDto request);
        ResponseClass ManageAllocateEntity(manageallocateEntityRequestDTO request);
        ResponseClass getAllocateEntityDropDownData(getAllocateEntityDropDownDataDTO request);
        ResponseClass PushSurveyResult(pushSurveyResultrequestDTO request);
        ResponseClass GetEntityNames(getEntityName request);

        ResponseClass DeleteEventAllocation(deleteeventallocationrequestDTO request);

        ResponseClass CheckEntityPublish(getEntityName request);

    }
}