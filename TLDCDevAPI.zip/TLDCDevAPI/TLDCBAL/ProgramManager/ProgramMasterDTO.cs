﻿namespace TLDCBAL.ProgramManager
{
    public class insertEditProgramLearningRequestDTO
    {
        public string ProgrameCode { get; set; }
        public string DayNo { get; set; }
        public string AssetType { get; set; }
        public string AssetID { get; set; }
        public string assetContent { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    } 
    public class ProgramAssetLearningMasterDTO
    {
        public string NodeName { get; set; }
        public string ProgramCode { get; set; }
        public string AssetID { get; set; }
        public string LearningCount { get; set; }
    }
    public class ProgramAssetDetailsLearningMasterDTO
    {
        public string ProgramName { get; set; }
        public string NodeName { get; set; }
        public string ProgramCode { get; set; }
        public string AssetID { get; set; }
        public string AssetDetailsID { get; set; }
        public string LearningType { get; set; }
        public string LearningName { get; set; }
    }
    public class DeleteAssetDayDTO
    {
        public string AssetID { get; set; }
        public string DeletedFlag { get; set; }
        public string DeletedBy { get; set; }
        public string DeletedOn { get; set; }
        public string DeletedIPAddress { get; set; }

    }
    public class DeleteAssetLearningDetailsSTO
    {
        public string AssetDetailsID { get; set; }
        public string DeletedFlag { get; set; }
        public string DeletedBy { get; set; }
        public string DeletedOn { get; set; }
        public string DeletedIPAddress { get; set; }

    }
    public class ProgramMasterDTO
    {
        public int ProgramMasterId { get; set; }
        public string ProgramName { get; set; }
        public string ProgramDescription { get; set; }
        public string EditAccess { get; set; }
        public string IsMultiDays { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string CreatedIPAddress { get; set; }
        public string UpdatedBy { get; set; }
        public string UpdatedOn { get; set; }
        public string UpdatedIPAddress { get; set; }
        public string action { get; set; }
        public string CurrentRole { get; set; }
        public string CurrentRoleCompany { get; set; }
        public string ProgramCode { get; set; }
        public string TSequenceNo { get; set; }
        public string DeletedFlag { get; set; }
        public string DeletedBy { get; set; }
        public string DeletedOn { get; set; }
        public string DeletedIPAddress { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public int GetMode { get; set; }

        public string objectCode { get; set; }

    }

    public class inserteditprogramdependencyrequestDTO
    {
        public string ProgramCode { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public string DependencyContent { get; set; }
    }

}

