﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;
using static TLDCBAL.ProgramManager.ProcessTrainingDTO;

namespace TLDCBAL.ProgramManager
{
    public interface IProcessTrainingBL
    {
        ResponseClass ManageProcessTraining(manageProcessTrainingDTO request);
        ResponseClass InsertEditProcessTraining(addupdateProcessTrainingDTO request);
        ResponseClass EditProcessTraining(addupdateProcessTrainingDTO request);
        ResponseClass GetProcessInstructor(ProcessInstructorDTO request);
        ResponseClass GetProcessAdministrator(ProcessAdministratorDTO request);
        ResponseClass GetEventProcessDetail(manageProcessTrainingDTO request);
        ResponseClass GetAttendanceRequiredTypeBySID(manageClassRoomrequestDTO request);
        
    }
}
