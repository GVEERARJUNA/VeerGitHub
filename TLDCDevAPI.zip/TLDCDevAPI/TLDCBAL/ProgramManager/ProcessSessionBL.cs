﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Service;
using static TLDCBAL.ProgramManager.ProcessSessionDTO;

namespace TLDCBAL.ProgramManager
{
    public class ProcessSessionBL : IProcessSessionBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        public ProcessSessionBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect)
        {
            appSettings = app;
            _serviceconnect = serviceconnect;
        }
        public ResponseClass ManageProcessSessionMaster(manageProcessSession request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = "select PTS.#TID# as tid, PTS.#SessionID# as sessionid,PTS.#SessionName# as sessionname,PTS.#ProcessTrainingCode# as processtrainingcode,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,PTS.#InsertedBy# as insertedemployeeid,TO_CHAR(PTS.#InsertedON#, 'dd-Mon-yyyy') as insertedon,PTM.#AttendanceRequire# as attendancerequire,(select count(*) from #vw_classroom_employee# where #ObjectCode#=PTM.#ClassRoomCode#) as allocated from #ProcessTrainingSession# PTS inner join #EmployeeMaster# EM on PTS.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# inner join #ProcessTrainingMaster# PTM on PTS.#ProcessTrainingCode# = PTM.#ProcessTrainingCode# where (PTS.#DeletedFlag#)=0 and (PTS.#ProcessTrainingCode#)='" + request.ProcessTrainingCode + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageProcessSessionMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass InsertUpdateProcessSessionMaster(addupdateProcessSession request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            if (request.Action == "ADD")
            {
                bool checkValue = false;
                checkValue=checkName(request.SessionName, "Session");
                if (checkValue==true)
                {
                    response.responseCode =0;
                    response.responseMessage = "session with same name already exist!";
                    return response;
                }

                try
                {
                    //TID
                    string sequenceNo = string.Empty;
                    int codeCountNoCount = 0;
                    string sqlQuery10 = "SELECT coalesce(max(#TsequenceNo#),0) as #TsequenceNo# FROM public.#ProcessTrainingSession#";

                    sqlQuery10 = sqlQuery10.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand10 = new NpgsqlCommand(sqlQuery10, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader10 = npgsqlCommand10.ExecuteReader();

                    if (npgsqlDataReader10.Read())
                    {
                        sequenceNo = npgsqlDataReader10[0].ToString();
                        codeCountNoCount = Convert.ToInt32(sequenceNo) + 1;
                        request.SessionID = "PTS" + codeCountNoCount;
                    }
                    else
                    {
                        ++codeCountNoCount;
                        request.SessionID = "PTS" + codeCountNoCount;
                    }

                    npgsqlCon.Close();

                    //Insert Data ProcessTrainingSession

                    string sqlQuery = "INSERT INTO public.#ProcessTrainingSession#(#SessionID#,#ProcessTrainingCode#,#SessionName#,#InsertedBy#,#InsertedON#,#DeletedFlag#,#TsequenceNo#) " + "VALUES('" + request.SessionID + "', '" + request.ProcessTrainingCode + "', '" + request.SessionName + "',  '" + request.InsertUpdatedBy + "', now(), '0', '" + codeCountNoCount + "')";

                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();

                    //Get Latest SessionID
                    string sessionId = string.Empty;

                    string sqlQuery2 = "SELECT max(#TsequenceNo#) as #TsequenceNo# FROM public.#ProcessTrainingSession#";

                    sqlQuery2 = sqlQuery2.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand2 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader2 = npgsqlCommand2.ExecuteReader();

                    if (npgsqlDataReader2.Read())
                    {
                        // videoCode = npgsqlDataReader2[0].ToString();
                        sessionId = "PTS" + npgsqlDataReader2[0].ToString();
                    }
                    npgsqlCon.Close();

                    if (request.ProcessSessionCalendorList != null && request.ProcessSessionCalendorList.Count > 0)
                    {
                        foreach (var item in request.ProcessSessionCalendorList)
                        {
                            //Insert Data ProcessTrainingSessionCalendar

                            string sqlQuery3 = "INSERT INTO public.#ProcessTrainingSessionCalendar#(#SessionID#,#StartDate#,#EndDate#,#TimeStart#,#TimeEnd#,#TimeZone#,#Venue#,#FacilitatorType#,#FacilitatorName#,#InsertedBy#,#InsertedOn#,#DeletedFlag#) " + "VALUES('" + sessionId + "', '" + item.StartDate + "', '" + item.EndDate + "', '" + item.StartTime + "', '" + item.EndTime + "', '" + item.TimeZone + "', '" + item.Venue + "', '" + item.FacilitatorType + "', '" + item.FacilitatorName + "', '" + request.InsertUpdatedBy + "', now(), '0')";

                            sqlQuery3 = sqlQuery3.Replace('#', '"');

                            npgsqlCon.Open();

                            NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery3, npgsqlCon);

                            NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();

                            npgsqlCon.Close();
                        }
                    }

                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Add Video", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            else if (request.Action == "EDIT")
            {
                try
                {
                    if (string.IsNullOrEmpty(request.SessionID))
                    {
                        response.responseMessage = "Please provide sessionID.";
                    }
                    else
                    {
                        //Update ProcessTrainingSession

                        string sqlQuery = "UPDATE public.#ProcessTrainingSession# SET #ProcessTrainingCode#='" + request.ProcessTrainingCode + "',#SessionName#='" + request.SessionName + "',#UpdatedBy#='" + request.InsertUpdatedBy + "',#UpdatedOn#=now() WHERE #SessionID# = '" + request.SessionID + "'";

                        sqlQuery = sqlQuery.Replace('#', '"');
                        npgsqlCon.Open();
                        NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);
                        NpgsqlDataReader dataReader = cmd.ExecuteReader();
                        npgsqlCon.Close();

                        // Delete previous ProcessTrainingSessionCalendar
                        string sqlQuery1 = "DELETE FROM public.#ProcessTrainingSessionCalendar# WHERE #SessionID# = '" + request.SessionID + "'";

                        sqlQuery1 = sqlQuery1.Replace('#', '"');
                        npgsqlCon.Open();
                        NpgsqlCommand cmd1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);
                        NpgsqlDataReader dataReader1 = cmd1.ExecuteReader();
                        npgsqlCon.Close();

                        //Update ProcessTrainingSessionCalendar
                        if (request.ProcessSessionCalendorList != null && request.ProcessSessionCalendorList.Count > 0)
                        {
                            foreach (var item in request.ProcessSessionCalendorList)
                            {
                                //Insert Data ProcessTrainingSessionCalendar

                                string sqlQuery2 = "INSERT INTO public.#ProcessTrainingSessionCalendar#(#SessionID#,#StartDate#,#EndDate#,#TimeStart#,#TimeEnd#,#TimeZone#,#Venue#,#FacilitatorType#,#FacilitatorName#,#InsertedBy#,#InsertedOn#,#DeletedFlag#) " + "VALUES('" + request.SessionID + "', '" + item.StartDate + "', '" + item.EndDate + "', '" + item.StartTime + "', '" + item.EndTime + "', '" + item.TimeZone + "', '" + item.Venue + "', '" + item.FacilitatorType + "', '" + item.FacilitatorName + "', '" + request.InsertUpdatedBy + "', now(), '0')";

                                sqlQuery2 = sqlQuery2.Replace('#', '"');

                                npgsqlCon.Open();

                                NpgsqlCommand cmd2 = new NpgsqlCommand(sqlQuery2, npgsqlCon);

                                NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                                npgsqlCon.Close();
                            }
                        }
                    }
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("InsertUpdateProcessSessionMaster", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            return response;
        }

        public ResponseClass DeleteProcessSession(deleteProcessSessiom request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            try
            {
                DataTable dtEmployees = new DataTable();

                string selectQuery = string.Empty;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM delete_process_session
                                                                        ( 
                                                                            :p_sessionid,:p_deletedby,:p_deletedipaddress

                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.SessionID))
                            cmd.Parameters.AddWithValue("p_sessionid", DbType.String).Value = request.SessionID;
                        else
                            cmd.Parameters.AddWithValue("p_sessionid", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.DeletedBy))
                            cmd.Parameters.AddWithValue("p_deletedby", DbType.String).Value = request.DeletedBy;
                        else
                            cmd.Parameters.AddWithValue("p_deletedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.DeletedIPAddress))
                            cmd.Parameters.AddWithValue("p_deletedipaddress", DbType.String).Value = request.DeletedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_deletedipaddress", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);


                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("DeleteProcessSession", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            
            return response;
        }

        //public ResponseClass DeleteProcessSession(deleteProcessSessiom request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    string pgsqlConnection = appSettings.Value.DbConnection;
        //    NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
        //    try
        //    {
        //        //Delete ProcessTrainingSession by session id

        //        string sqlQuery = "UPDATE public.#ProcessTrainingSession# set #DeletedFlag# =1,#DeletedBy# ='" + request.DeletedBy + "',#DeletedOn#=now() where #SessionID# ='" + request.SessionID + "'";

        //        sqlQuery = sqlQuery.Replace('#', '"');

        //        npgsqlCon.Open();

        //        NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

        //        NpgsqlDataReader dataReader = cmd.ExecuteReader();

        //        npgsqlCon.Close();

        //        response.responseCode = 1;
        //        response.responseMessage = "Success";
        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("Delete Course", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}
        public ResponseClass EditProcessSessionMaster(addupdateProcessSession request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable model = new DataTable();

                string selectQuery = string.Empty;

                //selectQuery = "select * from public.#ProcessTrainingSession# vm where #DeletedFlag# =0 and #SessionID# ='" + request.SessionID + "'";
                selectQuery = "select vm.*,(select ptm.#AttendanceRequire# from public.#ProcessTrainingMaster# ptm where ptm.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "'),(select ptm.#AttendanceLevel# from public.#ProcessTrainingMaster# ptm where ptm.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "') from public.#ProcessTrainingSession# vm where vm.#DeletedFlag# =0 and vm.#SessionID# ='" + request.SessionID + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(model);
                npgsql.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(model);
                response.responseJSONSecondary = JsonConvert.SerializeObject(ProcessTrainingSessionCalendarBySessionId(request.SessionID));

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditProcessSessionMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public DataTable ProcessTrainingSessionCalendarBySessionId(string sessionid)
        {
            ResponseClass response = new ResponseClass();

            DataTable model = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                selectQuery = "select * from public.#ProcessTrainingSessionCalendar# vm where #DeletedFlag#=0 and #SessionID# ='" + sessionid + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(model);
                npgsql.Close();
                return model;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ProcessTrainingSessionCalendarBySessionId", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return model;
        }
        public ResponseClass GetVenueForSession(VenueDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;


                selectQuery = "select * from (select distinct EM.#Building_Facility_Name# as buildingfacilityname,EM.#Company_Name# as companyname from public.#EmployeeMaster# EM where EM.#COMPANY_CODE# = '" + request.UserCompanyName + "'and EM.#Active_Separated# = 'Active' and EM.#Building_Facility_Name# != '' ";
                selectQuery =selectQuery +  " union all ";
                selectQuery = selectQuery + " select 'Virtually' as buildingfacilityname,'' as companyname ) PR";
                selectQuery =selectQuery + " order by PR.#buildingfacilityname#";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetVenueForSession", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetManageSessionCount(SessionCount request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select (select count(*) as TotalCount from public.#ProcessTrainingSession# where #DeletedFlag#=0 and #ProcessTrainingCode#='" + request.ProcessTrainingCode + "') ,";
                selectQuery += "(select count(a.result) as WIP from (select p.#SessionID#, (min(TO_CHAR(p.#StartDate# :: DATE, 'dd-mm-yyyy')) <= TO_CHAR(NOW() :: DATE, 'dd-mm-yyyy')) as result from public.#ProcessTrainingSessionCalendar# as p inner join public.#ProcessTrainingSession# as c on p.#SessionID#=c.#SessionID#  where p.#DeletedFlag#=0 and c.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "'  group by p.#SessionID# ) as a where a.result= true),";
                selectQuery += "(select count(a.result) as Completed from (select p.#SessionID#, (min(TO_CHAR(p.#StartDate# :: DATE, 'dd-mm-yyyy')) > TO_CHAR(NOW() :: DATE, 'dd-mm-yyyy')) as result from public.#ProcessTrainingSessionCalendar# as p inner join public.#ProcessTrainingSession# as c on p.#SessionID#=c.#SessionID#  where p.#DeletedFlag#=0 and c.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "'  group by p.#SessionID# ) as a where a.result= true)";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetVenueForSession", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetFacilitatorTypeForSession(FacilitatorTypeDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "SELECT F.#FacilitatorTypeId# as facilitatortypeid, F.#FacilitatorType# as facilitatortype FROM public.#FacilitatorTypeMaster# F where F.#DeletedFlag#=0";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetFacilitatorTypeForSession", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetFacilitatorNameFromFacType(FacilitatorNameDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;
                // request.FacilitatorType = "Administrator";
                if (request.FacilitatorType == "Administrator")
                {
                    selectQuery = "select pt.#TrainingAdministrator# as EmployeeId,concat(E.#FIRSTNAME#,' ',E.#LASTNAME#) as FacilitatorName from public.#ProcessTrainingMaster# pt inner join #EmployeeMaster# E on pt.#TrainingAdministrator#= E.#EXTERNALDATAREFERENCE# where pt.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "' and pt.#DeletedFlag#=0";
                }
                else if (request.FacilitatorType == "Instructor")
                {
                    selectQuery = "select pt.#InstructorEmpCode#  as EmployeeId,concat(E.#FIRSTNAME#,' ',E.#LASTNAME#) as FacilitatorName from public.#ProcessTrainingInstructor# pt inner join #EmployeeMaster# E on pt.#InstructorEmpCode#= E.#EXTERNALDATAREFERENCE# where pt.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "' and pt.#DeletedFlag#=0";
                }

                if (!string.IsNullOrEmpty(selectQuery))
                {
                    selectQuery = selectQuery.Replace('#', '"');

                    string pgsqlConnection = appSettings.Value.DbConnection;
                    NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                    npgsql.Open();

                    NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    dataAdapter.Fill(dt);
                    npgsql.Close();
                }

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetFacilitatorNameFromFacType", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetSessionDetail(manageProcessSession request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select * from public.#ProcessTrainingSession# where #SessionID#='" + request.SessionID + "' and #DeletedFlag#=0";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetSessionDetail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public bool checkName(string name,string source)
        {
            try
            {
                DataTable trainingGroup = new DataTable();
                string selectQuery = string.Empty;
                if (source == "Training")
                {
                    selectQuery = " select count(*) as existcount from #ProcessTrainingMaster# where #TrainingName#='" + name + "';";
                }
                else if(source == "Session")
                {
                    selectQuery = " select count(*) as existcount from #ProcessTrainingSession# where #SessionName#='" + name + "';";
                }



                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                if (trainingGroup!=null && trainingGroup.Rows.Count>0)
                {
                    if (Convert.ToInt32(trainingGroup.Rows[0]["existcount"])>0)
                    {
                        return true;
                    }
                }

                npgsql.Close();
                return false;

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("checkName", "1024", ex.Message, "Exception");
                return false;
            }

           
        }
    }
}
