﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ProgramManager
{
    public class ProcessTrainingDTO
    {
        public class manageProcessTrainingDTO
        {
            public int TID { get; set; }
            public string ProcessTrainingCode { get; set; }
            public string TrainingName { get; set; }
            public string TrainingAdministrator { get; set; }
            public string InstructorRequire { get; set; }
            public string ExternalInstructor { get; set; }
            public string AttendanceRequire { get; set; }
            public string AttendanceLevel { get; set; }
            public string ProcessTrainingType { get; set; }
            public string SingleSessionEvent { get; set; }
            public string CreatedUpdatedBy { get; set; }
            public string TSequenceNo { get; set; }
        }
        public class addupdateProcessTrainingDTO
        {
            public int TID { get; set; }
            public string ProcessTrainingCode { get; set; }
            public string TrainingName { get; set; }
            public string TrainingAdministrator { get; set; }
            public string InstructorRequire { get; set; }
            public string ExternalInstructor { get; set; }
            public string AttendanceRequire { get; set; }
            public string AttendanceLevel { get; set; }
            public string ProcessTrainingType { get; set; }
            public string ClassRoomCode { get; set; }
            public string SingleSessionEvent { get; set; }
            public string ProcessTrainingInsList { get; set; }
            public string CreatedUpdatedBy { get; set; }
            public string TSequenceNo { get; set; }
            public string Action { get; set; }
            public int deletedflag { get; set; }
            public List<ProcessTrainingInstructorDTO> processTrainingInstructorlist { get; set; }
            public addupdateProcessTrainingDTO()
            {
                processTrainingInstructorlist = new List<ProcessTrainingInstructorDTO>();
            }
        }
        public class ProcessTrainingInstructorDTO
        {
            public string ProcessTrainingCode { get; set; }
            public string InstructorEmpCode { get; set; }
            public string InstructorEmpFirstName { get; set; }
            public string InstructorEmpLastName { get; set; }
        }

        public class deleteProcessTrainingDTO
        {
            public string ProcessTrainingCode { get; set; }
        }
        public class ProcessInstructorDTO
        {
            public string TID { get; set; }
            public string InstructorCode { get; set; }
            public string InstructorFName { get; set; }
            public string InstructorLName { get; set; }
            public string Country { get; set; }
            public string ProcessTrainingCode { get; set; }

            public string LoginEMPCode { get; set; }

            public string LoginRole { get; set; }

            public string UserCountry { get; set; }
        }
        public class ProcessAdministratorDTO
        {
            public string TID { get; set; }
            public string TrainingAdministorCode { get; set; }
            public string TrainingAdministorFName { get; set; }
            public string TrainingAdministorLName { get; set; }
            public string Country { get; set; }
        }

    }
}
