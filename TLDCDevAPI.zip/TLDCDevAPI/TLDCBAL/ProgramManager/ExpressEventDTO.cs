﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ProgramManager
{
    public class insertEditEventRequestDTO
    {
        public string EventID { get; set; }
        public string EventCode { get; set; }
        public string EventName { get; set; }
        public string EventStartDate { get; set; }
        public string EventEndDate { get; set; }
        public string EventStartTime { get; set; }
        public string EventEndTime { get; set; }
        public string EventContent { get; set; }

        public string EventDays { get; set; }
        public string EventType{ get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public string action { get; set; }
        public int IsPublished { get; set; }

        public string EventSource { get; set; }

        public string ClassRoomCode { get; set; }
        public int AcknowledgeRequired { get; set; }
        public string TimeZone { get; set; }
        public string serverstartdate { get; set; }
        public string serverstarttime { get; set; }

        public string serverenddate { get; set; }
        public string serverendtime { get; set; }

        public string CurrentRole { get; set; }

        public string EventFrequency { get; set; }

        public int HideSeekBar { get; set; }

        public int IsPublishOnApp { get; set; }

        public int EEDSSubcategory { get; set; }

        public int AllocationCategory { get; set; }


    }
    public class manageEventrequestDTO
    {
        public string eventCode { get; set; }
        public string searchKey { get; set; }

        public string LoginEMPCode { get; set; }
        public string CurrentRole { get; set; }
        public string CallingSource { get; set; }
        public string EventType { get; set; }

        public string UserCompany { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public int GetMode { get; set; }
    }

    public class getadmindashboardcount
    {
        public string CurrentRole { get; set; }
        public string UserName { get; set; }

        public string Geo { get; set; }

        public string UserCompany { get; set; }
    }
    public class getEntityDescription
    {
        public string entityCode { get; set; }
        public string objectType { get; set; }
    }

    public class eventdashboardCountrequetDTO
    {
        public string EventCode { get; set; }
        public string EventType { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }

    public class insertWIPrequestDTO
    {
        public string PrimaryID { get; set; }
        public string EventCode { get; set; }
        public string EmployeeCode { get; set; }

        public string Action { get; set; }
    }

    public class TeamLeadPendingTaskDTO
    {
        public string employeeCode { get; set; }
        public string CurrentRole { get; set; }
        public string picktype { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string searchbyempcode { get; set; }
    }
    public class RequestionDTO
    {
        public string RequisitionNumber { get; set; }
    }

    public class eventdeleterequestDTO
    {
        public string EventCode { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

        public string ObjectType { get; set; }
    }

    public class getprogramdashboardcountrequestdto
    {
        public string EventCode { get; set; }
        public string EmplopyeeCode { get; set; }

        public string ProgramDate { get; set; }

        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string AssetType { get; set; }
    }
}
