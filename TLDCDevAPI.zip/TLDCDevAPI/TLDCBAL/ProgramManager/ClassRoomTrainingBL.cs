﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;

namespace TLDCBAL.ProgramManager
{
    public class ClassRoomTrainingBL : IClassRoomTrainingBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;
        private IQualtricsDataBL _qualtricsBL;
        private ISchedulerBL _schedulerBL;

        public ClassRoomTrainingBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL, ISchedulerBL schedulerBL)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
            _schedulerBL = schedulerBL;
        }

        public ResponseClass ManageClassRoomTraining(manageClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string companiestopass = string.Empty;
                DataTable expressEvent = new DataTable();
                string selectQuery = string.Empty;
                selectQuery = "select A.#ClassRoomCode# as valuefield,A.#ClassRoomTitle# as displayfield,A.#ClassRoomCode# as classroomcode,A.#ClassRoomTitle# as classroomtitle,A.#ClassRoomDescription# as classroomdescription,A.#AssignKeyWord# as assignkeyword,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,TO_CHAR(A.#InsertedDateTime#, 'dd Mon yyyy') as createddate,(select STRING_AGG(#EventType#,',') from #ClassRoomEvent# where #ClassRoomCode#=A.#ClassRoomCode#) as eventType,A.#IsPublished# as ispublished,case when A.#IsPublished#=1 then 'YES' else 'NO' end as publishedtext,A.#AcknowledgeRequired#,(select count(*) from #EventAllocation# where #ObjectCode#=A.#ClassRoomCode# and #ObjectType#='ClassRoom') as allocationcount ,(select ptm.#AttendanceRequire# from public.#ProcessTrainingMaster# ptm where ptm.#ProcessTrainingCode#='" + request.ProcessTrainingCode+ "' limit 1),(select ptm.#AttendanceLevel# from public.#ProcessTrainingMaster# ptm where ptm.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "'  limit 1),TO_CHAR(A.#StartDate#, 'dd-Mon-yyyy') as startDate,TO_CHAR(A.#EndDate#, 'dd-Mon-yyyy') as enddate,TO_CHAR(A.#StartDate#, 'dd-Mon-yyyy') as classstartdate,TO_CHAR(A.#EndDate#, 'dd-Mon-yyyy') as classenddate,A.#IsCertificateRequired# as iscertificaterequired,A.#CertificateName# as certificatename, ";
                selectQuery = selectQuery + " (select count(*) from #ClassRoomEntityDetails# where #ClassRoomCode#=A.#ClassRoomCode#) as entitycount, ";
                selectQuery = selectQuery + " (select count(*) from #ProcessTrainingMaster# where #ClassRoomCode#=A.#ClassRoomCode# and #DeletedFlag#=0) as trainingcount, ";
                selectQuery = selectQuery + " coalesce((select STRING_AGG(#SkillName#,',') from #ClassRoomTrainingSkills# where #ClassRoomCode#=A.#ClassRoomCode#),'') as addedskills,A.#InsertedBy# ";
                selectQuery = selectQuery + "   from #ClassRoomTraining# A inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                                //selectQuery = "select A.#ClassRoomCode# as classroomcode,A.#ClassRoomTitle# as classroomtitle,A.#ClassRoomDescription# as classroomdescription,A.#AssignKeyWord# as assignkeyword,A.#StartDate# as startdate,A.#EndDate# as enddate,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,TO_CHAR(A.#InsertedDateTime#, 'dd Mon yyyy') as createddate,(select STRING_AGG(#EventType#,',') from #ClassRoomEvent# where #ClassRoomCode#=A.#ClassRoomCode#) as eventType,A.#IsPublished# as ispublished,case when A.#IsPublished#=1 then 'YES' else 'NO' end as publishedtext,A.#AcknowledgeRequired#,(select count(*) from #EventAllocation# where #ObjectCode#=A.#ClassRoomCode# and #ObjectType#='ClassRoom') as allocationcount ,(select ptm.#AttendanceRequire# from public.#ProcessTrainingMaster# ptm where ptm.#ProcessTrainingCode#='" + request.ProcessTrainingCode+ "' limit 1),(select ptm.#AttendanceLevel# from public.#ProcessTrainingMaster# ptm where ptm.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "'  limit 1) from #ClassRoomTraining# A inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                selectQuery = selectQuery + " where (A.#DeletedFlag#)=0  ";
               // and A.#EndDate#>=cast(now() as date)
                if (!string.IsNullOrEmpty(request.classRoomCode))
                {
                    selectQuery = selectQuery + " and  A.#ClassRoomCode#='" + request.classRoomCode + "'";
                }
                else
                {
                    if (!string.IsNullOrEmpty(request.searchKey))
                    {

                        selectQuery = selectQuery + " and  lower(A.#ClassRoomTitle#) like lower('%" + request.searchKey + "%')";
                    }
                }
                
                if (!string.IsNullOrEmpty(request.EventType))
                {
                    if (request.EventType=="ScormCourse")
                    {
                        selectQuery = selectQuery + " and A.#ClassRoomCode# in (select A.#ClassRoomCode# ";
                        selectQuery = selectQuery + "  from #ClassRoomEntityDetails# A ";
                        selectQuery = selectQuery + " inner join #CourseMaster# CM on A.#EntityCode# = CM.#CourseCode# ";
                        selectQuery = selectQuery + "  where #EntityType# = 'Course' and CM.#CourseType# in ('SCORM1.2', 'SCORM1.3') ";
                        selectQuery = selectQuery + "  and A.#IsPublished# = 1)";
                    }
                    else
                    {
                        selectQuery = selectQuery + " and A.#ClassRoomCode# in (select #ClassRoomCode# from #ClassRoomEvent# where #EventType# = '" + request.EventType +"')";
                    }
                    
                    

                }

                if (request.LoginEMPRole == "Program Manager")
                {
                    selectQuery = selectQuery + " and ( A.#InsertedBy#='" + request.LoginEMPCode + "'";

                    //  selectQuery = selectQuery + " and (A.#InsertedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                    //  selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                }
                else if (request.LoginEMPRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);

                    selectQuery = selectQuery + " and ((A.#CurrentRole#='200009' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    selectQuery = selectQuery + " )";


                    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //{
                    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    {
                    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    }

                    //    companiestopass = companiestopass.TrimEnd(',');

                    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //}
                }
                //else if (request.LoginEMPRole == "Participant")
                //{
                //    selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";
                //}

                //if (request.CallingSource == "Report")
                //{
                //    selectQuery = selectQuery + " and A.#IsPublished#=1 ";
                //}

                else if (request.LoginEMPRole == "Global Admin")
                {
                    selectQuery = selectQuery + " and (  A.#CurrentRole# in ('Program Manager','Geo Admin','Global Admin') ";
                }

                selectQuery = selectQuery + " or A.#ClassRoomCode# in (select distinct PTB.#ClassRoomCode# from #ProcessTrainingInstructor# PTI inner join #ProcessTrainingMaster# PTB on PTB.#ProcessTrainingCode# = PTI.#ProcessTrainingCode# and PTB.#DeletedFlag# = 0 and PTI.#InstructorEmpCode#='" + request.LoginEMPCode + "' ) )";

                selectQuery = selectQuery + " order by  A.#InsertedDateTime# desc";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(expressEvent);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(expressEvent);
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageClassRoomTraining", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetClassRoomListView(manageClassRoomrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_manage_classroom
                                                                        ( 
                                                                            :pcurrentemployeeid,
                                                                            :pcurrentemployeerole,:psearchkey,:pclassroomcode,:peventtype,
                                                                            :p_pageno,:p_recordno
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.LoginEMPCode))
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.LoginEMPCode;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.LoginEMPRole))
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.LoginEMPRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.searchKey))
                            cmd.Parameters.AddWithValue("psearchkey", DbType.String).Value = request.searchKey;
                        else
                            cmd.Parameters.AddWithValue("psearchkey", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.classRoomCode))
                            cmd.Parameters.AddWithValue("pclassroomcode", DbType.String).Value = request.classRoomCode;
                        else
                            cmd.Parameters.AddWithValue("pclassroomcode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EventType))
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = request.EventType;
                        else
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {

                           
                            dtEmployees.Columns.Add("encryptedID");
                            CommonFunction function = new CommonFunction();

                            if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                            {
                                foreach (DataRow item in dtEmployees.Rows)
                                {
                                    item["encryptedID"] = function.Encrypt(Convert.ToString(item["classroomcode"]));
                                }
                            }
                        }

                        if (request.GetMode == 0)
                        {
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                        else
                        {
                            response.dtresponse = dtEmployees;
                        }


                    }
                }


                if (dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    int recordcount = 1;
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                        if (request.PageNumber > 0)
                        {


                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                }



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetClassRoomListView", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass insertEditClassRoom(insertEditClassRoomRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                DateTime dtFrom = new DateTime();
                DateTime dtTo = new DateTime();
                string fromDate = string.Empty;
                string toDate = string.Empty;
                if (!string.IsNullOrEmpty(request.StartDate))
                {
                    try
                    {
                        dtFrom = Convert.ToDateTime(request.StartDate);
                        fromDate = Convert.ToDateTime(request.StartDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("insertEditClassRoom", "1024", "From Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid FromDate";
                        return response;


                    }
                }
                if (!string.IsNullOrEmpty(request.EndDate))
                {
                    try
                    {
                        dtTo = Convert.ToDateTime(request.EndDate);
                        toDate = Convert.ToDateTime(request.EndDate).ToString("yyyy-MM-dd");

                    }
                    catch (Exception ex)
                    {
                        _serviceconnect.LogConnect("insertEditClassRoom", "1024", "To Date : " + ex.Message, "Exception");
                        response.responseCode = 0;
                        response.responseMessage = "Invalid ToDate";
                        return response;


                    }
                }

                if (dtFrom > dtTo)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid start time and end time!";
                    return response;
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_classroomtraining
                                                                        ( 
                                                                            :p_classroom_code,
                                                                            :pclass_room_title,:pclass_room_description,
                                                                            :passign_keyword,:pclass_event_type,
                                                                            :p_details,
                                                                            :pinsertedby,
                                                                            :pinsertedipaddress,
                                                                            :p_action,:ispublished,:p_startdate,:p_enddate,
                                                                            :p_certificaterequired,:p_certificatename,:p_skills,:pcurrentrole
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.classRoomCode))
                            cmd.Parameters.AddWithValue("p_classroom_code", DbType.String).Value = request.classRoomCode;
                        else
                            cmd.Parameters.AddWithValue("p_classroom_code", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.classRoomTitle))
                            cmd.Parameters.AddWithValue("pclass_room_title", DbType.String).Value = request.classRoomTitle;
                        else
                            cmd.Parameters.AddWithValue("pclass_room_title", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.classRoomDescription))
                            cmd.Parameters.AddWithValue("pclass_room_description", DbType.String).Value = request.classRoomDescription;
                        else
                            cmd.Parameters.AddWithValue("pclass_room_description", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.assignKeyword))
                            cmd.Parameters.AddWithValue("passign_keyword", DbType.String).Value = request.assignKeyword;
                        else
                            cmd.Parameters.AddWithValue("passign_keyword", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.eventtype))
                            cmd.Parameters.AddWithValue("pclass_event_type", DbType.String).Value = request.eventtype;
                        else
                            cmd.Parameters.AddWithValue("pclass_event_type", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.eventDetails))
                            cmd.Parameters.AddWithValue("p_details", DbType.String).Value = request.eventDetails;
                        else
                            cmd.Parameters.AddWithValue("p_details", DbType.String).Value = DBNull.Value;

                      
                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;

                    

                        if (!String.IsNullOrEmpty(request.action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = string.Empty;
                        cmd.Parameters.AddWithValue("ispublished", DbType.String).Value = request.IsPublished;

                        if (!String.IsNullOrEmpty(fromDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = fromDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(toDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = toDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.IsCertificateRequired))
                            cmd.Parameters.AddWithValue("p_certificaterequired", DbType.String).Value = request.IsCertificateRequired;
                        else
                            cmd.Parameters.AddWithValue("p_certificaterequired", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CertificateName))
                            cmd.Parameters.AddWithValue("p_certificatename", DbType.String).Value = request.CertificateName;
                        else
                            cmd.Parameters.AddWithValue("p_certificatename", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.Skills))
                            cmd.Parameters.AddWithValue("p_skills", DbType.String).Value = request.Skills;
                        else
                            cmd.Parameters.AddWithValue("p_skills", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("pcurrentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentrole", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                            if (response.responseCode == 1 && request.action == "PUBLISH")
                            {
                                DataTable employeeData = new DataTable();
                                employeeData = allocateBusinessTraining("ClassRoom", request.classRoomCode);


                                if (employeeData != null && employeeData.Rows.Count > 0)
                                {
                                    DataTable dtSurveyContent = new DataTable();

                                    dtSurveyContent = getClassRoomSurveyContent(request.classRoomCode);

                                    //dtSurveyContent=insertSurvey(request);
                                    if (dtSurveyContent != null || dtSurveyContent.Rows.Count > 0)
                                    {
                                        foreach (DataRow drrow in dtSurveyContent.Rows)
                                        {
                                            if (Convert.ToInt32(drrow["SurveyID"]) > 0)
                                            {
                                                try
                                                {
                                                    surveyAllocationRequestDTO srv = new surveyAllocationRequestDTO();
                                                    surveyAllocationResponseDTO res = new surveyAllocationResponseDTO();
                                                    srv.LoggedInEmployeeId = request.InsertedBy;

                                                    srv.SurveyId = Convert.ToInt32(drrow["SurveyID"]);
                                                    srv.LstEmployeeIds = new List<string>();
                                                    foreach (DataRow item in employeeData.Rows)
                                                    {

                                                        srv.LstEmployeeIds.Add(Convert.ToString(item["empcode"]));

                                                    }

                                                    string resData = _serviceconnect.insertSurveyAllocation(srv);
                                                    res = JsonConvert.DeserializeObject<surveyAllocationResponseDTO>(resData);
                                                }
                                                catch (Exception)
                                                {


                                                }
                                            }

                                        }
                                    }

                                }

                            }
                        }
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertEditClassRoom", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass getAssignedEntityDropDownData(getAssignedEntityDropDownDataDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                assessmentlistresponseData ASResponse = new assessmentlistresponseData();
                string selectQuery = string.Empty;
                selectQuery = "select A.#EventCode# as objectcode,A.#EventName# as objectname  ";
                if (!string.IsNullOrEmpty(request.objectCode))
                {
                    selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
                }
                else
                {
                    selectQuery = selectQuery + " ,0 as assignedContent";

                }

                
                selectQuery = selectQuery + " from #EventMaster# A ";

                if (!string.IsNullOrEmpty(request.objectCode))
                {
                    selectQuery = selectQuery + " left join #ClassRoomEventDetails# B on B.#EventCode#=A.#EventCode# and B.#ClassRoomCode#='" + request.objectCode + "' ";
                }
                selectQuery = selectQuery + " where A.#DeletedFlag#=0 and A.#EventSource#='1' and A.#EventEndDate#>cast(now() as date) and A.#EventType#='" + request.objectType + "'";


                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();

                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

                
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getAllocateEntityDropDownData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getAssignedEntityDetailedData(getAssignedEntityDropDownDataDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                assessmentlistresponseData ASResponse = new assessmentlistresponseData();
                string selectQuery = string.Empty;

                if (request.objectType == "Assessment" || request.objectType == "Course" || request.objectType == "Video" || request.objectType == "Survey")
                {



                    selectQuery = selectQuery + "select PR.*,case when PR.allocated>0 then  case when PR.allocated-PR.completed=0 then 'Completed' else 'WIP' end else 'WIP' end as entitystatus from (select CRED.#EventCode# as eventcode,A.#IsPublished# as ispublished,A.#TID# as recordid,A.#EntityCode# as contentcode,A.#EntityName# as contenttext,cast(TO_CHAR(A.#InsertedDateTime#, 'dd-Mon-yy') as character varying) as createddate,concat(EMP.#FIRSTNAME#,' ',EMP.#LASTNAME#) as createdby,   ";
                    selectQuery = selectQuery + " (select count(AB.#TID#) from #BusinessTrainingEmpLearningDetails# AB inner join #BusinessTrainingAllocation# AA on AA.#TID#=AB.#AllocationID# inner join #EventMaster# EME on EME.#EventCode#=AA.#EventCode# where AA.#ClassRoomCode#='" + Convert.ToString(request.objectCode) + "' and EME.#EventType#='" + Convert.ToString(request.objectType) + "' and AB.#ContentCode#=A.#EntityCode# and AA.#EventCode#=CRED.#EventCode# ) as allocated, ";
                    //selectQuery = selectQuery + " (select count(*)  from #vw_classroom_employee# where #ObjectCode#='" + Convert.ToString(request.objectCode) + "' ) as allocated,";
                    selectQuery = selectQuery + " (select count(AB.#TID#) from #BusinessTrainingEmpLearningDetails# AB inner join #BusinessTrainingAllocation# AA on AA.#TID#=AB.#AllocationID# inner join #EventMaster# EME on EME.#EventCode#=AA.#EventCode# where AA.#ClassRoomCode#='" + Convert.ToString(request.objectCode) + "' and EME.#EventType#='" + Convert.ToString(request.objectType) + "' and (AB.#AcknowledgedStatus#=1 or AB.#IsLastAttempt#=1 ) and AB.#ContentCode#=A.#EntityCode# )  as completed ";
                    selectQuery = selectQuery + " from #ClassRoomEntityDetails# A inner join #ClassRoomEventDetails# CRED on A.#EventDetailID#=CRED.#TID#";
                    selectQuery = selectQuery + "left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#InsertedBy# where A.#DeletedFlag#=0 and A.#ClassRoomCode# ='" + Convert.ToString(request.objectCode) + "' and  A.#EntityType# ='" + Convert.ToString(request.objectType) + "' order by A.#EntityCode# ) PR";
                    selectQuery = selectQuery.Replace('#', '"');

                    //or cast(concat(AA.#EndDate#,' ',coalesce(AA.#EndTime#,'23:59:59')) as timestamp)<=now()
                }
                else
                {
                    selectQuery = selectQuery + "select A.#TID# as recordid,A.#ProcessTrainingCode# as contentcode,A.#TrainingName# as contenttext,cast(TO_CHAR(A.#CreatedOn#, 'dd-Mon-yy') as character varying) as createddate,concat(EMP.#FIRSTNAME#,' ',EMP.#LASTNAME#) as createdby,   ";
                    selectQuery = selectQuery + " (select count(*) from #vw_classroom_employee# where  #ObjectCode#='" + Convert.ToString(request.objectCode) + "') as allocated, ";
                    selectQuery = selectQuery + " 0 as completed";
                    selectQuery = selectQuery + " from #ProcessTrainingMaster# A ";
                    selectQuery = selectQuery + "left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#CreatedBy# where  A.#DeletedFlag#=0 and A.#ClassRoomCode# ='" + Convert.ToString(request.objectCode) + "' and  A.#ProcessTrainingType# ='" + Convert.ToString(request.objectType) + "' order by A.#ProcessTrainingCode#";
                    selectQuery = selectQuery.Replace('#', '"');
                }


                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();

                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);


                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getAssignedEntityDetailedData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass insertEditClassRoomEntity(insertEditClassRoomEntity request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_classromm_entity
                                                                        ( 
                                                                            :p_classroom_code,
                                                                            :peventtype,
                                                                            :pinsertedby,
                                                                            :pinsertedipaddress,
                                                                            :pevent_content
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ClassRoomCode))
                            cmd.Parameters.AddWithValue("p_classroom_code", DbType.String).Value = request.ClassRoomCode;
                        else
                            cmd.Parameters.AddWithValue("p_classroom_code", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.EventType))
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = request.EventType;
                        else
                            cmd.Parameters.AddWithValue("peventtype", DbType.String).Value = string.Empty;


                       
                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;



                        if (!String.IsNullOrEmpty(request.EventContent))
                            cmd.Parameters.AddWithValue("pevent_content", DbType.String).Value = request.EventContent;
                        else
                            cmd.Parameters.AddWithValue("pevent_content", DbType.String).Value = string.Empty;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);


                        }
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertEditClassRoomEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass DeleteClassRoomEntity(deleteClassRoomEntityRequest request)
        {
            ResponseClass response = new ResponseClass();

            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request is required";
                return response;
            }
            if (string.IsNullOrEmpty(request.RecordID))
            {
                response.responseCode = 0;
                response.responseMessage = "RecordID required";
                return response;
            }
            if (string.IsNullOrEmpty(request.RecordType))
            {
                response.responseCode = 0;
                response.responseMessage = "RecordType required";
                return response;
            }
            if (string.IsNullOrEmpty(request.InsertedBy))
            {
                response.responseCode = 0;
                response.responseMessage = "InsertedBy required";
                return response;
            }
            if (string.IsNullOrEmpty(request.InsertedIPAddress))
            {
                response.responseCode = 0;
                response.responseMessage = "InsertedIPAddress required";
                return response;
            }

            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_delete_classroom_entity
                                                                        ( 
                                                                            :record_id,
                                                                            :record_type,:p_insertedby,
                                                                            :p_insertedipaddress
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.RecordID))
                            cmd.Parameters.AddWithValue("record_id", DbType.String).Value = request.RecordID;
                        else
                            cmd.Parameters.AddWithValue("record_id", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.RecordType))
                            cmd.Parameters.AddWithValue("record_type", DbType.String).Value = request.RecordType;
                        else
                            cmd.Parameters.AddWithValue("record_type", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = string.Empty;

                        

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                            
                        }
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("DeleteClassRoomEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;



        }

        public DataTable allocateBusinessTraining(string objecttype, string objectCode)
        {
            //DataTable response = new DataTable();
            DataTable dtEmployees = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_allocate_class_room
                                                                        ( 
                                                                            :p_objecttype,
                                                                            :p_objectcode
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(objecttype))
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = objecttype;
                        else
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(objectCode))
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = objectCode;
                        else
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = string.Empty;




                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        // response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        //if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        //{
                        //    response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                        //    response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);


                        //}
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("allocateBusinessTraining", "1024", ex.Message, "Exception");
                //response.responseCode = 0;
                //response.responseMessage = ex.Message;
            }

            return dtEmployees;
        }

        public DataTable getClassRoomSurveyContent(string ClassRoomCode)
        {
            DataTable dtSurveyContent = new DataTable();
            string selectQuery = string.Empty;
            selectQuery = "select #EntityCode# as SurveyID from #ClassRoomEntityDetails#  where  #ClassRoomCode#='" + ClassRoomCode + "'  and #EntityType#='Survey';";
           
            selectQuery = selectQuery.Replace('#', '"');
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(dtSurveyContent);
            npgsql.Close();


            return dtSurveyContent;
        }

        public DataTable getEventSurveyContent(string ClassRoomCode,string EventCode)
        {
            DataTable dtSurveyContent = new DataTable();
            string selectQuery = string.Empty;
            //selectQuery = "select A.#EntityCode# as SurveyID from #ClassRoomEntityDetails# A inner join #ClassRoomEventDetails# B on A.#EventDetailID#=B.#TID# where  A.#ClassRoomCode#='" + ClassRoomCode + "'  and A.#EntityType#='Survey' and B.#EventCode#='" + EventCode + "'";
            selectQuery = "select #SurveyID# from #EventContent# A where #EventCode#='"  + EventCode  +  "'";
            selectQuery = selectQuery.Replace('#', '"');
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(dtSurveyContent);
            npgsql.Close();


            return dtSurveyContent;
        }

        public ResponseClass GetClassRoomEntitycount(getclassroomentitycount request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_classroom_entity_count
                                                                        ( 
                                                                            :p_classroomcode,
                                                                            :p_entitytype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ClassRoomCode))
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = request.ClassRoomCode;
                        else
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.EntityType))
                            cmd.Parameters.AddWithValue("p_entitytype", DbType.String).Value = request.EntityType;
                        else
                            cmd.Parameters.AddWithValue("p_entitytype", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetClassRoomEntitycount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass publishClassRoomEntity(allocateClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            //DataTable response = new DataTable();
            DataTable dtEmployees = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_publish_class_room_entity
                                                                        ( 
                                                                            :p_classroomcode,:p_objecttype,
                                                                            :p_objectcode
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ClassRoomCode))
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = request.ClassRoomCode;
                        else
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.objectType))
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = request.objectType;
                        else
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.objectCode))
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = request.objectCode;
                        else
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = string.Empty;




                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);
                            if (response.responseCode==1)
                            {
                                try
                                {
                                   // _schedulerBL.emailonpublishevent(request.objectCode, "Event");
                                }
                                catch (Exception)
                                {


                                }
                            }


                            DataTable dtSurveyContent = new DataTable();
                           // dtSurveyContent = getEventSurveyContent(request.ClassRoomCode,request.objectCode);
                            //  dtSurveyContent = insertSurveyEvent(request.objectCode, request.InsertedBy);
                            //if (dtSurveyContent != null || dtSurveyContent.Rows.Count > 0)
                            //{
                            //    foreach (DataRow drrow in dtSurveyContent.Rows)
                            //    {
                            //        if (!string.IsNullOrEmpty(Convert.ToString(drrow["SurveyID"])))
                            //        {
                            //            if (Convert.ToInt32(drrow["SurveyID"]) > 0)
                            //            {
                            //                try
                            //                {
                            //                    surveyAllocationRequestDTO srv = new surveyAllocationRequestDTO();
                            //                    surveyAllocationResponseDTO res = new surveyAllocationResponseDTO();
                            //                    srv.LoggedInEmployeeId = request.InsertedBy;

                            //                    srv.SurveyId = Convert.ToInt32(drrow["SurveyID"]);
                            //                    srv.LstEmployeeIds = new List<string>();
                            //                    foreach (DataRow item in dtEmployees.Rows)
                            //                    {

                            //                        srv.LstEmployeeIds.Add(Convert.ToString(item["empcode"]));

                            //                    }

                            //                    string resData = _serviceconnect.insertSurveyAllocation(srv);
                            //                    res = JsonConvert.DeserializeObject<surveyAllocationResponseDTO>(resData);
                            //                }
                            //                catch (Exception)
                            //                {


                            //                }
                            //            }
                            //        }


                            //    }
                            //}
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("publishClassRoomEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public DataTable insertSurveyEvent(string eventCode,string insertedBy)
        {
            ResponseClass response = new ResponseClass();
            DataTable expressEvent = new DataTable();

            try
            {

                string selectQuery = string.Empty;
                
                selectQuery = "select A.#ContentCode#,A.#ContentText#,B.#EventStartDate#,B.#EventEndDate#,B.#EventStartTime#,B.#EventEndTime# from #EventContent# A inner join #EventMaster# B on A.#EventCode#=B.#EventCode# where B.#EventType#='Survey' and B.#EventCode#='" + eventCode + "'   ";



                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(expressEvent);
                npgsql.Close();

                if (expressEvent != null && expressEvent.Rows.Count > 0)
                {
                    //get survey ID
                    expressEvent.Columns.Add("SurveyID");
                    foreach (DataRow item in expressEvent.Rows)
                    {
                        // call API
                        SurveyInsertRequestDTO srv = new SurveyInsertRequestDTO();
                        SurveyDetailsData res = new SurveyDetailsData();
                        srv.LoggedInEmployeeId = insertedBy;
                        srv.TemplateId = Convert.ToString(item["ContentCode"]);
                        srv.TemplateName = Convert.ToString(item["ContentText"]);
                        DateTime fromDt = Convert.ToDateTime(item["EventStartDate"]);
                        DateTime toDt = Convert.ToDateTime(item["EventEndDate"]);


                        if (!string.IsNullOrEmpty(Convert.ToString(item["EventStartTime"])) && Convert.ToString(item["EventStartTime"]) != "0")
                        {
                            fromDt = Convert.ToDateTime(fromDt.ToString("yyyy-MM-dd") + " " + Convert.ToString(item["EventStartTime"]));

                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(item["EventEndTime"])) && Convert.ToString(item["EventEndTime"]) != "0")
                        {
                            fromDt = Convert.ToDateTime(fromDt.ToString("yyyy-MM-dd") + " " + Convert.ToString(item["EventEndTime"]));
                        }

                        srv.StartDate = fromDt;
                        srv.EndDate = toDt;

                        // srv.StartDate
                        string resData = _serviceconnect.insertSurveyInsert(srv);
                        res = JsonConvert.DeserializeObject<SurveyDetailsData>(resData);

                        if (res.status == true)
                        {
                            try
                            {
                                string sqlQuery = string.Empty;

                                npgsql.Open();
                                sqlQuery = "update #EventContent# set #SurveyID#='" + res.data.SurveyId + "' where #EventCode#='" + eventCode + "' and #ContentCode#='" + srv.TemplateId + "'";

                                sqlQuery = sqlQuery.Replace('#', '"');
                                // Define a command to call  procedure
                                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsql);
                                NpgsqlDataReader rdr = cmd.ExecuteReader();

                                npgsql.Close();

                                item["SurveyID"] = Convert.ToString(res.data.SurveyId);
                                //return response;
                            }
                            catch (Exception ex)
                            {
                                _serviceconnect.LogConnect("UpdateSurveyID", "1024", ex.Message, "Exception");
                                // return response;
                            }
                        }




                    }

                    response.responseCode = 1;
                    response.responseMessage = "SUCCESS";
                }


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageExpressEvent", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            return expressEvent;
        }

        public ResponseClass publishClassRoomEntitySingle(allocateClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            
            DataTable dtEmployees = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM prc_publish_class_room_entity_single
                                                                        ( 
                                                                            :p_classroomcode,:p_eventcode,
                                                                            :p_objecttype,
                                                                            :p_objectcode,:record_id
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ClassRoomCode))
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = request.ClassRoomCode;
                        else
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EventCode))
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                        else
                            cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.objectType))
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = request.objectType;
                        else
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.objectCode))
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = request.objectCode;
                        else
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.RecordID))
                            cmd.Parameters.AddWithValue("record_id", DbType.String).Value = request.RecordID;
                        else
                            cmd.Parameters.AddWithValue("record_id", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);
                            DataTable dtSurveyContent = new DataTable();
                           // dtSurveyContent = getSurveyContentByRecord(request.RecordID);
                            //  dtSurveyContent = insertSurveyEvent(request.objectCode, request.InsertedBy);
                            //if (dtSurveyContent != null || dtSurveyContent.Rows.Count > 0)
                            //{
                            //    foreach (DataRow drrow in dtSurveyContent.Rows)
                            //    {
                            //        if (!string.IsNullOrEmpty(Convert.ToString(drrow["SurveyID"])))
                            //        {
                            //            if (Convert.ToInt32(drrow["SurveyID"]) > 0)
                            //            {
                            //                try
                            //                {
                            //                    surveyAllocationRequestDTO srv = new surveyAllocationRequestDTO();
                            //                    surveyAllocationResponseDTO res = new surveyAllocationResponseDTO();
                            //                    srv.LoggedInEmployeeId = request.InsertedBy;

                            //                    srv.SurveyId = Convert.ToInt32(drrow["SurveyID"]);
                            //                    srv.LstEmployeeIds = new List<string>();
                            //                    foreach (DataRow item in dtEmployees.Rows)
                            //                    {

                            //                        srv.LstEmployeeIds.Add(Convert.ToString(item["empcode"]));

                            //                    }

                            //                    string resData = _serviceconnect.insertSurveyAllocation(srv);
                            //                    res = JsonConvert.DeserializeObject<surveyAllocationResponseDTO>(resData);
                            //                }
                            //                catch (Exception)
                            //                {


                            //                }
                            //            }
                            //        }


                            //    }
                            //}

                            if (response.responseCode == 1)
                            {
                                try
                                {
                                   // _schedulerBL.emailonpublishevent(request.RecordID, "Single");
                                }
                                catch (Exception)
                                {


                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("publishClassRoomEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public DataTable getSurveyContentByRecord(string recordid)
        {
            DataTable dtSurveyContent = new DataTable();
            string selectQuery = string.Empty;
            //selectQuery = "select A.#EntityCode# as SurveyID from #ClassRoomEntityDetails# A inner join #ClassRoomEventDetails# B on A.#EventDetailID#=B.#TID# where  A.#ClassRoomCode#='" + ClassRoomCode + "'  and A.#EntityType#='Survey' and B.#EventCode#='" + EventCode + "'";
            selectQuery = "select #EntityCode# as SurveyID from #ClassRoomEntityDetails#  where #EntityType#='Survey' and  #TID#=" + recordid + "";
            selectQuery = selectQuery.Replace('#', '"');
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(dtSurveyContent);
            npgsql.Close();


            return dtSurveyContent;
        }

        public ResponseClass GetClassRoomEntityHeadercount(getclassroomentitycount request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_classroom_entity_header_count
                                                                        ( 
                                                                            :p_classroomcode,
                                                                            :p_entitytype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ClassRoomCode))
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = request.ClassRoomCode;
                        else
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.EntityType))
                            cmd.Parameters.AddWithValue("p_entitytype", DbType.String).Value = request.EntityType;
                        else
                            cmd.Parameters.AddWithValue("p_entitytype", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetClassRoomEntitycount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        #region class room dashboard

        public ResponseClass getclassroomdashboarddata(classroomdashboardrequestdto request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_classroom_dashboard
                                                                        ( 
                                                                            :p_cccode,
                                                                            :p_employeecode
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.classroomcode))
                            cmd.Parameters.AddWithValue("p_cccode", DbType.String).Value = request.classroomcode;
                        else
                            cmd.Parameters.AddWithValue("p_cccode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.employeecode))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getclassroomdashboarddata", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass getdashboarddetailedentity(classroomdashboardrequestdto request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select distinct AA.#EventCode#,BE.#ContentCode#,BE.#ContentText#,EME.#EventType#,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as createdby,TO_CHAR(EME.#InsertedDateTime#, 'dd Mon yyyy') as createddate,Coalesce(Percen.completionpercentage,0) as completionpercentage from #BusinessTrainingEmpLearningDetails# BE inner join #BusinessTrainingAllocation# AA on AA.#TID#=BE.#AllocationID#";
                selectQuery = selectQuery + " inner join #EventMaster# EME on EME.#EventCode#=AA.#EventCode#";
                selectQuery = selectQuery + " inner join #EmployeeMaster# EM on EME.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";

                selectQuery = selectQuery + " left join ";
                selectQuery = selectQuery + "  ( ";
                selectQuery = selectQuery + "    select ";
                selectQuery = selectQuery + "    cast(round(cast(cast(concat(sum(PR.completed),'.00') as decimal)/ sum(PR.totalvalue) as decimal),5)*100 as integer) as completionpercentage, ";
                selectQuery = selectQuery + "    PR.#ContentCode#,PR.#ClassRoomCode#,PR.#EventCode# ";
                selectQuery = selectQuery + "   from ";
                selectQuery = selectQuery + "            (select case when(A.#AcknowledgedStatus# = 1  or  A.#IsLastAttempt# = 1) then 1 else 0 end as completed, ";

                selectQuery = selectQuery + "            case when A.#AcknowledgedStatus# = 0 then 1 else 0 end as notcompleted, ";

                selectQuery = selectQuery + "             1 as totalvalue, ";
                selectQuery = selectQuery + "            A.#AllocationID#,A.#ContentCode#,B.#ClassRoomCode#,B.#EventCode# ";

                selectQuery = selectQuery + "           from #BusinessTrainingEmpLearningDetails# A ";
                selectQuery = selectQuery + "          inner join #BusinessTrainingAllocation# B on A.#AllocationID# = B.#TID# ";


                selectQuery = selectQuery + "    )";
                selectQuery = selectQuery + "    PR ";
                selectQuery = selectQuery + "    group by PR.#ContentCode#,PR.#ClassRoomCode#,PR.#EventCode# ";

                selectQuery = selectQuery + "  )Percen on Percen.#ContentCode# = BE.#ContentCode# ";
                selectQuery = selectQuery + "   and Percen.#ClassRoomCode# = AA.#ClassRoomCode# ";
                selectQuery = selectQuery + "   and Percen.#EventCode# = AA.#EventCode# ";




                selectQuery = selectQuery + " where AA.#ClassRoomCode#='" + Convert.ToString(request.classroomcode) + "'";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();

                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);


                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getdashboarddetailedentity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getclassdashboarddaywiseactivities(classroomdashboardrequestdto request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_classroom_dashboard_date_count
                                                                        ( 
                                                                            :p_classroomcode,
                                                                            :p_entitytype
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.classroomcode))
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = request.classroomcode;
                        else
                            cmd.Parameters.AddWithValue("p_classroomcode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.employeecode))
                            cmd.Parameters.AddWithValue("p_entitytype", DbType.String).Value = request.employeecode;
                        else
                            cmd.Parameters.AddWithValue("p_entitytype", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getclassdashboarddaywiseactivities", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        //public ResponseClass getclassdashboarddaywiseactivities(classroomdashboardrequestdto request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //       // ,fn_getclassroom_dailyactivitycount(#ClassRoomCode#,) as activities
        //        DataTable trainingGroup = new DataTable();

        //        string selectQuery = string.Empty;

        //        selectQuery = "select TO_CHAR(PR.mydate,'Mon dd') as mydate,fn_getclassroom_dailyactivitycount(PR.cccode,PR.mydate) as activities from (select cast(generate_series(#StartDate#,#EndDate#, '1 day'::interval) as date) as mydate,#ClassRoomCode# as cccode from #ClassRoomTraining# where #ClassRoomCode#='" + Convert.ToString(request.classroomcode) + "') PR ";
        //       // selectQuery = selectQuery + " inner join #EventMaster# EME on EME.#EventCode#=AA.#EventCode#";
        //        //selectQuery = selectQuery + " inner join #EmployeeMaster# EM on EME.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
        //        //selectQuery = selectQuery + " where AA.#ClassRoomCode#='" + Convert.ToString(request.classroomcode) + "'";
        //        selectQuery = selectQuery.Replace('#', '"');
        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(trainingGroup);
        //        npgsql.Close();

        //        response.responseJSON = JsonConvert.SerializeObject(trainingGroup);


        //        response.responseCode = 1;
        //        response.responseMessage = "SUCCESS";

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("getdashboarddetailedentity", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}

        public ResponseClass getclassdashboardemployeewisedetail(classroomdashboardrequestdto request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = " select distinct EM.#Company_Name# as company,A.#EmployeeCode# as empcode,";
                selectQuery = selectQuery + " concat(EM.#FIRSTNAME#, ' ', EM.#LASTNAME#) as emname,";
                selectQuery = selectQuery + " percentage.completed,percentage.notcompleted";
                selectQuery = selectQuery + " from #BusinessTrainingAllocation# A";
                selectQuery = selectQuery + " inner join #BusinessTrainingEmpLearningDetails# B on A.#TID# = B.#AllocationID#";
                selectQuery = selectQuery + " inner join #EmployeeMaster# EM on A.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " left join";
                selectQuery = selectQuery + " (";
                selectQuery = selectQuery + " select PR.#EmployeeCode#,sum(PR.completed) as completed,";

                selectQuery = selectQuery + " sum(PR.notcompleted) as notcompleted";

                selectQuery = selectQuery + " from (select";

                selectQuery = selectQuery + " BTA.#EmployeeCode#,";

                selectQuery = selectQuery + " case when (BTED.#AcknowledgedStatus# = 1 or BTED.#IsLastAttempt# = 1) then 1 else 0 end as completed,";

                selectQuery = selectQuery + " case when (BTED.#AcknowledgedStatus# =0 and BTED.#IsLastAttempt# =0) then 1 else 0 end as notcompleted";

                selectQuery = selectQuery + " from #BusinessTrainingAllocation# BTA";
                selectQuery = selectQuery + " inner join #BusinessTrainingEmpLearningDetails# BTED on BTA.#TID# = BTED.#AllocationID#";

                selectQuery = selectQuery + " where BTA.#ClassRoomCode# = '" + Convert.ToString(request.classroomcode) + "') PR group by PR.#EmployeeCode#";


                selectQuery = selectQuery + " )percentage on percentage.#EmployeeCode# = A.#EmployeeCode#";
                selectQuery = selectQuery + " where A.#ClassRoomCode# = '" + Convert.ToString(request.classroomcode) + "'";

                
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                trainingGroup.Columns.Add("empprogress");
                if (trainingGroup!=null && trainingGroup.Rows.Count>0)
                {


                    foreach (DataRow item in trainingGroup.Rows)
                    {
                        double completedcount = 0;
                        double notcompletedcount = 0;
                        completedcount = Convert.ToDouble(item["completed"]);
                        notcompletedcount = Convert.ToDouble(item["notcompleted"]);
                        double progress = (completedcount / (completedcount + notcompletedcount)) * 100;
                       
                        item["empprogress"] = Convert.ToInt32(progress);

                    }

                    int assetcount = 0;
                    assetcount = Convert.ToInt32(trainingGroup.Rows[0]["completed"]) + Convert.ToInt32(trainingGroup.Rows[0]["notcompleted"]);
                    StringBuilder emailBodyText = new StringBuilder();
                    emailBodyText.Append("<thead>");
                    emailBodyText.Append("<tr>");
                    emailBodyText.Append("<th class='text-center' width='40'>#</th>");
                    emailBodyText.Append("<th>Company Name</th>");
                    emailBodyText.Append(" <th>Employee ID</th>");
                    emailBodyText.Append("<th>Employee Name</th>");
                    DataTable dtcolumncount = new DataTable();

                    dtcolumncount = getdistinctcontent(request.classroomcode);
                    if (dtcolumncount!=null && dtcolumncount.Rows.Count>0)
                    {
                        //int assetno = 1;
                        foreach (DataRow item in dtcolumncount.Rows)
                        {
                            string cctext = string.Empty;
                            cctext = Convert.ToString(item["ContentText"]);
                            emailBodyText.Append("<th class='text-center'>" + cctext + "</th>");

                            //assetno = assetno + 1;

                        }
                    }
                    
                    emailBodyText.Append("<th class='text-center'>Overall Progress</th>");
                    emailBodyText.Append("</tr>");
                    emailBodyText.Append("</thead>");

                    emailBodyText.Append("<tbody>");
                    int rowno = 1;
                    DataTable dtresult = new DataTable();
                    dtresult = getclasscontentemployeewise(request.classroomcode);
                    foreach (DataRow item in trainingGroup.Rows)
                    {
                        int progress = Convert.ToInt32(item["empprogress"]);
                        string progressbar ="<div class='progress'><div class='progress-bar' role ='progressbar' style='width: " + progress + "%;aria-valuenow=" + progress + " aria-valuemin='0' aria-valuemax='100'> " + progress + " %</div></div >";
                        string empcode = Convert.ToString(item["empcode"]);
                        emailBodyText.Append("<tr>");
                        emailBodyText.Append("<td class='text-center'>" + rowno + "</td>");
                        emailBodyText.Append("<td>" + item["company"] + "</td>");
                        emailBodyText.Append("<td>" + item["empcode"] + "</td>");
                        emailBodyText.Append("<td>" + item["emname"] + "</td>");
                        
                        
                        if (dtresult!=null && dtresult.Rows.Count>0)
                        {
                            if (dtcolumncount != null && dtcolumncount.Rows.Count > 0)
                            {
                                foreach (DataRow asset in dtcolumncount.Rows)
                                {
                                    DataRow[] result = dtresult.Select("EmployeeCode='" + empcode + "' and ContentCode='" + Convert.ToString(asset["ContentCode"]) + "' and EventCode='" + Convert.ToString(asset["EventCode"]) + "'") ;
                                    if (result != null && result.Length > 0)
                                    {
                                        foreach (DataRow row in result)
                                        {
                                            int acknowledgedstatus = 0;
                                            acknowledgedstatus = Convert.ToInt32(row["AcknowledgedStatus"]);
                                            if (acknowledgedstatus == 1 || Convert.ToInt32(row["FailedAttempt"])==1)
                                            {
                                                emailBodyText.Append("<td class='text-center'><i class='fa-solid fa-check-circle text-success font-20'></i></td>");
                                            }
                                            else
                                            {
                                                emailBodyText.Append("<td class='text-center'><i class='fa-solid fa-times-circle text-danger font-20'></i></td>");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        emailBodyText.Append("<td class='text-center'></td>");
                                    }
                                }
                            }
                            
                            
                        }

                        emailBodyText.Append("<td class='text-center'>" + progressbar + "</td>");
                        emailBodyText.Append("</tr>");

                        rowno = rowno + 1;


                    }
                    emailBodyText.Append("</tbody>");
                    response.responseJSON = emailBodyText.ToString();
                }

                
                // response.responseJSON = JsonConvert.SerializeObject(trainingGroup);


                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getclassdashboardemployeewisedetail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public DataTable getclasscontentemployeewise(string classcode)
        {
            DataTable dtResult = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                selectQuery = selectQuery + " select BTA.#EventCode#,BTA.#EmployeeCode#,BTED.#ContentCode#,BTED.#AcknowledgedStatus#,BTED.#IsLastAttempt# as FailedAttempt ";
                selectQuery = selectQuery + " from #BusinessTrainingAllocation# BTA ";
                selectQuery = selectQuery + " inner join #BusinessTrainingEmpLearningDetails# BTED on BTA.#TID# = BTED.#AllocationID# ";
                selectQuery = selectQuery + " where BTA.#ClassRoomCode# = '" + classcode + "' ";
                selectQuery = selectQuery + " order by  BTA.#EmployeeCode#,BTED.#ContentCode#";
                selectQuery = selectQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
                npgsql.Close();
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getclasscontentemployeewise", "1024", ex.Message, "Exception");

            }



            return dtResult;

        }

        public DataTable getdistinctcontent(string classcode)
        {
            DataTable dtResult = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                selectQuery = selectQuery + " select distinct  BTED.#ContentCode#,BTA.#EventCode#,case when EVM.#EventType#='Course' then concat(CM.#CourseName#,'</br>(',CM.#CourseType#,')') else concat(BTED.#ContentText#,'</br>(',EVM.#EventType#,')') end as ContentText";
                selectQuery = selectQuery + " from #BusinessTrainingAllocation# BTA ";
                selectQuery = selectQuery + " inner join #BusinessTrainingEmpLearningDetails# BTED on BTA.#TID# = BTED.#AllocationID# ";
                selectQuery = selectQuery + " inner join #EventMaster# EVM on BTA.#EventCode# = EVM.#EventCode# ";
                selectQuery = selectQuery + " left join #CourseMaster# CM on CM.#CourseCode# = BTED.#ContentCode# ";
                selectQuery = selectQuery + " where BTA.#ClassRoomCode# = '" + classcode + "' ";
               // selectQuery = selectQuery + " order by  BTA.#EmployeeCode#,BTED.#ContentCode#";
                selectQuery = selectQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtResult);
                npgsql.Close();

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getclasscontentemployeewise", "1024", ex.Message, "Exception");

            }



            return dtResult;

        }

        public ResponseClass CertificateListClass(getcertificatelistclass request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                // certificate list

                DataTable dtData = new DataTable();

                string seqQuery = "select a.#CertificateNumber#, a.#TemplateName# " +
                    " from #CertificateMaster# a left join  #CertificateAllocation# b on b.#CertificateNumber# = a.#CertificateNumber# " +
                    " where a.#IsDeleted# = 0 ";

                string companiestopass = string.Empty;
                if (request.CurrentRole == "Program Manager")
                {
                    seqQuery = seqQuery + " and b.#GEO#='" + request.CountryName + "'" + " and a.#CreatedBy# = " + "'" + request.EmpCode + "'";

                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.EmpCode);
                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                        }

                        companiestopass = companiestopass.TrimEnd(',');

                        seqQuery = seqQuery + " and b.#GEO# in (" + companiestopass + ")";

                    }
                }

               
                seqQuery = seqQuery + " group by a.#CertificateNumber#,a.#TemplateName# order by a.#CertificateNumber# desc;";

                seqQuery = seqQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(seqQuery, npgsqlCon);

                NpgsqlDataAdapter npgsqlDataReader1 = new NpgsqlDataAdapter(npgsqlCommand1);

                npgsqlDataReader1.Fill(dtData);

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseMessage = "Success";
                response.responseJSON = JsonConvert.SerializeObject(dtData);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("CertificateListClass", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        #endregion
    }
}
