﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;
using static TLDCBAL.ProgramManager.ProcessSessionDTO;

namespace TLDCBAL.ProgramManager
{
    public interface IProcessSessionBL
    {
        ResponseClass ManageProcessSessionMaster(manageProcessSession request);
        ResponseClass InsertUpdateProcessSessionMaster(addupdateProcessSession request);
        ResponseClass DeleteProcessSession(deleteProcessSessiom request);
        ResponseClass EditProcessSessionMaster(addupdateProcessSession request);
        ResponseClass GetVenueForSession(VenueDTO request);
        ResponseClass GetFacilitatorTypeForSession(FacilitatorTypeDTO request);
        ResponseClass GetManageSessionCount(SessionCount request);
        ResponseClass GetFacilitatorNameFromFacType(FacilitatorNameDTO request);
        ResponseClass GetSessionDetail(manageProcessSession request);
    }
}
