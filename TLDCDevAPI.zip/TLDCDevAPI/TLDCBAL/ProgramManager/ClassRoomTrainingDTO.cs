﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ProgramManager
{
    public class manageClassRoomrequestDTO
    {
        public string classRoomCode { get; set; }
        public string searchKey { get; set; }

        public string LoginEMPCode { get; set; }
        public string SessionId { get; set; }
        public string ProcessTrainingCode { get; set; }
        public string AttendanceLevel { get; set; }
        public string AttendanceRequired { get; set; }
        public string ProcessTrainingType { get; set; }

        public string LoginEMPRole { get; set; }
        public string CallingSource { get; set; }
        public string EventType { get; set; }

        public string UserCompany { get; set; }

        public int GetMode { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }
    public class insertEditClassRoomRequestDTO
    {
        public string classRoomCode { get; set; }
        public string classRoomTitle { get; set; }
        public string classRoomDescription { get; set; }
        public string assignKeyword { get; set; }
        public string eventtype { get; set; }
        public string eventDetails { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public string action { get; set; }
        public int IsPublished { get; set; }

        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string IsCertificateRequired { get; set; }
        public string CertificateName { get; set; }
        public string Skills { get; set; }

        public string CurrentRole { get; set; }
    }
    public class getAssignedEntityDropDownDataDTO
    {
        public string objectType { get; set; }
        public string objectCode { get; set; }

        public string Geo { get; set; }

        public string EmpCode { get; set; }

    }

    public class insertEditClassRoomEntity
    {
        public string ClassRoomCode { get; set; }
        public string EventType { get; set; }

        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

        public string EventContent { get; set; }
    }

    public class deleteClassRoomEntityRequest
    {
        public string RecordID { get; set; }
        public string RecordType { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }

    public class getclassroomentitycount
    {
        public string ClassRoomCode { get; set; }
        public string EntityType { get; set; }

        public string Geo { get; set; }
    }

    public class allocateClassRoomrequestDTO
    {
        public string ClassRoomCode { get; set; }
        public string objectType { get; set; }
        public string objectCode { get; set; }

        public string EventCode { get; set; }

        public string RecordID { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }

    public class classroomdashboardrequestdto
    {
        public string classroomcode { get; set; }
        public string employeecode { get; set; }
    }

    public class getcertificatelistclass
    {
        public string EmpCode { get; set; }
        public string CurrentRole { get; set; }
        public string CountryName { get; set; }
    }

    
}
