﻿using System;
using System.Collections.Generic;
using System.Text;
using TLDCBAL.Common;
using static TLDCBAL.ProgramManager.MarkAttendanceDTO;

namespace TLDCBAL.ProgramManager
{
    public interface IMarkAttendanceBL
    {
        ResponseClass InsertEditMarkAttendance(AddUpdatePTSAttendance request);
        ResponseClass GetDateListForMarkAttendance(AttendanceDates request);
        ResponseClass GetEWSReason(EWSReasonSession request);
        ResponseClass GetEWSStatus(EWSStatusSession request);
        ResponseClass GetAttendanceAbsentReason(AttendanceAbsentReasonSession request);
        ResponseClass GetAttendanceData(AddUpdatePTSAttendance request); 

    }
}
