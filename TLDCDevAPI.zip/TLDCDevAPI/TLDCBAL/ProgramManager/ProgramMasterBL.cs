﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.CourseAdmin;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;

namespace TLDCBAL.ProgramManager
{
   public class ProgramMasterBL : IProgramMasterBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        private IQualtricsDataBL _qualtricsBL;

        public ProgramMasterBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;

            _qualtricsBL = qualtricsBL;
        }
        public string RemoveQuotes(string str)
        {
            string result = string.Empty;
            if (str != null && str != "")
            {
                result = str.Replace("'", "''");
            }
            return result;
        }
        public ResponseClass InsertEditProgramMaster(ProgramMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            if (request.action == "ADD")
            {
                try
                {
                    if (!string.IsNullOrWhiteSpace(request.ProgramName))
                    {
                        string duplicateQuery = "select 'Yes'  from public.#ProgramMaster# where #ProgramName# = '"+ request.ProgramName + "' and #DeletedFlag# = '0' limit 1";
                        string isDuplicate = string.Empty;
                        duplicateQuery = duplicateQuery.Replace('#', '"');

                        npgsqlCon.Open();

                        NpgsqlCommand checkDuplicacyCmd = new NpgsqlCommand(duplicateQuery, npgsqlCon);

                        NpgsqlDataReader npgsqlDataReaderDupcheck = checkDuplicacyCmd.ExecuteReader();

                        if (npgsqlDataReaderDupcheck.Read())
                        {
                            isDuplicate = npgsqlDataReaderDupcheck[0].ToString();
                        }
                        else
                        {
                            isDuplicate = string.Empty;
                        }

                        npgsqlCon.Close();

                        if (isDuplicate == "Yes")
                        {
                            response.responseCode = 0;
                            response.responseMessage = "Program name already exists!";
                            return response;
                        }
                    }
                    //TSequenceNo
                    string programCodeNo = string.Empty;
                    int codeCountNoCount = 0;
                    string sqlQuery1 = "SELECT coalesce(max(#TSequenceNo#),0) as #TSequenceNo# FROM public.#ProgramMaster#";

                    sqlQuery1 = sqlQuery1.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                    NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                    if (npgsqlDataReader1.Read())
                    {
                        programCodeNo = npgsqlDataReader1[0].ToString();
                        codeCountNoCount = Convert.ToInt32(programCodeNo) + 1;
                        request.ProgramCode = "PRG" + codeCountNoCount;
                    }
                    else
                    {
                        ++codeCountNoCount;
                        request.ProgramCode = "PRG" + codeCountNoCount;
                    }

                    npgsqlCon.Close();

                    //Insert Data ProgramMaster

                    string sqlQuery = "INSERT INTO public.#ProgramMaster#(#ProgramName#,#ProgramDescription#,#IsMultiDays#,#CreatedBy#,#CreatedOn#,#CreatedIPAddress#,#CurrentRole#,#ProgramCode#,#TSequenceNo#,#CurrentRoleCompany#)";

                    sqlQuery = sqlQuery + "VALUES('" + request.ProgramName + "', '" + RemoveQuotes(request.ProgramDescription) + "', '" + request.IsMultiDays + "', '" + request.CreatedBy + "', now(), '" + request.CreatedIPAddress + "', '" + request.CurrentRole + "', '" + request.ProgramCode + "', '" + codeCountNoCount + "',";

                    if (request.CurrentRole == "Program Manager")
                    {
                        sqlQuery = sqlQuery + "(select #COMPANY_CODE# from #EmployeeMaster# where #EXTERNALDATAREFERENCE#='" + request.CreatedBy + "')";
                    }
                    else if (request.CurrentRole == "Geo Admin")
                    {
                        sqlQuery = sqlQuery + "(select STRING_AGG(#CompanyCode#,',') from #UserCompanyAssignment# where #EmployeeCode#='" + request.CreatedBy + "')";
                    }
                    else
                    {
                        sqlQuery = sqlQuery + "NULL";
                    }
                    sqlQuery = sqlQuery + ")";

                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);
                   

                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Create Program", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }

            if (request.action == "EDIT")
            {
                try
                {
                    if (!string.IsNullOrWhiteSpace(request.ProgramName))
                    {
                        string duplicateQuery = "select 'Yes'  from public.#ProgramMaster# where #ProgramName# = '"+ request.ProgramName +"' and #ProgramCode# != '"+request.ProgramCode+ "' and #DeletedFlag# = '0' limit 1";
                        string isDuplicate = string.Empty;
                        duplicateQuery = duplicateQuery.Replace('#', '"');

                        npgsqlCon.Open();

                        NpgsqlCommand checkDuplicacyCmd = new NpgsqlCommand(duplicateQuery, npgsqlCon);

                        NpgsqlDataReader npgsqlDataReaderDupcheck = checkDuplicacyCmd.ExecuteReader();

                        if (npgsqlDataReaderDupcheck.Read())
                        {
                            isDuplicate = npgsqlDataReaderDupcheck[0].ToString();
                        }
                        else
                        {
                            isDuplicate = string.Empty;
                        }

                        npgsqlCon.Close();

                        if (isDuplicate == "Yes")
                        {
                            response.responseCode = 0;
                            response.responseMessage = "Program name already exists!";
                            return response;
                        }
                    }
                   

                    //update Data ProgramMaster

                    string sqlQuery = "update public.#ProgramMaster# set #ProgramName# = '"+request.ProgramName+"' , #ProgramDescription# ='"+request.ProgramDescription+"' ,#IsMultiDays# = '"+request.IsMultiDays+"', #UpdatedBy# = '"+request.CreatedBy+"' , #UpdatedOn# = 'now()' , #UpdatedIPAddress# = '"+request.CreatedIPAddress+"' where #ProgramCode# = '"+request.ProgramCode+"';";


                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);
                   

                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("Update Program", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }
            if (request.action == "DELETE")
            {
                try
                {

                    //update -delete Data ProgramMaster

                    string sqlQuery = "update public.#ProgramMaster# set #DeletedFlag# = '1', #DeletedBy# = '" + request.DeletedBy + "' , #DeletedOn# = 'now()' , #DeletedIPAddress# = '" + request.DeletedIPAddress + "' where #ProgramCode# = '" + request.ProgramCode + "'; UPDATE #ProgramAssets# SET #isactive# = '0' WHERE #ProgramCode# = '" + request.ProgramCode + "'; UPDATE #ProgramAssetDetails# AS pasd SET #isactive# = '0' FROM #ProgramMaster# AS pm JOIN #ProgramAssets# AS pa ON pm.#ProgramCode# = pa.#ProgramCode# WHERE pm.#ProgramCode# = '" + request.ProgramCode + "' AND pa.#TID# = pasd.#ProgramAssetID#; ";


                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);


                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("delete Program", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            }

            return response;
        }
        public ResponseClass DeleteAssetLearningDetails(DeleteAssetLearningDetailsSTO request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
           
                try
                {

                    //update -delete Data ProgramAssetDetailMaster

                    string sqlQuery = "delete from public.#ProgramAssetDetails# where #TID# = '" + request.AssetDetailsID + "';";


                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);


                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("DeleteAssetLearningDetails", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            

            return response;
        }
        public ResponseClass DeleteAssetDay(DeleteAssetDayDTO request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
           
                try
                {

                    //update -delete Data ProgramAssetDetailMaster and ProgramAsset

                    string sqlQuery = "update public.#ProgramAssets# set #isactive# = '0' where #TID# = '" + request.AssetID + "'; update public.#ProgramAssetDetails# set #isactive# = '0' where #ProgramAssetID# = '" + request.AssetID + "';select fn_reorder_programday('" + request.AssetID + "'); ";


                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);


                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                catch (Exception ex)
                {
                    _serviceconnect.LogConnect("DeleteAssetDay", "1024", ex.Message, "Exception");
                    response.responseCode = 0;
                    response.responseMessage = ex.Message;
                }
            

            return response;
        }
        public ResponseClass GetProgramMasterList(ProgramMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = selectQuery + "select #ProgramCode# as #ProgramCode#, #ProgramName# as #ProgramName#, #IsMultiDays#  as #IsMultiDays# , concat(em.#FIRSTNAME#,' ',em.#LASTNAME#, ' (',em.#EXTERNALDATAREFERENCE#,')') as #CreatedBy#,cast(TO_CHAR(pm.#CreatedOn#, 'dd-Mon-yy') as character varying) as #CreatedOn#, (select count(*) as #AssetsCount#  from public.#ProgramAssets# as pa where pa.#ProgramCode# = pm.#ProgramCode# and pa.#isactive# = '1' ) from public.#ProgramMaster# as Pm left join public.#EmployeeMaster# em on  pm.#CreatedBy# = em.#EXTERNALDATAREFERENCE# where pm.#DeletedFlag# = '0' ";

                if (request.CurrentRole == "Program Manager")
                {
                     selectQuery = selectQuery + " and (Pm.#CreatedBy#='" + request.CreatedBy + "' or Pm.#CurrentRole#='Global Admin' ";

                      selectQuery = selectQuery + " or (Pm.#CurrentRole#='Geo Admin' and Pm.#CurrentRoleCompany# like '%" + request.CurrentRoleCompany + "%' )) ";
                   // selectQuery = selectQuery + " and Pm.#CreatedBy#='" + request.CreatedBy + "' and Pm.#CurrentRole#='" + request.CurrentRole + "'";

                }
                else if (request.CurrentRole == "Geo Admin")
                {
                    DataTable dtCompanies = new DataTable();
                    dtCompanies = _qualtricsBL.gtAssignedCompany(request.CreatedBy);
                   
                    selectQuery = selectQuery + " and (Pm.#CurrentRole#='Global Admin' ";

                    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    {
                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (Pm.#CurrentRole#='Geo Admin' and Pm.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }

                        foreach (DataRow exclude in dtCompanies.Rows)
                        {
                            selectQuery = selectQuery + " or (Pm.#CurrentRole#='Program Manager' and Pm.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                        }
                    }

                    selectQuery = selectQuery + " )";
                }

                selectQuery = selectQuery + "  order by pm.#CreatedOn# desc , pm.#ProgramName#;";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProgramMasterList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass ManageProgramMasterPaging(ProgramMasterDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();


                string pgsqlConnection = appSettings.Value.DbConnection;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_manage_program
                                                                        ( 
                                                                            :pcurrentemployeeid,
                                                                            :pcurrentemployeerole,:pusercompany,
                                                                            :p_pageno,:p_recordno,:pobjectcode
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.CreatedBy))
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = request.CreatedBy;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeeid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("pcurrentemployeerole", DbType.String).Value = DBNull.Value;

                       

                        if (!String.IsNullOrEmpty(request.CurrentRoleCompany))
                            cmd.Parameters.AddWithValue("pusercompany", DbType.String).Value = request.CurrentRoleCompany;
                        else
                            cmd.Parameters.AddWithValue("pusercompany", DbType.String).Value = DBNull.Value;



                        cmd.Parameters.AddWithValue("p_pageno", DbType.String).Value = request.PageNumber;
                        cmd.Parameters.AddWithValue("p_recordno", DbType.String).Value = request.RowsOfPage;

                        if (!String.IsNullOrEmpty(request.objectCode))
                            cmd.Parameters.AddWithValue("pobjectcode", DbType.String).Value = request.objectCode;
                        else
                            cmd.Parameters.AddWithValue("pobjectcode", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        //if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        //{


                        //    dtEmployees.Columns.Add("encryptedID");
                        //    CommonFunction function = new CommonFunction();

                        //    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        //    {
                        //        foreach (DataRow item in dtEmployees.Rows)
                        //        {
                        //            item["encryptedID"] = function.Encrypt(Convert.ToString(item["coursecode"]));
                        //        }
                        //    }
                        //}

                        if (request.GetMode == 0)
                        {
                            response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        }
                        else
                        {
                            response.dtresponse = dtEmployees;
                        }
                    }
                }


                if (dtEmployees != null)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    int recordcount = 1;
                    if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                    {
                        recordcount = Convert.ToInt32(dtEmployees.Rows[0]["recordcount"]);

                        if (request.PageNumber >0)
                        {


                            decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(recordcount) / request.RowsOfPage));

                            int recordPages = Convert.ToInt32(noOfPages);

                            if (noOfPages > recordPages)
                            {
                                recordPages = recordPages + 1;
                            }

                            response.recordCount = recordPages;
                        }
                    }
                }



                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ManageProgramMasterPaging", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetProgramLearningList(ProgramAssetLearningMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = selectQuery + "select pm.#IsMultiDays# as #IsMultiple#, pm.#ProgramName# as #ProgramName#, pa.#DayNo# as #NodeName# , pm.#ProgramCode# as #ProgramCode# ,pa.#TID# as #AssetID# ,(select count(*) from #ProgramAssetDetails# pad2 where pad2.#ProgramAssetID# = pa.#TID# and pad2.#isactive# = '1') as #LearningCount# from #ProgramMaster# pm join #ProgramAssets# as pa on pm.#ProgramCode# = pa.#ProgramCode# where pm.#DeletedFlag# = '0' and pa.#isactive# = '1' and pa.#ProgramCode# = '" + request.ProgramCode + "' order by pa.#DayNo# ;";

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProgramLearningList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetProgramLearningListByPRcodeAndAssetID(ProgramAssetDetailsLearningMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = selectQuery + "select pasd.#TID# as assetdetailid,pm.#IsMultiDays# as #IsMultiple#, pm.#ProgramName#  as #ProgramName# , pa.#DayNo# as #NodeName# , pm.#ProgramCode# as #ProgramCode# ,pa.#TID# as #AssetID#, pasd.#TID# as #AssetDetailsID#,pasd.#AssetType# as #LearningType#, pasd.#AssetName# as #LearningName# from #ProgramMaster# pm join #ProgramAssets# as pa on pm.#ProgramCode# = pa.#ProgramCode# join #ProgramAssetDetails# as pasd on pa.#TID# = pasd.#ProgramAssetID# where pm.#DeletedFlag# = '0' and pa.#isactive# = '1' and pasd.#isactive# = '1'  and pa.#ProgramCode# = '" + request.ProgramCode+"' and pa.#TID# = '"+request.AssetID+"'; ";

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProgramLearningList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetAllocateAssetDropDownDataByAssetID(insertEditProgramLearningRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = selectQuery + "select #AssetCode# as #ObjectCode# , #AssetName#  as #ObjectType# from #ProgramAssetDetails# where #AssetType# = '"+request.AssetType+"' and #ProgramAssetID# = '"+request.AssetID+"' and #isactive# = '1'";

                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProgramLearningList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetProgramMasterDataByProgramCode(ProgramMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select #ProgramCode# as #ProgramCode#, #ProgramName# as #ProgramName#, #IsMultiDays#  as #IsMultiDays# ,#ProgramDescription#  as #ProgramDescription#,  (select case when count(*)>0 then 'Block' else 'Edit' end as #EditAccess#  from #ProgramAssets# pa where pa.#ProgramCode#=pm.#ProgramCode#) from public.#ProgramMaster# as Pm where pm.#ProgramCode# = '" + request.ProgramCode + "';";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEventProcessDetail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass InsertEditProgramAsset(insertEditProgramLearningRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
                var sql = string.Empty;

                if (!string.IsNullOrWhiteSpace(request.ProgrameCode))
                {


                    //sql =  "  insert into #ProgramAssets#(#ProgramCode#, #DayNo#, #isactive#, #InsertedDateTime#) values('" + request.ProgrameCode + "', '" + request.DayNo + "', '1', 'now()')  returning #TID#;";

                    sql = "  WITH inserted_asset AS (insert into #ProgramAssets#(#ProgramCode#, #DayNo#, #isactive#, #InsertedDateTime#) values('" + request.ProgrameCode + "', '" + request.DayNo + "', '1', 'now()') ON CONFLICT(#ProgramCode#, #DayNo#) WHERE #isactive# = '1' DO NOTHING RETURNING #TID#) SELECT #TID#  FROM #inserted_asset# UNION ALL SELECT #TID#  FROM #ProgramAssets# WHERE #ProgramCode# = '" + request.ProgrameCode + "' AND #DayNo# = '" + request.DayNo + "' and #isactive# = '1'; ";



                    sql = sql.Replace('#', '"');

                        npgsqlCon.Open();

                        NpgsqlCommand cmd = new NpgsqlCommand(sql, npgsqlCon);

                        NpgsqlDataReader dataReader = cmd.ExecuteReader();
                        if (dataReader.Read())
                        {
                            request.AssetID = dataReader[0].ToString();
                        }

                        npgsqlCon.Close();
                        NpgsqlConnection.ClearPool(npgsqlCon);


                    

                    if (request.assetContent != null)
                    {
                        sql = "DROP TABLE IF EXISTS #temp_assetcontent#; CREATE TABLE #temp_assetcontent#(contentcode VARCHAR(300),contenttxt VARCHAR(500));";

                        sql = sql + "insert into #temp_assetcontent#(contentcode,contenttxt)select split_part(sprocess, ':', 1),split_part(sprocess, ':', 2)from(SELECT unnest(string_to_array('" + request.assetContent + "', ',')) AS sprocess) PR;";

                        sql = sql + "update #ProgramAssetDetails#  set #isactive# = 0 where #AssetType# = '" + request.AssetType + "' and #ProgramAssetID# = '" + request.AssetID + "' and #AssetCode# not in (select distinct #contentcode# from #temp_assetcontent#);";
                        
                        sql = sql + "insert into #ProgramAssetDetails#(#ProgramAssetID#, #AssetCode#, #AssetName#, #InsertedDateTime#, #isactive#,#AssetType#) select '" + request.AssetID + "', #contentcode#, REPLACE(#contenttxt#, '~', ',') , 'now()','1','" + request.AssetType+"' from #temp_assetcontent# where #contentcode# not in (select #AssetCode# from  #ProgramAssetDetails# where #ProgramAssetID# = '"+request.AssetID+"' and #isactive# = '1' ) ;";
                    }


                    //sql = sql + " update #ProgramMaster# set #UpdatedBy# = '" + request.InsertedBy + "' , #UpdatedOn# = 'now()', #UpdatedIPAddress# = '" + request.InsertedIPAddress + "' where #ProgramCode# = '" + request.ProgrameCode + "'; ";

                 
                        sql = sql.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd2 = new NpgsqlCommand(sql, npgsqlCon);

                    NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                    npgsqlCon.Close();
                    NpgsqlConnection.ClearPool(npgsqlCon);                   

                    response.responseCode = 1;
                    response.responseMessage = "Success";


                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditProgramAsset", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }

        public ResponseClass insertProgramDependency(inserteditprogramdependencyrequestDTO request)
        {
            //DataTable response = new DataTable();
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            try
            {

                string pgsqlConnection = appSettings.Value.DbConnection;

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_program_dependency
                                                                        ( 
                                                                            :pprogramcode,
                                                                            :pinsertedby,:pinsertedipaddress,:pdependency_content
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ProgramCode))
                            cmd.Parameters.AddWithValue("pprogramcode", DbType.String).Value = request.ProgramCode;
                        else
                            cmd.Parameters.AddWithValue("pprogramcode", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.DependencyContent))
                            cmd.Parameters.AddWithValue("pdependency_content", DbType.String).Value = request.DependencyContent;
                        else
                            cmd.Parameters.AddWithValue("pdependency_content", DbType.String).Value = string.Empty;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                         response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);


                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("allocateBusinessTraining", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetProgramDependencyList(ProgramAssetDetailsLearningMasterDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();
                string selectQuery = string.Empty;

                //selectQuery = selectQuery + "select pasd.#TID# as assetdetailid,pm.#IsMultiDays# as #IsMultiple#, pm.#ProgramName#  as #ProgramName# , pa.#DayNo# as #NodeName# , pm.#ProgramCode# as #ProgramCode# ,pa.#TID# as #AssetID#, pasd.#TID# as #AssetDetailsID#,pasd.#AssetType# as #LearningType#, pasd.#AssetName# as #LearningName# from #ProgramMaster# pm join #ProgramAssets# as pa on pm.#ProgramCode# = pa.#ProgramCode# join #ProgramAssetDetails# as pasd on pa.#TID# = pasd.#ProgramAssetID# where pm.#DeletedFlag# = '0' and pa.#isactive# = '1' and pasd.#isactive# = '1'  and pa.#ProgramCode# = '" + request.ProgramCode + "' and pa.#TID# = '" + request.AssetID + "'; ";
                selectQuery = " select pasd.#TID# as assetdetailid,pasd.#AssetType# as #LearningType#, pasd.#AssetName# as #LearningName#,Coalesce(pad.#DependencyAssets#,'') as dependencyassets from #ProgramMaster# pm join #ProgramAssets# as pa on pm.#ProgramCode# = pa.#ProgramCode# join #ProgramAssetDetails# as pasd on pa.#TID# = pasd.#ProgramAssetID# left join #ProgramAssetDependency# as pad on pad.#AssetDetailID# = pasd.#TID# where pm.#DeletedFlag# = '0' and pa.#isactive# = '1' and pasd.#isactive# = '1'  and pa.#ProgramCode# = '" + request.ProgramCode + "' and pa.#TID# = '" + request.AssetID + "' order by pasd.#TID#; "; 
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProgramLearningList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

    }
}
