﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Service;
using static TLDCBAL.ProgramManager.MarkAttendanceDTO;

namespace TLDCBAL.ProgramManager
{
    public class MarkAttendanceBL : IMarkAttendanceBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        public MarkAttendanceBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect)
        {
            appSettings = app;
            _serviceconnect = serviceconnect;
        }
        public ResponseClass InsertEditMarkAttendance(AddUpdatePTSAttendance request)
        {
            ResponseClass response = new ResponseClass();
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);
            try
            {
                foreach (var item in request.ptsAttendanceList)
                {
                    int isEmployeePresent = 0;
                    // check by date and employeeid and session
                    string sqlQuery12 = "select count(*) from public.#ProcessTrainingSessionAttendance# where #ParticipantEmpCode#='" + item.ParticipantEmpCode + "' and #AttendanceDate#='" + request.AttendanceDate + "'and #SessionID#='" + request.SessionID + "'";
                    sqlQuery12 = sqlQuery12.Replace('#', '"');
                    npgsqlCon.Open();
                    NpgsqlCommand npgsqlCommand12 = new NpgsqlCommand(sqlQuery12, npgsqlCon);
                    NpgsqlDataReader npgsqlDataReader12 = npgsqlCommand12.ExecuteReader();
                    if (npgsqlDataReader12.Read())
                    {
                        isEmployeePresent = Convert.ToInt32(npgsqlDataReader12[0]);
                    }
                    npgsqlCon.Close();
                    //if presend 
                    if (isEmployeePresent > 0)
                    {
                        //update
                        string sqlQuery31 = "UPDATE public.#ProcessTrainingSessionAttendance# SET #IsPresent#='" + item.IsPresent + "',#AbsenceReason#='" + item.AbsenceReason + "',#EWSReasonCode#='" + item.EWSReasonCode + "',#EWSStatus#='" + item.EWSStatus + "',#LearnerRating#='" + item.LearnerRating + "',#Remark#='" + item.Remark + "',#UpdatedBy#='" + request.InsertUpdatedBy + "',#UpdatedDate#=now() WHERE #SessionID# = '" + request.SessionID + "' and #AttendanceDate# = '" + request.AttendanceDate + "' and #ParticipantEmpCode# = '" + item.ParticipantEmpCode + "'";

                        sqlQuery31 = sqlQuery31.Replace('#', '"');

                        npgsqlCon.Open();

                        NpgsqlCommand cmd31 = new NpgsqlCommand(sqlQuery31, npgsqlCon);

                        NpgsqlDataReader dataReader = cmd31.ExecuteReader();

                        npgsqlCon.Close();

                    }
                    else     //insert new
                    {
                        //Insert Data ProcessTrainingSessionAttendance

                        string sqlQuery = "INSERT INTO public.#ProcessTrainingSessionAttendance#(#SessionID#,#AttendanceDate#,#ParticipantEmpCode#,#IsPresent#,#AbsenceReason#,#EWSReasonCode#,#EWSStatus#,#LearnerRating#,#Remark#,#CreatedBy#,#CreatedDate#,#DeletedFlag#) " + "VALUES('" + request.SessionID + "', '" + request.AttendanceDate + "', '" + item.ParticipantEmpCode + "', '" + item.IsPresent + "', '" + item.AbsenceReason + "', '" + item.EWSReasonCode + "', '" + item.EWSStatus + "', '" + item.LearnerRating + "', '" + item.Remark + "', '" + request.InsertUpdatedBy + "', now(), 0)";

                        sqlQuery = sqlQuery.Replace('#', '"');

                        npgsqlCon.Open();

                        NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                        NpgsqlDataReader dataReader = cmd.ExecuteReader();

                        npgsqlCon.Close();
                    }
                }

                int isDataPresent = 0;
                // check by date and session
                string sqlQuery123 = "select count(*) from public.#ProcessTrainingSessionRemarks# where #AttendanceDate#='" + request.AttendanceDate + "'and #SessionID#='" + request.SessionID + "'";
                sqlQuery123 = sqlQuery123.Replace('#', '"');
                npgsqlCon.Open();
                NpgsqlCommand npgsqlCommand123 = new NpgsqlCommand(sqlQuery123, npgsqlCon);
                NpgsqlDataReader npgsqlDataReader123 = npgsqlCommand123.ExecuteReader();
                if (npgsqlDataReader123.Read())
                {
                    isDataPresent = Convert.ToInt32(npgsqlDataReader123[0]);
                }
                npgsqlCon.Close();
                //if presend 
                if (isDataPresent > 0)
                {
                    //update ProcessTrainingSessionRemarks
                    string sqlQuery3 = "UPDATE public.#ProcessTrainingSessionRemarks# SET #DayRemarks#='" + request.DayRemarks + "',#OverAllRemarks#='" + request.OverAllRemarks + "',#UpdatedDate#=now(),#UpdatedBy#='" + request.InsertUpdatedBy + "' WHERE #SessionID# = '" + request.SessionID + "' and #AttendanceDate# = '" + request.AttendanceDate + "'";

                    sqlQuery3 = sqlQuery3.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd3 = new NpgsqlCommand(sqlQuery3, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd3.ExecuteReader();

                    npgsqlCon.Close();

                }
                else     //insert new
                {
                    //Insert Data ProcessTrainingSessionRemarks

                    string sqlQuery = "INSERT INTO public.#ProcessTrainingSessionRemarks#(#SessionID#,#DayRemarks#,#OverAllRemarks#,#CreatedBy#,#CreatedDate#,#DeletedFlag#,#AttendanceDate#) " + "VALUES('" + request.SessionID + "', '" + request.DayRemarks + "', '" + request.OverAllRemarks + "', '" + request.InsertUpdatedBy + "',now(), 0 ,'" + request.AttendanceDate + "')";

                    sqlQuery = sqlQuery.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                    NpgsqlDataReader dataReader = cmd.ExecuteReader();

                    npgsqlCon.Close();
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ProcessTrainingSessionRemarks", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            return response;
        }
        public ResponseClass GetDateListForMarkAttendance(AttendanceDates request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;
                if (request.AttendanceLevel == "Event Level")
                {
                    selectQuery = "select TO_CHAR(PSC.#EndDate#, 'dd-Mon-yyyy') as AttendanceDate,COALESCE(attendance.attendancecount,0) as attendancecount from #ProcessTrainingSessionCalendar# PSC ";
                   
                    selectQuery = selectQuery + " left join ";
                    selectQuery = selectQuery + " ( ";
                    selectQuery = selectQuery + "  select #SessionID#,#AttendanceDate#,count(#TID#) as attendancecount ";
                    selectQuery = selectQuery + "  from #ProcessTrainingSessionAttendance# ";
                    selectQuery = selectQuery + "   group by #SessionID#,#AttendanceDate# ";
                    selectQuery = selectQuery + " ) attendance on attendance.#SessionID# = PSC.#SessionID# ";
                    selectQuery = selectQuery + " and PSC.#StartDate#= attendance.#AttendanceDate# ";
                    selectQuery = selectQuery + " where PSC.#DeletedFlag#=0 ";
                    selectQuery = selectQuery + " and PSC.#SessionID#='" + request.SessionID + "' limit 1";
                }
                else
                {
                    selectQuery = "select distinct TO_CHAR(PSC.#StartDate#, 'dd-Mon-yyyy') as AttendanceDate,PSC.#StartDate#,COALESCE(attendance.attendancecount,0) as attendancecount from #ProcessTrainingSessionCalendar# PSC ";
                    selectQuery = selectQuery + " left join ";
                    selectQuery = selectQuery + " ( ";
                    selectQuery = selectQuery + "  select #SessionID#,#AttendanceDate#,count(#TID#) as attendancecount ";
                    selectQuery = selectQuery + "  from #ProcessTrainingSessionAttendance# ";
                    selectQuery = selectQuery + "   group by #SessionID#,#AttendanceDate# ";
                    selectQuery = selectQuery + " ) attendance on attendance.#SessionID# = PSC.#SessionID# ";
                    selectQuery = selectQuery + " and PSC.#StartDate#= attendance.#AttendanceDate# ";
                    selectQuery = selectQuery + " where PSC.#DeletedFlag#=0 ";
                    selectQuery = selectQuery + " and PSC.#SessionID#='" + request.SessionID + "' order by PSC.#StartDate#";
                }

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetDateListForMarkAttendance", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetEWSReason(EWSReasonSession request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "SELECT F.#TID# as tid, F.#EWSReason# as ewsreason FROM public.#EWSReason# F where F.#DeletedFlag#=0 order by F.#EWSReason#";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEWSReason", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetEWSStatus(EWSStatusSession request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "SELECT F.#EWSReason# as ewsreason, F.#EWSStatus# as ewsstatus FROM public.#EWSStatus# F where F.#DeletedFlag#=0 and F.#EWSReason#='" + request.EWSReason + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEWSStatus", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetAttendanceAbsentReason(AttendanceAbsentReasonSession request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "SELECT F.#TID# as tid, F.#AttendanceAbsentReason# as attendanceabsentreason FROM public.#AttendanceAbsentReason# F where F.#DeletedFlag#=0 order by F.#AttendanceAbsentReason#";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetAttendanceAbsentReason", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetAttendanceData(AddUpdatePTSAttendance request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                // get recors from ProcessTrainingSessionRemarks
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                //selectQuery = "select A.#EmployeeCode#,coalesce(PTSA.#IsPresent#,'') as AttendanceStatus,coalesce(PTSA.#AbsenceReason#,'') as AbsenceReason,coalesce(PTSA.#EWSReasonCode#,'') as EWSReasonCode,coalesce(PTSA.#EWSStatus#,'') as EWSStatus,coalesce(PTSA.#LearnerRating#,0) as LearnerRating,coalesce(PTSA.#Remark#,'') as Remark,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as employeename from #ClassEmployeeAttendance# A inner join #ProcessTrainingMaster# PTM on PTM.#ClassRoomCode#=A.#ClassRoomCode# inner join #ProcessTrainingSession# PTS on PTS.#ProcessTrainingCode#=PTM.#ProcessTrainingCode# left join #ProcessTrainingSessionAttendance# PTSA on PTSA.#SessionID#=PTS.#SessionID# and PTSA.#AttendanceDate#='" + request.AttendanceDate + "' and PTSA.#ParticipantEmpCode#=A.#EmployeeCode# left join #EmployeeMaster# EM on A.#EmployeeCode# = EM.#EXTERNALDATAREFERENCE# where A.#ClassRoomCode#='" + request.AttendanceDate + "' and PTM.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "' and PTS.#SessionID#='" + request.SessionID + "' and A.#EmployeeCode# is not null";
                // selectQuery = "select distinct a.#ClassRoomCode#,r.#DayRemarks#,r.#OverAllRemarks#,r.#AttendanceDate# from #ClassEmployeeAttendance# a inner join public.#ProcessTrainingMaster# p on a.#ClassRoomCode#=p.#ClassRoomCode# and p.#DeletedFlag#=0 inner join public.#ProcessTrainingSession# ts on p.#ProcessTrainingCode#=ts.#ProcessTrainingCode# inner join public.#ProcessTrainingSessionRemarks# r on r.#SessionID#=ts.#SessionID# where a.#ClassRoomCode#='" + request.ClassRoomCode + "' and p.#DeletedFlag#=0 and ts.#DeletedFlag#=0 and ts.#SessionID#='" + request.SessionID + "' and ts.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "' and r.#AttendanceDate#='" + request.AttendanceDate + "'";
                selectQuery = "select distinct a.#ObjectCode# as ClassRoomCode,r.#DayRemarks#,r.#OverAllRemarks#,r.#AttendanceDate# from #vw_classroom_employee# a inner join public.#ProcessTrainingMaster# p on a.#ObjectCode#=p.#ClassRoomCode# and p.#DeletedFlag#=0 inner join public.#ProcessTrainingSession# ts on p.#ProcessTrainingCode#=ts.#ProcessTrainingCode# inner join public.#ProcessTrainingSessionRemarks# r on r.#SessionID#=ts.#SessionID# where a.#ObjectCode#='" + request.ClassRoomCode + "' and p.#DeletedFlag#=0 and ts.#DeletedFlag#=0 and ts.#SessionID#='" + request.SessionID + "' and ts.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "' and r.#AttendanceDate#='" + request.AttendanceDate + "'";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);
                response.responseJSONSecondary = JsonConvert.SerializeObject(ProcessTrainingSessionData(request.SessionID, request.ProcessTrainingCode, request.AttendanceDate, request.ClassRoomCode));

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetAttendanceData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public DataTable ProcessTrainingSessionData(string sessionid, string ptc, string attendancedate, string classroomcode)
        {
            DataTable model = new DataTable();
            try
            {
               
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_getprocess_session_attendance_by_date
                                                                        ( 
                                                                            :p_classcode,
                                                                            :p_trainingcode,:p_session,:p_attendancedate
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(classroomcode))
                            cmd.Parameters.AddWithValue("p_classcode", DbType.String).Value = classroomcode;
                        else
                            cmd.Parameters.AddWithValue("p_classcode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(ptc))
                            cmd.Parameters.AddWithValue("p_trainingcode", DbType.String).Value = ptc;
                        else
                            cmd.Parameters.AddWithValue("p_trainingcode", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(sessionid))
                            cmd.Parameters.AddWithValue("p_session", DbType.String).Value = sessionid;
                        else
                            cmd.Parameters.AddWithValue("p_session", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(attendancedate))
                            cmd.Parameters.AddWithValue("p_attendancedate", DbType.String).Value = attendancedate;
                        else
                            cmd.Parameters.AddWithValue("p_attendancedate", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(model);
                        npgsqlConnection.Close();

                    }
                }
                return model;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ProcessTrainingSessionData", "1024", ex.Message, "Exception");
               
            }

            return model;
        }

        //public DataTable ProcessTrainingSessionData(string sessionid, string ptc, string attendancedate, string classroomcode)
        //{
        //    ResponseClass response = new ResponseClass();

        //    DataTable model = new DataTable();
        //    try
        //    {
        //        string selectQuery = string.Empty;
        //        //selectQuery = "select distinct ta.#ParticipantEmpCode#,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as employeename,a.#ClassRoomCode#,ta.#AbsenceReason#,ta.#AttendanceDate#,ta.#EWSStatus#,ta.#EWSReasonCode#,ta.#IsPresent#,ta.#LearnerRating#,ta.#ParticipantEmpCode#,ta.#Remark# from #ClassEmployeeAttendance# a inner join public.#ProcessTrainingMaster# p on a.#ClassRoomCode#=p.#ClassRoomCode# and p.#DeletedFlag#=0 inner join public.#ProcessTrainingSession# ts on p.#ProcessTrainingCode#=ts.#ProcessTrainingCode# inner join public.#ProcessTrainingSessionAttendance# ta on ts.#SessionID#=ta.#SessionID# inner join public.#EmployeeMaster# EM on ta.#ParticipantEmpCode# = EM.#EXTERNALDATAREFERENCE# where a.#ClassRoomCode#='" + classroomcode + "' and p.#DeletedFlag#=0 and ts.#DeletedFlag#=0 and ts.#SessionID#='" + sessionid + "' and ts.#ProcessTrainingCode#='" + ptc + "' and ta.#AttendanceDate#='" + attendancedate + "'";
        //        selectQuery = "select A.#empcode# as EmployeeCode,coalesce(PTSA.#IsPresent#,'') as AttendanceStatus,coalesce(PTSA.#AbsenceReason#,'') as AbsenceReason,coalesce(PTSA.#EWSReasonCode#,'') as EWSReasonCode,coalesce(PTSA.#EWSStatus#,'') as EWSStatus,coalesce(PTSA.#LearnerRating#,0) as LearnerRating,coalesce(PTSA.#Remark#,'') as Remark,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#) as employeename from #vw_classroom_employee# A inner join #ProcessTrainingMaster# PTM on PTM.#ClassRoomCode#=A.#ObjectCode# inner join #ProcessTrainingSession# PTS on PTS.#ProcessTrainingCode#=PTM.#ProcessTrainingCode# left join #ProcessTrainingSessionAttendance# PTSA on PTSA.#SessionID#=PTS.#SessionID# and PTSA.#AttendanceDate#='" + attendancedate + "' and PTSA.#ParticipantEmpCode#=A.#empcode# left join #EmployeeMaster# EM on A.#empcode# = EM.#EXTERNALDATAREFERENCE# where A.#ObjectCode#='" + classroomcode + "' and PTM.#ProcessTrainingCode#='" + ptc + "' and PTS.#SessionID#='" + sessionid + "' and A.#empcode# is not null and A.#addeddate#<='" + attendancedate + "'";
        //        selectQuery = selectQuery.Replace('#', '"');

        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(model);
        //        npgsql.Close();
        //        //response.responseCode = 1;
        //        //response.responseJSON = JsonConvert.SerializeObject(videoHeightlightmodel);
        //        return model;
        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("ProcessTrainingSessionData", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return model;
        //}
    }
}
