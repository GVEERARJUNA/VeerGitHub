﻿using TLDCBAL.Common;

namespace TLDCBAL.ProgramManager
{
    public interface IExpressEventBL
    {
        ResponseClass ManageExpressEvent(manageEventrequestDTO request);

        ResponseClass GetExpressEventListView(manageEventrequestDTO request);
        ResponseClass InsertEditExpressEvent(insertEditEventRequestDTO request);
        ResponseClass InsertEditEventbyClassRoom(insertEditEventRequestDTO request);

        ResponseClass GetAdminDashboardcount(getadmindashboardcount request);
        ResponseClass GetProgramManagerToDo(getadmindashboardcount request);

        ResponseClass eventdashboardCount(eventdashboardCountrequetDTO request);

        ResponseClass eventtaskProgress(eventdashboardCountrequetDTO request);
        ResponseClass eventdashboarddetails(eventdashboardCountrequetDTO request);

        ResponseClass insertWIPrequest(insertWIPrequestDTO request);

        ResponseClass insertWIPOptedrequest(insertWIPrequestDTO request);
        ResponseClass GetTeamLeadPendingTask(TeamLeadPendingTaskDTO request);
        ResponseClass GetTeamLeadEmployeePendingTaskList(TeamLeadPendingTaskDTO request);
        ResponseClass GetReportEvent(manageEventrequestDTO request);

        ResponseClass GetTotalPendingActivity(TeamLeadPendingTaskDTO request);
        ResponseClass GetTotalPendingActivityPaging(TeamLeadPendingTaskDTO request);
        ResponseClass GetRequisitionUsers(RequestionDTO request);

        ResponseClass EventPermanantDelete(eventdeleterequestDTO request);
        ResponseClass GetEventAllocationCount(eventdeleterequestDTO request);

        ResponseClass GetProgramDashboardCount(getprogramdashboardcountrequestdto request);
        ResponseClass getEventDays(getprogramdashboardcountrequestdto request);

        ResponseClass ProgramDashboardDetailData(getprogramdashboardcountrequestdto request);

        ResponseClass eventdashboarddetailsassessment(eventdashboardCountrequetDTO request);

    }
}