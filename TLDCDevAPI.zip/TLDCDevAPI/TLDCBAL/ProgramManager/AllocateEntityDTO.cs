﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ProgramManager
{
    public class AllocateEntityInsertRequestDto
    {
        public string Subprocess { get; set; }
        public string TrainingGroup { get; set; }
        public string Roles { get; set; }
        public string EmployeeCodes { get; set; }
        public string CompanyCodes { get; set; }
        public string ObjectType { get; set; }
        public string ObjectCode { get; set; }

        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public string action { get; set; }
    }
    public class manageallocateEntityRequestDTO
    {
        public string ObjectType { get; set; }
        public string ObjectCode { get; set; }
    }

    public class getAllocateEntityDropDownDataDTO
    {
        public string objectType { get; set; }
        public string objectCode { get; set; }

        public string Geo { get; set; }

        public string EmpCode { get; set; }

        public string LoginEMPCode { get; set; }

        public string currentRole { get; set; }

        public string UserCompany { get; set; }

    }

    public class assessmentlistresponseData
    {
        public ListData Data { get; set; }
        public string ResponseMessage { get; set; }

        public string ResponseCode { get; set; }
    }
    public class ListData
    {
        public List<assessmentList> Data { get; set; }
    }
    public class assessmentList
    {
        public int  AssessmentID { get; set; }
        public string AssessmentName { get; set; }
          
    }
    //public class TLDEnvelope
    //{
    //    public bool Status { get; set; }
    //    public string ResponseMessage { get; set; }
    //    public SurveyDetailsListViewModel Data { get; set; }
    //    public int TotalRecords { get; set; }
    //}
    public class TLDEnvelope
    {
        public bool Status { get; set; }
        public string ResponseMessage { get; set; }
        public TemplateDetailsListViewModel Data { get; set; }
        public int TotalRecords { get; set; }
    }

    public class TemplateDetailsListViewModel
    {
        public List<TemplateDetailsDataModel> Data { get; set; }
    }
    public class SurveyDetailsDataModel
    {
        public int SurveyId { get; set; }
        public int UserId { get; set; }

        public string SurveyName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string SurveyStatus { get; set; }
        public string LoggedInEmployeeId { get; set; }
        public List<string> LstEmployeeIds { get; set; }

    }

    public class TemplateDetailsDataModel
    {
        public int TemplateId { get; set; }
        public string TemplateName { get; set; }
        public string LoggedInEmployeeId { get; set; }
        public int UserId { get; set; }


    }
    public class surveyAllocationRequestDTO
    {
        public int SurveyId { get; set; }
        public string LoggedInEmployeeId { get; set; }
        public List<string> LstEmployeeIds { get; set; }

    }

    public class surveyAllocationResponseDTO
    {
        public bool status { get; set; }
        public string responseMessage { get; set; }
        

    }

    public class pushSurveyResultrequestDTO
    {
        public string AllocationID { get; set; }
        public string completionStatus { get; set; }

        public string SurveyStartDate { get; set; }
        public string SurveyEndDate { get; set; }
        public int TotalQuestion { get; set; }
        public int TotalSubmitted { get; set; }
    }

    public class SurveyInsertRequestDTO
    {
        public string LoggedInEmployeeId { get; set; }
        public string TemplateId { get; set; }
        public string TemplateName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

    }

    public class SurveyDetailsData
    {
        public bool status { get; set; }
        public string responseMessage { get; set; }

        public SurveyDetailsResponse data { get; set; }
    }

    public class SurveyDetailsResponse
    {
        public int SurveyId { get; set; }
        public int UserId { get; set; }

        public string SurveyName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string SurveyStatus { get; set; }
        public string LoggedInEmployeeId { get; set; }
        public List<string> LstEmployeeIds { get; set; }
        public int TemplateId { get; set; }
        public string TemplateName { get; set; }

    }

    public class getEntityName
    {
        public string objectCode { get; set; }
        public string objectType { get; set; }
    }

    public class deleteeventallocationrequestDTO
    {
        public string RecordID { get; set; }
        public string objectCode { get; set; }
        public string objectType { get; set; }
    }

    public class getrequistionnorequestDTO
    {
        public string employeeID { get; set; }
        public string currentrole { get; set; }
        public string CompanyCode { get; set; }
        // public string employeeID { get; set; }
    }
    //ODPM
    public class TLDQuesEnvelope
    {
        public bool Status { get; set; }
        public string ResponseMessage { get; set; }
        public TemplateQuesListViewModel Data { get; set; }
        public int TotalRecords { get; set; }
    }

    public class TemplateQuesListViewModel
    {
        public List<TemplateQuesDataModel> Data { get; set; }
    }

    public class TemplateQuesDataModel
    {
        public int TemplateId { get; set; }
        public string TemplateName { get; set; }
        public string LoggedInEmployeeId { get; set; }
        public int questionId { get; set; }

        public string question { get; set; }
        public int responseTypeId { get; set; }
        public string responseType { get; set; }
        public int masterHeadingId { get; set; }
        public string masterHeading { get; set; }
        public string isQuestionMandatory { get; set; }
    }
    public class savefeedbackDTO
    {
        public int SurveyId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int TemplateId { get; set; }
        public string TemplateName { get; set; }
        public string LoggedInEmployeeId { get; set; }
      

    }
    public class ODPMSurveyDetailsData
    {
        public bool status { get; set; }
        public string responseMessage { get; set; }

        public SurveyDetailsResponse data { get; set; }
    }

    public class ODPMSurveyDetailsResponse
    {
        public int SurveyId { get; set; }
        public int UserId { get; set; }

        public string SurveyName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string SurveyStatus { get; set; }
        public string LoggedInEmployeeId { get; set; }
        public List<string> LstEmployeeIds { get; set; }
        public int TemplateId { get; set; }
        public string TemplateName { get; set; }

    }

}
