﻿using TLDCBAL.Common;

namespace TLDCBAL.ProgramManager
{
    public interface IClassRoomTrainingBL
    {
        ResponseClass ManageClassRoomTraining(manageClassRoomrequestDTO request);

        ResponseClass GetClassRoomListView(manageClassRoomrequestDTO request);
        ResponseClass insertEditClassRoom(insertEditClassRoomRequestDTO request);

        ResponseClass getAssignedEntityDropDownData(getAssignedEntityDropDownDataDTO request);

        ResponseClass insertEditClassRoomEntity(insertEditClassRoomEntity request);
        ResponseClass getAssignedEntityDetailedData(getAssignedEntityDropDownDataDTO request);

        ResponseClass DeleteClassRoomEntity(deleteClassRoomEntityRequest request);
        ResponseClass GetClassRoomEntitycount(getclassroomentitycount request);
        ResponseClass GetClassRoomEntityHeadercount(getclassroomentitycount request);
        ResponseClass publishClassRoomEntity(allocateClassRoomrequestDTO request);

        ResponseClass publishClassRoomEntitySingle(allocateClassRoomrequestDTO request);
        ResponseClass getclassroomdashboarddata(classroomdashboardrequestdto request);
        ResponseClass getdashboarddetailedentity(classroomdashboardrequestdto request);
        ResponseClass getclassdashboarddaywiseactivities(classroomdashboardrequestdto request);

        ResponseClass getclassdashboardemployeewisedetail(classroomdashboardrequestdto request);

        ResponseClass CertificateListClass(getcertificatelistclass request);
    }
}