﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Service;
using static TLDCBAL.ProgramManager.ProcessTrainingDTO;

namespace TLDCBAL.ProgramManager
{
    public class ProcessTrainingBL : IProcessTrainingBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        private IQualtricsDataBL _qualtricsBL;

        public ProcessTrainingBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;

            _qualtricsBL = qualtricsBL;
        }

        public ResponseClass ManageProcessTraining(manageProcessTrainingDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select PT.#TID# as TID,PT.#ProcessTrainingCode# as ProcessTrainingCode,PT.#TrainingName# as TrainingName,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#,' (',EM.#EXTERNALDATAREFERENCE#,')') as CreatedBy, null as Allocated, null as Completed, null as TrainingStatus,TO_CHAR(PT.#CreatedOn#, 'dd-Mon-yyyy') as CreatedDate from #ProcessTrainingMaster# PT inner join #EmployeeMaster# EM on PT.#CreatedBy# = EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " where (CM.#DeletedFlag#)=0";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageProcessTraining", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass InsertEditProcessTraining(addupdateProcessTrainingDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                if (request.Action=="ADD")
                {
                    bool checkValue = false;
                    checkValue = checkName(request.TrainingName, "Training");
                    if (checkValue == true)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Training with same name already exist!";
                        return response;
                    }
                }
                

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_process_training
                                                                        ( 
                                                                            :p_process_training_code,
                                                                            :trainingname,
                                                                            :trainingadministrator,
                                                                            :instructorrequire,
                                                                            :externalinstructor,
                                                                            :attendancerequire,
                                                                            :attendancelevel,
                                                                            :processtrainingtype,
                                                                            :classroomcode,
                                                                            :singlesessionevent,
                                                                            :Instructor_code,
                                                                            :p_action,
                                                                            :pinsertedby,
                                                                            :deletedflag
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ProcessTrainingCode))
                            cmd.Parameters.AddWithValue("p_process_training_code", DbType.String).Value = request.ProcessTrainingCode;
                        else
                            cmd.Parameters.AddWithValue("p_process_training_code", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.TrainingName))
                            cmd.Parameters.AddWithValue("trainingname", DbType.String).Value = request.TrainingName;
                        else
                            cmd.Parameters.AddWithValue("trainingname", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.TrainingAdministrator))
                            cmd.Parameters.AddWithValue("trainingadministrator", DbType.String).Value = request.TrainingAdministrator;
                        else
                            cmd.Parameters.AddWithValue("trainingadministrator", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InstructorRequire))
                            cmd.Parameters.AddWithValue("instructorrequire", DbType.String).Value = request.InstructorRequire;
                        else
                            cmd.Parameters.AddWithValue("instructorrequire", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.ExternalInstructor))
                            cmd.Parameters.AddWithValue("externalinstructor", DbType.String).Value = request.ExternalInstructor;
                        else
                            cmd.Parameters.AddWithValue("externalinstructor", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.AttendanceRequire))
                            cmd.Parameters.AddWithValue("attendancerequire", DbType.String).Value = request.AttendanceRequire;
                        else
                            cmd.Parameters.AddWithValue("attendancerequire", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.AttendanceLevel))
                            cmd.Parameters.AddWithValue("attendancelevel", DbType.String).Value = request.AttendanceLevel;
                        else
                            cmd.Parameters.AddWithValue("attendancelevel", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.ProcessTrainingType))
                            cmd.Parameters.AddWithValue("processtrainingtype", DbType.String).Value = request.ProcessTrainingType;
                        else
                            cmd.Parameters.AddWithValue("processtrainingtype", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.ClassRoomCode))
                            cmd.Parameters.AddWithValue("classroomcode", DbType.String).Value = request.ClassRoomCode;
                        else
                            cmd.Parameters.AddWithValue("classroomcode", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.SingleSessionEvent))
                            cmd.Parameters.AddWithValue("singlesessionevent", DbType.String).Value = request.SingleSessionEvent;
                        else
                            cmd.Parameters.AddWithValue("singlesessionevent", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.ProcessTrainingInsList))
                            cmd.Parameters.AddWithValue("Instructor_code", DbType.String).Value = request.ProcessTrainingInsList;
                        else
                            cmd.Parameters.AddWithValue("Instructor_code", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.CreatedUpdatedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.CreatedUpdatedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (request.deletedflag != 0)
                            cmd.Parameters.AddWithValue("deletedflag", DbType.Int32).Value = request.deletedflag;
                        else
                            cmd.Parameters.AddWithValue("deletedflag", DbType.Int32).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditProcessTraining", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass EditProcessTraining(addupdateProcessTrainingDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable model = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select * from public.#ProcessTrainingMaster# vm where vm.#DeletedFlag# =0 and vm.#ProcessTrainingCode# ='" + request.ProcessTrainingCode + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(model);
                npgsql.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(model);
                response.responseJSONSecondary = JsonConvert.SerializeObject(EditProcessTrainingInstructor(request.ProcessTrainingCode));

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditProcessTraining", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public DataTable EditProcessTrainingInstructor(string processtrainingcode)
        {
            ResponseClass response = new ResponseClass();

            DataTable model = new DataTable();
            try
            {
                string selectQuery = string.Empty;
                // selectQuery = "select * from public.#ProcessTrainingInstructor# vm where #ProcessTrainingCode# ='" + processtrainingcode + "'";
                selectQuery = "select * from public.#ProcessTrainingInstructor# vm left outer join #EmployeeMaster# EM on vm.#InstructorEmpCode# = EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " where vm.#DeletedFlag#=0 and vm.#ProcessTrainingCode# ='" + processtrainingcode + "'";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(model);
                npgsql.Close();
                //response.responseCode = 1;
                //response.responseJSON = JsonConvert.SerializeObject(videoHeightlightmodel);
                return model;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("EditProcessTrainingInstructor", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return model;
        }
        public ResponseClass GetProcessInstructor(ProcessInstructorDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                //selectQuery = "SELECT PIM.#TID# as tid, PIM.#InstructorCode# as instructorcode,PIM.#InstructorFName# as instructorfname,PIM.#InstructorLName# as instructorlname FROM public.#ProcessInstructorMaster# PIM";
                //selectQuery = selectQuery + " where (PIM.#DeletedFlag#)=0 and lower(PIM.#Country#)=lower('" + request.Country+"')";

                //selectQuery = "SELECT PIM.#TID# as tid, PIM.#InstructorCode# as instructorcode,PIM.#InstructorFName# as instructorfname,PIM.#InstructorLName# as instructorlname FROM public.#ProcessInstructorMaster# PIM";
                //selectQuery = selectQuery + " where (PIM.#DeletedFlag#)=0 and lower(PIM.#Country#)=lower('" + request.Country + "')";
                //selectQuery = selectQuery + "select * from ( SELECT E.#EXTERNALDATAREFERENCE# as instructorcode,E.#FIRSTNAME# as instructorfname,E.#LASTNAME# as instructorlname,1 as seq FROM public.#EmployeeMaster# E where E.#Active_Separated#='Active' and E.#EXTERNALDATAREFERENCE#='" + request.LoginEMPCode +  "' union all ";
                //selectQuery = selectQuery + " SELECT E.#EXTERNALDATAREFERENCE# as instructorcode,E.#FIRSTNAME# as instructorfname,E.#LASTNAME# as instructorlname,2 as seq FROM public.#EmployeeMaster# E where E.#Active_Separated#='Active' and E.#EXTERNALDATAREFERENCE#!='" + request.LoginEMPCode + "' and E.#GRADE# in ('M0','M1','M2','M3','M4','M5','M6','M7','M8','M9','M10','M11','M12')";
                //if (!string.IsNullOrEmpty(request.ProcessTrainingCode))
                //{
                //    selectQuery = selectQuery + " and E.#EXTERNALDATAREFERENCE# Not in (select PT.#InstructorEmpCode# from public.#ProcessTrainingInstructor# PT where PT.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "' and PT.#DeletedFlag#=0) ";
                //}

                //selectQuery = selectQuery + ") PR  order by PR.#seq#";

                string companiestopass = string.Empty;

                //selectQuery = "select * from ( SELECT E.#EXTERNALDATAREFERENCE# as instructorcode,E.#FIRSTNAME# as instructorfname,E.#LASTNAME# as instructorlname,1 as seq,E.#COMPANY_CODE# FROM public.#EmployeeMaster# E where E.#Active_Separated#='Active' and E.#EXTERNALDATAREFERENCE#='" + request.LoginEMPCode +  "'";

                //selectQuery = selectQuery + " union all";

                //selectQuery = selectQuery + " SELECT E.#EXTERNALDATAREFERENCE# as instructorcode,E.#FIRSTNAME# as instructorfname,E.#LASTNAME# as instructorlname,2 as seq,E.#COMPANY_CODE# FROM public.#EmployeeMaster# E where E.#Active_Separated#='Active' and E.#EXTERNALDATAREFERENCE#!='" + request.LoginEMPCode + "'";

                //if (request.LoginRole == "Program Manager")
                //{

                //    selectQuery = selectQuery + " and E.#COMPANY_CODE#='" + request.UserCountry + "'  ";
                //}

                //if (request.LoginRole == "Geo Admin")
                //{
                //    DataTable dtCompanies = new DataTable();
                //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                //    {
                //        foreach (DataRow exclude in dtCompanies.Rows)
                //        {
                //            companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                //        }

                //        companiestopass = companiestopass.TrimEnd(',');

                //        selectQuery = selectQuery + " and E.#COMPANY_CODE# in (" + companiestopass + ")";

                //    }

                //}

                //if (!string.IsNullOrEmpty(request.ProcessTrainingCode))
                //{
                //    selectQuery = selectQuery + " and E.#EXTERNALDATAREFERENCE# Not in (select PT.#InstructorEmpCode# from public.#ProcessTrainingInstructor# PT where PT.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "' and PT.#DeletedFlag#=0) ";
                //}

                //selectQuery = selectQuery + ") PR  order by PR.#seq#,PR.#COMPANY_CODE#,PR.instructorfname";

                selectQuery = selectQuery + " select E.#EXTERNALDATAREFERENCE# as instructorcode,";
                selectQuery = selectQuery + " E.#FIRSTNAME# as instructorfname,E.#LASTNAME# as instructorlname,#COMPANY_CODE# ";
                selectQuery = selectQuery + " FROM public.#EmployeeMaster# E where E.#Active_Separated# = 'Active' ";
                selectQuery = selectQuery + " and E.#EXTERNALDATAREFERENCE# in ";
                selectQuery = selectQuery + " (select #EmployeeID# from #UserRoleMap#  ";
                selectQuery = selectQuery + "  where #RoleMasterName# in ('Program Manager','Geo Admin','Global Admin') and #IsActive# = 1) ";
                selectQuery = selectQuery + " order by E.#FIRSTNAME# ";


                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProcessInstructor", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetProcessAdministrator(ProcessAdministratorDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                //selectQuery = "SELECT PIM.#TID# as tid, PIM.#TrainingAdministorCode# as trainingadministorcode,PIM.#TrainingAdministorFName# as trainingadministorfname,PIM.#TrainingAdministorLName# as trainingadministorlname FROM public.#ProcessTrainingAdministratorMaster# PIM";
                //selectQuery = selectQuery + " where (PIM.#DeletedFlag#)=0 and lower(PIM.#Country#)=lower('" + request.Country + "')";
                selectQuery = "SELECT E.#EXTERNALDATAREFERENCE# as trainingadministorcode,E.#FIRSTNAME# as trainingadministorfname,E.#LASTNAME# as trainingadministorlname FROM public.#EmployeeMaster# E where E.#Active_Separated#='Active'  order by E.#FIRSTNAME#";
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetProcessAdministrator", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetEventProcessDetail(manageProcessTrainingDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select PT.#TID# as TID,PT.#ProcessTrainingCode# as ProcessTrainingCode,PT.#TrainingName# as TrainingName,concat(EM.#FIRSTNAME#,' ',EM.#LASTNAME#,' (',EM.#EXTERNALDATAREFERENCE#,')') as CreatedBy,TO_CHAR(PT.#CreatedOn#, 'dd-Mon-yyyy') as CreatedDate,PT.#ProcessTrainingType# as ProcessTrainingType from #ProcessTrainingMaster# PT inner join #EmployeeMaster# EM on PT.#CreatedBy# = EM.#EXTERNALDATAREFERENCE#";
                selectQuery = selectQuery + " where PT.#ProcessTrainingCode#='" + request.ProcessTrainingCode + "'";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEventProcessDetail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass GetAttendanceRequiredTypeBySID(manageClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable dt = new DataTable();

                string selectQuery = string.Empty;

                selectQuery = "select ptm.#AttendanceRequire#,ptm.#AttendanceLevel#,ptm.#ProcessTrainingType# from public.#ProcessTrainingSession# pts inner join public.#ProcessTrainingMaster# ptm on pts.#ProcessTrainingCode#=ptm.#ProcessTrainingCode# where pts.#DeletedFlag#=0 and ptm.#DeletedFlag#=0 and pts.#SessionID#='" + request.SessionId + "' limit 1";

                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dt);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(dt);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetAttendanceRequiredTypeByPTC", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public bool checkName(string name, string source)
        {
            try
            {
                DataTable trainingGroup = new DataTable();
                string selectQuery = string.Empty;
                if (source == "Training")
                {
                    selectQuery = " select count(*) as existcount from #ProcessTrainingMaster# where #DeletedFlag#=0 and #TrainingName#='" + name + "';";
                }
                else if (source == "Session")
                {
                    selectQuery = " select count(*) as existcount from #ProcessTrainingSession# where #DeletedFlag#=0 and #SessionName#='" + name + "';";
                }



                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                if (trainingGroup != null && trainingGroup.Rows.Count > 0)
                {
                    if (Convert.ToInt32(trainingGroup.Rows[0]["existcount"]) > 0)
                    {
                        return true;
                    }
                }

                npgsql.Close();
                return false;

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("checkName", "1024", ex.Message, "Exception");
                return false;
            }


        }

    }
}
