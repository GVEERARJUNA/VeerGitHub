﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.CourseAdmin;
using TLDCBAL.Qualtrics;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;

namespace TLDCBAL.ProgramManager
{
    public class AllocateEntityBL : IAllocateEntityBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;

        private IQualtricsDataBL _qualtricsBL;
        private ISchedulerBL _scheduleBL;

        private IVideoMasterBL _videomasterBL;

        private ICourseMasterBL _coursemasterBL;

        private IProgramMasterBL _programmasterBL;

        public AllocateEntityBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL, ISchedulerBL scheduleBL, IVideoMasterBL videomasterBL, ICourseMasterBL coursemasterBL, IProgramMasterBL programmasterBL)
        {
            appSettings = app;

            _serviceconnect = serviceconnect;

            _qualtricsBL = qualtricsBL;

            _scheduleBL = scheduleBL;

            _videomasterBL = videomasterBL;
            _coursemasterBL = coursemasterBL;
            _programmasterBL = programmasterBL;
        }
        public ResponseClass InsertEditAllocateEntity(AllocateEntityInsertRequestDto request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;
                if (request.ObjectType == "2")
                {
                    request.ObjectType = "ClassRoom";
                }
                else
                {
                    request.ObjectType = "Event";
                }


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_edit_allocate_entity
                                                                        ( 
                                                                            :p_subprocess,
                                                                            :p_traininggroup,:p_roles,
                                                                            :p_employeecode,:p_objectcode,
                                                                            :p_objecttype,:p_action,
                                                                            
                                                                            :pinsertedby,
                                                                            :pinsertedipaddress,
                                                                            :pcompanycode
                                                                            
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.Subprocess))
                            cmd.Parameters.AddWithValue("p_subprocess", DbType.String).Value = request.Subprocess;
                        else
                            cmd.Parameters.AddWithValue("p_subprocess", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.TrainingGroup))
                            cmd.Parameters.AddWithValue("p_traininggroup", DbType.String).Value = request.TrainingGroup;
                        else
                            cmd.Parameters.AddWithValue("p_traininggroup", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.Roles))
                            cmd.Parameters.AddWithValue("p_roles", DbType.String).Value = request.Roles;
                        else
                            cmd.Parameters.AddWithValue("p_roles", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.EmployeeCodes))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.EmployeeCodes;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.ObjectCode))
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = request.ObjectCode;
                        else
                            cmd.Parameters.AddWithValue("p_objectcode", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.ObjectType))
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = request.ObjectType;
                        else
                            cmd.Parameters.AddWithValue("p_objecttype", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = string.Empty;



                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("pinsertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("pinsertedipaddress", DbType.String).Value = string.Empty;
                        if (!String.IsNullOrEmpty(request.CompanyCodes))
                            cmd.Parameters.AddWithValue("pcompanycode", DbType.String).Value = request.CompanyCodes;
                        else
                            cmd.Parameters.AddWithValue("pcompanycode", DbType.String).Value = string.Empty;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                            
                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                //response.responseCode = 1;
                //response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("InsertEditAllocateEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;


        }
        public ResponseClass ManageAllocateEntity(manageallocateEntityRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                string selectQuery = string.Empty;
                if (request.ObjectType=="2")
                {
                    request.ObjectType = "ClassRoom";
                }
                else
                {
                    request.ObjectType = "Event";
                }


                selectQuery = "select A.#TID# as recordid,coalesce(A.#OrgSubProcessCode#,'') as subprocess,coalesce(VS.#Department_Code#,'') as department,coalesce(VS.#COMPANY_CODE#,'') as companycode,coalesce(A.#TrainingGroupCode#,'') as traininggroupCode,coalesce(A.#EmployeeCode#,'') as employees,coalesce(A.#RequistionNo#,'') as requistiono,coalesce(EM.#FIRSTNAME#,'') as firstname,coalesce(EM.#Official_Email#,'') as email,coalesce(A.#CompanyCode#,'') as companycodeselected from #EventAllocation# A left join vw_subprocess VS on VS.#Sub_Process_Code#=A.#OrgSubProcessCode# ";
                selectQuery = selectQuery + " left join #EmployeeMaster# EM on EM.#EXTERNALDATAREFERENCE#=A.#EmployeeCode#";
                selectQuery = selectQuery + " where A.#ObjectType#='" + request.ObjectType + "' and  (A.#ObjectCode#)='" + request.ObjectCode + "'";
                
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
               
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ManageAllocateEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getAllocateEntityDropDownData(getAllocateEntityDropDownDataDTO request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                assessmentlistresponseData ASResponse = new assessmentlistresponseData();
                string selectQuery = string.Empty;
                if (request.objectType == "Video")
                {
                    //selectQuery = "select A.#VideoCode# as objectcode,A.#VideoTitle# as objectname  ";
                    //if (!string.IsNullOrEmpty(request.objectCode))
                    //{
                    //    selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
                    //}
                    //else
                    //{
                    //    selectQuery = selectQuery + " ,0 as assignedContent";

                    //}
                    //selectQuery = selectQuery + " from #VideoMaster# A  inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
                    //if (!string.IsNullOrEmpty(request.objectCode))
                    //{
                    //    selectQuery = selectQuery + " left join #EventContent# B on B.#ContentCode#=A.#VideoCode# and B.#EventCode#='" + request.objectCode + "' ";
                    //}
                    //selectQuery = selectQuery + " where A.#DeletedFlag#=0 ";

                    //string companiestopass = string.Empty;


                    //if (request.currentRole == "Program Manager")
                    //{
                    //    // selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";

                    //    selectQuery = selectQuery + " and (A.#InsertedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                    //    selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                    //}
                    //else if (request.currentRole == "Geo Admin")
                    //{
                    //    DataTable dtCompanies = new DataTable();
                    //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    //{
                    //    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    //    {
                    //    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    //    }

                    //    //    companiestopass = companiestopass.TrimEnd(',');

                    //    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //    //}

                    //    selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

                    //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    {
                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }

                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }
                    //    }


                    //    selectQuery = selectQuery + " )";
                    //}

                    //selectQuery = selectQuery + "  order by A.#InsertedDateTime# desc";

                    //selectQuery = selectQuery.Replace('#', '"');
                    //string pgsqlConnection = appSettings.Value.DbConnection;
                    //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                    //npgsql.Open();

                    //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    //dataAdapter.Fill(trainingGroup);
                    //npgsql.Close();

                    // response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

                    manageVideoMasterrequestDTO requestVideo = new manageVideoMasterrequestDTO();

                    requestVideo.UserCompany = request.UserCompany;

                    requestVideo.PageNumber = 0;

                    requestVideo.LoginEMPCode = request.LoginEMPCode;

                    requestVideo.currentRole = request.currentRole;

                    requestVideo.GetMode = 1;

                    requestVideo.objectCode = request.objectCode;

                    // requestVideo



                    ResponseClass responseVideo = new ResponseClass();


                    responseVideo = _videomasterBL.ManageVideoMasterPaging(requestVideo);

                    if (responseVideo.responseCode == 1)
                    {
                        trainingGroup = responseVideo.dtresponse;

                       
                    }

                }
                else if (request.objectType == "Assessment")
                {
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        // first get existing content
                        selectQuery = "select #ContentCode# from #EventContent# where #EventCode#='" + request.objectCode + "'";
                        selectQuery = selectQuery.Replace('#', '"');
                        string pgsqlConnection = appSettings.Value.DbConnection;
                        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                        npgsql.Open();

                        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                        dataAdapter.Fill(trainingGroup);
                        npgsql.Close();
                    }


                    DataTable dtAssessment = new DataTable();

                    dtAssessment.Columns.Add("objectcode");
                    dtAssessment.Columns.Add("objectname");
                    dtAssessment.Columns.Add("assignedcontent");

                    //request.EmpCode = string.Empty ;
                    string companycode = string.Empty;

                    if (request.currentRole == "Geo Admin")
                    {
                        DataTable dtCompanies = new DataTable();
                        dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dtCompanies.Rows)
                            {
                                companycode = companycode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                            }

                            companycode = companycode.TrimEnd(',');

                            //selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companycode + ")";

                        }
                    }

                    string assessmentResponse = _serviceconnect.getAssessment(request.Geo, request.EmpCode, request.currentRole, companycode);
                    ASResponse = JsonConvert.DeserializeObject<assessmentlistresponseData>(assessmentResponse);
                    if (ASResponse.Data.Data != null && ASResponse.Data.Data.Count > 0 && ASResponse.ResponseCode == "1")
                    {

                        foreach (var item in ASResponse.Data.Data)
                        {
                            int assign = 0;
                            foreach (DataRow dc in trainingGroup.Rows)
                            {
                                if (Convert.ToString(dc["ContentCode"]) == Convert.ToString(item.AssessmentID))
                                {
                                    assign = 1;
                                }
                            }
                            dtAssessment.Rows.Add(item.AssessmentID, item.AssessmentName, assign);
                        }
                    }
                    if (dtAssessment != null && dtAssessment.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtAssessment.Rows)
                        {
                            item["objectname"] = Convert.ToString(item["objectname"]).Replace(",", " ");
                        }
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dtAssessment);
                    response.responseCode = 1;
                    response.responseMessage = "SUCCESS";
                    return response;
                }
                else if (request.objectType == "Course")
                {
                    manageCourseMasterrequestDTO requestCourse = new manageCourseMasterrequestDTO();

                    requestCourse.UserCompany = request.UserCompany;

                    requestCourse.PageNumber = 0;

                    requestCourse.LoginEMPCode = request.LoginEMPCode;

                    requestCourse.currentRole = request.currentRole;

                    requestCourse.GetMode = 1;

                    requestCourse.objectCode = request.objectCode;

                    ResponseClass responseCourse = new ResponseClass();


                    responseCourse = _coursemasterBL.ManageCourseMasterPaging(requestCourse);

                    if (responseCourse.responseCode == 1)
                    {
                        trainingGroup = responseCourse.dtresponse;

                       
                    }

                    //selectQuery = "select A.#CourseCode# as objectcode,concat(A.#CourseName#,'(',A.#CourseType#,')') as objectname  ";
                    //if (!string.IsNullOrEmpty(request.objectCode))
                    //{
                    //    selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
                    //}
                    //else
                    //{
                    //    selectQuery = selectQuery + " ,0 as assignedContent";

                    //}
                    //selectQuery = selectQuery + " from #CourseMaster# A inner join #EmployeeMaster# EM on A.#CreatedBy# = EM.#EXTERNALDATAREFERENCE# ";
                    //if (!string.IsNullOrEmpty(request.objectCode))
                    //{
                    //    selectQuery = selectQuery + " left join #EventContent# B on B.#ContentCode#=A.#CourseCode# and B.#EventCode#='" + request.objectCode + "' ";
                    //}
                    //selectQuery = selectQuery + " where A.#DeletedFlag#=0 and (coalesce(A.#ScormCourseURL#,'')!='' or coalesce(A.#CourseExtLink#,'')!='')  ";
                    //string companiestopass = string.Empty;
                    //if (request.currentRole == "Program Manager")
                    //{
                    //    // selectQuery = selectQuery + " and A.#CreatedBy#='" + request.LoginEMPCode + "'";

                    //    selectQuery = selectQuery + " and (A.#CreatedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                    //    selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                    //}
                    //else if (request.currentRole == "Geo Admin")
                    //{
                    //    DataTable dtCompanies = new DataTable();
                    //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    //{
                    //    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    //    {
                    //    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    //    }

                    //    //    companiestopass = companiestopass.TrimEnd(',');

                    //    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //    //}

                    //    selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

                    //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    {
                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }

                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }
                    //    }

                    //    //selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' ) ";

                    //    //selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + request.UserCompany + "%' ) ";

                    //    selectQuery = selectQuery + " )";
                    //}
                    //selectQuery = selectQuery + " and A.#IsPartOfSeed#=0  order by A.#CreatedOn# desc";

                    //selectQuery = selectQuery.Replace('#', '"');
                    //string pgsqlConnection = appSettings.Value.DbConnection;
                    //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                    //npgsql.Open();

                    //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    //dataAdapter.Fill(trainingGroup);
                    //npgsql.Close();

                    //response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
                }
                else if (request.objectType == "Survey")
                {
                    if (!string.IsNullOrEmpty(request.objectCode))
                    {
                        // first get existing content
                        selectQuery = "select #ContentCode# from #EventContent# where #EventCode#='" + request.objectCode + "'";
                        selectQuery = selectQuery.Replace('#', '"');
                        string pgsqlConnection = appSettings.Value.DbConnection;
                        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                        npgsql.Open();

                        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                        dataAdapter.Fill(trainingGroup);
                        npgsql.Close();
                    }


                    DataTable dtAssessment = new DataTable();

                    dtAssessment.Columns.Add("objectcode");
                    dtAssessment.Columns.Add("objectname");
                    dtAssessment.Columns.Add("assignedcontent");
                    TLDEnvelope responseData = new TLDEnvelope();
                    string companycode = string.Empty;
                    if (request.currentRole == "Geo Admin")
                    {
                        DataTable dtCompanies = new DataTable();
                        dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                        if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                        {
                            foreach (DataRow exclude in dtCompanies.Rows)
                            {
                                companycode = companycode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
                            }

                            companycode = companycode.TrimEnd(',');

                            //selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companycode + ")";

                        }
                    }
                    // request.EmpCode = string.Empty;
                    string assessmentResponse = _serviceconnect.getSurvey(request.Geo, request.EmpCode, request.currentRole, companycode);
                    responseData = JsonConvert.DeserializeObject<TLDEnvelope>(assessmentResponse);
                    if (responseData.Status == true && responseData.TotalRecords > 0 && responseData.Data != null)
                    {

                        foreach (var item in responseData.Data.Data)
                        {
                            int assign = 0;
                            foreach (DataRow dc in trainingGroup.Rows)
                            {
                                if (Convert.ToString(dc["ContentCode"]) == Convert.ToString(item.TemplateId))
                                {
                                    assign = 1;
                                }
                            }
                            dtAssessment.Rows.Add(item.TemplateId, item.TemplateName, assign);
                        }
                    }
                    if (dtAssessment != null && dtAssessment.Rows.Count > 0)
                    {
                        foreach (DataRow item in dtAssessment.Rows)
                        {
                            item["objectname"] = Convert.ToString(item["objectname"]).Replace(",", " ");
                        }
                    }

                    response.responseJSON = JsonConvert.SerializeObject(dtAssessment);

                    response.responseCode = 1;
                    response.responseMessage = "SUCCESS";
                    return response;
                }
                else if (request.objectType == "Program")
                {
                    ProgramMasterDTO requestProgram = new ProgramMasterDTO();

                    requestProgram.CurrentRoleCompany = request.UserCompany;

                    requestProgram.PageNumber = 0;

                    requestProgram.CreatedBy = request.LoginEMPCode;

                    requestProgram.CurrentRole = request.currentRole;

                    requestProgram.GetMode = 1;

                    requestProgram.objectCode = request.objectCode;

                    //request.

                    DataTable dtProgramCount = new DataTable();

                    ResponseClass responseProgram = new ResponseClass();

                    responseProgram = _programmasterBL.ManageProgramMasterPaging(requestProgram);

                    if (responseProgram.responseCode == 1)
                    {
                        trainingGroup = responseProgram.dtresponse;
                    }

                    //selectQuery = "select A.#ProgramCode# as objectcode,A.#ProgramName# as objectname,A.#IsMultiDays# as ismultidays,coalesce(ProgramDay.totaldays,0) programdays,coalesce(ProgramAsset.assettype,0) as hasvideo,coalesce(ProgramAssetAssessment.assettype,0) as hasassessmentsurvey  ";
                    //if (!string.IsNullOrEmpty(request.objectCode))
                    //{
                    //    selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
                    //}
                    //else

                    //{
                    //    selectQuery = selectQuery + " ,0 as assignedContent";

                    //}
                    //selectQuery = selectQuery + " from #ProgramMaster# A left join ( select #ProgramCode#,count(distinct #DayNo#) as totaldays from #ProgramAssets# where #isactive#='1' group by #ProgramCode#  ) ProgramDay on ProgramDay.#ProgramCode#=A.#ProgramCode#    inner join #EmployeeMaster# EM on A.#CreatedBy# = EM.#EXTERNALDATAREFERENCE# ";
                    //selectQuery = selectQuery + " left join ( ";

                    //selectQuery = selectQuery + " select PA.#ProgramCode#,count(PAD.#AssetType#) as assettype ";

                    //selectQuery = selectQuery + "  from #ProgramAssets# PA ";
                    //selectQuery = selectQuery + "  inner join #ProgramAssetDetails# PAD on PA.#TID# = PAD.#ProgramAssetID# ";

                    //selectQuery = selectQuery + "  where PA.#isactive#='1' and PAD.#isactive# = '1' and PAD.#AssetType# = 'Video' ";

                    //selectQuery = selectQuery + "  group by PA.#ProgramCode# ";
                    //selectQuery = selectQuery + " ) ProgramAsset on ProgramAsset.#ProgramCode# = A.#ProgramCode#";

                    //selectQuery = selectQuery + " left join ( ";

                    //selectQuery = selectQuery + " select PA.#ProgramCode#,count(PAD.#AssetType#) as assettype ";

                    //selectQuery = selectQuery + "  from #ProgramAssets# PA ";
                    //selectQuery = selectQuery + "  inner join #ProgramAssetDetails# PAD on PA.#TID# = PAD.#ProgramAssetID# ";

                    //selectQuery = selectQuery + "  where PAD.#isactive# = '1' and PAD.#AssetType# in  ('Assessment','Survey') ";

                    //selectQuery = selectQuery + "  group by PA.#ProgramCode# ";
                    //selectQuery = selectQuery + " ) ProgramAssetAssessment on ProgramAssetAssessment.#ProgramCode# = A.#ProgramCode#";

                    //if (!string.IsNullOrEmpty(request.objectCode))
                    //{
                    //    selectQuery = selectQuery + " left join #EventContent# B on B.#ContentCode#=A.#ProgramCode# and B.#EventCode#='" + request.objectCode + "' ";
                    //}
                    //selectQuery = selectQuery + " where A.#DeletedFlag#=0 and coalesce(ProgramDay.totaldays,0)>0 ";

                    //string companiestopass = string.Empty;


                    //if (request.currentRole == "Program Manager")
                    //{
                    //    // selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";

                    //    selectQuery = selectQuery + " and (A.#CreatedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

                    //    selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
                    //}
                    //else if (request.currentRole == "Geo Admin")
                    //{
                    //    DataTable dtCompanies = new DataTable();
                    //    dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
                    //    //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    //{
                    //    //    foreach (DataRow exclude in dtCompanies.Rows)
                    //    //    {
                    //    //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    //    //    }

                    //    //    companiestopass = companiestopass.TrimEnd(',');

                    //    //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

                    //    //}

                    //    selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

                    //    if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                    //    {
                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }

                    //        foreach (DataRow exclude in dtCompanies.Rows)
                    //        {
                    //            selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

                    //        }
                    //    }


                    //    selectQuery = selectQuery + " )";
                    //}

                    //selectQuery = selectQuery + "  order by A.#CreatedOn# desc";

                    //selectQuery = selectQuery.Replace('#', '"');
                    //string pgsqlConnection = appSettings.Value.DbConnection;
                    //NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                    //npgsql.Open();

                    //NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                    //NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                    //dataAdapter.Fill(trainingGroup);
                    //npgsql.Close();



                }
                if (trainingGroup != null && trainingGroup.Rows.Count > 0)
                {
                    foreach (DataRow item in trainingGroup.Rows)
                    {
                        item["objectname"] = Convert.ToString(item["objectname"]).Replace(",", " ");
                    }
                }

                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getAllocateEntityDropDownData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        //public ResponseClass getAllocateEntityDropDownData(getAllocateEntityDropDownDataDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable trainingGroup = new DataTable();
        //        assessmentlistresponseData ASResponse = new assessmentlistresponseData();
        //        string selectQuery = string.Empty;
        //        if (request.objectType=="Video")
        //        {
        //            selectQuery = "select A.#VideoCode# as objectcode,A.#VideoTitle# as objectname  ";
        //            if (!string.IsNullOrEmpty(request.objectCode))
        //            {
        //                selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
        //            }
        //            else
        //            {
        //                selectQuery = selectQuery + " ,0 as assignedContent";

        //            }
        //            selectQuery = selectQuery + " from #VideoMaster# A  inner join #EmployeeMaster# EM on A.#InsertedBy# = EM.#EXTERNALDATAREFERENCE# ";
        //            if (!string.IsNullOrEmpty(request.objectCode))
        //            {
        //                selectQuery = selectQuery + " left join #EventContent# B on B.#ContentCode#=A.#VideoCode# and B.#EventCode#='" + request.objectCode + "' ";
        //            }
        //            selectQuery = selectQuery + " where A.#DeletedFlag#=0 ";

        //            string companiestopass = string.Empty;


        //            if (request.currentRole == "Program Manager")
        //            {
        //                // selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";

        //                selectQuery = selectQuery + " and (A.#InsertedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

        //                selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
        //            }
        //            else if (request.currentRole == "Geo Admin")
        //            {
        //                DataTable dtCompanies = new DataTable();
        //                dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
        //                //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //                //{
        //                //    foreach (DataRow exclude in dtCompanies.Rows)
        //                //    {
        //                //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
        //                //    }

        //                //    companiestopass = companiestopass.TrimEnd(',');

        //                //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

        //                //}

        //                selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

        //                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //                {
        //                    foreach (DataRow exclude in dtCompanies.Rows)
        //                    {
        //                        selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

        //                    }

        //                    foreach (DataRow exclude in dtCompanies.Rows)
        //                    {
        //                        selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

        //                    }
        //                }


        //                selectQuery = selectQuery + " )";
        //            }

        //            selectQuery = selectQuery + "  order by A.#InsertedDateTime# desc";

        //            selectQuery = selectQuery.Replace('#', '"');
        //            string pgsqlConnection = appSettings.Value.DbConnection;
        //            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //            npgsql.Open();

        //            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //            dataAdapter.Fill(trainingGroup);
        //            npgsql.Close();

        //           // response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

        //        }
        //        else if (request.objectType == "Assessment")
        //        {
        //            if (!string.IsNullOrEmpty(request.objectCode))
        //            {
        //                // first get existing content
        //                selectQuery = "select #ContentCode# from #EventContent# where #EventCode#='" + request.objectCode + "'";
        //                selectQuery = selectQuery.Replace('#', '"');
        //                string pgsqlConnection = appSettings.Value.DbConnection;
        //                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //                npgsql.Open();

        //                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //                dataAdapter.Fill(trainingGroup);
        //                npgsql.Close();
        //            }


        //            DataTable dtAssessment = new DataTable();

        //            dtAssessment.Columns.Add("objectcode");
        //            dtAssessment.Columns.Add("objectname");
        //            dtAssessment.Columns.Add("assignedcontent");

        //            //request.EmpCode = string.Empty ;
        //            string companycode = string.Empty;

        //            if (request.currentRole == "Geo Admin")
        //            {
        //                DataTable dtCompanies = new DataTable();
        //                dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
        //                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //                {
        //                    foreach (DataRow exclude in dtCompanies.Rows)
        //                    {
        //                        companycode = companycode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
        //                    }

        //                    companycode = companycode.TrimEnd(',');

        //                    //selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companycode + ")";

        //                }
        //            }

        //            string assessmentResponse=_serviceconnect.getAssessment(request.Geo,request.EmpCode,request.currentRole, companycode);
        //            ASResponse = JsonConvert.DeserializeObject<assessmentlistresponseData>(assessmentResponse);
        //            if (ASResponse.Data.Data!=null && ASResponse.Data.Data.Count>0 && ASResponse.ResponseCode=="1")
        //            {

        //                foreach (var item in ASResponse.Data.Data)
        //                {
        //                    int assign = 0;
        //                    foreach (DataRow dc in trainingGroup.Rows)
        //                    {
        //                        if (Convert.ToString(dc["ContentCode"])==Convert.ToString(item.AssessmentID))
        //                        {
        //                            assign = 1;
        //                        }
        //                    }
        //                    dtAssessment.Rows.Add(item.AssessmentID,item.AssessmentName, assign);
        //                }
        //            }
        //            if (dtAssessment != null && dtAssessment.Rows.Count > 0)
        //            {
        //                foreach (DataRow item in dtAssessment.Rows)
        //                {
        //                    item["objectname"] = Convert.ToString(item["objectname"]).Replace(",", " ");
        //                }
        //            }
        //            response.responseJSON = JsonConvert.SerializeObject(dtAssessment);
        //            response.responseCode = 1;
        //            response.responseMessage = "SUCCESS";
        //            return response;
        //        }
        //        else if (request.objectType == "Course")
        //        {
        //            selectQuery = "select A.#CourseCode# as objectcode,concat(A.#CourseName#,'(',A.#CourseType#,')') as objectname  ";
        //            if (!string.IsNullOrEmpty(request.objectCode))
        //            {
        //                selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
        //            }
        //            else
        //            {
        //                selectQuery = selectQuery + " ,0 as assignedContent";

        //            }
        //            selectQuery = selectQuery + " from #CourseMaster# A inner join #EmployeeMaster# EM on A.#CreatedBy# = EM.#EXTERNALDATAREFERENCE# ";
        //            if (!string.IsNullOrEmpty(request.objectCode))
        //            {
        //                selectQuery = selectQuery + " left join #EventContent# B on B.#ContentCode#=A.#CourseCode# and B.#EventCode#='" + request.objectCode + "' ";
        //            }
        //            selectQuery = selectQuery + " where A.#DeletedFlag#=0 and (coalesce(A.#ScormCourseURL#,'')!='' or coalesce(A.#CourseExtLink#,'')!='')  ";
        //            string companiestopass = string.Empty;
        //            if (request.currentRole == "Program Manager")
        //            {
        //                // selectQuery = selectQuery + " and A.#CreatedBy#='" + request.LoginEMPCode + "'";

        //                selectQuery = selectQuery + " and (A.#CreatedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

        //                selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
        //            }
        //            else if (request.currentRole == "Geo Admin")
        //            {
        //                DataTable dtCompanies = new DataTable();
        //                dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
        //                //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //                //{
        //                //    foreach (DataRow exclude in dtCompanies.Rows)
        //                //    {
        //                //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
        //                //    }

        //                //    companiestopass = companiestopass.TrimEnd(',');

        //                //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

        //                //}

        //                selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

        //                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //                {
        //                    foreach (DataRow exclude in dtCompanies.Rows)
        //                    {
        //                        selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

        //                    }

        //                    foreach (DataRow exclude in dtCompanies.Rows)
        //                    {
        //                        selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

        //                    }
        //                }

        //                //selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' ) ";

        //                //selectQuery = selectQuery + " or (CM.#CurrentRole#='Program Manager' and CM.#CurrentRoleCompany# like '%" + request.UserCompany + "%' ) ";

        //                selectQuery = selectQuery + " )";
        //            }
        //            selectQuery = selectQuery + " and A.#IsPartOfSeed#=0  order by A.#CreatedOn# desc";

        //            selectQuery = selectQuery.Replace('#', '"');
        //            string pgsqlConnection = appSettings.Value.DbConnection;
        //            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //            npgsql.Open();

        //            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //            dataAdapter.Fill(trainingGroup);
        //            npgsql.Close();

        //            //response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
        //        }
        //        else if (request.objectType == "Survey")
        //        {
        //            if (!string.IsNullOrEmpty(request.objectCode))
        //            {
        //                // first get existing content
        //                selectQuery = "select #ContentCode# from #EventContent# where #EventCode#='" + request.objectCode + "'";
        //                selectQuery = selectQuery.Replace('#', '"');
        //                string pgsqlConnection = appSettings.Value.DbConnection;
        //                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //                npgsql.Open();

        //                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //                dataAdapter.Fill(trainingGroup);
        //                npgsql.Close();
        //            }


        //            DataTable dtAssessment = new DataTable();

        //            dtAssessment.Columns.Add("objectcode");
        //            dtAssessment.Columns.Add("objectname");
        //            dtAssessment.Columns.Add("assignedcontent");
        //            TLDEnvelope responseData = new TLDEnvelope();
        //            string companycode = string.Empty;
        //            if (request.currentRole == "Geo Admin")
        //            {
        //                DataTable dtCompanies = new DataTable();
        //                dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
        //                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //                {
        //                    foreach (DataRow exclude in dtCompanies.Rows)
        //                    {
        //                        companycode = companycode + "" + Convert.ToString(exclude["CompanyCode"]) + ",";
        //                    }

        //                    companycode = companycode.TrimEnd(',');

        //                    //selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companycode + ")";

        //                }
        //            }
        //            // request.EmpCode = string.Empty;
        //            string assessmentResponse = _serviceconnect.getSurvey(request.Geo, request.EmpCode, request.currentRole, companycode);
        //            responseData = JsonConvert.DeserializeObject<TLDEnvelope>(assessmentResponse);
        //            if (responseData.Status == true && responseData.TotalRecords>0 && responseData.Data!=null)
        //            {

        //                foreach (var item in responseData.Data.Data)
        //                {
        //                    int assign = 0;
        //                    foreach (DataRow dc in trainingGroup.Rows)
        //                    {
        //                        if (Convert.ToString(dc["ContentCode"]) == Convert.ToString(item.TemplateId))
        //                        {
        //                            assign = 1;
        //                        }
        //                    }
        //                    dtAssessment.Rows.Add(item.TemplateId, item.TemplateName, assign);
        //                }
        //            }
        //            if (dtAssessment != null && dtAssessment.Rows.Count > 0)
        //            {
        //                foreach (DataRow item in dtAssessment.Rows)
        //                {
        //                    item["objectname"] = Convert.ToString(item["objectname"]).Replace(",", " ");
        //                }
        //            }

        //            response.responseJSON = JsonConvert.SerializeObject(dtAssessment);

        //            response.responseCode = 1;
        //            response.responseMessage = "SUCCESS";
        //            return response;
        //        }
        //        else if (request.objectType == "Program")
        //        {
        //            selectQuery = "select A.#ProgramCode# as objectcode,A.#ProgramName# as objectname,A.#IsMultiDays# as ismultidays,coalesce(ProgramDay.totaldays,0) programdays,coalesce(ProgramAsset.assettype,0) as hasvideo,coalesce(ProgramAssetAssessment.assettype,0) as hasassessmentsurvey  ";
        //            if (!string.IsNullOrEmpty(request.objectCode))
        //            {
        //                selectQuery = selectQuery + " , case when coalesce(B.#EventCode#,'')!='' then 1 else 0 end as assignedContent";
        //            }
        //            else

        //            {
        //                selectQuery = selectQuery + " ,0 as assignedContent";

        //            }
        //            selectQuery = selectQuery + " from #ProgramMaster# A left join ( select #ProgramCode#,count(distinct #DayNo#) as totaldays from #ProgramAssets# where #isactive#='1' group by #ProgramCode#  ) ProgramDay on ProgramDay.#ProgramCode#=A.#ProgramCode#    inner join #EmployeeMaster# EM on A.#CreatedBy# = EM.#EXTERNALDATAREFERENCE# ";
        //            selectQuery = selectQuery + " left join ( ";

        //            selectQuery = selectQuery + " select PA.#ProgramCode#,count(PAD.#AssetType#) as assettype ";

        //            selectQuery = selectQuery + "  from #ProgramAssets# PA ";
        //            selectQuery = selectQuery + "  inner join #ProgramAssetDetails# PAD on PA.#TID# = PAD.#ProgramAssetID# ";

        //            selectQuery = selectQuery + "  where PA.#isactive#='1' and PAD.#isactive# = '1' and PAD.#AssetType# = 'Video' ";

        //            selectQuery = selectQuery + "  group by PA.#ProgramCode# ";
        //            selectQuery = selectQuery + " ) ProgramAsset on ProgramAsset.#ProgramCode# = A.#ProgramCode#";

        //            selectQuery = selectQuery + " left join ( ";

        //            selectQuery = selectQuery + " select PA.#ProgramCode#,count(PAD.#AssetType#) as assettype ";

        //            selectQuery = selectQuery + "  from #ProgramAssets# PA ";
        //            selectQuery = selectQuery + "  inner join #ProgramAssetDetails# PAD on PA.#TID# = PAD.#ProgramAssetID# ";

        //            selectQuery = selectQuery + "  where PAD.#isactive# = '1' and PAD.#AssetType# in  ('Assessment','Survey') ";

        //            selectQuery = selectQuery + "  group by PA.#ProgramCode# ";
        //            selectQuery = selectQuery + " ) ProgramAssetAssessment on ProgramAssetAssessment.#ProgramCode# = A.#ProgramCode#";

        //            if (!string.IsNullOrEmpty(request.objectCode))
        //            {
        //                selectQuery = selectQuery + " left join #EventContent# B on B.#ContentCode#=A.#ProgramCode# and B.#EventCode#='" + request.objectCode + "' ";
        //            }
        //            selectQuery = selectQuery + " where A.#DeletedFlag#=0 and coalesce(ProgramDay.totaldays,0)>0 ";

        //            string companiestopass = string.Empty;


        //            if (request.currentRole == "Program Manager")
        //            {
        //                // selectQuery = selectQuery + " and A.#InsertedBy#='" + request.LoginEMPCode + "'";

        //                selectQuery = selectQuery + " and (A.#CreatedBy#='" + request.LoginEMPCode + "' or A.#CurrentRole#='Global Admin' ";

        //                selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + request.UserCompany + "%' )) ";
        //            }
        //            else if (request.currentRole == "Geo Admin")
        //            {
        //                DataTable dtCompanies = new DataTable();
        //                dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoginEMPCode);
        //                //if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //                //{
        //                //    foreach (DataRow exclude in dtCompanies.Rows)
        //                //    {
        //                //        companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
        //                //    }

        //                //    companiestopass = companiestopass.TrimEnd(',');

        //                //    selectQuery = selectQuery + " and EM.#COMPANY_CODE# in (" + companiestopass + ")";

        //                //}

        //                selectQuery = selectQuery + " and (A.#CurrentRole#='Global Admin' ";

        //                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
        //                {
        //                    foreach (DataRow exclude in dtCompanies.Rows)
        //                    {
        //                        selectQuery = selectQuery + " or (A.#CurrentRole#='Geo Admin' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

        //                    }

        //                    foreach (DataRow exclude in dtCompanies.Rows)
        //                    {
        //                        selectQuery = selectQuery + " or (A.#CurrentRole#='Program Manager' and A.#CurrentRoleCompany# like '%" + Convert.ToString(exclude["CompanyCode"]) + "%' )";

        //                    }
        //                }


        //                selectQuery = selectQuery + " )";
        //            }

        //            selectQuery = selectQuery + "  order by A.#CreatedOn# desc";

        //            selectQuery = selectQuery.Replace('#', '"');
        //            string pgsqlConnection = appSettings.Value.DbConnection;
        //            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //            npgsql.Open();

        //            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //            dataAdapter.Fill(trainingGroup);
        //            npgsql.Close();



        //        }
        //        if (trainingGroup!=null && trainingGroup.Rows.Count>0)
        //        {
        //            foreach (DataRow item in trainingGroup.Rows)
        //            {
        //                item["objectname"] = Convert.ToString(item["objectname"]).Replace(","," ");
        //            }
        //        }

        //        response.responseJSON = JsonConvert.SerializeObject(trainingGroup);
        //        response.responseCode = 1;
        //        response.responseMessage = "SUCCESS";

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("getAllocateEntityDropDownData", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}

        public ResponseClass PushSurveyResult(pushSurveyResultrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (string.IsNullOrEmpty(request.AllocationID))
            {
                response.responseCode = 0;
                response.responseMessage = "Allocation id required!";
            }

            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;

                string learningstartDate = string.Empty;
                string learningendDate = string.Empty;

                if (!string.IsNullOrEmpty(request.SurveyStartDate))
                {
                    try
                    {
                        learningstartDate = Convert.ToDateTime(request.SurveyStartDate).ToString("yyyy-MM-dd HH:mm:ss");

                    }
                    catch (Exception)
                    {
                       

                    }
                }
                if (!string.IsNullOrEmpty(request.SurveyEndDate))
                {
                    try
                    {
                        learningendDate = Convert.ToDateTime(request.SurveyEndDate).ToString("yyyy-MM-dd HH:mm:ss");

                    }
                    catch (Exception)
                    {


                    }
                }

                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM update_event_survey_result
                                                                        ( 
                                                                            :p_allocationid,
                                                                            :p_completionstatus,:p_startdate,:p_enddate,:p_totalquestion,:p_totalsubmitted
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.AllocationID))
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = request.AllocationID;
                        else
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = string.Empty;


                        cmd.Parameters.AddWithValue("p_completionstatus", DbType.Int32).Value = Convert.ToInt32(request.completionStatus);

                        if (!String.IsNullOrEmpty(learningstartDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = learningstartDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(learningendDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = learningendDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_totalquestion", DbType.String).Value = request.TotalQuestion;
                        cmd.Parameters.AddWithValue("p_totalsubmitted", DbType.String).Value = request.TotalSubmitted;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);

                            if (response.responseCode==1)
                            {
                                try
                                {
                                    var scResponse = _scheduleBL.SendFSTLCertificateEmail();
                                }
                                catch (Exception ex)
                                {

                                    _serviceconnect.LogConnect("PushSurveyResult", "1024", ex.Message, "Exception");
                                }
                            }


                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("PushSurveyResult", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

           
            return response;
        }

        public ResponseClass GetEntityNames(getEntityName request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                string selectQuery = string.Empty;
                
                if (request.objectType == "2")
                {
                    selectQuery = "select #ClassRoomTitle# as entityname,case when (select count(*) from #ClassRoomEntityDetails# A inner join #ClassRoomEventDetails# B on A.#EventDetailID#=B.#TID# where B.#ClassRoomCode#='" + request.objectCode + "' and A.#IsPublished#=1)>0 then 1 else 0 end as published,TO_CHAR(#StartDate#, 'dd-Mon-yy') as startDate,TO_CHAR(#EndDate#, 'dd-Mon-yy') as enddate,(select count(*) from #EventAllocation# where #ObjectCode#=A.#ClassRoomCode# and #ObjectType#='ClassRoom') as allocationcount,case when cast(A.#EndDate# as date)>=cast(now() as date) then 0 else 1 end as Isexpired,'Class' as eventtype from #ClassRoomTraining# A  where #ClassRoomCode#='" + request.objectCode + "'  ";
                }
                else
                {
                    selectQuery = "select #EventName# as entityname,#IsPublished# as published,case when cast(concat(#ServerEndDate#,' ',coalesce(#ServerEndTime#,'23:59:59')) as timestamp)>=now() then 0 else 1 end as Isexpired,#EventType# as eventtype from #EventMaster#  where #EventCode#='" + request.objectCode + "'  ";
                }



                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("GetEntityNames", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass DeleteEventAllocation(deleteeventallocationrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request is required";
                return response;
            }
            if (string.IsNullOrEmpty(request.RecordID))
            {
                response.responseCode = 0;
                response.responseMessage = "RecordID required";
                return response;
            }
            if (string.IsNullOrEmpty(request.objectType))
            {
                response.responseCode = 0;
                response.responseMessage = "objectType required";
                return response;
            }
            if (string.IsNullOrEmpty(request.objectCode))
            {
                response.responseCode = 0;
                response.responseMessage = "objectCode required";
                return response;
            }
           

            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string selectQuery = string.Empty;


                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_delete_eventallocation
                                                                        ( 
                                                                            :record_id,
                                                                            :object_code,:object_type
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.RecordID))
                            cmd.Parameters.AddWithValue("record_id", DbType.String).Value = request.RecordID;
                        else
                            cmd.Parameters.AddWithValue("record_id", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.objectCode))
                            cmd.Parameters.AddWithValue("object_code", DbType.String).Value = request.objectCode;
                        else
                            cmd.Parameters.AddWithValue("object_code", DbType.String).Value = string.Empty;


                        if (!String.IsNullOrEmpty(request.objectType))
                            cmd.Parameters.AddWithValue("object_type", DbType.String).Value = request.objectType;
                        else
                            cmd.Parameters.AddWithValue("object_type", DbType.String).Value = string.Empty;

                       
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);

                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);


                        }
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("DeleteClassRoomEntity", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;



        }

        //public ResponseClass getrequistionno(getrequistionnorequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();

        //    try
        //    {
        //        DataTable trainingGroup = new DataTable();
        //        string selectQuery = string.Empty;
        //        //if (request.objectType == "2")
        //        //{
        //        //    selectQuery = "select #ClassRoomTitle# as entityname,#IsPublished# as published,TO_CHAR(#StartDate#, 'dd-Mon-yy') as startDate,TO_CHAR(#EndDate#, 'dd-Mon-yy') as enddate,(select count(*) from #EventAllocation# where #ObjectCode#=A.#ClassRoomCode# and #ObjectType#='ClassRoom') as allocationcount from #ClassRoomTraining# A  where #ClassRoomCode#='" + request.objectCode + "'  ";
        //        //}
        //        //else
        //        //{
        //        //    selectQuery = "select #EventName# as entityname,#IsPublished# as published from #EventMaster#  where #EventCode#='" + request.objectCode + "'  ";
        //        //}
        //        selectQuery = "select  from #EmployeeMaster# EM where "";


        //        selectQuery = selectQuery.Replace('#', '"');
        //        string pgsqlConnection = appSettings.Value.DbConnection;
        //        NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
        //        npgsql.Open();

        //        NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

        //        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

        //        dataAdapter.Fill(trainingGroup);
        //        npgsql.Close();
        //        response.responseCode = 1;
        //        response.responseJSON = JsonConvert.SerializeObject(trainingGroup);

        //    }
        //    catch (Exception ex)
        //    {
        //        _serviceconnect.LogConnect("GetEntityNames", "1024", ex.Message, "Exception");
        //        response.responseCode = 0;
        //        response.responseMessage = ex.Message;
        //    }

        //    return response;
        //}

        public ResponseClass CheckEntityPublish(getEntityName request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable trainingGroup = new DataTable();
                string selectQuery = string.Empty;
                //selectQuery = "select #TID# from #BusinessTrainingEmpLearningDetails# where #ContentCode#='" + request.objectCode + "'  ";
                selectQuery = "select A.#TID# from #BusinessTrainingEmpLearningDetails# A inner join #BusinessTrainingAllocation# B on A.#AllocationID# = B.#TID# inner join #EventMaster# EM on EM.#EventCode# = B.#EventCode# where A.#ContentCode# ='" + request.objectCode + "' and(EM.#EventType# ='Assessment' or (EM.#EventType# = 'Program' and A.#ContentType# ='Assessment'))";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(trainingGroup);
                npgsql.Close();
                if (trainingGroup!=null && trainingGroup.Rows.Count>0)
                {
                    response.responseCode = 1;
                    response.responseMessage = "Published";
                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "NotPublished";
                }
               

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("CheckEntityPublish", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
    }
}
