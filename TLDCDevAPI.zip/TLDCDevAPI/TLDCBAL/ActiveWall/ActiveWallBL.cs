﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;
using TLDCDAL;

namespace TLDCBAL.ActiveWall
{
    public class ActiveWallBL : IActiveWallBL
    {
        private readonly IServiceConnect _serviceconnect;

        private readonly IOptions<IDBConnection> appSettings;
        DBConnection dBConnection;
        private IQualtricsDataBL _qualtricsBL;

        public ActiveWallBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect, IQualtricsDataBL qualtricsBL)
        {
            appSettings = app;
            dBConnection = new DBConnection(appSettings.Value.TLDCSchedulerDbConnection);
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
        }

        public string RemoveQuotes(string str)
        {
            string result = string.Empty;
            if(str != null && str != "")
            {
                result = str.Replace("'", "''");
            }
            return result;
        }

        public ResponseClass CreatePost(WallPostingDTO request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                // insert post allocation - pending
                // insert visibility filters data - pending

                //sequence number
                int postIDCount = 0;
                string sqlQuery1 = "SELECT coalesce(max(#TSequenceNo#),0) as #TSequenceNo# FROM public.#WallPosting#";

                sqlQuery1 = sqlQuery1.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                if (npgsqlDataReader1.Read())
                {
                    postIDCount = Convert.ToInt32(npgsqlDataReader1[0]) + 1;
                    request.PostingID = postIDCount;
                }
                else
                {
                    ++postIDCount;
                    request.PostingID = postIDCount;
                }

                npgsqlCon.Close();

                //insert post data


                string sqlQuery = "INSERT INTO public.#WallPosting#(#PostingID#,#PostingSubject#,#PostingContent#,#PostingImage#," +
                    "#TSequenceNo#,#PostedBy#,#IsActive#,#PostedOn#) VALUES('" + request.PostingID + "', '" + "post share" + "', " +
                    "'" + RemoveQuotes(request.PostingContent) + "', '" + request.PostImage + "', '" + postIDCount + "', '" + request.PostedBy + "', '1',now()" + ")";

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();


                npgsqlCon.Close();

                //insert attachment data
                foreach(WallPostingAttachment attachment in request.AttachmentsList)
                {
                    string query = "INSERT INTO public.#WallPostingAttachment#(#PostingID#,#AttachmentFileName#," +
                    "#PostedBy#,#PostedOn#) VALUES('" + request.PostingID + "', '" + attachment.AttachmentFileName + "', "+
                     "'" + request.PostedBy + "', now()" + ")";

                    query = query.Replace('#', '"');

                    npgsqlCon.Open();

                    NpgsqlCommand cmd2 = new NpgsqlCommand(query, npgsqlCon);

                    NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                    npgsqlCon.Close();

                }

                List<string> subprocesslist = new List<string>();
                if(request.SubProcesses != "")
                {
                    string[] numberStrings = request.SubProcesses.Split(',');
                    //insert visibility filter data
                    foreach (string spc in numberStrings)
                    {
                        string query = "INSERT INTO public.#WallPostingAllocation#(#PostingID#,#SubProcessCode#" +
                        ") VALUES('" + request.PostingID + "', '" + spc + "')";

                        npgsqlCon.Open();

                        query = query.Replace('#', '"');

                        NpgsqlCommand cmd2 = new NpgsqlCommand(query, npgsqlCon);

                        NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                        npgsqlCon.Close();

                    }

                }
                


                //insert allocation data
                foreach (AllocatedUsers usr in request.AllocationList)
                {
                    string query = "INSERT INTO public.#WallPostingAllocation#(#PostingID#,#EmpCode#" +
                    ") VALUES('" + request.PostingID + "', '" + usr.empid  + "')";

                    npgsqlCon.Open();

                    query = query.Replace('#', '"');

                    NpgsqlCommand cmd2 = new NpgsqlCommand(query, npgsqlCon);

                    NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                    npgsqlCon.Close();

                }

                //insert allocation group data
                if(request.GroupList != null && request.GroupList.Count > 0)
                {
                    //insert employees
                    List<string> rowlist = new List<string>();
                    string insertquery = "INSERT INTO public.#WallPostingAllocation# (#PostingID#,#EmpCode#" +
                                       ") VALUES #DataList# ;";

                    npgsqlCon.Open();

                    foreach (AllocationGroup group in request.GroupList)
                    {
                        string grpQuery = string.Empty;

                        grpQuery = "SELECT * FROM public.#TrainingGroupMembers# a INNER JOIN public.#TrainingGroup# b ON a.#TrainingGroupCode# = b.#TrainingGroupCode# WHERE #TrainingGroupID# = '#groupID#';";

                        grpQuery = grpQuery.Replace("#groupID#", group.grpid);
                        grpQuery = grpQuery.Replace('#', '"');

                        DataTable employee = new DataTable();

                        NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(grpQuery, npgsqlCon);

                        NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                        scdataAdapter.Fill(employee);

                        foreach (DataRow row in employee.Rows)
                        {
                            string equery = string.Empty;
                            string employeeID = row["EmployeeCode"].ToString();
                            if(employeeID != null && employeeID != "")
                            {
                                equery = "('" + request.PostingID + "', '" + employeeID + "')";
                                rowlist.Add(equery);

                            }
                            

                        }
                       

                        foreach (DataRow row in employee.Rows)
                        {
                            string equery = string.Empty;
                            string subprocessCode = row["Subprocess"].ToString();

                            string subprocessquery = "SELECT #EXTERNALDATAREFERENCE# FROM PUBLIC.#EmployeeMaster# WHERE #Active_Separated# = 'Active' AND #Sub_Process_Code# = '#SUBPROCESS#';";

                            subprocessquery = subprocessquery.Replace("#SUBPROCESS#", subprocessCode);

                            subprocessquery = subprocessquery.Replace('#', '"');

                            DataTable employee2 = new DataTable();

                            NpgsqlCommand scnpgsqlCommand2 = new NpgsqlCommand(subprocessquery, npgsqlCon);

                            NpgsqlDataAdapter scdataAdapter2 = new NpgsqlDataAdapter(scnpgsqlCommand2);

                            scdataAdapter2.Fill(employee2);

                            foreach (DataRow row2 in employee2.Rows)
                            {
                                string employeeID = row2["EXTERNALDATAREFERENCE"].ToString();
                                if (employeeID != null && employeeID != "")
                                {
                                    equery = "('" + request.PostingID + "', '" + employeeID + "')";
                                    rowlist.Add(equery);

                                }


                            }

                        }
                        npgsqlCon.Close();
                    }

                    string rows = string.Join(",", rowlist);

                    insertquery = insertquery.Replace("#DataList#", rows);
                    insertquery = insertquery.Replace('#', '"');

                    if (rowlist.Count > 0)
                    {
                        npgsqlCon.Open();
                        NpgsqlCommand cmd2 = new NpgsqlCommand(insertquery, npgsqlCon);
                        NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();
                        npgsqlCon.Close();

                    }

                }


                // All users
                if (request.AllEmployee)
                {
                    bool checkNext = true;

                    if (request.AssignedRoles.Count > 0)
                    {
                        #region
                        //all user allocation for global admins
                        // for now not needed

                        //if (checkNext)
                        //{
                        //    foreach (UserRoles role in request.AssignedRoles)
                        //    {
                        //        if (role.RoleMasterName == "Global Admin")
                        //        {
                        //            // team of user
                        //            string subProcessCode = string.Empty;
                        //            string scodeQuery = string.Empty;
                        //            scodeQuery = "select * from #EmployeeMaster# where #EmployeeMaster#.#Active_Separated# = 'Active';";

                        //            scodeQuery = scodeQuery.Replace('#', '"');

                        //            DataTable employee = new DataTable();

                        //            NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsqlCon);

                        //            NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                        //            scdataAdapter.Fill(employee);
                        //            npgsqlCon.Open();

                        //            List<string> rowlist = new List<string>();
                        //            string insertquery = "INSERT INTO public.#WallPostingAllocation# (#PostingID#,#EmpCode#" +
                        //                               ") VALUES #DataList# ;";

                        //            foreach (DataRow row in employee.Rows)
                        //            {
                        //                string employeeID = row["EXTERNALDATAREFERENCE"].ToString();
                        //                string query = "('" + request.PostingID + "', '" + employeeID + "')";

                        //                rowlist.Add(query);

                        //            }
                        //            string rows = string.Join(",", rowlist);

                        //            insertquery = insertquery.Replace("#DataList#", rows);
                        //            insertquery = insertquery.Replace('#', '"');

                        //            NpgsqlCommand cmd2 = new NpgsqlCommand(insertquery, npgsqlCon);

                        //            NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                        //            checkNext = false;
                        //            break;
                        //        }
                        //    }

                        //}

                        //all user allocation for Geo Admin
                        // for now not needed

                        //if (checkNext)
                        //{
                        //    foreach (UserRoles role in request.AssignedRoles)
                        //    {
                        //        if (role.RoleMasterName == "Geo Admin")
                        //        {
                        //            //SELECT * FROM #UserCompanyAssignment# where #EmployeeCode#='198739';
                        //            string scodeQuery = string.Empty;
                        //            string subProcessCode = string.Empty;
                        //            scodeQuery = "SELECT * FROM #UserCompanyAssignment# where #EmployeeCode#= '#empId#';";
                        //            scodeQuery = scodeQuery.Replace("#empId#", request.PostedBy);
                        //            scodeQuery = scodeQuery.Replace('#', '"');

                        //            DataTable employee = new DataTable();
                        //            npgsqlCon.Open();

                        //            NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsqlCon);

                        //            NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                        //            scdataAdapter.Fill(employee);
                        //            npgsqlCon.Close();

                        //            List<string> companycodelist = new List<string>();

                        //            foreach (DataRow row1 in employee.Rows)
                        //            {
                        //                string id = row1["CompanyCode"].ToString();
                        //                if (id != null && id != "")
                        //                {
                        //                    companycodelist.Add("'" + id + "'");
                        //                }

                        //            }

                        //            string companycode = string.Join(",", companycodelist);


                        //            // team of user
                        //            string empQuery = string.Empty;
                        //            empQuery = "select * from #EmployeeMaster# where #EmployeeMaster#.#Active_Separated# = 'Active' AND #COMPANY_CODE# IN ( #Compancodeslist# ) ;";
                        //            empQuery = empQuery.Replace("#Compancodeslist#", companycode);
                        //            empQuery = empQuery.Replace('#', '"');

                        //            DataTable employee2 = new DataTable();

                        //            NpgsqlCommand scnpgsqlCommand2 = new NpgsqlCommand(empQuery, npgsqlCon);

                        //            NpgsqlDataAdapter scdataAdapter2 = new NpgsqlDataAdapter(scnpgsqlCommand2);

                        //            scdataAdapter2.Fill(employee2);
                        //            npgsqlCon.Open();

                        //            List<string> rowlist = new List<string>();
                        //            string insertquery = "INSERT INTO public.#WallPostingAllocation# (#PostingID#,#EmpCode#" +
                        //                               ") VALUES #DataList# ;";

                        //            foreach (DataRow row in employee2.Rows)
                        //            {
                        //                string employeeID = row["EXTERNALDATAREFERENCE"].ToString();
                        //                string query = "('" + request.PostingID + "', '" + employeeID + "')";

                        //                rowlist.Add(query);

                        //            }
                        //            string rows = string.Join(",", rowlist);

                        //            insertquery = insertquery.Replace("#DataList#", rows);
                        //            insertquery = insertquery.Replace('#', '"');

                        //            NpgsqlCommand cmd2 = new NpgsqlCommand(insertquery, npgsqlCon);

                        //            NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                        //            checkNext = false;
                        //            break;
                        //        }
                        //    }

                        //}

                        //all user allocation for Program Manager
                        // for now not needed

                        //if (checkNext)
                        //{
                        //    foreach (UserRoles role in request.AssignedRoles)
                        //    {
                        //        if (role.RoleMasterName == "Program Manager")
                        //        {

                        //            // team of user
                        //            string empQuery = string.Empty;
                        //            string countryName = string.Empty;
                        //            empQuery = "select * from #EmployeeMaster# where #EXTERNALDATAREFERENCE# = '#empId#';";
                        //            empQuery = empQuery.Replace("#empId#", request.PostedBy);
                        //            empQuery = empQuery.Replace('#', '"');

                        //            DataTable employeereq = new DataTable();

                        //            NpgsqlCommand scnpgsqlCommand2 = new NpgsqlCommand(empQuery, npgsqlCon);

                        //            NpgsqlDataAdapter scdataAdapter2 = new NpgsqlDataAdapter(scnpgsqlCommand2);

                        //            scdataAdapter2.Fill(employeereq);
                        //            countryName = (employeereq.Rows[0]["COUNTRY"]).ToString();


                        //            string scodeQuery = string.Empty;
                        //            scodeQuery = "select * from #EmployeeMaster# where #EmployeeMaster#.#Active_Separated# = 'Active' AND #COUNTRY# = '#Countryname#';";
                        //            scodeQuery = scodeQuery.Replace("#Countryname#", countryName);

                        //            scodeQuery = scodeQuery.Replace('#', '"');

                        //            DataTable employee = new DataTable();

                        //            NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsqlCon);

                        //            NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                        //            scdataAdapter.Fill(employee);
                        //            npgsqlCon.Open();

                        //            List<string> rowlist = new List<string>();
                        //            string insertquery = "INSERT INTO public.#WallPostingAllocation# (#PostingID#,#EmpCode#" +
                        //                               ") VALUES #DataList# ;";

                        //            foreach (DataRow row in employee.Rows)
                        //            {
                        //                string employeeID = row["EXTERNALDATAREFERENCE"].ToString();
                        //                string query = "('" + request.PostingID + "', '" + employeeID + "')";

                        //                rowlist.Add(query);

                        //            }
                        //            string rows = string.Join(",", rowlist);

                        //            insertquery = insertquery.Replace("#DataList#", rows);
                        //            insertquery = insertquery.Replace('#', '"');

                        //            NpgsqlCommand cmd2 = new NpgsqlCommand(insertquery, npgsqlCon);

                        //            NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                        //            checkNext = false;
                        //            break;
                        //        }
                        //    }

                        //}

                        #endregion


                        if (checkNext)
                        {
                            foreach (UserRoles role in request.AssignedRoles)
                            {
                                if (role.RoleMasterName == "Global Admin")
                                {
                                    checkNext = false;
                                    break;
                                }
                                if (role.RoleMasterName == "Geo Admin")
                                {
                                    checkNext = false;
                                    break;
                                }
                                if (role.RoleMasterName == "Program Manager")
                                {
                                    checkNext = false;
                                    break;
                                }
                            }
                        }

                        //all user allocation for Team Lead

                        if (checkNext)
                        {
                            foreach (UserRoles role in request.AssignedRoles)
                            {
                                if (role.RoleMasterName == "Team Lead")
                                {
                                    // team of user
                                    string subProcessCode = string.Empty;
                                    string scodeQuery = string.Empty;
                                    scodeQuery = "select * from #EmployeeMaster# where #EmployeeMaster#.#Active_Separated# = 'Active' AND #Manager_ID# = '#empId#';";
                                    scodeQuery = scodeQuery.Replace("#empId#", request.PostedBy);
                                    scodeQuery = scodeQuery.Replace('#', '"');

                                    DataTable employee = new DataTable();

                                    NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsqlCon);

                                    NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                                    scdataAdapter.Fill(employee);
                                    npgsqlCon.Open();

                                    List<string> rowlist = new List<string>();
                                    string insertquery = "INSERT INTO public.#WallPostingAllocation# (#PostingID#,#EmpCode#" +
                                                       ") VALUES #DataList# ;";

                                    foreach (DataRow row in employee.Rows)
                                    {
                                        string employeeID = row["EXTERNALDATAREFERENCE"].ToString();
                                        string query = "('" + request.PostingID + "', '" + employeeID + "')";

                                        rowlist.Add(query);

                                    }
                                    string rows = string.Join(",", rowlist);

                                    insertquery = insertquery.Replace("#DataList#", rows);
                                    insertquery = insertquery.Replace('#', '"');

                                    if(rowlist.Count > 0)
                                    {
                                        NpgsqlCommand cmd2 = new NpgsqlCommand(insertquery, npgsqlCon);

                                        NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();
                                    }
                                    

                                    checkNext = false;
                                    break;
                                }
                            }

                        }

                        //all user allocation for participent

                        if (checkNext)
                        {
                            foreach (UserRoles role in request.AssignedRoles)
                            {
                                if (role.RoleMasterName == "Participant")
                                {
                                    // sub process code of user
                                    string subProcessCode = string.Empty;
                                    string scodeQuery = string.Empty;
                                    scodeQuery = "select * from #EmployeeMaster# where #EXTERNALDATAREFERENCE# = '#empId#';";
                                    scodeQuery = scodeQuery.Replace("#empId#", request.PostedBy);
                                    scodeQuery = scodeQuery.Replace('#', '"');

                                    DataTable employee = new DataTable();

                                    NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsqlCon);

                                    NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                                    scdataAdapter.Fill(employee);
                                    subProcessCode = (employee.Rows[0]["DEPARTMENT"]).ToString();

                                    string query = "INSERT INTO public.#WallPostingAllocation#(#PostingID#,#SubProcessCode#" +
                                    ") VALUES('" + request.PostingID + "', '" + subProcessCode + "')";

                                    query = query.Replace('#', '"');

                                    npgsqlCon.Open();

                                    NpgsqlCommand cmd2 = new NpgsqlCommand(query, npgsqlCon);

                                    NpgsqlDataReader dataReader2 = cmd2.ExecuteReader();

                                    checkNext = false;
                                    break;
                                }
                            }

                        }


                    }

                }

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject("Success");
                response.responseMessage = "Success";
                
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ActiveWall-CreatePost", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass ProfanityCheck(ProfanityRequest request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                string apiUrl = appSettings.Value.ProfanityURL;
                string inputJson = JsonConvert.SerializeObject(request);
                WebClient client = new WebClient();
                client.Headers["Content-type"] = "application/json";
                client.Encoding = Encoding.UTF8;
                string jsonResponse = client.UploadString(apiUrl, inputJson);

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject(jsonResponse);
                response.responseMessage = "Success";
                
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ActiveWall-ProfanityCheck", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                response.responseJSON = ex.Message;
            }

            return response;
        }
        public ResponseClass LikePost(WallPostingCommunication request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                //message max count
                int msgCount = 0;
                string sqlQuery1 = "SELECT coalesce(max(#TSequenceNo#),0) as #TSequenceNo# FROM public.#WallPostingCommunication#";

                sqlQuery1 = sqlQuery1.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                if (npgsqlDataReader1.Read())
                {
                    msgCount = Convert.ToInt32(npgsqlDataReader1[0]) + 1;
                    request.MessageID = msgCount;
                }
                else
                {
                    ++msgCount;
                    request.MessageID = msgCount;
                }

                npgsqlCon.Close();

                //insert post data

                string sqlQuery = "INSERT INTO public.#WallPostingCommunication#(#PostingID#,#MessageID#,#EmpCode#,#ActionType#,#Comments#," +
                    "#TSequenceNo#,#ParentMessageID#,#CreatedOn#) VALUES('" + request.PostingID + "', '"  + request.MessageID + "', '" + request.EmpCode + "', " +
                    "'" + request.ActionType + "', '" + request.Comments + "', '" + msgCount + "', '" + request.parentmessageid + "', now()" + ")";

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject("Success");
                response.responseMessage = "Success";
                
            }
            catch (Exception ex)
            {
                //_serviceconnect.LogConnect("ManageTrainingGroup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass HidePost(PostHideBlockRequest request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                //insert post data

                string sqlQuery = "INSERT INTO public.#WallPostingBlock# (#PostingID#,#BlockedBy#,#BlockedDate#" +
                    ") VALUES('" + request.PostingID + "', '"  + request.BlockedBy + "',now()" + ")";

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject("Success");
                response.responseMessage = "Success";
                
            }
            catch (Exception ex)
            {
                //_serviceconnect.LogConnect("ManageTrainingGroup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass DeletePost(PostHideBlockRequest request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                //insert post data

                string sqlQuery = "UPDATE #WallPosting# SET #IsActive# = '0' WHERE #PostingID# = " + request.PostingID + " ;" ;

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject("Success");
                response.responseMessage = "Success";
                
            }
            catch (Exception ex)
            {
                //_serviceconnect.LogConnect("ManageTrainingGroup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass BlockUser(PostHideBlockRequest request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                //insert post data

                string sqlQuery = "INSERT INTO public.#WallPostingBlock#(#EmpCode#,#BlockedBy#,#BlockedDate#" +
                    ") VALUES('" + request.EmpCode + "', '"  + request.BlockedBy + "', now()" + ")";

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject("Success");
                response.responseMessage = "Success";
                
            }
            catch (Exception ex)
            {
                //_serviceconnect.LogConnect("ManageTrainingGroup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public DataRow[] getSubprocess(DataTable subprocess, string departmentCode)
        {
            string selectQuery = "Department_Code='" + departmentCode + "'";
            DataRow[] drSubprocess = subprocess.Select(selectQuery);

            return drSubprocess;
        }

        public ResponseClass PostsList(PostsRequest request)
        {
            ResponseClass response = new ResponseClass();
            string selectQuery = string.Empty;
            string subProcessCode = string.Empty;


            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
            npgsql.Open();

            // sub process code of user
            string scodeQuery = string.Empty;
            scodeQuery = "select * from #EmployeeMaster# where #EXTERNALDATAREFERENCE# = '#empId#';";
            scodeQuery = scodeQuery.Replace("#empId#", request.empId);
            scodeQuery = scodeQuery.Replace('#', '"');

            DataTable employee = new DataTable();

            NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsql);

            NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

            scdataAdapter.Fill(employee);
            subProcessCode = (employee.Rows[0]["DEPARTMENT"]).ToString();
            string subProcessCode2 = (employee.Rows[0]["Sub_Process_Code"]).ToString();

            // posts data

            selectQuery = "SELECT distinct a.#PostingID#, a.#PostingContent#, a.#PostingImage#, a.#PostedBy# as PostedById, a.#PostedOn#,concat(b.#FIRSTNAME#,' ', b.#LASTNAME#) as PostedByName, b.#Job_Title# as userrole,0 as TotalLikes, 0 as TotalComments, 0 as PostCreator, 0 as PostLiked, '' as AttachmentFileName,f.#ProfilePIC# FROM #WallPosting# a LEFT JOIN #EmployeeMaster# b ON a.#PostedBy# = b.#EXTERNALDATAREFERENCE# LEFT JOIN #WallPostingAllocation# c ON a.#PostingID# = c.#PostingID# LEFT JOIN #WallPostingBlock# d ON a.#PostingID# = d.#PostingID# and d.#BlockedBy# = '#empId#' LEFT JOIN #WallPostingBlock# e ON a.#PostedBy# = e.#EmpCode# and e.#BlockedBy# = '#empId#' LEFT JOIN #UserMaster# f ON a.#PostedBy# = f.#EmployeeID# WHERE a.#IsActive# = '1' AND d.#PostingID# IS NULL AND e.#BlockedBy# IS NULL AND (a.#PostedBy# = '#empId#' OR c.#EmpCode# = '#empId#' OR c.#SubProcessCode# = '#EMP_Sub_Process_Code#' OR c.#SubProcessCode# = '#EMP_Sub_Process_Code2#') order by a.#PostingID# desc;";
            selectQuery = selectQuery.Replace("#empId#", request.empId);
            selectQuery = selectQuery.Replace("#EMP_Sub_Process_Code#", subProcessCode);
            selectQuery = selectQuery.Replace("#EMP_Sub_Process_Code2#", subProcessCode2);

            selectQuery = selectQuery.Replace('#', '"');

            DataTable postsList = new DataTable();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(postsList);

            //Likes Count
            string likesQuery = string.Empty;
            likesQuery = "SELECT a.#PostingID#,COUNT(b.#MessageID#) AS TotalLikes FROM #WallPosting# a LEFT JOIN #WallPostingCommunication# b ON a.#PostingID# = b.#PostingID# WHERE b.#ActionType# = 'LIKE' GROUP BY b.#PostingID#,a.#PostingID# ORDER BY a.#PostingID# DESC;"; 
            likesQuery = likesQuery.Replace('#', '"');
            DataTable likesList = new DataTable();

            NpgsqlCommand likesqlCommand = new NpgsqlCommand(likesQuery, npgsql);

            NpgsqlDataAdapter liksDataAdapter = new NpgsqlDataAdapter(likesqlCommand);

            liksDataAdapter.Fill(likesList);

            //Comments Count
            string commentssQuery = string.Empty;
            commentssQuery = "SELECT a.#PostingID#,COUNT(b.#MessageID#) AS TotalComments FROM #WallPosting# a LEFT JOIN #WallPostingCommunication# b ON a.#PostingID# = b.#PostingID# WHERE b.#ActionType# = 'COMMENT' GROUP BY b.#PostingID#,a.#PostingID# ORDER BY a.#PostingID# DESC;";
            commentssQuery = commentssQuery.Replace('#', '"');
            DataTable commentsList = new DataTable();

            NpgsqlCommand commentsqlCommand = new NpgsqlCommand(commentssQuery, npgsql);

            NpgsqlDataAdapter commentsDataAdapter = new NpgsqlDataAdapter(commentsqlCommand);

            commentsDataAdapter.Fill(commentsList);

            // Merge the second DataTable into the first DataTable
            //postsList.Merge(likesList, true, MissingSchemaAction.Add);

            // Adding Posts likes
            foreach (DataRow row1 in postsList.Rows)
            {
                int id = Convert.ToInt32(row1["PostingID"]);
                string postedbyId = row1["postedbyId"].ToString();

                if (postedbyId == request.empId)
                {
                    row1["PostCreator"] = 1;
                }
                else
                {
                    row1["PostCreator"] = 0;
                }

                // add like count
                DataRow[] matchingRows = likesList.Select($"PostingID = {id}");
                if (matchingRows.Length > 0)
                {
                    int likes = Convert.ToInt32(matchingRows[0]["TotalLikes"]);
                    row1["TotalLikes"] = likes; 
                }
                else
                {
                    row1["TotalLikes"] = 0;
                }

                // add Comment count
                DataRow[] matchingRowsComment = commentsList.Select($"PostingID = {id}");
                if (matchingRowsComment.Length > 0)
                {
                    int comments = Convert.ToInt32(matchingRowsComment[0]["TotalComments"]);
                    row1["TotalComments"] = comments; 
                }
                else
                {
                    row1["TotalComments"] = 0;
                }

                                

                //liked by current user
                string likebyquery = "select * from #WallPostingCommunication# where #PostingID# = #PosID# and #ActionType# = 'LIKE' and #EmpCode# = '#empid#' ;";
                likebyquery = likebyquery.Replace("#PosID#", id.ToString());
                likebyquery = likebyquery.Replace("#empid#", request.empId.ToString());
                likebyquery = likebyquery.Replace('#', '"');

                DataTable commentsList2 = new DataTable();

                NpgsqlCommand commentsqlCommand2 = new NpgsqlCommand(likebyquery, npgsql);

                NpgsqlDataAdapter commentsDataAdapter2 = new NpgsqlDataAdapter(commentsqlCommand2);

                commentsDataAdapter2.Fill(commentsList2);
                if(commentsList2.Rows.Count > 0)
                {
                    row1["PostLiked"] = 1;
                }
                else
                {
                    row1["PostLiked"] = 0;
                }

                //posts attachment
                string attchquery = "select * from #WallPostingAttachment# where #PostingID# = #PosID# ;";
                attchquery = attchquery.Replace("#PosID#", id.ToString());
                attchquery = attchquery.Replace('#', '"');

                DataTable commentsList23 = new DataTable();

                NpgsqlCommand commentsqlCommand23 = new NpgsqlCommand(attchquery, npgsql);

                NpgsqlDataAdapter commentsDataAdapter23 = new NpgsqlDataAdapter(commentsqlCommand23);

                commentsDataAdapter23.Fill(commentsList23);
                if(commentsList23.Rows.Count > 0)
                {
                    string attachment = (commentsList23.Rows[0]["AttachmentFileName"]).ToString();
                    row1["AttachmentFileName"] = attachment;
                }
            }

            npgsql.Close();
            response.responseCode = 1;
            response.responseJSON = JsonConvert.SerializeObject(postsList);

            return response;
        }
        
        public ResponseClass GetUserSearchList(SearchRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable usersList = new DataTable();
            string selectQuery = string.Empty;
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

            bool checkNext = true;


            if (request.AssignedRoles.Count > 0)
            {
                //mySessionObjectRoles.Any(obj => obj.RoleMasterName == "Geo Admin")

                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Global Admin")
                        {
                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR (CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#) ILIKE '%#searchinput#%') OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%' ORDER BY UserName ;";
                            checkNext = false;
                            break;
                        }
                    }

                }

                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Geo Admin")
                        {
                            //SELECT * FROM #UserCompanyAssignment# where #EmployeeCode#='198739';
                            string scodeQuery = string.Empty;
                            string subProcessCode = string.Empty;
                            scodeQuery = "SELECT * FROM #UserCompanyAssignment# where #EmployeeCode#= '#empId#';";
                            scodeQuery = scodeQuery.Replace("#empId#", request.empId);
                            scodeQuery = scodeQuery.Replace('#', '"');

                            DataTable employee = new DataTable();
                            npgsql.Open();

                            NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsql);

                            NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                            scdataAdapter.Fill(employee);
                            npgsql.Close();

                            List<string> companycodelist = new List<string>(); 

                            foreach (DataRow row1 in employee.Rows)
                            {
                                string id = row1["CompanyCode"].ToString();
                                if(id != null && id != "")
                                {
                                    companycodelist.Add("'" + id + "'");
                                }

                            }

                            string companycode = string.Join(",", companycodelist);

                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #COMPANY_CODE# IN ( #Compancodeslist# ) AND #EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR (CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#) ILIKE '%#searchinput#%') OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%' ORDER BY UserName ;";
                            selectQuery = selectQuery.Replace("#Compancodeslist#", companycode);
                            
                            checkNext = false;
                            break;
                        }
                    }

                }

                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Program Manager")
                        {
                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #COUNTRY# = '#Countryname#' AND #EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR (CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#) ILIKE '%#searchinput#%')  OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%' ORDER BY UserName ;";
                            selectQuery = selectQuery.Replace("#Countryname#",request.CountryName);
                            checkNext = false;
                            break;
                        }
                    }

                }


                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Team Lead")
                        {
                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #EmployeeMaster#.#Active_Separated# = 'Active' AND #EmployeeMaster#.#Manager_ID# = '#MangerID#' AND (#EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%') ORDER BY UserName ;";
                            selectQuery = selectQuery.Replace("#MangerID#", request.empId);
                            checkNext = false;
                            break;
                        }
                    }

                }


                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Participant")
                        {
                            // sub process code of user
                            string scodeQuery = string.Empty;
                            string subProcessCode = string.Empty;
                            scodeQuery = "select * from #EmployeeMaster# where #EXTERNALDATAREFERENCE# = '#empId#';";
                            scodeQuery = scodeQuery.Replace("#empId#", request.empId);
                            scodeQuery = scodeQuery.Replace('#', '"');

                            DataTable employee = new DataTable();
                            npgsql.Open();

                            NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsql);

                            NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                            scdataAdapter.Fill(employee);
                            subProcessCode = (employee.Rows[0]["Sub_Process_Code"]).ToString();
                            npgsql.Close();

                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #EmployeeMaster#.#Sub_Process_Code# = '#EMP_Sub_Process_Code#' AND (#EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR (CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#) ILIKE '%#searchinput#%')  OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%') ORDER BY UserName ;";
                            selectQuery = selectQuery.Replace("#EMP_Sub_Process_Code#", subProcessCode);
                            break;
                        }
                    }

                }

            }

            //selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# ORDER BY 1 DESC limit 200;";
            
            selectQuery = selectQuery.Replace("#searchinput#", request.SearchInput);
            selectQuery = selectQuery.Replace('#', '"');

            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(usersList);

            npgsql.Close();
            response.responseCode = 1;
            response.responseJSON = JsonConvert.SerializeObject(usersList);

            return response;
        }
        
        public ResponseClass GetUserGroupList(SearchRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable groupsList = new DataTable();
            string selectQuery = string.Empty;
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);


            selectQuery = "SELECT #TrainingGroup#.#TrainingGroupID#,#TrainingGroup#.#TrainingGroupCode#,#TrainingGroup#.#TrainingGroupName#,#TrainingGroup#.#InsertedBy# FROM PUBLIC.#TrainingGroup# WHERE #TrainingGroup#.#DeletedFlag# = '0' AND #TrainingGroup#.#InsertedBy# = '#empId#';";

            selectQuery = selectQuery.Replace("#empId#", request.empId);
            selectQuery = selectQuery.Replace('#', '"');

            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(groupsList);

            npgsql.Close();
            response.responseCode = 1;
            response.responseJSON = JsonConvert.SerializeObject(groupsList);

            return response;
        }
        
        public ResponseClass GetUserGradeList(SearchRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable usersList = new DataTable();
            string selectQuery = string.Empty;
            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

            bool checkNext = true;


            if (request.AssignedRoles.Count > 0)
            {
                //mySessionObjectRoles.Any(obj => obj.RoleMasterName == "Geo Admin")

                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Global Admin")
                        {
                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%' ORDER BY UserName ;";
                            checkNext = false;
                            break;
                        }
                    }

                }

                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Geo Admin")
                        {
                            //SELECT * FROM #UserCompanyAssignment# where #EmployeeCode#='198739';
                            string scodeQuery = string.Empty;
                            string subProcessCode = string.Empty;
                            scodeQuery = "SELECT * FROM #UserCompanyAssignment# where #EmployeeCode#= '#empId#';";
                            scodeQuery = scodeQuery.Replace("#empId#", request.empId);
                            scodeQuery = scodeQuery.Replace('#', '"');

                            DataTable employee = new DataTable();
                            npgsql.Open();

                            NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsql);

                            NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                            scdataAdapter.Fill(employee);
                            npgsql.Close();

                            List<string> companycodelist = new List<string>(); 

                            foreach (DataRow row1 in employee.Rows)
                            {
                                string id = row1["CompanyCode"].ToString();
                                if(id != null && id != "")
                                {
                                    companycodelist.Add("'" + id + "'");
                                }

                            }

                            string companycode = string.Join(",", companycodelist);

                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #COMPANY_CODE# IN ( #Compancodeslist# ) AND #EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%' ORDER BY UserName ;";
                            selectQuery = selectQuery.Replace("#Compancodeslist#", companycode);
                            
                            checkNext = false;
                            break;
                        }
                    }

                }

                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Program Manager")
                        {
                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #COUNTRY# = '#Countryname#' AND #EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%' ORDER BY UserName ;";
                            selectQuery = selectQuery.Replace("#Countryname#",request.CountryName);
                            checkNext = false;
                            break;
                        }
                    }

                }


                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Team Lead")
                        {
                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #EmployeeMaster#.#Active_Separated# = 'Active' AND #EmployeeMaster#.#Manager_ID# = '#MangerID#' AND (#EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%') ORDER BY UserName ;";
                            selectQuery = selectQuery.Replace("#MangerID#", request.empId);
                            checkNext = false;
                            break;
                        }
                    }

                }


                if (checkNext)
                {
                    foreach (UserRoles role in request.AssignedRoles)
                    {
                        if (role.RoleMasterName == "Participant")
                        {
                            // sub process code of user
                            string scodeQuery = string.Empty;
                            string subProcessCode = string.Empty;
                            scodeQuery = "select * from #EmployeeMaster# where #EXTERNALDATAREFERENCE# = '#empId#';";
                            scodeQuery = scodeQuery.Replace("#empId#", request.empId);
                            scodeQuery = scodeQuery.Replace('#', '"');

                            DataTable employee = new DataTable();
                            npgsql.Open();

                            NpgsqlCommand scnpgsqlCommand = new NpgsqlCommand(scodeQuery, npgsql);

                            NpgsqlDataAdapter scdataAdapter = new NpgsqlDataAdapter(scnpgsqlCommand);

                            scdataAdapter.Fill(employee);
                            subProcessCode = (employee.Rows[0]["Sub_Process_Code"]).ToString();
                            npgsql.Close();

                            selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# WHERE #EmployeeMaster#.#Active_Separated# = 'Active' AND #EmployeeMaster#.#Sub_Process_Code# = '#EMP_Sub_Process_Code#' AND (#EmployeeMaster#.#FIRSTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#LASTNAME# ILIKE '%#searchinput#%' OR #EmployeeMaster#.#EXTERNALDATAREFERENCE# ILIKE '%#searchinput#%') ORDER BY UserName ;";
                            selectQuery = selectQuery.Replace("#EMP_Sub_Process_Code#", subProcessCode);
                            break;
                        }
                    }

                }

            }

            //selectQuery = "SELECT DISTINCT #EmployeeMaster#.#EXTERNALDATAREFERENCE# as EmpID,CONCAT(#EmployeeMaster#.#FIRSTNAME#,' ',#EmployeeMaster#.#LASTNAME#,' (',#EmployeeMaster#.#EXTERNALDATAREFERENCE#,')') as UserName FROM #EmployeeMaster# ORDER BY 1 DESC limit 200;";
            
            selectQuery = selectQuery.Replace("#searchinput#", request.SearchInput);
            selectQuery = selectQuery.Replace('#', '"');

            npgsql.Open();

            NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

            NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

            dataAdapter.Fill(usersList);

            npgsql.Close();
            response.responseCode = 1;
            response.responseJSON = JsonConvert.SerializeObject(usersList);

            return response;
        }
        
        public ResponseClass GetCommentList(commentRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable usersList = new DataTable();
            string selectQuery = string.Empty;

            
            if(request.SearchInput != "")
            {

                selectQuery = "SELECT a.#PostingID#,a.#MessageID#,0 as TotalLikes,0 as CommentsLiked, a.#EmpCode#,a.#Comments#,a.#EmpCode#,a.#CreatedOn#,concat(b.#FIRSTNAME#,' ', b.#LASTNAME#) as PostedByName FROM #WallPostingCommunication# a LEFT JOIN #EmployeeMaster# b ON a.#EmpCode# = b.#EXTERNALDATAREFERENCE# WHERE a.#ActionType# = 'COMMENT' and a.#PostingID# = #requestID# ORDER BY a.#CreatedOn# DESC;";

                selectQuery = selectQuery.Replace("#requestID#", request.SearchInput);
                selectQuery = selectQuery.Replace('#', '"');

                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(usersList);

                //Comments Count
                string commentssQuery = string.Empty;
                commentssQuery = "select a.#ParentMessageID#,count(a.*) as totallikes from #WallPostingCommunication# a inner join #WallPostingCommunication# b on a.#ParentMessageID# = b.#MessageID# group by a.#ParentMessageID#;";
                commentssQuery = commentssQuery.Replace('#', '"');
                DataTable commentsList = new DataTable();

                NpgsqlCommand commentsqlCommand = new NpgsqlCommand(commentssQuery, npgsql);

                NpgsqlDataAdapter commentsDataAdapter = new NpgsqlDataAdapter(commentsqlCommand);

                commentsDataAdapter.Fill(commentsList);

                // Adding Comments likes
                foreach (DataRow row1 in usersList.Rows)
                {
                    int id = Convert.ToInt32(row1["MessageID"]);

                    // add like count
                    DataRow[] matchingRows = commentsList.Select($"ParentMessageID = {id}");
                    if (matchingRows.Length > 0)
                    {
                        int likes = Convert.ToInt32(matchingRows[0]["totallikes"]);
                        row1["TotalLikes"] = likes;
                    }
                    else
                    {
                        row1["TotalLikes"] = 0;
                    }

                    //liked by current user
                    string likebyquery = "select * from #WallPostingCommunication# where #ParentMessageID# = #MSGID# and #ActionType# = 'LIKE' and #EmpCode# = '#empid#' ;";
                    likebyquery = likebyquery.Replace("#MSGID#", id.ToString());
                    likebyquery = likebyquery.Replace("#empid#", request.empId.ToString());
                    likebyquery = likebyquery.Replace('#', '"');

                    DataTable commentsList2 = new DataTable();

                    NpgsqlCommand commentsqlCommand2 = new NpgsqlCommand(likebyquery, npgsql);

                    NpgsqlDataAdapter commentsDataAdapter2 = new NpgsqlDataAdapter(commentsqlCommand2);

                    commentsDataAdapter2.Fill(commentsList2);
                    if (commentsList2.Rows.Count > 0)
                    {
                        row1["CommentsLiked"] = 1;
                    }
                    else
                    {
                        row1["CommentsLiked"] = 0;
                    }

                }

                npgsql.Close();
            }

            response.responseCode = 1;
            response.responseJSON = JsonConvert.SerializeObject(usersList);

            return response;
        }

        public ResponseClass LikeComment(WallPostingCommunication request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                //message max count
                int msgCount = 0;
                string sqlQuery1 = "SELECT coalesce(max(#TSequenceNo#),0) as #TSequenceNo# FROM public.#WallPostingCommunication#";

                sqlQuery1 = sqlQuery1.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                if (npgsqlDataReader1.Read())
                {
                    msgCount = Convert.ToInt32(npgsqlDataReader1[0]) + 1;
                    request.MessageID = msgCount;
                }
                else
                {
                    ++msgCount;
                    request.MessageID = msgCount;
                }

                npgsqlCon.Close();

                //insert comment like data

                string sqlQuery = "INSERT INTO public.#WallPostingCommunication#(#ParentMessageID#,#MessageID#,#EmpCode#,#ActionType#,#Comments#," +
                    "#TSequenceNo#,#ParentMessageID#,#CreatedOn#) VALUES('" + request.parentmessageid + "', '" + request.MessageID + "', '" + request.EmpCode + "', " +
                    "'" + request.ActionType + "', '" + RemoveQuotes(request.Comments) + "', '" + msgCount + "', '" + request.parentmessageid + "', now()" + ")";

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject("Success");
                response.responseMessage = "Success";

            }
            catch (Exception ex)
            {
                //_serviceconnect.LogConnect("ManageTrainingGroup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
        public ResponseClass ProfanityCheck(WallPostingCommunication request)
        {
            ResponseClass response = new ResponseClass();

            string pgsqlConnection = appSettings.Value.DbConnection;
            NpgsqlConnection npgsqlCon = new NpgsqlConnection(pgsqlConnection);

            try
            {
                //message max count
                int msgCount = 0;
                string sqlQuery1 = "SELECT coalesce(max(#TSequenceNo#),0) as #TSequenceNo# FROM public.#WallPostingCommunication#";

                sqlQuery1 = sqlQuery1.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand npgsqlCommand1 = new NpgsqlCommand(sqlQuery1, npgsqlCon);

                NpgsqlDataReader npgsqlDataReader1 = npgsqlCommand1.ExecuteReader();

                if (npgsqlDataReader1.Read())
                {
                    msgCount = Convert.ToInt32(npgsqlDataReader1[0]) + 1;
                    request.MessageID = msgCount;
                }
                else
                {
                    ++msgCount;
                    request.MessageID = msgCount;
                }

                npgsqlCon.Close();

                //insert comment like data

                string sqlQuery = "INSERT INTO public.#WallPostingCommunication#(#ParentMessageID#,#MessageID#,#EmpCode#,#ActionType#,#Comments#," +
                    "#TSequenceNo#,#ParentMessageID#,#CreatedOn#) VALUES('" + request.parentmessageid + "', '" + request.MessageID + "', '" + request.EmpCode + "', " +
                    "'" + request.ActionType + "', '" + RemoveQuotes(request.Comments) + "', '" + msgCount + "', '" + request.parentmessageid + "', now()" + ")";

                sqlQuery = sqlQuery.Replace('#', '"');

                npgsqlCon.Open();

                NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgsqlCon);

                NpgsqlDataReader dataReader = cmd.ExecuteReader();

                npgsqlCon.Close();

                response.responseCode = 1;
                response.responseJSON = JsonConvert.SerializeObject("Success");
                response.responseMessage = "Success";

            }
            catch (Exception ex)
            {
                //_serviceconnect.LogConnect("ManageTrainingGroup", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getTreeData(getAWTreeDataRequest request)
        {
            string htmlData = "";
            ResponseClass response = new ResponseClass();
            string companiestopass = string.Empty;


            if (request.currentRole == "Geo Admin")
            {
                DataTable dtCompanies = new DataTable();
                dtCompanies = _qualtricsBL.gtAssignedCompany(request.LoggedInUser);
                if (dtCompanies != null && dtCompanies.Rows.Count > 0)
                {
                    foreach (DataRow exclude in dtCompanies.Rows)
                    {
                        companiestopass = companiestopass + Convert.ToString(exclude["CompanyCode"]) + ",";
                        //companiestopass = companiestopass + "'" + Convert.ToString(exclude["CompanyCode"]) + "',";
                    }

                    companiestopass = companiestopass.TrimEnd(',');

                }
            }
            else if (request.currentRole == "Program Manager")
            {
                companiestopass = request.requestData;
            }
            try
            {
                SqlParameter[] parameter = {
                new SqlParameter("@CountryName",companiestopass),

                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_get_tree_data", parameter, outParameters);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    //response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    foreach (DataRow companies in dsResult.Tables[0].Rows)
                    {
                        htmlData = htmlData + "<li data-company='" + Convert.ToString(companies["COMPANY_CODE"]) + "'><input type='checkbox' value='" + Convert.ToString(companies["COMPANY_CODE"]) + "'><label>" + Convert.ToString(companies["Company_Name"]) + " </label>";
                        string selectQuery = "COMPANY_CODE='" + Convert.ToString(companies["COMPANY_CODE"]) + "'";
                        // get department
                        DataRow[] drDepartment = dsResult.Tables[1].Select(selectQuery);
                        if (drDepartment.Length != 0)
                        {
                            htmlData = htmlData + "<ul>";
                            foreach (DataRow item in drDepartment)
                            {
                                htmlData = htmlData + "<li data-department='" + Convert.ToString(item["Department_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(item["Department_Code"]) + "'><label>" + Convert.ToString(item["DEPARTMENT"]) + " </label>";

                                DataRow[] drSubProcess = getSubprocess(dsResult.Tables[2], Convert.ToString(item["Department_Code"]));
                                if (drSubProcess.Length != 0)
                                {
                                    htmlData = htmlData + "<ul>";
                                    foreach (DataRow sub in drSubProcess)
                                    {
                                        htmlData = htmlData + "<li data-subproces='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><input type='checkbox' value='" + Convert.ToString(sub["Sub_Process_Code"]) + "'><label>" + Convert.ToString(sub["Sub_Process"]) + " </label></li>";
                                    }
                                    htmlData = htmlData + "</ul>";
                                }

                                htmlData = htmlData + "</li>";

                            }
                            htmlData = htmlData + "</ul>";
                        }

                        htmlData = htmlData + "</li>";
                    }

                }

                response.responseCode = 1;
                response.responseMessage = htmlData;

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("getTreeData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }



            return response;
        }


    }
}
