﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ActiveWall
{
    public class WallPostingDTO
    {
        public int TID { get; set; }
        public int PostingID { get; set; }
        public string PostingSubject { get; set; }
        public string PostingContent { get; set; }
        public string PostingImage { get; set; }
        public string PostedBy { get; set; }
        public string PostedOn { get; set; }
        public string PostImage { get; set; }
        public string CountryName { get; set; }
        public List<WallPostingAttachment> AttachmentsList { get; set; }
        //public List<WallPostingAllocation> AllocationList { get; set; }
        public bool VisibilityFilter { get; set; }
        public bool AllEmployee { get; set; }
        public List<string> EmployeeList { get; set; }

        public List<AllocatedUsers> AllocationList { get; set; }
        public string SubProcesses { get; set; }

        public List<AllocationGroup> GroupList { get; set; }

        public List<UserRoles> AssignedRoles { get; set; }
    }

    public class WallPostingAttachment
    {
        public int TID { get; set; }
        public int PostingID { get; set; }
        public string AttachmentFileName { get; set; }
        public string PostedBy { get; set; }
        public DateTime PostedOn { get; set; }
    }


    public class AllocationGroup
    {
        public string grpid { get; set; }
    }

    public class getAWTreeDataRequest
    {
        public string requestData { get; set; }
        public string currentRole { get; set; }
        public string LoggedInUser { get; set; }

        public List<UserRoles> AssignedRoles { get; set; }
    }


    public class WallPostingCommentLikes
    {
        public int TID { get; set; }
        public int PostingID { get; set; }
        public int MessageID { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }

    public class WallPostingAllocation
    {
        public int TID { get; set; }
        public int PostingID { get; set; }
        public int SubProcessCode { get; set; }
        public string EmpCode { get; set; }
    }

    public class WallPostingCommunication
    {
        public int TID { get; set; }
        public int PostingID { get; set; }
        public int MessageID { get; set; }
        public string EmpCode { get; set; }
        public string ActionType { get; set; }
        public string Comments { get; set; }
        public int parentmessageid { get; set; }
        public int CreatedBy { get; set; }
        public int TSequenceno { get; set; }
        public DateTime CreatedOn { get; set; }
        
    }

    public class AllocatedUsers
    {
        public string empid { get; set; }
        public string username { get; set; }
    }

    public class SearchRequest
    {
        public string SearchInput { get; set; }
        public string empId { get; set; }
        public string CountryName { get; set; }

        public List<UserRoles> AssignedRoles { get; set; }
    }

    public class commentRequest
    {
        public string SearchInput { get; set; }

        public List<UserRoles> AssignedRoles { get; set; }

        public string empId { get; set; }
    }
    public class PostHideBlockRequest
    {
        public string EmpCode { get; set; }
        public string PostingID { get; set; }
        public string BlockedBy { get; set; }
    }
    public class PostsRequest
    {
        public string empId { get; set; }
    }

    public class UserRoles
    {
        public string EmployeeID { get; set; }
        public string RoleMasterName { get; set; }
    }


    public class ProfanityRequest
    {
        public string input_text { get; set; }
    }
}
