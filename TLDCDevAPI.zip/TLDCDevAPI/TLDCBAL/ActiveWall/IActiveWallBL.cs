﻿using TLDCBAL.Common;
using TLDCBAL.Schedulers;

namespace TLDCBAL.ActiveWall
{
    public interface IActiveWallBL
    {
        ResponseClass CreatePost(WallPostingDTO request);
        ResponseClass ProfanityCheck(ProfanityRequest request);
        ResponseClass LikePost(WallPostingCommunication request);
        ResponseClass getTreeData(getAWTreeDataRequest companyCode);
        ResponseClass PostsList(PostsRequest request);
        ResponseClass GetUserSearchList(SearchRequest request);
        ResponseClass GetCommentList(commentRequest request);
        ResponseClass HidePost(PostHideBlockRequest request);
        ResponseClass DeletePost(PostHideBlockRequest request);
        ResponseClass BlockUser(PostHideBlockRequest request);
        ResponseClass LikeComment(WallPostingCommunication request);
        ResponseClass GetUserGroupList(SearchRequest request);
        ResponseClass GetUserGradeList(SearchRequest request);
    }
}
