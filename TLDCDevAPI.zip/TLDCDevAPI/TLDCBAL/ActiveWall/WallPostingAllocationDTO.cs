﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.ActiveWall
{
    public class WallPostingAllocationDTO
    {
        public int TID { get; set; }
        public int PostingID { get; set; }
        public int SubProcessCode { get; set; }
        public string EmpCode { get; set; }
    }
}
