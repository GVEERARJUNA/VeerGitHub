﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCBAL.WebSite
{
   public class getAgentHomePageDTO
    {
        public string UserName { get; set; }
        public string Action { get; set; }

        public string LearningType { get; set; }
        public string AssetType { get; set; }
    }

    public class getAgentModuleDataDTO
    {
        public string UserName { get; set; }
        public string ModuleCode { get; set; }
        public string CurrentRole { get; set; }
        public string EntityType { get; set; }
    }
    public class getAgentDashboardCountDTO
    {
        public string currentUser { get; set; }
        public string UserName { get; set; }
        public string CurrentRole { get; set; }
        public string ModuleAllocationID { get; set; }
        public string Action { get; set; }
    }

    public class getUpcomingTrainingRequestDTO
    {
        public string UserName { get; set; }
        public string CurrentRole { get; set; }
    }

    public class updateModuleLearningStatusRequestDTO
    {
        public string ModuleAllocationID { get; set; }
        public string UserName { get; set; }
        public string ECLDID { get; set; }
        public string Action { get; set; }
        public string InsertedIPAddress { get; set; }
        public string InsertedBy { get; set; }
        public string AssessmentStartDate { get; set; }
        public string AssessmentEndDate { get; set; }
        public string TotalDurationSecond { get; set; }
    }

    public class pushAssessmentResultrequestDTO
    {
        public string AllocationCode { get; set; }
        public string AssessmentScheduleID { get; set; }
        public string AssessmentStartDate { get; set; }
        public string AssessmentEndDate { get; set; }
        public double TotalScore { get; set; }
        public string ScoreGrade { get; set; }
        public int AttemptNo { get; set; }
        public string InsertedIPAddress { get; set; }
        public string InsertedBy { get; set; }
        public string ResultFlag { get; set; }

        public int IsLastAttempt { get; set; }

        public Double MinMarks { get; set; }
        public Double MaxMarks { get; set; }
        public Double MarksObtained { get; set; }

        public string ReattemptDateTime { get; set; }
    }
    public class readISAPrequestDTO
    {
        public string UserName { get; set; }
        public string ModuleCode { get; set; }
        public string CurrentRole { get; set; }
    }

    public class getUserMenu
    {
        public string UserName { get; set; }
        public string CurrentRole { get; set; }
    }

    public class AssessmentResultDetail
    {
        public string AssessmentScheduleID { get; set; }
        public string AssessmentQuestion { get; set; }
        public string OptedAnswer { get; set; }
        public string CorrectAnswer { get; set; }
        public string isCorrect { get; set; }
    }

    public class AssessmentResultDetailRequestDTO
    {
        public List<AssessmentResultDetail> assessmentResultDetails { get; set; }
    }

    public class  getAssessmentResultDetailDTO
    {
        public string AssessmentScheduleID { get; set; }
    }
    public class getEmployeeCertificateRequest
    {
        public string UserName { get; set; }
        public string CurrentRole { get; set; }

        public string AllocationID { get; set; }
        public string strtDate { get; set; }
        public string endDate { get; set; }
    }
    public class ISAPExtensionRequestDTO
    {
        public string UserName { get; set; }
    }

    public class ExtendISAPRequestDTO
    {
        public string ModuleAllocationID { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string InsertedIPAddress { get; set; }
        public string InsertedBy { get; set; }
    }

    public class ISAPExtensionRequestDepartmentDTO
    {
        public string CompanyCode { get; set; }
        public string Department { get; set; }
    }

    public class getHighlightedText
    {
        public string VideoCode { get; set; }
    }

    public class AssetLikeRequestDTO
    {
        public string PrimaryID { get; set; }
    }

    public class MenuRoleMapping
    {
        public int MenuID { get; set; }
        public string RoleName { get; set; }
    }

    public class checkUserVisit
    {
        public string UserName { get; set; }
    }

    public class getEventProgramdaysRequest
    {
        public string EventCode { get; set; }
    }

    public class getprogramdependency
    {
        public string AssetDetailID { get; set; }
    }

    public class getsurveyview
    {
        public string EmployeeCode { get; set; }
        public string SurveyID { get; set; }
    }

    public class getassessmentview
    {
        public string TLDCID { get; set; }
    }

    public class getVideoChannelDTO
    {
        public string EmployeeCode { get; set; }
        public string CurrentRole { get; set; }
        public string Action { get; set; }
    }

    public class insertvideoprogressrequestDTO
    {
        public string LearningDetailID { get; set; }
        public string LearningMode { get; set; }

        public string ProgressTime { get; set; }

        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }
}
