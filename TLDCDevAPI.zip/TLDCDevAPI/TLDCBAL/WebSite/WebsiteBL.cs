﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;
using TLDCBAL.Common;
using TLDCBAL.Configuration;
using TLDCBAL.Qualtrics;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;
using TLDCDAL;
using TLDCBAL.MobApp;
using TLDCBAL.ProgramManager;

namespace TLDCBAL.WebSite
{
    public class WebsiteBL : IWebsiteBL
    {
        private readonly IServiceConnect _serviceconnect;
        private IQualtricsDataBL _qualtricsBL;
        private ISchedulerBL _scheduleBL;
         DBConnection AssessmentdBConnection;
        DBConnection SurveyDBConnection;
        //public WebsiteBL(IServiceConnect serviceconnect)
        //{
        //    _serviceconnect = serviceconnect;
        //}

        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        public WebsiteBL(IOptions<IDBConnection> app, IServiceConnect serviceconnect,
            IQualtricsDataBL qualtricsBL, ISchedulerBL scheduleBL)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.QualtricsDbConnection);
            AssessmentdBConnection = new DBConnection(appSettings.Value.AssessmentDBConnection);
            SurveyDBConnection = new DBConnection(appSettings.Value.SurveyDBConnection);
            _serviceconnect = serviceconnect;
            _qualtricsBL = qualtricsBL;
            _scheduleBL = scheduleBL;
        }

        public ResponseClass GetAgntHomePage(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

            
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_agent_homepage
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAgntHomePage", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetParticipantToDo(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_particpant_todo
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAgntHomePage", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetAgntLearningMAterial(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_my_learning
                                                                ( 
                                                                    :p_username,
                                                                    :p_action,:p_learningtype,:p_assettype
                                                                    
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.LearningType))
                            cmd.Parameters.AddWithValue("p_learningtype", DbType.String).Value = request.LearningType;
                        else
                            cmd.Parameters.AddWithValue("p_learningtype", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.AssetType))
                            cmd.Parameters.AddWithValue("p_assettype", DbType.String).Value = request.AssetType;
                        else
                            cmd.Parameters.AddWithValue("p_assettype", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAgntLearningMAterial", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass geteedsdata(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_eeds_data
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action,:p_learningtype,:p_assettype
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.LearningType))
                            cmd.Parameters.AddWithValue("p_learningtype", DbType.String).Value = request.LearningType;
                        else
                            cmd.Parameters.AddWithValue("p_learningtype", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.AssetType))
                            cmd.Parameters.AddWithValue("p_assettype", DbType.String).Value = request.AssetType;
                        else
                            cmd.Parameters.AddWithValue("p_assettype", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("geteedsdata", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetSeedMaterial(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_partcipant_seed
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAgntLearningMAterial", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetModuleCodeDetails(getAgentModuleDataDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_website_get_moduledetails
                                                                    ( 
                                                                        :p_username,
                                                                        :p_modulecode,
                                                                        :p_currentrole
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.UserName))
                        cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                    else
                        cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(request.ModuleCode))
                        cmd.Parameters.AddWithValue("p_modulecode", DbType.String).Value = request.ModuleCode;
                    else
                        cmd.Parameters.AddWithValue("p_modulecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(request.CurrentRole))
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                    else
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

        public ResponseClass GetBULaunchPageDetails(getAgentModuleDataDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_bu_launch_details
                                                                    ( 
                                                                        :p_username,
                                                                        :p_modulecode,
                                                                        :p_currentrole,:p_entitytype
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.ModuleCode))
                            cmd.Parameters.AddWithValue("p_modulecode", DbType.String).Value = request.ModuleCode;
                        else
                            cmd.Parameters.AddWithValue("p_modulecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.EntityType))
                            cmd.Parameters.AddWithValue("p_entitytype", DbType.String).Value = request.EntityType;
                        else
                            cmd.Parameters.AddWithValue("p_entitytype", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                        //if (dtEmployees.Rows.Count>0)
                        //{
                        //    // ContentCode
                        //    DataTable dtHighlights = new DataTable();
                        //    dtHighlights = getVideoHighlights(Convert.ToString(dtEmployees.Rows[0]["modulecode"]));
                        //    if (dtHighlights!=null && dtHighlights.Rows.Count>0)
                        //    {
                        //        response.responseJSONSecondary = JsonConvert.SerializeObject(dtHighlights);
                        //    }
                        //}

                        // get 


                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAgntHomePage", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            
            return response;
        }

        public ResponseClass getVideoHighlights(getHighlightedText request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtHighlights = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            string selectQuery = string.Empty;
            try
            {
                selectQuery = "select #DurationMinute#,#DurationSecond#,#HighlightedText# from #VideoHighlights# where #VideoCode#='" + request.VideoCode + "'; ";
                selectQuery = selectQuery.Replace('#', '"');

                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtHighlights);
                npgsql.Close();
                dtHighlights.Columns.Add("TextToShow");
                if (dtHighlights.Rows.Count > 0)
                {
                    foreach (DataRow item in dtHighlights.Rows)
                    {
                        string Minute = string.Empty;
                        string second = string.Empty;
                        string text = string.Empty;
                        string TexttoShow = string.Empty;

                        Minute = Convert.ToString(item["DurationMinute"]);
                        second = Convert.ToString(item["DurationSecond"]);
                        text = Convert.ToString(item["HighlightedText"]);

                        if (Minute.Length == 1)
                        {
                            Minute = "0" + Minute;
                        }

                        if (second.Length == 1)
                        {
                            second = "0" + second;
                        }

                        TexttoShow = Minute + ":" + second + " - " + text;

                        item["TextToShow"] = TexttoShow;

                    }

                }
                response.responseJSON = JsonConvert.SerializeObject(dtHighlights);
            }
            catch (Exception)
            {

              
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;

        }

        public ResponseClass GetUpcomingTraining(getUpcomingTrainingRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_website_get_upcoming_modules
                                                                    ( 
                                                                        :p_username,
                                                                        :p_currentrole
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.UserName))
                        cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                    else
                        cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(request.CurrentRole))
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                    else
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();

                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

        public ResponseClass GetActiveModuleDetails(getAgentModuleDataDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_website_active_moduledetails
                                                                    ( 
                                                                        :p_username,
                                                                        :p_modulecode,
                                                                        :p_currentrole
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.UserName))
                        cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                    else
                        cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(request.ModuleCode))
                        cmd.Parameters.AddWithValue("p_modulecode", DbType.String).Value = request.ModuleCode;
                    else
                        cmd.Parameters.AddWithValue("p_modulecode", DbType.String).Value = DBNull.Value;

                    if (!String.IsNullOrEmpty(request.CurrentRole))
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                    else
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

        public ResponseClass ExtendISAP(ExtendISAPRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.ModuleAllocationID))
            {
                response.responseCode = 0;
                response.responseMessage = "ModuleAllocationID required";
                return response;
            }
            if (string.IsNullOrEmpty(request.StartDate))
            {
                response.responseCode = 0;
                response.responseMessage = "StartDate required";
                return response;
            }
            if (string.IsNullOrEmpty(request.EndDate))
            {
                response.responseCode = 0;
                response.responseMessage = "EndDate required";
                return response;
            }
            if (string.IsNullOrEmpty(request.InsertedBy))
            {
                response.responseCode = 0;
                response.responseMessage = "InsertedBy required";
                return response;
            }
            if (string.IsNullOrEmpty(request.InsertedIPAddress))
            {
                response.responseCode = 0;
                response.responseMessage = "InsertedIPAddress required";
                return response;
            }
            string startDate = string.Empty;
            string endDate = string.Empty;
            try
            {
                startDate = Convert.ToDateTime(request.StartDate).ToString("yyyy-MM-dd");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ExtendISAP", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid AssessmentStartDate";
                return response;


            }

            try
            {
                endDate = Convert.ToDateTime(request.EndDate).ToString("yyyy-MM-dd");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("ExtendISAP", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid EndDate";
                return response;


            }

            DataTable dtEmployees = new DataTable();
            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_extend_isap
                                                                    ( 
                                                                        :p_mallocationid,
                                                                        :p_startdate,:penddate,
                                                                        :p_insertedby,:p_insertedipaddress
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.ModuleAllocationID))
                            cmd.Parameters.AddWithValue("p_mallocationid", DbType.String).Value = request.ModuleAllocationID;
                        else
                            cmd.Parameters.AddWithValue("p_mallocationid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(startDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = startDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(endDate))
                            cmd.Parameters.AddWithValue("penddate", DbType.String).Value = endDate;
                        else
                            cmd.Parameters.AddWithValue("penddate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                {
                    response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                    response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ExtendISAP", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                return response;
            }
            
            return response;

        }

        public ResponseClass UpdateModuleLearningStatus(updateModuleLearningStatusRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtResult = new DataTable();
            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request is required";
                return response;
            }
            if (string.IsNullOrEmpty(request.UserName))
            {
                response.responseCode = 0;
                response.responseMessage = "UserName required";
                return response;
            }
            if (string.IsNullOrEmpty(request.ECLDID))
            {
                response.responseCode = 0;
                response.responseMessage = "ECLDID required";
                return response;
            }
            if (string.IsNullOrEmpty(request.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "Action required";
                return response;
            }
            if (string.IsNullOrEmpty(request.InsertedBy))
            {
                response.responseCode = 0;
                response.responseMessage = "InsertedBy required";
                return response;
            }
            if (string.IsNullOrEmpty(request.InsertedIPAddress))
            {
                response.responseCode = 0;
                response.responseMessage = "InsertedIPAddress required";
                return response;
            }
            if (string.IsNullOrEmpty(request.AssessmentStartDate))
            {
                response.responseCode = 0;
                response.responseMessage = "AssessmentStartDate required";
                return response;
            }
            if (string.IsNullOrEmpty(request.AssessmentEndDate))
            {
                response.responseCode = 0;
                response.responseMessage = "AssessmentEndDate required";
                return response;
            }

            string assessmentstartDate = string.Empty;
            string assessmentendDate = string.Empty;
            try
            {
                assessmentstartDate = Convert.ToDateTime(request.AssessmentStartDate).ToString("yyyy-MM-dd HH:mm:ss");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("UpdateModuleLearningStatus", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid AssessmentStartDate";
                return response;
               

            }

            try
            {
                assessmentendDate = Convert.ToDateTime(request.AssessmentEndDate).ToString("yyyy-MM-dd HH:mm:ss");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("UpdateModuleLearningStatus", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid Assessment";
                return response;
                

            }


            string pgsqlConnection = appSettings.Value.DbConnection;

            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                   
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_updatemodulelearningstatus
                                                                    ( 
                                                                        :p_mallocationid,
                                                                        :p_employeecode,
                                                                        :p_ecldid,
                                                                        :p_action,
                                                                        :p_insertedby,
                                                                        :p_insertedipaddress,
                                                                        :p_startdate,
                                                                        :p_enddate,
                                                                        :p_totalduration
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //

                        if (!String.IsNullOrEmpty(request.ModuleAllocationID))
                            cmd.Parameters.AddWithValue("p_mallocationid", DbType.String).Value = request.ModuleAllocationID;
                        else
                            cmd.Parameters.AddWithValue("p_mallocationid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_employeecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.ECLDID))
                            cmd.Parameters.AddWithValue("p_ecldid", DbType.String).Value = request.ECLDID;
                        else
                            cmd.Parameters.AddWithValue("p_ecldid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(assessmentstartDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = assessmentstartDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(assessmentendDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = assessmentendDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;

                        cmd.Parameters.AddWithValue("p_totalduration", DbType.String).Value = Convert.ToString(request.TotalDurationSecond);


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtResult);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtResult);

                        if (dtResult.Rows.Count>0 && dtResult!=null)
                        {
                            try
                            {
                              var scResponse=_scheduleBL.AssignFSTLAssignment();
                            }
                            catch (Exception)
                            {

                                
                            }

                            try
                            {
                                var scResponse = _scheduleBL.AssignDIAssessment();
                            }
                            catch (Exception)
                            {


                            }

                            try
                            {
                                var scResponse = _scheduleBL.ProjectFrameworkAssessment();
                            }
                            catch (Exception)
                            {


                            }


                        }
                    }
                }

              
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
                return response;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("UpdateModuleLearningStatus", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                // LogException.Log(ex.Message);
                return response;
            }
           

            
           
        }

        public ResponseClass pushAssessmentResult(pushAssessmentResultrequestDTO request)
        {
           // _serviceconnect.LogConnect("PushAssessmentResult", "1024", "API Calling for allocation code : " + request.AllocationCode, "Information");

            ResponseClass response = new ResponseClass();
            DataTable dtResult = new DataTable();
            if (request == null)
            {
               
                response.responseCode = 0;
                response.responseMessage = "request is required";
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
                return response;
            }
            if (string.IsNullOrEmpty(request.AllocationCode))
            {
                response.responseCode = 0;
                response.responseMessage = "AllocationCode required";
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
                return response;
            }
            if (string.IsNullOrEmpty(request.AssessmentScheduleID))
            {
                response.responseCode = 0;
                response.responseMessage = "AssessmentScheduleID required";
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
                return response;
            }
            if (string.IsNullOrEmpty(request.AssessmentStartDate))
            {
                response.responseCode = 0;
                response.responseMessage = "AssessmentStartDate required";
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
                return response;
            }
            if (string.IsNullOrEmpty(request.AssessmentEndDate))
            {
                response.responseCode = 0;
                response.responseMessage = "AssessmentEndDate required";
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
                return response;
            }

            if (string.IsNullOrEmpty(request.ScoreGrade))
            {
                response.responseCode = 0;
                response.responseMessage = "ScoreGrade required";
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
                return response;
            }

            //if (request.TotalScore==0)
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "TotalScore required";
            //    _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
            //    return response;
            //}

            if (request.AttemptNo == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "AttemptNo required";
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
                return response;
            }

            string assessmentstartDate = string.Empty;
            string assessmentendDate = string.Empty;
            try
            {
                assessmentstartDate = Convert.ToDateTime(request.AssessmentStartDate).ToString("yyyy-MM-dd HH:mm:ss");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", "AssessmentStartDate : " + ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid AssessmentStartDate";
                return response;
                //WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion needed by date :" + ex.Message);

            }

            try
            {
                assessmentendDate = Convert.ToDateTime(request.AssessmentEndDate).ToString("yyyy-MM-dd HH:mm:ss");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("PushAssessmentResult", "1024", "AssessmentEndDate" + ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid Assessment";
                return response;
                //WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion needed by date :" + ex.Message);

            }

            string pgsqlConnection = appSettings.Value.DbConnection;

            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                  
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_pushassessmentresult
                                                                    ( 
                                                                        :p_mallocationid,
                                                                        :p_assigmentscheduleid,
                                                                        :p_startdate,
                                                                        :p_enddate,
                                                                        :p_totalScore,
                                                                        :p_totalGrade,
                                                                        :p_insertedby,
                                                                        :p_insertedipaddress,
                                                                        :p_attemptno
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //


                        if (!String.IsNullOrEmpty(request.AllocationCode))
                            cmd.Parameters.AddWithValue("p_mallocationid", DbType.String).Value = request.AllocationCode;
                        else
                            cmd.Parameters.AddWithValue("p_mallocationid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.AssessmentScheduleID))
                            cmd.Parameters.AddWithValue("p_assigmentscheduleid", DbType.String).Value = request.AssessmentScheduleID;
                        else
                            cmd.Parameters.AddWithValue("p_assigmentscheduleid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(assessmentstartDate))
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = assessmentstartDate;
                        else
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(assessmentendDate))
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = assessmentendDate;
                        else
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;


                        cmd.Parameters.AddWithValue("p_totalScore", DbType.String).Value = Convert.ToString(request.TotalScore);
                      

                        if (!String.IsNullOrEmpty(request.ScoreGrade))
                            cmd.Parameters.AddWithValue("p_totalGrade", DbType.String).Value = request.ScoreGrade;
                        else
                            cmd.Parameters.AddWithValue("p_totalGrade", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = string.Empty;


                        cmd.Parameters.AddWithValue("p_attemptno", DbType.String).Value = request.AttemptNo;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtResult);
                        npgsqlConnection.Close();

                        if (dtResult.Rows.Count>0)
                        {
                            response.responseCode = Convert.ToInt32(dtResult.Rows[0]["responseCode"]);
                            response.responseMessage = Convert.ToString(dtResult.Rows[0]["responseMessage"]);
                        }
                        
                        response.responseJSON = JsonConvert.SerializeObject(dtResult);

                       // now check for failure notification
                        try
                            {
                                _scheduleBL.isapFailureNotification();
                            }
                            catch (Exception)
                            {


                            }
                    }
                }


              //  _serviceconnect.LogConnect("PushAssessmentResult", "1024", "API Calling done for allocation code : " + request.AllocationCode, "Information");
                return response;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("PushAssessmentResult", "1024",ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage =ex.Message;
                return response;
            }




        }
        public ResponseClass pushAssessmentResultBusiness(pushAssessmentResultrequestDTO request)
        {
            //_serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", "API Calling for allocation code : " + request.AllocationCode, "Information");

            ResponseClass response = new ResponseClass();
            DataTable dtResult = new DataTable();
            if (request == null)
            {

                response.responseCode = 0;
                response.responseMessage = "request is required";
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", response.responseMessage, "Exception");
                return response;
            }
            if (string.IsNullOrEmpty(request.AllocationCode))
            {
                response.responseCode = 0;
                response.responseMessage = "AllocationCode required";
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", response.responseMessage, "Exception");
                return response;
            }
            if (string.IsNullOrEmpty(request.AssessmentScheduleID))
            {
                response.responseCode = 0;
                response.responseMessage = "AssessmentScheduleID required";
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", response.responseMessage, "Exception");
                return response;
            }
            if (string.IsNullOrEmpty(request.AssessmentStartDate))
            {
                response.responseCode = 0;
                response.responseMessage = "AssessmentStartDate required";
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", response.responseMessage, "Exception");
                return response;
            }
            if (string.IsNullOrEmpty(request.AssessmentEndDate))
            {
                response.responseCode = 0;
                response.responseMessage = "AssessmentEndDate required";
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", response.responseMessage, "Exception");
                return response;
            }

            if (string.IsNullOrEmpty(request.ScoreGrade))
            {
                response.responseCode = 0;
                response.responseMessage = "ScoreGrade required";
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", response.responseMessage, "Exception");
                return response;
            }

            //if (request.TotalScore==0)
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "TotalScore required";
            //    _serviceconnect.LogConnect("PushAssessmentResult", "1024", response.responseMessage, "Exception");
            //    return response;
            //}

            if (request.AttemptNo == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "AttemptNo required";
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", response.responseMessage, "Exception");
                return response;
            }

            string assessmentstartDate = string.Empty;
            string assessmentendDate = string.Empty;
            try
            {
                assessmentstartDate = Convert.ToDateTime(request.AssessmentStartDate).ToString("yyyy-MM-dd HH:mm:ss");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", "AssessmentStartDate : " + ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid AssessmentStartDate";
                return response;
                //WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion needed by date :" + ex.Message);

            }

            try
            {
                assessmentendDate = Convert.ToDateTime(request.AssessmentEndDate).ToString("yyyy-MM-dd HH:mm:ss");

            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", "AssessmentEndDate" + ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = "Invalid Assessment";
                return response;
                //WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion needed by date :" + ex.Message);

            }

            string pgsqlConnection = appSettings.Value.DbConnection;

            try
            {
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {

                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_pushassessmentresultbusiness
                                                                    ( 
                                                                        :p_mallocationid,
                                                                        :p_assigmentscheduleid,
                                                                        :p_startdate,
                                                                        :p_enddate,
                                                                        :p_totalScore,
                                                                        :p_totalGrade,
                                                                        :p_insertedby,
                                                                        :p_insertedipaddress,
                                                                        :p_attemptno,:p_resultflag,:p_lastattempt,
                                                                        :p_minmarks,:p_maxmarks,:p_marksobtained,:p_reattemptdatetime
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //


                        if (!String.IsNullOrEmpty(request.AllocationCode))
                            cmd.Parameters.AddWithValue("p_mallocationid", DbType.String).Value = request.AllocationCode;
                        else
                            cmd.Parameters.AddWithValue("p_mallocationid", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.AssessmentScheduleID))
                            cmd.Parameters.AddWithValue("p_assigmentscheduleid", DbType.String).Value = request.AssessmentScheduleID;
                        else
                            cmd.Parameters.AddWithValue("p_assigmentscheduleid", DbType.String).Value = DBNull.Value;

                       

                        DateTime startdate = new DateTime();
                        if (!String.IsNullOrEmpty(assessmentstartDate))
                        {
                            startdate = Convert.ToDateTime(assessmentstartDate);
                            startdate = EncryptDecryptAES.ConvertTimeZone(startdate, "IST");

                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = startdate.ToString("yyyy-MM-dd HH:mm:ss");
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = string.Empty;
                        }

                        DateTime enddate = new DateTime();

                        if (!String.IsNullOrEmpty(assessmentendDate))
                        {
                            enddate = Convert.ToDateTime(assessmentendDate);
                            enddate = EncryptDecryptAES.ConvertTimeZone(enddate, "IST");

                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = enddate.ToString("yyyy-MM-dd HH:mm:ss");
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = string.Empty;
                        }

                        //if (!String.IsNullOrEmpty(assessmentstartDate))
                        //    cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = assessmentstartDate;
                        //else
                        //    cmd.Parameters.AddWithValue("p_startdate", DbType.String).Value = DBNull.Value;

                        //if (!String.IsNullOrEmpty(assessmentendDate))
                        //    cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = assessmentendDate;
                        //else
                        //    cmd.Parameters.AddWithValue("p_enddate", DbType.String).Value = DBNull.Value;


                        cmd.Parameters.AddWithValue("p_totalScore", DbType.String).Value = Convert.ToString(request.TotalScore);


                        if (!String.IsNullOrEmpty(request.ScoreGrade))
                            cmd.Parameters.AddWithValue("p_totalGrade", DbType.String).Value = request.ScoreGrade;
                        else
                            cmd.Parameters.AddWithValue("p_totalGrade", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = string.Empty;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = string.Empty;


                        cmd.Parameters.AddWithValue("p_attemptno", DbType.String).Value = request.AttemptNo;

                        if (!String.IsNullOrEmpty(request.ResultFlag))
                            cmd.Parameters.AddWithValue("p_resultflag", DbType.String).Value = request.ResultFlag;
                        else
                            cmd.Parameters.AddWithValue("p_resultflag", DbType.String).Value = string.Empty;

                        cmd.Parameters.AddWithValue("p_lastattempt", DbType.String).Value = request.IsLastAttempt;

                        cmd.Parameters.AddWithValue("p_minmarks", DbType.Double).Value = request.MinMarks;
                        cmd.Parameters.AddWithValue("p_maxmarks", DbType.Double).Value = request.MaxMarks;
                        cmd.Parameters.AddWithValue("p_marksobtained", DbType.Double).Value = request.MarksObtained;

                        DateTime ctdTime = new DateTime();

                        if (!String.IsNullOrEmpty(request.ReattemptDateTime))
                        {
                            ctdTime = Convert.ToDateTime(request.ReattemptDateTime);

                            if (appSettings.Value.ApplicationUrl.Contains("https://hgsconnect.teamhgs.com/"))
                            {
                                ctdTime = EncryptDecryptAES.ConvertTimeZone(ctdTime, "IST");
                            }

                            

                            cmd.Parameters.AddWithValue("p_reattemptdatetime", DbType.String).Value = ctdTime.ToString("yyyy-MM-dd HH:mm:ss");
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue("p_reattemptdatetime", DbType.String).Value = string.Empty;
                        }

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtResult);
                        npgsqlConnection.Close();

                        if (dtResult.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtResult.Rows[0]["responseCode"]);
                            response.responseMessage = Convert.ToString(dtResult.Rows[0]["responseMessage"]);
                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtResult);

                        try
                        {
                            var scResponse = _scheduleBL.AssignFSTLSurvey();
                        }
                        catch (Exception)
                        {


                        }

                       

                        try
                        {
                            var scResponse = _scheduleBL.SendFSTLCertificateEmail();
                        }
                        catch (Exception)
                        {


                        }

                        try
                        {
                            var scResponse = _scheduleBL.SendDNICertificateEmail();
                        }
                        catch (Exception)
                        {


                        }

                        try
                        {
                            var scResponse = _scheduleBL.AssignPFSurvey();
                        }
                        catch (Exception)
                        {


                        }

                        // now check for failure notification
                        //try
                        //{
                        //    _scheduleBL.isapFailureNotification();
                        //}
                        //catch (Exception)
                        //{


                        //}
                    }
                }


                //_serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", "API Calling done for allocation code : " + request.AllocationCode, "Information");
                return response;
            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("pushAssessmentResultBusiness", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                return response;
            }




        }

        public ResponseClass GetAgentDashboardCount(getAgentDashboardCountDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_agent_dashboard_count
                                                                        ( 
                                                                            :p_username,
                                                                            :p_currentrole
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        // to get gamification point
                        dtEmployees.Columns.Add("GamificationPoint");

                        try
                        {
                            getparticipantgamificationscoreDTO getgamificationpoint = new getparticipantgamificationscoreDTO();
                            getgamificationpoint.EmployeeCode = request.UserName;
                            int participantscore = _scheduleBL.getParticipantScore(getgamificationpoint);

                            dtEmployees.Rows[0]["GamificationPoint"] = participantscore;
                        }
                        catch (Exception ex)
                        {
                            _serviceconnect.LogConnect("InsertEditExpressEvent", "1024", ex.Message, "Exception");

                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAgntHomePage", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetISAPScoreCard(getAgentDashboardCountDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {

                // check employee valid
                if (request.Action!= "GETISAPACORE" && !string.IsNullOrEmpty(request.UserName))
                {
                    bool checkValidEmployeeId;
                    checkValidEmployeeId = _qualtricsBL.checkEmployee(request.currentUser, request.CurrentRole, request.UserName);
                    if (!checkValidEmployeeId)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid Employee!";
                        return response;
                    }
                }
                else
                {
                    if (request.CurrentRole=="Team Lead" && string.IsNullOrEmpty(request.UserName))
                    {
                        getTeamMembersRequestDTO getMemberRequest = new getTeamMembersRequestDTO();
                        getMemberRequest.EmployeeCode = request.currentUser;
                        var QualtriData = _qualtricsBL.GetTeamMembers(getMemberRequest);
                        DataTable QualtricTeamMembers = JsonConvert.DeserializeObject<DataTable>(QualtriData.responseJSON.ToString());
                        if (QualtricTeamMembers != null && QualtricTeamMembers.Rows.Count > 0)
                        {
                            foreach (DataRow exclude in QualtricTeamMembers.Rows)
                            {
                                // request.UserName = request.UserName + "'" + Convert.ToString(exclude["EmployeeID"]) + "',";
                                request.UserName = request.UserName + Convert.ToString(exclude["EmployeeID"]) + ",";
                            }

                            request.UserName = request.UserName.TrimEnd(',');

                        }
                    }
                }
                

                // check employee valid
                //bool checkValidEmployee;
                //checkValidEmployee = _qualtricsBL.checkEmployee(request.currentUser,request.CurrentRole,request.UserName);
                //if (!checkValidEmployee)
                //{
                //    response.responseCode = 0;
                //    response.responseMessage = "Invalid Employee!";
                //    return response;
                //}


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_isap_scorecard
                                                                        ( 
                                                                            :p_username,
                                                                            :p_currentrole,
                                                                            :p_action,
                                                                            :p_allocationid
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.ModuleAllocationID))
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = request.ModuleAllocationID;
                        else
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetISAPScoreCard", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass ReadISAP(readISAPrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_read_isap
                                                                    ( 
                                                                        :p_username,
                                                                        :p_modulecode,
                                                                        :p_currentrole
                                                                    )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.ModuleCode))
                            cmd.Parameters.AddWithValue("p_modulecode", DbType.String).Value = request.ModuleCode;
                        else
                            cmd.Parameters.AddWithValue("p_modulecode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("ReadISAP", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            
            return response;
        }

        public ResponseClass getUserMenu(getUserMenu request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_menu_by_role
                                                                    ( 
                                                                        :p_username,
                                                                        :p_currentrole
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.UserName))
                        cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                    else
                        cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                    if (!String.IsNullOrEmpty(request.CurrentRole))
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                    else
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;



                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();

                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

        public ResponseClass pushAssessmentResultDetail(AssessmentResultDetailRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            NpgsqlConnection npgCon = new NpgsqlConnection(appSettings.Value.DbConnection);

            _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", "API calling started for pushing result :" + DateTime.Now, "Information");
            try
            {


                if (request == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "request is required";
                    _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", response.responseMessage, "Exception");
                    return response;
                }

                if (request.assessmentResultDetails == null || request.assessmentResultDetails.Count == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "request.assessmentResultDetails is required";
                    _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", response.responseMessage, "Exception");
                    return response;
                }
                foreach (var item in request.assessmentResultDetails)
                {
                    if (string.IsNullOrEmpty(item.AssessmentScheduleID) || item.AssessmentScheduleID == "0")
                    {
                        response.responseCode = 0;
                        response.responseMessage = "item.AssessmentScheduleID is required";
                      //  _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", response.responseMessage, "Exception");
                        return response;
                    }
                    if (string.IsNullOrEmpty(item.AssessmentQuestion))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "item.AssessmentQuestion is required";
                      //  _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", response.responseMessage, "Exception");
                        return response;
                    }
                    //if (string.IsNullOrEmpty(item.OptedAnswer))
                    //{
                    //    response.responseCode = 0;
                    //    response.responseMessage = "item.OptedAnswer is required";
                    ////    _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", response.responseMessage, "Exception");
                    //    return response;
                    //}
                    //if (string.IsNullOrEmpty(item.CorrectAnswer))
                    //{
                    //    response.responseCode = 0;
                    //    response.responseMessage = "item.CorrectAnswer is required";
                    // //   _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", response.responseMessage, "Exception");
                    //    return response;
                    //}
                    if (string.IsNullOrEmpty(item.isCorrect))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "item.isCorrect is required";
                      //  _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", response.responseMessage, "Exception");
                        return response;
                    }
                    string p_assessmentscheduleid = string.Empty;
                    // p_assessmentscheduleid = Convert.ToString(item["EmployeeCode"]);
                    string sqlQuery = "call prc_pushassessmentresult_detail_bt('" + item.AssessmentScheduleID + "','" + item.AssessmentQuestion + "','" + item.OptedAnswer + "','" + item.CorrectAnswer + "','" + item.isCorrect + "')";
                    npgCon.Open();
                    // Define a command to call  procedure
                    NpgsqlCommand cmd = new NpgsqlCommand(sqlQuery, npgCon);
                    NpgsqlDataReader rdr = cmd.ExecuteReader();
                    npgCon.Close();
                }

                //_serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", "API calling done for pushing result :" + DateTime.Now, "Information");
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("pushAssessmentResultDetail", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                return response;
            }
            return response;
        }

        public ResponseClass getISAPScoreCardDetails(getAssessmentResultDetailDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                DataSet dsAssessmentResult = new DataSet();
                string sqlQuery = string.Empty;
                sqlQuery = "select #AssessmentQuestion# as Question,#OptedAnswer# as GivenOption,#CorrectAnswer# as CorrectAnswer,#isCorrect# as IsSelectedOptionCorrect from #EmployeeAssessmentResultDetails#  WHERE  #AssessmentScheduleID#=" + request.AssessmentScheduleID + "  ";
                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dsAssessmentResult);

                npgsql.Close();

                response.responseJSON = JsonConvert.SerializeObject(dsAssessmentResult);

                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getISAPScoreCardDetails", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
                return response;
            }
           
            return response;
        }

        public ResponseClass getCertificateList(getEmployeeCertificateRequest request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_certificate_list
                                                                        ( 
                                                                            :p_username,
                                                                            :p_currentrole,
                                                                            :p_allocationid
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.CurrentRole))
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;
                        else
                            cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.AllocationID))
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = request.AllocationID;
                        else
                            cmd.Parameters.AddWithValue("p_allocationid", DbType.String).Value = DBNull.Value;


                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getCertificateList", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass getISAPExtensionRequest(ISAPExtensionRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string sqlQuery = string.Empty;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                sqlQuery = "select A.#MAllocationID# as allocationid,concat(EMP.#FIRSTNAME#,' ',EMP.#LASTNAME#) as employeename,EMP.#Manager_Name# as managername,EMP.#DEPARTMENT# as department,cast(TO_CHAR(A.#AllocationDate#, 'yyyy') as character varying) as allocationyear,7 as modulecompleted,'Not Completed' as assessmentstatus,cast(TO_CHAR(A.#AllocationDate#, 'dd-Mon-yy') as character varying) as startdate,cast(TO_CHAR(a.#ExpiryDate#, 'dd-Mon-yy') as character varying) as enddate  from #ModuleEmployeeAllocation# A left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#EmployeeCode# where A.#EmployeeCode#='" + request.UserName + "' and A.#AllocationStatus#='Active' and (COALESCE(A.#CompletionStatus#,0)=0 or COALESCE(A.#AssessmentStatus#,0)=0) order by A.#MAllocationID#  desc  limit 1";

                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getISAPExtensionRequest", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }

        public ResponseClass getISAPExtensionRequestDepartment(ISAPExtensionRequestDepartmentDTO request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                string sqlQuery = string.Empty;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);

                //sqlQuery = "select A.#MAllocationID# as allocationid,concat(EMP.#FIRSTNAME#,' ',EMP.#LASTNAME#) as employeename,EMP.#Manager_Name# as managername,EMP.#DEPARTMENT# as department,cast(TO_CHAR(A.#AllocationDate#, 'yyyy') as character varying) as allocationyear,7 as modulecompleted,'Not Completed' as assessmentstatus,cast(TO_CHAR(A.#AllocationDate#, 'dd-Mon-yy') as character varying) as startdate,cast(TO_CHAR(a.#ExpiryDate#, 'dd-Mon-yy') as character varying) as enddate  from #ModuleEmployeeAllocation# A left join #EmployeeMaster# EMP on EMP.#EXTERNALDATAREFERENCE#=A.#EmployeeCode# where A.#EmployeeCode#='" + request.UserName + "' and A.#AllocationStatus#='Active' and (COALESCE(A.#CompletionStatus#,0)=0 or COALESCE(A.#AssessmentStatus#,0)=0) order by A.#MAllocationID#  desc  limit 1";
                ///sqlQuery = "select from #ModuleYarlyCalenderConfig# where #AllocationYear#='2023' and #CompanyCode#='C001'  and #DepartmentCode#=";
                //sqlQuery= "select A."ModuleYearlyConfigID",B."DEPARTMENT",";
                //sqlQuery = "cast(TO_CHAR(A.#AssignedDate#, 'dd-Mon-yyyy') as character varying) as AssignedDate,";
                //sqlQuery = "select A."ModuleYearlyConfigID",B."DEPARTMENT","
                //sqlQuery = "select A."ModuleYearlyConfigID",B."DEPARTMENT","
                //sqlQuery = "select A."ModuleYearlyConfigID",B."DEPARTMENT","
                sqlQuery = sqlQuery.Replace('#', '"');
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(sqlQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(dtEmployees);
                npgsql.Close();
                response.responseCode = 1;
                response.responseMessage = "SUCCESS";
                response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getISAPExtensionRequest", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;

        }

        public ResponseClass insertAssetLikeHistory(AssetLikeRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_asset_like_history
                                                                        ( 
                                                                            :p_primary
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.PrimaryID))
                            cmd.Parameters.AddWithValue("p_primary", DbType.String).Value = request.PrimaryID;
                        else
                            cmd.Parameters.AddWithValue("p_primary", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertWIPrequest", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass getemployeeskills(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_gt_employee_skills
                                                                        ( 
                                                                            :p_username,
                                                                            :p_action
                                                                            
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getemployeeskills", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass getMenuMaster()
        {
            ResponseClass response = new ResponseClass();

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"select * from public.fn_get_menumaster()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getMenuMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getMenuRoleName()
        {
            ResponseClass response = new ResponseClass();

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"select * from public.fn_get_LMSRole()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getMenuMaster", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getMenuRoleMapping()
        {
            ResponseClass response = new ResponseClass();

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"select * from public.fn_get_menu_rolemapping()", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getMenuRoleMapping", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass insertMenuRoleMapping(MenuRoleMapping request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                long checkRoleMapping = 0;
                NpgsqlConnection connection = new NpgsqlConnection(pgsqlConnection);

                connection.Open();
                string sqlQuery1 = "select * from public.fn_get_menu_checkrolemapping('" + request.RoleName + "'," + request.MenuID + ")";
                NpgsqlCommand command1 = new NpgsqlCommand(sqlQuery1, connection);
                NpgsqlDataReader reader1 = command1.ExecuteReader();
                while(reader1.Read())
                {
                    checkRoleMapping = long.Parse(reader1["mrmidcnt"].ToString());
                }
                connection.Close();

                if(checkRoleMapping == 0)
                {
                    connection.Open();
                    string sqlQuery = "CALL public.usp_insert_rolemastermapping(" + request.MenuID + ",'" + request.RoleName + "')";
                    NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);
                    NpgsqlDataReader reader = command.ExecuteReader();
                    connection.Close();

                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "Role already assign in menu.";
                }
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertMenuRoleMapping", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass deleteMenuRoleMapping(MenuRoleMapping request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                string pgsqlConnection = appSettings.Value.DbConnection;
                NpgsqlConnection connection = new NpgsqlConnection(pgsqlConnection);

                connection.Open();
                string sqlQuery = "CALL public.usp_delete_rolemastermapping(" + request.MenuID + ")";
                NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);
                NpgsqlDataReader reader = command.ExecuteReader();
                connection.Close();

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("deleteMenuRoleMapping", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getSearchMenuRoleMapping(MenuRoleMapping request)
        {
            ResponseClass response = new ResponseClass();

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"select * from public.fn_get_menu_searchrolemapping('"+request.RoleName+"')", npgsqlConnection))
                    {
                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);

                        npgsqlConnection.Close();

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getMenuRoleMapping", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass CheckUserVisitData(checkUserVisit request)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                DataTable cityList = new DataTable();
                string selectQuery = string.Empty;

                selectQuery = "select * from #log_page_hits# where #employee_code#='" + request.UserName + "'  and #page_url# like '%https://hgsconnect.teamhgs.com/hgshall2.0/Home/Index%'";
                selectQuery = selectQuery.Replace('#', '"');
                string pgsqlConnection = appSettings.Value.ComponentConnection;
                NpgsqlConnection npgsql = new NpgsqlConnection(pgsqlConnection);
                npgsql.Open();

                NpgsqlCommand npgsqlCommand = new NpgsqlCommand(selectQuery, npgsql);

                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlCommand);

                dataAdapter.Fill(cityList);
                npgsql.Close();

                if (cityList!=null && cityList.Rows.Count>0)
                {
                    response.responseCode = 1;
                }
                else
                {
                    response.responseCode = 0;
                }
                
               // response.responseJSON = JsonConvert.SerializeObject(cityList);


            }
            catch (Exception ex)
            {
                _serviceconnect.LogConnect("CheckUserVisitData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass getEventProgramDays(getEventProgramdaysRequest request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_event_program_days
                                                                    ( 
                                                                        :p_eventcode
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.EventCode))
                        cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = request.EventCode;
                    else
                        cmd.Parameters.AddWithValue("p_eventcode", DbType.String).Value = DBNull.Value;
                    
                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();

                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

        public ResponseClass getProgramDependency(getprogramdependency request)
        {
            ResponseClass response = new ResponseClass();
            DataTable dtEmployees = new DataTable();
            string pgsqlConnection = appSettings.Value.DbConnection;
            using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
            {
                using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_programassetdependency
                                                                    ( 
                                                                        :passetid
                                                                    )", npgsqlConnection))
                {
                    cmd.CommandType = CommandType.Text; //
                    if (!String.IsNullOrEmpty(request.AssetDetailID))
                        cmd.Parameters.AddWithValue("passetid", DbType.String).Value = request.AssetDetailID;
                    else
                        cmd.Parameters.AddWithValue("passetid", DbType.String).Value = DBNull.Value;
                    
                    npgsqlConnection.Open();

                    NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                    dataAdapter.Fill(dtEmployees);
                    npgsqlConnection.Close();
                    response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "Success";
            return response;
        }

        public ResponseClass getAssessmentResultView(getassessmentview request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                SqlParameter[] parameter = {
                        new SqlParameter("@TLDCID", request.TLDCID)
                        };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = AssessmentdBConnection.ExecuteDataSet("PRC_Assessment_User_response_MyLearning", parameter, outParameters);
                if (dsResult != null && dsResult.Tables[0].Rows.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getAssessmentResultView", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            
            return response;
        }

        public ResponseClass getSurveyResultView(getsurveyview request)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                SqlParameter[] parameter = {
                        new SqlParameter("@EmpCode", request.EmployeeCode),
                        new SqlParameter("@SurveyId", request.SurveyID)
                        };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = SurveyDBConnection.ExecuteDataSet("PRC_ESurvey_TLDC_SurveyResponsesBasedonEmpId", parameter, outParameters);
                if (dsResult != null && dsResult.Tables[0].Rows.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("getSurveyResultView", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetEEDSMaterial(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_partcipant_eeds
                                                                 ( 
                                                                     :p_username,
                                                                     :p_action
                                                                     
                                                                 )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.UserName))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.UserName;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAgntLearningMAterial", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetUserMyLearningCount(getuserprofileDetailsRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(request.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "employee id required!";
                return response;
            }

            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_get_my_learning_count
                                                                ( 
                                                                    :p_username,
                                                                    :p_action
                                                                    
                                                                )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.EmployeeID))
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = request.EmployeeID;
                        else
                            cmd.Parameters.AddWithValue("p_username", DbType.String).Value = DBNull.Value;
                        if (!String.IsNullOrEmpty(request.Action))
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = request.Action;
                        else
                            cmd.Parameters.AddWithValue("p_action", DbType.String).Value = DBNull.Value;



                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetUserTaskCount", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetAllChannelData(getVideoChannelDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_get_allvideochannel
                                                                 ( 
                                                                     :p_currentemployee,
                                                                     :p_currentrole
                                                                     
                                                                 )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeCode;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAllChannelData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }
        public ResponseClass GetMyChannelData(getVideoChannelDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {


                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM vc_fn_get_myvideochannel
                                                                 ( 
                                                                     :p_currentemployee,
                                                                     :p_currentrole
                                                                     
                                                                 )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        cmd.Parameters.AddWithValue("p_currentemployee", DbType.String).Value = request.EmployeeCode;
                        cmd.Parameters.AddWithValue("p_currentrole", DbType.String).Value = request.CurrentRole;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }

                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("GetAllChannelData", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass insertVideoProgress(insertvideoprogressrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            try
            {
                if (string.IsNullOrEmpty(request.LearningDetailID))
                {
                    response.responseCode = 0;
                    response.responseMessage = "PrimaryID required!";
                    return response;
                }

                DataTable dtEmployees = new DataTable();
                string pgsqlConnection = appSettings.Value.DbConnection;
                using (NpgsqlConnection npgsqlConnection = new NpgsqlConnection(pgsqlConnection))
                {
                    using (NpgsqlCommand cmd = new NpgsqlCommand(@"SELECT * FROM fn_insert_video_progress_tracking
                                                                        ( 
                                                                            :p_primary,:p_learningmode,:p_progresstime,:p_insertedby,:p_insertedipaddress
                                                                        )", npgsqlConnection))
                    {
                        cmd.CommandType = CommandType.Text; //
                        if (!String.IsNullOrEmpty(request.LearningDetailID))
                            cmd.Parameters.AddWithValue("p_primary", DbType.String).Value = request.LearningDetailID;
                        else
                            cmd.Parameters.AddWithValue("p_primary", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.LearningMode))
                            cmd.Parameters.AddWithValue("p_learningmode", DbType.String).Value = request.LearningMode;
                        else
                            cmd.Parameters.AddWithValue("p_learningmode", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.ProgressTime))
                            cmd.Parameters.AddWithValue("p_progresstime", DbType.String).Value = request.ProgressTime;
                        else
                            cmd.Parameters.AddWithValue("p_progresstime", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedBy))
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = request.InsertedBy;
                        else
                            cmd.Parameters.AddWithValue("p_insertedby", DbType.String).Value = DBNull.Value;

                        if (!String.IsNullOrEmpty(request.InsertedIPAddress))
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = request.InsertedIPAddress;
                        else
                            cmd.Parameters.AddWithValue("p_insertedipaddress", DbType.String).Value = DBNull.Value;

                        npgsqlConnection.Open();

                        NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(cmd);
                        dataAdapter.Fill(dtEmployees);
                        npgsqlConnection.Close();
                        if (dtEmployees != null && dtEmployees.Rows.Count > 0)
                        {
                            response.responseCode = Convert.ToInt32(dtEmployees.Rows[0]["statuscode"]);
                            response.responseMessage = Convert.ToString(dtEmployees.Rows[0]["statusmessage"]);
                        }

                        response.responseJSON = JsonConvert.SerializeObject(dtEmployees);
                    }
                }


            }
            catch (Exception ex)
            {

                _serviceconnect.LogConnect("insertVideoProgress", "1024", ex.Message, "Exception");
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }
            return response;
        }

    }
}
