﻿using System.Data;
using TLDCBAL.Common;
using TLDCBAL.MobApp;

namespace TLDCBAL.WebSite
{
    public interface IWebsiteBL
    {
        ResponseClass GetAgntHomePage(getAgentHomePageDTO request);

        ResponseClass GetParticipantToDo(getAgentHomePageDTO request);
        ResponseClass GetAgntLearningMAterial(getAgentHomePageDTO request);

        ResponseClass geteedsdata(getAgentHomePageDTO request);
        ResponseClass GetSeedMaterial(getAgentHomePageDTO request);
        ResponseClass GetModuleCodeDetails(getAgentModuleDataDTO request);
        ResponseClass GetBULaunchPageDetails(getAgentModuleDataDTO request);
        ResponseClass GetUpcomingTraining(getUpcomingTrainingRequestDTO request);
        ResponseClass GetActiveModuleDetails(getAgentModuleDataDTO request);
        ResponseClass UpdateModuleLearningStatus(updateModuleLearningStatusRequestDTO request);

        ResponseClass pushAssessmentResult(pushAssessmentResultrequestDTO request);
        ResponseClass pushAssessmentResultBusiness(pushAssessmentResultrequestDTO request);
        ResponseClass GetAgentDashboardCount(getAgentDashboardCountDTO request);
        ResponseClass GetISAPScoreCard(getAgentDashboardCountDTO request);
        ResponseClass ReadISAP(readISAPrequestDTO request);

        ResponseClass getUserMenu(getUserMenu request);
        ResponseClass pushAssessmentResultDetail(AssessmentResultDetailRequestDTO request);
        ResponseClass getISAPScoreCardDetails(getAssessmentResultDetailDTO request);

        ResponseClass getCertificateList(getEmployeeCertificateRequest request);
        ResponseClass getISAPExtensionRequest(ISAPExtensionRequestDTO request);
        ResponseClass ExtendISAP(ExtendISAPRequestDTO request);
        ResponseClass getVideoHighlights(getHighlightedText request);

        ResponseClass insertAssetLikeHistory(AssetLikeRequestDTO request);
        ResponseClass getemployeeskills(getAgentHomePageDTO request);

        ResponseClass getMenuMaster();
        ResponseClass getMenuRoleName();
        ResponseClass getMenuRoleMapping();
        ResponseClass getSearchMenuRoleMapping(MenuRoleMapping request);
        ResponseClass insertMenuRoleMapping(MenuRoleMapping request);
        ResponseClass deleteMenuRoleMapping(MenuRoleMapping request);
        ResponseClass CheckUserVisitData(checkUserVisit request);

        ResponseClass getEventProgramDays(getEventProgramdaysRequest request);

        ResponseClass getProgramDependency(getprogramdependency request);

        ResponseClass getAssessmentResultView(getassessmentview request);

        ResponseClass getSurveyResultView(getsurveyview request);

        ResponseClass GetEEDSMaterial(getAgentHomePageDTO request);

        ResponseClass GetUserMyLearningCount(getuserprofileDetailsRequestDTO request);


        ResponseClass GetAllChannelData(getVideoChannelDTO request);
        ResponseClass GetMyChannelData(getVideoChannelDTO request);

        ResponseClass insertVideoProgress(insertvideoprogressrequestDTO request);


    }
}