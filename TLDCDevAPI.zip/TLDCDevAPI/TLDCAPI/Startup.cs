using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Configuration;
using TLDCBAL.CourseAdmin;
using TLDCBAL.EmailManagement;
using TLDCBAL.EmployeeLeave;
using TLDCBAL.Induction;
using TLDCBAL.ISAPAdmin;
using TLDCBAL.KnowledgeBase;
using TLDCBAL.Masters;
using TLDCBAL.Module;
using TLDCBAL.ProgramManager;
using TLDCBAL.Qualtrics;
using TLDCBAL.Reports;
using TLDCBAL.Schedulers;
using TLDCBAL.Service;
using TLDCBAL.UserManagement;
using TLDCBAL.WebSite;
using TLDCBAL.ActiveWall;
using TLDCBAL.MobApp;
using TLDCBAL.ODPM;
using TLDCBAL.LearnerDashboard;

namespace TLDCAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<IMasterBL, MasterBL>();

            services.AddScoped<IUserManagementBL, UserManagementBL>();
            services.AddScoped<IWebsiteBL, WebsiteBL>();
            services.AddScoped<IServiceConnect, ServiceConnect>();
            services.AddScoped<IMailTemplateBL, MailTemplateBL>();
            services.Configure<TLDCDAL.DBConnection>(Configuration);
            services.AddScoped<IQualtricsDataBL, QualtricsDataBL>();
            services.AddScoped<IISAPReportBL, ISAPReportBL>();
            services.AddScoped<IModuleBL, ModuleBL>();
            services.AddScoped<IEmployeeLeaveBL, EmployeeLeaveBL>();
            services.AddScoped<ISchedulerBL, SchedulerBL>();
            services.AddScoped<IEmailMGTBL, EmailMGTBL>();
            services.AddScoped<IInductionGroupBL, InductionGroupBL>();
            services.AddScoped<IInductionReportBL, InductionReportBL>();
            services.AddScoped<ITrainingGroupBL, TrainingGroupBL>();
            services.AddScoped<IVideoMasterBL, VideoMasterBL>();
            services.AddScoped<ICourseMasterBL, CourseMasterBL>();
            services.AddScoped<IExpressEventBL, ExpressEventBL>();
            services.AddScoped<IAllocateEntityBL, AllocateEntityBL>();
            services.AddScoped<IClassRoomTrainingBL, ClassRoomTrainingBL>();
            services.AddScoped<IProcessTrainingBL, ProcessTrainingBL>();
            services.AddScoped<IProcessSessionBL, ProcessSessionBL>();
            services.AddScoped<IMarkAttendanceBL, MarkAttendanceBL>();
            services.AddScoped<IKnowledgeBaseBL, KnowledgeBaseBL>();
            services.AddScoped<IActiveWallBL, ActiveWallBL>();
            services.AddScoped<ICertificateMasterBL, CertificateMasterBL>();
            services.AddScoped<IProgramMasterBL, ProgramMasterBL>();
            services.AddScoped<IAssessmentReportBL, AssessmentReportBL>();
            services.AddScoped<IScheduleReportBL, ScheduleReportBL>();
            services.AddScoped<IMOBAPPBL, MOBAPPBL>();
            services.AddScoped<IODPMBL, ODPMBL>();
            services.AddScoped<IODPMAdminBL, ODPMAdminBL>();
            services.AddScoped<ILearnerDashboardBL, LearnerDashboardBL>();
            services.AddScoped<IVideoChannelBL, VideoChannelBL>();
            services.AddScoped<IFireBaseAPICallBL, FireBaseAPICallBL>();
            services.AddScoped<IODPMReportBL, ODPMReportBL>();
            services.Configure<IDBConnection>(Configuration.GetSection("ConnectionStrings"));
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAllHeaders",
                builder =>
                {
                    builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();

                }


                 );


            });
            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            app.UseCors("AllowAllHeaders"); // allow credentials

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
