﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.CourseAdmin;
using TLDCBAL.ODPM;
using TLDCBAL.ProgramManager;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ODPMController : ControllerBase
    {

        private IODPMBL _oDPMBL;
        public ODPMController(IODPMBL oDPMBL)
        {
            _oDPMBL = oDPMBL;

        }
        [HttpPost]
        public ResponseClass GetODPMGeo()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetGeo();
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMshareGeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMshareGeo(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMsuggestGeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMsuggestGeo(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMschGeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMschGeo(oDPMinput);
            return response;
        }

        
        [HttpPost]
        public ResponseClass GetODPMQtr()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetQtr();
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMQtryear()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMQtryear();
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMStakeholder()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetStakeholder();
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMProgramManager(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetProgramManager(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMStatus()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetStatus();
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMShareTNIList(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetShareTNIList(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMCity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetCity(oDPMinput.companycode);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMDepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetDepartment(oDPMinput);
            return response;
        }

        
        [HttpPost]
        public ResponseClass GetODPMshareDepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMshareDepartment(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMsuggestDepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMsuggestDepartment(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMschDepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMschDepartment(oDPMinput);
            return response;
        }
        

        [HttpPost]
        public ResponseClass GetODPMGrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetGrade(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMShareGrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMShareGrade(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMsuggestGrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMsuggestGrade(oDPMinput);
            return response;
        }

        

            [HttpPost]
        public ResponseClass GetODPMschGrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMschGrade(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMNominateTeamMembers(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetNominateTeamMembers(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMShareNominateTeamMembers(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMShareNominateTeamMembers(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMTrainingName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetTrainingName(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMProgramName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetProgramName(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMEfficacy()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetEfficacy();
            return response;
        }
        [HttpPost]
        public ResponseClass ODPMInsertShareTNI(List<ShareTNIDetails> shareTNIDetails)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ODPMInsertShareTNI(shareTNIDetails);
            return response;
        }
        [HttpPost]
        public ResponseClass getedit_TNI_Master(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getedit_TNI_Master(oDPMinput);
            return response;
        }


        [HttpPost]
        public ResponseClass getedit_TNI_QtrMapping(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getedit_TNI_QtrMapping(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass getedit_TNI_DepartmentMapping(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getedit_TNI_DepartmentMapping(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass getedit_TNI_Grade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getedit_TNI_Grade(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass getedit_TNI_MemberNomination(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getedit_TNI_MemberNomination(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass getedit_TNI_TrainingName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getedit_TNI_TrainingName(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass get_EmployeeAutocompleteName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.get_EmployeeAutocompleteName(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass ODPMInsertSuggestTNI(List<ShareTNIDetails> shareTNIDetails)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ODPMInsertSuggestTNI(shareTNIDetails);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMSuggestTNIList(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMSuggestTNIList(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass getedit_SuggestTNI_Master(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getedit_SuggestTNI_Master(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass ApproveShareTNI(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ApproveShareTNI(oDPMinput);
            return response;
        }
        [HttpPost]

        public ResponseClass RejectShareTNI(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.RejectShareTNI(oDPMinput);
            return response;
        }
        public ResponseClass GetODPMQtrDur()
        {

            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMQtrDur();
            return response;
        }

        //Program manager schedule training
        [HttpPost]
        public ResponseClass GetODPMPMschtraifrmtnilist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMPMschtraifrmtnilist(oDPMinput);
            return response;
        }
        public ResponseClass ODPMPMSavetrainschedfromtni(List<schFROMTNI> schFROMTNI)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ODPMPMSavetrainschedfromtni(schFROMTNI);
            return response;
        }
        [HttpPost]
        public ResponseClass PMSavetrainschedfromdirecttni(List<schDirectFROMTNI> schFROMTNI)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.PMSavetrainschedfromdirecttni(schFROMTNI);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMdraftlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMdraftlist(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass getedit_savedraft(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getedit_savedraft(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMPMdraftworkshop()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMPMdraftworkshop();
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMPM360tworkshop()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMPM360tworkshop();
            return response;
        }
        

        [HttpPost]
        public ResponseClass GetODPMschCity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMschCity(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMschLocation(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMschLocation(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Getallocusrcreateschtraining(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Getallocusrcreateschtraining(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Geteditschgeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Geteditschgeo(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Geteditschdep(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Geteditschdep(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GeteditschCity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GeteditschCity(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Geteditschloc(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Geteditschloc(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Geteditschgrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Geteditschgrade(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Geteditschtraname(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Geteditschtraname(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Geteditschassetlst(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Geteditschassetlst(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMNMProgramName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMNMProgramName(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMNPTrainingName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMNPTrainingName(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMNPAssetName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMNPAssetName(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMNPEditAssetName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMNPEditAssetName(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetOldWorkShop()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetOldWorkShop();
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMOldWrkShpCity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMOldWrkShpCity(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMOldWrkShpLocation(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMOldWrkShpLocation(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMOldWrkShpProName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMOldWrkShpProName(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMOldWrkShpTraingName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMOldWrkShpTraingName(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMOldWrkShpAssetName(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMOldWrkShpAssetName(oDPMinput);
            return response;
        }
        public ResponseClass ODPMPMSavetrainschedoldwrkshp(List<schFROMTNI> schFROMTNI)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ODPMPMSavetrainschedoldwrkshp(schFROMTNI);
            return response;
        }


        //// 360 view

        [HttpPost]
        public ResponseClass GetODPM360vwlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPM360vwlist(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Getwrkshpcancelreason()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Getwrkshpcancelreason();
            return response;
        }
        [HttpPost]
        public ResponseClass Getwrkshpreschreason()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Getwrkshpreschreason();
            return response;
        }

        public ResponseClass ODPMPMSaveReschCancel(List<schFROMTNI> schFROMTNI)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ODPMPMSaveReschCancel(schFROMTNI);
            return response;
        }
        [HttpPost]
        public ResponseClass GetPMSchTrainingDetails(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetPMSchTrainingDetails(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass getPM360statlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getPM360statlist(oDPMinput);
            return response;
        }
        //Mark Att
        [HttpPost]
        public ResponseClass GetODPMmarkattlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMmarkattlist(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetPMemployeeattd(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetPMemployeeattd(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass ODPMInsertMarkAttd(List<markAttd> markAttds)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ODPMInsertMarkAttd(markAttds);
            return response;
        }
        [HttpPost]
        public ResponseClass ODPMFinalMarkAttd(List<markAttd> markAttds)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ODPMFinalMarkAttd(markAttds);
            return response;
        }
        
        [HttpPost]
        public ResponseClass GetODPMPMmarkemployeeattd(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMPMmarkemployeeattd(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMenabfeedlist(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMenabfeedlist(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMfeedworkshop(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMfeedworkshop(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMsurveytype(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMsurveytype(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMsurveyquestion(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMsurveyquestion(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass GetODPMfeedbackdetails(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GetODPMfeedbackdetails(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass ODPMsavefeedback(List<feedback> feedback)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.ODPMsavefeedback(feedback);
            return response;
        }
        
        //[HttpPost]
        //public ResponseClass ManageVideoMasterlist(manageVideoMasterrequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.ManageVideoMasterlist(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass InsertVideoMaster(addVideoMasterRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.InsertVideoMaster(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass EditVideoMaster(deleteVideoMasterRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.EditVideoMaster(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass DeleteVideoMaster(deleteVideoMasterRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.DeleteVideoMaster(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass ManageCourseMasterlist(manageCourseMasterrequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.ManageCourseMasterlist(request);
        //    return response;
        //}

        //    [HttpPost]
        //public ResponseClass InsertCourseMaster(addEditCourseMasterrequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.InsertCourseMaster(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass EditCourseMaster(addEditCourseMasterrequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.EditCourseMaster(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass DeleteCourseMaster(deleteCourseMasterRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.DeleteCourseMaster(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass GetProgramMasterList(ODPMProgramMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.GetProgramMasterList(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass GetProgramLearningList(ODPMProgramAssetLearningMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.GetProgramLearningList(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass InsertEditProgramMaster(ODPMProgramMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.InsertEditProgramMaster(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass GetProgramMasterDataByProgramCode(ODPMProgramMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.GetProgramMasterDataByProgramCode(request);
        //    return response;
        //}

        [HttpPost]
        public ResponseClass Gettninumbergeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Gettninumbergeo(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Gettninumberdepartment(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Gettninumberdepartment(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass Gettninumbergrade(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Gettninumbergrade(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass GettninumberprogramandTraining(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.GettninumberprogramandTraining(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass Gettninumbercity(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.Gettninumbercity(oDPMinput);
            return response;
        }
        //[HttpPost]
        //public ResponseClass GetProgramLearningListByPRcodeAndAssetID(ODPMProgramAssetDetailsLearningMasterDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.GetProgramLearningListByPRcodeAndAssetID(request);
        //    return response;
        //}
        //[HttpPost]
        //public ResponseClass GetAllocateAssetDropDownDataByAssetID(ODPMinsertEditProgramLearningRequestDTO request)
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _oDPMBL.GetAllocateAssetDropDownDataByAssetID(request);
        //    return response;
        //}
        [HttpPost]
        public ResponseClass getODPMAllocateEntityDropDownData(getAllocateEntityDropDownDataDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getODPMAllocateEntityDropDownData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getParticipantdiscrianduserinstru(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getParticipantdiscrianduserinstru(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass getParticipanttrainingdetails(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getParticipanttrainingdetails(oDPMinput);
            return response;
        }

        [HttpPost]
        public ResponseClass getODPMMarkGeo(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getODPMMarkGeo(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass getODPMMarkProgramManager(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getODPMMarkProgramManager(oDPMinput);
            return response;
        }
        [HttpPost]
        public ResponseClass getODPMPMMarkworkshop(ODPMinput oDPMinput)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMBL.getODPMPMMarkworkshop(oDPMinput);
            return response;
        }
    }
}
