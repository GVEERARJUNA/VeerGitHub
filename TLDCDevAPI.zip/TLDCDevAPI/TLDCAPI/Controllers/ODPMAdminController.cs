﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.ODPM;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ODPMAdminController : ControllerBase
    {

        private IODPMAdminBL _oDPMAdminBL;
        public ODPMAdminController(IODPMAdminBL oDPMAdminBL)
        {
            _oDPMAdminBL = oDPMAdminBL;

        }
        [HttpPost]
        

        [HttpPost]
        public ResponseClass InsertEditTrainingWithAssets(addTrainingRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.InsertEditTrainingWithAssets(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertEditProgramWithTrainings(addProgramRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.InsertEditProgramWithTrainings(request);
            return response;
        }

        [HttpPost]
        public ResponseClass LoadTraingsandPrograms(TrainingProgramDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.LoadTraingsandPrograms(request);
            return response;
        }

        [HttpPost]
        public ResponseClass EditTraining(EditTrainingRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.EditTraining(request);
            return response;
        }

        [HttpPost]
        public ResponseClass EditProgram(EditProgramRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.EditProgram(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetTrainingsforProgDrop()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.GetTrainingsforProgDrop();
            return response;
        }

        [HttpPost]
        public ResponseClass GetOdpmGeos()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.GetOdpmGeos();
            return response;
        }

        [HttpPost]
        public ResponseClass GetProgTrainingswithTrainId(GetProgTrainswithTridResp req)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.GetProgTrainingswithTrainId(req);
            return response;
        }

        public ResponseClass DeleteTraining(DeleteRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.DeleteTraining(request);
            return response;
        }

        public ResponseClass DeleteProgram(DeleteRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.DeleteProgram(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetOdpmCategory()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.GetOdpmCategory();
            return response;
        }

        [HttpPost]
        public ResponseClass GetDeliveryMethods()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.GetDeliveryMethods();
            return response;
        }

        [HttpPost]
        public ResponseClass GetAssetTypes()
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.GetAssetTypes();
            return response;
        }

        [HttpPost]
        public ResponseClass GetAssetNamesByType(AssetTypeRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.GetAssetNamesByType(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetODPMAdminLookUpData(AssetTypeRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _oDPMAdminBL.GetODPMAdminLookUpData(request.LookupType);
            return response;
        }
    }
}
