﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.MobApp;
using TLDCBAL.ProgramManager;
using TLDCBAL.WebSite;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class MobileAPIController : Controller
    {
        private IWebsiteBL _websiteBL;

        private IMOBAPPBL _mobappbl;

        private IExpressEventBL _expresseventBL;

        public MobileAPIController(IWebsiteBL websiteBL, IMOBAPPBL mobappbl, IExpressEventBL expresseventBL)
        {
            _websiteBL = websiteBL;
            _mobappbl = mobappbl;
            _expresseventBL = expresseventBL;

        }

       
        [HttpPost]
        public ResponseClassMobile GetUserProfile(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            getuserprofileDetailsRequestDTO request = new getuserprofileDetailsRequestDTO();
            request = JsonConvert.DeserializeObject<getuserprofileDetailsRequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _mobappbl.GetUserProfile(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile GetUserTaskCount(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            getuserprofileDetailsRequestDTO request = new getuserprofileDetailsRequestDTO();
            request = JsonConvert.DeserializeObject<getuserprofileDetailsRequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _mobappbl.GetUserTaskCount(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile GetUserTaskList(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            getuserprofileDetailsRequestDTO request = new getuserprofileDetailsRequestDTO();
            request = JsonConvert.DeserializeObject<getuserprofileDetailsRequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _mobappbl.GetUserTaskList(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile GetModuleDetails(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            getuserprofileDetailsRequestDTO request = new getuserprofileDetailsRequestDTO();
            request = JsonConvert.DeserializeObject<getuserprofileDetailsRequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _mobappbl.GetModuleDetails(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile UpdateModuleAcknowledgeStatus(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            updatemoduleacknowledgestatusrequestDTO request = new updatemoduleacknowledgestatusrequestDTO();
            request = JsonConvert.DeserializeObject<updatemoduleacknowledgestatusrequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _mobappbl.UpdateModuleAcknowledgeStatus(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile InsertAssetWIPStatus(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            insertWIPrequestDTO request = new insertWIPrequestDTO();
            request = JsonConvert.DeserializeObject<insertWIPrequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _expresseventBL.insertWIPrequest(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile insertWIPOptedrequest(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            insertWIPrequestDTO request = new insertWIPrequestDTO();
            request = JsonConvert.DeserializeObject<insertWIPrequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _expresseventBL.insertWIPOptedrequest(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile MobinsertVideoProgress(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            insertvideoprogressrequestDTO request = new insertvideoprogressrequestDTO();
            request = JsonConvert.DeserializeObject<insertvideoprogressrequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _websiteBL.insertVideoProgress(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile MobPushSurveyResult(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            pushSurveyResultrequestDTO request = new pushSurveyResultrequestDTO();
            request = JsonConvert.DeserializeObject<pushSurveyResultrequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _mobappbl.PushSurveyResult(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile MobAssessmentResultView(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            getassessmentview request = new getassessmentview();
            request = JsonConvert.DeserializeObject<getassessmentview>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _websiteBL.getAssessmentResultView(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile MobSurveyResultView(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            ResponseClass response = new ResponseClass();
            getsurveyview request = new getsurveyview();
            request = JsonConvert.DeserializeObject<getsurveyview>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _websiteBL.getSurveyResultView(request);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public string EncryptString(requestencryptdecrypt request)
        {
            return EncryptDecryptAES.EncryptStringAES(request.inputstring);
        }

        [HttpPost]
        public string DecryptString(requestencryptdecrypt request)
        {
            return EncryptDecryptAES.DecryptStringAES(request.inputstring);
        }
    }
}
