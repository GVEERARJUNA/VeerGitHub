﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.ActiveWall;
using TLDCBAL.Schedulers;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ActiveWallController : Controller
    {
        private IActiveWallBL activeWallBL;

        public ActiveWallController(IActiveWallBL acrtiveWallBL)
        {
            activeWallBL = acrtiveWallBL;

        }

        [HttpPost]
        public ResponseClass CreatePost(WallPostingDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.CreatePost(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ProfanityCheck(ProfanityRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.ProfanityCheck(request);
            return response;
        }

        [HttpPost]
        public ResponseClass LikePost(WallPostingCommunication request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.LikePost(request);
            return response;
        }

        [HttpPost]
        public ResponseClass LikeComment(WallPostingCommunication request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.LikeComment(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ActiveWallTreeData(getAWTreeDataRequest requestData)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.getTreeData(requestData);
            return response;
        }

        [HttpPost]
        public ResponseClass GetPostsList(PostsRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.PostsList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetUserSearchList(SearchRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.GetUserSearchList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetCommentList(commentRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.GetCommentList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass DeletePost(PostHideBlockRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.DeletePost(request);
            return response;
        }

        [HttpPost]
        public ResponseClass HidePost(PostHideBlockRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.HidePost(request);
            return response;
        }

        [HttpPost]
        public ResponseClass BlockUser(PostHideBlockRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.BlockUser(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetUserGroupList(SearchRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.GetUserGroupList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetUserGradeList(SearchRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = activeWallBL.GetUserGradeList(request);
            return response;
        }
    }
}
