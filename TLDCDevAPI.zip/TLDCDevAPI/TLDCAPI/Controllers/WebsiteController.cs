﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.MobApp;
using TLDCBAL.WebSite;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class WebsiteController : Controller
    {
        private IWebsiteBL _websiteBL;


        public WebsiteController(IWebsiteBL websiteBL)
        {
            _websiteBL = websiteBL;

        }

        [HttpPost]
        public ResponseClass GetAgentHomePage(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetAgntHomePage(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetParticipantToDo(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetParticipantToDo(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetAgentLearningMaterial(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetAgntLearningMAterial(request);
            return response;
        }

        [HttpPost]
        public ResponseClass geteedsdata(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.geteedsdata(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetSeedMaterial(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetSeedMaterial(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetEEDSMaterial(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetEEDSMaterial(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetModuleCodeDetails(getAgentModuleDataDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetModuleCodeDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetBULaunchPageDetails(getAgentModuleDataDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetBULaunchPageDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getVideoHighlights(getHighlightedText request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getVideoHighlights(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetUpcomingTraining(getUpcomingTrainingRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetUpcomingTraining(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetActiveModuleDetails(getAgentModuleDataDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetActiveModuleDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass UpdateModuleLearningStatus(updateModuleLearningStatusRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.UpdateModuleLearningStatus(request);
            return response;
        }

        [HttpPost]
        public ResponseClass PushAssessmentResult(pushAssessmentResultrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.pushAssessmentResult(request);
            //AA
            return response;
        }

        [HttpPost]
        public ResponseClass pushAssessmentResultBusiness(pushAssessmentResultrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.pushAssessmentResultBusiness(request);
            //AA
            return response;
        }

        [HttpPost]
        public ResponseClass GetAgentDashboardCount(getAgentDashboardCountDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetAgentDashboardCount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetISAPScoreCard(getAgentDashboardCountDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetISAPScoreCard(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ReadISAP(readISAPrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.ReadISAP(request);
            return response;
        }
        [HttpPost]
        public ResponseClass getUserMenu(getUserMenu request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.getUserMenu(request);
            return response;
        }
        [HttpPost]
        public ResponseClass pushAssessmentResultDetail(AssessmentResultDetailRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.pushAssessmentResultDetail(request);
           
            return response;
        }

        [HttpPost]
        public ResponseClass getISAPScoreCardDetails(getAssessmentResultDetailDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.getISAPScoreCardDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getCertificateList(getEmployeeCertificateRequest request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getCertificateList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getISAPExtensionRequest(ISAPExtensionRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getISAPExtensionRequest(request);
            return response;
        }
        [HttpPost]
        public ResponseClass ExtendISAP(ExtendISAPRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.ExtendISAP(request);
            return response;
        }

        [HttpPost]
        public ResponseClass insertAssetLikeHistory(AssetLikeRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.insertAssetLikeHistory(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getemployeeskills(getAgentHomePageDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getemployeeskills(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getMenuMaster()
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getMenuMaster();
            return response;
        }

        [HttpPost]
        public ResponseClass getMenuRoleMapping()
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getMenuRoleMapping();
            return response;
        }

        [HttpPost]
        public ResponseClass insertMenuRoleMapping(MenuRoleMapping request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.insertMenuRoleMapping(request);
            return response;
        }

        [HttpPost]
        public ResponseClass deleteMenuRoleMapping(MenuRoleMapping request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.deleteMenuRoleMapping(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getSearchMenuRoleMapping(MenuRoleMapping request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getSearchMenuRoleMapping(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getRoleMenuMaster()
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getMenuMaster();
            return response;
        }

        [HttpPost]
        public ResponseClass getRoleNameMaster()
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getMenuRoleName();
            return response;
        }

        [HttpPost]
        public ResponseClass CheckUserVisitData(checkUserVisit request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.CheckUserVisitData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getEventProgramDays(getEventProgramdaysRequest request)
        {

            ResponseClass response = new ResponseClass();
            response = _websiteBL.getEventProgramDays(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getProgramDependency(getprogramdependency request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.getProgramDependency(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getAssessmentResultView(getassessmentview request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.getAssessmentResultView(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getSurveyResultView(getsurveyview request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.getSurveyResultView(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetUserMyLearningCount(getuserprofileDetailsRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetUserMyLearningCount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetAllChannelData(getVideoChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetAllChannelData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetMyChannelData(getVideoChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.GetMyChannelData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass insertVideoProgress(insertvideoprogressrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _websiteBL.insertVideoProgress(request);
            return response;
        }

    }
}
