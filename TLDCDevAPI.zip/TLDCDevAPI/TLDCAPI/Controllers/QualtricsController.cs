﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.ProgramManager;
using TLDCBAL.Qualtrics;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class QualtricsController : Controller
    {
        private IQualtricsDataBL _qualtricsBL;
        public QualtricsController(IQualtricsDataBL qualtricsBL)
        {
            _qualtricsBL = qualtricsBL;

        }

        [HttpPost]
        public ResponseClass GetTeamMembers(getTeamMembersRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _qualtricsBL.GetTeamMembers(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetComapny(getCompanyRequest request)
        {

            ResponseClass response = new ResponseClass();
            response = _qualtricsBL.GetComapny(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDepartment(getDepartmentRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _qualtricsBL.GetDepartment(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDepartmentCertificate(getDepartmentRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _qualtricsBL.GetDepartmentCertificate(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetSubProcess(getSubProcessRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _qualtricsBL.GetSubProcess(request.DepartmentCode);
            return response;
        }

        [HttpPost]
        public ResponseClass GetRequistionNo(getrequistionnorequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _qualtricsBL.GetRequistionNo(request);
            return response;
        }


        [HttpPost]
        public ResponseClass GetComapnyForCertificate(getCompanyRequest request)
        {

            ResponseClass response = new ResponseClass();
            response = _qualtricsBL.GetComapnyForCertificate(request);
            return response;
        }
    }
}
