﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.UserManagement;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class UserManagementController : Controller
    {
        private IUserManagementBL _userManagement;

      
        public UserManagementController(IUserManagementBL userManagement)
        {
            _userManagement = userManagement;
           
        }

        [HttpPost]
        public ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO)
        {
            
            ResponseClass response = new ResponseClass();
            response = _userManagement.CheckUserLogin(loginRequestBO);
            return response;
        }


        [HttpPost]
        public ResponseClass getUserRoles(UserRoleRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getUserRoles(request);
            return response;
        }

        [HttpPost]
        public ResponseClass deleteRole(UserRoleRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.deleteRole(request);
            return response;
        }

        [HttpPost]
        public ResponseClass addVisitSummary(UserVisitSummaryRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.addVisitSummary(request);
            return response;
        }

        [HttpPost]
        public ResponseClass setDefaultRole(setDefaultRole request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.setDefaultRole(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertSiteLoginData(insertSiteDataRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.InsertSiteLoginData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass updateProfilePIC(profilepicrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.updateProfilePIC(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getAllowEmailDetails()
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getAllowEmailDetails();
            return response;
        }

        [HttpPost]
        public ResponseClass addAllowEmail(allowEmailDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.addAllowEmail(request);
            return response;
        }

        [HttpPost]
        public ResponseClass deleteAllowEmail(allowEmailDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.deleteAllowEmail(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getEditAllowEmailDetails(allowEmailDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getEditAllowEmailDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass updateEditAllowEmailDetails(allowEmailDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.updateEditAllowEmailDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getLMSRoleDetails()
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getLMSRoleDetails();
            return response;
        }

        [HttpPost]
        public ResponseClass getJobRoleDetails()
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getJobRoleDetails();
            return response;
        }

        [HttpPost]
        public ResponseClass addUserDetails(addUserDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.addUserDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getManageUserDetails()
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getManageUserDetails();
            return response;
        }

        [HttpPost]
        public ResponseClass deleteManageUser(addUserDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.deleteManageUser(request);
            return response;
        }

        [HttpPost]
        public ResponseClass editUserDetails(addUserDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.editUserDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass updateUserDetails(addUserDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.updateUserDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getSearchManageUserDetails(searchUserDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getSearchManageUserDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getLMSRoleCompanyDetails()
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getLMSRoleCompanyDetails();
            return response;
        }

        [HttpPost]
        public ResponseClass getPMProxyDeatils(addPMProxyUser request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getPMProxyDeatils(request);
            return response;
        }

        [HttpPost]
        public ResponseClass deletePMProxyDeatils(addPMProxyUser request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.deletePMProxyDeatils(request);
            return response;
        }

        [HttpPost]
        public ResponseClass addPMProxyDeatils(addPMProxyUser request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.addPMProxyDeatils(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getLogProxyDeatils()
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getLogProxyDeatils();
            return response;
        }

        [HttpPost]
        public ResponseClass getSearchLogProxyDeatils(ProxyUserLog request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getSearchLogProxyDeatils(request);
            return response;
        }

        [HttpPost]
        public ResponseClass addLogProxyDeatils(ProxyUserLog request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.addLogProxyDeatils(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getAdminProxyDeatils(addPMProxyUser request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.getAdminProxyDeatils(request);
            return response;
        }

        [HttpPost]
        public ResponseClass deleteAdminProxyDeatils(addPMProxyUser request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.deleteAdminProxyDeatils(request);
            return response;
        }

        [HttpPost]
        public ResponseClass addAdminProxyDeatils(addPMProxyUser request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.addAdminProxyDeatils(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageUserPrivilege(searchUserDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.ManageUserPrivilege(request);
            return response;
        }

        [HttpPost]
        public ResponseClass assignroletouser(assignroletouserrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.assignroletouser(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetUserPrivilege(assignroletouserrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.GetUserPrivilege(request);
            return response;
        }

        [HttpPost]
        public ResponseClass AssignProgramManagerAccess(UserAccessMasterRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.AssignProgramManagerAccess(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetFormRightData(assignroletouserrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.GetFormRightData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass UserRoleManage(userrolemanagerequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.UserRoleManage(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetUserProgramManagerData(assignroletouserrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _userManagement.GetUserProgramManagerData(request);
            return response;
        }

    }
}
