﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.CourseAdmin;
using TLDCBAL.WebSite;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class CourseAdminController : Controller
    {
        private ITrainingGroupBL _traininggroupBL;
        private IVideoMasterBL _VideoMaster;
        private ICourseMasterBL _CourseMaster;
        private ICertificateMasterBL _CertificateMaster;
        private IScheduleReportBL _schedulereportBL;
        private IVideoChannelBL _videoChannelBL;


        public CourseAdminController(ITrainingGroupBL traininggroupBL,
            IVideoMasterBL VideoMaster, ICourseMasterBL CourseMaster,
            ICertificateMasterBL CertificateMaster,
            IScheduleReportBL schedulereportBL,
            IVideoChannelBL videoChannelBL
            )
        {
            _traininggroupBL = traininggroupBL;
            _VideoMaster = VideoMaster;
            _CourseMaster = CourseMaster;
            _CertificateMaster = CertificateMaster;
            _schedulereportBL = schedulereportBL;
            _videoChannelBL = videoChannelBL;

        }

        [HttpPost]
        public ResponseClass ManageTrainingGroup(manageTrainingGrouprequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _traininggroupBL.ManageTrainingGroup(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageTrainingGroupPaging(manageTrainingGrouprequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _traininggroupBL.ManageTrainingGroupPaging(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertEditTrainingGroup(addTrainingGroupRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _traininggroupBL.InsertEditTrainingGrup(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageVideoMaster(manageVideoMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _VideoMaster.ManageVideoMaster(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageVideoMasterPaging(manageVideoMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _VideoMaster.ManageVideoMasterPaging(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertEditVideoMaster(addVideoMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _VideoMaster.InsertEditVideoMaster(request);
            return response;
        }
        [HttpPost]
        public ResponseClass DeleteVideo(deleteVideoMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _VideoMaster.DeleteVideo(request);
            return response;
        }
        [HttpPost]
        public ResponseClass EditVideo(deleteVideoMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _VideoMaster.EditVideo(request);
            return response;
        }
        [HttpPost]
        public ResponseClass IsCourseAssign(CheckCourseAssign request)
        {
            ResponseClass response = new ResponseClass();
            response = _CourseMaster.IsCourseAssign(request);
            return response;
        }
        [HttpPost]
        public ResponseClass EditCourse(addEditCourseMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CourseMaster.EditCourse(request);
            return response;
        }
        [HttpPost]
        public ResponseClass ManageCourseMaster(manageCourseMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CourseMaster.ManageCourseMaster(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageCourseMasterPaging(manageCourseMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CourseMaster.ManageCourseMasterPaging(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertEditCourseMaster(addEditCourseMasterrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CourseMaster.InsertEditCourseMaster(request);
            return response;
        }
        [HttpPost]
        public ResponseClass DeleteCourse(deleteCourseMasterRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CourseMaster.DeleteCourse(request);
            return response;
        }

        [HttpPost]
        public ResponseClass AddEmployeeToAllocation(allocateEmployeeRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _traininggroupBL.AddEmployeeToAllocation(request);
            return response;
        }

        [HttpPost]
        public ResponseClass searchEmployee(allocateEmployeeRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _traininggroupBL.searchEmployee(request);
            return response;
        }

        [HttpPost]
        public ResponseClass addMultiEmployee(allocateEmployeeRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _traininggroupBL.addMultiEmployee(request);
            return response;
        }

        [HttpPost]
        public ResponseClass AddCertificateTemplate(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CertificateMaster.AddCertificate(request);
            return response;
        }

        [HttpPost]
        public ResponseClass CertificateList(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CertificateMaster.CertificateList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass CertificateNameList(CertificateListDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CertificateMaster.CertificateNameList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteCertificate(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CertificateMaster.DeleteCertificate(request);
            return response;
        }   

        [HttpPost]
        public ResponseClass GetCertificate(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CertificateMaster.GetCertificate(request);
            return response;
        }
        [HttpPost]
        public ResponseClass EditCertificate(CertificateMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _CertificateMaster.EditCertificate(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetReportNames(getreportnamesrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _schedulereportBL.GetReportNames(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetReportSchedule(getreportnamesrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _schedulereportBL.GetReportSchedule(request);
            return response;
        }

        [HttpPost]
        public ResponseClass AddEditScheduleReport(addnewscheduleRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _schedulereportBL.AddEditScheduleReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetScheduleDataForEdit(geteditdatarequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _schedulereportBL.GetScheduleDataForEdit(request);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteScheduleReport(deleteschedulereportrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _schedulereportBL.DeleteScheduleReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetSchedulePageData(getschedulepagelistDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _schedulereportBL.GetSchedulePageData(request);
            return response;
        }

        //Video Channel
        [HttpPost]
        public ResponseClass GetVideoChannelList(ChannelReuest request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.GetVideoChannelList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertEditVideoChannel(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.InsertEditVideoChannel(request);
            return response;
        }

        [HttpPost]
        public ResponseClass editVideoChanneldata(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.editVideoChanneldata(request);
            return response;
        }

        [HttpPost]
        public ResponseClass EditVideoChannel(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.EditVideoChannel(request);
            return response;
        }


        [HttpPost]
        public ResponseClass ManageChannelAccess(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.EditVideoChannel(request);
            return response;
        }

        [HttpPost]
        public ResponseClass SubscribeChannel(SubscribeChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.SubscribeChannel(request);
            return response;
        }

        [HttpPost]
        public ResponseClass UpdateLikes(VideoLikeDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.UpdateLikes(request);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteChannelVideo(VideoLikeDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.DeleteChannelVideo(request);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteMyChannelVideo(VideoLikeDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.DeleteMyChannelVideo(request);
            return response;
        }


        [HttpPost]
        public ResponseClass searchProgramManager(allocateEmployeeRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.searchProgramManager(request);
            return response;
        }

        [HttpPost]
        public ResponseClass AssignUserAccess(ChannelAccessDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.AssignUserAccess(request);
            return response;
        }

        [HttpPost]
        public ResponseClass UpdateAccessList(ChannelAccessDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.UpdateAccessList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetWatchVideoChannel(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.GetWatchVideoChannel(request);
            return response;
        }

        [HttpPost]
        public ResponseClass CreateChannelVideoViewCount(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.CreateChannelVideoViewCount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ViewChannel(CreateChannelDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.ViewChannel(request);
            return response;
        }

        [HttpPost]
        public ResponseClass UploadVideotoChannel(ChannelVideoDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _videoChannelBL.UploadVideotoChannel(request);
            return response;
        }

    }
}
