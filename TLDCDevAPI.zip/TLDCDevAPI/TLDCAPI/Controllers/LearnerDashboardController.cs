﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using TLDCBAL.Common;
using TLDCBAL.LearnerDashboard;
using TLDCBAL.WebSite;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class LearnerDashboardController : Controller
    {
        private ILearnerDashboardBL _learnerDashboardBL;


        public LearnerDashboardController(ILearnerDashboardBL learnerDashboardBL)
        {
            _learnerDashboardBL = learnerDashboardBL;

        }

        [HttpPost]
        public ResponseClass GetLearnerDashboardCount(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetLearnerDashboardCount(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetTotalTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetTotalTrainingBifurcation(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetCompletedTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetCompletedTrainingBifurcation(request);
            return response;
        } 
        [HttpPost]
        public ResponseClass GetOngoingTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetOngoingTrainingBifurcation(request);
            return response;
        } 
        [HttpPost]
        public ResponseClass GetPendingTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetPendingTrainingBifurcation(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetExpiredTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetExpiredTrainingBifurcation(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetLibraryTrainingBifurcation(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetLibraryTrainingBifurcation(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetTotalTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetTotalTrianingAssetDetails(request);
            return response;
        }
        
        [HttpPost]
        public ResponseClass GetOngoingTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetOngoingTrianingAssetDetails(request);
            return response;
        } 
        
        [HttpPost]
        public ResponseClass GetCompletedTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetCompletedTrianingAssetDetails(request);
            return response;
        }

         [HttpPost]
        public ResponseClass GetExpiredTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetExpiredTrianingAssetDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetLibraryTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetLibraryTrianingAssetDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetPendingTrianingAssetDetails(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetPendingTrianingAssetDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDateWiseTrainingBifurcationforGraph(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetDateWiseTrainingBifurcationforGraph(request);
            return response;
        } 
        [HttpPost]
        public ResponseClass GetEmployeeRecentActivities(CommonTraningAssetInputDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.GetEmployeeRecentActivities(request);
            return response;
        }
        [HttpPost]
        public ResponseClass getCertificateListByDateWise(getEmployeeCertificateRequest request)
        {

            ResponseClass response = new ResponseClass();
            response = _learnerDashboardBL.getCertificateListByDateWise(request);
            return response;
        }

    }
}
