﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using TLDCBAL.Common;
using TLDCBAL.Module;
using static TLDCBAL.Module.ModuleDTO;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ModuleController : Controller
    {
        private IModuleBL _ModuleBL;
        public ModuleController(IModuleBL ModuleDataBL)
        {
            _ModuleBL = ModuleDataBL;

        }
        [HttpPost]
        public ResponseClass GetMasterBusinessType()
        {
            ResponseClass response = new ResponseClass();
            response = _ModuleBL.GetMasterBusinessType();
            return response;
        }
        [HttpPost]
        public ResponseClass GetMasterModuleOnBusinessTypeCode(ModuleBusinssType request)
        {
            ResponseClass response = new ResponseClass();
            response = _ModuleBL.GetMasterModuleOnBusinessTypeCode(request);
            return response;
        }

        [HttpPost]
        public ResponseClass  GetJoiningConfig(ModuleJoiningConfigFilters request)
        {
            ResponseClass response = new ResponseClass();
            response = _ModuleBL.GetJoiningConfig(request);
            return response;
        }
        [HttpPost]
        public ResponseClass InsertJoiningConfig(ModuleSaveJoiningConfig request)
        {
            ResponseClass response = new ResponseClass();
            response = _ModuleBL.InsertJoiningConfig(request);
            return response;
        }
        [HttpPost]
        public ResponseClass ValidateUploadFile(ValidateData request)
        {
            ResponseClass response = new ResponseClass();
            response = _ModuleBL.ValidateUploadFile(request);
            return response;
        }
        [HttpPost]
        public ResponseClass InsertYearConfig(ModuleSaveYearDepartmentConfig request)
        {
            ResponseClass response = new ResponseClass();
            response = _ModuleBL.InsertYearConfig(request);
            return response;
        }

        [HttpPost]
        public ResponseClass  GetUploadConfigData(FiltersforUploadDataConfig request)
        {
            ResponseClass response = new ResponseClass();
            response = _ModuleBL.GetUploadConfigData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetManualUploadConfig(FiltersforManualUploadDataConfig request)
        {
            ResponseClass response = new ResponseClass();
            response = _ModuleBL.GetManualUploadConfig(request);
            return response;
        }

    }
}
