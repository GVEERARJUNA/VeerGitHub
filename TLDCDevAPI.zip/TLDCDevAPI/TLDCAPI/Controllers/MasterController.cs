﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.Masters;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class MasterController : Controller
    {
        private IMasterBL _MasterBL;
        public MasterController(IMasterBL MasterDataBL)
        {
            _MasterBL = MasterDataBL;
           
        }

        [HttpPost]
        public ResponseClass GetCommonEntity(MasterSelectInsertDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterBL.GetMasterData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertStateMaster(StateMasterInsertDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterBL.InsertStateMaster(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetCommonDropDownValue(getcommonentityrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _MasterBL.GetCommonEntity(request);
            return response;
        }
    }
}
