﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using TLDCBAL.Common;
using TLDCBAL.EmployeeLeave;
using static TLDCBAL.EmployeeLeave.EmployeeLeaveDTO;
namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class EmployeeLeaveController : Controller
    {

        private IEmployeeLeaveBL _EmployeeLeaveBL;
        public EmployeeLeaveController(IEmployeeLeaveBL ModuleDataBL)
        {
            _EmployeeLeaveBL = ModuleDataBL;

        }

        [HttpPost]
        public ResponseClass InsertUpdateEmployeeLeave(EmployeeLeaveInsertUpdateModel request)
        {
            ResponseClass response = new ResponseClass();
            response = _EmployeeLeaveBL.InsertUpdateEmployeeLeave(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetEmployeeLeaveData(EmployeeLeaveFilter request)
        {
            ResponseClass response = new ResponseClass();
            response = _EmployeeLeaveBL.GetEmployeeLeaveData(request);
            return response;
        }
    }
}
