﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.Induction;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class InductionController : Controller
    {
        private IInductionGroupBL _inductionGroupBL;
        private IInductionReportBL _inductionReportBL;

        public InductionController(IInductionGroupBL inductionGroupBL, IInductionReportBL inductionReprot)
        {
            _inductionGroupBL = inductionGroupBL;
            _inductionReportBL = inductionReprot;
        }

        [HttpPost]
        public ResponseClass GetGeoList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetGeoList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetCityList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetCityList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetTypeOfSubmissionList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetTypeOfSubmissionList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetEmployeeListByDOJ(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetEmployeeListByDOJ(request);
            return response;
        }

        [HttpPost]
        public ResponseClass AddEmployeeDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.AddEmployeeDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertInductionGroupDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.InsertInductionGroupDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertInductionGroupDraftDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.InsertInductionGroupDraftDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertInductionGroupFeedbackDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.InsertInductionGroupFeedbackDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertInductionGroupFeedbackDraftDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.InsertInductionGroupFeedbackDraftDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetInductionFacilitatorList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetInductionFacilitatorList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetOnboarderList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetOnboarderList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetInductionGroupList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetInductionGroupList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetInductionGroupEmployeeList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetInductionGroupEmployeeList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetInductionGroupSerachList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetInductionGroupSearchList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass EditInductionGroupDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.EditInductionGroupDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass UpdateInductionGroupDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.UpdateInductionGroupDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass UpdateInductionGroupDraftDetails(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.UpdateInductionGroupDraftDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetInductionFeedbackQuestionList(InductionGroupDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.GetInductionFeedbackQuestionList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDetailedReport(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionReportBL.GetDetailedReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetCityCoverageReport(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionReportBL.GetCityCoverageReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetStatusReport(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionReportBL.GetStatusReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetStatusReportEmployees(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionReportBL.GetStatusReportEmployees(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDepartmentList(InductionReportRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionReportBL.GetDepartmentList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ChangeGroupStatus(changeGroupStatusRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionGroupBL.ChangeGroupStatus(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetInductionDashboardIconData(InductionDashboardRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionReportBL.GetInductionDashboardIconData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetInductionDashboardChartData(InductionDashboardRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionReportBL.GetInductionDashboardChartData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetInductionDashboardDepartmentData(InductionDashboardRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _inductionReportBL.GetInductionDashboardDepartmentData(request);
            return response;
        }
    }
}
