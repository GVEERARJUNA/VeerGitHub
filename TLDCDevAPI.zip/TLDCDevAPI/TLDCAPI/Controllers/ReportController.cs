﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.Reports;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ReportController : Controller
    {
        private IISAPReportBL _isapreport;
        private IAssessmentReportBL _assessmentReportBL;
        public ReportController(IISAPReportBL sapReport,IAssessmentReportBL assessmentReportBL)
        {
            _isapreport = sapReport;
            _assessmentReportBL = assessmentReportBL;

        }

        [HttpPost]
        public ResponseClass GetISAPCompletionSummary(getISAPCompletionSummaryDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.GetISAPCompletionSummary(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetISAPStatusReport(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.GetISAPStatusReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetFinalISAPStatusReport(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.GetFinalISAPStatusReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetISAPCSummaryReport(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.GetISAPCSummaryReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetISAPCSummaryReportDetail(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.GetISAPCSummaryReportDetail(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetISAPCompletionSummaryYearly(getISAPCompletionSummaryYearlyDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.GetISAPCompletionSummaryYearly(request);
            return response;
        }
        [HttpPost]
        public ResponseClass getEmployeeISAPExtension(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.getEmployeeISAPExtension(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getDepartmentISAPExtension(getISAPStatusReport request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.getDepartmentISAPExtension(request);
            return response;
        }

        [HttpPost]
        public ResponseClass checkFSTLReportAccess(checkFSTLReportaccessDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.checkFSTLReportAccess(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getFSTLSummaryReport()
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.getFSTLSummaryReport();
            return response;
        }
        [HttpPost]
        public ResponseClass getFSTLReportDetails(getFSTLReportDetails request)
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.getFSTLReportDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getFSTLReportDetailsForExport()
        {
            ResponseClass response = new ResponseClass();
            response = _isapreport.getFSTLReportDetailsForExport();
            return response;
        }
        [HttpPost]
        public ResponseClass GetDistinctGeo()
        {
            ResponseClass response = new ResponseClass();
            response = _assessmentReportBL.GetDistinctGeo();
            return response;
        }
        [HttpPost]
        public ResponseClass GetDistinctAssessment(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _assessmentReportBL.GetDistinctAssessment(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetAssessmentSummaryReportData(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _assessmentReportBL.GetAssessmentSummaryReportData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetQuickAssessmentDashboardCount(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _assessmentReportBL.GetQuickAssessmentDashboardCount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDistinctEvent(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _assessmentReportBL.GetDistinctEvent(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetQuickAssessmentDashboardCountDetail(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _assessmentReportBL.GetQuickAssessmentDashboardCountDetail(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetDistinctAssessmentDetail(AssessmentReportRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _assessmentReportBL.GetDistinctAssessmentDetail(request);
            return response;
        }
    }
}
