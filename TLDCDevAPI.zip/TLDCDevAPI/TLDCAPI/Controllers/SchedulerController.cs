﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Channels;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.Schedulers;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class SchedulerController : Controller
    {
        private ISchedulerBL _schedulerBL;
        public SchedulerController(ISchedulerBL schedulerBL)
        {
            _schedulerBL = schedulerBL;

        }

        [HttpGet]
        public ResponseClass NewJoiningAllocation()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.newJoiningAllocation();
            return response;
        }

        [HttpGet]
        public ResponseClass ISAPcalenderAllocation()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.ISAPcalenderAllocation();
            return response;
        }

        [HttpGet]
        public ResponseClass updateModuleExpiration()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.updateModuleExpiration();
            return response;
        }

        [HttpGet]
        public ResponseClass isapFailureNotification()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.isapFailureNotification();
            return response;
        }

        [HttpPost]
        public ResponseClass emailonpublishevent(publisheventrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.emailonpublishevent(request.objectcode, request.objecttype);
            return response;
        }

        //[HttpGet]
        //public ResponseClass weeklyInductionEmail()
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _schedulerBL.weeklyInductionEmail();
        //    return response;
        //}

        //[HttpGet]
        //public ResponseClass newjoineestatusupdate()
        //{
        //    ResponseClass response = new ResponseClass();
        //    response = _schedulerBL.newjoineestatusupdate();
        //    return response;
        //}

        [HttpPost]
        public ResponseClass getTreeData(getTreeDataRequest requestData)
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.getTreeData(requestData);
            return response;
        }

        [HttpGet]
        public ResponseClass ISAPcalenderStatusUpdate()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.ISAPcalenderStatusUpdate();
            return response;
        }

        [HttpGet]
        public ResponseClass ecoursepending()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.ecoursepending();
            return response;
        }

        [HttpGet]
        public ResponseClass mytodopending()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.mytodopending();
            return response;
        }

        [HttpGet]
        public ResponseClass weeklyteamleadupdate()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.weeklyteamleadupdate();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignFSTLCourse()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignFSTLCourse();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignFSTLAssignment()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignFSTLAssignment();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignFSTLSurvey()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignFSTLSurvey();
            return response;
        }

        [HttpGet]
        public ResponseClass SendFSTLCertificateEmail()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.SendFSTLCertificateEmail();
            return response;
        }

        [HttpGet]
        public ResponseClass addPendingUserToHall()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.addPendingUserToHall();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignDICourse()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignDICourse();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignDIAssessment()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignDIAssessment();
            return response;
        }

        [HttpGet]
        public ResponseClass UploadFSTLData()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.UploadFSTLData();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignSEEDGeneralEvent()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignSEEDGeneralEvent();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignSEEDTeamLeadEvent()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignSEEDTeamLeadEvent();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignSEEDAgentEvent()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignSEEDAgentEvent();
            return response;
        }

        [HttpGet]
        public ResponseClass UploadDNIData()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.UploadDNIData();
            return response;
        }

        [HttpGet]
        public ResponseClass ProjectFrameworkCourse()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.ProjectFrameworkCourse();
            return response;
        }

        [HttpGet]
        public ResponseClass ProjectFrameworkAssessment()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.ProjectFrameworkAssessment();
            return response;
        }

        [HttpGet]
        public ResponseClass AddNewEmployeeInExisitingEvent()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AddNewEmployeeInExisitingEvent();
            return response;
        }

        [HttpGet]
        public ResponseClass addEmployeeSkills()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.addEmployeeSkills();
            return response;
        }

        [HttpGet]
        public ResponseClass FSTLReportJob()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.FSTLReportJob();
            return response;
        }

        [HttpGet]
        public ResponseClass ProjectFrameworkReportJob()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.ProjectFrameworkReportJob();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignPFSurvey()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignPFSurvey();
            return response;
        }

        [HttpGet]
        public ResponseClass PRCAssessessmentSummary()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.PRCAssessessmentSummary();
            return response;
        }

        [HttpGet]
        public ResponseClass SendScheduleReportEmail()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.SendScheduleReportEmail();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignPOSHTONewEmployee()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignPOSHTONewEmployee();
            return response;
        }

        [HttpGet]
        public ResponseClass AssignPOSHTOExistingEmployee()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.AssignPOSHTOExistingEmployee();
            return response;
        }

        [HttpGet]
        public ResponseClass PendingPoshEmail()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.PendingPoshEmail();
            return response;
        }

        [HttpGet]
        public ResponseClass BOQReportJob()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.BOQReportJob();
            return response;
        }

        [HttpGet]
        public ResponseClass POSHReportJob()
        {
            ResponseClass response = new ResponseClass();
            response = _schedulerBL.POSHReportJob();
            return response;
        }

    }
}
