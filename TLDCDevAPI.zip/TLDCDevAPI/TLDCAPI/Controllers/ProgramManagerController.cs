﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.CourseAdmin;
using TLDCBAL.ProgramManager;
using TLDCBAL.WebSite;
using static TLDCBAL.ProgramManager.MarkAttendanceDTO;
using static TLDCBAL.ProgramManager.ProcessSessionDTO;
using static TLDCBAL.ProgramManager.ProcessTrainingDTO;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ProgramManagerController : Controller
    {
        private IExpressEventBL _expresseventBL;
        private IAllocateEntityBL _allocateentityBL;
        private IClassRoomTrainingBL _classroomtrainingbl;
        private IProcessTrainingBL _processTrainingBL;
        private IProcessSessionBL _ProcessSessionBL;
        private IMarkAttendanceBL _MarkAttendanceBL;
        private IProgramMasterBL _ProgramMasterBL;

        public ProgramManagerController(IExpressEventBL expresseventBL, IAllocateEntityBL allocateentityBL, IClassRoomTrainingBL classroomtrainingbl,IProcessTrainingBL processTrainingBL, IProcessSessionBL processSessionBL, IMarkAttendanceBL markAttendance, IProgramMasterBL programMasterBL)
        {
            _expresseventBL = expresseventBL;
            _allocateentityBL = allocateentityBL;
            _classroomtrainingbl = classroomtrainingbl;
            _processTrainingBL = processTrainingBL;
            _ProcessSessionBL = processSessionBL;
            _MarkAttendanceBL = markAttendance;
            _ProgramMasterBL = programMasterBL;
        }

        [HttpPost]
        public ResponseClass GetAdminDashboardcount(getadmindashboardcount request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetAdminDashboardcount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetProgramManagerToDo(getadmindashboardcount request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetProgramManagerToDo(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageExpressEvent(manageEventrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.ManageExpressEvent(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetExpressEventListView(manageEventrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetExpressEventListView(request);
            return response;
        }


        [HttpPost]
        public ResponseClass GetReportEvent(manageEventrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetReportEvent(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertEditExpressEvent(insertEditEventRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.InsertEditExpressEvent(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertEditAllocateEntity(AllocateEntityInsertRequestDto request)
        {
            ResponseClass response = new ResponseClass();
            response = _allocateentityBL.InsertEditAllocateEntity(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageAllocateEntity(manageallocateEntityRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _allocateentityBL.ManageAllocateEntity(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getAllocateEntityDropDownData(getAllocateEntityDropDownDataDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _allocateentityBL.getAllocateEntityDropDownData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageClassRoomTraining(manageClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.ManageClassRoomTraining(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetClassRoomListView(manageClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.GetClassRoomListView(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetProcessInstructor(ProcessInstructorDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _processTrainingBL.GetProcessInstructor(request);
            return response;
        }
        
        [HttpPost]
        public ResponseClass GetEventProcessDetail(manageProcessTrainingDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _processTrainingBL.GetEventProcessDetail(request);
            return response;
        }

        
            [HttpPost]
        public ResponseClass GetSessionDetail(manageProcessSession request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.GetSessionDetail(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetProcessAdministrator(ProcessAdministratorDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _processTrainingBL.GetProcessAdministrator(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetAttendanceRequiredTypeBySID(manageClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _processTrainingBL.GetAttendanceRequiredTypeBySID(request);
            return response;
        }
        [HttpPost]
        public ResponseClass ManageProcessTraining(manageProcessTrainingDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _processTrainingBL.ManageProcessTraining(request);
            return response;
        }
        [HttpPost]
        public ResponseClass InsertEditProcessTraining(addupdateProcessTrainingDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _processTrainingBL.InsertEditProcessTraining(request);
            return response;
        }
        [HttpPost]
        public ResponseClass EditProcessTraining(addupdateProcessTrainingDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _processTrainingBL.EditProcessTraining(request);
            return response;
        }

        [HttpPost]
        public ResponseClass PushSurveyResult(pushSurveyResultrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _allocateentityBL.PushSurveyResult(request);
            return response;
        }

        [HttpPost]
        public ResponseClass insertEditClassRoom(insertEditClassRoomRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.insertEditClassRoom(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getAssignedEntityDropDownData(getAssignedEntityDropDownDataDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.getAssignedEntityDropDownData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass insertEditClassRoomEntity(insertEditClassRoomEntity request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.insertEditClassRoomEntity(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getAssignedEntityDetailedData(getAssignedEntityDropDownDataDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.getAssignedEntityDetailedData(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageProcessSessionMaster(manageProcessSession request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.ManageProcessSessionMaster(request);
            return response;
        }
        [HttpPost]
        public ResponseClass InsertUpdateProcessSessionMaster(addupdateProcessSession request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.InsertUpdateProcessSessionMaster(request);
            return response;
        }
        [HttpPost]
        public ResponseClass EditProcessSessionMaster(addupdateProcessSession request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.EditProcessSessionMaster(request);
            return response;
        }
        [HttpPost]
        public ResponseClass DeleteProcessSession(deleteProcessSessiom request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.DeleteProcessSession(request);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertEditEventbyClassRoom(insertEditEventRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.InsertEditEventbyClassRoom(request);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteClassRoomEntity(deleteClassRoomEntityRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.DeleteClassRoomEntity(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetVenueForSession(VenueDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.GetVenueForSession(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetManageSessionCount(SessionCount request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.GetManageSessionCount(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetFacilitatorTypeForSession(FacilitatorTypeDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.GetFacilitatorTypeForSession(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetFacilitatorNameFromFacType(FacilitatorNameDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProcessSessionBL.GetFacilitatorNameFromFacType(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetEWSReason(EWSReasonSession request)
        {
            ResponseClass response = new ResponseClass();
            response = _MarkAttendanceBL.GetEWSReason(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetEWSStatus(EWSStatusSession request)
        {
            ResponseClass response = new ResponseClass();
            response = _MarkAttendanceBL.GetEWSStatus(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetAttendanceAbsentReason(AttendanceAbsentReasonSession request)
        {
            ResponseClass response = new ResponseClass();
            response = _MarkAttendanceBL.GetAttendanceAbsentReason(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetAttendanceData(AddUpdatePTSAttendance request)
        {
            ResponseClass response = new ResponseClass();
            response = _MarkAttendanceBL.GetAttendanceData(request);
            return response;
        }
        [HttpPost]
        public ResponseClass InsertEditMarkAttendance(AddUpdatePTSAttendance request)
        {
            ResponseClass response = new ResponseClass();
            response = _MarkAttendanceBL.InsertEditMarkAttendance(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetDateListForMarkAttendance(AttendanceDates request)
        {
            ResponseClass response = new ResponseClass();
            response = _MarkAttendanceBL.GetDateListForMarkAttendance(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetEntityNames(getEntityName request)
        {
            ResponseClass response = new ResponseClass();
            response = _allocateentityBL.GetEntityNames(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetClassRoomEntitycount(getclassroomentitycount request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.GetClassRoomEntitycount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetClassRoomEntityHeadercount(getclassroomentitycount request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.GetClassRoomEntityHeadercount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass DeleteEventAllocation(deleteeventallocationrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _allocateentityBL.DeleteEventAllocation(request);
            return response;
        }

        [HttpPost]
        public ResponseClass publishClassRoomEntity(allocateClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.publishClassRoomEntity(request);
            return response;
        }

        [HttpPost]
        public ResponseClass publishClassRoomEntitySingle(allocateClassRoomrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.publishClassRoomEntitySingle(request);
            return response;
        }

        [HttpPost]
        public ResponseClass eventdashboardCount(eventdashboardCountrequetDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.eventdashboardCount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass eventtaskProgress(eventdashboardCountrequetDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.eventtaskProgress(request);
            return response;
        }

        [HttpPost]
        public ResponseClass eventdashboarddetails(eventdashboardCountrequetDTO request)
        {
            ResponseClass response = new ResponseClass();
            if (request.EventType=="Assessment")
            {
                response = _expresseventBL.eventdashboarddetailsassessment(request);
            }
            else
            {
                response = _expresseventBL.eventdashboarddetails(request);
            }
            
            return response;
        }

        [HttpPost]
        public ResponseClass insertWIPrequest(insertWIPrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.insertWIPrequest(request);
            return response;
        }

        [HttpPost]
        public ResponseClass insertWIPOptedrequestWeb(insertWIPrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.insertWIPOptedrequest(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getclassroomdashboarddata(classroomdashboardrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.getclassroomdashboarddata(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getdashboarddetailedentity(classroomdashboardrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.getdashboarddetailedentity(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getclassdashboarddaywiseactivities(classroomdashboardrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.getclassdashboarddaywiseactivities(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getclassdashboardemployeewisedetail(classroomdashboardrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.getclassdashboardemployeewisedetail(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetTeamLeadPendingTask(TeamLeadPendingTaskDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetTeamLeadPendingTask(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetTeamLeadEmployeePendingTaskList(TeamLeadPendingTaskDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetTeamLeadEmployeePendingTaskList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetTotalPendingActivity(TeamLeadPendingTaskDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetTotalPendingActivity(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetTotalPendingActivityPaging(TeamLeadPendingTaskDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetTotalPendingActivityPaging(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetRequisitionUsers(RequestionDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetRequisitionUsers(request);
            return response;
        }

        [HttpPost]
        public ResponseClass CertificateListClass(getcertificatelistclass request)
        {
            ResponseClass response = new ResponseClass();
            response = _classroomtrainingbl.CertificateListClass(request);
            return response;
        }

        [HttpPost]
        public ResponseClass CheckEntityPublish(getEntityName request)
        {
            ResponseClass response = new ResponseClass();
            response = _allocateentityBL.CheckEntityPublish(request);
            return response;
        }
        [HttpPost]
        public ResponseClass InsertEditProgramMaster(ProgramMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.InsertEditProgramMaster(request);
            return response;
        }
        [HttpPost]
        public ResponseClass DeleteAssetLearningDetails(DeleteAssetLearningDetailsSTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.DeleteAssetLearningDetails(request);
            return response;
        }
        [HttpPost]
        public ResponseClass DeleteAssetDay(DeleteAssetDayDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.DeleteAssetDay(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetProgramMasterList(ProgramMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.GetProgramMasterList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ManageProgramMasterPaging(ProgramMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.ManageProgramMasterPaging(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetProgramLearningList(ProgramAssetLearningMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.GetProgramLearningList(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetProgramLearningListByPRcodeAndAssetID(ProgramAssetDetailsLearningMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.GetProgramLearningListByPRcodeAndAssetID(request);
            return response;
        } 
        [HttpPost]
        public ResponseClass GetAllocateAssetDropDownDataByAssetID(insertEditProgramLearningRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.GetAllocateAssetDropDownDataByAssetID(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetProgramMasterDataByProgramCode(ProgramMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.GetProgramMasterDataByProgramCode(request);
            return response;
        } 
        [HttpPost]
        public ResponseClass InsertEditProgramAsset(insertEditProgramLearningRequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.InsertEditProgramAsset(request);
            return response;
        }

        [HttpPost]
        public ResponseClass insertProgramDependency(inserteditprogramdependencyrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.insertProgramDependency(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetProgramDependencyList(ProgramAssetDetailsLearningMasterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ProgramMasterBL.GetProgramDependencyList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass EventPermanantDelete(eventdeleterequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.EventPermanantDelete(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetEventAllocationCount(eventdeleterequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetEventAllocationCount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetProgramDashboardCount(getprogramdashboardcountrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.GetProgramDashboardCount(request);
            return response;
        }

        [HttpPost]
        public ResponseClass getEventDays(getprogramdashboardcountrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.getEventDays(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ProgramDashboardDetailData(getprogramdashboardcountrequestdto request)
        {
            ResponseClass response = new ResponseClass();
            response = _expresseventBL.ProgramDashboardDetailData(request);
            return response;
        }
    }
}
