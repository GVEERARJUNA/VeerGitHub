﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.KnowledgeBase;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class KnowledgeBaseController : Controller
    {
        private IKnowledgeBaseBL _knowledgeBaseBL;


        public KnowledgeBaseController(IKnowledgeBaseBL knowledgeBaseBL)
        {
            _knowledgeBaseBL = knowledgeBaseBL;

        }

        [HttpPost]
        public ResponseClass GetAssessmentDetailReport(getassessmentdetailreportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetAssessmentDetailReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetAssessmentQuestionsReport(getAssessmentQuestionsReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetAssessmentQuestionsReport(request);
            return response;
        }


        [HttpPost]
        public ResponseClass GetAssessmentQuestionsType(getAssessmentQuestionsReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetAssessmentQuestionsType(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetAssessmentNames(getAssessmentQuestionsReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetAssessmentNames(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetClassEventNames(getAssessmentQuestionsReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetClassEventNames(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetSCORMCoursesProgressReport(getscormcourseprogressreportrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetSCORMCoursesProgressReport(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetEmployeeDetails(EmployeeNameWithIdDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetEmployeeDetails(request);
            return response;
        }
        public ResponseClass GetDesignationDetails(DesignationDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetDesignationDetails(request);
            return response;
        }
        public ResponseClass GetRoleDetails(RoleDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetRoleDetails(request);
            return response;
        }
        public ResponseClass GetReportingAuthorityDetails(ReportingAuthorityDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportingAuthorityDetails(request);
            return response;
        }
        public ResponseClass GetLocationDetails(LocationDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetLocationDetails(request);
            return response;
        }
        [HttpPost]
        public ResponseClass SiteUsageReport(getSiteUsageReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.SiteUsageReport(request);
            return response;
        }
        public ResponseClass GetLearningNameDetails(LearningNameDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetLearningNameDetails(request);
            return response;
        }
        public ResponseClass GetEventNameDetails(EventNameDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetEventNameDetails(request);
            return response;
        }
        public ResponseClass GetClassNameDetails(ClassNameDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetClassNameDetails(request);
            return response;
        }
        [HttpPost]
        public ResponseClass BlendedLearnerProgressReport(BlendedLearnerProgressReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.BlendedLearnerProgressReport(request);
            return response;
        }
        public ResponseClass GetClassNameForReport(ClassNameReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetClassNameForReport(request);
            return response;
        }
        public ResponseClass GetEventNameForReport(EventNameReportDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetEventNameForReport(request);
            return response;
        }
        [HttpPost]
        public ResponseClass LearningDistributionReport(LearningDistributionReport request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.LearningDistributionReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetAssessmentSummaryReport(getAssessmentReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetAssessmentSummaryReport(request);
            return response;
        }
        public ResponseClass GetClassNameAttendance(ClassNameForAttendanceDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetClassNameAttendance(request);
            return response;
        }
        public ResponseClass GetEventNameAttendance(EventNameForAttendanceDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetEventNameAttendance(request);
            return response;
        }
        public ResponseClass GetSessionNameAttendance(SessionNameForAttendanceDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetSessionNameAttendance(request);
            return response;
        }
        [HttpPost]
        public ResponseClass ClassroomAttendanceDetailsReport(ClassroomAttendanceDetailsReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.ClassroomAttendanceDetailsReport(request);
            return response;
        }
        
            [HttpPost]
        public ResponseClass ClassroomAttendanceSummaryReport(ClassroomAttendanceSummaryReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.ClassroomAttendanceSummaryReport(request);
            return response;
        }
        [HttpPost]
        public ResponseClass SurveyQuestionSummaryReport(SurveyQuestionSummaryReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.SurveyQuestionSummaryReport(request);
            return response;
        }
        [HttpPost]
        public ResponseClass SurveySummaryReportDetails(SurveySummaryDetailedReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.SurveySummaryReportDetails(request);
            return response;
        }
        public ResponseClass GetSurveyNameDetails(SurveyNameDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetSurveyNameDetails(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetSurveySummaryReport(getSurveySummaryReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetSurveySummaryReport(request);
            return response;
        }
        
        public ResponseClass GetSurveySummaryReportNameList(getSurveySummaryReportDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetSurveySummaryReportNameList(request);
            return response;
        }

        public ResponseClass getProjectFrameworkReport(getprojectframeworkreportrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.getProjectFrameworkReport(request);
            return response;
        }

        public ResponseClass getProjectFrameworkReportDashboard(getprojectframeworkreportrequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.getProjectFrameworkReportDashboard(request);
            return response;
        }

        public ResponseClass GetScheduleReportHeader(getschedulereportrequestdto request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetScheduleReportHeader(request);
            return response;
        }

        public ResponseClass GetDynamicReport(getschedulereportrequestdto request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetDynamicReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetBOQAssessmentReport(getBOQAssessmentReportRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetBOQAssessmentReport(request);
            return response;
        }
        [HttpPost]
        public ResponseClass GetBOQCourseReport(getBOQAssessmentReportRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetBOQCourseReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetPOSHReport(getPOSHReportRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetPOSHCourseReport(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetPOSHReportFilters(getPOSHReportRequestDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetPOSHReportFilters(request);
            return response;
        }

        
        [HttpPost]
        public ResponseClass GetReportFilterEventList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterEventList(request);
            return response;
        }


        [HttpPost]
        public ResponseClass GetReportFilterClassroomList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterClassroomList(request);
            return response;
        }


        [HttpPost]
        public ResponseClass GetReportFilterAssessmentList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterAssessmentList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetReportFilterAssessmentCreatorList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterAssessmentCreatorList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetReportFilterEventCreatorList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterEventCreatorList(request);
            return response;
        }


        [HttpPost]
        public ResponseClass GetReportFilterLearningNameList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterLearningNameList(request);
            return response;
        }


        [HttpPost]
        public ResponseClass GetReportFilterLearningCreatorList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterLearningCreatorList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetReportFilterSurveyCreatorList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterSurveyCreatorList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetReportFilterSurveyNameList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterSurveyNameList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass GetReportFilterClassroomCreatorList(ReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _knowledgeBaseBL.GetReportFilterClassroomCreatorList(request);
            return response;
        }

    }
}
