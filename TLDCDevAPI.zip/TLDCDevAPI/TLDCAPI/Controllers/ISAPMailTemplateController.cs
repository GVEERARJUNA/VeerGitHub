﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TLDCBAL.Common;
using TLDCBAL.ISAPAdmin;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ISAPMailTemplateController : Controller
    {
        private IMailTemplateBL _mailTemplateBL;

        public ISAPMailTemplateController(IMailTemplateBL mailTemplateBL)
        {
            _mailTemplateBL = mailTemplateBL;
        }

        [HttpPost]
        public ResponseClass GetISAPMailTemplateDetails(MailTemplateDTO request)
        {
            ResponseClass response = new ResponseClass();

            response = _mailTemplateBL.GetMailTemplateDetails(request);

            return response;
        }

        [HttpPost]
        public ResponseClass InsertISAPMailTemplateDetails(MailTemplateDTO request)
        {
            ResponseClass response = new ResponseClass();

            response = _mailTemplateBL.InsertMailTemplateDetails(request);

            return response;
        }

        [HttpPost]
        public ResponseClass DeleteISAPMailTemplateDetails(MailTemplateDeleteDTO request)
        {
            ResponseClass response = new ResponseClass();

            response = _mailTemplateBL.DeleteMailTemplateDetails(request);

            return response;
        }

        [HttpPost]
        public ResponseClass ViewISAPMailTemplateDetails(MailTemplateDTO request)
        {
            ResponseClass response = new ResponseClass();

            response = _mailTemplateBL.ViewISAPMailTemplateDetails(request);

            return response;
        }

        [HttpPost]
        public ResponseClass UpdateISAPMailTemplateDetails(MailTemplateDTO request)
        {
            ResponseClass response = new ResponseClass();

            response = _mailTemplateBL.UpdateISAPMailTemplateDetails(request);

            return response;
        }

        [HttpPost]
        public ResponseClass GetMailLanguage(MailLanguageDTO request)
        {
            ResponseClass response = new ResponseClass();

            response = _mailTemplateBL.GetMailLanguage(request);

            return response;
        }

    }
}
