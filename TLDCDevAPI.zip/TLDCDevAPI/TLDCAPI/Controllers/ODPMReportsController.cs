﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using TLDCBAL.Common;
using TLDCBAL.KnowledgeBase;
using TLDCBAL.ODPM;

namespace TLDCAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ODPMReportsController : Controller
    {
        private IODPMReportBL _reportBL;
        public ODPMReportsController(IODPMReportBL oDPMBL)
        {
            _reportBL = oDPMBL;

        }


        [HttpPost]
        public ResponseClass ODPMReportFilterGeoList(ODPMReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _reportBL.ODPMReportFilterGeoList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ODPMReportFilterDepartmentList(ODPMReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _reportBL.ODPMReportFilterDepartmentList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ODPMReportFilterCityList(ODPMReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _reportBL.ODPMReportFilterCityList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ODPMReportFilterProgramManagerList(ODPMReportFilterDTO request)
        {

            ResponseClass response = new ResponseClass();
            response = _reportBL.ODPMReportFilterProgramManagerList(request);
            return response;
        }

        [HttpPost]
        public ResponseClass ODPMTrainingDetailedReport(ODPMReportFilterDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _reportBL.ODPMTrainingDetailedReport(request);
            return response;
        }
    }
}
