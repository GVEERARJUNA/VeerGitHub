﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TLDCDAL
{
    public class OutParameter
    {
        public string ParameterName { get; set; }

        public string ParameterValue { get; set; }
        public int RecordCount { get; set; }
    }
}
