﻿using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace TLDCDAL
{
    public class DBConnection
    {
		string connString = string.Empty;

		private IConfiguration configuration;

		public DBConnection()
		{

		}
		public DBConnection(string dbConnection)
		{
			connString = dbConnection;


		}

		public DataSet ExecuteDataSet(string procName, SqlParameter[] paramters, List<OutParameter> outparameter)

		{
			DataSet result = null;

			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					using (SqlDataAdapter sda = new SqlDataAdapter(command))
					{
						command.CommandType = System.Data.CommandType.StoredProcedure;
						command.CommandText = procName;
						if (paramters != null)
						{
							command.Parameters.AddRange(paramters);
						}
						result = new DataSet();
						sda.Fill(result);

						foreach (SqlParameter item in paramters)
						{
							if (item.Direction == ParameterDirection.Output)
							{
								outparameter.Add(new OutParameter { ParameterName = item.ParameterName, ParameterValue = Convert.ToString(item.Value) });

							}

						}
					}
				}
			}
			return result;
		}

		public int ExecuteNonQuery(string procName, SqlParameter[] paramters, List<OutParameter> outparameter)

		{
			
			int result = 0;
			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					command.CommandType = System.Data.CommandType.StoredProcedure;
					command.CommandText = procName;
					if (paramters != null)
					{
						command.Parameters.AddRange(paramters);
					}
					sqlConnection.Open();
					result = command.ExecuteNonQuery();

					foreach (SqlParameter item in paramters)
					{
						if (item.Direction == ParameterDirection.Output)
						{
							outparameter.Add(new OutParameter { ParameterName = item.ParameterName, ParameterValue = Convert.ToString(item.Value) });

						}

					}

					sqlConnection.Close();


				}
			}
			return result;
		}

		//public DataSet ExecuteDataSet(string procName, NpgsqlParameter[] paramters, List<OutParameter> outparameter)

		//{
		//	DataSet result = null;

		//	using (var sqlConnection = new NpgsqlConnection(connString))
		//	{
		//		using (var command = sqlConnection.CreateCommand())
		//		{
		//			using (NpgsqlDataAdapter sda = new NpgsqlDataAdapter(command))
		//			{
		//				command.CommandType = System.Data.CommandType.StoredProcedure;
		//				command.CommandText = procName;
		//				if (paramters != null)
		//				{
		//					command.Parameters.AddRange(paramters);
		//				}
		//				result = new DataSet();
		//				sda.Fill(result);

		//				foreach (NpgsqlParameter item in paramters)
		//				{
		//					if (item.Direction == ParameterDirection.Output)
		//					{
		//						outparameter.Add(new OutParameter { ParameterName = item.ParameterName, ParameterValue = Convert.ToString(item.Value) });

		//					}

		//				}
		//			}
		//		}
		//	}
		//	return result;
		//}
		//public int ExecuteNonQuery(string procName, NpgsqlParameter[] paramters, List<OutParameter> outparameter)

		//{

		//	int result = 0;
		//	using (var sqlConnection = new NpgsqlConnection(connString))
		//	{
		//		using (var command = sqlConnection.CreateCommand())
		//		{
		//			command.CommandType = System.Data.CommandType.StoredProcedure;
		//			command.CommandText = procName;
		//			if (paramters != null)
		//			{

		//			}
		//			command.Parameters.AddWithValue("StateName", NpgsqlTypes.NpgsqlDbType.Name, "Deepak");
		//			sqlConnection.Open();
		//			result = command.ExecuteNonQuery();

		//			foreach (NpgsqlParameter item in paramters)
		//			{
		//				if (item.Direction == ParameterDirection.Output)
		//				{
		//					outparameter.Add(new OutParameter { ParameterName = item.ParameterName, ParameterValue = Convert.ToString(item.Value) });

		//				}

		//			}

		//			sqlConnection.Close();


		//		}
		//	}
		//	return result;
		//}

		public DataSet ExecuteDataSetInline(string inlineQuery)

		{
			DataSet result = null;
			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					using (SqlDataAdapter sda = new SqlDataAdapter(command))
					{
						command.CommandType = System.Data.CommandType.Text;
						command.CommandText = inlineQuery;

						result = new DataSet();
						sda.Fill(result);


					}
				}
			}
			return result;
		}
	}
}
