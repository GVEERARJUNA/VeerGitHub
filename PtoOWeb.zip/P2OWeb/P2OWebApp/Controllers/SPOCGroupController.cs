﻿using Microsoft.AspNetCore.Mvc;
using P2OWebApp.Extensions;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Masters;
using P2OWebApp.Models.SessionManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Controllers
{
    public class SPOCGroupController : Controller
    {
        private readonly IMasterDataBL _masterBl;

        public SPOCGroupController(IMasterDataBL masterBl)
        {
            _masterBl = masterBl;
        }

        public IActionResult Index()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "SPOCGroupManage";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            return View();
        }

        [HttpPost]
        public JsonResult PRSPOCGroupManage(PRSPOCRequestDTO pRSPOCRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                response.responseCode = 2;
                response.responseMessage = "Session not exist!";
                return Json(response);
            }
            if (pRSPOCRequestDTO.Action == "ADDGROUP")
            {
                if (string.IsNullOrEmpty(pRSPOCRequestDTO.PRSPOCGroupTitle))
                {
                    response.responseCode = 0;
                    response.responseMessage = "PRSPOCGroupTitle required!";
                    return Json(response);
                }
                else if (pRSPOCRequestDTO.PRSPOCGroupTitle.Length>100)
                {
                    response.responseCode = 0;
                    response.responseMessage = "PRSPOCGroupTitle cannot be exceed than 200 characters!";
                    return Json(response);
                }

            }
            if (pRSPOCRequestDTO.Action == "ADDMEMBER")
            {
                if (string.IsNullOrEmpty(pRSPOCRequestDTO.EmployeeID))
                {
                    response.responseCode = 0;
                    response.responseMessage = "EmployeeID required!";
                    return Json(response);
                }
                
            }
            if (pRSPOCRequestDTO.Action == "GETMEMBER" || pRSPOCRequestDTO.Action == "ADDMEMBER")
            {

                if ((pRSPOCRequestDTO.PRSPOCGroupID) == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "PRSPOCGroupID required!";
                    return Json(response);
                }
            }
            if (pRSPOCRequestDTO.Action == "DELETEMEMBER")
            {
                if ((pRSPOCRequestDTO.PRSPOCMemberID) == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "PRSPOCMemberID required!";
                    return Json(response);
                }

            }
            pRSPOCRequestDTO.InsertedBy = loggedInUser.EmployeeId;
            pRSPOCRequestDTO.InsertedIPAddress= Request.HttpContext.Connection.RemoteIpAddress.ToString();
            response = _masterBl.PRSPOCGroupManage(pRSPOCRequestDTO);

            return Json(response);
        }
    }
}
