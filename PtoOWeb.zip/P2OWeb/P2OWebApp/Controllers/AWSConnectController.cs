﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using P2OWebApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AWSModel = P2OWebApp.Models.AWSConnectListViewModel;
using System.IO.Compression;
using Amazon.S3.Transfer;

namespace P2OWebApp.Controllers
{
    public class AWSConnectController : Controller
    {
        private readonly IOptions<IDBConnection> appSettings;
        public string bucketName, AccessKey, secretKey;
        public AWSConnectController(IOptions<IDBConnection> appSettings)
        {
            this.appSettings = appSettings;
            bucketName = appSettings.Value.BucketName;
            AccessKey = appSettings.Value.AccessKey;
            secretKey = appSettings.Value.SecretKey;
        }
        public ActionResult Index()
        {
            var p = Request.QueryString.ToString();
            var PrNumber = p.Trim('?');
            var folderName = "Requisition/" + PrNumber;
            var s3Client = new AmazonS3Client(AccessKey, secretKey, RegionEndpoint.APSouth1);
            ListObjectsV2Request request = new ListObjectsV2Request
            {
                BucketName = bucketName,
                Prefix = folderName
            };
            var response = s3Client.ListObjectsV2Async(request).Result;
            var arquivos = response.S3Objects.Select(x => x.Key);
            var fileList = arquivos.Select(x => Path.GetFileName(x)).ToList();

            List<AWSModel.NodeDetails> List = new List<AWSModel.NodeDetails>();
           AWSModel.ListViewModel PRDetails = new AWSModel.ListViewModel();

            foreach (var file in fileList)
            {
                string fullpath = bucketName + "/" + folderName + "/" + file;
                var url = s3Client.GetPreSignedURL(new Amazon.S3.Model.GetPreSignedUrlRequest
                {
                    BucketName = bucketName,
                    Key = folderName + "/" + file,

                    Expires = DateTime.UtcNow.AddMinutes(15)
                });


                IEnumerable<AWSModel.DataModel> FileDetails = new List<AWSModel.DataModel>();
                var spResult1 = fileList;
                FileDetails = spResult1.Select(r => new AWSModel.DataModel
                {
                    UserFileName = file,
                    ActualFileName = fullpath
                }).ToList();
                PRDetails.PRNumber = PrNumber;

                PRDetails.FileDetails = FileDetails;
                PRDetails.BaseURL = appSettings.Value.P2OBaseURL;

            }

            return View(PRDetails);
        }

        [HttpPost]
        public JsonResult GetNodeDetailsForFileList(string abc)
        {
            var PrNumber = abc;
            var folderName = "Requisition/" + PrNumber;
            //var folderName = "Receipt/";
            List<AWSModel.NodeDetails> List = new List<AWSModel.NodeDetails>();
            var s3Client = new AmazonS3Client(AccessKey, secretKey, RegionEndpoint.APSouth1);
            ListObjectsV2Request request = new ListObjectsV2Request
            {
                BucketName = bucketName,
                Prefix = folderName
            };
            var response = s3Client.ListObjectsV2Async(request).Result;
            var arquivos = response.S3Objects.Select(x => x.Key);
            var fileList = arquivos.Select(x => Path.GetFileName(x)).ToList();

            foreach (var file in fileList)
            {
                string fullpath = bucketName + "/" + folderName + "/" + file;
                var url = s3Client.GetPreSignedURL(new Amazon.S3.Model.GetPreSignedUrlRequest
                {
                    BucketName = bucketName,
                    Key = folderName + "/" + file,

                    Expires = DateTime.UtcNow.AddMinutes(15)
                });

                AWSModel.NodeDetails lst = new AWSModel.NodeDetails();

                lst.name = file;
                lst.id = fullpath;
                lst.file = url;

                List.Add(lst);
            }
            return Json(List);
        }

    public IActionResult DownloadFile(string filePath, string fileName, string prNumber)
    {
        var folderName = "Requisition/" + prNumber;
        string basePath = Path.Combine(Directory.GetCurrentDirectory(), "Downloads");
        DirectoryInfo drsub = new DirectoryInfo(Path.Combine(basePath, prNumber));
        if (drsub.Exists)
        {
            drsub.Delete(true); //Delete subdirectory with PR number
        }

        DirectoryInfo dr = new DirectoryInfo(basePath);
        dr.CreateSubdirectory(prNumber); //Create sub directory with PR Number
        foreach (FileInfo fr in drsub.GetFiles())
        {
            fr.Delete(); //delete if file exists
        }

        var s3Client = new AmazonS3Client(AccessKey, secretKey, RegionEndpoint.APSouth1);
        var request = new GetObjectRequest
        {
            BucketName = bucketName,
            Key = folderName + "/" + fileName
        };
        var response = s3Client.GetObjectAsync(request).Result;
        var transferUtility = new TransferUtility(s3Client);
        string savePath = Path.Combine(basePath, prNumber, fileName);
        transferUtility.DownloadAsync(savePath, bucketName, folderName + "/" + fileName).Wait(); // Save file in Downloads/PRnumber folder
        return File(new FileStream(savePath, FileMode.Open), System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
    }

        public IActionResult DownloadAllFilesAsZip(string filePath, string FileName, string PRNumber)
        {
            var folderName = "Requisition/" + PRNumber;
            string BasePath = Path.Combine(Directory.GetCurrentDirectory(), "Downloads");
            DirectoryInfo drsub = new DirectoryInfo(Path.Combine(BasePath, PRNumber));

            if (drsub.Exists)
            {
                drsub.Delete(true); // Delete subdirectory with PR number
            }

            DirectoryInfo dr = new DirectoryInfo(BasePath);
            dr.CreateSubdirectory(PRNumber); // Create subdirectory with PR number

            foreach (FileInfo fr in drsub.GetFiles())
            {
                fr.Delete(); // Delete file if exists
            }

            var s3Client = new AmazonS3Client(AccessKey, secretKey, RegionEndpoint.APSouth1);
            List<AWSModel.NodeDetails> List = new List<AWSModel.NodeDetails>();
            string urlMain = filePath;
            string fileNameMain = FileName;

            ListObjectsV2Request request = new ListObjectsV2Request
            {
                BucketName = bucketName,
                Prefix = folderName
            };
            var response = s3Client.ListObjectsV2Async(request).Result;
            var arquivos = response.S3Objects.Select(x => x.Key);
            var fileList = arquivos.Select(x => Path.GetFileName(x)).ToList();

            foreach (var file in fileList)
            {
                var url = s3Client.GetPreSignedURL(new Amazon.S3.Model.GetPreSignedUrlRequest
                {
                    BucketName = bucketName,
                    //Key = fullpath,
                    Key = folderName + "/" + file,

                    Expires = DateTime.UtcNow.AddMinutes(15)
                });

                urlMain = url;
                fileNameMain = file;

                string savePath = Path.Combine(BasePath, PRNumber, fileNameMain);
                using (WebClient client = new WebClient())
                {
                    client.DownloadFile(urlMain, savePath); // Save file in Downloads/PRnumber folder
                }
            }

            string[] filePaths = Directory.GetFiles(Path.Combine(BasePath, PRNumber));
            List<AWSModel.FileModel> files = new List<AWSModel.FileModel>();

            foreach (string filePath1 in filePaths)
            {
                files.Add(new AWSModel.FileModel()
                {
                    FileName = Path.GetFileName(filePath1),
                    FilePath = filePath1
                });
            }

            string zipFileName = PRNumber + DateTime.Now.ToString("yyyy-MM-dd-HHmmss");
            string zipName = String.Format(PRNumber + "_{0}.zip", DateTime.Now.ToString("yyyy-MM-dd-HHmmss"));
            var memoryStream = new MemoryStream();

            using (var zipArchive = new ZipArchive(memoryStream, ZipArchiveMode.Create, true))
            {
                zipArchive.CreateEntry(zipFileName + "/");
                foreach (var file in files)
                {
                    var entry = zipArchive.CreateEntry(zipFileName + "/" + file.FileName);
                    using (var streamWriter = new StreamWriter(entry.Open()))
                    {
                        using (var fileStream = new FileStream(file.FilePath, FileMode.Open, FileAccess.Read))
                        {
                            fileStream.CopyTo(streamWriter.BaseStream);
                        }
                    }
                }
            }
            return File(memoryStream.ToArray(), "application/zip", zipName);
        }
    }
}
