﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using P2OWebApp.Extensions;
using P2OWebApp.Models.Approval;
using P2OWebApp.Models.AppStats;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Header;
using P2OWebApp.Models.SessionManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Controllers
{
    public class UserResponseController : Controller
    {

        private IApprovalBL _approvalBL;
        private IAppStatsBL _appStats;

        public UserResponseController(IApprovalBL approvalBL, IAppStatsBL appStats)
        {

            _approvalBL = approvalBL;
            _appStats = appStats;

        }

        public IActionResult Index(string requistionNo, string EMPCode)
        {
            ViewBag.ModuleName = "PR Detail";
            ViewBag.PageName = "Email Approval";
            PRRequistionDataRequestDTO approvalRequestDTO = new PRRequistionDataRequestDTO();
            WaitingApproval waitingApproval = new WaitingApproval();
            List<WaitingApprovalResponceDTO> WaitingApprovalResponse = new List<WaitingApprovalResponceDTO>();

            if (string.IsNullOrEmpty(requistionNo))
            {
                ViewBag.Error = "Requistion No required!";
                return View(waitingApproval);
            }

            if (string.IsNullOrEmpty(EMPCode))
            {
                ViewBag.Error = "Employee Code required!";
                return View(waitingApproval);
            }

            CommonFunction commonFunction = new CommonFunction();
            string approvalEmpCode = commonFunction.Decrypt(HttpUtility.HtmlEncode(EMPCode));
            ViewBag.LoggedinEmpId = approvalEmpCode;

            approvalRequestDTO.LoggedInEmpId = (approvalEmpCode);
            approvalRequestDTO.requistionNo = commonFunction.Decrypt(requistionNo);
            ViewBag.EMPCode = approvalRequestDTO.LoggedInEmpId;
            //approvalRequestDTO.LoggedInEmpId = EMPCode;
            //approvalRequestDTO.requistionNo = requistionNo;

            ResponseClass response = new ResponseClass();
            response = _approvalBL.GetPRRequistionDataByRequistionNo(approvalRequestDTO);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    WaitingApprovalResponse = JsonConvert.DeserializeObject<List<WaitingApprovalResponceDTO>>(response.responseJSON.ToString());

                    if (WaitingApprovalResponse.Count() > 0)
                    {

                        foreach (var item in WaitingApprovalResponse)
                        {
                            item.RequistionControlID = item.PurchaseRequistionID + "_approvallistflow";

                            GetPREntityRequest requestDTOdetails = new GetPREntityRequest();
                            requestDTOdetails.PurchaseRequistionID = item.PurchaseRequistionID;
                            requestDTOdetails.SearchType = "DETAILLINE";
                            var detailResponse = _approvalBL.GetPRDetailLines(requestDTOdetails);
                            if (detailResponse != null)
                            {
                                item.waitingApprovalDetails = detailResponse;

                            }

                        }
                    }
                    waitingApproval.waitingApprovalRes = WaitingApprovalResponse;
                }
            }
            else
            {
                ViewBag.Error = response.responseMessage;
            }


            return View(waitingApproval);
        }

        public IActionResult RequistionDetail(string requistionNo, string EMPCode,string Source)
        {
            ViewBag.ModuleName = "PR Detail";
            ViewBag.PageName = "Recent PR";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            PRRequistionDataRequestDTO approvalRequestDTO = new PRRequistionDataRequestDTO();
            WaitingApproval waitingApproval = new WaitingApproval();
            List<WaitingApprovalResponceDTO> WaitingApprovalResponse = new List<WaitingApprovalResponceDTO>();

            if (string.IsNullOrEmpty(requistionNo))
            {
                ViewBag.Error = "Requistion No required!";
                return View(waitingApproval);
            }

            if (string.IsNullOrEmpty(EMPCode))
            {
                ViewBag.Error = "Employee Code required!";
                return View(waitingApproval);
            }

            CommonFunction commonFunction = new CommonFunction();
            string approvalEmpCode = commonFunction.Decrypt(HttpUtility.HtmlEncode(EMPCode));
            ViewBag.LoggedinEmpId = approvalEmpCode;

            approvalRequestDTO.LoggedInEmpId = (approvalEmpCode);
            approvalRequestDTO.requistionNo = commonFunction.Decrypt(requistionNo);
            approvalRequestDTO.AppSource = Source;
            ViewBag.EMPCode = approvalRequestDTO.LoggedInEmpId;
            //approvalRequestDTO.LoggedInEmpId = EMPCode;
            //approvalRequestDTO.requistionNo = requistionNo;

            ResponseClass response = new ResponseClass();
            response = _approvalBL.GetPRRequistionDataByRequistionNo(approvalRequestDTO);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    WaitingApprovalResponse = JsonConvert.DeserializeObject<List<WaitingApprovalResponceDTO>>(response.responseJSON.ToString());

                    if (WaitingApprovalResponse.Count() > 0)
                    {

                        foreach (var item in WaitingApprovalResponse)
                        {
                            item.RequistionControlID = item.PurchaseRequistionID + "_approvallistflow";

                            GetPREntityRequest requestDTOdetails = new GetPREntityRequest();
                            requestDTOdetails.PurchaseRequistionID = item.PurchaseRequistionID;
                            requestDTOdetails.SearchType = "DETAILLINE";
                            var detailResponse = _approvalBL.GetPRDetailLines(requestDTOdetails);
                            if (detailResponse != null)
                            {
                                item.waitingApprovalDetails = detailResponse;

                            }

                        }
                    }
                    waitingApproval.waitingApprovalRes = WaitingApprovalResponse;
                }
            }
            else
            {
                ViewBag.Error = response.responseMessage;
            }


            return View(waitingApproval);
        }
        public JsonResult trackuser(AppStatsDTO appStatsBO)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                appStatsBO.employee_code = loggedInUser.EmployeeId;
                appStatsBO.employee_name = loggedInUser.FirstName;
                appStatsBO.country = loggedInUser.CountryName;

            }
           

            string Path = HttpContext.Request.Path;
            appStatsBO.ip_address = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            appStatsBO.device_model = (Environment.MachineName ?? string.Empty);
            var response = _appStats.AppStatInsert(appStatsBO);
           
            return Json("SUCCESS");
        }
    }
}
