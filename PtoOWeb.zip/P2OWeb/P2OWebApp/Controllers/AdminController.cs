﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ClosedXML.Excel;
using ExcelDataReader;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using P2OWebApp.Extensions;
using P2OWebApp.Models;
using P2OWebApp.Models.AdminManagement;
using P2OWebApp.Models.Audit;
using P2OWebApp.Models.CatalogueManagement;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.CurrencyManagement;
using P2OWebApp.Models.Masters;
using P2OWebApp.Models.SessionManagement;
using P2OWebApp.Models.ShoppingCart;

namespace P2OWebApp.Controllers
{
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;
        private readonly IUserManagementBL _UserManagementBL;
        private readonly IMasterDataBL _masterBl;
        private readonly IAuditBL _auditBL;
        private readonly ICatalogueManagementBL _catalogueManagementBL;
        private readonly ICurrencyConversionBL _CurrencyConversionBL;
        public AdminController(ILogger<AdminController> logger,
            IUserManagementBL userManagement,
            IMasterDataBL masterBl, IAuditBL auditBL,
            ICatalogueManagementBL catalogueManagementBL,
            ICurrencyConversionBL currencyConversionBL
            )
        {
            _logger = logger;
            _UserManagementBL = userManagement;
            _masterBl = masterBl;
            _auditBL = auditBL;
            _catalogueManagementBL = catalogueManagementBL;
            _CurrencyConversionBL = currencyConversionBL;
        }

        public IActionResult Index()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Manage User";
            
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser ==null)
            {
                return Redirect("~/Auth/Index");

            }

            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            //UserManagement userManagement = new UserManagement();
            //userManagement.UserName = loggedInUser.EmployeeId;
            //List<UserManagementResponse> userManagementResponses = new List<UserManagementResponse>();
            //userManagementResponses = _UserManagementBL.ManageUsers(userManagement);
            //return View(userManagementResponses);
            return View();
        }

        public JsonResult GetUserData(UserManagement userManagement
            //int RowsOfPage, int pageNumber,string UserName
            )
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Json(null);

            }

            if (userManagement.RowsOfPage==0)
            {
                userManagement.RowsOfPage = 20;
            }
            //UserManagement userManagement = new UserManagement();
            //userManagement.UserName = loggedInUser.EmployeeId;
            //userManagement.RowsOfPage = userManagement.RowsOfPage;
            //userManagement.PageNumber = userManagement.pageNumber;

            var UserData = _UserManagementBL.ManageUsers(userManagement);
            return Json(UserData);
        }

        public IActionResult UserManagement()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Manage User";
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult PurchaseType()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Purchase Type";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult PurchaseGroup()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Purchase Group";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult CostCenter()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Cost Center";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult CurrencyMaster()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Currency Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult PlantCode()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Plant Code";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult Vendor()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Vendor Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult GLMaster()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "GL Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult Material()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Material Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult ServiceMaterial()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Service Material Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult PurchaseOrganisation()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Purchase Organisation Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult StatusMaster()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Status Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult CompanyMaster()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Company Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");

            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public JsonResult GetMasterData(int RowsOfPage, int pageNumber, string MasterType, string CompanyCode, string CostCenterSearch)
        {
            List<CostCenter> costCenter = new List<CostCenter>();
            MasterDataRequestDTO masterDataRequest = new MasterDataRequestDTO();
            masterDataRequest.MasterType = MasterType;
            masterDataRequest.CompanyCode = (CompanyCode == "null" || CompanyCode== "undefined" || CompanyCode == "0" || CompanyCode == null) ? "" : CompanyCode;
            masterDataRequest.RowsOfPage = RowsOfPage;
            masterDataRequest.PageNumber = pageNumber;
            masterDataRequest.CostCenterSearch = (CostCenterSearch == "null" || CostCenterSearch == "undefined" || CostCenterSearch == "0" || CostCenterSearch == null ? "" : CostCenterSearch);
            var CostCenter = _masterBl.GetMasterData_V1(masterDataRequest);
            return Json(CostCenter);
        }

        public JsonResult GetCompanyMaster()
        {
            //List<CompanyMaster> companyMaster = new List<CompanyMaster>();
            MasterDataRequestDTO masterDataRequest = new MasterDataRequestDTO();
            masterDataRequest.MasterType = "CompanyMaster";
            masterDataRequest.RowsOfPage = 20;
            masterDataRequest.PageNumber = 1;

            var CompanyMaster = _masterBl.GetMasterData_V1(masterDataRequest);  
            
            return Json(CompanyMaster);
        }

        [HttpPost]
        public FileResult ExportMaster(int RowsOfPage, int pageNumber, string MasterType, string CompanyCode, string CostCenterSearch)
        {
            string FileName = MasterType +"-" + DateTime.Now.Date;
            MasterDataRequestDTO masterDataRequest = new MasterDataRequestDTO();
            masterDataRequest.MasterType = MasterType;
            masterDataRequest.CompanyCode = (CompanyCode == "null" || CompanyCode == "undefined" || CompanyCode == "0") ? "" : CompanyCode;
            masterDataRequest.RowsOfPage = RowsOfPage;
            masterDataRequest.PageNumber = pageNumber;
            masterDataRequest.CostCenterSearch = (CostCenterSearch == "null" || CostCenterSearch == "undefined" || CostCenterSearch == "0" || CostCenterSearch == null ? "" : CostCenterSearch); 
            var CostCenter = _masterBl.GetMasterData_V1(masterDataRequest);


            DataTable dt = new DataTable("Grid");
            dt.Columns.AddRange(new DataColumn[10] {
                                            new DataColumn("SrNo"),
                                            new DataColumn("CostCentreCode"),
                                            new DataColumn("Name"),
                                            new DataColumn("Companycode"),
                                            new DataColumn("EmployeeId"),
                                            new DataColumn("EmployeeName"),
                                            new DataColumn("AddedOnDate"),
                                            new DataColumn("InsertedBy"),
                                            new DataColumn("ModifiedBy"),
                                            new DataColumn("ModifiedON"),

            });



            if (CostCenter.costCenter.Count > 0)
            {
                int i = 1;
                foreach (var cost in CostCenter.costCenter)
                {
                    dt.Rows.Add(i, cost.ValueField, cost.DisplayField,cost.Companycode,cost.EmployeeId,cost.EmployeeName,cost.AddedOnDate, cost.InsertedBy,cost.ModifiedBy,cost.ModifiedOn);
                    i++;
                }
            }
            else
            {
                dt.Rows.Add("No records to display");
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "" + FileName + ".xlsx");
                }
            }
        }

        public IActionResult ApplicationConfig()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Application Config";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
               
            }
            else
            {

                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult ForexRate()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Forex Rate";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {

            }
            else
            {

                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        [HttpPost]
        public JsonResult ApplicationConfigSetting(ApplicationConfigDTORequest applicationConfigDTORequest)
        {

            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }

            
            applicationConfigDTORequest.InsertdBy = loggedInUser.EmployeeId;
            applicationConfigDTORequest.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            var applicationConfig = _masterBl.ApplicationConfigSetting(applicationConfigDTORequest);
            if (applicationConfig.responseCode == 1)
            {
               
                try
                {
                    //InsertAdminActivityLog(loggedInUser.EmployeeId, "Updated", "APPLICATIONCONFIG", "");
                }

                catch (Exception)
                {


                }
            }

            return Json(applicationConfig);
        }

        [HttpPost]
        public JsonResult InsertCostCenterConfig(CostConfigInsertRequestDTO insertRequestDTO)
        {
            var approverStatus = _masterBl.InsertCostCenterConfig(insertRequestDTO);
            if (approverStatus.responseCode == 1)
            {
                var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
                try
                {
                    List<AuditProperties> auditProperties = new List<AuditProperties>();
                    AuditProperties auditProperties1 = new AuditProperties();
                    auditProperties1.PropertyName = "CostCenter";
                    auditProperties1.PropertyValue = insertRequestDTO.CostCenterCode;
                    auditProperties.Add(auditProperties1);

                    AuditProperties auditProperties2 = new AuditProperties();
                    auditProperties2.PropertyName = "EMPID";
                    auditProperties2.PropertyValue = insertRequestDTO.RoleEmpCode;
                    auditProperties.Add(auditProperties2);

                    var serialized = JsonConvert.SerializeObject(auditProperties);

                    //MyModuleName module = MyModuleName.High;

                    InsertAdminActivityLog(loggedInUser.EmployeeId, "Created","CostCenter Config", "", serialized);
                }

                catch (Exception)
                {


                }
            }
            return Json(approverStatus);
        }

        [HttpPost]
        public JsonResult GetCostCenterConfig(CostConfigGetRequestDTO CostCenterRequestDTO)
        {
            var CompanyMaster = _masterBl.GetCostCenterConfig(CostCenterRequestDTO);
            return Json(CompanyMaster);
        }

        [HttpPost]
        public JsonResult DeleteCostCenterRoleConfig(CostConfigGetRequestDTO CostCenterRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            var myRightObject = HttpContext.Session.GetObjectFromJson<List<UserRight>>("UserRight");
            var EmpID = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            var readOnlyAccess = false;
            if (myRightObject != null)
            {
                var readOnly = myRightObject.Where(x => x.UserRightCode == "R003").FirstOrDefault();
                if (readOnly != null)
                {
                    readOnlyAccess = true;
                    response.responseCode = 2;
                    response.responseMessage = "You cannot make any action as you have read only access!";
                    return Json(response);

                }
            }

            CostCenterRequestDTO.DeletedBy = EmpID.EmployeeId;
            var CompanyMaster = _masterBl.DeleteCostCenterRoleConfig(CostCenterRequestDTO);
            if (CompanyMaster.responseCode==1)
            {
                var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
                try
                {
                    List<AuditProperties> auditProperties = new List<AuditProperties>();
                    AuditProperties auditProperties1 = new AuditProperties();
                    auditProperties1.PropertyName = "CostCenter";
                    auditProperties1.PropertyValue = CostCenterRequestDTO.CostCenterCode;
                    auditProperties.Add(auditProperties1);

                    AuditProperties auditProperties2 = new AuditProperties();
                    auditProperties2.PropertyName = "EMPID";
                    auditProperties2.PropertyValue = CostCenterRequestDTO.RoleEmpCode;
                    auditProperties.Add(auditProperties2);

                    var serialized = JsonConvert.SerializeObject(auditProperties);

                    InsertAdminActivityLog(loggedInUser.EmployeeId, "Delete", "CostCenter Config", "", serialized);
                }

                catch (Exception)
                {


                }
            }
            return Json(CompanyMaster);
        }

        [HttpPost]
        public JsonResult AddUser(AddUserRequestDTO addUserRequestDTO)
        {
            
            var addUser = _UserManagementBL.AddUser(addUserRequestDTO);
            if (addUser.responseCode==1)
            {
                var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

                
                try
                {
                    string userAction = "";
                    string subject = "";
                    var serialized = "";
                    List<AuditProperties> auditProperties = new List<AuditProperties>();

                    if (addUserRequestDTO.Action== "ADDUSER")
                    {
                        userAction = "Add User";
                        AuditProperties auditProperties1 = new AuditProperties();
                        auditProperties1.PropertyName = "Employee";
                        auditProperties1.PropertyValue = (addUserRequestDTO.UserName);
                        auditProperties.Add(auditProperties1);

                    }
                    if (addUserRequestDTO.Action == "ASSIGNCOMPANY")
                    {
                        userAction = "Assign Company";

                        AuditProperties auditProperties1 = new AuditProperties();
                        auditProperties1.PropertyName = "Employee";
                        auditProperties1.PropertyValue = (addUserRequestDTO.UserName);
                        auditProperties.Add(auditProperties1);

                        AuditProperties auditProperties2 = new AuditProperties();
                        auditProperties2.PropertyName = "CompanyCode";
                        auditProperties2.PropertyValue = (addUserRequestDTO.Companies);
                        auditProperties.Add(auditProperties2);
                    }
                    if (addUserRequestDTO.Action == "ASSIGNRIGHT")
                    {
                        userAction = "Assign Right";

                        AuditProperties auditProperties1 = new AuditProperties();
                        auditProperties1.PropertyName = "Employee";
                        auditProperties1.PropertyValue = (addUserRequestDTO.UserName);
                        auditProperties.Add(auditProperties1);

                        AuditProperties auditProperties2 = new AuditProperties();
                        auditProperties2.PropertyName = "RightCode";
                        auditProperties2.PropertyValue = (addUserRequestDTO.Companies);
                        auditProperties.Add(auditProperties2);
                    }

                    subject = "User Management";

                    


                    serialized = JsonConvert.SerializeObject(auditProperties);

                    InsertAdminActivityLog(loggedInUser.EmployeeId, userAction, subject, "", serialized);
                }

                catch (Exception)
                {

                    
                }
                
            }
            
            return Json(addUser);
        }

        [HttpPost]
        public JsonResult AddDelegator(AddDelegatorRequestDTO addDelegatorRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }
            addDelegatorRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            addDelegatorRequestDTO.IPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            var addDelegator = _UserManagementBL.AddDelegator(addDelegatorRequestDTO);
            if (addDelegator.responseCode == 1)
            {
                try
                {
                   
                    string subject = "";
                    var serialized = "";

                    subject = "User Management";

                   
                    List<AuditProperties> auditProperties = new List<AuditProperties>();
                    AuditProperties auditProperties1 = new AuditProperties();
                    auditProperties1.PropertyName = "Delegator";
                    auditProperties1.PropertyValue = (addDelegatorRequestDTO.DelgatorEMPCode);
                    auditProperties.Add(auditProperties1);

                    AuditProperties auditProperties2 = new AuditProperties();
                    auditProperties2.PropertyName = "Delegatee";
                    auditProperties2.PropertyValue = (addDelegatorRequestDTO.DelegateeEMPCode);
                    auditProperties.Add(auditProperties2);

                    AuditProperties auditProperties3 = new AuditProperties();
                    auditProperties3.PropertyName = "StartDate";
                    auditProperties3.PropertyValue = (addDelegatorRequestDTO.StartDate.ToString("dd-MMM-yyyy"));
                    auditProperties.Add(auditProperties3);

                    AuditProperties auditProperties4 = new AuditProperties();
                    auditProperties4.PropertyName = "EndDate";
                    auditProperties4.PropertyValue = (addDelegatorRequestDTO.EndDate.ToString("dd-MMM-yyyy"));
                    auditProperties.Add(auditProperties4);

                    AuditProperties auditProperties5 = new AuditProperties();
                    auditProperties5.PropertyName = "Reason";
                    auditProperties5.PropertyValue = (addDelegatorRequestDTO.DelegationReason);
                    auditProperties.Add(auditProperties5);

                    serialized = JsonConvert.SerializeObject(auditProperties);
                    InsertAdminActivityLog(loggedInUser.EmployeeId, "Assign Delegator", subject, "", serialized);



                    //string activityLog = string.Empty;
                    //activityLog = JsonConvert.SerializeObject(addDelegatorRequestDTO);
                    // InsertAdminActivityLog(loggedInUser.EmployeeId, "Created", "ASSIGNDELEGATOR", activityLog);
                }
                catch (Exception)
                {

                   
                }
                
            }

            return Json(addDelegator);
        }


        [HttpPost]
        public JsonResult GetDelegationDetails(string EmployeeId)
        {
            var CompanyMaster = _UserManagementBL.GetDelegationDetails(EmployeeId);
            return Json(CompanyMaster);
        }

        [HttpPost]
        public JsonResult MaterialImageManage(MaterialImagaeManageDTO materialImagaeManageDTO)
        {
            var response = _masterBl.MaterialImageManage(materialImagaeManageDTO);
            return Json(response);
        }

        [HttpPost]
        public JsonResult Upload_File()
        {

            string result = string.Empty;
            string materialCode = string.Empty;
            string imageType = string.Empty;

            if (Request.Form.Keys.Count > 0)
            {
                foreach (var item in Request.Form.Keys)
                {
                    if (item.StartsWith("materialCode"))
                    {
                        materialCode = Convert.ToString(Request.Form[item]);
                        
                    }

                    if (item.StartsWith("imageType"))
                    {
                        imageType = Convert.ToString(Request.Form[item]);

                    }
                }
            }

            try

            {

                

                var file = Request.Form.Files;

                if (file.Count > 0)
                {
                    foreach (var item in file)
                    {
                        var filename = ContentDispositionHeaderValue

                                .Parse(item.ContentDisposition).FileName.Trim('"');

                        filename = filename.ToString().Replace(" ", "_");
                        string saveFileName = (DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + "-" + filename);
                        var filesize = item.Length;


                        System.IO.Stream fs = item.OpenReadStream();
                        System.IO.BinaryReader br = new System.IO.BinaryReader(fs);
                        Byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
                        base64String = "data:" + item.ContentType + ";base64," + base64String;

                        var path = "";
                        
                        path = Path.Combine(Directory.GetCurrentDirectory(),"wwwroot","assets", "MaterialImage", saveFileName);
                        try
                        {
                            using (var stream = System.IO.File.Create(path))
                            {
                                item.CopyTo(stream);

                                MaterialImagaeManageDTO materialImagaeManageDTO = new MaterialImagaeManageDTO();

                                materialImagaeManageDTO.Action = "UPDATE";
                                materialImagaeManageDTO.MatCode = materialCode;
                                materialImagaeManageDTO.MatImage = saveFileName;
                                materialImagaeManageDTO.Type =imageType;
                                var response = _masterBl.MaterialImageManage(materialImagaeManageDTO);

                                if (response.responseCode == 1)
                                {
                                    try
                                    {
                                        var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
                                        string activityLog = string.Empty;
                                        activityLog = JsonConvert.SerializeObject(materialImagaeManageDTO);
                                      //  InsertAdminActivityLog(loggedInUser.EmployeeId, "Updated", "MATERIALIMAGE", activityLog);
                                    }
                                    catch (Exception)
                                    {


                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {

                            result =path + "/" + ex.Message;
                            return Json(result);
                        }
                        





                    }
                }

               
                result = "SUCCESS";

            }

            catch (Exception ex)

            {

                result = ex.Message;

            }



            return Json(result);

        }

        public void InsertAdminActivityLog(string ActionEmployeeID, string ActivityAction, string ActivitySubject, string OldValue,string NewValue)
        {
            AdminActivityLogInsertDTO adminActivityLogInsertDTO = new AdminActivityLogInsertDTO();
            adminActivityLogInsertDTO.ActionEmployeeID = ActionEmployeeID;
            adminActivityLogInsertDTO.ActivityAction = ActivityAction;
            adminActivityLogInsertDTO.ActivityLog = string.Empty;
            adminActivityLogInsertDTO.ActivitySubject = ActivitySubject;
            adminActivityLogInsertDTO.OldValue = OldValue;
            adminActivityLogInsertDTO.NewValue = NewValue;
            var response=_auditBL.InsertAdminActivityLog(adminActivityLogInsertDTO);
        }

        public IActionResult MenuMaster()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Menu Master";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {

            }
            else
            {

                return Redirect("~/Auth/Index");
            }

            return View();
        }

        [HttpPost]
        public JsonResult GetMenuMaster(string SerachParm, int RowsOfPage , int pageNumber)
        {
            MenuMasterDetailsRequestDTO masterDetailsRequestDTO = new MenuMasterDetailsRequestDTO();
            masterDetailsRequestDTO.Action = "Manage";
            masterDetailsRequestDTO.SerachParm = SerachParm;
            masterDetailsRequestDTO.RowsOfPage = RowsOfPage;
            masterDetailsRequestDTO.PageNumber = pageNumber;
            var menuMaster = _masterBl.GetMenuMaster(masterDetailsRequestDTO);
            return Json(menuMaster);
        }


        [HttpPost]
        public JsonResult GetParentMenuMaster()
        {
            var menuMaster = _masterBl.GetParentMenuMaster();
            return Json(menuMaster);
        }

        [HttpPost]
        public JsonResult InsertMenuMaster(MenuMasterDetailsInsertDTO masterDetailsInsertDTO)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            masterDetailsInsertDTO.LoggedInEmpId = loggedInUser.UserId;
            var menuMaster = _masterBl.InsertMenuMaster(masterDetailsInsertDTO);
            if (menuMaster.responseCode == 1)
            {
                try
                {
                   // InsertAdminActivityLog(loggedInUser.EmployeeId, "Created", "MENUMASTERCONFIG", "");
                }
                catch (Exception)
                {
                }
            }
            return Json(menuMaster);
        }

        [HttpPost]
        public JsonResult DeleteMenuMaster(int MenuId)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            var menuMaster = _masterBl.DeleteMenuMaster(MenuId , loggedInUser.UserId);
            if (menuMaster.responseCode == 1)
            {
                try
                {
                    //InsertAdminActivityLog(loggedInUser.EmployeeId, "Delete", "COSTCENTERCONFIG", "");
                }

                catch (Exception)
                {
                }
            }
            return Json(menuMaster);
        }

        [HttpPost]
        public JsonResult GetUserTypeMaster()
        {
            var menuMaster = _masterBl.GetUserTypeMaster();
            return Json(menuMaster);
        }

        [HttpPost]
        public JsonResult GetMenuMasterType(string UserType)
        {
            var menuMaster = _masterBl.GetMenuMasterType(UserType);
            return Json(menuMaster);
        }

        public IActionResult MenuUserMapping()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Menu User Mapping";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {

            }
            else
            {

                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        [HttpPost]
        public JsonResult GetMenuUserMapping(string SerachParm, int RowsOfPage, int pageNumber, string UserType)
        {
            MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO = new MenuUserMappingDetailsRequestDTO();
            userMappingDetailsRequestDTO.Action = "Manage";
            userMappingDetailsRequestDTO.SerachParm = SerachParm;
            userMappingDetailsRequestDTO.RowsOfPage = RowsOfPage;
            userMappingDetailsRequestDTO.PageNumber = pageNumber;
            userMappingDetailsRequestDTO.UserType = UserType;
            var menuMaster = _masterBl.GetMenuUserMapping(userMappingDetailsRequestDTO);
            return Json(menuMaster);
        }

        [HttpPost]
        public JsonResult InsertMenuUserMapping(MenuUserMappingInsertDTO userMappingInsertDTO)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            var menuUserMaster = _masterBl.InsertMenuUserMapping(userMappingInsertDTO);
            if (menuUserMaster.responseCode == 1)
            {
                try
                {
                    //InsertAdminActivityLog(loggedInUser.EmployeeId, "Created", "MENUUSERMASTERCONFIG", "","");
                }
                catch (Exception)
                {
                }
            }
            return Json(menuUserMaster);
        }

        [HttpPost]
        public JsonResult DeleteUserMenuMapping(int MenuId)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            var menuMaster = _masterBl.DeleteUserMenuMapping(MenuId);
            if (menuMaster.responseCode == 1)
            {
                try
                {
                    //InsertAdminActivityLog(loggedInUser.EmployeeId, "Delete", "COSTCENTERCONFIG", "");
                }

                catch (Exception)
                {
                }
            }
            return Json(menuMaster);
        }

        [HttpPost]
        public JsonResult SupplierEmployeeAssign(SupplierEmployeeMappingRequestDTO supplierEmployeeMappingRequestDTO)
        {
            ResponseClass responseClass = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser==null)
            {
                responseClass.responseCode = 2;
                responseClass.responseMessage = "Session not exist!";
            }
            else
            {
                
                supplierEmployeeMappingRequestDTO.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
                supplierEmployeeMappingRequestDTO.InsertedBy = loggedInUser.EmployeeId;
                
                responseClass = _UserManagementBL.SupplierEmployeeAssign(supplierEmployeeMappingRequestDTO);
            }
            return Json(responseClass);
        }


        #region Catalogue Management

        public IActionResult CatalogueManagement()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Catalogue Management";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult UploadCatalogue()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Upload Catalogue";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            //var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            //bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            //if (returnValue == false)
            //{
            //    return Redirect("~/Auth/UnAuthorizedPage");
            //}
            return View();
        }

        [HttpPost]
        public JsonResult UploadCatalogueData()
        {
            ResponseClass response = new ResponseClass();
            string companyCode = string.Empty;
            if (Request.Form.Keys.Count > 0)
            {
                foreach (var item in Request.Form.Keys)
                {
                    if (item.StartsWith("companyCode"))
                    {
                        companyCode = Convert.ToString(Request.Form[item]);
                        
                    }
                }
            }
            else
            {
                response.responseCode = 0;
                response.responseMessage = "Company code required!";
                return Json(response);
            }

            if (string.IsNullOrEmpty(companyCode))
            {
                response.responseCode = 0;
                response.responseMessage = "Company code required!";
                return Json(response);
            }
            //string result = string.Empty;
            string ColumnName = "SupplierCode,SupplierPartID,ItemDescription,MaterialCode,UnitPrice,UOM,Currency,ShortName,PlantCode,Image";
            //List<SlotManagementDTO> slotManagements = new List<SlotManagementDTO>();
            DataTable dt = new DataTable();
            DataTable dtNew = new DataTable();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            #region fetch Company Supplier

            List<MasterDataResponse> lstSupplierCode = new List<MasterDataResponse>();
            MasterDataRequest masterDataRequestReq = new MasterDataRequest();

            if (loggedInUser == null)
            {
                response.responseCode = 2;
                response.responseMessage = "Session not exist!";
                return Json(response);
            }

            masterDataRequestReq.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequestReq.CompanyCode = companyCode;
            masterDataRequestReq.EntityName = "CompanySupplier";
            var Req = _masterBl.GetCommonEntity(masterDataRequestReq);
            if (Req.responseCode == 1)
            {
                lstSupplierCode = Req.masterDataResponses;
            }

            #endregion

            #region fetch Material Code

            List<MasterDataResponse> lstMaterialCode = new List<MasterDataResponse>();
            MasterDataRequest masterDataRequest = new MasterDataRequest();
            masterDataRequest.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequest.CompanyCode = companyCode;
            masterDataRequest.EntityName = "CompanyMaterialCode";
            var model = _masterBl.GetCommonEntity(masterDataRequest);
            if (model.responseCode == 1)
            {
                lstMaterialCode = model.masterDataResponses;
            }
            #endregion
            #region fetch Plant Code

            List<MasterDataResponse> lstPlantCode = new List<MasterDataResponse>();
            MasterDataRequest masterDataRequestPlantcode = new MasterDataRequest();
            masterDataRequestPlantcode.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequestPlantcode.CompanyCode = companyCode;
            masterDataRequestPlantcode.EntityName = "CompanyPlantCode";
            var modelPlantCode = _masterBl.GetCommonEntity(masterDataRequestPlantcode);
            if (modelPlantCode.responseCode == 1)
            {
                lstPlantCode = modelPlantCode.masterDataResponses;
            }

            #endregion

            #region fetch Currency

            List<MasterDataResponse> lstCurrency = new List<MasterDataResponse>();
            MasterDataRequest masterDataRequestCurrency = new MasterDataRequest();
            masterDataRequestCurrency.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequestCurrency.CompanyCode = companyCode;
            masterDataRequestCurrency.EntityName = "CatalogueCurrency";
            var modelCurrency = _masterBl.GetCommonEntity(masterDataRequestCurrency);
            if (modelPlantCode.responseCode == 1)
            {
                lstCurrency = modelCurrency.masterDataResponses;
            }

            #endregion

            try

            {

                long size = 0;

                var file = Request.Form.Files;

                if (file.Count > 0)
                {
                    foreach (var item in file)
                    {
                        var filename = ContentDispositionHeaderValue

                                .Parse(item.ContentDisposition).FileName.Trim('"');

                        System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                        System.IO.Stream stream = item.OpenReadStream();
                        if (stream.Length != 0)
                        {
                            using (var reader = ExcelReaderFactory.CreateReader(stream))
                            {
                                DataSet ds = reader.AsDataSet();
                                //DataTable dt = new DataTable();
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    bool firstRow = true;
                                    int RowCount = 1;
                                    foreach (DataRow dr in ds.Tables[0].Rows)
                                    {
                                        if (firstRow)
                                        {
                                            foreach (var row in dr.ItemArray)
                                            {
                                                dt.Columns.Add(row.ToString());
                                            }

                                            firstRow = false;

                                             #region Check columns

                                            if (dt.Columns.Count == 0 || dt.Columns.Count != 10)
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet should have these columns :" + ColumnName;
                                                return Json(response);
                                            }
                                            //SupplierID,SupplierPartID,ItemDescription,SPSCCode,UnitPrice,UOM,Currency,ShortName,PlantCode
                                            if (dt.Columns[0].ColumnName != "SupplierCode")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet First Column Name should be SupplierCode";
                                                return Json(response);
                                            }
                                            if (dt.Columns[1].ColumnName != "SupplierPartID")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Second Column Name should be SupplierPartID";
                                                return Json(response);
                                            }
                                            if (dt.Columns[2].ColumnName != "ItemDescription")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Third Column Name should be ItemDescription";
                                                return Json(response);
                                            }
                                            if (dt.Columns[3].ColumnName != "MaterialCode")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Fourth Column Name should be MaterialCode";
                                                return Json(response);
                                            }
                                            if (dt.Columns[4].ColumnName != "UnitPrice")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Fifth Column Name should be UnitPrice";
                                                return Json(response);
                                            }
                                            if (dt.Columns[5].ColumnName != "UOM")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Sixth Column Name should be UOM";
                                                return Json(response);
                                            }
                                            if (dt.Columns[6].ColumnName != "Currency")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Seventh Column Name should be Currency";
                                                return Json(response);
                                            }
                                            if (dt.Columns[7].ColumnName != "ShortName")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Eight Column Name should be ShortName";
                                                return Json(response);
                                            }
                                            if (dt.Columns[8].ColumnName != "PlantCode")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Ninth Column Name should be PlantCode";
                                                return Json(response);
                                            }
                                            if (dt.Columns[9].ColumnName != "Image")
                                            {
                                                response.responseCode = 0;
                                                response.responseMessage = "Sheet Ninth Column Name should be Image";
                                                return Json(response);
                                            }
                                            dt.Columns.Add("LineNo");

                                            #endregion

                                        }
                                        else
                                        {
                                            DataRow dataRow = dt.NewRow();
                                            int i = 0;
                                            //dataRow = dr;
                                            foreach (DataColumn dc in dt.Columns)
                                            {
                                                if (dc.ColumnName != "LineNo")
                                                {
                                                    dataRow[dc.ColumnName] = dr[i];
                                                    i = i + 1;
                                                }


                                            }
                                            dataRow["LineNo"] = RowCount;
                                            dt.Rows.Add(dataRow);
                                            RowCount = RowCount + 1;
                                        }


                                    }

                                    if (dt.Rows.Count == 0)
                                    {
                                        response.responseCode = 0;
                                        response.responseMessage = "Please add some data!";
                                        return Json(response);
                                    }
                                    //else if (dt.Rows.Count > 80)
                                    //{
                                    //    response.responseCode = 0;
                                    //    response.responseMessage = "Please add 80 lines item at one time!";
                                    //    return Json(response);
                                    //}
                                }
                            }
                        }
                        else
                        {
                            response.responseCode = 0;
                            response.responseMessage = "Please add some data!";
                            return Json(response);

                        }

                    }

                    int validation = 1;
                    List<CheckSupplierPartID> checkSupplierPartIDs = new List<CheckSupplierPartID>();
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        dt.Columns.Add("Error");
                        // Validation for Data
                        int i = 1;
                        foreach (DataRow item in dt.Rows)
                        {
                             #region File Data Validation


                            if (string.IsNullOrEmpty(Convert.ToString(item["SupplierCode"])))
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                {
                                    item["Error"] = "Supplier Code cannot be empty!<br>";
                                    validation = 0;
                                }
                                else
                                {
                                    item["Error"] = Convert.ToString(item["Error"]) + "Supplier Code cannot be empty!<br>";
                                    validation = 0;
                                }

                            }
                            else
                            {
                                var validSupplierCode = lstSupplierCode.Where(x => x.ValueField.ToLower() == item["SupplierCode"].ToString().ToLower()).FirstOrDefault();
                                if (validSupplierCode == null)
                                {
                                    if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                    {
                                        item["Error"] = "Invalid Supplier Code!<br>";
                                        validation = 0;
                                    }
                                    else
                                    {
                                        item["Error"] = Convert.ToString(item["Error"]) + "Invalid Supplier Code!<br>";
                                        validation = 0;
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Convert.ToString(item["SupplierPartID"])) || Convert.ToString(item["SupplierPartID"]).Length > 40)
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                {
                                    item["Error"] = "SupplierPartID cannot be empty and with 40 character maximum!<br>";
                                    validation = 0;
                                }
                                else
                                {
                                    item["Error"] = Convert.ToString(item["Error"]) + "SupplierPartID cannot be empty and with 40 character maximum!<br>";
                                    validation = 0;
                                }

                                

                            }
                            else
                            {
                                if (i > 1)
                                {
                                    var checkPArt = checkSupplierPartIDs.Where(x => x.SupplierPartID.ToLower() == Convert.ToString(item["SupplierPartID"]).ToLower()).FirstOrDefault();
                                    if (checkPArt != null && !string.IsNullOrEmpty(checkPArt.SupplierPartID))
                                    {
                                        if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                        {
                                            item["Error"] = "Duplicate SupplierPartID!<br>";
                                            validation = 0;
                                        }
                                        else
                                        {
                                            item["Error"] = Convert.ToString(item["Error"]) + "Duplicate SupplierPartID!<br>";
                                            validation = 0;
                                        }
                                    }
                                }

                                checkSupplierPartIDs.Add(new CheckSupplierPartID { SupplierPartID = Convert.ToString(item["SupplierPartID"]) });
                            }

                            if (string.IsNullOrEmpty(Convert.ToString(item["ItemDescription"])) || Convert.ToString(item["ItemDescription"]).Length > 2000)
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                {
                                    item["Error"] = "ItemDescription cannot be empty and with 2000 character maximum!<br>";
                                    validation = 0;
                                }
                                else
                                {
                                    item["Error"] = Convert.ToString(item["Error"]) + "ItemDescription cannot be empty and with 2000 character maximum!<br>";
                                    validation = 0;
                                }


                            }

                            if (string.IsNullOrEmpty(Convert.ToString(item["MaterialCode"])))
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                {
                                    item["Error"] = "Material Code cannot be empty!<br>";
                                    validation = 0;
                                }
                                else
                                {
                                    item["Error"] = Convert.ToString(item["Error"]) + "Material Code cannot be empty!<br>";
                                    validation = 0;
                                }

                            }
                            else
                            {
                                var validMaterialCode = lstMaterialCode.Where(x => x.ValueField.ToLower() == item["MaterialCode"].ToString().ToLower()).FirstOrDefault();
                                if (validMaterialCode == null)
                                {
                                    if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                    {
                                        item["Error"] = "Invalid Material Code!<br>";
                                        validation = 0;
                                    }
                                    else
                                    {
                                        item["Error"] = Convert.ToString(item["Error"]) + "Invalid Material Code!<br>";
                                        validation = 0;
                                    }
                                }
                            }

                            if (string.IsNullOrEmpty(Convert.ToString(item["UnitPrice"])))
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                {
                                    item["Error"] = "UnitPrice cannot be empty!<br>";
                                    validation = 0;
                                }
                                else
                                {
                                    item["Error"] = Convert.ToString(item["Error"]) + "UnitPrice cannot be empty!<br>";
                                    validation = 0;
                                }


                            }
                            else
                            {
                                try
                                {
                                    double totalSeat = Convert.ToDouble(item["UnitPrice"]);

                                    if (totalSeat == 0 || totalSeat<0)
                                    {
                                        item["Error"] = Convert.ToString(item["Error"]) + "UnitPrice cannot be zero or less than zero!<br>";
                                        validation = 0;
                                    }
                                }
                                catch
                                {

                                    item["Error"] = Convert.ToString(item["Error"]) + "UnitPrice format is invalid!<br>";
                                    validation = 0;
                                }
                            }
                            if (string.IsNullOrEmpty(Convert.ToString(item["UOM"])) || Convert.ToString(item["UOM"]).Length > 6)
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                {
                                    item["Error"] = "UOM cannot be empty and with 6 character maximum!<br>";
                                    validation = 0;
                                }
                                else
                                {
                                    item["Error"] = Convert.ToString(item["Error"]) + "UOM cannot be empty and with 6 character maximum!<br>";
                                    validation = 0;
                                }
                            }
                            if (string.IsNullOrEmpty(Convert.ToString(item["Currency"])))
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                {
                                    item["Error"] = "Currency cannot be empty!<br>";
                                    validation = 0;
                                }
                                else
                                {
                                    item["Error"] = Convert.ToString(item["Error"]) + "Currency cannot be empty!<br>";
                                    validation = 0;
                                }
                            }
                            else
                            {
                                var validCurrency = lstCurrency.Where(x => x.ValueField.ToLower() == item["Currency"].ToString().ToLower()).FirstOrDefault();
                                if (validCurrency == null)
                                {
                                    if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                    {
                                        item["Error"] = "Invalid Currency!<br>";
                                        validation = 0;
                                    }
                                    else
                                    {
                                        item["Error"] = Convert.ToString(item["Error"]) + "Invalid Currency!<br>";
                                        validation = 0;
                                    }
                                }
                            }
                            if (string.IsNullOrEmpty(Convert.ToString(item["ShortName"])) || Convert.ToString(item["ShortName"]).Length>200)
                            {
                                if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                {
                                    item["Error"] = "ShortName cannot be empty and with 200 characters maximum!<br>";
                                    validation = 0;
                                }
                                else
                                {
                                    item["Error"] = Convert.ToString(item["Error"]) + "ShortName cannot be empty and with 200 characters maximum!<br>";
                                    validation = 0;
                                }
                            }
                            if (!string.IsNullOrEmpty(Convert.ToString(item["PlantCode"])))
                            {
                                var validPlantCode = lstPlantCode.Where(x => x.ValueField.ToLower() == item["PlantCode"].ToString().ToLower()).FirstOrDefault();
                                if (validPlantCode == null)
                                {
                                    if (string.IsNullOrEmpty(Convert.ToString(item["Error"])))
                                    {
                                        item["Error"] = "Invalid Plant Code!<br>";
                                        validation = 0;
                                    }
                                    else
                                    {
                                        item["Error"] = Convert.ToString(item["Error"]) + "Invalid Plant Code!<br>";
                                        validation = 0;
                                    }
                                }

                            }
                            else
                            {
                                
                            }

                            

                            i = i + 1;
                             #endregion
                        }

                    }


                    if (validation == 0)
                    {
                        response.responseCode = 3;
                        response.responseMessage = "There is some issue in file data.Please check error column description!";
                    }
                    else if (validation == 1)
                    {

                        response.responseCode = 1;
                        foreach (DataRow dr in dt.Rows)
                        {
                            dr["Error"] = "SUCCESS";
                        }
                        response.responseMessage = "SUCCESS";
                    }

                    //var duplicates = dt.AsEnumerable()
                    //.GroupBy(r => r[1])//Using Column Index
                    //.Where(gr => gr.Count() > 1)
                    //.Select(g => g.Key);

                    //DataTable tbNew = (DataTable)duplicates;

                    //if (tbNew!=null && tbNew.Rows.Count>0)
                    //{
                    //    response.responseCode = 3;
                    //    response.responseMessage = "There is some issue in file data.Supplier part id cannot be duplicate!";
                    //}

                    response.responseJSON = JsonConvert.SerializeObject(dt);



                }
            }

            catch (Exception ex)

            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;

            }



            return Json(response);

        }

        [HttpPost]
        public JsonResult UploadData(string CompanyCode,List<CatalogueDataUploadRequestLines> catalogueDataUploadRequestLines)
        {
            ResponseClass response = new ResponseClass();
            CatalogueDataUploadRequestDTO catalogue = new CatalogueDataUploadRequestDTO();
            if (catalogueDataUploadRequestLines == null || catalogueDataUploadRequestLines.Count == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "catalogueDataUploadRequestLines required";
                return Json(response);
            }
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                response.responseCode = 2;
                response.responseMessage = "Session not exist!";
                return Json(response);
            }

            catalogue.catalogueDataUploadRequestLines = catalogueDataUploadRequestLines;
            catalogue.InsertedBy = loggedInUser.EmployeeId;
            catalogue.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            catalogue.CompanyCode = CompanyCode;
            response = _catalogueManagementBL.UploadCatalogue(catalogue);
            return Json(response);
        }

        [HttpPost]
        public JsonResult GetAdvancedSearchData(MasterDataRequest masterDataRequest)
        {

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                ResponseClass response = new ResponseClass();
                response.responseCode = 2;
                return Json(response);
            }

            masterDataRequest.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequest.CompanyCode = loggedInUser.SAPCompanyCode;
            var model = _masterBl.GetCommonEntity(masterDataRequest);
            return Json(model);
        }

        [HttpPost]
        public JsonResult ManageCatalogue(CatalogueManagementSearchRequestDTO catalogueManagementSearchRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                response.responseCode = 2;
                response.responseMessage = "Session not exist!";
                return Json(response);
            }

            if (string.IsNullOrEmpty(catalogueManagementSearchRequestDTO.FromDate))
            {
                response.responseCode = 0;
                response.responseMessage = "catalogueManagementSearchRequestDTO.FromDate required";
                return Json(response);
            }

            if (string.IsNullOrEmpty(catalogueManagementSearchRequestDTO.ToDate))
            {
                response.responseCode = 0;
                response.responseMessage = "catalogueManagementSearchRequestDTO.ToDate required";
                return Json(response);
            }

            response = _catalogueManagementBL.ManageCatalogue(catalogueManagementSearchRequestDTO);
            return Json(response);
        }

        [HttpPost]
        public JsonResult UpdateCataloguePublishStatus(UpdatePublishStatusRequestDTO updatePublishStatusRequest)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                response.responseCode = 2;
                response.responseMessage = "Session not exist!";
                return Json(response);
            }

            if (updatePublishStatusRequest.updatePublishStatusRequestLines == null && updatePublishStatusRequest.updatePublishStatusRequestLines.Count == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePublishStatusRequest.updatePublishStatusRequestLines required";
                return Json(response);
            }
            updatePublishStatusRequest.InsertedBy = loggedInUser.EmployeeId;
            updatePublishStatusRequest.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            response = _catalogueManagementBL.UpdateCataloguePublishStatus(updatePublishStatusRequest);
            return Json(response);
        }

        [HttpPost]
        public JsonResult SearchCatalogueData(SearchCatalogueDataRequestDTO searchCatalogueDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<CatalogueDataListResponse> catalogueDataListResponses = new List<CatalogueDataListResponse>();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                response.responseCode = 2;
                response.responseMessage = "Session not exist!";
                return Json(response);
            }

            if (searchCatalogueDataRequestDTO.SearchType==0)
            {
                response.responseCode = 0;
                response.responseMessage = "searchCatalogueDataRequestDTO.SearchType required";
                return Json(response);
            }

            if (string.IsNullOrEmpty(searchCatalogueDataRequestDTO.SearchText))
            {
                response.responseCode = 0;
                response.responseMessage = "catalogueManagementSearchRequestDTO.SearchText required";
                return Json(response);
            }

            searchCatalogueDataRequestDTO.CompanyCode = loggedInUser.SAPCompanyCode;
            searchCatalogueDataRequestDTO.EmpCode = loggedInUser.EmployeeId;
            searchCatalogueDataRequestDTO.PageNumber = -1;
            searchCatalogueDataRequestDTO.RowsOfPage = 1;
            response = _catalogueManagementBL.SearchCatalogueData(searchCatalogueDataRequestDTO);
            if (response.responseCode==1)
            {
                if (!string.IsNullOrEmpty(response.responseJSON.ToString()))
                {
                    catalogueDataListResponses = JsonConvert.DeserializeObject<List<CatalogueDataListResponse>>(response.responseJSON.ToString());
                    if (catalogueDataListResponses!=null && catalogueDataListResponses.Count>0)
                    {
                        foreach (var item in catalogueDataListResponses)
                        {
                            item.PriceToShow = CurrencyConversion.FormatCurrency(item.Currency, item.UnitPrice);
                        }
                    }
                }
            }
            return Json(catalogueDataListResponses);
        }

        [HttpPost]
        public JsonResult RedirectToCatalogue(int catalogueDataID,double quantity)
        {
            HttpContext.Session.ClearSessionByName("catalogueredirectSession");
            ResponseClass response = new ResponseClass();
            if (catalogueDataID==0)
            {
                response.responseCode = 0;
                response.responseMessage = "catalogueDataID required!";
                return Json(response);
            }
            
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                response.responseCode = 2;
                response.responseMessage = "Session not exist!";
                return Json(response);
            }
            CatalogueDataListResponse catalogueDataListResponse = new CatalogueDataListResponse();
            SearchCatalogueDataRequestDTO searchCatalogueDataRequestDTO = new SearchCatalogueDataRequestDTO();
            searchCatalogueDataRequestDTO.PageNumber = -1;
            searchCatalogueDataRequestDTO.RowsOfPage = 1;
            searchCatalogueDataRequestDTO.SearchType = 3;
            searchCatalogueDataRequestDTO.SearchText = Convert.ToString(catalogueDataID);
            response = _catalogueManagementBL.SearchCatalogueData(searchCatalogueDataRequestDTO);
            if (response.responseCode == 1)
            {
                List<CatalogueDataListResponse> catalogueDataListResponses = new List<CatalogueDataListResponse>();
                if (!string.IsNullOrEmpty(response.responseJSON.ToString()))
                {
                    catalogueDataListResponses = JsonConvert.DeserializeObject<List<CatalogueDataListResponse>>(response.responseJSON.ToString());
                    if (catalogueDataListResponses != null && catalogueDataListResponses.Count > 0)
                    {
                        catalogueDataListResponse = catalogueDataListResponses[0];
                        var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");
                        if (MyCart != null && !string.IsNullOrEmpty(MyCart.VendorCode))
                        {
                            if (catalogueDataListResponse.VendorCode!= MyCart.VendorCode)
                            {
                                response.responseCode = 0;
                                response.responseMessage = "You can only add items of :" + MyCart.Vendor;
                                return Json(response);
                            }
                        }
                        if (MyCart != null && !string.IsNullOrEmpty(MyCart.Currency))
                        {
                            if (catalogueDataListResponse.Currency != MyCart.Currency)
                            {
                                response.responseCode = 0;
                                response.responseMessage = "You can only add items of :" + MyCart.Currency + " Currency!";
                                return Json(response);
                            }
                        }
                        catalogueDataListResponse.quantity = quantity;
                       
                        HttpContext.Session.SetObjectAsJson("catalogueredirectSession", catalogueDataListResponse);
                        response.responseCode = 1;
                        return Json(response);
                    }
                    else
                    {
                        response.responseCode = 0;
                        response.responseMessage = "There is some issue!";
                        return Json(response);
                    }
                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "There is some issue!";
                    return Json(response);
                }
            }
            else
            {
                response.responseCode = 0;
                response.responseMessage = "There is some issue!";
                return Json(response);
            }

            //return Json("");
        }

        [HttpPost]

        public FileResult ExportCatalogueData(string hdUploadCompany,
            string fromDate, string toDate, string hdtxtSupplier, string hdtxtMaterialCode,
            string hdddlPublishStatus)
        {
            string GridHtml = string.Empty;
            string FileName = "Catalogue Data -" + DateTime.Now.Date;
            CatalogueManagementSearchRequestDTO catalogueManagementSearchRequestDTO = new CatalogueManagementSearchRequestDTO();

            ResponseClass response = new ResponseClass();
            
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser==null)
            {
                //return File([], "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "" + FileName + ".xlsx");
            }

            DataTable dt = new DataTable("Grid");

            catalogueManagementSearchRequestDTO.PageNumber = -1;
            catalogueManagementSearchRequestDTO.RowsOfPage = 20;
            catalogueManagementSearchRequestDTO.FromDate = fromDate;
            catalogueManagementSearchRequestDTO.ToDate = toDate;
            catalogueManagementSearchRequestDTO.MaterialCode = hdtxtMaterialCode;
            catalogueManagementSearchRequestDTO.SupplierCode = hdtxtSupplier;
            catalogueManagementSearchRequestDTO.PublishStatus = Convert.ToInt32(hdddlPublishStatus);
            response = _catalogueManagementBL.ManageCatalogue(catalogueManagementSearchRequestDTO);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    dt = GetJSONToDataTableUsingMethod(response.responseJSON.ToString());

                   
                }

            }



            dt.TableName = "CatalogueData";

            if (dt != null && dt.Columns.Count>0)
            {
                dt.Columns.Remove("CatalogueDataID");
               
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "" + FileName + ".xlsx");
                }
            }

            //return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "" + FileName + ".xls");
        }

        public static DataTable GetJSONToDataTableUsingMethod(string JSONData)
        {
            DataTable dtUsingMethodReturn = new DataTable();
            string[] jsonStringArray = Regex.Split(JSONData.Replace("[", "").Replace("]", ""), "},{");
            List<string> ColumnsName = new List<string>();
            foreach (string strJSONarr in jsonStringArray)
            {
                string[] jsonStringData = Regex.Split(strJSONarr.Replace("{", "").Replace("}", ""), ",");
                foreach (string ColumnsNameData in jsonStringData)
                {
                    try
                    {
                        int idx = ColumnsNameData.IndexOf(":");
                        string ColumnsNameString = ColumnsNameData.Substring(0, idx).Replace("\"", "").Trim();
                        if (!ColumnsName.Contains(ColumnsNameString))
                        {
                            ColumnsName.Add(ColumnsNameString);
                        }
                    }
                    catch (Exception ex)
                    {
                        //throw new Exception(string.Format("Error Parsing Column Name : {0}", ColumnsNameData));
                    }
                }
                break;
            }
            foreach (string AddColumnName in ColumnsName)
            {
                dtUsingMethodReturn.Columns.Add(AddColumnName);
            }
            foreach (string strJSONarr in jsonStringArray)
            {
                string[] RowData = Regex.Split(strJSONarr.Replace("{", "").Replace("}", ""), ",");
                DataRow nr = dtUsingMethodReturn.NewRow();
                foreach (string rowData in RowData)
                {
                    try
                    {
                        int idx = rowData.IndexOf(":");
                        string RowColumns = rowData.Substring(0, idx).Replace("\"", "").Trim();
                        string RowDataString = rowData.Substring(idx + 1).Replace("\"", "").Trim();
                        nr[RowColumns] = RowDataString;
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }
                dtUsingMethodReturn.Rows.Add(nr);
            }
            return dtUsingMethodReturn;
        }

        #endregion

        #region  CURRENCY CONVERSION
        [HttpPost]
        public JsonResult ManageCurrencyConvesion(CurrencyConversionMGTDTO currencyConversionMGTDTO)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                response.responseCode = 2;
                response.responseMessage = "Session not exist!";
                return Json(response);
            }

            if (string.IsNullOrEmpty(currencyConversionMGTDTO.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "Action required!";
                return Json(response);
            }

            if (currencyConversionMGTDTO.Action=="A")
            {
                if (currencyConversionMGTDTO.ConversionYear==0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "ConversionYear required!";
                    return Json(response);
                }
                if (currencyConversionMGTDTO.ConversionMonth == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "ConversionMonth required!";
                    return Json(response);
                }
                if (currencyConversionMGTDTO.FromCurrency == "0")
                {
                    response.responseCode = 0;
                    response.responseMessage = "FromCurrency required!";
                    return Json(response);
                }

                if (currencyConversionMGTDTO.ConversionRate==0 || currencyConversionMGTDTO.ConversionRate<0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid conversion rate!";
                    return Json(response);
                }
            }

            currencyConversionMGTDTO.InsertedBy = loggedInUser.EmployeeId;
            currencyConversionMGTDTO.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();

            response = _CurrencyConversionBL.CurrencyConversion(currencyConversionMGTDTO);
            return Json(response);
        }
        #endregion

        public class CheckSupplierPartID
        {
            public string SupplierPartID { get; set; }
        }

        [HttpPost]
        public JsonResult MastersInsert(MastersInsertRequestDTO mastersInsertRequestDTO)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            var menuUserMaster = _masterBl.MastersInsert(mastersInsertRequestDTO);
            if (menuUserMaster.responseCode == 1)
            {
                try
                {
                    InsertAdminActivityLog(loggedInUser.EmployeeId, "Created", "COSTCENTER", "", mastersInsertRequestDTO.IParam1);
                }
                catch (Exception)
                {
                }
            }
            return Json(menuUserMaster);
        }

        public IActionResult CompanyApprovalFlow()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "Company Approval Flow";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {

            }
            else
            {

                return Redirect("~/Auth/Index");
            }

            return View();
        }

        [HttpPost]
        public JsonResult ManageCompanyApprovalFlow(ApprovalConfigRequestDTO request)
        {

            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }


            request.InsertedBy = loggedInUser.EmployeeId;
            request.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            var applicationConfig = _masterBl.ManageCompanyApprovalFlow(request);
            if (applicationConfig.responseCode == 1)
            {

                try
                {
                    //InsertAdminActivityLog(loggedInUser.EmployeeId, "Updated", "APPLICATIONCONFIG", "");
                }

                catch (Exception)
                {


                }
            }

            return Json(applicationConfig);
        }

        [HttpPost]
        public JsonResult DeleteApprovalFlow(int PrimaryId)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            var approvalMaster = _masterBl.DeleteApprovalFlow(PrimaryId);
            if (approvalMaster.responseCode == 1)
            {
                try
                {
                    //InsertAdminActivityLog(loggedInUser.EmployeeId, "Delete", "COSTCENTERCONFIG", "");
                }

                catch (Exception)
                {
                }
            }
            return Json(approvalMaster);
        }


        [HttpPost]
        public JsonResult ChangeUserType(ChangeUserTypeDTO changeUserTypeDTO)
        {

            var changeUserType = _UserManagementBL.ChangeUserType(changeUserTypeDTO);
            if (changeUserType.responseCode == 1)
            {
                var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");


                try
                {
                    string userAction = "";
                    string subject = "";
                    var serialized = "";
                    List<AuditProperties> auditProperties = new List<AuditProperties>();

                    if (changeUserTypeDTO.Action == "CHANGEUSERTYPE")
                    {
                        userAction = "Change User Type";
                        AuditProperties auditProperties1 = new AuditProperties();
                        auditProperties1.PropertyName = "Employee";
                        auditProperties1.PropertyValue = (changeUserTypeDTO.UserName);
                        auditProperties.Add(auditProperties1);

                    }

                    subject = "User Management";




                    serialized = JsonConvert.SerializeObject(auditProperties);

                    InsertAdminActivityLog(loggedInUser.EmployeeId, userAction, subject, "", serialized);
                }

                catch (Exception)
                {


                }

            }

            return Json(changeUserType);
        }

    }
}
