﻿using Aspose.Pdf;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OWebApp.Extensions;
using P2OWebApp.Models;
using P2OWebApp.Models.AdminManagement;
using P2OWebApp.Models.AppStats;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Header;
using P2OWebApp.Models.Reports;
using P2OWebApp.Models.SessionManagement;
using P2OWebApp.Models.ShoppingCart;
using P2OWebApp.Models.Website;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHostingEnvironment _hostingEnvironment;
        private IHeaderDataBL _HeaderDataBL;
        private IProductBL _IProductBL;
        private IAppStatsBL _appStats;
        private readonly IReportBL _ReportBL;

        public HomeController(ILogger<HomeController> logger, IHeaderDataBL headerBL,
            IProductBL IProductBL, IHostingEnvironment hostingEnvironment, IAppStatsBL appStats, IReportBL reportBL)
        {
            _logger = logger;
            _HeaderDataBL = headerBL;
            _IProductBL = IProductBL;
            _hostingEnvironment = hostingEnvironment;
            _appStats = appStats;
            _ReportBL = reportBL;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = false)]
        public IActionResult Index()
        {
            ViewBag.PageName = "Home";
            ViewBag.ModuleName = "Home";
            HeaderDataRequestBO headerDataRequestBO = new HeaderDataRequestBO();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                headerDataRequestBO.UserName = loggedInUser.EmployeeId;
                headerDataRequestBO.CurrentRole = loggedInUser.CurrentRoleName;
                headerDataRequestBO.SAPCompanyCode = loggedInUser.SAPCompanyCode;

            }
            else
            {

                return Redirect("~/Auth/Index");
            }

            var response = _HeaderDataBL.GetDashboardData(headerDataRequestBO);
            if (response != null)
            {
                ViewBag.CountryNames = response.CompanyCode;
                HttpContext.Session.SetObjectAsJson("HeaderDataResponse", response);

                List<ToDoTask> toDoTasks = new List<ToDoTask>();

                toDoTasks = response.ToDoTask;

                HttpContext.Session.SetObjectAsJson("RequistionCount", toDoTasks);

                List<RecentPR> recentPRs = new List<RecentPR>();

                recentPRs = response.RecentPR;

                HttpContext.Session.SetObjectAsJson("RecentPR", recentPRs);

                List<MenuMaster> menus = new List<MenuMaster>();
                menus = response.MenuMaster;
                if (menus!=null && menus.Count>0)
                {
                    foreach (var item in menus)
                    {
                        item.MenuUrl = "/" + item.MenuUrl;
                    }
                }
                HttpContext.Session.SetObjectAsJson("menuList", menus);
            }

            ViewBag.CurrentUrl = HttpContext.Request.Path;
            return View();
        }


        public IActionResult Dashboard()
        {
            ViewBag.PageName = "Home";
            ViewBag.ModuleName = "Home";
           
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser==null || string.IsNullOrEmpty(loggedInUser.EmployeeId))
            {
                return Redirect("~/Auth/Index");
            }
            return View();
        }

        public IActionResult RDAccess()
        {
            ViewBag.PageName = "Home";
            ViewBag.ModuleName = "Home";

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null || string.IsNullOrEmpty(loggedInUser.EmployeeId))
            {
                return Redirect("~/Auth/Index");
            }
            return View();
        }

        [HttpGet]
        public JsonResult ProductList(int? pageNumber)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            GetProductListingRequestDTO getProductListingRequest = new GetProductListingRequestDTO();
            if (loggedInUser == null)
            {
                ResponseClass response = new ResponseClass();
                response.responseCode = 2;
                return Json(response);
            }

            getProductListingRequest.UserID = loggedInUser.EmployeeId;
            getProductListingRequest.PageNumber = Convert.ToInt32(pageNumber);
            getProductListingRequest.RowsOfPage = 20;
            var model = _IProductBL.GetProductListing(getProductListingRequest);

            return Json(model);
        }

        [HttpPost]
        public JsonResult ProductSearch(GetProductListingRequestDTO getProductListingRequest)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            //GetProductListingRequestDTO getProductListingRequest = new GetProductListingRequestDTO();
            if (loggedInUser == null)
            {
                ResponseClass response = new ResponseClass();
                response.responseCode = 2;
                return Json(response);
            }

            getProductListingRequest.UserID = loggedInUser.EmployeeId;
            //getProductListingRequest.PageNumber = Convert.ToInt32(1);
            //getProductListingRequest.RowsOfPage = 20;
            var model = _IProductBL.GetProductListing(getProductListingRequest);
            if (model.productList != null)
            {
                CommonFunction commonFunction = new CommonFunction();
                foreach (var item in model.productList)
                {
                    item.ProductID = commonFunction.Encrypt(Convert.ToString(item.ProductID));
                }
            }
            return Json(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult RedirectDetail(string requistionNo)
        {
            /*http://10.247.251.75/P2OWeb/UserResponse?requistionNo=1JnsydiqNY3/pVMkQ6SWGw==&EMPCode=TnObR2TabCbXFpQ8H39CEg== */
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                CommonFunction commonFunction = new CommonFunction();
                requistionNo = commonFunction.Encrypt(requistionNo);
                string empCode= commonFunction.Encrypt(loggedInUser.EmployeeId);
                return Redirect("~/UserResponse/RequistionDetail?requistionNo=" + requistionNo + "&EMPCode=" + empCode + "&Source=Detail");
            }
            else
            {

                return Redirect("~/Auth/Index");
            }
            
        }

        [HttpPost]
        public JsonResult CheckReadOnlyAccess()
        {
            var userRight = HttpContext.Session.GetObjectFromJson<List<UserRight>>("UserRight");
            if (userRight != null)
            {
                var behalfRight = userRight.Where(x => x.UserRightCode == "R003").FirstOrDefault();
                if (behalfRight != null)
                {
                    return Json("RightEnabled");
                }
                return Json("");
            }

            return Json("");
        }

        [HttpPost]
        public JsonResult switchCompany(string CompanyName)
        {
            ResponseClass response = new ResponseClass();
            if (string.IsNullOrEmpty(CompanyName))
            {
                response.responseCode = 0;
                response.responseMessage = "Company name required!";
                return Json(response);
            }
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                response.responseCode = 2;
                return Json(response);
            }
            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");
            if (MyCart!=null)
            {
                response.responseCode = 0;
                response.responseMessage = "Please delete all cart items!";
                return Json(response);
            }
            loggedInUser.SAPCompanyCode = CompanyName;
            HttpContext.Session.SetObjectAsJson("EmployeeDetails", loggedInUser);
            response.responseCode = 1;
            response.responseMessage = "SUCCESS!";
            return Json(response);
        }

        public ActionResult DownloadFile(string FileName, string filePath)
        {
         
            string webRootPath = _hostingEnvironment.WebRootPath + filePath;
            // string contentRootPath = _hostingEnvironment.ContentRootPath;
            var _actualFile = Url.Content(webRootPath);
            byte[] fileBytes = Encoding.Unicode.GetBytes("No Data");

            if (System.IO.File.Exists(_actualFile))
            {
                fileBytes = System.IO.File.ReadAllBytes(_actualFile);
                return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, FileName);
            }
            else
            {
                return Redirect("~/Auth/Index");
            }



        }

        public JsonResult trackuser(AppStatsDTO appStatsBO)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                appStatsBO.employee_code = loggedInUser.EmployeeId;
                appStatsBO.employee_name = loggedInUser.FirstName;
                appStatsBO.country = loggedInUser.CountryName;

            }

            string Path = HttpContext.Request.Path;
            appStatsBO.ip_address = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            appStatsBO.device_model = (Environment.MachineName ?? string.Empty);
            var response = _appStats.AppStatInsert(appStatsBO);
            //appStatsBO.device_software
            //AppStatsDTO appStatsBO = new AppStatsDTO();
            return Json("SUCCESS");
        }

        public IActionResult GetLatestPR(string fromDate, string toDate,
           string geo, string statusText)
        {
            ViewBag.ModuleName = "Dashboard";
            ViewBag.PageName = "Dashboard";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            UserDashboardRequestDTO userDashboardRequestDTO = new UserDashboardRequestDTO();
            userDashboardRequestDTO.LoginID = loggedInUser.EmployeeId;
            userDashboardRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;
            userDashboardRequestDTO.ReportType = "PRList";
            //userDashboardRequestDTO.RowsOfPage = 20;
            //userDashboardRequestDTO.PageNumber = 1;
            userDashboardRequestDTO.CompanyCode = loggedInUser.SAPCompanyCode;
            //userDashboardRequestDTO.requistionNo = PRNumber;

            //if (!string.IsNullOrEmpty(PRNumber))
            //{
            //    ViewBag.SearchPR = PRNumber;
            //}

            List<WaitingApprovalResponceDTO> waitingApproval = new List<WaitingApprovalResponceDTO>();
            waitingApproval = _ReportBL.GetLatestPRDashboard(userDashboardRequestDTO);


            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            ViewBag.CurrentUrl = HttpContext.Request.Path;
            return View("Dashboard", waitingApproval);
        }
    }
}
