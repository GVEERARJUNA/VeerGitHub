﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OWebApp.Extensions;
using P2OWebApp.Models.Approval;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Header;
using P2OWebApp.Models.SessionManagement;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Controllers
{
    public class ApprovalController : Controller
    {
        private readonly ILogger<ApprovalController> _logger;
        private IHeaderDataBL _HeaderDataBL;

        private IApprovalBL _approvalBL;

        public ApprovalController(ILogger<ApprovalController> logger, IApprovalBL approvalBL, IHeaderDataBL headerBL)
        {
            _logger = logger;
            _approvalBL = approvalBL;
            _HeaderDataBL = headerBL;

        }

        public IActionResult Index()
        {
            ViewBag.ModuleName = "PR Detail";
            ViewBag.PageName = "TODO";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            approvalRequestDTO.SearchType = "WAITING";
            WaitingApproval waitingApproval = new WaitingApproval();

            waitingApproval.waitingApprovalRes = _approvalBL.GetWaitingApprovalList(approvalRequestDTO, out int PRId);

            //approvalRequestDTO.PurchaseRequistionID = PRId;
            //waitingApproval.approvalStatuses = _approvalBL.GetApproverList(approvalRequestDTO);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;

            HeaderDataRequestBO headerDataRequestBO = new HeaderDataRequestBO();

            headerDataRequestBO.UserName = loggedInUser.EmployeeId;
            headerDataRequestBO.CurrentRole = loggedInUser.CurrentRoleName;
            headerDataRequestBO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            var response = _HeaderDataBL.GetDashboardData(headerDataRequestBO);
            if (response != null)
            {

                List<ToDoTask> toDoTasks = new List<ToDoTask>();

                toDoTasks = response.ToDoTask;

                HttpContext.Session.SetObjectAsJson("RequistionCount", toDoTasks);
            }

            ViewBag.CurrentUrl = HttpContext.Request.Path;
            return View(waitingApproval);
        }

        public IActionResult WaitingSearch(string SearchBy, string SearchText, int currentPageIndex)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            if (SearchText != null && SearchBy != null)
            {
                HttpContext.Session.SetString("SearchBy", SearchBy);
                HttpContext.Session.SetString("SearchText", SearchText);
            }
            else
            {
                HttpContext.Session.SetString("SearchBy", "");
                HttpContext.Session.SetString("SearchText", "");
            }
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            //approvalRequestDTO.requistionNo = PRNumber;
            approvalRequestDTO.SearchBy = SearchBy;
            approvalRequestDTO.SearchText = SearchText;
            approvalRequestDTO.SearchType = "WAITING";
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            if (currentPageIndex == 0)
            {
                approvalRequestDTO.PageNumber = 1;
            }
            else
            {
                approvalRequestDTO.PageNumber = currentPageIndex;
            }
           // approvalRequestDTO.SearchBy = HttpContext.Session.GetString("SearchBy");
           // approvalRequestDTO.SearchText = HttpContext.Session.GetString("SearchText");
            ViewBag.SearchPR = SearchText;
            ViewBag.SearchCC = SearchBy;
            //ViewBag.SearchPR = PRNumber;
            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval.waitingApprovalRes = _approvalBL.GetWaitingApprovalList(approvalRequestDTO, out int PRId);

         //   approvalRequestDTO.PurchaseRequistionID = PRId;
          //  waitingApproval.approvalStatuses = _approvalBL.GetApproverList(approvalRequestDTO);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;

            HeaderDataRequestBO headerDataRequestBO = new HeaderDataRequestBO();

            headerDataRequestBO.UserName = loggedInUser.EmployeeId;
            headerDataRequestBO.CurrentRole = loggedInUser.CurrentRoleName;
            headerDataRequestBO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            var response = _HeaderDataBL.GetDashboardData(headerDataRequestBO);
            if (response != null)
            {

                List<ToDoTask> toDoTasks = new List<ToDoTask>();

                toDoTasks = response.ToDoTask;

                HttpContext.Session.SetObjectAsJson("RequistionCount", toDoTasks);
            }

            ViewBag.CurrentUrl = HttpContext.Request.Path;
            return View("Index", waitingApproval);
        }

        public IActionResult RequistionRaised()
        {
            ViewBag.ModuleName = "PR Detail";
            ViewBag.PageName = "Requistion Raised";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SearchType = "RAISED";
            approvalRequestDTO.RowsOfPage = 20;
            approvalRequestDTO.PageNumber = 1;
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            if (approvalRequestDTO.SearchText != null && approvalRequestDTO.SearchBy != null)
            {
                HttpContext.Session.SetString("SearchBy", approvalRequestDTO.SearchBy);
                HttpContext.Session.SetString("SearchText", approvalRequestDTO.SearchText);
            }
            else
            {
                HttpContext.Session.SetString("SearchBy", "");
                HttpContext.Session.SetString("SearchText", "");
            }
            // approvalRequestDTO.requistionNo = PRNumber;
            //if (currentPageIndex == 0)
            //{
            //    approvalRequestDTO.PageNumber = 1;
            //    currentPageIndex = 1;
            //}
            //else
            //{
            //    approvalRequestDTO.PageNumber = currentPageIndex;
            //}

            //if (!string.IsNullOrEmpty(PRNumber))
            //{
            //    ViewBag.SearchPR = PRNumber;
            //}

            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval = _approvalBL.GetRaisedRequistion(approvalRequestDTO, out int PRId);

            //approvalRequestDTO.PurchaseRequistionID = PRId;
          //  waitingApproval.approvalStatuses = _approvalBL.GetApproverList(approvalRequestDTO);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            //waitingApproval.PageCount = 10;

            
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            waitingApproval.CurrentPageIndex = 1;
            ViewBag.CurrentUrl = HttpContext.Request.Path;
            return View(waitingApproval);
        }


        public IActionResult RequistionRaisedPaging(int i)
        {

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SearchType = "RAISED";
            approvalRequestDTO.RowsOfPage = 20;
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            
                if (i == 0)
                {
                    approvalRequestDTO.PageNumber = 1;
                    i = 1;
                }
                else
                {
                    approvalRequestDTO.PageNumber = i;
                }

                approvalRequestDTO.SearchBy = HttpContext.Session.GetString("SearchBy");
                approvalRequestDTO.SearchText = HttpContext.Session.GetString("SearchText");
            

            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval = _approvalBL.GetRaisedRequistion(approvalRequestDTO, out int PRId);

            //approvalRequestDTO.PurchaseRequistionID = PRId;
           // waitingApproval.approvalStatuses = _approvalBL.GetApproverList(approvalRequestDTO);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
           // waitingApproval.PageCount = 10;

            waitingApproval.CurrentPageIndex = i;
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            waitingApproval.CurrentPageIndex = approvalRequestDTO.PageNumber;
            ViewBag.SearchPR = approvalRequestDTO.SearchText;
            ViewBag.SearchCC = approvalRequestDTO.SearchBy;
       
            return View("RequistionRaised", waitingApproval);
        }

        [HttpPost]
        public IActionResult RequistionRaisedSearch(string SearchBy,string SearchText, int currentPageIndex)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            if(SearchText!=null && SearchBy != null)
            {
                HttpContext.Session.SetString("SearchBy", SearchBy);
                HttpContext.Session.SetString("SearchText", SearchText);
            }
            else
            {
                HttpContext.Session.SetString("SearchBy", "");
                HttpContext.Session.SetString("SearchText", "");
            }
           
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SearchType = "RAISED";
            approvalRequestDTO.SearchBy = SearchBy;
            approvalRequestDTO.SearchText = SearchText;
            approvalRequestDTO.RowsOfPage = 20;
            approvalRequestDTO.PageNumber = 1;

            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            if (currentPageIndex == 0)
            {
                approvalRequestDTO.PageNumber = 1;
            }
            else
            {
                approvalRequestDTO.PageNumber = 1;
            }

            ViewBag.SearchPR = SearchText;
            ViewBag.SearchCC = SearchBy;
            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval = _approvalBL.GetRaisedRequistion(approvalRequestDTO, out int PRId);

            //approvalRequestDTO.PurchaseRequistionID = PRId;
            //waitingApproval.approvalStatuses = _approvalBL.GetApproverList(approvalRequestDTO);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            //return RedirectToAction("RequistionRaised", "Approval", waitingApproval);
            return View("RequistionRaised", waitingApproval);
        }

        public IActionResult RequistionApproved()
        {
            ViewBag.ModuleName = "PR Detail";
            ViewBag.PageName = "Requistion Approved";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SearchType = "APPROVED";
            approvalRequestDTO.RowsOfPage = 20;
            approvalRequestDTO.PageNumber = 1;
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;

            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval = _approvalBL.GetRaisedRequistion(approvalRequestDTO, out int PRId);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            waitingApproval.CurrentPageIndex = 1;
            ViewBag.CurrentUrl = HttpContext.Request.Path;
            return View(waitingApproval);
        }

        public IActionResult RequistionRejected()
        {
            ViewBag.ModuleName = "PR Detail";
            ViewBag.PageName = "Requistion Rejected";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SearchType = "Rejected";
            approvalRequestDTO.RowsOfPage = 20;
            approvalRequestDTO.PageNumber = 1;
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;

            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval = _approvalBL.GetRaisedRequistion(approvalRequestDTO, out int PRId);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            waitingApproval.CurrentPageIndex = 1;
            ViewBag.CurrentUrl = HttpContext.Request.Path;
            return View(waitingApproval);
        }


        public IActionResult RequistionRejectedSearch(string SearchBy, string SearchText, int currentPageIndex)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            if (SearchText != null && SearchBy != null)
            {
                HttpContext.Session.SetString("SearchBy", SearchBy);
                HttpContext.Session.SetString("SearchText", SearchText);
            }
            else
            {
                HttpContext.Session.SetString("SearchBy", "");
                HttpContext.Session.SetString("SearchText", "");
            }
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SearchType = "Rejected";
           // approvalRequestDTO.requistionNo = PRNumber;
            approvalRequestDTO.SearchBy = SearchBy;
            approvalRequestDTO.SearchText = SearchText;
            approvalRequestDTO.RowsOfPage = 20;
            approvalRequestDTO.PageNumber = 1;
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            if (currentPageIndex == 0)
            {
                approvalRequestDTO.PageNumber = 1;
            }
            else
            {
                approvalRequestDTO.PageNumber = 1;
            }

            ViewBag.SearchPR = SearchText;
            ViewBag.SearchCC = SearchBy;

            //ViewBag.SearchPR = PRNumber;

            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval = _approvalBL.GetRaisedRequistion(approvalRequestDTO, out int PRId);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            waitingApproval.CurrentPageIndex = 1;
            return View("RequistionRejected", waitingApproval);

        }
        public IActionResult RequistionApprovedPaging(int i, string searchBy, string searchText)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }

            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SearchType = "APPROVED";
            approvalRequestDTO.RowsOfPage = 20;
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            if (i == 0)
            {
                approvalRequestDTO.PageNumber = 1;
                i = 1;
            }
            else
            {
                approvalRequestDTO.PageNumber = i;
            }

            approvalRequestDTO.SearchBy = HttpContext.Session.GetString("SearchBy");
            approvalRequestDTO.SearchText = HttpContext.Session.GetString("SearchText");


            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval = _approvalBL.GetRaisedRequistion(approvalRequestDTO, out int PRId);

            //approvalRequestDTO.PurchaseRequistionID = PRId;
            //waitingApproval.approvalStatuses = _approvalBL.GetApproverList(approvalRequestDTO);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            //waitingApproval.PageCount = 10;

            waitingApproval.CurrentPageIndex = i;
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            waitingApproval.CurrentPageIndex = approvalRequestDTO.PageNumber;
            ViewBag.SearchPR = approvalRequestDTO.SearchText;
            ViewBag.SearchCC = approvalRequestDTO.SearchBy;
            return View("RequistionApproved", waitingApproval);
        }

        public IActionResult RequistionApprovedSearch(string SearchBy, string SearchText, int currentPageIndex)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            if (SearchText != null && SearchBy != null)
            {
                HttpContext.Session.SetString("SearchBy", SearchBy);
                HttpContext.Session.SetString("SearchText", SearchText);
            }
            else
            {
                HttpContext.Session.SetString("SearchBy", "");
                HttpContext.Session.SetString("SearchText", "");
            }
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInUser.EmployeeId;
            approvalRequestDTO.SearchType = "APPROVED";
            //approvalRequestDTO.requistionNo = PRNumber;
            approvalRequestDTO.SearchBy = SearchBy;
            approvalRequestDTO.SearchText = SearchText;
            approvalRequestDTO.RowsOfPage = 20;
            approvalRequestDTO.PageNumber = 1;
            approvalRequestDTO.SAPCompanyCode = loggedInUser.SAPCompanyCode;

            if (currentPageIndex == 0)
            {
                approvalRequestDTO.PageNumber = 1;
            }
            else
            {
                approvalRequestDTO.PageNumber = 1;
            }

            ViewBag.SearchPR = SearchText;
            ViewBag.SearchCC = SearchBy;
            WaitingApproval waitingApproval = new WaitingApproval();
            waitingApproval = _approvalBL.GetRaisedRequistion(approvalRequestDTO, out int PRId);

            waitingApproval.Count = waitingApproval.waitingApprovalRes.Count();
            ViewBag.LoggedinEmpId = loggedInUser.EmployeeId;
            waitingApproval.CurrentPageIndex = 1;
            return View("RequistionApproved", waitingApproval);

        }

        [HttpPost]
        public JsonResult GetApproverList(string loggedInEmpId, int PRrequisitionId)
        {
            ApprovalRequestDTO approvalRequestDTO = new ApprovalRequestDTO();
            approvalRequestDTO.LoggedInEmpId = loggedInEmpId;
            approvalRequestDTO.PurchaseRequistionID = PRrequisitionId;

            var approverList = _approvalBL.GetApproverList(approvalRequestDTO);
            return Json(approverList);
        }

        [HttpPost]
        public JsonResult UpdateApprovalStatus(string loggedInEmpId, int PRrequisitionId, int PRApprovalMatrixID, int ApprovalLevel, int ApprovalStatus, string Remark)
        {
            ApprovalSatatusUpdateRequestDTO updateRequestDTO = new ApprovalSatatusUpdateRequestDTO();
            updateRequestDTO.ApproverId = loggedInEmpId;
            updateRequestDTO.PurchaseRequistionID = PRrequisitionId;
            updateRequestDTO.PRApprovalMatrixID = PRApprovalMatrixID;
            updateRequestDTO.ApprovalLevel = ApprovalLevel;
            updateRequestDTO.ApprovalStatus = ApprovalStatus;
            updateRequestDTO.Remark = Remark;

            var approverStatus = _approvalBL.UpdateApprovalStatus(updateRequestDTO);
            return Json(approverStatus);
        }

        [HttpPost]
        public JsonResult GetPREntity(int PurchaseRequistionID, string SearchType)
        {
            GetPREntityRequest getPREntityDTO = new GetPREntityRequest();
            getPREntityDTO.PurchaseRequistionID = PurchaseRequistionID;
            getPREntityDTO.SearchType = SearchType;

            var approverList = _approvalBL.GetPREntity(getPREntityDTO);
            return Json(approverList);
        }

        [HttpPost]
        public JsonResult GetAuditTrial(int PurchaseRequistionID, string SearchType)
        {
            GetPREntityRequest getPREntityDTO = new GetPREntityRequest();
            getPREntityDTO.PurchaseRequistionID = PurchaseRequistionID;
            getPREntityDTO.SearchType = SearchType;

            var approverList = _approvalBL.GetAuditTrial(getPREntityDTO);
            return Json(approverList);
        }

        [HttpPost]
        public JsonResult GetPRFiles(int PurchaseRequistionID, string SearchType)
        {
            GetPREntityRequest getPREntityDTO = new GetPREntityRequest();
            getPREntityDTO.PurchaseRequistionID = PurchaseRequistionID;
            getPREntityDTO.SearchType = SearchType;

            var approverList = _approvalBL.GetPRFiles(getPREntityDTO);
            return Json(approverList);
        }

        [HttpPost]
        public JsonResult GetPRSAPDetails(int PurchaseRequistionID, string SearchType)
        {
            GetPREntityRequest getPREntityDTO = new GetPREntityRequest();
            getPREntityDTO.PurchaseRequistionID = PurchaseRequistionID;
            getPREntityDTO.SearchType = SearchType;

            var approverList = _approvalBL.GetPRSAPDetails(getPREntityDTO);
            return Json(approverList);
        }

        [HttpPost]
        public JsonResult GetPRDetailByDetaiID(int PurchaseRequistionID, string SearchType)
        {
            GetPREntityRequest getPREntityDTO = new GetPREntityRequest();
            getPREntityDTO.PurchaseRequistionID = PurchaseRequistionID;
            getPREntityDTO.SearchType = SearchType;

            var approverList = _approvalBL.GetPRDetailByDetailID(getPREntityDTO);
            return Json(approverList);
        }

        [HttpPost]
        public JsonResult UpdatePRDetail(UpdatePRDetailRequest updatePRDetailRequest)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                response.responseCode = 2;
                return Json(response);
            }
            else
            {
                updatePRDetailRequest.InsertedBy = loggedInUser.EmployeeId;
            }

            if (updatePRDetailRequest.PurchaseRequistionDetailID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.PurchaseRequistionDetailID required!";
                return Json(response);
            }
            if (updatePRDetailRequest.Quantity == 0 || updatePRDetailRequest.Quantity < 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.Quantity required";
                return Json(response);
            }
            if (updatePRDetailRequest.Amount == 0 || updatePRDetailRequest.Amount < 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.Amount is required";
                return Json(response);
            }
            DateTime needDate = new DateTime();
            try
            {
                needDate = Convert.ToDateTime(updatePRDetailRequest.NeededByDate);
            }
            catch (Exception)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid format of need by date!";
                return Json(response);
            }
            if (needDate < DateTime.Now)
            {
                response.responseCode = 0;
                response.responseMessage = "Need by date should be greater than today date!";
                return Json(response);
            }

            DateTime wsStartDate = new DateTime();
            try
            {
                wsStartDate = Convert.ToDateTime(updatePRDetailRequest.WarrantyStartDate);
            }
            catch (Exception)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid format of warranty start date!";
                return Json(response);
            }
            DateTime wsEndDate = new DateTime();

            try
            {
                wsEndDate = Convert.ToDateTime(updatePRDetailRequest.WarrantyEndDate);
            }
            catch (Exception)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid format of warranty end date!";
                return Json(response);
            }

            if (wsStartDate > wsEndDate)
            {
                response.responseCode = 0;
                response.responseMessage = "Warranty start date should be smallar than warranty end date!";
                return Json(response);
            }
            if (updatePRDetailRequest.LineComments.Length > 5000)
            {
                response.responseCode = 0;
                response.responseMessage = "Line comments cannot exceed 5000 characters!";
                return Json(response);
            }
            updatePRDetailRequest.InsertedBy = loggedInUser.EmployeeId;
            updatePRDetailRequest.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            updatePRDetailRequest.Action = "Edit";
            var approverStatus = _approvalBL.UpdatePRDetail(updatePRDetailRequest);
            return Json(approverStatus);
        }

        [HttpPost]
        public JsonResult AddPRDetail(UpdatePRDetailRequest updatePRDetailRequest)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                response.responseCode = 2;
                return Json(response);
            }
            else
            {
                updatePRDetailRequest.InsertedBy = loggedInUser.EmployeeId;
            }

            if (updatePRDetailRequest.PurchaseRequistionID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.PurchaseRequistionID required!";
                return Json(response);
            }
            if (string.IsNullOrEmpty(updatePRDetailRequest.MaterialCode))
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.MaterialCode required!";
                return Json(response);
            }
            if (updatePRDetailRequest.Quantity == 0 || updatePRDetailRequest.Quantity < 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.Quantity required";
                return Json(response);
            }
            if (updatePRDetailRequest.Amount == 0 || updatePRDetailRequest.Amount < 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.Amount is required";
                return Json(response);
            }
            if (updatePRDetailRequest.LineComments.Length > 5000)
            {
                response.responseCode = 0;
                response.responseMessage = "Line comments cannot exceed 5000 characters!";
                return Json(response);
            }


            DateTime needDate = new DateTime();
            try
            {
                needDate = Convert.ToDateTime(updatePRDetailRequest.NeededByDate);
            }
            catch (Exception)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid format of need by date!";
                return Json(response);
            }
            if (needDate < DateTime.Now)
            {
                response.responseCode = 0;
                response.responseMessage = "Need by date should be greater than today date!";
                return Json(response);
            }

            DateTime wsStartDate = new DateTime();
            try
            {
                wsStartDate = Convert.ToDateTime(updatePRDetailRequest.WarrantyStartDate);
            }
            catch (Exception)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid format of warranty start date!";
                return Json(response);
            }
            DateTime wsEndDate = new DateTime();

            try
            {
                wsEndDate = Convert.ToDateTime(updatePRDetailRequest.WarrantyEndDate);
            }
            catch (Exception)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid format of warranty end date!";
                return Json(response);
            }

            if (wsStartDate > wsEndDate)
            {
                response.responseCode = 0;
                response.responseMessage = "Warranty start date should be smallar than warranty end date!";
                return Json(response);
            }

            updatePRDetailRequest.InsertedBy = loggedInUser.EmployeeId;
            updatePRDetailRequest.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            updatePRDetailRequest.Action = "ADD";
            var approverStatus = _approvalBL.UpdatePRDetail(updatePRDetailRequest);
            return Json(approverStatus);
        }

        [HttpPost]
        public JsonResult DeletePRDetail(UpdatePRDetailRequest updatePRDetailRequest)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                response.responseCode = 2;
                return Json(response);
            }
            else
            {
                updatePRDetailRequest.InsertedBy = loggedInUser.EmployeeId;
            }

            if (updatePRDetailRequest.PurchaseRequistionDetailID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.PurchaseRequistionDetailID required!";
                return Json(response);
            }

            updatePRDetailRequest.InsertedBy = loggedInUser.EmployeeId;
            updatePRDetailRequest.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            updatePRDetailRequest.Action = "DELETE";
            var approverStatus = _approvalBL.UpdatePRDetail(updatePRDetailRequest);
            return Json(approverStatus);
        }

        [HttpPost]
        public JsonResult ManagePRFiles(int PurchaseRequistionID, string SearchType)
        {
            GetPREntityRequest getPREntityDTO = new GetPREntityRequest();
            getPREntityDTO.PurchaseRequistionID = PurchaseRequistionID;
            getPREntityDTO.SearchType = SearchType;

            var approverList = _approvalBL.GetPRDetailByDetailID(getPREntityDTO);
            return Json(approverList);
        }

        [HttpPost]
        public JsonResult ChangeStatus(UpdatePRDetailRequest updatePRDetailRequest)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                response.responseCode = 2;
                return Json(response);
            }
            else
            {
                updatePRDetailRequest.InsertedBy = loggedInUser.EmployeeId;
            }

            if (updatePRDetailRequest.PurchaseRequistionID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "updatePRDetailRequest.PurchaseRequistionID required!";
                return Json(response);
            }

            updatePRDetailRequest.InsertedBy = loggedInUser.EmployeeId;
            updatePRDetailRequest.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            updatePRDetailRequest.Action = "CHANGESTATUS";
            var approverStatus = _approvalBL.UpdatePRDetail(updatePRDetailRequest);
            return Json(approverStatus);
        }

        [HttpPost]
        public JsonResult GetPRDetails(GetPREntityRequest requestDTOdetails)
        {
            requestDTOdetails.SearchType = "DETAILLINE";
            var detailResponse = _approvalBL.GetPRDetailLines(requestDTOdetails);
            if (detailResponse != null && detailResponse.Count > 0)
            {
                foreach (var item in detailResponse)
                {
                    item.amountToShow = CurrencyConversion.FormatCurrency(item.Currency, item.Amount);
                    item.netAmountToShow = CurrencyConversion.FormatCurrency(item.Currency, item.NetAmount);
                }
            }
            return Json(detailResponse);
        }

        [HttpPost]
        public JsonResult ChangePRHeaderDetails(UpdatePRRequest request)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                response.responseCode = 2;
                return Json(response);
            }
            else
            {
                request.InsertedBy = loggedInUser.EmployeeId;
            }

            if (request.PurchaseRequistionID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "request.PurchaseRequistionID required!";
                return Json(response);
            }

            if (request.CreatorCode == loggedInUser.EmployeeId)
            {
                response.responseCode = 0;
                response.responseMessage = "Login user and On behalf user cannot be same!";
                return Json(response);
            }


            request.InsertedBy = loggedInUser.EmployeeId;
            if (request.OnBehalfOfFlag == "noOnBehalfOf")
            {
                request.CreatorCode = loggedInUser.EmployeeId;
            }
            else if (request.OnBehalfOfFlag == "yesOnBehalfOf")
            {
                request.CreatorCode = request.CreatorCode;
            }
            request.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();

            var approverStatus = _approvalBL.UpdatePRHeaderDetail(request);
            return Json(approverStatus);
        }

        [HttpPost]
        public JsonResult GetPRHeaderDetails(GetPREntityRequest requestDTOdetails)
        {
            requestDTOdetails.SearchType = "PRHEADERDETAIL";
            var detailResponse = _approvalBL.GetPRHeaderDetails(requestDTOdetails);

            return Json(detailResponse);
        }

        [HttpPost]
        public JsonResult Upload_File()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            var InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            string[] _extensions = { ".gif", ".png", ".jpg", ".jpeg", ".pdf", ".eml", ".xls", ".xlsx", ".msg", ".doc", ".docx" };
            string result = string.Empty;

            PRFiles PRFiles = new PRFiles();
            string PRNumber = string.Empty;
            string cartDetailN0 = string.Empty;
            if (Request.Form.Keys.Count > 0)
            {
                foreach (var item in Request.Form.Keys)
                {
                    if (item.StartsWith("PRID"))
                    {
                        cartDetailN0 = Convert.ToString(Request.Form[item]);
                        //listValues.Add(Convert.ToInt32(Request.Form[key]));
                    }
                }
            }
            if (Request.Form.Keys.Count > 0)
            {
                foreach (var item in Request.Form.Keys)
                {
                    if (item.StartsWith("PRNO"))
                    {
                        PRNumber = Convert.ToString(Request.Form[item]);
                        //listValues.Add(Convert.ToInt32(Request.Form[key]));
                    }
                }
            }

            try
            {

                long size = 0;

                var file = Request.Form.Files;

                if (file.Count > 0)
                {
                    /******** FIRST CHECK FILE EXTENSION ********/
                    foreach (var item in file)
                    {
                        var filename = ContentDispositionHeaderValue
                               .Parse(item.ContentDisposition).FileName.Trim('"');
                        var extension = Path.GetExtension(filename);
                        if (!_extensions.Contains(extension.ToLower()))
                        {

                            response.responseCode = 0;
                            response.responseMessage = "Invalid file extension!";
                            return Json(response);
                        }

                    }

                    foreach (var item in file)
                    {
                        var filename = ContentDispositionHeaderValue
                                .Parse(item.ContentDisposition).FileName.Trim('"');
                        PRFiles.FileName = filename;
                        
                        filename = filename.ToString().Replace(" ", "_");
                        filename = filename.ToString().Replace("&", "and");
                        filename = filename.ToString().Replace("#", "_");
                        var extension = Path.GetExtension(filename);
                        string saveFileName = (DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + extension);
                        
                        PRFiles.PRID = Convert.ToInt32(cartDetailN0);
                        PRFiles.FilePath = saveFileName;
                        PRFiles.Action = "ADD";
                        PRFiles.FileContent = null;
                        PRFiles.InsertedEMPCode = loggedInUser.EmployeeId;
                        PRFiles.InsertedIPAddress = InsertedIPAddress;

                        //Guid objId = Guid.NewGuid();
                        //PRFiles.Add(new PRFiles { FilePath = "", FileName = filename, FileContent = saveFileName });

                        var path = "";
                        var path1 = "";
                        path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument",loggedInUser.SAPCompanyCode, PRNumber);
                        path1 = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", loggedInUser.SAPCompanyCode, PRNumber, saveFileName);
                        try
                        {
                            if (!Directory.Exists(path))
                            {
                                Directory.CreateDirectory(path);
                                using (var stream = System.IO.File.Create(path1))
                                {
                                    item.CopyTo(stream);
                                    var approverStatus = _approvalBL.AddPRFiles(PRFiles);

                                }
                            }
                            else
                            {
                                using (var stream = System.IO.File.Create(path1))
                                {
                                    item.CopyTo(stream);
                                    var approverStatus = _approvalBL.AddPRFiles(PRFiles);

                                }
                            }
                        }
                        catch (Exception ex)
                        {

                            response.responseCode = 0;
                            response.responseMessage = ex.Message;
                            return Json(response);
                        }

                    }
                }

                //GetPREntityRequest getPREntityDTO = new GetPREntityRequest();
                //getPREntityDTO.PurchaseRequistionID = Convert.ToInt32(cartDetailN0);
                //getPREntityDTO.SearchType = "PRFILES";

                //var approverList = _approvalBL.GetPRFiles(getPREntityDTO);
                ////return Json(approverList);
                //// Store cartFiles in a dictionary using cartDetailN0 as the key
                
                //if (approverList != null)
                //{
                //    foreach (var item in cartFiles)
                //    {
                //        approverList.Add(item); // Add item from cartFiles to approverList
                //    }
                //}

                //else
                //{
                //    approverList = cartFiles;
                //}
                //cartDetail.cartFiles = cartFiles;
                //HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
            
            

                response.responseCode = 1;
                response.responseMessage = "SUCCESS!";
                return Json(response);

            }

            catch (Exception ex)

            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
                return Json(response);

            }

        }

        [HttpPost]
        public JsonResult DeleteFile(string filename, string filecontent,string filepath, string PRID)
        {
            ResponseClass response = new ResponseClass();

            PRFiles PRFiles = new PRFiles();
            

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }
            PRFiles.PRID = Convert.ToInt32(PRID);
            PRFiles.FileName = filename;
            PRFiles.FilePath = filepath;
            PRFiles.Action = "DELETE";
            PRFiles.FileContent = null;
            PRFiles.InsertedEMPCode = loggedInUser.EmployeeId;
            PRFiles.InsertedIPAddress = null;

            try
            {
              var path = "";
                
                path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", filecontent);
                if (System.IO.File.Exists(path))
                        {
                            System.IO.File.Delete(path);
                            Console.WriteLine("File deleted.");
                            var approverStatus = _approvalBL.AddPRFiles(PRFiles);
                        }
                            
                response.responseCode = 1;
                response.responseMessage = "SUCCESS!";
                return Json(response);



            }
            catch (Exception ex)
            {
              response.responseCode = 0;
              response.responseMessage = ex.Message;
              return Json(response);
            }

        }
    }
}
