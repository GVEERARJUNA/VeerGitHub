﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using P2OWebApp.Extensions;
using P2OWebApp.Models;
using P2OWebApp.Models.AdminManagement;
using P2OWebApp.Models.ApprovalMapping;
using P2OWebApp.Models.Audit;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.SessionManagement;

namespace P2OWebApp.Controllers
{
    public class ApprovalMappingController : Controller
    {
        private readonly ILogger<ApprovalMappingController> _logger;
        private readonly IApprovalMappingBL _ApprovalMappingBL;
        private readonly IAuditBL _auditBL;

        public ApprovalMappingController(ILogger<ApprovalMappingController> logger, IApprovalMappingBL approvalMapping,IAuditBL auditBL)
        {
            _logger = logger;
            _ApprovalMappingBL = approvalMapping;
            _auditBL = auditBL;


        }

        public IActionResult Index()
        {
            ViewBag.ModuleName = "Approval Mapping";
            ViewBag.PageName = "Create Approval Mapping";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                

            }
            else
            {

                return Redirect("~/Auth/Index");
            }
            //var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            //bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            //if (returnValue == false)
            //{
            //    return Redirect("~/Auth/UnAuthorizedPage");
            //}
            return View();
        }
        public IActionResult EmailEscalationMatrix()
        {
            ViewBag.ModuleName = "Approval Mapping";
            ViewBag.PageName = "Create Approval Mapping";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {


            }
            else
            {

                return Redirect("~/Auth/Index");
            }
            //var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            //bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            //if (returnValue == false)
            //{
            //    return Redirect("~/Auth/UnAuthorizedPage");
            //}
            return View();
        }
        

        public IActionResult EditApprovalMapping()
        {
            ViewBag.ModuleName = "Approval Mapping";
            ViewBag.PageName = "EditApprovalMapping";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {


            }
            else
            {

                return Redirect("~/Auth/Index");
            }
            //var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            //bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            //if (returnValue == false)
            //{
            //    return Redirect("~/Auth/UnAuthorizedPage");
            //}
            return View();
        }

        public IActionResult PRApprovalMapping()
        {
            ViewBag.ModuleName = "Approval Mapping";
            ViewBag.PageName = "PRApprovalMapping";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {


            }
            else
            {

                return Redirect("~/Auth/Index");
            }
            //var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            //bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            //if (returnValue == false)
            //{
            //    return Redirect("~/Auth/UnAuthorizedPage");
            //}
            return View();
        }

        public IActionResult ApprovalMappingModel()
        {
            ViewBag.ModuleName = "Approval Mapping";
            ViewBag.PageName = "Create Approval Mapping";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {


            }
            else
            {

                return Redirect("~/Auth/Index");
            }
           
            return View();
        }

        [HttpPost]
        public JsonResult CreateApplicatonHierarchy(ApprovalMappingInsertRequestDTO approvalMappingInsertRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
               
                response.responseCode = 2;
                return Json(response);
            }
            else
            {
                approvalMappingInsertRequestDTO.InsertdBy = loggedInUser.EmployeeId;
                approvalMappingInsertRequestDTO.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            }

            response = _ApprovalMappingBL.ApplicationHierarchyCreate(approvalMappingInsertRequestDTO);

            if (response.responseCode == 1)
            {
                try
                {

                    //activityLog = "Cost Center : ";
                    //foreach (var item in approvalMappingInsertRequestDTO.costCenterAPRequestLists)
                    //{
                    //    activityLog += item.CostCenterCode + ",";
                    //}

                    //activityLog = activityLog.TrimEnd(',');
                    //string activityLog = string.Empty;
                    //activityLog = JsonConvert.SerializeObject(approvalMappingInsertRequestDTO.costCenterAPRequestLists);
                    List<AuditProperties> auditProperties = new List<AuditProperties>();
                    AuditProperties auditProperties1 = new AuditProperties();
                    auditProperties1.PropertyName = "CostCenter";
                    auditProperties1.PropertyValue = JsonConvert.SerializeObject(approvalMappingInsertRequestDTO.costCenterAPRequestLists);
                    auditProperties.Add(auditProperties1);

                    AuditProperties auditProperties2 = new AuditProperties();
                    auditProperties2.PropertyName = "ApprovalLevel";
                    auditProperties2.PropertyValue = JsonConvert.SerializeObject(approvalMappingInsertRequestDTO.approvalLevelRequestLists);
                    auditProperties.Add(auditProperties2);

                    var serialized = JsonConvert.SerializeObject(auditProperties);

                    InsertAdminActivityLog(loggedInUser.EmployeeId, "Add", "Approval Mapping","", serialized);
                }
                catch (Exception)
                {


                }

            }

            return Json(response);
        }

        [HttpPost]
        public JsonResult ManageApplicatonHierarchy(AppHierarchyManageRequestDTO appHierarchyManageRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            if (appHierarchyManageRequestDTO.Action == "DELETE")
            {
                var myRightObject = HttpContext.Session.GetObjectFromJson<List<UserRight>>("UserRight");

                var readOnlyAccess = false;
                if (myRightObject != null)
                {
                    var readOnly = myRightObject.Where(x => x.UserRightCode == "R003").FirstOrDefault();
                    if (readOnly != null)
                    {
                        readOnlyAccess = true;
                        response.responseCode = 2;
                        response.responseMessage = "You cannot make any action as you have read only access!";
                        return Json(response);

                    }
                }
            }


                

            string activityLog = string.Empty;
            
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 2;
                return Json(response);
            }
            else
            {
                appHierarchyManageRequestDTO.InsertedBy = loggedInUser.EmployeeId;
                appHierarchyManageRequestDTO.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            }

            if (appHierarchyManageRequestDTO.Action== "PRMAppingEDIT")
            {
                if (appHierarchyManageRequestDTO.pRApprovalMatrices == null || appHierarchyManageRequestDTO.pRApprovalMatrices.Count == 0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Edit data required!";
                    return Json(response);
                }

                int editedCount = appHierarchyManageRequestDTO.pRApprovalMatrices.Where(x => x.updateRequired == 1).Count();

                if (editedCount==0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Edit data required!";
                    return Json(response);
                }

                List<int> myList = new List<int>(); //{ 1, 2, 3, 5, 8, 9 };

                foreach (var item in appHierarchyManageRequestDTO.pRApprovalMatrices)
                {
                    myList.Add(item.ApprovalLevel);
                }

                int a = myList.OrderBy(x => x).First();
                int b = myList.OrderBy(x => x).Last();

                List<int> myList2 = Enumerable.Range(a, b - a + 1).ToList();
                List<int> remaining = myList2.Except(myList).ToList();

                if (remaining!=null && remaining.Count>0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "You cannot skip any level!";
                    return Json(response);
                }

            }

            

            response = _ApprovalMappingBL.AppHierarchyManage(appHierarchyManageRequestDTO);
            if (response.responseCode == 1)
            {
                try
                {
                    string userAction = "";
                    string subject = "";
                    var serialized="";

                    if (appHierarchyManageRequestDTO.Action== "ADD")
                    {
                        userAction = "Add Level";
                        subject = "Edit Approval Mapping";

                        List<AuditProperties> auditProperties = new List<AuditProperties>();
                        AuditProperties auditProperties1 = new AuditProperties();
                        auditProperties1.PropertyName = "CostCenter";
                        auditProperties1.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.CostCenterCode);
                        auditProperties.Add(auditProperties1);

                        AuditProperties auditProperties3 = new AuditProperties();
                        auditProperties3.PropertyName = "RoleName";
                        auditProperties3.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.RoleName);
                        auditProperties.Add(auditProperties3);

                        AuditProperties auditProperties2 = new AuditProperties();
                        auditProperties2.PropertyName = "ApprovalLevel";
                        auditProperties2.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.AppLevel);
                        auditProperties.Add(auditProperties2);

                        serialized = JsonConvert.SerializeObject(auditProperties);

                        InsertAdminActivityLog(loggedInUser.EmployeeId, userAction, subject, "", serialized);
                    }
                    else if(appHierarchyManageRequestDTO.Action== "DELETE")
                    {
                        userAction = "Delete Level";
                        subject = "Edit Approval Mapping";

                        List<AuditProperties> auditProperties = new List<AuditProperties>();
                        AuditProperties auditProperties1 = new AuditProperties();
                        auditProperties1.PropertyName = "CostCenter";
                        auditProperties1.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.CostCenterCode);
                        auditProperties.Add(auditProperties1);

                        AuditProperties auditProperties3 = new AuditProperties();
                        auditProperties3.PropertyName = "RoleName";
                        auditProperties3.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.RoleName);
                        auditProperties.Add(auditProperties3);

                        AuditProperties auditProperties2 = new AuditProperties();
                        auditProperties2.PropertyName = "ApprovalLevel";
                        auditProperties2.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.AppLevel);
                        auditProperties.Add(auditProperties2);

                        serialized = JsonConvert.SerializeObject(auditProperties);

                        InsertAdminActivityLog(loggedInUser.EmployeeId, userAction, subject, "", serialized);
                    }

                    if (appHierarchyManageRequestDTO.Action == "PRMAppingEDIT")
                    {
                        userAction = "Updated";
                        subject = "PR Approval Mapping";

                        List<AuditProperties> auditProperties = new List<AuditProperties>();
                        AuditProperties auditProperties1 = new AuditProperties();
                        auditProperties1.PropertyName = "PRNumber";
                        auditProperties1.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.RequistionNo);
                        auditProperties.Add(auditProperties1);

                        AuditProperties auditProperties2 = new AuditProperties();
                        auditProperties2.PropertyName = "ApprovalFlow";
                        auditProperties2.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.existingData);
                        auditProperties.Add(auditProperties2);

                        var oldserialized = JsonConvert.SerializeObject(auditProperties);

                        /*******************  New Data  *******************/

                        List<AuditProperties> auditPropertiesnew = new List<AuditProperties>();
                        AuditProperties auditProperties3 = new AuditProperties();
                        auditProperties3.PropertyName = "PRNumber";
                        auditProperties3.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.RequistionNo);
                        auditPropertiesnew.Add(auditProperties3);

                        AuditProperties auditProperties4 = new AuditProperties();
                        auditProperties4.PropertyName = "ApprovalFlow";
                        auditProperties4.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.pRApprovalMatrices);
                        auditPropertiesnew.Add(auditProperties4);

                        var newserialized = JsonConvert.SerializeObject(auditPropertiesnew);

                        InsertAdminActivityLog(loggedInUser.EmployeeId, userAction, subject, oldserialized, newserialized);

                    }

                  
                    if (appHierarchyManageRequestDTO.Action == "PRLEVELADD")
                    {
                       
                        userAction = "NewApprover";
                        subject = "PR Approval Mapping";

                        List<AuditProperties> auditProperties = new List<AuditProperties>();
                        AuditProperties auditProperties1 = new AuditProperties();
                        auditProperties1.PropertyName = "PRNumber";
                        auditProperties1.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.RequistionNo);
                        auditProperties.Add(auditProperties1);

                        AuditProperties auditProperties3 = new AuditProperties();
                        auditProperties3.PropertyName = "Employee";
                        auditProperties3.PropertyValue = JsonConvert.SerializeObject(appHierarchyManageRequestDTO.EMPCode);
                        auditProperties.Add(auditProperties3);

                        serialized = JsonConvert.SerializeObject(auditProperties);

                        InsertAdminActivityLog(loggedInUser.EmployeeId, userAction, subject, "", serialized);


                    }
                    //PRLEVELADD
                    //if (userAction!="")
                    //{
                    //    InsertAdminActivityLog(loggedInUser.EmployeeId, userAction, subject, "",serialized);
                    //}

                }
                catch (Exception)
                {


                }

            }

            return Json(response);
        }

        public void InsertAdminActivityLog(string ActionEmployeeID, string ActivityAction, string ActivitySubject, 
             string OldValue, string NewValue)
        {
            AdminActivityLogInsertDTO adminActivityLogInsertDTO = new AdminActivityLogInsertDTO();
            adminActivityLogInsertDTO.ActionEmployeeID = ActionEmployeeID;
            adminActivityLogInsertDTO.ActivityAction = ActivityAction;
            adminActivityLogInsertDTO.ActivityLog = string.Empty;
            adminActivityLogInsertDTO.ActivitySubject = ActivitySubject;
            adminActivityLogInsertDTO.OldValue = OldValue;
            adminActivityLogInsertDTO.NewValue = NewValue;
            var response = _auditBL.InsertAdminActivityLog(adminActivityLogInsertDTO);
        }

        //[HttpPost]
        //public JsonResult()
        //{


        //}

        public JsonResult GetApprovelName()
        {
            ViewBag.ModuleName = "Approval Mapping";

            List<SelectListItem> Approvers = new List<SelectListItem>();
            Approvers.Add(new SelectListItem() { Text = "Select", Value = "0",Selected=true });
            Approvers.Add(new SelectListItem() { Text = "Shyam", Value = "1" });
            Approvers.Add(new SelectListItem() { Text = "Sanjay", Value = "2" });
            Approvers.Add(new SelectListItem() { Text = "Ekta", Value = "3" });
            Approvers.Add(new SelectListItem() { Text = "Veer", Value = "4" });
            return Json(Approvers);
        }

        [HttpPost]
        public JsonResult SaveEmailEscMatrix(ApprovalMappingInsertRequestDTO approvalMappingInsertRequestDTO)
        {
            ViewBag.ModuleName = "Approval Mapping";

            List<SelectListItem> Approvers = new List<SelectListItem>();
            //Approvers.Add(new SelectListItem() { Text = "Select", Value = "0", Selected = true });
            //Approvers.Add(new SelectListItem() { Text = "Shyam", Value = "1" });
            //Approvers.Add(new SelectListItem() { Text = "Sanjay", Value = "2" });
            //Approvers.Add(new SelectListItem() { Text = "Ekta", Value = "3" });
            //Approvers.Add(new SelectListItem() { Text = "Veer", Value = "4" });
            return Json(Approvers);
        }
    }
}
