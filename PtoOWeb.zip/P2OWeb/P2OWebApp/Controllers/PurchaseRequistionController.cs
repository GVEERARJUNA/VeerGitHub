﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using P2OWebApp.Extensions;
using P2OWebApp.Models.AdminManagement;
using P2OWebApp.Models.CatalogueManagement;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Masters;
using P2OWebApp.Models.SessionManagement;
using P2OWebApp.Models.ShoppingCart;
using P2OWebApp.Models.Website;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace P2OWebApp.Controllers
{
    public class PurchaseRequistionController : Controller
    {
        private readonly ILogger<PurchaseRequistionController> _logger;

        private IMasterDataBL _MasterDataBL;
        private IProductBL _IProductBL;

        public PurchaseRequistionController(ILogger<PurchaseRequistionController> logger, IMasterDataBL masterBL, IProductBL IProductBL)
        {
            _logger = logger;
            _MasterDataBL = masterBL;
            _IProductBL = IProductBL;

        }

        public IActionResult Index(string type,string code)
        {
            HttpContext.Session.ClearSessionByName("ShoppingCartFiles");

            ViewBag.ModuleName = "PRCreation";
            ViewBag.PageName = "NonCatalogue";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null )
            {
                return Redirect("~/Auth/Index");
            }

            ViewBag.CostCenter = Convert.ToString(loggedInUser.CostCenter);

            if (!string.IsNullOrEmpty(type))
            {
                ViewBag.PurchaseType = type;

                TempData["PurchaseType"] = type;
            }


            if (!string.IsNullOrEmpty(code))
            {
                CommonFunction commonFunction = new CommonFunction();
                string materialCode = commonFunction.Decrypt(code);

                TempData["MaterialCode"] = materialCode;

            }

            purchaseRequistionMaster myMasterData = new purchaseRequistionMaster();

            MasterDataRequest masterDataRequest = new MasterDataRequest();
            masterDataRequest.EntityName = "PRMasterData";
            masterDataRequest.SearchParameter1 = "";
            masterDataRequest.SearchParameter2 = "";
            masterDataRequest.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequest.CompanyCode = loggedInUser.SAPCompanyCode;
            myMasterData = _MasterDataBL.GetPRRequistionMaster(masterDataRequest);

            ViewBag.CurrentUrl = HttpContext.Request.Path;



            return View(myMasterData);
        }

        [HttpPost]
        public JsonResult GetMaterialCodeQueryString(string code)
        {
            try
            {
                //var myData = { "MaterialCode":Convert.ToString(TempData["MaterialCode"]) }
                string matCode = Convert.ToString(TempData["MaterialCode"]);
                string pType = Convert.ToString(TempData["PurchaseType"]);
                returnData data = new returnData();
                data.matCode = matCode;
                data.purchaseType = pType;
                return Json(data);
            }
            catch (Exception)
            {

                return Json("");
            }

           

        }

        [HttpPost]
        public JsonResult CheckCart()
        {
            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart != null)
            {
                return Json(MyCart);
            }

            return Json("");
        }


        [HttpPost]
        public JsonResult GetMasterData(MasterDataRequest masterDataRequest)
        {

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            
            if (loggedInUser == null)
            {
                ResponseClass response = new ResponseClass();
                response.responseCode = 2;
                return Json(response);
            }

            masterDataRequest.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequest.CompanyCode = loggedInUser.SAPCompanyCode;
            var model = _MasterDataBL.GetCommonEntity(masterDataRequest);
            if (masterDataRequest.EntityName== "AssignedCompanies")
            {
                model.responseReturnNo = loggedInUser.SAPCompanyCode;
            }
            return Json(model);
        }

        [HttpPost]
        public JsonResult AddToCart(ShoppingCart shoppingCart)
        {
            ResponseClass response = new ResponseClass();

            DateTime needDate = new DateTime();
            try
            {
                needDate = Convert.ToDateTime(shoppingCart.shoppingCartDetails[0].NeededByDate);
            }
            catch (Exception)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid format of need by date!";
                return Json(response);
            }

            if (shoppingCart.CartType== "NonCatalogue")
            {
                DateTime wsStartDate = new DateTime();
                try
                {
                    wsStartDate = Convert.ToDateTime(shoppingCart.shoppingCartDetails[0].WarrantyStartDate);
                }
                catch (Exception)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid format of warranty start date!";
                    return Json(response);
                }
                DateTime wsEndDate = new DateTime();

                try
                {
                    wsEndDate = Convert.ToDateTime(shoppingCart.shoppingCartDetails[0].WarrantyEndDate);
                }
                catch (Exception)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid format of warranty end date!";
                    return Json(response);
                }

                if (wsStartDate>wsEndDate)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Warranty start date should be smallar than warranty end date!";
                    return Json(response);
                }
            }

            if (shoppingCart.shoppingCartDetails[0].MaterialQuantity<0 || shoppingCart.shoppingCartDetails[0].MaterialQuantity==0)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid value of quantity!";
                return Json(response);
            }
            if (shoppingCart.shoppingCartDetails[0].MaterialAmount < 0 || shoppingCart.shoppingCartDetails[0].MaterialAmount == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid value of amount!";
                return Json(response);
            }
            if (shoppingCart.shoppingCartDetails[0].Comments.Length>5000)
            {
                response.responseCode = 0;
                response.responseMessage = "Line comments cannot exceed 5000 characters!";
                return Json(response);
            }

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                
                response.responseCode = 2;
                return Json(response);
            }

            if (shoppingCart.OnBehalfOfFlag == "yesOnBehalfOf" && string.IsNullOrEmpty(shoppingCart.EmployeeCode))
            {
                response.responseCode = 0;
                response.responseMessage = "Creator code is missing!";
                return Json(response);
            }

            if (shoppingCart.EmployeeCode == loggedInUser.EmployeeId)
            {
                response.responseCode = 0;
                response.responseMessage = "Login user and On behalf user cannot be same!";
                return Json(response);
            }



            Guid obj = Guid.NewGuid();

            if (shoppingCart.shoppingCartDetails!=null)
            {
                shoppingCart.shoppingCartDetails[0].CartDetailNo = obj.ToString();

                shoppingCart.shoppingCartDetails[0].NetAmount = shoppingCart.shoppingCartDetails[0].MaterialAmount * shoppingCart.shoppingCartDetails[0].MaterialQuantity;

                try
                {
                    GetProductListingRequestDTO getProductListingRequest = new GetProductListingRequestDTO();
                    getProductListingRequest.ProductCode = shoppingCart.shoppingCartDetails[0].MaterialCode;
                    getProductListingRequest.PageNumber = -1;
                    getProductListingRequest.SearchType = shoppingCart.PurchaseType;
                    getProductListingRequest.UserID = loggedInUser.EmployeeId;
                    var model = _IProductBL.GetProductListing(getProductListingRequest);
                    if (model.productList != null)
                    {
                        CommonFunction commonFunction = new CommonFunction();
                        foreach (var item in model.productList)
                        {
                            //item.ProductID = commonFunction.Encrypt(Convert.ToString(item.ProductID));
                            if (item.ProductID == getProductListingRequest.ProductCode)
                            {
                                shoppingCart.shoppingCartDetails[0].MaterialImage = "~/assets/MaterialImage/" + item.MaterialImage;
                            }
                        }
                    }
                }
                catch (Exception)
                {

                }
               
            }
            var MyCartFiles = HttpContext.Session.GetObjectFromJson<List<CartFiles>>("ShoppingCartFiles");

           
            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCartFiles!=null)
            {
                shoppingCart.shoppingCartDetails[0].cartFiles = MyCartFiles;
                HttpContext.Session.ClearSessionByName("ShoppingCartFiles");
            }

            //shoppingCart.shoppingCartDetails[0].cartFiles=

            if (MyCart==null)
            {
                shoppingCart.TotalAmount = CurrencyConversion.FormatCurrency(shoppingCart.Currency, shoppingCart.shoppingCartDetails.Sum(x => x.NetAmount));
                
                HttpContext.Session.SetObjectAsJson("ShoppingCart", shoppingCart);

                
            }
            else
            {
                MyCart.shoppingCartDetails.Add(shoppingCart.shoppingCartDetails[0]);

                MyCart.TotalAmount = CurrencyConversion.FormatCurrency(MyCart.Currency, MyCart.shoppingCartDetails.Sum(x => x.NetAmount));

                HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
            }


            response.responseCode = 1;
            response.responseReturnNo = obj.ToString();

            return Json(response);
        }

        [HttpPost]
        public JsonResult Upload_File()
        {
            ResponseClass response = new ResponseClass();
            //.gif,*.png,*.jpg,*.jpeg,*.pdf,*.eml,*.xls,*.xlsx
            string[] _extensions= { ".gif", ".png", ".jpg", ".jpeg", ".pdf", ".eml", ".xls", ".xlsx",".msg",".doc", ".docx" };
            string result = string.Empty;

            List<CartFiles> cartFiles = new List<CartFiles>();

            string cartDetailN0 = string.Empty;

            if (Request.Form.Keys.Count>0)
            {
                foreach (var item in Request.Form.Keys)
                {
                    if (item.StartsWith("DetailNo"))
                    {
                        cartDetailN0 = Convert.ToString(Request.Form[item]);
                        //listValues.Add(Convert.ToInt32(Request.Form[key]));
                    }
                }
            }

            try

            {

                long size = 0;

                var file = Request.Form.Files;

                if (file.Count>0)
                {
                    /******** FIRST CHECK FILE EXTENSION ********/
                    foreach (var item in file)
                    {
                        var filename = ContentDispositionHeaderValue

                               .Parse(item.ContentDisposition).FileName.Trim('"');
                        var extension = Path.GetExtension(filename);
                        if (!_extensions.Contains(extension.ToLower()))
                        {
                            var MyCartToCheck = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

                            if (MyCartToCheck != null)
                            {
                                var cartDetail = MyCartToCheck.shoppingCartDetails.Where(x => x.CartDetailNo == cartDetailN0).FirstOrDefault();
                                MyCartToCheck.shoppingCartDetails.Remove(cartDetail);
                                if (MyCartToCheck.shoppingCartDetails == null || MyCartToCheck.shoppingCartDetails.Count == 0)
                                {
                                    HttpContext.Session.ClearSessionByName("ShoppingCart");
                                }
                                else
                                {
                                    HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCartToCheck);
                                }
                                
                            }

                            response.responseCode = 0;
                            response.responseMessage = "Invalid file extension!";
                            return Json(response);
                        }

                    }
                    foreach (var item in file)
                    {

                        var filename = ContentDispositionHeaderValue

                                .Parse(item.ContentDisposition).FileName.Trim('"');

                        var extension = Path.GetExtension(filename);

                        filename = filename.ToString().Replace(" ","_");
                        filename = filename.ToString().Replace("&", "and");
                        filename = filename.ToString().Replace("#", "_");
                        var filesize = item.Length;

                        //string saveFileName = (DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + "-" + filename);
                        string saveFileName = (DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString()  + extension);


                        Guid objId= Guid.NewGuid();
                        
                        cartFiles.Add(new CartFiles {FileContent= "",FileName= filename, FilePath= saveFileName, fileNo = objId.ToString(),fileSize= Convert.ToInt32(filesize) });

                        var path = "";

                        path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", saveFileName);

                        try
                        {
                            using (var stream = System.IO.File.Create(path))
                            {
                                item.CopyTo(stream);

                                
                            }
                        }
                        catch (Exception ex)
                        {

                            response.responseCode = 0;
                            response.responseMessage = ex.Message;
                            return Json(response);
                        }

                    }
                }

                var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

                if (MyCart!=null)
                {
                    var cartDetail = MyCart.shoppingCartDetails.Where(x=>x.CartDetailNo==cartDetailN0).FirstOrDefault();
                    cartDetail.cartFiles = cartFiles;
                    HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
                }


                response.responseCode = 1;
                response.responseMessage = "SUCCESS!";
                return Json(response);

            }

            catch (Exception ex)

            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
                return Json(response);

            }

        }

        [HttpPost]
        public JsonResult GetSelfCostCenter()
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser !=null)
            {
                //object model = "{"CostCenter":loggedInUser.CostCenter }";
                return Json(loggedInUser.CostCenter);
            }

            return Json("");
        }

        [HttpPost]
        public JsonResult GetUserBehalfRight()
        {
            var userRight = HttpContext.Session.GetObjectFromJson<List<UserRight>>("UserRight");
            if (userRight != null)
            {
                var behalfRight = userRight.Where(x => x.UserRightCode == "R001").FirstOrDefault();
                if (behalfRight!=null)
                {
                    return Json("RightEnabled");
                }
                return Json("");
            }

            return Json("");
        }

        [HttpPost]
        public JsonResult GetOtherCostCenter(MasterDataRequest masterDataRequest)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                ResponseClass response = new ResponseClass();
                response.responseCode = 2;
                return Json(response);
            }

            masterDataRequest.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequest.CompanyCode = loggedInUser.CompanyCode;
            var model = _MasterDataBL.GetCommonEntity(masterDataRequest);
            if (model.responseCode == 1)
            {
                return Json(model.masterDataResponses[0].ValueField);
            }


            return Json("");
            
        }

        [HttpPost]
        public JsonResult GetEmployeeList()
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null)
            {
                MasterDataRequest masterDataRequestuser = new MasterDataRequest();
                masterDataRequestuser.EntityName = "UserMaster";
                masterDataRequestuser.SearchParameter1 = "";
                masterDataRequestuser.SearchParameter2 = "";
                masterDataRequestuser.EmployeeID = loggedInUser.EmployeeId;
                masterDataRequestuser.CompanyCode = loggedInUser.CompanyCode;
                var userMaster = _MasterDataBL.GetCommonEntity(masterDataRequestuser);
                return Json(userMaster.masterDataResponses);
            }
            else
            {
                return Json("");
            }

           
        }

        [HttpPost]
        public JsonResult GetPREntityData(MasterDataRequest masterDataRequest)
        {

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {
                ResponseClass response = new ResponseClass();
                response.responseCode = 2;
                return Json(response);
            }

            masterDataRequest.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequest.CompanyCode = loggedInUser.CompanyCode;
            var model = _MasterDataBL.GetPRRequistionMaster(masterDataRequest);
            return Json(model);
        }


        public class returnData
        {
            public string matCode { get; set; }
            public string purchaseType { get; set; }
        }

        public IActionResult PRCatalogue()
        {
            ViewBag.ModuleName = "PRCreation";
            ViewBag.PageName = "Catalogue";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }

            ViewBag.CostCenter = Convert.ToString(loggedInUser.CostCenter);

            purchaseRequistionMaster myMasterData = new purchaseRequistionMaster();

            MasterDataRequest masterDataRequest = new MasterDataRequest();
            masterDataRequest.EntityName = "PRMasterData";
            masterDataRequest.SearchParameter1 = "";
            masterDataRequest.SearchParameter2 = "";
            masterDataRequest.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequest.CompanyCode = loggedInUser.SAPCompanyCode;
            myMasterData = _MasterDataBL.GetPRRequistionMaster(masterDataRequest);

            ViewBag.CurrentUrl = HttpContext.Request.Path;

            var selectedCatalogue = HttpContext.Session.GetObjectFromJson<CatalogueDataListResponse>("catalogueredirectSession");
            if (selectedCatalogue == null)
            {
                return Redirect("~/Home/Index");
            }
            else
            {
                ViewBag.FullDescription = selectedCatalogue.ItemDescription;
                ViewBag.UOM = selectedCatalogue.ItemUOM;
                ViewBag.Quantity = selectedCatalogue.quantity;
                ViewBag.Vendor = selectedCatalogue.VendorName;
                ViewBag.Price = selectedCatalogue.UnitPrice;
                ViewBag.VendorCode = selectedCatalogue.VendorCode;
                ViewBag.MaterialCode = selectedCatalogue.MaterialCode;
                ViewBag.Currency = selectedCatalogue.Currency;
                ViewBag.CatalogueDataID = selectedCatalogue.CatalogueDataID;
            }


            return View(myMasterData);
        }
        [HttpPost]
        public JsonResult AddToCartCatalogue(ShoppingCart shoppingCart)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 2;
                return Json(response);
            }

            if (shoppingCart.OnBehalfOfFlag == "yesOnBehalfOf" && string.IsNullOrEmpty(shoppingCart.EmployeeCode))
            {
                response.responseCode = 0;
                response.responseMessage = "Creator code is missing!";
                return Json(response);
            }

            if (shoppingCart.EmployeeCode == loggedInUser.EmployeeId)
            {
                response.responseCode = 0;
                response.responseMessage = "Login user and On behalf user cannot be same!";
                return Json(response);
            }
           
           

            DateTime needDate = new DateTime();
            try
            {
                needDate = Convert.ToDateTime(shoppingCart.shoppingCartDetails[0].NeededByDate);
            }
            catch (Exception)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid format of need by date!";
                return Json(response);
            }

            if (shoppingCart.EmployeeCode == loggedInUser.EmployeeId)
            {
                response.responseCode = 0;
                response.responseMessage = "Login user and On behalf user cannot be same!";
                return Json(response);
            }

            if (string.IsNullOrEmpty(shoppingCart.CostCenter) || Convert.ToString(shoppingCart.CostCenter)=="0")
            {
                response.responseCode = 0;
                response.responseMessage = "Cost center required!";
                return Json(response);
            }
            if (string.IsNullOrEmpty(shoppingCart.CartType))
            {
                response.responseCode = 0;
                response.responseMessage = "Cart Type required!";
                return Json(response);
            }

            if (shoppingCart.CartType=="Catalogue")
            {
                if (string.IsNullOrEmpty(shoppingCart.VendorCode) || Convert.ToString(shoppingCart.VendorCode) == "0")
                {
                    response.responseCode = 0;
                    response.responseMessage = "Vendor required!";
                    return Json(response);
                }
            }
            if (shoppingCart.shoppingCartDetails[0].MaterialQuantity < 0 || shoppingCart.shoppingCartDetails[0].MaterialQuantity == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid value of quantity!";
                return Json(response);
            }
            if (shoppingCart.shoppingCartDetails[0].MaterialAmount < 0 || shoppingCart.shoppingCartDetails[0].MaterialAmount == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid value of amount!";
                return Json(response);
            }
            if (shoppingCart.shoppingCartDetails[0].Comments.Length > 5000)
            {
                response.responseCode = 0;
                response.responseMessage = "Line comments cannot exceed 5000 characters!";
                return Json(response);
            }

            Guid obj = Guid.NewGuid();

            if (shoppingCart.shoppingCartDetails != null)
            {
                shoppingCart.shoppingCartDetails[0].CartDetailNo = obj.ToString();

                shoppingCart.shoppingCartDetails[0].NetAmount = shoppingCart.shoppingCartDetails[0].MaterialAmount * shoppingCart.shoppingCartDetails[0].MaterialQuantity;

                shoppingCart.shoppingCartDetails[0].MaterialImage = "~/assets/images/no_image.jpg";

            }

            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart == null)
            {
                shoppingCart.TotalAmount = CurrencyConversion.FormatCurrency(shoppingCart.Currency, shoppingCart.shoppingCartDetails.Sum(x => x.NetAmount));
                HttpContext.Session.SetObjectAsJson("ShoppingCart", shoppingCart);


            }
            else
            {
                MyCart.shoppingCartDetails.Add(shoppingCart.shoppingCartDetails[0]);

                MyCart.TotalAmount = CurrencyConversion.FormatCurrency(MyCart.Currency, MyCart.shoppingCartDetails.Sum(x => x.NetAmount));

                HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
            }

            HttpContext.Session.ClearSessionByName("catalogueredirectSession");
            response.responseCode = 1;
            response.responseReturnNo = obj.ToString();

            return Json(response);
        }

        [HttpPost]
        public JsonResult UploadMultipleFiles()
        {
            ResponseClass response = new ResponseClass();
            //.gif,*.png,*.jpg,*.jpeg,*.pdf,*.eml,*.xls,*.xlsx
            string[] _extensions = { ".gif", ".png", ".jpg", ".jpeg", ".pdf", ".eml", ".xls", ".xlsx", ".msg", ".doc",".docx" };
            string result = string.Empty;


            List<CartFiles> cartFiles = new List<CartFiles>();
            //string cartDetailN0 = string.Empty;

            //if (Request.Form.Keys.Count > 0)
            //{
            //    foreach (var item in Request.Form.Keys)
            //    {
            //        if (item.StartsWith("DetailNo"))
            //        {
            //            cartDetailN0 = Convert.ToString(Request.Form[item]);
            //            //listValues.Add(Convert.ToInt32(Request.Form[key]));
            //        }
            //    }
            //}

            try

            {

                long size = 0;

                var file = Request.Form.Files;

                if (file.Count > 0)
                {
                    /******** FIRST CHECK FILE EXTENSION ********/
                    foreach (var item in file)
                    {
                        var filename = ContentDispositionHeaderValue

                               .Parse(item.ContentDisposition).FileName.Trim('"');
                        var extension = Path.GetExtension(filename);
                        if (!_extensions.Contains(extension.ToLower()))
                        {
                           
                            response.responseCode = 0;
                            response.responseMessage = "Invalid file extension!";
                            return Json(response);
                        }

                    }
                    foreach (var item in file)
                    {

                        var filename = ContentDispositionHeaderValue

                                .Parse(item.ContentDisposition).FileName.Trim('"');

                        var extension = Path.GetExtension(filename);

                        filename = filename.ToString().Replace(" ", "_");
                        filename = filename.ToString().Replace("&", "and");
                        filename = filename.ToString().Replace("#", "_");
                        var filesize = item.Length;

                        //string saveFileName = (DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + "-" + filename);
                        string saveFileName = (DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + extension);


                        Guid objId = Guid.NewGuid();

                        cartFiles.Add(new CartFiles { FileContent = "", FileName = filename, FilePath = saveFileName, fileNo = objId.ToString(), fileSize = Convert.ToInt32(filesize) });

                        var path = "";

                        path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", saveFileName);

                        try
                        {
                            using (var stream = System.IO.File.Create(path))
                            {
                                item.CopyTo(stream);


                            }
                        }
                        catch (Exception ex)
                        {

                            response.responseCode = 0;
                            response.responseMessage = ex.Message;
                            return Json(response);
                        }

                    }
                }

                

                var MyCartFiles = HttpContext.Session.GetObjectFromJson<List<CartFiles>>("ShoppingCartFiles");

                if (MyCartFiles != null)
                {
                    if (cartFiles!=null && cartFiles.Count>0)
                    {
                        foreach (var item in cartFiles)
                        {
                            MyCartFiles.Add(item);
                        }
                    }
                    //var cartDetail = MyCart.shoppingCartDetails.Where(x => x.CartDetailNo == cartDetailN0).FirstOrDefault();
                    
                    HttpContext.Session.SetObjectAsJson("ShoppingCartFiles", MyCartFiles);
                }
                else
                {
                    HttpContext.Session.SetObjectAsJson("ShoppingCartFiles", cartFiles);
                }


                response.responseCode = 1;
                response.responseMessage = "SUCCESS!";
                return Json(response);

            }

            catch (Exception ex)

            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
                return Json(response);

            }

        }

        public JsonResult GetUploadedFiles()
        {
            var MyCartFiles = HttpContext.Session.GetObjectFromJson<List<CartFiles>>("ShoppingCartFiles");
            return Json(MyCartFiles);

        }
        [HttpPost]
        public JsonResult deleteFileMultiple(string fileNo)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }
            var MyCartFiles = HttpContext.Session.GetObjectFromJson<List<CartFiles>>("ShoppingCartFiles");

            if (MyCartFiles != null)
            {
                var detail = MyCartFiles.Where(x => x.fileNo == fileNo).FirstOrDefault();
                if (detail != null)
                {
                   // var file = detail.cartFiles.Where(x => x.fileNo == fileNo).FirstOrDefault();
                    try
                    {
                        var path = "";

                        path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", detail.FilePath);
                        if (System.IO.File.Exists(path))
                        {
                            // If file found, delete it    
                            System.IO.File.Delete(path);
                            Console.WriteLine("File deleted.");
                        }



                    }
                    catch (Exception)
                    {


                    }


                    MyCartFiles.Remove(detail);
                    HttpContext.Session.SetObjectAsJson("ShoppingCartFiles", MyCartFiles);

                    response.responseCode = 1;



                }

            }
            return Json(response);
        }
    }
}
