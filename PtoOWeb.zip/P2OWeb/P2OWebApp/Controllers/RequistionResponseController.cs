﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OWebApp.Extensions;
using P2OWebApp.Models.Header;
using P2OWebApp.Models.SessionManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Controllers
{
    public class RequistionResponseController : Controller
    {
        private IHeaderDataBL _HeaderDataBL;
        private readonly ILogger<RequistionResponseController> _logger;

        public RequistionResponseController(ILogger<RequistionResponseController> logger, IHeaderDataBL headerBL)
        {
            _logger = logger;
            _HeaderDataBL = headerBL;
           
        }

        public IActionResult Index()
        {
            ViewBag.ModuleName = "PRCreation";
            ViewBag.PageName = "SuccessPage";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }

            HeaderDataRequestBO headerDataRequestBO = new HeaderDataRequestBO();
            headerDataRequestBO.UserName = loggedInUser.EmployeeId;
            headerDataRequestBO.CurrentRole = loggedInUser.CurrentRoleName;
            headerDataRequestBO.SAPCompanyCode = loggedInUser.SAPCompanyCode;
            var response = _HeaderDataBL.GetDashboardData(headerDataRequestBO);
            if (response != null)
            {
                ViewBag.CountryNames = response.CompanyCode;
                HttpContext.Session.SetObjectAsJson("HeaderDataResponse", response);

                List<ToDoTask> toDoTasks = new List<ToDoTask>();

                toDoTasks = response.ToDoTask;

                HttpContext.Session.SetObjectAsJson("RequistionCount", toDoTasks);
            }

            return View();
        }
    }
}
