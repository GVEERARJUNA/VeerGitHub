﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using P2OWebApp.Extensions;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.EmailManagement;
using P2OWebApp.Models.SessionManagement;

namespace P2OWebApp.Controllers
{
    public class EmailMasterController : Controller
    {
        private readonly IEmailManagementBL  _emailManagementBL;
        public EmailMasterController(IEmailManagementBL emailManagementBL)
        {
            _emailManagementBL = emailManagementBL;
        }

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.ModuleName = "Admin";
            ViewBag.PageName = "EmailMaster";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            //ResponseClass response = new ResponseClass();
            //EmailMGTRequestDTO emailMGTRequestDTO = new EmailMGTRequestDTO();
            //emailMGTRequestDTO.Action = "Manage";
            //response = _emailManagementBL.EmailManagementSetting(emailMGTRequestDTO);

            return View();
        }


        public JsonResult GetEmailManagementSetting()
        {
            ResponseClass response = new ResponseClass();
            EmailMGTRequestDTO emailMGTRequestDTO = new EmailMGTRequestDTO();
            emailMGTRequestDTO.Action = "Manage";
            response = _emailManagementBL.EmailManagementSetting(emailMGTRequestDTO);
            return Json(response);
        }

        [HttpPost]
        public JsonResult GetEmailManagementSetting(int EmailMasterId)
        {
            ResponseClass response = new ResponseClass();
            EmailMGTRequestDTO emailMGTRequestDTO = new EmailMGTRequestDTO();
            emailMGTRequestDTO.Action = "Manage";
            emailMGTRequestDTO.EmailMasterID = EmailMasterId;
            response = _emailManagementBL.EmailManagementSetting(emailMGTRequestDTO);
            return Json(response);
        }

        [HttpPost]
        public JsonResult UpdateEmailManagementSetting(int EmailMasterId, string EmailSubject, string EmailTemplate)
        {
            ResponseClass response = new ResponseClass();
            EmailMGTUpdateDTO emailMGTUpdateDTO = new EmailMGTUpdateDTO();
            emailMGTUpdateDTO.EmailMasterID = EmailMasterId;
            emailMGTUpdateDTO.EmailSubject = EmailSubject;
            emailMGTUpdateDTO.EmailTemplate = EmailTemplate.Replace("&lt;", "<").Replace("&gt;", ">");
            emailMGTUpdateDTO.Action = "Update";
            response = _emailManagementBL.UpdateEmailManagementSetting(emailMGTUpdateDTO);

            return Json(response);
        }
    }
}
