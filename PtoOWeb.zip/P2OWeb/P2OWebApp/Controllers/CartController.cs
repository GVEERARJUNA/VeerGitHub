﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OWebApp.Extensions;
using P2OWebApp.Models.Approval;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Masters;
using P2OWebApp.Models.SessionManagement;
using P2OWebApp.Models.ShoppingCart;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Controllers
{
    public class CartController : Controller
    {
        private readonly ILogger<CartController> _logger;
        private IMasterDataBL _MasterDataBL;

        private IShoppingCartBL _ShoppingCartBL;

        private IApprovalBL _approvalBL;

        public CartController(ILogger<CartController> logger, IMasterDataBL masterBL, IShoppingCartBL shoppingCartBL, IApprovalBL approvalBL)
        {
            _logger = logger;
            _MasterDataBL = masterBL;
            _ShoppingCartBL = shoppingCartBL;
            _approvalBL = approvalBL;

        }

        public IActionResult Index(string type, string code)
        {
            ViewBag.ModuleName = "ShoppingCart";
            ViewBag.PageName = "ShoppingCart";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }

            ViewBag.CostCenter = Convert.ToString(loggedInUser.CostCenter);

            if (!string.IsNullOrEmpty(type))
            {
                ViewBag.PurchaseType = type;

                TempData["PurchaseType"] = type;
            }


            if (!string.IsNullOrEmpty(code))
            {
                CommonFunction commonFunction = new CommonFunction();
                string materialCode = commonFunction.Decrypt(code);

                TempData["MaterialCode"] = materialCode;

            }

            purchaseRequistionMaster myMasterData = new purchaseRequistionMaster();

            MasterDataRequest masterDataRequest = new MasterDataRequest();
            masterDataRequest.EntityName = "PRMasterData";
            masterDataRequest.SearchParameter1 = "";
            masterDataRequest.SearchParameter2 = "";
            masterDataRequest.EmployeeID = loggedInUser.EmployeeId;
            masterDataRequest.CompanyCode = loggedInUser.SAPCompanyCode;
            myMasterData = _MasterDataBL.GetPRRequistionMaster(masterDataRequest);
            ViewBag.CurrentUrl = HttpContext.Request.Path;
            return View(myMasterData);
        }

        public IActionResult Delete(string deleteID)
        {
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }

            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart != null)
            {
                var detail = MyCart.shoppingCartDetails.Where(x => x.CartDetailNo == deleteID).FirstOrDefault();
                if (detail != null)
                {
                    if (detail.cartFiles != null && detail.cartFiles.Count > 0)
                    {
                        foreach (var item in detail.cartFiles)
                        {
                            try
                            {
                                var path = "";

                                path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", item.FileName);
                                if (System.IO.File.Exists(path))
                                {
                                    // If file found, delete it    
                                    System.IO.File.Delete(path);
                                    Console.WriteLine("File deleted.");
                                }



                            }
                            catch (Exception)
                            {


                            }
                        }
                    }
                    MyCart.shoppingCartDetails.Remove(detail);

                    if (MyCart.shoppingCartDetails == null || MyCart.shoppingCartDetails.Count == 0)
                    {
                        HttpContext.Session.ClearSessionByName("ShoppingCart");
                    }
                    else
                    {
                        HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
                    }


                }

            }


            return Redirect("~/Cart/Index");
        }

        [HttpPost]
        public JsonResult editQuantity(string detailNo, int Quantity)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }
            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart != null)
            {
                var detail = MyCart.shoppingCartDetails.Where(x => x.CartDetailNo == detailNo).FirstOrDefault();
                if (detail != null)
                {
                    //MyCart.shoppingCartDetails.Remove(detail);

                    detail.MaterialQuantity = Quantity;
                    detail.NetAmount = detail.MaterialAmount * detail.MaterialQuantity;


                    if (MyCart.shoppingCartDetails == null || MyCart.shoppingCartDetails.Count == 0)
                    {
                        HttpContext.Session.ClearSessionByName("ShoppingCart");
                    }
                    else
                    {
                        HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
                    }

                    response.responseCode = 1;



                }

            }

            return Json(response);
        }

        [HttpPost]
        public JsonResult GetDetail(string detailNo)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }
            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart != null)
            {
                var detail = MyCart.shoppingCartDetails.Where(x => x.CartDetailNo == detailNo).FirstOrDefault();
                if (detail != null)
                {

                    return Json(MyCart);
                }

            }

            return Json(response);
        }

        [HttpPost]
        public JsonResult PlaceOrder(ShoppingCart shoppingCart)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }

            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart == null)
            {

                response.responseCode = 2;
                response.responseMessage = "Please add item in cart!";
                return Json(response);
            }


            MyCart.InsertedBy = loggedInUser.EmployeeId;
            if (MyCart.OnBehalfOfFlag == "noOnBehalfOf")
            {
                MyCart.CreatorCode = loggedInUser.EmployeeId;
            }
            else if (MyCart.OnBehalfOfFlag == "yesOnBehalfOf")
            {
                MyCart.CreatorCode = MyCart.EmployeeCode;
            }


            MyCart.InsertedIPAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();
            response = _ShoppingCartBL.PlaceHolder(MyCart);
            if (response.responseCode == 1)
            {
                TempData["requistionNo"] = response.responseReturnNo;
                try
                {
                    string createpath = string.Empty;
                    createpath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", loggedInUser.SAPCompanyCode, response.responseReturnNo);

                    foreach (var item in MyCart.shoppingCartDetails)
                    {
                        if (item.cartFiles != null && item.cartFiles.Count > 0)
                        {
                            if (!Directory.Exists(createpath))
                            {
                                Directory.CreateDirectory(createpath);
                            }

                            foreach (var files in item.cartFiles)
                            {
                                string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", files.FilePath);
                                string path2 = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", loggedInUser.SAPCompanyCode, response.responseReturnNo, files.FilePath);
                                System.IO.File.Move(path, path2);
                                WriteLogFile.WriteLog("Information", "copy file " + path + "To" + path2);
                            }



                        }
                    }
                }
                catch (Exception ex)
                {
                    WriteLogFile.WriteLog("Exception", "Exception in copy file " + ex.Message);


                }

                HttpContext.Session.ClearSessionByName("ShoppingCart");


            }
            return Json(response);
        }

        public JsonResult checkFileUpload()
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }
            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart != null)
            {
                if (MyCart.OnBehalfOfFlag == "yesOnBehalfOf")
                {
                    int fileCount = 0;
                    foreach (var item in MyCart.shoppingCartDetails)
                    {
                        if (item.cartFiles != null && item.cartFiles.Count > 0)
                        {
                            fileCount = fileCount + 1;
                        }
                    }

                    if (fileCount == 0)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Please upload supporting documents!";
                        return Json(response);
                    }
                }
                else
                {
                    response.responseCode = 1;
                    response.responseMessage = "";
                    return Json(response);
                }
            }

            response.responseCode = 1;
            response.responseMessage = "";
            return Json(response);


        }

        [HttpPost]
        public JsonResult editDetails(
            //string PurchaseTypeCode, string PurchaseType, 
            //string PurchaseGroup, string Currency, string CostCenterFlag, string CostCenterCode,
            //string CostCenter, string PlantCode, string PlantName, string PurchaseOrganisationCode,
            //string PurchaseOrganisation, string VendorCode, string Vendor, string OnBehalfOfFlag,string EmployeeCode,
            string detailNo, double Quantity, double amount, string materialCode,string materialDesc, string glCode, string productType, string comments)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }
            if (Quantity < 0 || Quantity == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid value of quantity!";
                return Json(response);
            }
            if (amount < 0 || amount == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid value of amount!";
                return Json(response);
            }
            if (comments.Length > 5000)
            {
                response.responseCode = 0;
                response.responseMessage = "Line comments cannot exceed 5000 characters!";
                return Json(response);
            }

            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart != null)
            {
                //MyCart.CostCenter = CostCenter;
                //MyCart.CostCenterCode = CostCenterCode;
                //MyCart.CostCenterFlag = CostCenterFlag;
                //MyCart.Currency = Currency;
                //MyCart.PlantCode = PlantCode;
                //MyCart.PlantName = PlantName;
                //MyCart.PurchaseGroup = PurchaseGroup;
                //MyCart.PurchaseOrganisation = PurchaseOrganisation;
                //MyCart.PurchaseOrganisationCode = PurchaseOrganisationCode;
                //MyCart.PurchaseType = PurchaseType;
                //MyCart.PurchaseTypeCode = PurchaseTypeCode;
                //MyCart.Vendor = Vendor;
                //MyCart.VendorCode = VendorCode;

                //if (MyCart.OnBehalfOfFlag == "yesOnBehalfOf")
                //{
                //    int fileCount = 0;
                //    foreach (var item in MyCart.shoppingCartDetails)
                //    {
                //        if (item.cartFiles!=null && item.cartFiles.Count>0)
                //        {
                //            fileCount = fileCount + 1;
                //        }
                //    }

                //    if (fileCount==0)
                //    {
                //        response.responseCode = 0;
                //        response.responseMessage = "Please upload supporting documents!";
                //        return Json(response);
                //    }
                //}

                var detail = MyCart.shoppingCartDetails.Where(x => x.CartDetailNo == detailNo).FirstOrDefault();
                if (detail != null)
                {

                    detail.MaterialAmount = amount;
                    detail.GLCode = glCode;
                    detail.MaterialCode = materialCode;
                    detail.MaterialDescription = materialDesc;
                    detail.Comments = comments;
                    detail.ProductType = productType;

                    detail.MaterialQuantity = Quantity;
                    detail.NetAmount = detail.MaterialAmount * detail.MaterialQuantity;




                    if (MyCart.shoppingCartDetails == null || MyCart.shoppingCartDetails.Count == 0)
                    {
                        HttpContext.Session.ClearSessionByName("ShoppingCart");
                    }
                    else
                    {
                        MyCart.TotalAmount = CurrencyConversion.FormatCurrency(MyCart.Currency, MyCart.shoppingCartDetails.Sum(x => x.NetAmount));

                        HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
                    }

                    response.responseCode = 1;



                }

            }

            return Json(response);
        }



        [HttpPost]
        public JsonResult deleteFile(string detailNo, string fileNo)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }
            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart != null)
            {
                var detail = MyCart.shoppingCartDetails.Where(x => x.CartDetailNo == detailNo).FirstOrDefault();
                if (detail != null)
                {
                    var file = detail.cartFiles.Where(x => x.fileNo == fileNo).FirstOrDefault();
                    try
                    {
                        var path = "";

                        path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", file.FilePath);
                        if (System.IO.File.Exists(path))
                        {
                            // If file found, delete it    
                            System.IO.File.Delete(path);
                            Console.WriteLine("File deleted.");
                        }



                    }
                    catch (Exception)
                    {


                    }


                    detail.cartFiles.Remove(file);
                    if (MyCart.shoppingCartDetails == null || MyCart.shoppingCartDetails.Count == 0)
                    {
                        HttpContext.Session.ClearSessionByName("ShoppingCart");
                    }
                    else
                    {
                        HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
                    }

                    response.responseCode = 1;



                }

            }
            return Json(response);
        }

        [HttpPost]

        public JsonResult Upload_File()
        {
            ResponseClass response = new ResponseClass();
            string[] _extensions = { ".gif", ".png", ".jpg", ".jpeg", ".pdf", ".eml", ".xls", ".xlsx", ".msg", ".doc", ".docx" };
            string result = string.Empty;

            List<CartFiles> cartFiles = new List<CartFiles>();

            string cartDetailN0 = string.Empty;

            if (Request.Form.Keys.Count > 0)
            {
                foreach (var item in Request.Form.Keys)
                {
                    if (item.StartsWith("DetailNo"))
                    {
                        cartDetailN0 = Convert.ToString(Request.Form[item]);
                        //listValues.Add(Convert.ToInt32(Request.Form[key]));
                    }
                }
            }

            try

            {

                long size = 0;

                var file = Request.Form.Files;

                if (file.Count > 0)
                {
                    /******** FIRST CHECK FILE EXTENSION ********/
                    foreach (var item in file)
                    {
                        var filename = ContentDispositionHeaderValue

                               .Parse(item.ContentDisposition).FileName.Trim('"');
                        var extension = Path.GetExtension(filename);
                        if (!_extensions.Contains(extension.ToLower()))
                        {

                            response.responseCode = 0;
                            response.responseMessage = "Invalid file extension!";
                            return Json(response);
                        }

                    }

                    foreach (var item in file)
                    {
                        var filename = ContentDispositionHeaderValue

                                .Parse(item.ContentDisposition).FileName.Trim('"');

                        filename = filename.ToString().Replace(" ", "_");
                        filename = filename.ToString().Replace("&", "and");
                        filename = filename.ToString().Replace("#", "_");
                        var extension = Path.GetExtension(filename);
                        string saveFileName = (DateTime.Now.Day.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Year.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + DateTime.Now.Millisecond.ToString() + extension);

                        Guid objId = Guid.NewGuid();
                        cartFiles.Add(new CartFiles { FileContent = "", FileName = filename, FilePath = saveFileName, fileNo = objId.ToString() });

                        var path = "";

                        path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "assets", "PRDocument", saveFileName);

                        try
                        {
                            using (var stream = System.IO.File.Create(path))
                            {
                                item.CopyTo(stream);


                            }
                        }
                        catch (Exception ex)
                        {

                            response.responseCode = 0;
                            response.responseMessage = ex.Message;
                            return Json(response);
                        }

                    }
                }

                var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

                if (MyCart != null)
                {
                    var cartDetail = MyCart.shoppingCartDetails.Where(x => x.CartDetailNo == cartDetailN0).FirstOrDefault();
                    if (cartDetail.cartFiles != null && cartDetail.cartFiles.Count > 0)
                    {
                        foreach (var item in cartFiles)
                        {
                            cartDetail.cartFiles.Add(item);
                        }
                    }
                    else
                    {
                        cartDetail.cartFiles = cartFiles;
                    }
                    //cartDetail.cartFiles = cartFiles;
                    HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
                }


                response.responseCode = 1;
                response.responseMessage = "SUCCESS!";
                return Json(response);

            }

            catch (Exception ex)

            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
                return Json(response);

            }





        }

        [HttpPost]
        public JsonResult GetPRVirtualFlow()
        {
            string CreatorCode = string.Empty;
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null)
            {

                PRVirtualFlowRequestDTO prVirtualFlow = new PRVirtualFlowRequestDTO();
                var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");
                if (MyCart != null)
                {

                    if (MyCart.OnBehalfOfFlag == "noOnBehalfOf")
                    {
                        CreatorCode = loggedInUser.EmployeeId;
                        //prVirtualFlow.CostCenterCode = MyCart;
                    }
                    else
                    {
                        CreatorCode = MyCart.EmployeeCode;
                    }
                    prVirtualFlow.CreatorCode = CreatorCode;
                    prVirtualFlow.CostCenterCode = MyCart.CostCenterCode;

                    prVirtualFlow.PurchaseGroup = MyCart.PurchaseGroup;
                    prVirtualFlow.PurchaseTypeID = Convert.ToInt32(MyCart.PurchaseTypeCode);
                    prVirtualFlow.TotalAmount = MyCart.shoppingCartDetails.Sum(x => x.NetAmount);
                    var approverList = _approvalBL.GetPRVirtualFlow(prVirtualFlow);
                    return Json(approverList);
                }
            }

            return Json("");


        }

        [HttpPost]
        public JsonResult editPRDetails(
            //string PurchaseTypeCode, string PurchaseType, 
            //string PurchaseGroup, string Currency, string CostCenterFlag, string CostCenterCode,
            //string CostCenter, string PlantCode, string PlantName, string PurchaseOrganisationCode,
            //string PurchaseOrganisation, string VendorCode, string Vendor, string OnBehalfOfFlag,string EmployeeCode
            string PurchaseType, string PurchaseTypeCode,
            string PurchaseGroup, string PurchaseGroupText, string Currency, string OnBehalfOfFlag, string EmployeeCode,string CreatorName,
            string CostCenter,string CostCenterCode,string CostCenterFlag, string PlantCode, string PlantName,
            string PurchaseOrganisationCode,string PurchaseOrganisation, string VendorCode, string Vendor) //string Vendor, string OnBehalfOfFlag, string EmployeeCode)
        {
            ResponseClass response = new ResponseClass();

            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");

            if (loggedInUser == null)
            {

                response.responseCode = 3;
                return Json(response);
            }

            if (EmployeeCode == loggedInUser.EmployeeId)
            {
                response.responseCode = 0;
                response.responseMessage = "Login user and On behalf user cannot be same!";
                return Json(response);
            }
            var MyCart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("ShoppingCart");

            if (MyCart != null)
            {

                MyCart.PurchaseType = PurchaseType;
                MyCart.PurchaseTypeCode = PurchaseTypeCode;

                MyCart.CostCenter = CostCenter;

                MyCart.CostCenterCode = CostCenterCode;
                MyCart.CostCenterFlag = CostCenterFlag;
                MyCart.Currency = Currency;
                MyCart.PlantCode = PlantCode;
                MyCart.PlantName = PlantName;
                MyCart.PurchaseGroup = PurchaseGroup;
                MyCart.PurchaseGroupText = PurchaseGroupText;
                MyCart.PurchaseOrganisation = PurchaseOrganisation;
                MyCart.PurchaseOrganisationCode = PurchaseOrganisationCode;
                MyCart.OnBehalfOfFlag = OnBehalfOfFlag;
                MyCart.EmployeeCode = EmployeeCode;
                MyCart.CreatorName = CreatorName;

                //MyCart.PurchaseTypeCode = PurchaseTypeCode;
                MyCart.Vendor = Vendor;
                MyCart.VendorCode = VendorCode;
                MyCart.TotalAmount = CurrencyConversion.FormatCurrency(MyCart.Currency, MyCart.shoppingCartDetails.Sum(x => x.NetAmount));

                if (MyCart.shoppingCartDetails == null || MyCart.shoppingCartDetails.Count == 0)
                {
                    HttpContext.Session.ClearSessionByName("ShoppingCart");
                }
                else
                {
                    HttpContext.Session.SetObjectAsJson("ShoppingCart", MyCart);
                }

                response.responseCode = 1;
                //if (MyCart.OnBehalfOfFlag == "yesOnBehalfOf")
                //{
                //    int fileCount = 0;
                //    foreach (var item in MyCart.shoppingCartDetails)
                //    {
                //        if (item.cartFiles != null && item.cartFiles.Count > 0)
                //        {
                //            fileCount = fileCount + 1;
                //        }
                //    }

                //    if (fileCount == 0)
                //    {
                //        response.responseCode = 0;
                //        response.responseMessage = "Please upload supporting documents!";
                //        return Json(response);
                //    }
                //}


            }
            return Json(response);
        }
    }
}
