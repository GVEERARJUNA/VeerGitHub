﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OWebApp.Extensions;
using P2OWebApp.Models;
using P2OWebApp.Models.AdminManagement;
using P2OWebApp.Models.SessionManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Controllers
{
    public class P2OController : Controller
    {
        private readonly IOptions<IDBConnection> appSettings;
        private readonly ILogger<P2OController> _logger;
        private readonly ILoginRequestBL _LoginRequestBL;
        public P2OController(ILogger<P2OController> logger, ILoginRequestBL loginRequestBL,
            IOptions<IDBConnection> appSettings
            )
        {
            _logger = logger;
            _LoginRequestBL = loginRequestBL;
            this.appSettings = appSettings;
        }
        public IActionResult P2ODashboard()
        {
            LoginRequest login = new LoginRequest();
            login.UserName = "5219";
            var response = _LoginRequestBL.UserLogin(login);
            if (response.responseCode != 1)
            {
                ViewBag.ErrorMessage = response.responseMessage;
                return View();

            }
            else
            {
                // set session
                var employee = new List<LoggedInUserModel>();

                employee = JsonConvert.DeserializeObject<List<LoggedInUserModel>>(response.responseJSON.ToString());

                HttpContext.Session.SetObjectAsJson("EmployeeDetails", employee[0]);
                try
                {
                    var userRight = new List<UserRight>();

                    userRight = JsonConvert.DeserializeObject<List<UserRight>>(response.responseJSONSecondary.ToString());

                    HttpContext.Session.SetObjectAsJson("UserRight", userRight);
                }
                catch
                {


                }

                //return Redirect("~/Home/Index");
            }
            return View();
        }
    }
}
