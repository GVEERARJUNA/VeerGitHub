﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using P2OWebApp.Extensions;
using P2OWebApp.Models;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Reports;
using P2OWebApp.Models.SessionManagement;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Controllers
{
    public class ReportController : Controller
    {
        private readonly IReportBL _ReportBL;
        public ReportController(IReportBL reportBL)
        {
            _ReportBL = reportBL;
        }

        public IActionResult PRSummary()
        {
            ViewBag.ModuleName = "Report";
            ViewBag.PageName = "PRSummary";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult EventReport()
        {
            ViewBag.ModuleName = "Report";
            ViewBag.PageName = "EventReport";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult CompanyApprovalReport()
        {
            ViewBag.ModuleName = "Report";
            ViewBag.PageName = "EventReport";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult PRAgingReport()
        {
            ViewBag.ModuleName = "Report";
            ViewBag.PageName = "PRAgingReport";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult AdminActivityLog()
        {
            ViewBag.ModuleName = "Report";
            ViewBag.PageName = "AdminActivityLog";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult SummaryReport()
        {
            ViewBag.ModuleName = "Report";
            ViewBag.PageName = "SummaryReport";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult SummaryReportDetails()
        {
            ViewBag.ModuleName = "Report";
            ViewBag.PageName = "SummaryReportDetails";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            
            return View();
        }

        [HttpPost]
        public JsonResult GETPRReportData(PRReportRequestDTO pRReportRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                pRReportRequestDTO.UserName = loggedInUser.EmployeeId;
                pRReportRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;

            }


            response = _ReportBL.GetPRReport(pRReportRequestDTO);
            return Json(response);

        }

        [HttpPost]
        //[ValidateInput(false)]
        public FileResult ExportPRAgingReport(string GridHtml)
        {
            string FileName = "PRAgingReport-" + DateTime.Now.Date;
            return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "" + FileName + ".xls");
        }

        [HttpPost]
       
        public FileResult ExportPRSummaryReport(string costCompany, string fromDate, string toDate, string ddlStatus)
        {
            string GridHtml = string.Empty;
            string FileName = "PR Summary -" + DateTime.Now.Date;
            
            ResponseClass response = new ResponseClass();
            PRReportRequestDTO pRReportRequestDTO = new PRReportRequestDTO();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                pRReportRequestDTO.UserName = loggedInUser.EmployeeId;
                pRReportRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;

            }

            DataTable dt = new DataTable("Grid");

            pRReportRequestDTO.PageNumber = -1;
            pRReportRequestDTO.ReportType = "PRSummary";
            pRReportRequestDTO.RowsOfPage = 20;
            pRReportRequestDTO.FromDate = fromDate;
            pRReportRequestDTO.ToDate = toDate;
            pRReportRequestDTO.SearchCriteria1 = costCompany;
            pRReportRequestDTO.SearchCriteria2 = ddlStatus;
            response = _ReportBL.GetPRReport(pRReportRequestDTO);
            if (response.responseCode==1)
            {
                if (response.responseJSON.ToString().Length>0)
                {
                    dt = GetJSONToDataTableUsingMethod(response.responseJSON.ToString());
                }
                
            }

           

            dt.TableName = "PRSummary";
            if (dt.Columns.Contains("PurchaseRequistionID"))
            {
                dt.Columns.Remove("PurchaseRequistionID");
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "" + FileName + ".xlsx");
                }
            }

            //return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "" + FileName + ".xls");
        }

        public static DataTable GetJSONToDataTableUsingMethod(string JSONData)
        {
            DataTable dtUsingMethodReturn = new DataTable();
            string[] jsonStringArray = Regex.Split(JSONData.Replace("[", "").Replace("]", ""), "},{");
            List<string> ColumnsName = new List<string>();
            foreach (string strJSONarr in jsonStringArray)
            {
                string[] jsonStringData = Regex.Split(strJSONarr.Replace("{", "").Replace("}", ""), ",");
                foreach (string ColumnsNameData in jsonStringData)
                {
                    try
                    {
                        int idx = ColumnsNameData.IndexOf(":");
                        string ColumnsNameString = ColumnsNameData.Substring(0, idx).Replace("\"", "").Trim();
                        if (!ColumnsName.Contains(ColumnsNameString))
                        {
                            ColumnsName.Add(ColumnsNameString);
                        }
                    }
                    catch (Exception ex)
                    {
                        //throw new Exception(string.Format("Error Parsing Column Name : {0}", ColumnsNameData));
                    }
                }
                break;
            }
            foreach (string AddColumnName in ColumnsName)
            {
                dtUsingMethodReturn.Columns.Add(AddColumnName);
            }
            foreach (string strJSONarr in jsonStringArray)
            {
                string[] RowData = Regex.Split(strJSONarr.Replace("{", "").Replace("}", ""), ",");
                DataRow nr = dtUsingMethodReturn.NewRow();
                foreach (string rowData in RowData)
                {
                    try
                    {
                        int idx = rowData.IndexOf(":");
                        string RowColumns = rowData.Substring(0, idx).Replace("\"", "").Trim();
                        string RowDataString = rowData.Substring(idx + 1).Replace("\"", "").Trim();
                        nr[RowColumns] = RowDataString;
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }
                dtUsingMethodReturn.Rows.Add(nr);
            }
            return dtUsingMethodReturn;
        }

        [HttpPost]
        //[ValidateInput(false)]
        public FileResult ExportAdminActivityLogReport(string fromDate, string toDate)
        {
            string GridHtml = string.Empty;
            string FileName = "Admin Activity Log -" + DateTime.Now.Date;

            ResponseClass response = new ResponseClass();
            PRReportRequestDTO pRReportRequestDTO = new PRReportRequestDTO();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                pRReportRequestDTO.UserName = loggedInUser.EmployeeId;
                pRReportRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;

            }

            DataTable dt = new DataTable("Grid");

            pRReportRequestDTO.PageNumber = -1;
            pRReportRequestDTO.ReportType = "ADMINACTLOG";
            pRReportRequestDTO.RowsOfPage = 20;
            pRReportRequestDTO.FromDate = fromDate;
            pRReportRequestDTO.ToDate = toDate;
           
            response = _ReportBL.GetPRReport(pRReportRequestDTO);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    List<AdminActivityLogResponse> adminActivityLogResponses = new List<AdminActivityLogResponse>();
                    adminActivityLogResponses = JsonConvert.DeserializeObject<List<AdminActivityLogResponse>>(response.responseJSON.ToString());
                    
                    dt.Columns.AddRange(new DataColumn[7] {
                                            new DataColumn("SrNo"),
                                            new DataColumn("EmpName"),
                                            new DataColumn("Module"),
                                             new DataColumn("Action"),
                                              new DataColumn("ActionedOn"),
                                               new DataColumn("OldValue"),
                                                new DataColumn("NewValue")

                     });

                    if (adminActivityLogResponses!=null && adminActivityLogResponses.Count > 0)
                    {
                        int i = 1;
                        foreach (var cost in adminActivityLogResponses)
                        {
                            dt.Rows.Add(i, cost.EmployeeName, cost.ActivitySubject, cost.ActivityAction, cost.ActionedOn,cost.OldValue,cost.NewValue);
                            i++;
                        }
                    }
                    else
                    {
                        dt.Rows.Add("No records to display");
                    }

                    //dt = GetJSONToDataTableUsingMethod(response.responseJSON.ToString());
                }

            }



            dt.TableName = "Admin Activity Log";

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "" + FileName + ".xlsx");
                }
            }
        }

        [HttpPost]
        //[ValidateInput(false)]
        public FileResult ExportSummaryReport(string GridHtml)
        {
            string FileName = "Summary Report-" + DateTime.Now.Date;
            return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "" + FileName + ".xls");
        }

        #region Historical Report
        public IActionResult OrderReport()
        {
            ViewBag.ModuleName = "HistoricalReport";
            ViewBag.PageName = "OrderReport";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }

        public IActionResult ReceiptReport()
        {
            ViewBag.ModuleName = "HistoricalReport";
            ViewBag.PageName = "ReceiptReport";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }
        public IActionResult RequistionReport()
        {
            ViewBag.ModuleName = "HistoricalReport";
            ViewBag.PageName = "RequistionReport";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }
            var menuList = HttpContext.Session.GetObjectFromJson<List<MenuMaster>>("menuList");
            bool returnValue = CheckPageAccess.PageAccess(HttpContext.Request.Path, menuList);
            if (returnValue == false)
            {
                return Redirect("~/Auth/UnAuthorizedPage");
            }
            return View();
        }



        [HttpPost]
        public JsonResult GetHistoricalReport(HistoricalReportDTO historicalReportDTO)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                historicalReportDTO.LoginID = loggedInUser.EmployeeId;
                historicalReportDTO.CurrentRole = loggedInUser.CurrentRoleName;

            }
            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();

            string fromDate = string.Empty;
            string toDate = string.Empty;
            if (!string.IsNullOrEmpty(historicalReportDTO.FromDate))
            {
                dtFrom = Convert.ToDateTime(historicalReportDTO.FromDate);
                fromDate = dtFrom.ToString("yyyy-MM-dd");
            }
            if (!string.IsNullOrEmpty(historicalReportDTO.FromDate))
            {
                dtTo = Convert.ToDateTime(historicalReportDTO.ToDate);
                toDate = dtTo.ToString("yyyy-MM-dd");
            }

            if (historicalReportDTO.ReportName == "OrderReport")
            {
                if (dtFrom > dtTo)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid date range selected!";
                    return Json(response);
                }

                TimeSpan difference = dtTo - dtFrom;

                if (difference.TotalDays > 180)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    return Json(response);
                }
            }
            if (historicalReportDTO.ReportName == "ReceiptReport")
            {
                if (Convert.ToString(historicalReportDTO.CustomParam2) == "3" || Convert.ToString(historicalReportDTO.CustomParam2) == "4")
                {
                    if (dtFrom > dtTo)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid date range selected!";
                        return Json(response);
                    }
                    TimeSpan difference = dtTo - dtFrom;
                    if (difference.TotalDays > 180)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                        return Json(response);
                    }
                }

            }
            response = _ReportBL.GetHistoricalReport(historicalReportDTO);
            return Json(response);

        }

        [HttpPost]

        public FileResult ExportOrderReport(string OrderID, string fromDate, string toDate)
        {
            string GridHtml = string.Empty;
            string FileName = "Order Report -" + DateTime.Now.Date + "_" + DateTime.Now.Hour  + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + "_" + DateTime.Now.Millisecond;

            ResponseClass response = new ResponseClass();
            HistoricalReportDTO historicalReportDTO = new HistoricalReportDTO();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                historicalReportDTO.LoginID = loggedInUser.EmployeeId;
                historicalReportDTO.CurrentRole = loggedInUser.CurrentRoleName;
            }

            DataTable dt = new DataTable("Grid");
            historicalReportDTO.PageNumber = -1;
            historicalReportDTO.ReportName = "OrderReport";
            historicalReportDTO.RowsOfPage = 20;
            historicalReportDTO.FromDate = fromDate;
            historicalReportDTO.ToDate = toDate;
            historicalReportDTO.CustomParam1 = OrderID;
            
            response = _ReportBL.GetHistoricalReport(historicalReportDTO);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    dt = GetJSONToDataTableUsingMethod(response.responseJSON.ToString());
                }

            }
            dt.TableName = "ORderReport";
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "" + FileName + ".xlsx");
                }
            }

            //return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "" + FileName + ".xls");
        }

        [HttpPost]
        public FileResult ExportReceiptReport(string OrderID, string hdddlSearchBy, string fromDate, string toDate)
        {
            string GridHtml = string.Empty;
            string FileName = "Receipt Report -" + DateTime.Now.Date + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + "_" + DateTime.Now.Millisecond;

            ResponseClass response = new ResponseClass();
            HistoricalReportDTO historicalReportDTO = new HistoricalReportDTO();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                historicalReportDTO.LoginID = loggedInUser.EmployeeId;
                historicalReportDTO.CurrentRole = loggedInUser.CurrentRoleName;
            }

            DataTable dt = new DataTable("Grid");
            historicalReportDTO.PageNumber = -1;
            historicalReportDTO.ReportName = "ReceiptReport";
            historicalReportDTO.RowsOfPage = 20;
            historicalReportDTO.FromDate = fromDate;
            historicalReportDTO.ToDate = toDate;
            historicalReportDTO.CustomParam1 = OrderID;
            historicalReportDTO.CustomParam2 = hdddlSearchBy;
            response = _ReportBL.GetHistoricalReport(historicalReportDTO);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    dt = GetJSONToDataTableUsingMethod(response.responseJSON.ToString());
                }

            }
            dt.TableName = "ReceiptReport";
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "" + FileName + ".xlsx");
                }
            }

            //return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "" + FileName + ".xls");
        }

        [HttpPost]
        public FileResult ExportRequistionReport(string hdddlStatus, string fromDate, string toDate)
        {
            string GridHtml = string.Empty;
            string FileName = "Requistion Report -" + DateTime.Now.Date + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + "_" + DateTime.Now.Millisecond;

            ResponseClass response = new ResponseClass();
            HistoricalReportDTO historicalReportDTO = new HistoricalReportDTO();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                historicalReportDTO.LoginID = loggedInUser.EmployeeId;
                historicalReportDTO.CurrentRole = loggedInUser.CurrentRoleName;
            }

            DataTable dt = new DataTable("Grid");
            historicalReportDTO.PageNumber = -1;
            historicalReportDTO.ReportName = "RequistionReport";
            historicalReportDTO.RowsOfPage = 20;
            historicalReportDTO.FromDate = fromDate;
            historicalReportDTO.ToDate = toDate;
            historicalReportDTO.CustomParam1 = hdddlStatus;

            response = _ReportBL.GetHistoricalReport(historicalReportDTO);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    dt = GetJSONToDataTableUsingMethod(response.responseJSON.ToString());
                }

            }
            dt.TableName = "RequistionReport";
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "" + FileName + ".xlsx");
                }
            }

            //return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "" + FileName + ".xls");
        }
        #endregion

        #region Dashboard Report
        [HttpPost]
        public JsonResult GetDashboardData(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                userDashboardRequestDTO.LoginID = loggedInUser.EmployeeId;
                userDashboardRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;

            }
            response = _ReportBL.GetUserDashboard(userDashboardRequestDTO);
            return Json(response);

        }

        [HttpPost]
        public JsonResult GetLatestPR(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<WaitingApprovalResponceDTO> waitingApproval = new List<WaitingApprovalResponceDTO>();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                userDashboardRequestDTO.LoginID = loggedInUser.EmployeeId;
                userDashboardRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;

            }
            response = _ReportBL.GetUserDashboard(userDashboardRequestDTO);
            if (response.responseCode==1 )
            {
                try
                {
                    waitingApproval = _ReportBL.GetLatestPRDashboard(userDashboardRequestDTO);
                    if (waitingApproval!=null && waitingApproval.Count>0)
                    {
                        foreach (var item in waitingApproval)
                        {
                            item.AmountToShow = CurrencyConversion.FormatCurrency(item.Currency, item.Amount);
                        }
                    }
                }
                catch (Exception)
                {

                    
                }
            }

            response.responsedynamic = waitingApproval;
            return Json(response);

        }

        #endregion

        #region RD Access

        [HttpPost]
        public JsonResult GetRDAccress(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                userDashboardRequestDTO.LoginID = loggedInUser.EmployeeId;
                userDashboardRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;

            }
            response = _ReportBL.GetRDAccress(userDashboardRequestDTO);
            try
            {
                
                if (response.prList != null && response.prList.Count > 0)
                {
                    foreach (var item in response.prList)
                    {
                        item.AmountToShow = CurrencyConversion.FormatCurrency(item.Currency, item.Amount);
                    }
                }
            }
            catch (Exception)
            {


            }
            return Json(response);

        }

        [HttpPost]
        public JsonResult GetPRList(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<WaitingApprovalResponceDTO> waitingApproval = new List<WaitingApprovalResponceDTO>();
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser != null && loggedInUser.UserId > 0)
            {
                userDashboardRequestDTO.LoginID = loggedInUser.EmployeeId;
                userDashboardRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;

            }
            //response.responseCode = 1;

            response = _ReportBL.GetRDAccress(userDashboardRequestDTO);
            if (response.responseCode == 1)
            {
                try
                {
                    waitingApproval = _ReportBL.GetRDAccessPRList(userDashboardRequestDTO);
                    if (waitingApproval != null && waitingApproval.Count > 0)
                    {
                        foreach (var item in waitingApproval)
                        {
                            item.AmountToShow = CurrencyConversion.FormatCurrency(item.Currency, item.Amount);
                        }
                    }
                }
                catch (Exception)
                {


                }
            }

            response.responsedynamic = waitingApproval;
            return Json(response);

        }

        #endregion

        #region  Workflow Summary

        public IActionResult Workflow()
        {
            ViewBag.ModuleName = "Report";
            ViewBag.PageName = "WorkFlow Summary";
            var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            if (loggedInUser == null)
            {
                return Redirect("~/Auth/Index");
            }

            return View();
        }

        [HttpPost]
        public JsonResult GetWorkFlowReport(WorkflowReportrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            //var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
            //if (loggedInUser != null && loggedInUser.UserId > 0)
            //{
            //    userDashboardRequestDTO.LoginID = loggedInUser.EmployeeId;
            //    userDashboardRequestDTO.CurrentRole = loggedInUser.CurrentRoleName;

            //}
            response = _ReportBL.GetWorkFlowReport(request);
            
            return Json(response);

        }

        [HttpPost]
        //[ValidateInput(false)]
        public FileResult ExportWorkFlowReport(string GridHtml)
        {
            string FileName = "WorkFlow Report-" + DateTime.Now.Date;
            return File(Encoding.ASCII.GetBytes(GridHtml), "application/vnd.ms-excel", "" + FileName + ".xls");
        }

        #endregion
    }


}
