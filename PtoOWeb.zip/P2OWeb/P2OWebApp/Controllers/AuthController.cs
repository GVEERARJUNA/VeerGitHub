﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OWebApp.Extensions;
using P2OWebApp.Models;
using P2OWebApp.Models.AdminManagement;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.SessionManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Controllers
{
    public class AuthController : Controller
    {
        private readonly IOptions<IDBConnection> appSettings;
        private readonly ILogger<AuthController> _logger;
        private readonly ILoginRequestBL _LoginRequestBL;
        public AuthController(ILogger<AuthController> logger, ILoginRequestBL loginRequestBL,
            IOptions<IDBConnection> appSettings
            )
        {
            _logger = logger;
            _LoginRequestBL = loginRequestBL;
            this.appSettings = appSettings;
        }

        public IActionResult Index(string eid,string masterlogin)
        {
           
            if (!string.IsNullOrEmpty(eid))
            {
                CommonFunction commonFunction = new CommonFunction();
                LoginRequest login = new LoginRequest();
                
                try
                {
                    login.UserName = commonFunction.Decrypt(eid);
                    var response = _LoginRequestBL.UserLogin(login);
                    if (response.responseCode != 1)
                    {
                        return Redirect("~/Auth/UnAuthorized");

                    }
                    else
                    {
                        // set session
                        var employee = new List<LoggedInUserModel>();

                        employee = JsonConvert.DeserializeObject<List<LoggedInUserModel>>(response.responseJSON.ToString());

                        HttpContext.Session.SetObjectAsJson("EmployeeDetails", employee[0]);

                        try
                        {
                            var userRight = new List<UserRight>();

                            userRight = JsonConvert.DeserializeObject<List<UserRight>>(response.responseJSONSecondary.ToString());

                            HttpContext.Session.SetObjectAsJson("UserRight", userRight);
                        }
                        catch
                        {


                        }

                        var loggedInUser = HttpContext.Session.GetObjectFromJson<LoggedInUserModel>("EmployeeDetails");
                        if (loggedInUser != null && loggedInUser.UserId > 0)
                        {
                            return Redirect("~/Home/Index");
                        }

                        //return Json(response);
                    }
                }
                catch (Exception)
                {

                    return Redirect("~/Auth/UnAuthorized");
                }
               
               
            }
            else
            {
                if (!string.IsNullOrEmpty(masterlogin) && masterlogin== "vs5iv5p2")
                {
                    return View();
                }
                else
                {
                    if (appSettings.Value.isRedirect==1)
                    {
                        return Redirect(appSettings.Value.RedirectLink);
                    }
                    //string Path = HttpContext.Request.Host.ToString();
                    //if (Path.Contains("hgsconnect.teamhgs.com"))
                    //{
                    //    return Redirect("https://hgsconnect.teamhgs.com");
                    //}
                }


               

            }

            return View();

        }

        public JsonResult LoginAuth(LoginRequest login)
        {
            ResponseClass responseclass = new ResponseClass();
            if (login == null || string.IsNullOrEmpty(login.UserName))
            {
                responseclass.responseCode = 0;
                responseclass.responseMessage = "Please provide username!";
                return Json(responseclass);
               
            }

            string responseToView = string.Empty;
            var response = _LoginRequestBL.UserLogin(login);
            if (response.responseCode != 1)
            {
                return Json(response); ;

            }
            else
            {
                // set session
                var employee = new List<LoggedInUserModel>();

                employee = JsonConvert.DeserializeObject<List<LoggedInUserModel>>(response.responseJSON.ToString());

                HttpContext.Session.SetObjectAsJson("EmployeeDetails", employee[0]);

                try
                {
                    var userRight = new List<UserRight>();

                    userRight = JsonConvert.DeserializeObject<List<UserRight>>(response.responseJSONSecondary.ToString());

                    HttpContext.Session.SetObjectAsJson("UserRight", userRight);
                }
                catch 
                {
                    

                }

                return Json(response);
            }
           
        }

        [HttpPost]
        public IActionResult IndexAuth(LoginRequest login)
        {
            string responseToView = string.Empty;
            //CommonFunction commonFunction = new CommonFunction();
            //string result = commonFunction.Encrypt(login.UserName);
            //ViewBag.ErrorMessage = result;
            //responseToView = "Index";
            //return View(responseToView);

            if (login == null || string.IsNullOrEmpty(login.UserName))
            {

                ViewBag.ErrorMessage = "Please enter username!";
                responseToView = "Index";
                return View(responseToView);
            }

            
            var response = _LoginRequestBL.UserLogin(login);
            if (response.responseCode != 1)
            {
                ViewBag.ErrorMessage = response.responseMessage;
                responseToView = "Index";

            }
            else
            {
                // set session
                var employee = new List<LoggedInUserModel>();

                employee = JsonConvert.DeserializeObject<List<LoggedInUserModel>>(response.responseJSON.ToString());

                HttpContext.Session.SetObjectAsJson("EmployeeDetails", employee[0]);
                try
                {
                    var userRight = new List<UserRight>();

                    userRight = JsonConvert.DeserializeObject<List<UserRight>>(response.responseJSONSecondary.ToString());

                    HttpContext.Session.SetObjectAsJson("UserRight", userRight);
                }
                catch
                {


                }

                return Redirect("~/Home/Index");
            }
            return View(responseToView);


        }

        public IActionResult logout()
        {
            HttpContext.Session.Clear();
            //string Path = HttpContext.Request.Host.ToString();
            //if (Path.Contains("hgsconnect.teamhgs.com"))
            //{
            //    return Redirect("https://hgsconnect.teamhgs.com");
            //}
            if (appSettings.Value.isRedirect == 1)
            {
                return Redirect(appSettings.Value.RedirectLink);
            }
            return View("Index");
        }

        public IActionResult UnAuthorized()
        {
           
            return View();
        }

        public IActionResult UnAuthorizedPage()
        {

            return View();
        }
    }
}
