﻿$(function () {
    var appUrl = 'https://hgsconnectbeta.teamhgs.com/P2OWEB/';

});
function loadMasterData(controlName, EntityName, SearchParameter1, SearchParameter2) {
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: { "EntityName": EntityName, "SearchParameter1": SearchParameter1, "SearchParameter2": SearchParameter2},
        success: function (data, textstatus) {

            if (data.responseCode == 1) {
                if (data.productList != '') {
                   
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#" + controlName).append($("<option></option>").val(item.valueField).text(item.displayField));
                       
                    });


                }
                else {
                    page = -1;
                }
            }
            else if (data.responseCode == 2) {
                location.href = appUrl +  "/Auth/Index";

            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            
        }
    });
}