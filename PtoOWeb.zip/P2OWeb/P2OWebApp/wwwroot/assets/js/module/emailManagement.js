﻿var appUrl = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    if (pageURL.indexOf('/EmailMaster/Index') != -1) {

       GetEmailManagementPageData(1, 20);

    }

    document.getElementById("updateButton").disabled = true;
    $("#updateButton").click(function () {
        UpdateEmailDetails();
    })

});
/*Material Master :*/
function GetEmailManagementPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#emailListSelect").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetEmailManagementSetting", // Controller/View
            data: null,
            success: function (pdata) {
                if (pdata.recordCount > 0 ) {
                    $.each(pdata.emailMGTResponses, function (i, item) {
                        var list = "<li value=" + item.emailMasterID + " onClick='GetEmailDetails(" + item.emailMasterID + ")' style='background-color: white;'>" + item.emailSubject + "</li>";

                        $("#emailListSelect").append(list);
                    });
                }
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });

}


function GetEmailDetails(emailId) {
    $('.loader-wrapper').show();

    $("#emailSubject").empty();
    $("#emailTemplate").empty();
    const parser = new DOMParser();

    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: "GetEmailManagementSetting", // Controller/View
            data: {
                "EmailMasterId": emailId
            },
            success: function (pdata) {
                if (pdata.recordCount > 0) {
                    $.each(pdata.emailMGTResponses, function (i, item) {
                        console.log(pdata.emailMGTResponses);
                        $("#emailMasterId").val(item.emailMasterID);
                        $("#emailSubject").val(item.emailSubject);
                        var htxt = parser.parseFromString(item.emailTemplate, 'text/html');
                        $("#emailTemplateDiv").html(htxt.body.innerHTML);
                    });
                }
                document.getElementById("updateButton").disabled = false;
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
}

function UpdateEmailDetails() {
    $('.loader-wrapper').show();

    var emailMasterId = $("#emailMasterId").val();
    var emailSubject = $("#emailSubject").val();
    var emailTemplate = $("#emailTemplateDiv").html().toString();
    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: "UpdateEmailManagementSetting", // Controller/View
            data: {
                "EmailMasterId": emailMasterId,
                "EmailSubject": emailSubject,
                "EmailTemplate": emailTemplate.toString(),
            },
            success: function (pdata) {
                if (pdata.responseCode > 0) {
                    alert("Saved Succefully.");
                    GetEmailDetails(emailMasterId);
                }
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
}

function MaterialPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetMaterialPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetMaterialPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetMaterialPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetMaterialPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetMaterialPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#materialPageList").append(template);
}

