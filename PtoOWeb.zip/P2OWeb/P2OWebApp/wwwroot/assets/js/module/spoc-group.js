﻿var appUrl = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
    $("#spocgroupBody").append($tr);
    getSPOCGroup();
});

function getSPOCGroup() {
    $("#spocgroupBody").empty();
    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: appUrl + "SPOCGroup/PRSPOCGroupManage", // Controller/View
            data: { "Action":"MANAGE"},
            success: function (result) {
                if (result.responseCode == 1) {
                    var jsonData = JSON.parse(result.responseJSON);
                    if (jsonData!="") {
                        $.each(jsonData, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(i+1),
                                $('<td>').text(item.PRSPOCGRoupTitle),

                                $('<td>').html('<a href="javascript:;" title="Manage Member" class="btn btn-success btn-sm me-2" data-toggle="model"  onclick="OpenManageMember(' + item.PRSPOCGRoupID  + ')"><i class="fas fa-plus"></i></a>'),
                            );
                            $("#spocgroupBody").append($tr);
                        });
                    }
                   


                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    $("#spocgroupBody").append($tr);
                }
               
                $('.loader-wrapper').hide();



            }

        });
}

function createGroup() {
    $("#addGroup").modal('show');
    $("#txtGroupName").val('');
}

function AddGroup() {
    if ($("#txtGroupName").val()=='') {
        alert("Group name required!");
        return false;
    }

    $('.loader-wrapper').show();
    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: appUrl + "SPOCGroup/PRSPOCGroupManage", // Controller/View
            data: { "Action": "ADDGROUP", "PRSPOCGroupTitle": $("#txtGroupName").val() },
            success: function (result) {
                if (result.responseCode == 1) {
                    alert("Group created successfully.");
                    $("#txtGroupName").val('');
                   
                    getSPOCGroup();
                    $("#addGroup").modal('hide');
                }
                else {

                    alert(result.responseMessage);
                }

                $('.loader-wrapper').hide();



            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
}

function OpenManageMember(spocGroup) {
    $("#configDetails").modal('show');
    $("#hidSPOCGroup").val(spocGroup);
    $("#txtCostSearchEmployee").val('');
    $("#selCostEmployee").empty();
    getSPOCGroupMembers(spocGroup);
}
function searchUserEmployee() {
    var searchString = $("#txtCostSearchEmployee").val();
    if (searchString == '') {
        alert("Please enter search text!");
        return false;

    }
    else if (searchString.length < 2) {
        alert("Please provide at least three characters to search!");
        return false;

    }
    $('.loader-wrapper').show();

    $("#selCostEmployee").empty();
    $("#selCostEmployee").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "CostSearchUser", "SearchParameter1": searchString
        },
        success: function (data, textstatus) {
            if (data.responseCode == 1) {

                $.each(data.masterDataResponses, function () {
                    $("#selCostEmployee").append($("<option />").val(this.valueField).text(this.displayField));
                });
            }

            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });


}

function getSPOCGroupMembers(spocGroup) {
    $("#bodyGroupMembers").empty();
    $('.loader-wrapper').show();
    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: appUrl + "SPOCGroup/PRSPOCGroupManage", // Controller/View
            data: { "Action": "GETMEMBER", "PRSPOCGroupID": spocGroup },
            success: function (result) {
                if (result.responseCode == 1) {
                    var jsonData = JSON.parse(result.responseJSON);
                    if (jsonData != "") {
                        $.each(jsonData, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td>').text(i + 1),
                                $('<td>').text(item.FullName),

                                $('<td>').html('<a href="javascript:;" title="Delete Member"  onclick="deletegroupMember(' + item.PRSPOCMemberID + ')"><i class="fas fa-trash-alt text-danger"></i></a>'),
                            );
                            $("#bodyGroupMembers").append($tr);
                        });
                    }



                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    $("#bodyGroupMembers").append($tr);
                }

                $('.loader-wrapper').hide();



            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
}
function AddMember() {
    //ADDMEMBER
    if ($("#selCostEmployee").val()==0) {
        alert("Please select employee!");
        return false;
    }
    $('.loader-wrapper').show();
    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: appUrl + "SPOCGroup/PRSPOCGroupManage", // Controller/View
            data: { "Action": "ADDMEMBER", "PRSPOCGroupID": $("#hidSPOCGroup").val(), "EmployeeID": $("#selCostEmployee").val() },
            success: function (result) {
                if (result.responseCode == 1) {
                    alert("Employee successfully added to group.");
                    $("#txtCostSearchEmployee").val('');
                    $("#selCostEmployee").empty();
                    getSPOCGroupMembers($("#hidSPOCGroup").val());
                }
                else {
                    
                    alert(result.responseMessage);
                }

                $('.loader-wrapper').hide();



            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
}

function deletegroupMember(member) {
    if (member==0 || member=='' || member==undefined) {
        alert("member id required!");
        return false;
    }
    if (confirm('Do you want to delete member?')) {
        $('.loader-wrapper').show();
        $.ajax(
            {
                type: "POST", //HTTP POST Method  
                url: appUrl + "SPOCGroup/PRSPOCGroupManage", // Controller/View
                data: { "Action": "DELETEMEMBER", "PRSPOCMemberID": member },
                success: function (result) {
                    if (result.responseCode == 1) {
                        
                        $("#txtCostSearchEmployee").val('');
                        $("#selCostEmployee").empty();
                        getSPOCGroupMembers($("#hidSPOCGroup").val());
                    }
                    else {

                        alert(result.responseMessage);
                    }

                    $('.loader-wrapper').hide();



                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('.loader-wrapper').hide();
                }
            });
    }
   
}