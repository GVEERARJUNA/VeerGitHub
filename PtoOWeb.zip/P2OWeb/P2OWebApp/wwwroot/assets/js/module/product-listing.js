﻿var appUrl = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    $("div#loading").hide();
    loadProducts(ajaxCallUrl);
    $(window).scroll(scrollHandler);
});

var ajaxCallUrl = appUrl + 'ProductList',
    page = 0,
    inCallback = false,
    isReachedScrollEnd = false;


var scrollHandler = function () {
    if (isReachedScrollEnd == false &&
        ($(document).scrollTop() <= $(document).height() - $(window).height())) {
        loadProducts(ajaxCallUrl);
    }
}
function loadProducts(ajaxCallUrl) {
    if (page > -1 && !inCallback) {
        inCallback = true;
        page++;
        $("div#loading").show();
        $.ajax({
            type: 'GET',
            url: ajaxCallUrl,
            data: "pageNumber=" + page,
            success: function (data, textstatus) {
                
                if (data.responseCode == 1) {
                    if (data.productList != '') {

                        $.each(data.productList, function (i, item) {

                            var $div = $('<div class="col-md-3">');
                            var $productcard = $('<div class="card product-card">');
                            var $productImage = $('<div class="product-image">');
                            var productImageURL = appUrl + 'assets/images/products/HP-14s-11th--Gen.png';
                            $productImage = $productImage.append('<img src=' + productImageURL + ' class="img - fluid">');

                            $productcard = $productcard.append($productImage);

                            var $productOverview = $('<div class="product-overview">');
                            var $productDesc = $('<div class="product-desc"><p>' + item.productDescription + '</p>');
                            var $productPrice = $('<div class="product-price" <h6><i class="fas fa-inr"></i>' + item.price + '</h6>');
                            var $productButton = $('<div class="product-button"><a href="/PurchaseRequistion" class="btn btn-primary"> Create PR</a>');

                            $productOverview = $productOverview.append($productDesc);
                            $productOverview = $productOverview.append($productPrice);
                            $productOverview = $productOverview.append($productButton);

                            $productcard = $productcard.append($productOverview);

                            $div = $div.append($productcard);


                            $("#productList").append($div);
                        });


                    }
                    else {
                        page = -1;
                    }
                }
                else if (data.responseCode == 2) {
                    location.href = appUrl +  "Auth/Index";

                }

                

                inCallback = false;
                $("div#loading").hide();
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert(errorThrown);
            }
        });
    }
}