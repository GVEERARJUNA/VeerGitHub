﻿var appUrl = '';
$(function () {
    $(window).on('load', function () {

        $('.loader-wrapper').hide();

        $("#UserName").focus();

    });
    
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    $("#btnLogin").click(function () {
        $('.loader-wrapper').show();
        $.ajax({
            type: 'POST',

            url: appUrl + 'Auth/LoginAuth',
            data: { "UserName": $("#UserName").val() },
            success: function (data, textstatus) {
                $('.loader-wrapper').hide();
                if (data.responseCode == 1) {
                    location.href = appUrl + "Home/Index";
                }
                else {
                    alert(data.responseMessage);

                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
    });



});

