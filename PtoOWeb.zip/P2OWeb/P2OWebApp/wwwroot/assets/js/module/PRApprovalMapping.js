﻿var appUrl = '';
var addedLevel = [];
$(document).ready(function () {
    $("#manageLevelData").hide();
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    $("#txtRequistionNo").focus();

});

function searchPRData() {
    var requistionNo = $("#txtRequistionNo").val();
    if (requistionNo == "") {
        alert("Please enter requistion no!");
        $("#txtRequistionNo").focus();
        return false;
    }

    $('.loader-wrapper').show();
    $("#bodyfiles").empty();
    
    $.ajax(
        {
            type: "POST",
            url: appUrl + "ApprovalMapping/ManageApplicatonHierarchy",
            dataType: "JSON",
            data: { "Action": "PRDETAILS", "RequistionNo": $("#txtRequistionNo").val() },
            success: function (data) {
                if (data.responseCode == 1) {

                    var parsedLevelData = JSON.parse(data.responseJSON);

                    addedLevel = parsedLevelData;

                    $.each(parsedLevelData, function (i, item) {

                        var dropdown = '';
                        var deletedRow = '';

                        if (item.ApprovedStatus != "Approved") {

                            var ddID = 'ddl' + item.PRApprovalMatrixID;

                            dropdown = "<select id='" + ddID + "'>";

                            var startLevel = item.MaxApprovedLevel;

                            for (var q = startLevel; q <= 20; q++) {

                                if (q == item.ApprovalLevel) {
                                    dropdown = dropdown + "<option value=" + q + " selected>" + q + "</option>";
                                }
                                else {
                                    dropdown = dropdown + "<option value=" + q + ">" + q + "</option>";
                                }

                            }

                            dropdown = dropdown + "</select>";

                            deletedRow = '&nbsp; <a href="#" onclick=removePRLevel(' + item.PRApprovalMatrixID + ')> <i class="fa-solid fa-trash-can"></i></a>';
                        }
                        else {
                            dropdown = item.ApprovalLevel;
                            deletedRow = '';
                        }
                        

                        
                        
                        var $tr = $('<tr>').append(
                            $('<td>').text(i + 1),
                            $('<td>').html(dropdown),
                            $('<td>').text(item.ApprovalName),
                            $('<td>').text(item.ApprovedStatus),
                            $('<td >').html(deletedRow),
                            
                        );
                        $("#bodyfiles").append($tr);
                    });

                    $("#manageLevelData").show();

                    $("#txtRequistionNo").prop("disabled", true);

                    $("#levelApproval").focus();

                }
                else {
                    alert(data.responseMessage);
                    $("#manageLevelData").hide();
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}

function addLevel() {

    var requistionNo = $("#txtRequistionNo").val();
    if (requistionNo == "") {
        alert("Please enter requistion no!");
        return false;
    }

    var appLevel = $("#SelectLevel").val();
    if (appLevel == "0") {
        alert("Please select Level!");
        return false;
    }
    var empCode = $("#txtEmployee").val();
    if (empCode == "") {
        alert("Employee Code Required!");
        return false;
    }

    $('.loader-wrapper').show();

    $.ajax(
        {
            type: "POST",
            url: appUrl + "ApprovalMapping/ManageApplicatonHierarchy",
            dataType: "JSON",
            data: { "Action": "PRLEVELADD", "RequistionNo": $("#txtRequistionNo").val(), "AppLevel": appLevel, "EMPCode": empCode },
            success: function (data) {
                if (data.responseCode == 1) {
                    $("#SelectLevel").val("0");
                    $("#txtEmployee").val("");
                    searchPRData();
                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}

function resetControl() {
    
    $("#txtRequistionNo").prop("disabled", false);
    $("#txtRequistionNo").focus();
    $("#bodyfiles").empty();
    $("#SelectLevel").val("0");
    $("#txtEmployee").val("");
    $("#txtRequistionNo").val("");
    $("#manageLevelData").hide();

    addedLevel = [];
}

function savePRHierarchy() {
    var requistionNo = $("#txtRequistionNo").val();
    if (requistionNo == "") {
        alert("Please enter requistion no!");
        $("#txtRequistionNo").focus();
        return false;
    }

    if (addedLevel.length==0) {
        alert("Please search requistion data first!");
        $("#txtRequistionNo").focus();
        return false;
    }

    var confirmText = 'Do you want to update details?';
    if (confirm(confirmText)) {
        var pRApprovalMatrices = [];
        for (var i = 0; i < addedLevel.length; i++) {

            if (addedLevel[i].ApprovedStatus != "Approved") {

                var selectedValue = $("#ddl" + addedLevel[i].PRApprovalMatrixID).val();
                //alert(selectedValue);
                pRApprovalMatrices.push({ "PRApprovalMatrixID": addedLevel[i].PRApprovalMatrixID, "ApprovalLevel": selectedValue, "updateRequired": 1, "ApprovalName": addedLevel[i].ApprovalName });
            }
            else {
                pRApprovalMatrices.push({ "PRApprovalMatrixID": addedLevel[i].PRApprovalMatrixID, "ApprovalLevel": addedLevel[i].ApprovalLevel, "updateRequired": 0, "ApprovalName": addedLevel[i].ApprovalName  });
            }
        }

            $('.loader-wrapper').show();

            $.ajax(
                {
                    type: "POST",
                    url: appUrl + "ApprovalMapping/ManageApplicatonHierarchy",
                    dataType: "JSON",
                    data: { "Action": "PRMAppingEDIT", "RequistionNo": $("#txtRequistionNo").val(), "pRApprovalMatrices": pRApprovalMatrices,"existingData":addedLevel },
                    success: function (data) {
                        if (data.responseCode == 1) {
                            $("#SelectLevel").val("0");
                            $("#txtEmployee").val("");
                            searchPRData();
                        }
                        else {
                            alert(data.responseMessage);
                        }

                        $('.loader-wrapper').hide();

                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        $('.loader-wrapper').hide();
                    }
                }
            );

        //var tb = $("#bodyfiles");
        //tb.find("tr").each(function (index, element) {
        //    var colSize = $(element).find('td').length;

        //    var objKey = '';
        //    var objValue = '';

        //    $(element).find('td').each(function (tdindex, element) {
        //        //var colVal = $(element).text();
        //        //alert(colVal);

        //        if (tdindex == 1) {
        //            let result = $(element).html().includes("select");
        //            alert(result);
        //            //objKey = $(element).text();
        //        }
        //        //if (index == 1) {
        //        //    objValue = $("#ddl" + objKey).val();
        //        //    //alert(objValue);
        //        //}
        //    });


        //});

    }


    
}

function removePRLevel(approvalMatrixID) {
    if (confirm('Do you want to delete details?')) {


        $('.loader-wrapper').show();
        //var pRApprovalMatrices = [];
        //for (var i = 0; i < addedLevel.length; i++) {

        //    if (addedLevel[i].ApprovedStatus != "Approved") {

        //        var selectedValue = $("#ddl" + addedLevel[i].PRApprovalMatrixID).val();
        //        //alert(selectedValue);
        //        pRApprovalMatrices.push({ "PRApprovalMatrixID": addedLevel[i].PRApprovalMatrixID, "ApprovalLevel": selectedValue, "updateRequired": 1 });
        //    }
        //    else {
        //        pRApprovalMatrices.push({ "PRApprovalMatrixID": addedLevel[i].PRApprovalMatrixID, "ApprovalLevel": addedLevel[i].ApprovalLevel, "updateRequired": 0 });
        //    }
        //}


        $.ajax(
            {
                type: "POST",
                url: appUrl + "ApprovalMapping/ManageApplicatonHierarchy",
                dataType: "JSON",
                data: { "Action": "DELETEPRLevel", "AppHierarchyID": approvalMatrixID},
                success: function (data) {
                    if (data.responseCode == 1) {
                        alert("Deleted Successfully!");
                        searchPRData();
                    }
                    else {
                        alert(data.responseMessage);
                    }

                    $('.loader-wrapper').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('.loader-wrapper').hide();
                }
            }
        );

    }

}