﻿var appUrl = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    
    appUrl = setAppUrl();

    BindApprovalNames();
});

function BindApprovalNames() {
    var approvers = $('#approverName');
    approvers.empty();
    $.getJSON("/ApprovalMapping/GetApprovelName", function (listobj) {
        if (listobj != null && !jQuery.isEmptyObject(listobj)) {
            //alert(approvers);
            $.each(listobj, function (index, appr) {
                $("#approverName").append($("<option />").val(appr.value).text(appr.text));

            });
        }
    });
    return;
}

/* Start Email matrix*/

var levelCount = 1
$(document).on('click', '.approverlevel', function (e) {
    e.preventDefault();
    levelCount++;
    alert(levelCount);
    if (levelCount <= 4) {
        var newRow = $(`
    <div>
    <hr class="light-border">
    <div class="row">
    <div class="col">
        <label class="form-label mb-1">Level `+ levelCount + ` Type</label>
        <select class="customSelect">
            <option>Select</option>
            <option>Individual</option>
            <option>Role</option>
        </select>
    </div>
    <div class="col">
        <label class="form-label mb-1">Level `+ levelCount + ` User</label>
        <select class="customSelect">
            <option>Select</option>
            <option>Shyam</option>
            <option>Sanjay</option>
            <option>Ekata</option>
        </select>
    </div>
    <div class="col">
        <label class="form-label mb-1">Level `+ levelCount + ` Esclation</label>
        <div class="d-flex esc-days">
            <input type="text"
                class="form-control form-control-sm">
            <span class="ms-2 mt-2">Days</span>
        </div>
    </div>
    <div class="col">       
        <a class="mt-1 btn btn-danger btn-sm DeleteApproverlevel mt-3"><i class="fa-solid fa-trash-can"></i></a>
    </div>
</div></div>`);

    }

    $(this).parent().parent().parent().parent().find('.approverlevelWrapper').append(newRow);
    function explode() {
        selectInit();
    }
    setTimeout(explode, 300);
});

$(document).on('click', '.DeleteApproverlevel', function (e) {
    e.preventDefault();
    $(this).parent().parent().parent().remove();
    selectInit();
});


$(document).on('click', '#addApprover', function (e) {
    e.preventDefault();
    levelCount = 1;
    var newRow = $(`<tr>
    <td>
        <label class="form-label mb-1">Approver Name</label>
        <select class="customSelect">
            <option>Select</option>
            <option>Shyam</option>
            <option>Sanjay</option>
            <option>Ekata</option>
        </select>
    </td>
    <td>
        <div class="container-fluid approverlevelWrapper">
            <div class="row">
                <div class="col">
                    <label class="form-label mb-1">Level 1 Type</label>
                    <select class="customSelect">
                        <option>Select</option>
                        <option>Individual</option>
                        <option>Role</option>
                    </select>
                </div>
                <div class="col">
                    <label class="form-label mb-1">Level 1 User</label>
                    <select class="customSelect">
                        <option>Select</option>
                        <option>Shyam</option>
                        <option>Sanjay</option>
                        <option>Ekata</option>
                    </select>
                </div>
                <div class="col">
                    <label class="form-label mb-1">Level 1 Esclation</label>
                    <div class="d-flex esc-days">
                        <input type="text"
                            class="form-control form-control-sm">
                        <span class="ms-2 mt-2">Days</span>
                    </div>
                </div>
                <div class="col">
                    <a href="#"
                        class="btn btn-sm btn-success mt-4 approverlevel">
                        <i class="fa-solid fa-plus"></i></a>
                </div>
            </div>
        </div>
    </td>
</tr>`);
    $('#EscMatrix tbody').append(newRow);
    function explode() {
        selectInit();
    }
    setTimeout(explode, 300);

});

function saveEmailEscMatrix() {

    var selectedValue = $("#approverName option:selected").val();
    var approvers = $('#approverName');
    approvers.empty();
    alert(selectedValue);
    $.ajax(
        {
            
            type: "POST", //HTTP POST Method
            url: appUrl + "ApprovalMapping/SaveEmailEscMatrix", // Controller/View
            data: {
                "costCenterAPRequestLists": selectedValue, "approvalLevelRequestLists": "sdfsdf"
            },
            success: function (result) {

                if (result.responseCode == 1) {

                    alert(result.responseMessage);

                    //GetCompanyDDLData();

                    searchCostCenter();

                    addedLevel = [];

                    bindLevelData();


                    //$("#ulAssignedList").empty();
                }
                else if (result.responseCode == 0) {
                    alert(result.responseMessage);
                }
                else if (result.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";
                }

                //$('.loader-wrapper').hide();



            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        });
    BindApprovalNames();
    alert(selectedValue);
    //$("#approverName").val(selectedValue);
    $("#approverName").val(selectedValue).change();
    //$('#approverName option[value=selectedValue]').attr("selected", "selected");
}
