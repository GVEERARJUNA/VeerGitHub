﻿var appUrl = '';
var appCurrentSelction = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
   // getLatestPR(1);
    
    bindCompany();
    bindFilterBy();
    
    //$("#divCompany").hide();
    $("#divFilterDropDown").hide();
    $("#divFilterTextBox").hide();
    $("#ddlCompany").change(function () {
        if ($("#ddlCompany").val() != "0") {
            if ($("#ddlFilterBy").val() == "2" || $("#ddlFilterBy").val() == "3" || $("#ddlFilterBy").val() == "4" ) {

                bindSearchFilterValues();
            }
            
        }
    });

    $("#ddlFilterBy").change(function () {
        
        //bindSearchFilterValues();
        if ($("#ddlFilterBy").val() == "1") {
            $("#divCompany").show();
            $("#divFilterDropDown").hide();
            $("#divFilterTextBox").hide();
        }
        else if ($("#ddlFilterBy").val() == "2") {
            $("#divCompany").show();
            $("#divFilterDropDown").show();
            bindSearchFilterValues();
            $("#divFilterTextBox").hide();
        }
        else if ($("#ddlFilterBy").val() == "3") {
            $("#divCompany").show();
            $("#divFilterDropDown").show();
            bindSearchFilterValues();
            $("#divFilterTextBox").hide();
        }
        else if ($("#ddlFilterBy").val() == "4") {
            $("#divCompany").show();
            $("#divFilterDropDown").show();
            bindSearchFilterValues();
            $("#divFilterTextBox").hide();
        }
        else if ($("#ddlFilterBy").val() == "5") {
            $("#divCompany").hide();
            $("#divFilterDropDown").hide();
            $("#ddlFilterValue").empty();
            $("#divFilterTextBox").show();
        }

    });

    function selectPicker2() {
        $(".selectPicker2").select2();
    }
    selectPicker2();

});
function getRDAccess(pagenum) {


    let fromDate = $("#fromDateTop").val();
    let toDate = $("#toDateTop").val();

    var scriteria1 = '';
    var scriteria2= '';

    if ($("#ddlFilterBy").val() == "1") {
        
        if ($("#ddlCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }

        scriteria1 = $("#ddlCompany").val();
    }
    else if ($("#ddlFilterBy").val() == "2") {
        if ($("#ddlCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }
        if ($("#ddlFilterValue").val() == "0") {
            alert("Please select filter value!");
            return false;
        }
        scriteria1 = $("#ddlCompany").val();
        scriteria2 = $("#ddlFilterValue").val();
    }
    else if ($("#ddlFilterBy").val() == "3") {
        if ($("#ddlCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }
        if ($("#ddlFilterValue").val() == "0") {
            alert("Please select filter value!");
            return false;
        }
        scriteria1 = $("#ddlCompany").val();
        scriteria2 = $("#ddlFilterValue").val();
    }
    else if ($("#ddlFilterBy").val() == "4") {
        if ($("#ddlCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }
        if ($("#ddlFilterValue").val() == "0") {
            alert("Please select filter value!");
            return false;
        }
        scriteria1 = $("#ddlCompany").val();
        scriteria2 = $("#ddlFilterValue").val();
    }
    else if ($("#ddlFilterBy").val() == "5") {
       
        if ($("#txtFilterValue").val() == "0" || $("#txtFilterValue").val()=="") {
            alert("Please enter PR No!");
            return false;
        }
        scriteria2 = $("#txtFilterValue").val();
    }

    $('.loader-wrapper').show();
    $("#geoWisePRDetails").empty();
    $("#PRbarChart").empty;

    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GetRDAccress',
            dataType: "JSON",
            data: {
                "ReportType": "HeaderCount", "FromDate": fromDate, "ToDate": toDate,
                "SearchCriteria1": $("#ddlFilterBy").val(),
                "SearchCriteria2": scriteria1,
                "SearchCriteria3": scriteria2,
                "PageNumber": pagenum, "RowsOfPage": 30
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData != undefined) {

                        $("#lblTotalPRCount").html(reportData[0].TotalPRRequested);
                        $("#lblTotalInprogress").html(reportData[0].TotalPRWIP);
                        $("#lblTotalPRApproved").html(reportData[0].TotalPOWIP);
                        $("#lblTotalPOCreated").html(reportData[0].TotalPOCREATED);
                        
                        $("#lblTotalCancelled").html(reportData[0].TotalCancelled);

                       
                        
                    }

                    if (data.prList != undefined) {

                        $("#prListBody").empty();

                        $("#pageList").empty();
                        if (data.prList.length>0) {
                            $.each(data.prList, function (i, item) {
                                var PRID = item.purchaseRequistionID;
                                var $maindiv = $('<div class="card pr-card-panel pending">');
                                var $div = $('<div class="card-header shadow">');
                                var $productcard = $('<div class="d-flex justify-content-between header-border">');
                                var $flexDiv = $('<div class="d-flex">');
                                $flexDiv = $flexDiv.append('<h3>HGS_PR # ' + item.requistionNo + '</h3><p>Created on : ' + item.insertedDateTime + '</p>');

                                $productcard = $productcard.append($flexDiv);
                                var $flexDivStatus = $('<div class="d-flex float-end pr-status">');
                                $flexDivStatus = $flexDivStatus.append('Current Status');
                                var $flexDivStatusButton = $('<div class="btn-status">');
                                $flexDivStatusButton = $flexDivStatusButton.append('<a href="#" class="btn btn-primary btn-xm">' + item.status + '</a>');
                                $flexDivStatus = $flexDivStatus.append($flexDivStatusButton);
                                $productcard = $productcard.append($flexDivStatus);
                                $div = $div.append($productcard);

                                var $rowprData = $('<div class="row pr-data">');
                                $rowprData.append(
                                    $('<div class="col">').html("<label>Cost Centre:</label><div>" + item.costCenterName + "</div>"),
                                    $('<div class="col">').html("<label>Company:</label><div>" + item.company + "</div>"),
                                    $('<div class="col">').html("<label>Amount:</label><div>" + item.amountToShow + "</div>"),
                                    $('<div class="col">').html("<label>Quantity:</label><div>" + item.quantity + "</div>"),
                                    $('<div class="col">').html("<label>Plant Code:</label><div>" + item.plantCode + "</div>"),
                                    $('<div class="col">').html("<label>Purchasing Org:</label><div>" + item.purchasingOrg + "</div>"),
                                    $('<div class="col">').html('<div class="showhide-pr"> <a href="#" class="tableShowDetailsDashboard" onclick="View(' + item.purchaseRequistionID + ')"><span>View Details</span> <i class="fa-solid fa-circle-chevron-down"></i></a></div>'),

                                );
                                $div = $div.append($rowprData);
                                var $hiddenTR = $('<div id="hid' + item.purchaseRequistionID + '" class="card-body hiddenTR ps-0 pe-0 pb-0 shadow">');
                                var $md12Div = $('<div class="col-md-12">');
                                var $ul = $('<ul id="myTab" role="tablist" class="nav nav-tabs cart-tab">');
                                $ul.append(
                                    $('<li class="nav-item" role="presentation">').html('<button class="nav-link active " id="first-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#first-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="first-tab-pane-' + PRID + '" aria-selected="true"> Requisition Details </button>'),
                                    $('<li class="nav-item" role="presentation">').html('<button class="nav-link " id="second-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#second-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="second-tab-pane-' + PRID + '" aria-selected="true" onclick="GetPREntity(' + PRID + ',1)">Comments </button>'),
                                    $('<li class="nav-item" role="presentation">').html('<button class="nav-link " id="third-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#third-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="third-tab-pane-' + PRID + '" aria-selected="true" onclick="GetPRFile(' + PRID + ',1)"> Attachments </button>'),
                                    $('<li class="nav-item" role="presentation">').html('<button class="nav-link  " id="fourth-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#fourth-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="fourth-tab-pane-' + PRID + '" aria-selected="true" onclick="GetApprovalFlow(' + PRID + ')"> Approval Status </button>'),
                                    $('<li class="nav-item" role="presentation">').html('<button class="nav-link  " id="fifth-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#fifth-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="fifth-tab-pane-' + PRID + '" aria-selected="true" onclick="GetPRDetail(' + PRID + ')"> Requisition Summary </button>'),

                                );
                                $md12Div = $md12Div.append($ul);
                                var $TabContent = $('<div class="tab-content" id="myTabContent">');

                                /******************************* FIRST TAB   *****************************************/
                                var $firstTab = $('<div class="tab-pane fade show active" id="first-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="first-tab-' + PRID + '" tabindex = "0">');
                                var $row1 = $('<div class="row">');
                                $row1.append(
                                    $('<div class="col-2">').html("<label>Requestor</label><p>" + item.creator + "</p>"),
                                    $('<div class="col-2">').html("<label>Purchase Type</label><p>" + item.purchaseTypeName + "</p>"),
                                    $('<div class="col-2">').html("<label>Purchase Group</label><p>" + item.purchaseGroupName + "</p>"),
                                    $('<div class="col-2">').html("<label>Company</label><p>" + item.company + "</p>"),
                                    $('<div class="col-2">').html("<label>Currency</label><p>" + item.currency + "</p>"),
                                    $('<div class="col-2">').html("<label>Amount</label><p>" + item.amountToShow + "</p>"),
                                    $('<div class="col-2">').html("<label>Quantity</label><p>" + item.quantity + "</p>"),
                                    $('<div class="col-2">').html("<label>Plant Code</label><p>" + item.plantCode + "</p>"),

                                );
                                $firstTab = $firstTab.append($row1);
                                $TabContent = $TabContent.append($firstTab);

                                /******************************* SECOND TAB   *****************************************/
                                var $secondTab = $('<div class="tab-pane fade show" id="second-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="second-tab-' + PRID + '" tabindex = "0">');
                                var $secondTabtable = $('<table class="table table-blue table-striped bg-white"><thead><tr><th>Name</th><th>Status</th><th>Comment</th></tr></thead><tbody id="comment-' + PRID + '"> </tbody></table>');
                                $secondTab = $secondTab.append($secondTabtable);
                                $TabContent = $TabContent.append($secondTab);

                                /******************************* THIRD TAB   *****************************************/

                                var $thirdTab = $('<div class="tab-pane fade show" id="third-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="third-tab-' + PRID + '" tabindex = "0">');
                                var $thirdTabtable = $('<table class="table table-blue table-striped bg-white"><thead><tr><th>File Name</th><th>Submitted By</th><th>Action</th></tr></thead><tbody id="attachment-' + PRID + '"> </tbody></table>');
                                $thirdTab = $thirdTab.append($thirdTabtable);
                                $TabContent = $TabContent.append($thirdTab);

                                /******************************* FOURTH TAB   *****************************************/

                                var $fourthTab = $('<div class="tab-pane fade show" id="fourth-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="fourth-tab-' + PRID + '" tabindex = "0">');
                                var $fourthTabtable = $('<ul class="approval-status" id="approvalworkflow-' + PRID + '"></ul>');
                                $fourthTab = $fourthTab.append($fourthTabtable);
                                $TabContent = $TabContent.append($fourthTab);

                                /******************************* FIFTH TAB   *****************************************/

                                var $fifthTab = $('<div class="tab-pane fade show" id="fifth-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="fifth-tab-' + PRID + '" tabindex = "0">');
                                var $fifthTabtable = $('<div class="accordion-body requisition-summary" id="prdetails-' + PRID + '">');
                                $fifthTab = $fifthTab.append($fifthTabtable);
                                $TabContent = $TabContent.append($fifthTab);

                                $md12Div = $md12Div.append($TabContent);
                                $hiddenTR.append($md12Div);
                                $maindiv = $maindiv.append($div);
                                $maindiv = $maindiv.append($hiddenTR);
                                $("#prListBody").append($maindiv);


                            });
                        }
                        else {
                            var $maindiv = $('<table class="table table-hover table-striped table-blue">');
                            var $tr = $('<tr>').append(
                                $('<td>').text("No records to display"));
                            $maindiv.append($tr);
                            $("#prListBody").append($maindiv);
                        }
                        

                        latestPRPaging(data.recordCount, pagenum);
                    }
                    else {
                        var $maindiv = $('<table class="table table-hover table-striped table-blue">');
                        var $tr = $('<tr>').append(
                            $('<td>').text("No records to display"));
                        $maindiv.append($tr);
                        $("#prListBody").append($maindiv);
                    }
                    $('.loader-wrapper').hide();
                }
                else if (data.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(data.responseMessage);
                }
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function getLatestPR(pagenum, SearchValue) {
    
    appCurrentSelction = SearchValue;
    var scriteria1 = '';
    var scriteria2 = '';

    if ($("#ddlFilterBy").val() == "1") {

        if ($("#ddlCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }

        scriteria1 = $("#ddlCompany").val();
    }
    else if ($("#ddlFilterBy").val() == "2") {
        if ($("#ddlCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }
        if ($("#ddlFilterValue").val() == "0") {
            alert("Please select filter value!");
            return false;
        }
        scriteria1 = $("#ddlCompany").val();
        scriteria2 = $("#ddlFilterValue").val();
    }
    else if ($("#ddlFilterBy").val() == "3") {
        if ($("#ddlCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }
        if ($("#ddlFilterValue").val() == "0") {
            alert("Please select filter value!");
            return false;
        }
        scriteria1 = $("#ddlCompany").val();
        scriteria2 = $("#ddlFilterValue").val();
    }
    else if ($("#ddlFilterBy").val() == "4") {
        if ($("#ddlCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }
        if ($("#ddlFilterValue").val() == "0") {
            alert("Please select filter value!");
            return false;
        }
        scriteria1 = $("#ddlCompany").val();
        scriteria2 = $("#ddlFilterValue").val();
    }
    else if ($("#ddlFilterBy").val() == "5") {

        if ($("#txtFilterValue").val() == "0" || $("#txtFilterValue").val() == "") {
            alert("Please enter PR No!");
            return false;
        }
        scriteria2 = $("#txtFilterValue").val();
    }
   
    $('.loader-wrapper').show();
    $("#prListBody").empty();
   
    $("#pageList").empty();

    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GetPRList',
            dataType: "JSON",
            data: {
                "ReportType": "PRList", "FromDate": '', "ToDate": '',
                "SearchCriteria1": $("#ddlFilterBy").val(),
                "SearchCriteria2": scriteria1,
                "SearchCriteria3": scriteria2,
                "SearchCriteria4": SearchValue,
                "PageNumber": pagenum, "RowsOfPage": 30,
                "SearchCriteria3": $("#txtPRNo").val()
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    if (data.responsedynamic.length > 0) {

                        $.each(data.responsedynamic, function (i, item) {
                            var PRID = item.purchaseRequistionID;
                            var $maindiv = $('<div class="card pr-card-panel pending">');
                            var $div = $('<div class="card-header shadow">');
                            var $productcard = $('<div class="d-flex justify-content-between header-border">');
                            var $flexDiv = $('<div class="d-flex">');
                            $flexDiv = $flexDiv.append('<h3>HGS_PR # ' + item.requistionNo + '</h3><p>Created on : ' + item.insertedDateTime + '</p>');

                            $productcard = $productcard.append($flexDiv);
                            var $flexDivStatus = $('<div class="d-flex float-end pr-status">');
                            $flexDivStatus = $flexDivStatus.append('Current Status');
                            var $flexDivStatusButton = $('<div class="btn-status">');
                            $flexDivStatusButton = $flexDivStatusButton.append('<a href="#" class="btn btn-primary btn-xm">' + item.status + '</a>');
                            $flexDivStatus = $flexDivStatus.append($flexDivStatusButton);
                            $productcard = $productcard.append($flexDivStatus);
                            $div = $div.append($productcard);

                            var $rowprData = $('<div class="row pr-data">');
                            $rowprData.append(
                                $('<div class="col">').html("<label>Cost Centre:</label><div>" + item.costCenterName + "</div>"),
                                $('<div class="col">').html("<label>Company:</label><div>" + item.company + "</div>"),
                                $('<div class="col">').html("<label>Amount:</label><div>" + item.amountToShow + "</div>"),
                                $('<div class="col">').html("<label>Quantity:</label><div>" + item.quantity + "</div>"),
                                $('<div class="col">').html("<label>Plant Code:</label><div>" + item.plantCode + "</div>"),
                                $('<div class="col">').html("<label>Purchasing Org:</label><div>" + item.purchasingOrg + "</div>"),
                                $('<div class="col">').html('<div class="showhide-pr"> <a href="#" class="tableShowDetailsDashboard" onclick="View(' + item.purchaseRequistionID + ')"><span>View Details</span> <i class="fa-solid fa-circle-chevron-down"></i></a></div>'),

                            );
                            $div = $div.append($rowprData);
                            var $hiddenTR = $('<div id="hid' + item.purchaseRequistionID + '" class="card-body hiddenTR ps-0 pe-0 pb-0 shadow">');
                            var $md12Div = $('<div class="col-md-12">');
                            var $ul = $('<ul id="myTab" role="tablist" class="nav nav-tabs cart-tab">');
                            $ul.append(
                                $('<li class="nav-item" role="presentation">').html('<button class="nav-link active " id="first-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#first-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="first-tab-pane-' + PRID + '" aria-selected="true"> Requisition Details </button>'),
                                $('<li class="nav-item" role="presentation">').html('<button class="nav-link " id="second-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#second-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="second-tab-pane-' + PRID + '" aria-selected="true" onclick="GetPREntity(' + PRID + ',1)">Comments </button>'),
                                $('<li class="nav-item" role="presentation">').html('<button class="nav-link " id="third-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#third-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="third-tab-pane-' + PRID + '" aria-selected="true" onclick="GetPRFile(' + PRID + ',1)"> Attachments </button>'),
                                $('<li class="nav-item" role="presentation">').html('<button class="nav-link  " id="fourth-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#fourth-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="fourth-tab-pane-' + PRID + '" aria-selected="true" onclick="GetApprovalFlow(' + PRID + ')"> Approval Status </button>'),
                                $('<li class="nav-item" role="presentation">').html('<button class="nav-link  " id="fifth-tab-' + PRID + '" data-bs-toggle="tab" data-bs-target="#fifth-tab-pane-' + PRID + '" type="button" role="tab" aria-controls="fifth-tab-pane-' + PRID + '" aria-selected="true" onclick="GetPRDetail(' + PRID + ')"> Requisition Summary </button>'),

                            );
                            $md12Div = $md12Div.append($ul);
                            var $TabContent = $('<div class="tab-content" id="myTabContent">');

                            /******************************* FIRST TAB   *****************************************/
                            var $firstTab = $('<div class="tab-pane fade show active" id="first-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="first-tab-' + PRID + '" tabindex = "0">');
                            var $row1 = $('<div class="row">');
                            $row1.append(
                                $('<div class="col-2">').html("<label>Requestor</label><p>" + item.creator + "</p>"),
                                $('<div class="col-2">').html("<label>Purchase Type</label><p>" + item.purchaseTypeName + "</p>"),
                                $('<div class="col-2">').html("<label>Purchase Group</label><p>" + item.purchaseGroupName + "</p>"),
                                $('<div class="col-2">').html("<label>Company</label><p>" + item.company + "</p>"),
                                $('<div class="col-2">').html("<label>Currency</label><p>" + item.currency + "</p>"),
                                $('<div class="col-2">').html("<label>Amount</label><p>" + item.amountToShow + "</p>"),
                                $('<div class="col-2">').html("<label>Quantity</label><p>" + item.quantity + "</p>"),
                                $('<div class="col-2">').html("<label>Plant Code</label><p>" + item.plantCode + "</p>"),

                            );
                            $firstTab = $firstTab.append($row1);
                            $TabContent = $TabContent.append($firstTab);

                            /******************************* SECOND TAB   *****************************************/
                            var $secondTab = $('<div class="tab-pane fade show" id="second-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="second-tab-' + PRID + '" tabindex = "0">');
                            var $secondTabtable = $('<table class="table table-blue table-striped bg-white"><thead><tr><th>Name</th><th>Status</th><th>Comment</th></tr></thead><tbody id="comment-' + PRID + '"> </tbody></table>');
                            $secondTab = $secondTab.append($secondTabtable);
                            $TabContent = $TabContent.append($secondTab);

                            /******************************* THIRD TAB   *****************************************/

                            var $thirdTab = $('<div class="tab-pane fade show" id="third-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="third-tab-' + PRID + '" tabindex = "0">');
                            var $thirdTabtable = $('<table class="table table-blue table-striped bg-white"><thead><tr><th>File Name</th><th>Submitted By</th><th>Action</th></tr></thead><tbody id="attachment-' + PRID + '"> </tbody></table>');
                            $thirdTab = $thirdTab.append($thirdTabtable);
                            $TabContent = $TabContent.append($thirdTab);

                            /******************************* FOURTH TAB   *****************************************/

                            var $fourthTab = $('<div class="tab-pane fade show" id="fourth-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="fourth-tab-' + PRID + '" tabindex = "0">');
                            var $fourthTabtable = $('<ul class="approval-status" id="approvalworkflow-' + PRID + '"></ul>');
                            $fourthTab = $fourthTab.append($fourthTabtable);
                            $TabContent = $TabContent.append($fourthTab);

                            /******************************* FIFTH TAB   *****************************************/

                            var $fifthTab = $('<div class="tab-pane fade show" id="fifth-tab-pane-' + PRID + '" role="tabpanel" aria - labelledby="fifth-tab-' + PRID + '" tabindex = "0">');
                            var $fifthTabtable = $('<div class="accordion-body requisition-summary" id="prdetails-' + PRID + '">');
                            $fifthTab = $fifthTab.append($fifthTabtable);
                            $TabContent = $TabContent.append($fifthTab);

                            $md12Div = $md12Div.append($TabContent);
                            $hiddenTR.append($md12Div);
                            $maindiv = $maindiv.append($div);
                            $maindiv = $maindiv.append($hiddenTR);
                            $("#prListBody").append($maindiv);


                        });

                        PRPaging(data.recordCount, pagenum);
                    }
                    else {
                        var $maindiv = $('<table class="table table-hover table-striped table-blue">');
                        var $tr = $('<tr>').append(
                            $('<td>').text("No records to display"));
                        $maindiv.append($tr);
                        $("#prListBody").append($maindiv);
                    }
                }
                else if (data.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();


            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function PRPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    template = '<ul class="pagination justify-content-end pagination-sm">';
    template = template + '<li "page-item disabled"><span class="page-link" onclick="getLatestPR(' + BackwardOne + ',appCurrentSelction)">Previous</span></li>';

    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        if (PageNumberArray[i] == currentPage) {
            numberingLoop = numberingLoop + '<li class="page-item active"><span class="page-link" onclick="getLatestPR(' + PageNumberArray[i] + ',appCurrentSelction)">' + PageNumberArray[i] + '<span class="sr-only">(current)</span></span></li>'
        }
        else {
            numberingLoop = numberingLoop + '<li class="page-item"><span class="page-link" onclick="getLatestPR(' + PageNumberArray[i] + ',appCurrentSelction)">' + PageNumberArray[i] + '</span></li>'
        }

    }
    template = template + numberingLoop + '<li "page-item"><span class="page-link"><a href="#" onclick="getLatestPR(' + ForwardOne + ',appCurrentSelction)"></a>Next</span></li></ul>';

    $("#pageList").append(template);
}
function latestPRPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    template = '<ul class="pagination justify-content-end pagination-sm">';
    template = template + '<li "page-item disabled"><span class="page-link" onclick="getRDAccess(' + BackwardOne + ',appCurrentSelction)">Previous</span></li>';

    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        if (PageNumberArray[i] == currentPage) {
            numberingLoop = numberingLoop + '<li class="page-item active"><span class="page-link" onclick="getRDAccess(' + PageNumberArray[i] + ',appCurrentSelction)">' + PageNumberArray[i] + '<span class="sr-only">(current)</span></span></li>'
        }
        else {
            numberingLoop = numberingLoop + '<li class="page-item"><span class="page-link" onclick="getRDAccess(' + PageNumberArray[i] + ',appCurrentSelction)">' + PageNumberArray[i] + '</span></li>'
        }

    }
    template = template + numberingLoop + '<li "page-item"><span class="page-link"><a href="#" onclick="getRDAccess(' + ForwardOne + ',appCurrentSelction)"></a>Next</span></li></ul>';

    $("#pageList").append(template);
}
function View(prID) {
    event.preventDefault()
    $("#hid" + prID).toggle();
    $("#hid" + prID).focus();

}
function GetPREntity(PurchaseRequistionID, SerchType) {
    if (SerchType == 1) {
        SerchType = "PRNOTES";
    }
    var ulID = "comment-" + PurchaseRequistionID;
    console.log(ulID);
    $("#" + ulID).empty();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPREntity", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: SerchType
            },
            success: function (result) {
                console.log('result');
                console.log(result);
                if (SerchType == 'PRNOTES') {
                    if (result.length > 0) {
                        $.each(result, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td width="100">').text(item.fullName),
                                $('<td width="100">').text(item.statusText),
                                $('<td width="100">').text(item.remarks),
                            );
                            console.log('$tr');
                            console.log($tr);
                            $("#" + ulID).append($tr);

                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                        $("#" + ulID).append($tr);
                    }
                }
                if (SerchType == 'DETAILLINE') {


                }

                $("#waitLoadingPanel").hide();
            }

        });
}
function GetPRFile(PurchaseRequistionID, SerchType) {
    if (SerchType == 1) {
        SerchType = "PRFILES";
    }
    var ulID = "attachment-" + PurchaseRequistionID;
    console.log(ulID);
    $("#" + ulID).empty();
    //$("divloading").show();
    $('.loader-wrapper').show();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRFiles", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: SerchType
            },
            success: function (result) {
                console.log('result');
                console.log(result);
                if (SerchType == 'PRFILES') {
                    if (result.length > 0) {
                        $.each(result, function (i, item) {
                            // var downloadLink = appUrl + "assets/PRDocument/" + item.fileContent;
                            var downloadLink = appUrl + "assets/PRDocument/" + item.filePath;
                            var ddlLink = "/assets/PRDocument/" + item.fileContent;
                            var ddl = "'" + item.fileName + "','" + ddlLink + "'";


                            var $tr = $('<tr>').append(

                                $('<td width="100">').text(item.fileName),
                                $('<td width="100">').text(item.submittedBy),
                                $('<td width="100">').html('&nbsp; <a href=# onclick=DownloadFile(' + ddl + ')>Download</a>'),
                                //$('<td width="100">').html('&nbsp; <a href=' + downloadLink + ' target="_blank">Download</a>'),
                            );
                            console.log('$tr');
                            console.log($tr);
                            $("#" + ulID).append($tr);

                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('No records to display'));
                        $("#" + ulID).append($tr);
                    }
                }
                //$("divloading").hide();
                $('.loader-wrapper').hide();
            }

        });
}
function GetApprovalFlow(PurchaseRequistionID) {

    var ulID = "approvalworkflow-" + PurchaseRequistionID;

    $("#" + ulID).empty();
    $('.loader-wrapper').show();

    var list = '';
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetApproverList", // Controller/View
            data: { //Passing data
                loggedInEmpId: 1, PRrequisitionId: PurchaseRequistionID
            },
            success: function (result) {

                if (result != '' && result.distinctLevel.length > 0) {
                    var submitli = '<li><div class="sub-pending"><h4 style="background-color :yellowgreen;color:white">Submitted</h4><p>' + result.distinctLevel[0].submittedBy + '</p></div></li>';
                    //var submitli = '<li><div class="submited">' + result.distinctLevel[0].submittedBy + '</div></li>';
                    var finalli = '<li><div class="final-approval">' + result.distinctLevel[0].prStatus + '</div></li>';
                    var pendinglist = '';

                    $.each(result.distinctLevel, function (i, item) {
                        var getLevelData = [];

                        $.each(result.approvalData, function (j, treeData) {

                            if (item.approvalLevel == treeData.approvalLevel) {
                                getLevelData.push(treeData);
                            }

                        });

                        if (getLevelData.length > 0) {

                            pendinglist += '<li>';
                            $.each(getLevelData, function (j, treeData) {
                                var colorBg = '';
                                if (treeData.approvalStatus == "Approved") {
                                    colorBg = 'yellowgreen';
                                }
                                else if (treeData.approvalStatus == "Reject") {
                                    colorBg = 'indianred';
                                }
                                else if (treeData.approvalStatus == "Rework") {
                                    colorBg = 'gold';
                                }
                                else {
                                    colorBg = 'orange';
                                }
                                if (j == 0) {
                                    if (treeData.isDelegator == 0) {
                                        pendinglist += '<div class="sub-pending"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p>' + treeData.approvalName + '</p></div>';
                                    }
                                    else {
                                        pendinglist += '<div class="sub-pending"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p class="pb-0">' + treeData.approvalName + '</p><p class="pt-0">' + treeData.delegatorName + '</p></div>';
                                    }
                                }
                                else {
                                    if (treeData.isDelegator == 0) {
                                        pendinglist += '<div class="sub-pending top-line"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p>' + treeData.approvalName + '</p></div>';
                                    }
                                    else {
                                        pendinglist += '<div class="sub-pending top-line"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p class="pb-0">' + treeData.approvalName + '</p><p class="pt-0">' + treeData.delegatorName + '</p></div>';
                                    }
                                }
                            });
                            pendinglist += '</li>';
                        }

                    });

                    list = list + pendinglist;


                    list = submitli + list;
                    list = list + finalli;
                    $("#" + ulID).append(list.toString());
                }
                $('.loader-wrapper').hide();
            }

        });
}
function GetPRDetail(PurchaseRequistionID) {
    $('.loader-wrapper').show();
    var ulID = "prdetails-" + PurchaseRequistionID;

    $("#" + ulID).empty();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRDetails", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID
            },
            success: function (result) {

                if (result.length > 0) {
                    $.each(result, function (i, item) {
                        var $row1 = $('<div class="row">');
                        $row1.append(
                            $('<div class="col-md-1">').html("<label>SL No</label><p>" + item.srNo + "</p>"),
                            $('<div class="col-md-3">').html("<label>Description</label><p>" + item.material + "</p>"),
                            $('<div class="col-md-2">').html("<label>Quantity</label><p>" + item.quantity + "</p>"),
                            $('<div class="col-md-2">').html("<label>Unit</label><p>" + item.uom + "</p>"),
                            $('<div class="col-md-2">').html("<label>Price</label><p>" + item.amountToShow + "</p>"),
                            $('<div class="col-md-2">').html("<label>Net Amount</label><p>" + item.netAmountToShow + "</p>"),

                        );

                        $("#" + ulID).append($row1);

                    });
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="6">').text('No records to display'));
                    $("#" + ulID).append($tr);
                }
                $('.loader-wrapper').hide();
            }

        });
}
function DownloadFile(filename, filepath) {

    window.location.href = appUrl + 'Home/DownloadFile?FileName=' + filename + '&filePath=' + filepath;
};
function SearchPR() {
    if ($("#txtPRNo").val()=="") {
        alert("Please enter PR Number to search!");
        return false;
    }
    getLatestPR(1, '0');
}
function clearSearch() {
    $("#txtPRNo").val("");
    appCurrentSelction = '';

    //$('.loader-wrapper').show();
    $("#prListBody").empty();

    $("#pageList").empty();
}
/************   SEARCH FILTER   *************/
function bindFilterBy() {
    $('.loader-wrapper').show();
    $("#ddlFilterBy").empty();
    //$("#ddlFilterBy").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            dataType: "JSON",
            data: {
                "EntityName": "FilterBy"
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#ddlFilterBy").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                    getRDAccess(1);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function bindCompany() {
    $('.loader-wrapper').show();
    $("#ddlCompany").empty();
    //$("#ddlCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            dataType: "JSON",
            data: {
                "EntityName": "AssignedCompanies"
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#ddlCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function bindSearchFilterValues() {
    $('.loader-wrapper').show();
    $("#ddlFilterValue").empty();
    $("#ddlFilterValue").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            dataType: "JSON",
            data: {
                "EntityName": "FilterValue", "SearchParameter1": $("#ddlFilterBy").val(),
                "SearchParameter2": $("#ddlCompany").val()
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#ddlFilterValue").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}