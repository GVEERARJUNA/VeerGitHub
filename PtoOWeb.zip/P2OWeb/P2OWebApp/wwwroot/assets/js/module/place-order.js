﻿var appUrl = '';
var detailNo = '';
var purchasetype = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    purchasetype = $('#purchaseTypeEdit').val();

   // $("#selMaterial").select2();
    //$("#selGLCode").select2();

       $("#txtAmount").keypress(function (event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) &&

            ((event.which < 48 || event.which > 57) &&

                (event.which != 0 && event.which != 8))) {

            event.preventDefault();

        }
        var text = $(this).val();
        if ((text.indexOf('.') != -1) &&

            (text.substring(text.indexOf('.')).length > 2) &&

            (event.which != 0 && event.which != 8) &&

            ($(this)[0].selectionStart >= text.length - 2)) {

            event.preventDefault();

        }
    });


    $("#selQuantity").keypress(function (event) {

        if ((event.which != 46 || $(this).val().indexOf('.') != -1) &&

            ((event.which < 48 || event.which > 57) &&

                (event.which != 0 && event.which != 8))) {

            event.preventDefault();

        }
        var text = $(this).val();
        if ((text.indexOf('.') != -1) &&

            (text.substring(text.indexOf('.')).length > 2) &&

            (event.which != 0 && event.which != 8) &&

            ($(this)[0].selectionStart >= text.length - 2)) {

            event.preventDefault();

        }

    });

    $('.loader-wrapper').hide();

    GetApprovalFlow();

});

$(document).ready(function () {
    function selectPicker3() {
        $(".selectPicker3").select2(
            {
                dropdownParent: $('#editPRDetail')
                //dropdownParent: $('#changeHeaderDetails')
            }
        );
    }
    selectPicker3();

    function selectPicker4() {
        $(".selectPicker4").select2(
            {
                dropdownParent: $('#editDetail')
                //dropdownParent: $('#changeHeaderDetails')
            }
        );
    }

    selectPicker4();
});

//function selectPicker2() {
//    $("#selEmployeeEdit").select2();
//}

//$(document).ready(function () {
//    selectPicker2();
//});

//// Now you can call selectPicker2() elsewhere in your code
//selectPicker2();


//$(document).ready(function() {
//    $('.selEmployeeEdit').select2({
//        width: '100%',
//        dropdownAutoWidth: true,
//        placeholder: 'Select',
//        allowClear: true,
//        minimumInputLength: 1, // minimum number of characters to start searching
//        ajax: {
//            url: 'search-employee.php', // replace with your search endpoint
//            dataType: 'json',
//            delay: 250, // delay in milliseconds before sending the search request
//            data: function (params) {
//                return {
//                    q: params.term // search term entered by user
//                };
//            },
//            processResults: function (data) {
//                return {
//                    results: data
//                };
//            },
//            cache: true
//        }
//    });
//});


//    $(document).ready(function() {
//        $('.selEmployeeEdit').select2({
//            placeholder: 'Select',
//            allowClear: true,
//            dropdownSearch: true
//        });
//});


$("#selCostCentreEdit").prop("disabled", true);

$(document).ready(function () {
    $("#inlineRadio2Edit").click(function () {
        $("#selCostCentreEdit").prop("disabled", false);
    });
});

$(document).ready(function () {
    $("#inlineRadio1Edit").click(function () {
        $.ajax({
            type: 'POST',
            url: appUrl + 'PurchaseRequistion/GetSelfCostCenter',
            data: {

            },
            success: function (data, textstatus) {

                if (data != '') {
                    $("#selCostCentreEdit").val(data).trigger('change');
                }

                $("#loading").hide();
                $("#selCostCentreEdit").prop("disabled", true);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    });
});

$(document).ready(function () {
    $("#selOnBehalfOfEdit").change(function () {
        var val = this.value;
        // alert(val);
        if (val == 'noOnBehalfOf') {
            $(".hideDiv").hide();
            $(".hideDivEmp").hide();
            $("#inlineRadio1Edit").prop("disabled", false);
            
        } else {
            $(".hideDiv").show();
            $(".hideDivEmp").hide();
            $("#inlineRadio1Edit").prop("disabled", true);
            $("#inlineRadio2Edit").prop("checked", true);
            $("#selCostCentreEdit").prop("disabled", false);
            val = 'yesOnBehalfOf'
            /*bindEmployeeDropDownEdit();*/

        }
    });
});

$(document).ready(function () {
    $("#selMaterial").change(function () {
        var materialcode = this.value;
        bindGLDropDownEdit(materialcode);
    });
});



function bindMaterialDropDown(searchType, selectedValue, disableflag) {
    $("#selMaterial").empty();
    $("#selMaterial").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "MaterialMaster", "SearchParameter1": searchType
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selMaterial").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selMaterial").val(selectedValue);
                }

                if (disableflag == true) {
                    $("#selMaterial").prop("disabled", true);
                }


            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function bindGLDropDown(selectedValue,materialcode) {
    $("#selGLCodeEdit").empty();
    $("#selGLCodeEdit").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "GLMasterEdit", "SearchParameter1": materialcode
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selGLCodeEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selGLCodeEdit").val(selectedValue);
                }

               

            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function bindGLDropDownEdit(materialcode) {
    $("#selGLCodeEdit").empty();
    $("#selGLCodeEdit").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "GLMasterEdit", "SearchParameter1": materialcode
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selGLCodeEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });


            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function editClick(cartdetailNo,purchaseType) {
    $('#hdCartDetail').val(cartdetailNo);
    detailNo = $('#hdCartDetail').val(cartdetailNo);
    $("#hdpurchaseType").val(purchaseType);
    $("#divShippingPlantCode").hide();
    $("#divCartGLCode").hide();
    $('.loader-wrapper').show();

    $.ajax({
        type: 'POST',
        url: appUrl + 'Cart/GetDetail',
        data: {
            "detailNo": cartdetailNo
        },
        success: function (data, textstatus) {
            if (data != '') {
                if (data.shoppingCartDetails.length > 0) {
                    $("#hdonBehalf").val(data.onBehalfOfFlag);
                    for (var i = 0; i < data.shoppingCartDetails.length; i++) {
                        if (cartdetailNo == data.shoppingCartDetails[i].cartDetailNo) {
                            $("#txtProductType").val(data.shoppingCartDetails[i].productType);
                            $("#txtAmount").val(data.shoppingCartDetails[i].materialAmount);
                            $("#selQuantity").val(data.shoppingCartDetails[i].materialQuantity);
                            $("#txtComments").val(data.shoppingCartDetails[i].comments);
                            $("#txtNeededByDate").val(data.shoppingCartDetails[i].neededByDate);
                            bindMaterialDropDown(purchaseType, data.shoppingCartDetails[i].materialCode, false);
                            //bindGLDropDown(data.shoppingCartDetails[i].glCode);
                            if (data.shoppingCartDetails[i].glCode != '' && data.shoppingCartDetails[i].glCode != 'undefined' || data.shoppingCartDetails[i].glCode != '0') {
                                $("#divCartGLCode").show();
                                /*$("#lblGLCode").text(data.shoppingCartDetails[i].glCode);*/
                                bindGLDropDown(data.shoppingCartDetails[i].glCode, data.shoppingCartDetails[i].materialCode);
                            }
                            
                           
                            //if (data.shoppingCartDetails[i].glCode != '' && data.shoppingCartDetails[i].glCode != 'undefined') {
                            //{
                            //        $("#divCartGLCode").show();
                            //        $("#lblGLCode").text(data.shoppingCartDetails[i].glCode);
                                    
                            //}
                           

                            $("#selPurchaseType").text(data.purchaseType);
                            $("#selPurchaseGroup").text(data.purchaseGroupText);
                            $("#selCurrency").text(data.currency);
                            //$("#selVendor").text(data.vendor);
                            $("#selPlantCode").text(data.plantName);
                            if (data.shippingPlantName != '' && data.shippingPlantName != 'undefined') {
                                $("#divShippingPlantCode").show();
                                $("#lblShippingPlantCode").text(data.shippingPlantName);
                            }
                            else {
                                $("#divShippingPlantCode").hide();
                                $("#selPlantCode").text('');
                            }
                            $("#selCostCentre").text(data.costCenter);
                            $("#selPurchaseOrganisation").text(data.purchaseOrganisation);
                            //var onbehalf = '';
                            //if (data.onBehalfOfFlag == 'yesOnBehalfOf') {
                            //    onbehalf = 'YES';
                            //}
                            //else {
                            //    onbehalf = 'NO';
                            //}
                            //$("#selOnBehalfOfEdit").text(onbehalf);


                            //if (data.onBehalfOfFlag == "yesOnBehalfOf") {

                            //    $(".hideDiv").show();
                            //    $("#selEmployeeEdit").text(data.creatorName);
                            //    // bindEmployeeDropDown(data.employeeCode, true);


                            //}
                            //else {
                            //    $(".hideDiv").hide();
                            //}
                           
                            //bindMasterDropDowns(data.purchaseTypeCode, data.purchaseGroup, data.currency, data.vendorCode, data.plantCode, data.purchaseOrganisationCode, data.costCenterCode);

                           // $("#selOnBehalfOf").prop("disabled", true);

                           

                            //if (data.costCenterFlag == "SC") {
                            //    $("#inlineRadio1Edit").prop("checked", true);
                            //    $("#inlineRadio2Edit").prop("checked", false);
                            //}
                            //else if (data.costCenterFlag == "OT") {
                            //    $("#inlineRadio1Edit").prop("checked", false);
                            //    $("#inlineRadio2Edit").prop("checked", true);
                            //}

                            //$("#inlineRadio1Edit").prop("disabled", true);
                            //$("#inlineRadio2Edit").prop("disabled", true);

                            // bind files
                            $("#bodyfiles").empty();

                            if (data.shoppingCartDetails[i].cartFiles != null && data.shoppingCartDetails[i].cartFiles.length > 0) {
                                
                                $.each(data.shoppingCartDetails[i].cartFiles, function (i, item) {
                                    var downloadLink = appUrl + "assets/PRDocument/" + item.filePath;
                                    var ddlLink = "/assets/PRDocument/" + item.filePath;
                                    var attr = "'" + item.fileNo + "'";
                                    var ddl = "'" + item.fileName + "','" + ddlLink + "'";
                                    var $tr = $('<tr>').append(
                                        $('<td>').text(i + 1),
                                        $('<td>').text(item.fileName),

                                        //$('<td >').html('&nbsp; <a href=' + downloadLink + ' target="_blank">Download</a>'),
                                        $('<td >').html('&nbsp; <a href=# onclick=DownloadFile(' + ddl + ')>Download</a>'),
                                        $('<td >').html('&nbsp; <a href="#" onclick=deleteFile(' + attr + ')>Remove</a>'),
                                    );

                                    $tr.attr("id", item.fileNo);
                                    $("#bodyfiles").append($tr);

                                });

                                $("#divFiles").show();
                            }
                            else {
                                $("#divFiles").hide();
                            }

                           
                            $('.loader-wrapper').hide();
                            $('#editDetail').modal('show');
                        }
                    }
                }
                
                
            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        },
        complete: function (data) {

            
        }
    });

    

    
}

function deleteFile(fileNo) {
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Cart/deleteFile',
        data: {
            "detailNo": $("#hdCartDetail").val(), "fileNo": fileNo
        },
        success: function (data, textstatus) {
            if (data != '') {
                if (data.responseCode == 1) {
                    $('.loader-wrapper').hide();
                    alert("deleted Successfully!");
                    $('#' + fileNo).remove();
                    //alert("Quantity edit Successfully!");
                    //location.href = appUrl + "Cart/Index";
                }
                else if (data.responseCode == 3) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(data.responseMessage);
                }

            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function bindMasterDropDowns(purchaseType, purchaseGroup, currency, vendor, plantCode, purchaseOrganisation, costCenterCode) {
    $("#selPurchaseTypeEdit").empty();
    $("#selPurchaseGroupEdit").empty();
    $("#selCurrencyEdit").empty();
    $("#selVendorEdit").empty();
    $("#selPlantCodeEdit").empty();
    $("#selPurchaseOrganisationEdit").empty();
    $("#selCostCentreEdit").empty();

    $("#selPurchaseTypeEdit").append($("<option />").val("0").text("Select"));
    $("#selPurchaseGroupEdit").append($("<option />").val("0").text("Select"));
    $("#selCurrencyEdit").append($("<option />").val("0").text("Select"));
    $("#selVendorEdit").append($("<option />").val("0").text("Select"));
    $("#selPlantCodeEdit").append($("<option />").val("0").text("Select"));
    $("#selPurchaseOrganisationEdit").append($("<option />").val("0").text("Select"));
    $("#selCostCentreEdit").append($("<option />").val("0").text("Select"));

    //$("#selPurchaseType").select2();
    //$("#selPurchaseGroup").select2();
    //$("#selCurrency").select2();
    //$("#selVendor").select2();
    //$("#selPlantCode").select2();
    //$("#selPurchaseOrganisation").select2();
    //$("#selCostCentre").select2();

    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetPREntityData',
        data: {
            "EntityName": "PRMasterData"
        },
        success: function (pdata, textstatus) {
            if (pdata != '') {


                $.each(pdata.purchaseTypes, function (i, item) {
                    $("#selPurchaseTypeEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });

                $.each(pdata.purchaseGroups, function (i, item) {
                    $("#selPurchaseGroupEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });

                $.each(pdata.currencies, function (i, item) {
                    $("#selCurrencyEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });

                $.each(pdata.vendors, function (i, item) {
                    $("#selVendorEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });

                $.each(pdata.plantCodes, function (i, item) {
                    $("#selPlantCodeEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });

                $.each(pdata.purchaseOrganisations, function (i, item) {
                    $("#selPurchaseOrganisationEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });

                $.each(pdata.costCenters, function (i, item) {
                    $("#selCostCentreEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (purchaseType != '') {
                    $("#selPurchaseTypeEdit").val(purchaseType); 
                }
                if (purchaseGroup != '') {
                    $("#selPurchaseGroupEdit").val(purchaseGroup);
                }
                if (currency != '') {
                    $("#selCurrencyEdit").val(currency);
                }
                if (vendor != '') {
                    $("#selVendorEdit").val(vendor);
                }
                if (plantCode != '') {
                    $("#selPlantCodeEdit").val(plantCode);
                }
                if (purchaseOrganisation != '') {
                    $("#selPurchaseOrganisationEdit").val(purchaseOrganisation);
                }
                if (costCenterCode != '') {
                    $("#selCostCentreEdit").val(costCenterCode);
                }

               

                $("#selPurchaseTypeEdit").prop("disabled", true);
                //$("#selPurchaseGroup").prop("disabled", true);
                //$("#selCurrency").prop("disabled", true);
                //$("#selVendor").prop("disabled", true);
                //$("#selPlantCode").prop("disabled", true);
                //$("#selPurchaseOrganisation").prop("disabled", true);
                //$("#selCostCentre").prop("disabled", true);

              

                
            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function editQuantity(myvalue) {

    $.ajax({
        type: 'POST',
        url: appUrl + 'Cart/editQuantity',
        data: {
            "detailNo": myvalue.id, "Quantity": myvalue.value
        },
        success: function (data, textstatus) {
            if (data != '') {
                if (data.responseCode == 1) {
                    alert("Quantity edit Successfully!");
                    location.href = appUrl + "Cart/Index";
                }
                else if (data.responseCode == 3) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(data.responseMessage);
                }

            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function placeOrder() {
    if (confirm('Do you want to place order?')) {
        $('.loader-wrapper').show();
        $.ajax({
            type: 'POST',
            url: appUrl + 'Cart/PlaceOrder',
            data: {

            },
            success: function (data, textstatus) {
                if (data != '') {
                    if (data.responseCode == 1) {
                        alert("Purchase requisition created Successfully!");
                        location.href = appUrl + "RequistionResponse/Index";
                    }
                    else if (data.responseCode == 3) {
                        location.href = appUrl + "Auth/Index";
                    }
                    else {
                        alert(data.responseMessage);
                    }

                    $('.loader-wrapper').hide();

                }



            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
    }
}

function continueShopping() {
    location.href = appUrl + "Home/Index";
}

function attachFile()
{
    if (confirm('Do you want to upload file?')) {
        var fileUpload = $("#formFileMultiple").get(0);
        var files = fileUpload.files;

        if (files.length > 0) {

            //var ext = $('#formFileMultiple').val().split('.').pop().toLowerCase();
            //if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg', 'pdf', 'eml', 'msg']) == -1) {
            //    alert('Only (gif,png,jpg,jpeg,pdf,eml) are allowed!');
            //    return false;
            //}

            for (var i = 0; i < files.length; i++) {
               
                var fileext = files[i].name.substr((files[i].name.lastIndexOf('.') + 1)).toLowerCase();
                
                if ($.inArray(fileext, ['gif', 'png', 'jpg', 'jpeg', 'pdf', 'eml', 'msg', 'xls', 'xlsx', 'PNG', 'doc', 'docx']) == -1) {
                    alert('Only (gif,png,jpg,jpeg,pdf,eml,xls,xlsx,doc,docx) are allowed!');
                    return false;
                }
               

            }

            var allowedSize = 0;


            for (var i = 0; i < files.length; i++) {
                const fsize = files.item(i).size;
                const file = Math.round((fsize / 1024));
                allowedSize = allowedSize + file;
                // The size of the file.

            }

            if (allowedSize > 10240) {
                alert("File too Big, please select  files equal to 10 mb");


                return false;
            }

        }
        else {
            alert("Please choose the files then click on attach button!");
            return false;
        }

        $('.loader-wrapper').show();

        uploadFiles($("#hdCartDetail").val());
    }

}

function editDetails() {
    if (confirm('Do you want to edit details?')) {
        

        var selMaterial = $("#selMaterial").val();
        if (selMaterial == 0) {
            alert("Please select Material");
            $("#selMaterial").focus();
            return false;
        }
       

        //var selGLCode = $("#selGLCode").val();
        //if (selGLCode == 0) {
        //    alert("Please select GL Code");
        //    $("#selGLCode").focus();
        //    return false;
        //}
        var productType = $("#txtProductType").val();
        if (productType == "") {
            alert("Product Type required!");
            $("#txtProductType").focus();
            return false;
        }
        else if (productType.length > 40) {
            alert("Product Type cannot exceed 40 characters!");
            $("#txtProductType").focus();
            return false;
        }
        var productAmount = $("#txtAmount").val();
        if (productAmount == "" || productAmount == 0) {
            alert("Product amount required!");
            $("#txtAmount").focus();
            return false;
        }
        var selQuantity = $("#selQuantity").val();
        if (selQuantity == 0 || selQuantity == "") {
            alert("Please select Quantity!");
            $("#selQuantity").focus();
            return false;
        }
        
        if ($("#txtComments").val() == "") {
            alert("Comments required!");
            $("#txtProductType").focus();
            return false;
        }
        else if ($("#txtComments").length > 5000) {
            alert("Line comments cannot exceed 5000 characters!");
            $("#txtComments").focus();
            return false;
        }


        //var fileUpload = $("#formFileMultiple").get(0);
        //var files = fileUpload.files;

        //if (files.length > 0) {

        //    var ext = $('#formFileMultiple').val().split('.').pop().toLowerCase();
        //    if ($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg', 'pdf', 'eml', 'msg']) == -1) {
        //        alert('Only (gif,png,jpg,jpeg,pdf,eml) are allowed!');
        //        return false;
        //    }

        //    var allowedSize = 0;


        //    for (var i = 0; i < files.length; i++) {
        //        const fsize = files.item(i).size;
        //        const file = Math.round((fsize / 1024));
        //        allowedSize = allowedSize + file;
        //        // The size of the file.

        //    }

        //    if (allowedSize > 10240) {
        //        alert("File too Big, please select  files equal to 10 mb");


        //        return false;
        //    }

        //}

        $('.loader-wrapper').show();

        $.ajax({
            type: 'POST',
            url: appUrl + 'Cart/editDetails',
            data: {
               
                "detailNo": $("#hdCartDetail").val(), "Quantity": $("#selQuantity").val(),
                "amount": $("#txtAmount").val(),
                "materialCode": $("#selMaterial").val(), "materialDesc": $("#selMaterial option:selected").text(), "glCode": $("#selGLCodeEdit").val(),
                "productType": $("#txtProductType").val(), "comments": $("#txtComments").val()
            },
            success: function (data, textstatus) {
                if (data != '') {
                    

                    if (data.responseCode == 1) {
                        alert("The Details are Edited Successfully!");
                        $('.loader-wrapper').hide();
                        location.href = appUrl + "Cart/Index";

                        //var fileUpload = $("#formFileMultiple").get(0);
                        //var files = fileUpload.files;
                        //if (files.length > 0) {
                        //    uploadFiles($("#hdCartDetail").val());
                        //}
                        //else {
                        //    $('.loader-wrapper').hide();
                        //    alert("Details edit Successfully!");
                        //    location.href = appUrl + "Cart/Index";
                        //}

                        //alert("Details edit Successfully!");
                        //location.href = appUrl + "Cart/Index";
                    }
                    else if (data.responseCode == 3) {
                        location.href = appUrl + "Auth/Index";
                    }
                    else {
                        $('.loader-wrapper').hide();
                        alert(data.responseMessage);
                    }

                }



            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }

   
}

function uploadFiles(cartdetailNo) {
    var fileUpload = $("#formFileMultiple").get(0);

    var files = fileUpload.files;

    var data = new FormData();

    data.append("DetailNo", cartdetailNo);

    for (var i = 0; i < files.length; i++) {
        data.append("fileInput", files[i]);
    }
    $.ajax({

        type: "POST",

        url: appUrl + "Cart/Upload_File",

        contentType: false,

        processData: false,

        data: data,

        async: false,

        beforeSend: function () {

            $("#divloader").show()

        },

        success: function (data) {
            $('.loader-wrapper').hide();
            if (data.responseCode == 0) {
                alert(data.responseMessage);

            }
            else {
                alert("file uploaded Successfully!");
                editClick(cartdetailNo, $('#hdpurchaseType').val());
            }
            
            //location.href = appUrl + "Cart/Index";
           
        },

        error: function () {

            alert("Error!");

        },

        complete: function () {

            $("#divloader").hide()

        }

    });
}

//function bindEmployeeDropDown(selectedValue, disableflag) {
//    $("#selEmployeeEdit").empty();
//    $("#selEmployeeEdit").append($("<option />").val("0").text("Select"));
//    $.ajax({
//        type: 'POST',
//        url: appUrl + 'PurchaseRequistion/GetEmployeeList',
//        data: {

//        },
//        success: function (pdata, textstatus) {
//            if (pdata != '') {

//                $.each(pdata, function () {
//                    $("#selEmployeeEdit").append($("<option />").val(this.valueField).text(this.displayField));
//                });


//                $("#selEmployeeEdit").val(selectedValue);

//                if (disableflag == true) {
//                    $("#selEmployeeEdit").prop("disabled", false);
//                }

//                //$("#selEmployee").prop("disabled", true);
//            }


//        },
//        error: function (XMLHttpRequest, textStatus, errorThrown) {

//        }
//    });
//}

//function bindEmployeeDropDownEdit() {
//    $("#selEmployeeEdit").empty();
//    $("#selEmployeeEdit").append($("<option />").val("0").text("Select"));
//    $.ajax({
//        type: 'POST',
//        url: appUrl + 'PurchaseRequistion/GetEmployeeList',
//        data: {

//        },
//        success: function (pdata, textstatus) {
//            if (pdata != '') {

//                $.each(pdata, function () {
//                    $("#selEmployeeEdit").append($("<option />").val(this.valueField).text(this.displayField));
//                });

//                if (disableflag == true) {
//                    $("#selEmployeeEdit").prop("disabled", false);
//                }

//                //$("#selEmployee").prop("disabled", true);
//            }


//        },
//        error: function (XMLHttpRequest, textStatus, errorThrown) {

//        }
//    });
//}

function checkFileUpload() {
   // $('.loader-wrapper').show();
    $('#editDetail').modal('hide');
    //$.ajax({
    //    type: 'POST',
    //    url: appUrl + 'Cart/checkFileUpload',
    //    data: {

           
    //    },
    //    success: function (data, textstatus) {
    //        if (data != '') {


    //            if (data.responseCode == 1) {
                    
    //                $('.loader-wrapper').hide();
    //                $('#editDetail').modal('hide');
    //            }
    //            else if (data.responseCode == 3) {
    //                location.href = appUrl + "Auth/Index";
    //            }
    //            else {
    //                $('.loader-wrapper').hide();
    //                alert(data.responseMessage);
    //            }

    //        }



    //    },
    //    error: function (XMLHttpRequest, textStatus, errorThrown) {
    //        $('.loader-wrapper').hide();
    //    }
    //});
}

function DownloadFile(filename,filepath) {
    
    window.location.href = appUrl + 'Home/DownloadFile?FileName=' + filename + '&filePath=' + filepath;
};

function GetApprovalFlow() {
    var ulID = "approvalworkflow";

    $("#" + ulID).empty();
    $('.loader-wrapper').show();

    var list = '';
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Cart/GetPRVirtualFlow", // Controller/View
            data: { //Passing data
                
            },
            success: function (result) {

                if (result != '' && result.distinctLevel.length > 0) {
                    var submitli = '<li><div class="sub-pending"><h4 style="background-color :yellowgreen;color:white">Submitted</h4><p>' + result.distinctLevel[0].submittedBy + '</p></div></li>';
                    //var submitli = '<li><div class="submited">' + result.distinctLevel[0].submittedBy + '</div></li>';
                    var finalli = '<li><div class="final-approval">' + result.distinctLevel[0].prStatus + '</div></li>';
                    var pendinglist = '';

                    $.each(result.distinctLevel, function (i, item) {
                        var getLevelData = [];

                        $.each(result.approvalData, function (j, treeData) {

                            if (item.approvalLevel == treeData.approvalLevel) {
                                getLevelData.push(treeData);
                            }

                        });

                        if (getLevelData.length > 0) {
                            
                            var loopLength = getLevelData.length;
                            pendinglist += '<li>';
                            $.each(getLevelData, function (j, treeData) {
                                var colorBg = '';
                                colorBg = 'orange';
                                if (j == 0) {
                                    if (treeData.isDelegator == 0) {
                                        pendinglist += '<div class="sub-pending"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p>' + treeData.approvalName + '</p></div>';
                                    }
                                    else {
                                        pendinglist += '<div class="sub-pending"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p class="pb-0">' + treeData.approvalName + '</p><p class="pt-0">' + treeData.delegatorName + '</p></div>';
                                    }
                                }
                                else {
                                    if (treeData.isDelegator == 0) {
                                        pendinglist += '<div class="sub-pending top-line"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p>' + treeData.approvalName + '</p></div>';
                                    }
                                    else {
                                        pendinglist += '<div class="sub-pending top-line"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p class="pb-0">' + treeData.approvalName + '</p><p class="pt-0">' + treeData.delegatorName + '</p></div>';
                                    }
                                }
                            });
                            pendinglist += '</li>';
                        }

                    });

                    list = list + pendinglist;


                    //list = submitli + list;
                    //list = list + finalli;
                    $("#" + ulID).append(list.toString());
                }
                $('.loader-wrapper').hide();
            }

        });
}

function editPRDetails() {
    var hdnval = $('#hdnval').val();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Cart/GetDetail',
        data: {
            "detailNo": hdnval
        },
        success: function (data, textstatus) {
            if (data != '') {
                getRights();

                if (data.shoppingCartDetails.length > 0) {
                    $("#hdonBehalf").val(data.onBehalfOfFlag);

                    var onbehalf = '';
                    if (data.onBehalfOfFlag == 'yesOnBehalfOf') {
                        $("#selOnBehalfOfEdit").val('yesOnBehalfOf');
                    }
                    else {
                        $("#selOnBehalfOfEdit").val('noOnBehalfOf');
                    }
                    /*$("#selOnBehalfOfEdit").text(onbehalf);*/


                    if (data.onBehalfOfFlag == "yesOnBehalfOf") {

                        $(".hideDiv").show();
                        $(".hideDivEmp").hide();
                        $("#inlineRadio1Edit").prop("disabled", true);
                        $("#inlineRadio2Edit").prop("checked", true);
                        $("#txtSearchEmployee").val(data.creatorName);
                        $("#selEmployeeEdit option:selected").val(data.employeeCode);
                        $("#selEmployeeEdit option:selected").text(data.creatorName);
                        /*bindEmployeeDropDown(data.employeeCode, true);*/


                    }
                    else {
                        $(".hideDiv").hide();
                        $(".hideDivEmp").hide();
                        
                    }

                    if (data.costCenterFlag == "SC") {
                                $("#inlineRadio1Edit").prop("checked", true);
                                $("#inlineRadio2Edit").prop("checked", false);
                                $("#selCostCentreEdit").prop("disabled", true);
                            }
                            else if (data.costCenterFlag == "OT") {
                                $("#inlineRadio1Edit").prop("checked", false);
                                $("#inlineRadio2Edit").prop("checked", true);
                                $("#selCostCentreEdit").val(data.costCenterCode).trigger('change');
                            }

                    $('#editPRDetail').modal('show');
                }
            }





        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        },
        complete: function (data) {


        }
    });

}

function editDetailsPRSave() {
    $("#selPurchaseTypeEdit option:selected").text()

    const costType = document.querySelector('input[name="costTypeEdit"]:checked').value;
    var onbehalf = $("#selOnBehalfOfEdit").val();
    var ptype = $("#selPurchaseTypeEdit").val();
    if (ptype == "" || ptype == "0") {
        alert("Please Select Purchase Type!");
        $("#selPurchaseTypeEdit").focus();
        return false;
    }
    if (purchasetype == "1" || purchasetype == "2" || purchasetype == "6")
    {
        if (ptype == "4" || ptype == "5" || ptype == "7")
        {
            alert("Please select either Capex/Opex/Recovery as Purchase Type!");
            $("#selPurchaseTypeEdit").focus();
            return false;
        }

    }
    if (purchasetype == "4" || purchasetype == "5" || purchasetype == "7") {
        if (ptype == "1" || ptype == "2" || ptype == "6") {
            alert("Please select either Capex with Service/Opex with Service/Recovery with Service as Purchase Type!");
            $("#selPurchaseTypeEdit").focus();
            return false;
        }

    }
    var pgroup = $("#selPurchaseGroupEdit").val();
    if (pgroup == "" || pgroup == "0") {
        alert("Please Select Purchase Group!");
        $("#selPurchaseGroupEdit").focus();
        return false;
    }
    var pgroup = $("#selPurchaseGroupEdit").val();
    if (pgroup == "" || pgroup == "0") {
        alert("Please Select Purchase Group!");
        $("#selPurchaseGroupEdit").focus();
        return false;
    }
    var curr = $("#selCurrencyEdit").val();
    if (curr == "" || curr == "0") {
        alert("Please Select Currency");
        $("#selCurrencyEdit").focus();
        return false;
    }
    var cc = $("#selCostCentreEdit").val();
    if (cc == "" || cc == "0") {
        alert("Please Select Cost Centre");
        $("#selCostCentreEdit").focus();
        return false;
    }
    var vendor = $("#selVendorEdit").val();
    if (vendor == "" || vendor == "0") {
        alert("Please Select Vendor");
        $("#selVendorEdit").focus();
        return false;
    }
    var plant = $("#selPlantCodeEdit").val();
    if (plant == "" || plant == "0") {
        alert("Please Select Plant Code");
        $("#selPlantCodeEdit").focus();
        return false;
    }
    var po = $("#selPurchaseOrganisationEdit").val();
    if (po == "" || po == "0") {
        alert("Please Select Purchase Organisation");
        $("#selPurchaseOrganisationEdit").focus();
        return false;
    }
    if (onbehalf == 'yesOnBehalfOf') {
        var employee = $("#selEmployeeEdit").val();
        var searchtext = $("#txtSearchEmployee").val();
        if (employee == "" || employee == "0") {
            alert("Please Select Employee!");
            $("#selEmployeeEdit").focus();
            return false;
        }
        if (searchtext == "" || searchtext == "0") {
            alert("Please Enter Search Text!");
            $("#txtSearchEmployee").focus();
            return false;
        }
    }
    $.ajax({
        type: 'POST',
        url: appUrl + 'Cart/editPRDetails',
        data: {

            "PurchaseType": $("#selPurchaseTypeEdit option:selected").text(), "PurchaseTypeCode": $("#selPurchaseTypeEdit option:selected").val(), "PurchaseGroup": $("#selPurchaseGroupEdit option:selected").val(), "PurchaseGroupText": $("#selPurchaseGroupEdit option:selected").text(),
            "Currency": $("#selCurrencyEdit option:selected").val(),
            "CostCenter": $("#selCostCentreEdit option:selected").text(), "CostCenterCode": $("#selCostCentreEdit option:selected").val(), "CostCenterFlag": costType, /*"glCode": $("#selGLCode").val(),*/
            "PlantCode": $("#selPlantCodeEdit option:selected").val(), "PlantName": $("#selPlantCodeEdit option:selected").text(), "PurchaseOrganisationCode": $("#selPurchaseOrganisationEdit option:selected").val(), "PurchaseOrganisation": $("#selPurchaseOrganisationEdit option:selected").text(),
            "Vendor": $("#selVendorEdit option:selected").text(), "VendorCode": $("#selVendorEdit option:selected").val(), "OnBehalfOfFlag": $("#selOnBehalfOfEdit option:selected").val(), "EmployeeCode": $("#selEmployeeEdit option:selected").val(), "CreatorName": $("#selEmployeeEdit option:selected").text()
        },
        success: function (data, textstatus) {
            if (data != '') {


                if (data.responseCode == 1) {
                    alert("The Details are edited Successfully!");
                    $('.loader-wrapper').hide();
                    location.href = appUrl + "Cart/Index";

                    //var fileUpload = $("#formFileMultiple").get(0);
                    //var files = fileUpload.files;
                    //if (files.length > 0) {
                    //    uploadFiles($("#hdCartDetail").val());
                    //}
                    //else {
                    //    $('.loader-wrapper').hide();
                    //    alert("Details edit Successfully!");
                    //    location.href = appUrl + "Cart/Index";
                    //}

                    //alert("Details edit Successfully!");
                    //location.href = appUrl + "Cart/Index";
                }
                else if (data.responseCode == 3) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    $('.loader-wrapper').hide();
                    alert(data.responseMessage);
                }

            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function EditClose() {
    $('#editPRDetail').modal('hide');
}

function searchUser() {
    $(".hideDivEmp").show();
    var searchString = $("#txtSearchEmployee").val();
    if (searchString == '') {
        alert("Please enter search text!");
        return false;

    }
    else if (searchString.length < 2) {
        alert("Please provide at least three characters to search!");
        return false;

    }
    $('.loader-wrapper').show();

    $("#selEmployeeEdit").empty();
    $("#selEmployeeEdit").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "SearchUser", "SearchParameter1": searchString
        },
        success: function (data, textstatus) {
            if (data.responseCode == 1) {

                $.each(data.masterDataResponses, function () {
                    $("#selEmployeeEdit").append($("<option />").val(this.valueField).text(this.displayField));
                });
            }

            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });


}

function getRights() {
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetUserBehalfRight',
        data: {

        },
        success: function (data, textstatus) {
            if (data == '') {
                $("#selOnBehalfOfEdit").val("noOnBehalfOf");
                $("#selOnBehalfOfEdit").prop("disabled", true);
            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

$(document).ready(function () {
    $("#selEmployeeEdit").change(function () {
        if ($("#selEmployeeEdit").val() != "0") {
            getOtherCostCenter();
        }
        else {
            $("#selCostCentreEdit").val(0);
        }
    });
});

function getOtherCostCenter() {
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetOtherCostCenter',
        data: {
            "EntityName": "CCBYEID", "SearchParameter1": $("#selEmployeeEdit").val()
        },
        success: function (data, textstatus) {
            if (data != '') {
                $("#selCostCentreEdit").val(data).trigger('change');
            }

            $('.loader-wrapper').hide();
            //$("#selCostCentre").prop("disabled", true);
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}