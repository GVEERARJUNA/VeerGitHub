﻿var appUrl = '';
var addedCompany = [];
var addedRight = [];
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();

    GetUserMasterPageData(1, 20);
});

function SearchUser() {
    GetUserMasterPageData(1, 20);
}

function bindRole(userid) {
    $("#tbodyRole").empty();

    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/GetMasterData',
        data: {
            "EntityName": "RoleMaster"
        },
        success: function (data, textstatus) {
            if (data != '') {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(i + 1),
                            /*$('<td>').text(item.valueField),*/
                            $('<td>').text(item.displayField),

                            $('<td class="text-center">').html("<div class='form - check'> <input class='form - check - input' type='checkbox' value='' id='flexCheckDefault'> <label class='form - check - label' for='flexCheckDefault'></label> </div>")
                        );

                        $("#tbodyRole").append($tr);
                    });




                }
                else if (data.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(data.responseMessage);
                }

            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}


/*User Master*/
function GetUserMasterPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#userDataBody").empty();
    $("#userPageList").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetUserData?RowsOfPage",
            //url: "GetUserData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum,"&UserName=" // Controller/View
            data: { "RowsOfPage": pageSize, "PageNumber": pageNum, "UserName": $("#username").val()},
            success: function (result) {

                if (result.recordCount > 0) {
                    $.each(result.userManagementResponses, function (i, item) {
                        var empID = "'" + item.employeeId + "'";
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.srNo),
                            $('<td>').text(item.employeeId),
                            $('<td>').text(item.fullName),
                            $('<td>').text(item.emailId),
                            $('<td>').text(item.departmentName),
                            $('<td>').text(item.currentRole),
                            /*$('<td>').html(' <a href="#" title="Assign Company" class= "text-success assign-company me-1" onclick = "bindCompany(' + item.employeeId + ')" ><i class="fa-solid fa-user-plus"></i></a ><a href="#" title="Assign Role" onclick="bindRole(' + item.employeeId + ')"class="text-success assign-role ms-1"><i class="fa-solid fa-user-gear"></i></a> | <a href="#" title="Assign Delegator" class="text-success assign-delegator ms-1" data-toggle="model" data-target="createDelgation" id="assignDelgator" onclick="OpenDelegationDetails(' + "'" + item.fullName + "','" + item.employeeId +"'"+ ')"> <i class="fa-solid fa-user-group"></i></a> | <a href="#" title="Delete" class="text-danger ms-1 delete-row"><i class="fa-solid fa-trash-can"></i></a>')*/
                            $('<td>').html('<a href="#" title="Assign Company" class= "text-success assign-company me-1" onclick = "bindCompany(' + empID + ')" ><i class="fa-solid fa-user-plus"></i></a > <a href="#" title="Assign Delegator" class="text-success assign-delegator ms-1" data-toggle="model" data-target="createDelgation" id="assignDelgator" onclick="OpenDelegationDetails(' + "'" + item.employeeId + "','" + item.employeeId + "'" + ')"> <i class="fa-solid fa-user-group"></i></a> <a href="#" title="Assign Rights" class= "text-success assign-company me-1" onclick = "bindRights(' + empID + ')" ><i class="fa-solid fa-user-plus"></i></a ><a href="#" title="Assign Supplier" class="text-success assign-supplier me-1" onclick = "openAssignSupplier(' + empID + ')" ><i class="fas fa-user-tag"></i></a>')
                        );
                        $("#userDataBody").append($tr);
                    });


                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="7">').text('No records to display'));
                    $("#userDataBody").append($tr);
                }

                UserMasterPaging(result.recordCount, pageNum);
                $('.loader-wrapper').hide();



            }

        });

}

function UserMasterPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetUserMasterPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetUserMasterPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetUserMasterPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetUserMasterPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetUserMasterPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#userPageList").append(template);
}

function OpenUserDetails() {
    $('.loader-wrapper').show();
    console.log('OpenUserDetails');
    /*clear seartch*/
    $("#selUserEmployee").empty();
    $("#selUserRole").empty();
    document.getElementById('txtUserSearchEmployee').value = '';
    
    $("#userDetails").modal('show');
   
    var selectedValue = $("#selUserRole").val();
    $("#selUserRole").empty();
    $("#selUserRole").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "UserType"
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selUserRole").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selUserRole").val(selectedValue);
                }


                $('.loader-wrapper').hide();
            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
    
    //bindUserRoleDropDown($("#selUserRole").val());

}

function bindUserTypeDropDown() {
    
}

function searchUserEmployee() {
    var searchString = $("#txtUserSearchEmployee").val();
    if (searchString == '') {
        alert("Please enter search text!");
        return false;

    }
    else if (searchString.length < 2) {
        alert("Please provide at least three characters to search!");
        return false;

    }
    $('.loader-wrapper').show();

    $("#selUserEmployee").empty();
    $("#selUserEmployee").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "ManageSearchUser", "SearchParameter1": searchString
        },
        success: function (data, textstatus) {
            if (data.responseCode == 1) {

                $.each(data.masterDataResponses, function () {
                    $("#selUserEmployee").append($("<option />").val(this.valueField).text(this.displayField));
                });
            }

            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });


}

function bindUserRoleDropDown() {
    var selectedValue = $("#selUserRole").val();
    $("#selUserRole").empty();
    $("#selUserRole").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "RoleMaster"
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selUserRole").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selUserRole").val(selectedValue);
                }



            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function addUser() {
   
    if ($("#selUserEmployee").val() == 0 || $("#selUserEmployee").val() == null || $("#selUserEmployee").val() == "") {
        alert("Please select employee");
    }
    else if ($("#selUserRole").val() == 0 || $("#selUserRole").val() == null || $("#selUserRole").val() == "") {
        alert("Please select UserType");
    }
    else {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/AddUser',
            data: {
                "UserName": $("#selUserEmployee").val(),
                "Action": "ADDUSER",
                "Roles": $("#selUserRole").val()
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert("Data Saved Succefully.");
                    GetUserMasterPageData(1, 20);
                    $("#userDetails").modal('hide');
                }
                else {
                    alert(pdata.responseMessage);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }
}

//$("#addUser").click(function () {
//    alert("Clicl");
//    if ($("#selUserEmployee").val() == 0 || $("#selUserEmployee").val() == null || $("#selUserEmployee").val() == "") {
//        alert("Please select employee");
//    }
//    else if ($("#selUserRole").val() == 0 || $("#selUserRole").val() == null || $("#selUserRole").val() == "") {
//        alert("Please select Role");
//    }
//    else {
//        $.ajax({
//            type: 'POST',
//            url: appUrl + 'Admin/AddUser',
//            data: {
//                "UserName": $("#selUserEmployee").val(),
//                "Action": "ADDUSER",
//                "Roles": $("#selUserRole").val()
//            },
//            success: function (pdata) {
//                if (pdata.responseCode == 1) {
//                    alert("Data Saved Succefully.");
//                    GetUserMasterPageData(1, 20);
//                    $("#userDetails").modal('hide');
//                }
//                else {
//                    alert(pdata.responseMessage);
//                }
//            },
//            error: function (XMLHttpRequest, textStatus, errorThrown) {

//            }
//        });
//    }
//})

function OpenDelegationDetails(fullName, employeeId) {

    console.log('OpenDelegationDetails');
    $("#divDelegatee").hide();
    $("#createDelgation").modal('show');
    $("#selDelegatorCode").text(fullName);
    GetDelegationDetails(employeeId);

}

function GetDelegationDetails(EmployeeId) {
    console.log('GetDelegationDetails');
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/GetDelegationDetails',
        data: {
            "EmployeeId": EmployeeId
        },
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                var _result = JSON.parse(pdata.responseJSON);
                console.log(_result);
                $("#bodyDelegatee").empty();
                if (_result != null && pdata.responseJSON != "[]") {
                    $.each(_result, function (i, item) {
                        console.log(item);
                        var $tr = $('<tr>').append(
                            $('<td>').text(i + 1),
                            $('<td>').text(item.Delegatee),
                            $('<td>').text(item.StartDate),
                            $('<td>').text(item.EndDate),
                            $('<td>').text(item.DelegationReason),
                        );
                        $("#bodyDelegatee").append($tr);

                    });

                    $("#divDelegatee").show();
                }
                else {
                    $("#divDelegatee").hide();
                }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function saveDelegation() {
    console.log('Add Delagator');
    var delegatorDetails = $("#selDelegatorCode").text();
    var delegotorEmpCode = delegatorDetails;
    console.log(delegotorEmpCode);
    if (delegotorEmpCode == null || delegotorEmpCode == "") {
        alert("Please select Delegator");
    }
    else if ($("#Delegate").val() == null || $("#Delegate").val() == "") {
        alert("Please select Delegatee");
    }
    else if ($("#delegatorStart").val() == 0 || $("#delegatorStart").val() == null || $("#delegatorStart").val() == "") {
        alert("Please select Start Date");
    }
    else if ($("#delegatorEnd").val() == 0 || $("#delegatorEnd").val() == null || $("#delegatorEnd").val() == "") {
        alert("Please select End Date");
    }
    else if ($("#DelegationReason").val() == null || $("#DelegationReason").val() == "") {
        alert("Please select Delegation Reason");
    }
    else {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/AddDelegator',
            data: {
                "Action": "ADD",
                "DelgatorEMPCode": delegotorEmpCode,
                "DelegateeEMPCode": $("#Delegate").val(),
                "StartDate": $("#delegatorStart").val(),
                "EndDate": $("#delegatorEnd").val(),
                "DelegationReason": $("#DelegationReason").val()
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert("Data Saved Succefully.");
                    GetUserMasterPageData(1, 20);
                    $("#createDelgation").modal('hide');
                }
                else {
                    alert(pdata.responseMessage);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }
}

/* Assign Company  */
function bindCompany(userid) {
    $("#tbodyCompany").empty();
    $("#hiduserID").val(userid);
    
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "AssignedCompanyMaster", "SearchParameter1": userid
        },
        success: function (data, textstatus) {
            if (data != '') {
                if (data.responseCode == 1) {
                    if (data.masterDataResponses.length>0) {
                        addedCompany = data.masterDataResponses;
                    }
                    
                    $.each(data.masterDataResponses, function (i, item) {
                        var checkBoxID = 'chk' + item.valueField;
                        //alert(item.checkStatus);
                        var checkbox;
                        if (item.checkStatus == 1) {
                            if (item.isDefault == 1) {
                                checkbox = "<input checked class='form - check - input' disabled type='checkbox' value='' id=" + checkBoxID + ">";
                            }
                            else {
                                checkbox = "<input checked class='form - check - input' type='checkbox' value='' id=" + checkBoxID + ">";
                            }
                            
                        }
                        else {
                            checkbox = "<input class='form - check - input' type='checkbox' value='' id=" + checkBoxID + ">";
                        }
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(i + 1),
                            $('<td>').text(item.valueField),
                            $('<td>').text(item.displayField),

                            $('<td class="text-center">').html("<div class='form - check'> " + checkbox +  " <label class='form - check - label' for='flexCheckDefault'></label> </div>")
                        );

                        var $td = "";

                        $("#tbodyCompany").append($tr);
                    });

                    $("#assignCompany").modal('show');


                }
                else if (data.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(data.responseMessage);
                }

            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function addCompany() {
    
    var checkedCompany = '';
    if (addedCompany.length > 0) {
        $.each(addedCompany, function (i, item) {
            var checkBoxID = '#chk' + item.valueField;
            
            if ($(checkBoxID).prop('checked') == true) {
                if (checkedCompany=='') {
                    checkedCompany = item.valueField;
                }
                else {
                    checkedCompany = checkedCompany + ',' + item.valueField;
                }
            }

            

        });

        if (checkedCompany == '') {
            alert("Please select atleast one Company!");
            return false;
        }

        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/AddUser',
            data: {
                "UserName": $("#hiduserID").val(),
                "Action": "ASSIGNCOMPANY",
                "Companies": checkedCompany
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert("Data Saved Succefully.");
                    
                    $("#assignCompany").modal('hide');
                }
                else {
                    alert(pdata.responseMessage);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("There is some issue!");
            }
        });

    }
    //if ($("#selUserEmployee").val() == 0 || $("#selUserEmployee").val() == null || $("#selUserEmployee").val() == "") {
    //    alert("Please select employee");
    //}
    //else if ($("#selUserRole").val() == 0 || $("#selUserRole").val() == null || $("#selUserRole").val() == "") {
    //    alert("Please select Role");
    //}
    //else {
    //    $.ajax({
    //        type: 'POST',
    //        url: appUrl + 'Admin/AddUser',
    //        data: {
    //            "UserName": $("#selUserEmployee").val(),
    //            "Action": "ADDUSER",
    //            "Roles": $("#selUserRole").val()
    //        },
    //        success: function (pdata) {
    //            if (pdata.responseCode == 1) {
    //                alert("Data Saved Succefully.");
    //                GetUserMasterPageData(1, 20);
    //                $("#userDetails").modal('hide');
    //            }
    //            else {
    //                alert(pdata.responseMessage);
    //            }
    //        },
    //        error: function (XMLHttpRequest, textStatus, errorThrown) {

    //        }
    //    });
    //}
}

/* Assign Right  */

function bindRights(userid) {
    $("#tbodyRight").empty();
    $("#hiduserID").val(userid);

    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "AssignedRightMaster", "SearchParameter1": userid
        },
        success: function (data, textstatus) {
            if (data != '') {
                if (data.responseCode == 1) {
                    if (data.masterDataResponses.length > 0) {
                        addedRight = data.masterDataResponses;
                    }

                    $.each(data.masterDataResponses, function (i, item) {
                        var checkBoxID = 'chk' + item.valueField;
                        //alert(item.checkStatus);
                        var checkbox;
                        if (item.checkStatus == 1) {
                            checkbox = "<input checked class='form - check - input' type='checkbox' value='' id=" + checkBoxID + ">";
                        }
                        else {
                            checkbox = "<input class='form - check - input' type='checkbox' value='' id=" + checkBoxID + ">";
                        }
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(i + 1),
                            $('<td>').text(item.valueField),
                            $('<td>').text(item.displayField),

                            $('<td class="text-center">').html("<div class='form - check'> " + checkbox + " <label class='form - check - label' for='flexCheckDefault'></label> </div>")
                        );

                        var $td = "";

                        $("#tbodyRight").append($tr);
                    });

                    $("#assignRight").modal('show');


                }
                else if (data.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(data.responseMessage);
                }

            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function addRight() {

    var checkedCompany = '';
    if (addedRight.length > 0) {
        $.each(addedRight, function (i, item) {
            var checkBoxID = '#chk' + item.valueField;

            if ($(checkBoxID).prop('checked') == true) {
                if (checkedCompany == '') {
                    checkedCompany = item.valueField;
                }
                else {
                    checkedCompany = checkedCompany + ',' + item.valueField;
                }
            }



        });

        //if (checkedCompany == '') {
        //    alert("Please select atleast one Right!");
        //    return false;
        //}

        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/AddUser',
            data: {
                "UserName": $("#hiduserID").val(),
                "Action": "ASSIGNRIGHT",
                "Companies": checkedCompany
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert("Data Saved Succefully.");
                    addedRight = [];
                    $("#assignRight").modal('hide');
                }
                else {
                    alert(pdata.responseMessage);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                alert("There is some issue!");
            }
        });

    }
    
}
function selectPicker2() {
    $(".selectPicker2").select2();
}
/* Assign Supplier */
function openAssignSupplier(empid) {
    $("#assignSupplier").modal('show');
    $("#lblEmpCode").text(empid);
    selectPicker2();
    bindSupplyDropDown(empid);
    getAssignedSuppliers(empid);
}
function bindSupplyDropDown(empid) {
    $("#hdEmpCode").val(empid);
    $("#SelectSupplier").empty();
    $("#SelectSupplier").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "SupplierNotAssignedEMP", "SearchParameter1": empid
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#SelectSupplier").append($("<option />").val(this.valueField).text(this.displayField));

                });


               

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}
function addSupplierAssignment() {
    var selectedSupplier = $("#SelectSupplier").val();
    if (selectedSupplier=="0") {
        alert("Please select supplier!");
        return false;
    }

    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/SupplierEmployeeAssign',
        data: {
            "Action": "Assign", "EmpCode": $("#hdEmpCode").val(), "SupplierCode": selectedSupplier
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                alert("SUCCESS");
                bindSupplyDropDown($("#hdEmpCode").val());
                getAssignedSuppliers($("#hdEmpCode").val());
            }
            else {
                alert(pdata.responseMessage);
            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}
function getAssignedSuppliers(empid) {
    $("#tbodySupplierMapping").empty();
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/SupplierEmployeeAssign',
        data: {
            "Action": "GETASSIGN", "EmpCode": $("#hdEmpCode").val()
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                var responseData = JSON.parse(pdata.responseJSON);
                $.each(responseData, function (i, item) {
                   
                    var $tr = $('<tr>').append(
                        $('<td class="text-center">').text(i + 1),
                        $('<td>').text(item.VendorName),

                        $('<td>').html('<a href="javascript:;" class="mr-2" onclick="deletesupplierAssignment(' + item.VendorCode + ",'" + $("#hdEmpCode").val() + "'" + ')"><i class="fas fa-trash-alt text-danger"></i></a>')
                    );
                    $("#tbodySupplierMapping").append($tr);
                });
                
            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}

function deletesupplierAssignment(VendorCode,EmpCode) {
   
    var isDelate = window.confirm('Are you sure you want to delete this mapping?');
    if (isDelate) {
        $('.loader-wrapper').show();
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/SupplierEmployeeAssign',
            data: {
                "Action": "DELETEASSIGN", "EmpCode": EmpCode, "SupplierCode": VendorCode
            },
            success: function (pdata, textstatus) {
                if (pdata.responseCode == 1) {
                    alert("SUCCESS");
                    bindSupplyDropDown($("#hdEmpCode").val());
                    getAssignedSuppliers($("#hdEmpCode").val());
                }
                else {
                    alert(pdata.responseMessage);
                }
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
    }
}