﻿var appUrl = '';
$(document).ready(function () {
    appUrl = setAppUrl();
    var $tr = $('<tr>').append($('<td class="text-center" colspan="5">').text('No records to display'));
    $("#ccRateBody").append($tr);
    bindCurrencyDropDown();

    $("#txtConversionValue").keypress(function (event) {

        if ((event.which != 46 || $(this).val().indexOf('.') != -1) &&

            ((event.which < 48 || event.which > 57) &&

                (event.which != 0 && event.which != 8))) {

            event.preventDefault();

        }
        var text = $(this).val();
        if ((text.indexOf('.') != -1) &&

            (text.substring(text.indexOf('.')).length > 2) &&

            (event.which != 0 && event.which != 8) &&

            ($(this)[0].selectionStart >= text.length - 2)) {

            event.preventDefault();

        }

    });

});
$("#btnSearchCurrency").click(function () {
    if ($("#ddlYear").val() == "0") {
        alert("Please select Year!");
        return false;
    }
    if ($("#ddlMonth").val() == "0") {
        alert("Please select Motnh!");
        return false;
    }

    GetCurrencyConversion();

});

$("#btnAddConversion").click(function () {
    $("#addCurrencyConversion").modal('show');

});
function GetCurrencyConversion() {
    $('.loader-wrapper').show();
    $("#ccRateBody").empty();
    
    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: appUrl + 'Admin/ManageCurrencyConvesion',
            dataType: "JSON",
            data: {
                "Action": "L", "ConversionYear": $("#ddlYear").val(), "ConversionMonth": $("#ddlMonth").val()
            },
            success: function (result) {
                if (result.responseCode == 1) {
                    var reportData = JSON.parse(result.responseJSON);
                    if (reportData.length > 0) {
                        $.each(reportData, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(i + 1),
                                $('<td>').text(item.FromCurrency),
                                $('<td>').text(item.ToCurrency),
                                $('<td>').text(item.ConversionRate),
                                $('<td >').html('&nbsp; <a href="#" onclick=removeConversion(' + item.ConversionID + ')> <i class="fa-solid fa-trash-can"></i></a>')
                            );
                            $("#ccRateBody").append($tr);
                        });

                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('No records to display'));
                        $("#ccRateBody").append($tr);
                    }
                    


                }
                else {
                    alert(result.responseMessage);
                   
                }
               
                $('.loader-wrapper').hide();



            }

        });
}
function SaveCurrencyConversion() {
    $('.loader-wrapper').show();
    
    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: appUrl + 'Admin/ManageCurrencyConvesion',
            dataType: "JSON",
            data: {
                "Action": "A", "ConversionYear": $("#ddlModalYear").val(), "ConversionMonth": $("#ddlModalMonth").val(),
                "ConversionRate": $("#txtConversionValue").val(),
                "FromCurrency": $("#ddlFromCurrency").val()

            },
            success: function (result) {
                if (result.responseCode == 1) {
                    alert("Successfully added!");
                    $("#ddlModalYear").val("0");
                    $("#ddlModalMonth").val("0");
                    $("#ddlFromCurrency").val("0");
                    $("#txtConversionValue").val("0");

                }
                else {
                    alert(result.responseMessage);

                }

                $('.loader-wrapper').hide();



            }

        });
}
function bindCurrencyDropDown() {
    $("#ddlFromCurrency").empty();
    $("#ddlFromCurrency").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "CurrencyConversion"
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#ddlFromCurrency").append($("<option />").val(this.valueField).text(this.displayField));

                });



            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}
function removeConversion(ccID) {
    if (confirm('Do you want to delete details?')) {
        $('.loader-wrapper').show();

        $.ajax(
            {
                type: "POST", //HTTP POST Method  
                url: appUrl + 'Admin/ManageCurrencyConvesion',
                dataType: "JSON",
                data: {
                    "Action": "D",
                    "CurrencyConversionID": ccID,


                },
                success: function (result) {
                    if (result.responseCode == 1) {
                        alert("Successfully deleted!");
                        GetCurrencyConversion();
                    }
                    else {
                        alert(result.responseMessage);

                    }

                    $('.loader-wrapper').hide();



                }

            });

    }
}