﻿var appUrl = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();


});
/********** Cost Center *************/
function OpenCostCenter() {
    $("#mdAddCC").modal('show');
    BindCompany();
    resetCCControl();
}
function AddNewCC() {
    if ($("#ddlPopUpCompany").val() == "0") {
        alert("Please select Company");
        return false;
    }
    var CCCode = $("#txtCCCode").val();
    if (CCCode == "") {
        alert("Please enter cost center code!");
        $("#txtCCCode").focus();
        return false;
    }
    else if (CCCode.length > 20) {
        alert("Cost center code cannot exceed 20 characters!");
        $("#txtCCCode").focus();
        return false;
    }

    var CCName = $("#txtCCName").val();
    if (CCName == "") {
        alert("Please enter cost center name!");
        $("#txtCCName").focus();
        return false;
    }
    else if (CCName.length > 100) {
        alert("Cost center name cannot exceed 100 characters!");
        $("#txtCCName").focus();
        return false;
    }
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/MastersInsert',
        data: {
            "CompanyCode": $("#ddlPopUpCompany").val(),
            "Action": "ADDCC",
            "IParam1": $("#txtCCCode").val(),
            "IParam2": $("#txtCCName").val(),
        },
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                alert("Data Saved Succefully.");
                resetCCControl();
            }
            else {
                alert(pdata.responseMessage);
            }
            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}
function BindCompany() {
    $('.loader-wrapper').show();
    $("#ddlPopUpCompany").empty();
    $("#ddlPopUpCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            dataType: "JSON",
            data: {
                "EntityName": "CompanyMaster"
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#ddlPopUpCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function resetCCControl() {
    $("#ddlPopUpCompany").val("0");
    $("#txtCCCode").val("");
    $("#txtCCName").val("");
}
/********** Vendor *************/
function OpenVendorMaster() {
    $("#mdAddVendor").modal('show');
    BindCompany();
    resetVendorControl();
}
function resetVendorControl() {
    $("#ddlPopUpCompany").val("0");
    $("#txtVendorCode").val("");
    $("#txtVendorName").val("");
}
function AddNewVendor() {
    if ($("#ddlPopUpCompany").val() == "0") {
        alert("Please select Company");
        return false;
    }
    var VendorCode = $("#txtVendorCode").val();
    if (VendorCode == "") {
        alert("Please enter vendor code!");
        $("#txtVendorCode").focus();
        return false;
    }
    else if (VendorCode.length > 20) {
        alert("Vendor code cannot exceed 30 characters!");
        $("#txtVendorCode").focus();
        return false;
    }

    var VendorName = $("#txtVendorName").val();
    if (VendorName == "") {
        alert("Please enter vendor name!");
        $("#txtVendorName").focus();
        return false;
    }
    else if (VendorName.length > 100) {
        alert("Vendor name cannot exceed 100 characters!");
        $("#txtVendorName").focus();
        return false;
    }
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/MastersInsert',
        data: {
            "CompanyCode": $("#ddlPopUpCompany").val(),
            "Action": "ADDVENDOR",
            "IParam1": VendorCode,
            "IParam2": VendorName
        },
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                alert("Data Saved Succefully.");
                resetVendorControl();
            }
            else {
                alert(pdata.responseMessage);
            }
            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}
/********** Plant Code *************/


function OpenPlantCodeMaster() {
    $("#mdAddPlantCode").modal('show');
    BindCompany();
    resetPlantCodeControl();
}
function resetPlantCodeControl() {
    $("#ddlPopUpCompany").val("0");
    $("#txtPCPlantCode").val("");
    $("#txtPCPlantName").val("");
    $("#txtPCAddressLine1").val("");
    $("#txtPCAddressLine2").val("");
    $("#txtPCPOBox").val("");
    $("#txtPCPostalCode").val("");
    $("#txtPCCity").val("");
}
function AddNewPlantCode() {
    if ($("#ddlPopUpCompany").val() == "0") {
        alert("Please select Company");
        return false;
    }


    var PlantCode = $("#txtPCPlantCode").val();
   
    if (PlantCode == "") {
        alert("Please enter Plant Code!");
        $("#txtPCPlantCode").focus();
        return false;
    }


    else if (PlantCode.length > 20) {
        alert("Plant Code cannot exceed 30 characters!");
        $("#txtPCPlantCode").focus();
        return false;
    }
    var PlantName = $("#txtPCPlantName").val();
    if (PlantName == "") {
        alert("Please enter Plant Name!");
        $("#txtPCPlantName").focus();
        return false;
    }

    else if (PlantName.length > 200) {
        alert("Plant Name cannot exceed 200 characters!");
        $("#txtPCPlantName").focus();
        return false;
    }
    var AddressLine1 = $("#txtPCAddressLine1").val();
    if (AddressLine1.length > 200) {
        alert("Address Line1 cannot exceed 200 characters!");
        $("#txtPCAddressLine1").focus();
        return false;
    }

    var AddressLine2 = $("#txtPCAddressLine2").val();
    if (AddressLine2.lenght > 200) {
        alert("Address Line2 cannot exceed 200 characters!");
        $("#txtPCAddressLine2").focus();
        return false;
    }
    var POBox = $("#txtPCPOBox").val();
    if (POBox.length > 200) {
        alert("POBox cannot exceed 200 characters!");
        $("#txtPCPOBox").focus();
        return false;
    }
    var PostalCode = $("#txtPCPostalCode").val();
    if (PostalCode.length > 200) {
        alert("PostalCode cannot exceed 200 characters!");
        $("#txtPCPostalCode").focus();
        return false;
    }

    var City = $("#txtPCCity").val();
    if (City.length > 200) {
        alert("City cannot exceed 200 characters!");
        $("#txtPCCity").focus();
        return false;
    }

    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/MastersInsert',
        data: {
            "CompanyCode": $("#ddlPopUpCompany").val(),
            "Action": "AddNewPlantCode",
            "IParam1": PlantCode,
            "IParam2": PlantName,
            "IParam3": AddressLine1,
            "IParam4": AddressLine2,
            "IParam5": POBox,
            "IParam6": PostalCode,
            "IParam7": City


        },

        success: function (pdata) {
            if (pdata.responseCode == 1) {
                alert("Data Saved Succefully.");
                resetPlantCodeControl();
            }
            else {
                alert(pdata.responseMessage);
            }
            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}

/********** Purchase Organization *************/

function OpenPurchaseOrganisation() {
    $("#mdAddPurchaseOrganization").modal('show');
    BindCompany();
    resetPurchaseOrganisation();
}

function resetPurchaseOrganisation() {
    $("#ddlPopUpCompany").val("0");
    $("#txtPOrgID").val("");
    $("#txtPOrgCode").val("");
    $("#txtPOrgName").val("");

}

function AddNewPurchaseOrganisation() {
    if ($("#ddlPopUpCompany").val() == "0") {
        alert("Please select Company");
        return false;
    }
    
    var POrgID = $("#txtpoPOrgID").val();

    if (POrgID == "") {
        alert("Please enter POrgID !");
        $("#txtpoPOrgID").focus();
        return false;
    }

    else if (POrgID.length > 20) {
        alert("POrgID cannot exceed 30 characters!");
        $("#txtpoPOrgID").focus();
        return false;
    }

    var POrgCode = $("#txtpoPOrgCode").val();
    if (POrgCode.length > 20) {
        alert("POrgCode cannot exceed 200 characters!");
        $("#txtpoPOrgCode").focus();
        return false;
    }

    var POrgName = $("#txtpoPOrgName").val();
    if (POrgName.length > 200) {
        alert("POrgName cannot exceed 200 characters!");
        $("#txtpoPOrgName").focus();
        return false;
    }

    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/MastersInsert',
        data: {
            "CompanyCode": $("#ddlPopUpCompany").val(),
            "Action": "AddNewPurchaseOrganisation",
           /* "IParam1": POrgID,*/
            "IParam2": POrgCode,
            "IParam3": POrgName,
        },
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                alert("Data Saved Succefully.");
                resetPurchaseOrganisation();
            }
            else {
                alert(pdata.responseMessage);
            }
            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}
    

