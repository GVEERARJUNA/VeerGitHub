﻿var appUrl = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();

    if (pageURL.indexOf('/Report/PRSummary') != -1) {

        var $tr = $('<tr>').append(
            $('<td colspan="11">').text("No records to display"));

        $("#reportBody").append($tr);
        bindStatusDropDown();
    }
    if (pageURL.indexOf('/Report/PRAgingReport') != -1) {
        var $tr = $('<tr>').append(
            $('<td colspan="6" class="">').text("No records to display!"));
        $("#reportBody").append($tr);
    }
    if (pageURL.indexOf('/Report/SummaryReport') != -1) {
        var $tr = $('<tr>').append(
            $('<td colspan="11" class="">').text("No records to display!"));
        $("#summaryReportBody").append($tr);
    }
    if (pageURL.indexOf('/Report/SummaryReportDetails') != -1) {
        var $tr = $('<tr>').append(
            $('<td colspan="9" class="">').text("No records to display!"));
        $("#PRDetailBody").append($tr);

        var companyCode = GetParameterValues('companyCode');
        var StatusID = GetParameterValues('StatusID');
        if (companyCode != undefined && StatusID != undefined) {
            openReportDetail(companyCode, StatusID);

        }
    }

    $("#btnPRAgingReportExport").click(function () {

        $("input[name='GridHtml']").val($("#tbPRAgingReport").html());
    });

    $("#btnAdminActivityReportExport").click(function () {

        let fromDate = $("#DateRange").val().substring(0, 12);
        let toDate = $("#DateRange").val().substring(13, 25);
        $("input[name='fromDate']").val(fromDate);
        $("input[name='toDate']").val(toDate);
    });

    $("#btnPRSummaryReportExport").click(function () {
        if ($("#costCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }

        let fromDate = $("#DateRange").val().substring(0, 12);
        let toDate = $("#DateRange").val().substring(13, 25);

        
        $("input[name='costCompany']").val($("#costCompany").val());
        $("input[name='fromDate']").val(fromDate);
        $("input[name='toDate']").val(toDate);
        $("input[name='ddlStatus']").val($("#ddlStatus").val());
    });

    GetCostCenterCompanyMaster();

    if (pageURL.indexOf('/Report/OrderReport') != -1) {

        var $tr = $('<tr>').append(
            $('<td colspan="15">').text("No records to display"));

        $("#reportBody").append($tr);
       
    }
    $("#btnExportOrderReport").click(function () {
        
        let fromDate = $("#DateRange").val().substring(0, 12);
        let toDate = $("#DateRange").val().substring(13, 25);
        $("input[name='OrderID']").val($("#txtOrderID").val());
        $("input[name='fromDate']").val(fromDate);
        $("input[name='toDate']").val(toDate);
      
    });
    $("#btnExportReceiptReport").click(function () {
        if ($("#ddlSearchBy").val() != "0") {
            if ($("#ddlSearchBy").val() == "1" || $("#ddlSearchBy").val() == "2") {
                if ($("#txtOrderID").val() == "") {
                    alert("Please provide search text!");
                    return false;
                }
            }

        }
        else {
            alert("Please select search by!");
            return false;
        }

        let fromDate = $("#DateRange").val().substring(0, 12);
        let toDate = $("#DateRange").val().substring(13, 25);
        $("input[name='OrderID']").val($("#txtOrderID").val());
        $("input[name='hdddlSearchBy']").val($("#ddlSearchBy").val());
        $("input[name='fromDate']").val(fromDate);
        $("input[name='toDate']").val(toDate);

    });

    $("#btnExportRequistionReport").click(function () {

        let fromDate = $("#DateRange").val().substring(0, 12);
        let toDate = $("#DateRange").val().substring(13, 25);
        $("input[name='hdddlStatus']").val($("#ddlStatus").val());
        $("input[name='fromDate']").val(fromDate);
        $("input[name='toDate']").val(toDate);

    });

    if (pageURL.indexOf('/Report/ReceiptReport') != -1) {

        var $tr = $('<tr>').append(
            $('<td colspan="9">').text("No records to display"));

        $("#reportReceiptBody").append($tr);

        $("#divSearchText").show();
        $("#divSearchDate").hide();

        $("#ddlSearchBy").change(function () {
            var searchBy = $("#ddlSearchBy").val();
            if (searchBy == "1" || searchBy == "2") {
                $("#divSearchText").show();
                $("#divSearchDate").hide();
            }
            else if (searchBy == "3" || searchBy == "4") {
                $("#divSearchText").hide();
                $("#divSearchDate").show();
            }
            else {
                $("#divSearchText").show();
                $("#divSearchDate").hide();
                $("#txtOrderID").val('')
            }
        });
    }
    if (pageURL.indexOf('/Report/RequistionReport') != -1) {

        var $tr = $('<tr>').append(
            $('<td colspan="19">').text("No records to display"));

        $("#reportRequistionBody").append($tr);

       
    }

    $("#btnReportExport").click(function () {

        //$("input[name='GridHtml']").val($("#tbSummaryReportDetails").html());
        CopyToClipboard('tbSummaryReportDetails');
        //const container = document.getElementById('tbSummaryReportDetails');
        //var email = 'deepak.rohilla@teamhgs.com';
        //var subject = 'Summary Report';
        //var emailBody = '';
        //window.location = 'mailto:' + email + '?subject=' + subject + '&body=' + emailBody;
    });

});
function GetParameterValues(param) {

    var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < url.length; i++) {
        var urlparam = url[i].split('=');
        if (urlparam[0] == param) {
            return urlparam[1];
        }
    }
}
function GetCostCenterCompanyMaster() {
    $('.loader-wrapper').show();
    $("#costCompany").empty();
    $("#costCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            dataType: "JSON",
            data: {
                "EntityName": "AssignedCompanies"
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#costCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();
                
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function bindStatusDropDown() {
    $("#ddlStatus").empty();
    $("#ddlStatus").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "StatusMaster"
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#ddlStatus").append($("<option />").val(this.valueField).text(this.displayField));

                });


               
            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}
function searchPRSummary(pageNum) {
    pageNum = -1;
    if ($("#costCompany").val()=="0") {
        alert("Please select company!");
        return false;
    }

    let fromDate = $("#DateRange").val().substring(0, 12);
    let toDate = $("#DateRange").val().substring(13, 25);

    $('.loader-wrapper').show();
    $("#reportBody").empty();
    //$("#pageList").empty();
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GETPRReportData',
            dataType: "JSON",
            data: { "PageNumber": pageNum,"RowsOfPage":20, "ReportType": "PRSummary", "FromDate": fromDate, "ToDate": toDate, "SearchCriteria1": $("#costCompany").val(), "SearchCriteria2": $("#ddlStatus").val()},
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {

                        if (reportData != '') {
                            $.each(reportData, function (i, item) {
                                var reportID = "'" + item.PRID + "'";
                                var quantity = parseFloat(item.Quantity).toFixed(2);
                                var UnitPrice = parseFloat(item.UnitPrice).toFixed(2);
                                var TotalPrice = parseFloat(item.TotalPrice).toFixed(2);
                                var amt = parseFloat(this.value);
                                $(this).val('$' + amt.toFixed(2));
                                var amt = parseFloat(this.value);
                                $(this).val('$' + amt.toFixed(2));
                                var $tr = $('<tr>').append(
                                    $('<td>').text(i + 1),
                                    $('<td>').text(item.PRID),
                                    $('<td>').text(item.CostCenter),
                                    $('<td>').text(item.Material),
                                    $('<td>').text(item.RequestedBy),
                                    $('<td>').text(item.RequestedDate),
                                    $('<td class="text-right">').text(quantity),
                                    $('<td class="text-right">').text(UnitPrice),
                                    $('<td class="text-right">').text(TotalPrice),
                                    $('<td>').text(item.CurrentStatus),
                                    $('<td>').text(item.P2OGLCode),
                                    $('<td>').text(item.P2OVendorName),
                                    $('<td style="width:50px">').html('<a href="#" title="View" onclick="EventDetails(' + reportID + ')"> <i class="fa-solid fa-eye"></i></a> <a href="#" title="View SAP Details" onclick="getSAPDetails(' + item.PurchaseRequistionID + ')"> <i class="fa-regular fa-seedling"></i></a>'),
                                );


                                $("#reportBody").append($tr);

                            });

                            //PRSummaryPaging(data.recordCount, pageNum);
                        }
                    }
                    
                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="11">').text("No records to display"));

                        $("#reportBody").append($tr);
                    }
                    
                }
                else {
                    alert(data.responseMessage);
                }
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function EventDetails(PRID) {
    $('.loader-wrapper').show();
    $("#eventReportBody").empty();
    $("#divEventDetails").modal('show');
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GETPRReportData',
            dataType: "JSON",
            data: { "SearchCriteria2": $("#costCompany").val(), "PageNumber": -1, "RowsOfPage": 20, "ReportType": "EVENTREPORT", "SearchCriteria1": PRID },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);

                    if (reportData.length > 0) {
                        if (reportData != '') {
                            $.each(reportData, function (i, item) {

                                var $tr = $('<tr>').append(
                                    $('<td>').text(i + 1),
                                    $('<td>').text(item.RequistionNo),
                                    $('<td>').text(item.StatusName),
                                    $('<td>').text(item.ActionBy),
                                    $('<td>').text(item.RoleName),
                                    $('<td>').text(item.ActionDate),
                                    $('<td>').text(item.ActionTime),

                                );

                                $("#eventReportBody").append($tr);

                            });


                        }

                    }
                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="7">').text("No records to display!"));
                        $("#eventReportBody").append($tr);
                    }


                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}

function PRSummaryPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="searchPRSummary(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="searchPRSummary(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="searchPRSummary(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="searchPRSummary(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="searchPRSummary(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#pageList").append(template);
}

function searchEventReport() {
    if ($("#costCompany").val() == "0") {
        alert("Please select company!");
        return false;
    }

    if ($("#txtPRNumber").val() == "") {
        alert("PR Number required!");
        return false;
    }

    $('.loader-wrapper').show();
    $("#reportBody").empty();

    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GETPRReportData',
            dataType: "JSON",
            data: { "SearchCriteria2": $("#costCompany").val(), "PageNumber": -1, "RowsOfPage": 20, "ReportType": "EVENTREPORT", "SearchCriteria1": $("#txtPRNumber").val()},
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    
                    if (reportData.length>0) {
                        if (reportData != '') {
                            $.each(reportData, function (i, item) {

                                var $tr = $('<tr>').append(
                                    $('<td>').text(i + 1),
                                    $('<td>').text(item.RequistionNo),
                                    $('<td>').text(item.StatusName),
                                    $('<td>').text(item.ActionBy),
                                    $('<td>').text(item.RoleName),
                                    $('<td>').text(item.ActionDate),
                                    $('<td>').text(item.ActionTime),

                                );

                                $("#reportBody").append($tr);

                            });


                        }

                    }
                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="7">').text("No records to display!"));
                        $("#reportBody").append($tr);
                    }
                    

                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}

function searchPRAgingReport() {
    if ($("#costCompany").val() == "0") {
        alert("Please select company!");
        return false;
    }
    $("#lblAVGWorkingDays").text("");
    $('.loader-wrapper').show();
    $("#reportBody").empty();
    let fromDate = $("#DateRange").val().substring(0, 12);
    let toDate = $("#DateRange").val().substring(13, 25);
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GETPRReportData',
            dataType: "JSON",
            data: { "SearchCriteria1": $("#costCompany").val(), "PageNumber": -1, "RowsOfPage": 20, "ReportType": "PRAGING", "FromDate": fromDate, "ToDate": toDate },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {
                        if (reportData != '') {
                            $.each(reportData, function (i, item) {

                                var $tr = $('<tr>').append(
                                    $('<td>').text(i + 1),
                                    $('<td>').text(item.RequistionNo),
                                    $('<td>').text(item.VendorName),
                                    $('<td>').text(item.RequestedStartDate),
                                    $('<td>').text(item.RequestedEndDate),
                                    $('<td>').text(item.WorkingDays)

                                );

                                $("#reportBody").append($tr);

                            });

                            $("#lblAVGWorkingDays").text(reportData[0].AVGWorkingDays);


                        }
                    }
                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="6">').text("No records to display!"));
                        $("#reportBody").append($tr);
                    }


                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}

function searchAdminActivityLog() {
    $('.loader-wrapper').show();
    $("#reportBody").empty();
    let fromDate = $("#DateRange").val().substring(0, 12);
    let toDate = $("#DateRange").val().substring(13, 25);
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GETPRReportData',
            dataType: "JSON",
            data: { "PageNumber": -1, "RowsOfPage": 20, "ReportType": "ADMINACTLOG", "FromDate": fromDate, "ToDate": toDate },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {
                        if (reportData != '') {
                            $.each(reportData, function (i, item) {

                                var $tr = $('<tr>').append(
                                    $('<td>').text(i + 1),
                                   
                                    $('<td>').text(item.EmployeeName),
                                    $('<td>').text(item.ActivitySubject),
                                    $('<td>').text(item.ActivityAction),
                                    $('<td>').text(item.ActionedOn),
                                    $('<td>').text(item.OldValue),
                                    $('<td>').text(item.NewValue),
                                    

                                );

                                $("#reportBody").append($tr);

                            });
                        }
                    }
                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="6">').text("No records to display!"));
                        $("#reportBody").append($tr);
                    }


                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function getSAPDetails(PurchaseRequistionID) {
    
    $('.loader-wrapper').show();
    $("#divSAPDetails").modal('show');
    $("#lblPRNo").text("");
    $("#lblPRDate").text("");
    $("#lblPODate").text("");
    $("#lblPONo").text("");
    $("#lblPOValue").text("");
    $("#lblVendor").text("");
    $("#lblRejectionReason").text("");
    $("#divrejectionReason").hide();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRSAPDetails", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: "PRSAPDETAIL"
            },
            success: function (result) {
                console.log('result');
                console.log(result);
                if (result.responseCode == 1) {
                    var myarray = JSON.parse(result.responseJSON);
                    if (myarray.length > 0) {


                        $("#lblPRNo").text(myarray[0].SAPPRNo);
                        if (myarray[0].SAPPRNo != "") {
                            $("#lblPRDate").text(myarray[0].SAPPRDate);
                        }

                        if (myarray[0].SAPPONo != "") {
                            $("#lblPODate").text(myarray[0].SAPPODate);
                        }

                        $("#lblPONo").text(myarray[0].SAPPONo);

                        $("#lblPOValue").text(myarray[0].TotalPOValue);
                        $("#lblVendor").text(myarray[0].VendorCode);
                        if (myarray[0].RejectionReason != "") {
                            $("#divrejectionReason").show();
                            $("#lblRejectionReason").text(myarray[0].RejectionReason);
                        }
                    }
                }
                else {
                    //var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    //$("#" + ulID).append($tr);
                }

                $('.loader-wrapper').hide();


            }

        });
}
/*********** ORDER REPORT ***********/
function searchOrderReport(pageNum) {
   // pageNum = -1;
    
    let fromDate = $("#DateRange").val().substring(0, 12);
    let toDate = $("#DateRange").val().substring(13, 25);

    $('.loader-wrapper').show();
    $("#reportBody").empty();
    $("#pageList").empty();
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GetHistoricalReport',
            dataType: "JSON",
            data: { "PageNumber": pageNum, "RowsOfPage": 20, "ReportName": "OrderReport", "FromDate": fromDate, "ToDate": toDate, "CustomParam1": $("#txtOrderID").val()},
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {

                        if (reportData != '') {
                            $.each(reportData, function (i, item) {
                               
                                var $tr = $('<tr>').append(
                                    $('<td>').text(item.SRNo),
                                    $('<td>').text(item.Order_ID),
                                    $('<td>').text(item.Order_Type),
                                    $('<td>').text(item.Requester),
                                    $('<td>').text(item.Title),
                                    $('<td>').text(item.Order_Status),
                                    $('<td>').text(item.Created_Date),
                                    $('<td>').text(item.Supplier_Name),
                                    $('<td class="text-right">').text(item.Total_Amount),
                                    $('<td>').text(item.Preparer),
                                    $('<td>').text(item.Purchase_Unit),
                                    $('<td>').text(item.Sourcing_Exception),
                                    $('<td>').text(item.Budgeted),
                                    $('<td>').text(item.Supplier_Address1),
                                    $('<td>').text(item.Supplier_Address2)
                                    
                                );


                                $("#reportBody").append($tr);

                            });

                            OrderReportPaging(data.recordCount, pageNum);
                        }
                    }

                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="15">').text("No records to display"));

                        $("#reportBody").append($tr);
                    }

                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function OrderReportPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="searchOrderReport(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="searchOrderReport(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="searchOrderReport(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="searchOrderReport(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="searchOrderReport(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#pageList").append(template);
}
/*********** RECEIPT REPORT *********/
function searchReceiptReport(pageNum) {
    // pageNum = -1;
    if ($("#ddlSearchBy").val()!="0") {
        if ($("#ddlSearchBy").val() == "1" || $("#ddlSearchBy").val() == "2") {
            if ($("#txtOrderID").val()=="") {
                alert("Please provide search text!");
                return false;
            }
        }
        
    }
    else {
        alert("Please select search by!");
        return false;
    }

    let fromDate = $("#DateRange").val().substring(0, 12);
    let toDate = $("#DateRange").val().substring(13, 25);

    $('.loader-wrapper').show();
    $("#reportReceiptBody").empty();
    $("#pageList").empty();
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GetHistoricalReport',
            dataType: "JSON",
            data: {
                "PageNumber": pageNum, "RowsOfPage": 20, "ReportName": "ReceiptReport", "FromDate": fromDate,
                "ToDate": toDate, "CustomParam1": $("#txtOrderID").val(), "CustomParam2": $("#ddlSearchBy").val()
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {

                        if (reportData != '') {
                            $.each(reportData, function (i, item) {

                                var $tr = $('<tr>').append(
                                    $('<td>').text(item.SRNo),
                                    $('<td>').text(item.Receipt_ID),
                                    $('<td>').text(item.Title),
                                    $('<td>').text(item.Status),
                                    $('<td>').text(item.Date_Created),
                                    $('<td>').text(item.Imported),
                                    $('<td>').text(item.Preparer),
                                    $('<td>').text(item.Document_Number),
                                    $('<td>').text(item.Document_Date),
                                  
                                );


                                $("#reportReceiptBody").append($tr);

                            });

                            ReceiptReportPaging(data.recordCount, pageNum);
                        }
                    }

                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="9">').text("No records to display"));

                        $("#reportReceiptBody").append($tr);
                    }

                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function ReceiptReportPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="searchReceiptReport(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="searchReceiptReport(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="searchReceiptReport(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="searchReceiptReport(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="searchReceiptReport(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#pageList").append(template);
}
/*********** REQUISTION REPORT *********/
function searchRequistionReport(pageNum) {
    // pageNum = -1;

    let fromDate = $("#DateRange").val().substring(0, 12);
    let toDate = $("#DateRange").val().substring(13, 25);

    $('.loader-wrapper').show();
    $("#reportRequistionBody").empty();
    $("#pageList").empty();
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GetHistoricalReport',
            dataType: "JSON",
            data: { "PageNumber": pageNum, "RowsOfPage": 20, "ReportName": "RequistionReport", "FromDate": fromDate, "ToDate": toDate, "CustomParam1": $("#ddlStatus").val() },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {

                        if (reportData != '') {
                            $.each(reportData, function (i, item) {
                                var linktoRedirect = appUrl + "AWSConnect/Index?" + item.PRNo;
                                var PRNo = '<a href="' + linktoRedirect + '" target="_blank">' + item.PRNo + '</a>';
                                //var PRNo = '<a href="#" onclick="openPRDetail(' + "'" + item.PRNo + "'" + ')">' + item.PRNo + '</a>';
                                var $tr = $('<tr>').append(
                                    $('<td>').text(item.SRNo),
                                    $('<td>').html(PRNo),
                                    $('<td>').text(item.Title),
                                    $('<td>').text(item.Status),
                                    $('<td>').text(item.Sourcing_Status),
                                    $('<td>').text(item.Service_Requisition),
                                    $('<td>').text(item.Date_Created),
                                    $('<td>').text(item.Date_Submitted),
                                    $('<td class="text-right">').text(item.Total),
                                    $('<td>').text(item.Requester),
                                    $('<td>').text(item.Preparer),
                                    $('<td>').text(item.Purchasing_Unit),
                                    $('<td>').text(item.Fieldglass_Services),
                                    $('<td>').text(item.Fieldglass_Services_ID),
                                    $('<td>').text(item.Savings_Type),
                                    $('<td>').text(item.PO_Origination),
                                    $('<td>').text(item.Service_Start_Date),
                                    $('<td>').text(item.Service_End_Date),
                                    $('<td>').text(item.Sourcing_Exception),
                                    $('<td>').text(item.Budgeted)

                                );


                                $("#reportRequistionBody").append($tr);

                            });

                            RequistionReportPaging(data.recordCount, pageNum);
                        }
                    }

                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="19">').text("No records to display"));

                        $("#reportRequistionBody").append($tr);
                    }

                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function RequistionReportPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="searchRequistionReport(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="searchRequistionReport(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="searchRequistionReport(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="searchRequistionReport(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="searchRequistionReport(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#pageList").append(template);
}
function searchSummaryReport() {
    
    $('.loader-wrapper').show();
    $("#summaryReportBody").empty();
    let fromDate = $("#DateRange").val().substring(0, 12);
    let toDate = $("#DateRange").val().substring(13, 25);
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GETPRReportData',
            dataType: "JSON",
            data: { "PageNumber": -1, "RowsOfPage": 20, "ReportType": "GEOPRSUMMARY", "FromDate": fromDate, "ToDate": toDate },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {
                        if (reportData != '') {
                            $.each(reportData, function (i, item) {
                                if (item.CompanyName != "Total") {
                                    var inprogress = '';
                                    var Approved = '';
                                    var Cancel = '';
                                    var Rejected = '';
                                    var Referback = '';
                                    var Hold = '';
                                    var SAPPR = '';
                                    var SAPPO = '';
                                    var Total = 0;
                                    Total = parseInt(item.InProgress) + parseInt(item.Approved) + parseInt(item.Cancel) + parseInt(item.Rejected) + parseInt(item.Referback) + parseInt(item.Hold)
                                    if (item.InProgress != "0") {
                                        //companyCode, StatusID
                                       // var linktoRedirect = appUrl + "Report/SummaryReportDetails?companyCode=" + item.CompanyCode + "&StatusID=5";
                                        inprogress = '<a href="#" onclick="openReportDetail(' + "'" + item.CompanyCode + "'" + ', ' + "5" + ')">' + item.InProgress + '</a>';
                                        //inprogress = '<a href=' + linktoRedirect + '">' + item.InProgress + '</a>';
                                    }
                                    else {
                                        inprogress = item.InProgress;
                                    }
                                    if (item.Approved != "0") {
                                        Approved = '<a href="#" onclick="openReportDetail(' + "'" + item.CompanyCode + "'" + ', ' + "4" + ')">' + item.Approved + '</a>';
                                    }
                                    else {
                                        Approved = item.Approved;
                                    }
                                    if (item.Cancel != "0") {
                                        Cancel = '<a href="#" onclick="openReportDetail(' + "'" + item.CompanyCode + "'" + ', ' + "6" + ')">' + item.Cancel + '</a>';
                                    }
                                    else {
                                        Cancel = item.Cancel;
                                    }
                                    if (item.Rejected != "0") {
                                        Rejected = '<a href="#" onclick="openReportDetail(' + "'" + item.CompanyCode + "'" + ', ' + "3" + ')">' + item.Rejected + '</a>';
                                    }
                                    else {
                                        Rejected = item.Rejected;
                                    }
                                    if (item.Referback != "0") {
                                        Referback = '<a href="#" onclick="openReportDetail(' + "'" + item.CompanyCode + "'" + ', ' + "2" + ')">' + item.Referback + '</a>';
                                    }
                                    else {
                                        Referback = item.Referback;
                                    }
                                    if (item.Hold != "0") {
                                        Hold = '<a href="#" onclick="openReportDetail(' + "'" + item.CompanyCode + "'" + ', ' + "7" + ')">' + item.Hold + '</a>';
                                    }
                                    else {
                                        Hold = item.Hold;
                                    }
                                    //if (item.SAPPR != "0") {
                                    //    SAPPR = '<a href="#" onclick="openReportDetail(' + "'" + item.CompanyCode + "'" + ', ' + "10" + ')">' + item.SAPPR + '</a>';
                                    //}
                                    //else {
                                    //    SAPPR = item.SAPPR;
                                    //}
                                    if (item.SAPPO != "0") {
                                        SAPPO = '<a href="#" onclick="openReportDetail(' + "'" + item.CompanyCode + "'" + ', ' + "11" + ')">' + item.SAPPO + '</a>';
                                    }
                                    else {
                                        SAPPO = item.SAPPO;
                                    }
                                     
                                     
                                     
                                    //var Cpercentage = parseFloat(SAPPO % Total * 100);
                                    var POPercentage = parseInt(item.SAPPO);
                                    var Cpercentage = ((parseInt(POPercentage) / parseInt(Total)) * 100).toFixed(2) + '%';
                                    
                                    var $tr = $('<tr>').append(
                                        $('<td>').text(i + 1),

                                        $('<td>').text(item.CompanyName),
                                        $('<td class="text-right">').html(inprogress),
                                        $('<td class="text-right">').html(Approved),
                                        $('<td class="text-right">').html(Cancel),
                                        $('<td class="text-right">').html(Rejected),
                                        $('<td class="text-right">').html(Referback),
                                        $('<td class="text-right">').html(Hold),
                                        $('<td class="text-right">').html(Total),
                                        $('<td class="text-right">').html(SAPPO),
                                        $('<td class="text-right">').html(Cpercentage),

                                    );
                                    $("#summaryReportBody").append($tr);
                                }
                                else {
                                    
                                    var POPercentage = parseInt(item.SAPPO);
                                    var Total = parseInt(item.SAPPR);
                                    var Cpercentage = ((parseInt(POPercentage) / parseInt(Total)) * 100).toFixed(2) + '%';

                                    var $tr = $('<tr style="background: #012a7c;">').append(
                                        $('<td>').text(''),

                                        $('<td style="color: #fff;">').text(item.CompanyName),
                                        $('<td class="text-right" style="color: #fff;">').text(item.InProgress),
                                        $('<td class="text-right" style="color: #fff;">').text(item.Approved),
                                        $('<td class="text-right" style="color: #fff;">').text(item.Cancel),
                                        $('<td class="text-right" style="color: #fff;">').text(item.Rejected),
                                        $('<td class="text-right" style="color: #fff;">').text(item.Referback),
                                        $('<td class="text-right" style="color: #fff;">').text(item.Hold),
                                        $('<td class="text-right" style="color: #fff;">').text(item.SAPPR),
                                        $('<td class="text-right" style="color: #fff;">').text(item.SAPPO),
                                        $('<td class="text-right" style="color: #fff;">').html(Cpercentage),

                                    );
                                    $("#summaryReportBody").append($tr);
                                }
                                

                                

                            });
                        }
                    }
                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="11">').text("No records to display!"));
                        $("#summaryReportBody").append($tr);
                    }


                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}

function openReportDetail(companyCode, StatusID) {
    let fromDate = $("#DateRange").val().substring(0, 12);
    let toDate = $("#DateRange").val().substring(13, 25);
    $('.loader-wrapper').show();
    $("#PRDetailBody").empty();
    $("#divPRDetails").modal('show');
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GETPRReportData',
            dataType: "JSON",
            data: { "SearchCriteria1": companyCode, "SearchCriteria2": StatusID, "PageNumber": -1, "RowsOfPage": 20, "ReportType": "GEOPRDETAIL", "FromDate": fromDate, "ToDate": toDate },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {
                        if (reportData != '') {
                            $.each(reportData, function (i, item) {
                                var amount = parseFloat(item.TotalAmount).toFixed(2);
                                var $tr = $('<tr>').append(
                                    $('<td>').text(i + 1),

                                    $('<td>').text(item.RequistionNo),
                                    $('<td>').text(item.CostCenterName),
                                    $('<td>').text(item.Creator),
                                    $('<td>').text(item.CurrencyCode),
                                    $('<td class="text-right">').text(amount),
                                    $('<td>').text(item.StatusName),
                                    $('<td>').text(item.SAPPR),
                                    $('<td>').text(item.SAPPO),
                                  
                                );

                                $("#PRDetailBody").append($tr);

                            });
                        }
                    }
                    else {
                        var $tr = $('<tr>').append(
                            $('<td colspan="9">').text("No records to display!"));
                        $("#PRDetailBody").append($tr);
                    }


                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function CopyToClipboard(containerid) {
    var range = document.createRange();
    range.selectNode(document.getElementById(containerid));
    window.getSelection().removeAllRanges(); // clear current selection
    window.getSelection().addRange(range); // to select text
    document.execCommand("copy");
    window.getSelection().removeAllRanges();// to deselect
    alert("Text copied");
}

function openPRDetail(PRNo) {
    $('.loader-wrapper').show();
    $("#reportRequistionBody").empty();
    $("#pageList").empty();
    $.ajax({
        url: '/AWSConnect/Index?' + PRNo,
        type: 'GET',
        /*data: { "PageNumber": -1, "RowsOfPage": 20, "ReportName": "RequistionReport", "FromDate": fromDate, "ToDate": toDate },*/
        success: function (data) {
            // Open a new tab and set the URL to the data retrieved from the AJAX call
            var newTab = window.open();
            newTab.document.write(data);
        },
        error: function (xhr, status, error) {
         //handle error
        }
    });
}