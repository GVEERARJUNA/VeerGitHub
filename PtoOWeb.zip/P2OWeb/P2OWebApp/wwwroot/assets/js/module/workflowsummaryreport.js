﻿var appUrl = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();

    BindCompany();

    $("#btnWorkFlowExport").click(function () {

        $("input[name='GridHtml']").val($("#divResult").html());
    });

});
function BindCompany() {
    $('.loader-wrapper').show();
    $("#costCompany").empty();
    $("#costCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            dataType: "JSON",
            data: {
                "EntityName": "WorkFlowCompany"
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#costCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function searchWorkflow() {
    if ($("#costCompany").val() == "0") {
        alert("Please select company!");
        return false;
    }
    $('.loader-wrapper').show();
    $("#divResult").empty();

    $.ajax(
        {
            type: "POST",
            url: appUrl + 'Report/GetWorkFlowReport',
            dataType: "JSON",
            data: { "CompanyCode": $("#costCompany").val() },
            success: function (data) {
                if (data.responseCode == 1) {
                    var reportData = data.responseJSON;
                    $("#divResult").append(reportData);

                    //if (reportData.length > 0) {
                    //    if (reportData != '') {
                    //        $.each(reportData, function (i, item) {

                    //            var $tr = $('<tr>').append(
                    //                $('<td>').text(i + 1),
                    //                $('<td>').text(item.RequistionNo),
                    //                $('<td>').text(item.StatusName),
                    //                $('<td>').text(item.ActionBy),
                    //                $('<td>').text(item.RoleName),
                    //                $('<td>').text(item.ActionDate),
                    //                $('<td>').text(item.ActionTime),

                    //            );

                    //            $("#reportBody").append($tr);

                    //        });


                    //    }

                    //}
                    //else {
                    //    var $tr = $('<tr>').append(
                    //        $('<td colspan="7">').text("No records to display!"));
                    //    $("#reportBody").append($tr);
                    //}


                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}