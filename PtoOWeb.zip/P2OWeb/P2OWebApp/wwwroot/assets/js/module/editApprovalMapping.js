﻿var appUrl = '';
var addedLevel = [];
var readonlyaccess = false;
$(document).ready(function () {
    $("#manageLevelData").hide();
    
    appUrl = setAppUrl();

    GetCompanyDDLData();

    GetRoleMasterDDLData();

    $("#SelectCompany").change(function () {
        searchCostCenter();

    });

    $("#ddlCostCenter").change(function () {
        $("#bodyfiles").empty();
        $("#manageLevelData").hide();

    });

   

    function selectPicker2() {
        $(".selectPicker2").select2();
    }


    selectPicker2();
    //alert(readonlyaccess);

    $("#txtFromAmount").keypress(function (event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) &&

            ((event.which < 48 || event.which > 57) &&

                (event.which != 0 && event.which != 8))) {

            event.preventDefault();

        }
        var text = $(this).val();
        if ((text.indexOf('.') != -1) &&

            (text.substring(text.indexOf('.')).length > 2) &&

            (event.which != 0 && event.which != 8) &&

            ($(this)[0].selectionStart >= text.length - 2)) {

            event.preventDefault();

        }
    });
    $("#txtToAmount").keypress(function (event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) &&

            ((event.which < 48 || event.which > 57) &&

                (event.which != 0 && event.which != 8))) {

            event.preventDefault();

        }
        var text = $(this).val();
        if ((text.indexOf('.') != -1) &&

            (text.substring(text.indexOf('.')).length > 2) &&

            (event.which != 0 && event.which != 8) &&

            ($(this)[0].selectionStart >= text.length - 2)) {

            event.preventDefault();

        }
    });
    $("#selAppType").change(function () {

        if ($("#selAppType").val() == "0") {
            $("#divsRole").hide();
            $("#divsEMP").hide();
            $("#SelectRole").val("0");
            $("#txtEmployee").val("");
        }
        else if ($("#selAppType").val() == "Individual") {
            $("#divsRole").hide();
            $("#divsEMP").show();
            $("#SelectRole").val("0");
            $("#txtEmployee").val("");
        }
        else if ($("#selAppType").val() == "Role") {
            $("#divsRole").show();
            $("#divsEMP").hide();
            $("#SelectRole").val("0");
            $("#txtEmployee").val("");
        }
    });
    $("#selAmountApplicable").change(function () {

        if ($("#selAmountApplicable").val() == "0") {
            $("#divCalculationType").hide();
            $("#divFromAmount").hide();
            $("#divToAmount").hide();
            $("#selCalculationType").val("0");
            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
        else if ($("#selAmountApplicable").val() == "1") {
            $("#divCalculationType").show();
        }

    });
    $("#selCalculationType").change(function () {

        if ($("#selCalculationType").val() == "0") {

            $("#divFromAmount").hide();
            $("#divToAmount").hide();

            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
        else if ($("#selCalculationType").val() == "Greater") {
            $("#divFromAmount").show();
            $("#divToAmount").hide();
            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
        else if ($("#selCalculationType").val() == "Less") {
            $("#divFromAmount").show();
            $("#divToAmount").hide();
            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
        else if ($("#selCalculationType").val() == "Between") {
            $("#divFromAmount").show();
            $("#divToAmount").show();
            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
    });

});
function GetCompanyDDLData() {
    $('.loader-wrapper').show();
    $("#SelectCompany").empty();
    $("#SelectCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "GET",
            url: appUrl + "Admin/GetCompanyMaster",
            dataType: "JSON",
            data: null,
            success: function (data) {
                if (data.recordCount > 0) {
                    $.each(data.costCenter, function (i, item) {
                        $("#SelectCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}
function searchCostCenter() {
    $("#lstCostCenter").html("");
    $("#ddlCostCenter").empty();
    $("#ddlCostCenter").append($("<option />").val("0").text("Select"));

    if ($("#SelectCompany").val() > "0") {
        $('.loader-wrapper').show();
        $.ajax({
            type: 'POST',
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            data: {
                "EntityName": "CostCenterAssigned", "SearchParameter1": $("#SelectCompany").val()
            },
            success: function (pdata, textstatus) {
                if (pdata.responseCode == 1) {
                    $.each(pdata.masterDataResponses, function (i, item) {
                       
                        $("#ddlCostCenter").append($("<option />").val(item.valueField).text(item.displayField));
                    });


                    $("#ddlCostCenter").focus();

                }
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
    }
    else {
        $("#ddlCostCenter").empty("");


    }
}

function getLevelData() {
    var companyMaster = $("#SelectCompany").val();
    if (companyMaster == "0") {
        alert("Please select Company!");
        $("#SelectCompany").focus();
        return false;
    }

    var costCenter = $("#ddlCostCenter").val();
    if (costCenter == "0") {
        alert("Please select Cost Center!");
        $("#ddlCostCenter").focus();
        return false;
    }


    $('.loader-wrapper').show();
    $("#bodyfiles").empty();
    $("#manageLevelData").show();
    $.ajax(
        {
            type: "POST",
            url: appUrl + "ApprovalMapping/ManageApplicatonHierarchy",
            dataType: "JSON",
            data: { "Action": "GET", "CostCenterCode": $("#ddlCostCenter").val()},
            success: function (data) {
                if (data.responseCode == 1) {
                    var parsedLevelData = JSON.parse(data.responseJSON);
                    
                    $.each(parsedLevelData, function (i, item) {
                        var apptype = '';
                        var amountapplicable = '';
                        var amountsymbol = '';
                        var fromAmount = '';
                        var ToAmount = '';
                        if (item.AmountApplicableFlag == 0) {
                            amountapplicable = 'NO';
                        }
                        else if (item.AmountApplicableFlag == 1) {
                            amountapplicable = 'YES';
                            amountsymbol = item.CalculateSymbol;
                            fromAmount = item.FromAmount;
                            ToAmount = item.ToAmount;
                        }
                        if (item.AppType == 'Role') {
                            apptype = item.RoleName
                        }
                        else if (item.AppType == 'Individual') {
                            apptype = item.EMPCode
                        }
                        var $tr = $('<tr>').append(
                            $('<td>').text(i + 1),
                            $('<td>').text(item.AppLevel),
                            $('<td>').text(item.PurchaseType),
                            $('<td>').text(item.PGCategory),
                            $('<td>').text(item.AppType),
                            $('<td>').text(apptype),
                            $('<td>').text(amountapplicable),
                            $('<td>').text(amountsymbol),
                            $('<td>').text(fromAmount),
                            $('<td>').text(ToAmount),
                           // $('<td >').html('')
                            $('<td >').html('&nbsp; <a href="#" onclick=removeLevel(' + item.AppHierarchyID + ',' + item.AppLevel + ')> <i class="fa-solid fa-trash-can"></i></a>'),
                        );
                        $("#bodyfiles").append($tr);
                    });

                       
                    $("#SelectCompany").prop("disabled", true);
                    $("#ddlCostCenter").prop("disabled", true);

                    $("#levelApproval").focus();
                   
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}

function removeLevel(AppHierarchyID,appLevel) {
    if (confirm('Do you want to delete details?')) {


        $('.loader-wrapper').show();
        
        $.ajax(
            {
                type: "POST",
                url: appUrl + "ApprovalMapping/ManageApplicatonHierarchy",
                dataType: "JSON",
                data: { "Action": "DELETE", "CostCenterCode": $("#ddlCostCenter").val(), "AppHierarchyID": AppHierarchyID, "AppLevel": appLevel,"RoleName": $("#SelectRole option:selected").text() },
                success: function (data) {
                    if (data.responseCode == 1) {
                        alert("Deleted Successfully!");
                        getLevelData();
                    }
                    else {
                        alert(data.responseMessage);
                    }

                    $('.loader-wrapper').hide();

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('.loader-wrapper').hide();
                }
            }
        );

    }

}


function openaddLevelPOPUP() {
    $('#mdAddLevel').modal('show');
    resetModal();
    bindPurchaseType();
    bindPurchaseCategory();
    GetRoleMasterDDLData();

}
function bindPurchaseType() {
    $("#selPurchaseType").empty();
    $("#selPurchaseType").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PurchaseType", "SearchParameter1": ''
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selPurchaseType").append($("<option />").val(this.valueField).text(this.displayField));

                });
            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function bindPurchaseCategory() {
    $("#selPurchaseGroup").empty();
    $("#selPurchaseGroup").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PurchaseCategory", "SearchParameter1": ''
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selPurchaseGroup").append($("<option />").val(this.valueField).text(this.displayField));

                });
            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function GetRoleMasterDDLData() {
    $('.loader-wrapper').show();
    $("#SelectRole").empty();
    $("#SelectRole").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + "PurchaseRequistion/GetMasterData",
            dataType: "JSON",
            data: {
                "EntityName": "RoleMasterAPPHierarchy"
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#SelectRole").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}
function resetModal() {
    $("#divsRole").hide();
    $("#divsEMP").hide();
    $("#divCalculationType").hide();
    $("#divFromAmount").hide();
    $("#divToAmount").hide();
    $("#txtFromAmount").val("");
    $("#txtToAmount").val("");
    $("#SelectRole").val("0");
    $("#txtEmployee").val("");
    $("#selAppType").val("0")
    $("#selAmountApplicable").val("0");
    $("#selCalculationType").val("0");
    //addedLevel = [];
}
/**********  SAVE NEW LEVEL */
function addLevel() {

    var costCenter = $("#ddlCostCenter").val();
    if (costCenter == "0") {
        alert("Please select Cost Center!");
        return false;
    }

    var appLevel = $("#SelectLevel").val();
    if ($("#SelectLevel").val() == "0") {
        alert("Please select Level!");
        return false;
    }
    if ($("#selAppType").val() == "0") {
        alert("Please select app type!");
        return false;
    }

    if ($("#selAppType").val() == "Individual") {
        if ($("#txtEmployee").val() == "") {
            alert("Please enter employee code!");
            return false;
        }
    }
    else if ($("#selAppType").val() == "Role") {
        var roleSelected = $("#SelectRole").val();
        if (roleSelected == "0") {
            alert("Please select Role!");
            return false;
        }
    }
    if ($("#selAmountApplicable").val() == "1") {
        if ($("#selCalculationType").val() == "0") {
            alert("Please select calculation type!");
            return false;
        }
        else if ($("#selCalculationType").val() == "Greater") {
            if ($("#txtFromAmount").val() == "") {
                alert("Please enter from amount!");
                return false;
            }
            else if ($("#txtFromAmount").val() == "0" || parseFloat($("#txtFromAmount").val()) < 0) {
                alert("From Amount cannot be zero or less than zero!");
                return false;
            }
        }
        else if ($("#selCalculationType").val() == "Less") {
            if ($("#txtFromAmount").val() == "") {
                alert("Please enter from amount!");
                return false;
            }
            else if ($("#txtFromAmount").val() == "0" || parseFloat($("#txtFromAmount").val()) < 0) {
                alert("From Amount cannot be zero or less than zero!");
                return false;
            }
        }
        else if ($("#selCalculationType").val() == "Between") {
            if ($("#txtFromAmount").val() == "") {
                alert("Please enter from amount!");
                return false;
            }
            else if ($("#txtFromAmount").val() == "0" || parseFloat($("#txtFromAmount").val()) < 0) {
                alert("From Amount cannot be zero or less than zero!");
                return false;
            }
            if ($("#txtToAmount").val() == "") {
                alert("Please enter to amount!");
                return false;
            }
            else if ($("#txtToAmount").val() == "0" || parseFloat($("#txtToAmount").val()) < 0) {
                alert("To Amount cannot be zero or less than zero!");
                return false;
            }
        }
    }

    $('.loader-wrapper').show();

    $.ajax(
        {
            type: "POST",
            url: appUrl + "ApprovalMapping/ManageApplicatonHierarchy",
            dataType: "JSON",
            data: {
                "Action": "ADD",
                "CostCenterCode": costCenter,
                "AppLevel": appLevel, "RoleMasterID": roleSelected,
                "RoleName": $("#SelectRole option:selected").text(),
                "EMPCode": $("#txtEmployee").val(),
                "AppType": $("#selAppType").val(),
                "PurchaseTypeID": $("#selPurchaseType").val(),
                "PurchaseType": $("#selPurchaseType option:selected").val(),
                "PGCategoryCode": $("#selPurchaseGroup").val(),
                "AmountApplicableFlag": $("#selAmountApplicable").val(),
                "CalculateSymbol": $("#selCalculationType").val(),
                "FromAmount": $("#txtFromAmount").val(),
                "ToAmount": $("#txtToAmount").val(),
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    alert("Added Successfully!");
                    $('#mdAddLevel').modal('hide');
                    getLevelData();
                }
                else {
                    alert(data.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}
//function GetRoleMasterDDLData() {
//    $('.loader-wrapper').show();
//    $("#SelectRole").empty();
//    $("#SelectRole").append($("<option />").val("0").text("Select"));
//    $.ajax(
//        {
//            type: "POST",
//            url: appUrl + "PurchaseRequistion/GetMasterData",
//            dataType: "JSON",
//            data: {
//                "EntityName": "RoleMasterAPPHierarchy"
//            },
//            success: function (data) {
//                if (data.responseCode == 1) {
//                    $.each(data.masterDataResponses, function (i, item) {
//                        $("#SelectRole").append($("<option />").val(item.valueField).text(item.displayField));
//                    });
//                }

//                $('.loader-wrapper').hide();

//                //$("#ddlCostCenter").select2();

//            },
//            error: function (XMLHttpRequest, textStatus, errorThrown) {
//                $('.loader-wrapper').hide();
//            }
//        }
//    );
//}

function resetControl() {
    $("#SelectCompany").prop("disabled", false);
    $("#ddlCostCenter").prop("disabled", false);
    $("#SelectCompany").val("0").trigger('change');
    $("#ddlCostCenter").val("0").trigger('change');
    //$("#SelectCompany").val("0");
    //$("#ddlCostCenter").val("0");

    $("#bodyfiles").empty();
    $("#SelectLevel").val("0");
    $("#SelectRole").val("0");
    $("#manageLevelData").hide();
}

/*********** OLD CODE FOR ADD LEVEL  */
//function addLevel() {

//    var costCenter = $("#ddlCostCenter").val();
//    if (costCenter == "0") {
//        alert("Please select Cost Center!");
//        return false;
//    }

//    var appLevel = $("#SelectLevel").val();
//    if (appLevel == "0") {
//        alert("Please select Level!");
//        return false;
//    }
//    var roleSelected = $("#SelectRole").val();
//    if (roleSelected == "0") {
//        alert("Please select Role!");
//        return false;
//    }

//    $('.loader-wrapper').show();

//    $.ajax(
//        {
//            type: "POST",
//            url: appUrl + "ApprovalMapping/ManageApplicatonHierarchy",
//            dataType: "JSON",
//            data: { "Action": "ADD", "CostCenterCode": costCenter, "AppLevel": appLevel, "RoleMasterID": roleSelected, "RoleName": $("#SelectRole option:selected").text() },
//            success: function (data) {
//                if (data.responseCode == 1) {
//                    //alert("Added Successfully!");
//                    getLevelData();
//                }
//                else {
//                    alert(data.responseMessage);
//                }

//                $('.loader-wrapper').hide();

//            },
//            error: function (XMLHttpRequest, textStatus, errorThrown) {
//                $('.loader-wrapper').hide();
//            }
//        }
//    );
//}

