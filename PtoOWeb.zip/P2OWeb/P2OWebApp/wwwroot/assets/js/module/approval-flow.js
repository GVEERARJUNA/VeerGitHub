﻿var appUrl = '';
var purchaseTypecon = '';
var selectedPurchaseTypeCon = '';
$(document).ready(function () {

    appUrl = setAppUrl();
    purchaseTypecon = $('#purchaseTypeEdit').val();

    function selectPicker2() {
        $(".selectPicker2").select2(
            {
                dropdownParent: $('#addLineItem')
                //dropdownParent: $('#changeHeaderDetails')
            }
        );
    }
    function selectPicker3() {
        $(".selectPicker3").select2(
            {
                dropdownParent: $('#changeHeaderDetails')
                //dropdownParent: $('#changeHeaderDetails')
            }
        );
    }

    selectPicker3();

    function selectPicker4() {
        $(".selectPicker4").select2(
            {
                dropdownParent: $('#editDetail')
                //dropdownParent: $('#changeHeaderDetails')
            }
        );
    }

    selectPicker4();


});


$(document).ready(function () {
    $("#selOnBehalfOfEdit").change(function () {
        var val = this.value;
        // alert(val);
        if (val == 'noOnBehalfOf') {
            $(".hideDiv").hide();
            $(".hideDivEmp").hide();
            /*$("#inlineRadio1Edit").prop("disabled", false);*/

        } else {
            $(".hideDiv").show();
            $(".hideDivEmp").hide();
            //$("#inlineRadio1Edit").prop("disabled", true);
            //$("#inlineRadio2Edit").prop("checked", true);
            //$("#selCostCentreEdit").prop("disabled", false);
            val = 'yesOnBehalfOf'
            /*bindEmployeeDropDownEdit();*/

        }
    });
});

$(document).ready(function () {
    $("#selMaterialEdit").change(function () {
        var materialcode = this.value;
        bindGLDropDownForEdit(materialcode);
    });
});

function openApprovalPopup(requistionID) {
    var ID = 'approveCart-' + requistionID;
    $("#" + ID).modal('show');
}
function openRejectPopup(requistionID) {
    var ID = 'rejectCart-' + requistionID;
    $("#" + ID).modal('show');
}
function openReworkPopup(requistionID) {
    var ID = 'reworkCart-' + requistionID;
    $("#" + ID).modal('show');
}

function GetApprovalFlow(LoggedInEmpId, PurchaseRequistionID) {
    var ulID = "approvalworkflow-" + PurchaseRequistionID;

    $("#" + ulID).empty();
    $('.loader-wrapper').show();

    var list = '';
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetApproverList", // Controller/View
            data: { //Passing data
                loggedInEmpId: LoggedInEmpId, PRrequisitionId: PurchaseRequistionID
            },
            success: function (result) {

                if (result != '' && result.distinctLevel.length > 0) {
                    var submitli = '<li><div class="sub-pending"><h4 style="background-color :yellowgreen;color:white">Submitted</h4><p>' + result.distinctLevel[0].submittedBy + '</p></div></li>';
                    //var submitli = '<li><div class="submited">' + result.distinctLevel[0].submittedBy + '</div></li>';
                    var finalli = '<li><div class="final-approval">' + result.distinctLevel[0].prStatus + '</div></li>';
                    var pendinglist = '';

                    $.each(result.distinctLevel, function (i, item) {
                        var getLevelData = [];

                        $.each(result.approvalData, function (j, treeData) {

                            if (item.approvalLevel == treeData.approvalLevel) {
                                getLevelData.push(treeData);
                            }

                        });

                        if (getLevelData.length > 0) {

                            pendinglist += '<li>';
                            $.each(getLevelData, function (j, treeData) {
                                var colorBg = '';
                                if (treeData.approvalStatus == "Approved") {
                                    colorBg = 'yellowgreen';
                                }
                                else if (treeData.approvalStatus == "Reject") {
                                    colorBg = 'indianred';
                                }
                                else if (treeData.approvalStatus == "Rework") {
                                    colorBg = 'gold';
                                }
                                else {
                                    colorBg = 'orange';
                                }
                                if (j == 0) {
                                    if (treeData.isDelegator == 0) {
                                        pendinglist += '<div class="sub-pending"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p>' + treeData.approvalName + '</p></div>';
                                    }
                                    else {
                                        pendinglist += '<div class="sub-pending"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p class="pb-0">' + treeData.approvalName + '</p><p class="pt-0">' + treeData.delegatorName + '</p></div>';
                                    }
                                }
                                else {
                                    if (treeData.isDelegator == 0) {
                                        pendinglist += '<div class="sub-pending top-line"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p>' + treeData.approvalName + '</p></div>';
                                    }
                                    else {
                                        pendinglist += '<div class="sub-pending top-line"><h4 style="background-color :' + colorBg + ';color:white">' + treeData.approvalStatus + '</h4><p class="pb-0">' + treeData.approvalName + '</p><p class="pt-0">' + treeData.delegatorName + '</p></div>';
                                    }
                                }
                            });
                            pendinglist += '</li>';
                        }

                    });

                    list = list + pendinglist;


                    list = submitli + list;
                    list = list + finalli;
                    $("#" + ulID).append(list.toString());
                }
                $('.loader-wrapper').hide();
            }

        });
}


//function GetApprovalFlow(LoggedInEmpId, PurchaseRequistionID) {
//    var ulID = "approvalworkflow-" + PurchaseRequistionID;

//    $("#" + ulID).empty();
//    var list = '';
//    $.ajax(
//        {
//            type: "POST", //HTTP POST Method
//            url: appUrl +  "Approval/GetApproverList", // Controller/View
//            data: { //Passing data
//                loggedInEmpId: LoggedInEmpId, PRrequisitionId: PurchaseRequistionID
//            },
//            success: function (result) {
//                if (result.length > 0) {
//                    var submitli = '<li><div class="submited">Submitted</div></li>';
//                    var finalli = '<li><div class="final-approval">Final Approval</div></li>';
//                    $.each(result, function (i, item) {
//                        var pendinglist = '';
//                        console.log(item.level);
//                        if (item.level == 1) {
//                            if (item.delegator != "") {
//                                if (item.delegatorApprovalStatus == "Approved") {
//                                    if (item.firstApprovalPerson != "") {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : yellowgreen">' + item.delegatorApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalPerson != "") {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : yellowgreen">' + item.delegatorApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : yellowgreen">' + item.delegatorApprovalStatus + '</h4><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                }
//                                else if (item.delegatorApprovalStatus == "Reject") {
//                                    if (item.firstApprovalPerson != "") {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : indianred">' + item.delegatorApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalPerson != "") {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : indianred">' + item.delegatorApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : indianred">' + item.delegatorApprovalStatus + '</h4><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                }
//                                else if (item.delegatorApprovalStatus == "Rework") {
//                                    if (item.firstApprovalPerson != "") {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : gold">' + item.delegatorApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalPerson != "") {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : gold">' + item.delegatorApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : gold">' + item.delegatorApprovalStatus + '</h4><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                }
//                                else {
//                                    if (item.firstApprovalPerson != "") {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : orange">' + item.delegatorApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalPerson != "") {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : orange">' + item.delegatorApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="submited"><h4 style="background-color : orange">' + item.delegatorApprovalStatus + '</h4><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                }
//                            }
//                            if (item.firstApprovalPerson != "") {
//                                if (item.firstApprovalStatus == "Approved") {
//                                    pendinglist = '<li><div class="pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div></li>';
//                                }
//                                else if (item.firstApprovalStatus == "Reject") {
//                                    pendinglist = '<li><div class="pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div></li>';
//                                }
//                                else if (item.firstApprovalStatus == "Rework") {
//                                    pendinglist = '<li><div class="pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div></li>';
//                                }
//                                else {
//                                    pendinglist = '<li><div class="pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div></li>';
//                                }
//                            }
//                            if (item.secondApprovalPerson != "") {
//                                if (item.firstApprovalStatus == "Approved") {
//                                    if (item.secondApprovalStatus == "Approved") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : yellowgreen">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Reject") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : indianred">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Rework") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : gold">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : orange">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                }
//                                else if (item.firstApprovalStatus == "Reject") {
//                                    if (item.secondApprovalStatus == "Approved") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : yellowgreen">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Reject") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : indianred">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Rework") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : gold">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : orange">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                }
//                                else if (item.firstApprovalStatus == "Rework") {
//                                    if (item.secondApprovalStatus == "Approved") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : yellowgreen">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Reject") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : indianred">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Rework") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : gold">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : orange">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                }
//                                else {
//                                    if (item.secondApprovalStatus == "Approved") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : yellowgreen">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Reject") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : indianred">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Rework") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : gold">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : orange">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                }
//                            }
//                        }
//                        else {
//                            if (item.delegator != "") {
//                                if (item.delegatorApprovalStatus == "Approved") {
//                                    if (item.firstApprovalPerson != "") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.delegatorApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalPerson != "") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.delegatorApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.delegatorApprovalStatus + '</h4><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                }
//                                else if (item.delegatorApprovalStatus == "Reject") {
//                                    if (item.firstApprovalPerson != "") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.delegatorApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalPerson != "") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.delegatorApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.delegatorApprovalStatus + '</h4><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                }
//                                else if (item.delegatorApprovalStatus == "Rework") {
//                                    if (item.firstApprovalPerson != "") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.delegatorApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalPerson != "") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.delegatorApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.delegatorApprovalStatus + '</h4><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                }
//                                else {
//                                    if (item.firstApprovalPerson != "") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.delegatorApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalPerson != "") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.delegatorApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.delegatorApprovalStatus + '</h4><p>' + item.delegator + '</p></div></li>';
//                                    }
//                                }
//                            }
//                            if (item.firstApprovalPerson != "") {
//                                if (item.firstApprovalStatus == "Approved") {
//                                    pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div></li>';
//                                }
//                                else if (item.firstApprovalStatus == "Reject") {
//                                    pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div></li>';
//                                }
//                                else if (item.firstApprovalStatus == "Rework") {
//                                    pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div></li>';
//                                }
//                                else {
//                                    pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div></li>';
//                                }
//                            }
//                            if (item.secondApprovalPerson != "") {
//                                if (item.firstApprovalStatus == "Approved") {
//                                    if (item.secondApprovalStatus == "Approved") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : yellowgreen">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Reject") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : indianred">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Rework") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : gold">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : yellowgreen">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : orange">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                }
//                                else if (item.firstApprovalStatus == "Reject") {
//                                    if (item.secondApprovalStatus == "Approved") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : yellowgreen">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Reject") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : indianred">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Rework") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : gold">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : indianred">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : orange">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                }
//                                else if (item.firstApprovalStatus == "Rework") {
//                                    if (item.secondApprovalStatus == "Approved") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : yellowgreen">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Reject") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : indianred">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Rework") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : gold">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : gold">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : orange">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                }
//                                else {
//                                    if (item.secondApprovalStatus == "Approved") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : yellowgreen">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Reject") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : indianred">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else if (item.secondApprovalStatus == "Rework") {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : gold">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                    else {
//                                        pendinglist = '<li><div class="sub-pending"><h4 style="background-color : orange">' + item.firstApprovalStatus + '</h4><p>' + item.firstApprovalPerson + '</p></div><div class="sub-pending top-line"><h4 style="background-color : orange">' + item.secondApprovalStatus + '</h4><p>' + item.secondApprovalPerson + '</p></div></li>';
//                                    }
//                                }

//                            }
//                        }

//                        list = list + pendinglist;

//                    });
//                    list = submitli + list;
//                    list = list + finalli;
//                    console.log(list);
//                    $("#" + ulID).append(list.toString());
//                    //console.log($("#approvallistflow"));
//                }
//                $("#waitLoadingPanel").hide();
//            }

//        });
//}

function UpdateApproval(LoggedInEmpId, PurchaseRequistionID, PRApprovalMatrixID, ApprovalLevel, ApprovalStatus, source) {
    var confirmationtext = '';
    var remark = '';
    if (ApprovalStatus == 4) {
        var ID = 'commentsPopup-' + PurchaseRequistionID;
        remark = $("#" + ID).val();
    }
    else if (ApprovalStatus == 3) {
        var ID = 'commentsPopup-' + PurchaseRequistionID;
        remark = $("#" + ID).val();
    }
    else if (ApprovalStatus == 2) {
        var ID = 'commentsPopup-' + PurchaseRequistionID;
        remark = $("#" + ID).val();
    }
    else if (ApprovalStatus == 6) {
        var ID = 'commentsPopup-' + PurchaseRequistionID;
        remark = $("#" + ID).val();
    }
    else if (ApprovalStatus == 8) {
        var ID = 'commentsPopup-' + PurchaseRequistionID;
        remark = $("#" + ID).val();
    }
    else {
        remark = '';
    }

    if (remark == '') {
        alert("Remark required!");
        return false;
    }
    if (ApprovalStatus == 4) {
        confirmationtext = 'Are you sure you want to approve?';
    }
    else if (ApprovalStatus == 3) {
        confirmationtext = 'Are you sure you want to reject?';
    }
    else if (ApprovalStatus == 2) {
        confirmationtext = 'Are you sure you want to rework?';
    }
    else if (ApprovalStatus == 6) {
        confirmationtext = 'Are you sure you want to cancel?';
    }
    else if (ApprovalStatus == 8) {
        confirmationtext = 'Are you sure you want to resubmit?';
    }
    if (confirm(confirmationtext)) {
        console.log('UpdateApproval');


        if (remark.length > 500) {
            alert("comments cannot exceed 500 characters!");

            return false;
        }

        if (ApprovalStatus == 8) {

            ApprovalStatus = 4;
        }
        $('.loader-wrapper').show();

        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "Approval/UpdateApprovalStatus", // Controller/View
                data: { //Passing data
                    loggedInEmpId: LoggedInEmpId, PRrequisitionId: PurchaseRequistionID, PRApprovalMatrixID: PRApprovalMatrixID, ApprovalLevel: ApprovalLevel,
                    ApprovalStatus: ApprovalStatus, Remark: remark
                },
                success: function (result) {
                    if (result.responseCode == 1) {
                        if (ApprovalStatus == 4) {
                            var ID = 'approveCart-' + PurchaseRequistionID;
                            $("#" + ID).modal('hide');

                        }
                        else if (ApprovalStatus == 3) {
                            var ID = 'rejectCart-' + PurchaseRequistionID;
                            $("#" + ID).modal('hide');

                        }
                        else if (ApprovalStatus == 3) {
                            var ID = 'reworkCart-' + PurchaseRequistionID;
                            $("#" + ID).modal('hide');

                        }
                        else {
                            var ID = 'approveCart-' + PurchaseRequistionID;
                            $("#" + ID).modal('hide');
                        }

                        $('.loader-wrapper').hide();
                        RefreshWaitingForApprovalList();
                    }
                    else {
                        alert(result.responseMessage);
                        $('.loader-wrapper').hide();
                    }

                },
                error: function () {
                    $('.loader-wrapper').hide();
                    alert('Error while updating');

                }
            });
    }
}

function onBehalfSubmit(LoggedInEmpId, PurchaseRequistionID, PRApprovalMatrixID, ApprovalLevel, ApprovalStatus, source, reqNo) {
    var confirmationtext = '';
    var remark = '';
    if (ApprovalStatus == 6) {
        confirmationtext = 'Are you sure you want to cancel?';
    }
    else if (ApprovalStatus == 8) {
        confirmationtext = 'Are you sure you want to resubmit?';
    }
    if (ApprovalStatus == 6) {
        var ID = 'commentsPopup-' + PurchaseRequistionID;
        remark = $("#" + ID).val();
        if (remark == '') {
            alert("Remark required!");
            return false;
        }
    }
    if (confirm(confirmationtext)) {
        $('.loader-wrapper').show();

        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "Approval/UpdateApprovalStatus", // Controller/View
                data: { //Passing data
                    loggedInEmpId: LoggedInEmpId, PRrequisitionId: PurchaseRequistionID, PRApprovalMatrixID: PRApprovalMatrixID, ApprovalLevel: ApprovalLevel,
                    ApprovalStatus: ApprovalStatus, Remark: remark
                },
                success: function (result) {
                    if (result.responseCode == 1) {


                        alert("Success");

                        //location.reload();
                        location.href = appUrl + "Approval/RequistionRaised?PRNumber=" + reqNo;
                    }
                    else {
                        alert(result.responseMessage);
                    }
                    $('.loader-wrapper').hide();
                },
                error: function () {
                    $('.loader-wrapper').hide();
                    alert('Error while updating');

                }
            });
    }
}

function RefreshWaitingForApprovalList(source) {
    console.log('RefreshWaitingForApprovalList');
    try {
        if (source == 'login') {
            window.location.href = appUrl + 'Approval/Index';
        }
        else {
            //alert('Success');
            location.reload(true);
        }

    }
    catch (e) {
        alert('Error while resfeshing');
    }
}

function GetAuditTrial(PurchaseRequistionID, SerchType) {
    $('.loader-wrapper').show();
    var ulID = "audittrial-" + PurchaseRequistionID;
    $("#" + ulID).empty();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetAuditTrial", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: SerchType
            },
            success: function (result) {
                if (result.responseCode == 1) {
                    var reportData = JSON.parse(result.responseJSON);
                    if (reportData.length > 0) {
                        $.each(reportData, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td width="100">').text(item.DataField),
                                $('<td width="100">').text(item.OldValue),
                                $('<td width="100">').text(item.NewValue),
                                $('<td width="100">').text(item.UpdatedBy),
                                $('<td width="100">').text(item.UpdatedOn),
                            );

                            $("#" + ulID).append($tr);

                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="5">').text('No records to display'));
                        $("#" + ulID).append($tr);
                    }
                }
                else {
                    alert(result.responseMessage);
                }
                
                $('.loader-wrapper').hide();
            }

        });
}
function GetPREntity(PurchaseRequistionID, SerchType) {
    var ulID = "comment-" + PurchaseRequistionID;
    console.log(ulID);
    $("#" + ulID).empty();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPREntity", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: SerchType
            },
            success: function (result) {
                console.log('result');
                console.log(result);
                if (SerchType == 'PRNOTES') {
                    if (result.length > 0) {
                        $.each(result, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td width="100">').text(item.fullName),
                                $('<td width="100">').text(item.statusText),
                                $('<td width="100">').text(item.remarks),
                            );
                            console.log('$tr');
                            console.log($tr);
                            $("#" + ulID).append($tr);

                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                        $("#" + ulID).append($tr);
                    }
                }
                if (SerchType == 'DETAILLINE') {


                }

                $("#waitLoadingPanel").hide();
            }

        });
}

function GetPRFile(PurchaseRequistionID, SerchType) {
    var ulID = "attachment-" + PurchaseRequistionID;
    console.log(ulID);
    $("#" + ulID).empty();
    //$("divloading").show();
    $('.loader-wrapper').show();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRFiles", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: SerchType
            },
            success: function (result) {
                console.log('result');
                console.log(result);
                if (SerchType == 'PRFILES') {
                    if (result.length > 0) {
                        $.each(result, function (i, item) {
                            // var downloadLink = appUrl + "assets/PRDocument/" + item.fileContent;
                            var downloadLink = appUrl + "assets/PRDocument/" + item.filePath;
                            var ddlLink = "/assets/PRDocument/" + item.fileContent;
                            var ddl = "'" + item.fileName + "','" + ddlLink + "'";


                            var $tr = $('<tr>').append(

                                $('<td width="100">').text(item.fileName),
                                $('<td width="100">').text(item.submittedBy),
                                $('<td width="100">').html('&nbsp; <a href=# onclick=DownloadFile(' + ddl + ')>Download</a>'),
                                //$('<td width="100">').html('&nbsp; <a href=' + downloadLink + ' target="_blank">Download</a>'),
                            );
                            console.log('$tr');
                            console.log($tr);
                            $("#" + ulID).append($tr);

                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('No records to display'));
                        $("#" + ulID).append($tr);
                    }
                }
                //$("divloading").hide();
                $('.loader-wrapper').hide();
            }

        });
}

function editClick(PurchaseRequistionID) {
    var editmodalID = '#editDetail-' + PurchaseRequistionID;
    alert("Hi");
    $(editmodalID).modal('show');

}

function getSAPDetails(PurchaseRequistionID) {

    $('.loader-wrapper').show();
    $("#divSAPDetails").modal('show');
    $("#lblPRNo").text("");
    $("#lblPRDate").text("");
    $("#lblPODate").text("");
    $("#lblPONo").text("");
    $("#lblPOValue").text("");
    $("#lblVendor").text("");
    $("#lblRejectionReason").text("");
    $("#divrejectionReason").hide();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRSAPDetails", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: "PRSAPDETAIL"
            },
            success: function (result) {
                console.log('result');
                console.log(result);
                if (result.responseCode == 1) {
                    var myarray = JSON.parse(result.responseJSON);
                    if (myarray.length > 0) {


                        $("#lblPRNo").text(myarray[0].SAPPRNo);
                        if (myarray[0].SAPPRNo != "") {
                            $("#lblPRDate").text(myarray[0].SAPPRDate);
                        }

                        if (myarray[0].SAPPONo != "") {
                            $("#lblPODate").text(myarray[0].SAPPODate);
                        }

                        $("#lblPONo").text(myarray[0].SAPPONo);

                        $("#lblPOValue").text(myarray[0].TotalPOValue);
                        $("#lblVendor").text(myarray[0].VendorCode);

                        if (myarray[0].RejectionReason != "") {
                            $("#divrejectionReason").show();
                            $("#lblRejectionReason").text(myarray[0].RejectionReason);
                        }
                    }
                }
                else {
                    //var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    //$("#" + ulID).append($tr);
                }

                $('.loader-wrapper').hide();


            }

        });
}

function handleEditClick(PurchaseRequisitionDetailID, PurchaseRequistionID, glCode, oldstatusid) {
    $("#hdPRFiles").val(PurchaseRequistionID);
    $("#hdPRName").val(glCode);
    getEditDetails(PurchaseRequisitionDetailID, glCode, oldstatusid);
    GetEditPRFile(PurchaseRequistionID, 'PRFILES', oldstatusid);
}

function getEditDetails(pDetailID, reqNo,oldstatusid) {

    $("#editDetail").modal('show');
    $("#lblMaterialName").text("");
    $('.loader-wrapper').show();
    $("#hdPRDetailID").val(pDetailID);
    $("#hdPRNo").val(reqNo);
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRDetailByDetaiID", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: pDetailID, SearchType: "PRDETAILBYDETAILID"
            },
            success: function (result) {
                if (result.length > 0) {
                    $.each(result, function (i, item) {
                        $("#selMaterial").text(result[0].material);
                        $("#txtEditShortText").val(result[0].productType);
                        $("#txtAmount").val(result[0].amount);
                        $("#selQuantity").val(result[0].quantity);
                        $("#txtEditComments").val(result[0].lineComments);
                        $("#txtEditNeededByDate").val(result[0].needByDate);
                        bindMaterialDropDown(result[0].purchaseTypeName, result[0].materialCode, false);
                        if (result[0].purchaseTypeID == 1 || result[0].purchaseTypeID == 2 || result[0].purchaseTypeID == 7) {
                            $("#txtEditWarrantystartDate").prop("disabled", true);
                            $("#txtEditWarrantyEndDate").prop("disabled", true);
                        }

                        else {
                            $("#txtEditWarrantystartDate").prop("disabled", false);
                            $("#txtEditWarrantyEndDate").prop("disabled", false);
                            $("#txtEditWarrantystartDate").val(result[0].wsDate);
                            $("#txtEditWarrantyEndDate").val(result[0].weDate);
                        }
                        if (result[0].glCodeApplicable == 1) {
                            $("#divCartGLCode").show();
                            if (result[0].glCode != '' || result[0].glCode != '0') {
                                $("#divCartGLCode").show();
                                bindGLDropDown(result[0].glCode, result[0].materialCode);
                            }
                        }
                        else {
                            $("#divCartGLCode").hide();
                        }

                    });
                    if (oldstatusid==4) {
                        $("#selMaterialEdit").prop("disabled", true);
                        $("#selGLCodeEdit").prop("disabled", true);
                        //$("#txtEditNeededByDate").prop("disabled", true);
                        //$("#txtEditWarrantystartDate").prop("disabled", true);
                       // $("#txtEditWarrantyEndDate").prop("disabled", true);
                        $("#formFileMultiple").prop("disabled", true);
                        $("#btnAttachFile").prop("disabled", true);
                    }
                }

                else {

                }

                $('.loader-wrapper').hide();
            }

        });
}

function GetEditPRFile(pDetailID, SerchType,oldstatusid) {
    var ulID = "filesdisplay";
    console.log(ulID);
    $("#" + ulID).empty();
    //$("divloading").show();
    $('.loader-wrapper').show();
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRFiles", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: pDetailID, SearchType: SerchType
            },
            success: function (result) {
                console.log('result');
                console.log(result);
                if (SerchType == 'PRFILES') {
                    if (result.length > 0) {
                        $.each(result, function (i, item) {
                            var downloadLink = appUrl + "assets/PRDocument/" + item.fileContent;
                            var ddlLink = "/assets/PRDocument/" + item.fileContent;
                            var ddl = "'" + item.fileName + "','" + ddlLink + "'";
                            var attr = "'" + item.fileName + "','" + item.fileContent + "','" + item.filePath + "'";
                            var removeLink = '';

                            if (oldstatusid!=4) {
                                removeLink = '<a href="#" onclick=deleteFile(' + attr + ') > Remove</a >';
                            }
                            
                            var $tr = $('<tr>').append(
                                $('<td>').text(i + 1),
                                $('<td>').text(item.fileName),

                               
                                $('<td >').html('&nbsp; <a href=# onclick=DownloadFile(' + ddl + ')>Download</a>'),
                                $('<td >').html(removeLink),
                               
                            );
                            console.log('$tr');
                            console.log($tr);
                            $("#" + ulID).append($tr);

                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('No records to display'));
                        $("#" + ulID).append($tr);
                    }
                }
                //$("divloading").hide();
                $('.loader-wrapper').hide();
            }

        });
}

function editPRDetails() {
    var pDetailID = $("#hdPRDetailID").val();
    if (pDetailID == 0 || pDetailID == undefined) {
        alert("There is some issue in edit detail!");
        return false;
    }
    var productType = $("#txtEditShortText").val();
    if (productType == "") {
        alert("Short Text required!");
        $("#txtEditShortText").focus();
        return false;
    }
    else if (productType.length > 40) {
        alert("Short Text cannot exceed 40 characters!");
        $("#txtEditShortText").focus();
        return false;
    }
    var productAmount = $("#txtAmount").val();
    if (productAmount == "" || productAmount == 0) {
        alert("Product amount required!");
        $("#txtAmount").focus();
        return false;
    }
    var selQuantity = $("#selQuantity").val();
    if (selQuantity == 0 || selQuantity == "") {
        alert("Please select Quantity!");
        $("#selQuantity").focus();
        return false;
    }
    if ($("#txtEditComments").val() == "") {
        alert("Comments required!");
        $("#txtEditComments").focus();
        return false;
    }
    else if ($("#txtEditComments").length > 5000) {
        alert("Line comments cannot exceed 5000 characters!");
        $("#txtEditComments").focus();
        return false;
    }
    $('.loader-wrapper').show();

    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/UpdatePRDetail", // Controller/View
            data: { //Passing data
                PurchaseRequistionDetailID: pDetailID, Quantity: selQuantity, Amount: productAmount,
                NeededByDate: $("#txtEditNeededByDate").val(), WarrantyStartDate: $("#txtEditWarrantystartDate").val(),
                WarrantyEndDate: $("#txtEditWarrantyEndDate").val(), GLCode: $("#selGLCodeEdit").val(), MaterialCode: $("#selMaterialEdit").val(),
                "ShortText": productType, "LineComments": $("#txtEditComments").val()

            },
            success: function (result) {
                if (result.responseCode == 1) {
                    $("#editDetail").modal('hide');
                    location.href = appUrl + "Approval/RequistionRaised?PRNumber=" + $("#hdPRNo").val();
                }
                else if (result.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(result.responseMessage);
                }

                //$("#filesdisplay").empty();

                //if (result. != null && data.shoppingCartDetails[i].cartFiles.length > 0) {

                //    $.each(data.shoppingCartDetails[i].cartFiles, function (i, item) {
                //        var downloadLink = appUrl + "assets/PRDocument/" + item.filePath;
                //        var ddlLink = "/assets/PRDocument/" + item.filePath;
                //        var attr = "'" + item.fileNo + "'";
                //        var ddl = "'" + item.fileName + "','" + ddlLink + "'";
                //        var $tr = $('<tr>').append(
                //            $('<td>').text(i + 1),
                //            $('<td>').text(item.fileName),

                //            //$('<td >').html('&nbsp; <a href=' + downloadLink + ' target="_blank">Download</a>'),
                //            $('<td >').html('&nbsp; <a href=# onclick=DownloadFile(' + ddl + ')>Download</a>'),
                //            $('<td >').html('&nbsp; <a href="#" onclick=deleteFile(' + attr + ')>Remove</a>'),
                //        );

                //        $tr.attr("id", item.fileNo);
                //        $("#filesdisplay").append($tr);

                //    });

                //    $("#divFiles").show();
                //}
                //else {
                //    $("#divFiles").hide();
                //}

                $('.loader-wrapper').hide();

            },
            error: function () {
                $('.loader-wrapper').hide();
                alert('Error while updating');

            }
        });
}

function UpdateDetails(approvalValue) {

}
function DownloadFile(filename, filepath) {

    window.location.href = appUrl + 'Home/DownloadFile?FileName=' + filename + '&filePath=' + filepath;
};

/************  add new items *************/
function addLineItem(PurchaseRequistionID, reqNo) {
    $("#hdPR").val(PurchaseRequistionID);
    $("#hdAddPRNo").val(reqNo);
    $("#selMaterial").val("0");
    $("#selGLCode").val("0");
    $("#txtProductType").val("");
    $("#txtAmount").val("");
    $("#selQuantity").val("");
    $("#txtComments").val("");
    $("#addLineItem").modal('show');
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRDetailByDetaiID", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: "PRDETAILBYPRID"
            },
            success: function (result) {

                if (result.length > 0) {

                    $("#lblPRNo").text(result[0].requistionNo);
                    bindMasterDropDown(result[0].purchaseTypeName, '', false);
                    if (result[0].purchaseTypeID == 1 || result[0].purchaseTypeID == 2 || result[0].purchaseTypeID == 7) {
                        $("#txtWarrantystartDate").prop("disabled", true);
                        $("#txtWarrantyEndDate").prop("disabled", true);
                    }
                    else {
                        $("#txtWarrantystartDate").prop("disabled", false);
                        $("#txtWarrantyEndDate").prop("disabled", false);
                    }

                    if (result[0].glCodeApplicable == 1) {
                        $("#selGLCode").prop("disabled", false);
                        $("#selMaterial").change(function () {

                            if ($("#selMaterial").val() == "0") {
                                $("#selGLCode").empty();
                                $("#selGLCode").append($("<option />").val("0").text("Select"));
                            }
                            else {

                                bindGLDropDownEdit($("#selMaterial").val(), result[0].purchaseTypeID);
                            }


                        });
                    }
                }
                else {

                }

                $('.loader-wrapper').hide();
            }

        });
}
function addPRDetails() {
    var getPR = $("#hdPR").val();
    if (getPR == 0 || getPR == undefined) {
        alert("There is some issue in add line!");
        return false;
    }
    var selMaterial = $("#selMaterial").val();
    if (selMaterial == 0) {
        alert("Please select Material");
        $("#selMaterial").focus();
        return false;
    }
    var productType = $("#txtProductType").val();
    if (productType == "") {
        alert("Short Text required!");
        $("#txtProductType").focus();
        return false;
    }
    else if (productType.length > 40) {
        alert("Short Text cannot exceed 40 characters!");
        $("#txtProductType").focus();
        return false;
    }
    var productAmount = $("#txtAddAmount").val();
    if (productAmount == "" || productAmount == 0) {
        alert("Product amount required!");
        $("#txtAmount").focus();
        return false;
    }
    var selQuantity = $("#selAddQuantity").val();
    if (selQuantity == 0 || selQuantity == "") {
        alert("Please enter Quantity!");
        $("#selQuantity").focus();
        return false;
    }
    if ($("#txtComments").val() == "") {
        alert("Comments required!");
        $("#txtComments").focus();
        return false;
    }
    else if ($("#txtComments").length > 5000) {
        alert("Line comments cannot exceed 5000 characters!");
        $("#txtComments").focus();
        return false;
    }
    $('.loader-wrapper').show();

    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/AddPRDetail", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: $("#hdPR").val(), Quantity: selQuantity, Amount: productAmount,
                NeededByDate: $("#txtNeededByDate").val(), WarrantyStartDate: $("#txtWarrantystartDate").val(),
                WarrantyEndDate: $("#txtWarrantyEndDate").val(),
                MaterialCode: selMaterial, "ShortText": productType, "LineComments": $("#txtComments").val(),
                "GLCode": $("#selGLCode").val()

            },
            success: function (result) {
                if (result.responseCode == 1) {
                    $("#editDetail").modal('hide');
                    location.href = appUrl + "Approval/RequistionRaised?PRNumber=" + $("#hdAddPRNo").val();
                }
                else if (result.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";
                }
                else {
                    alert(result.responseMessage);
                }

                $('.loader-wrapper').hide();

            },
            error: function () {
                $('.loader-wrapper').hide();
                alert('Error while updating');

            }
        });
}
function bindGLDropDown(selectedValue, materialcode) {
    $("#selGLCodeEdit").empty();
    $("#selGLCodeEdit").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "GLMasterEdit", "SearchParameter1": materialcode
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selGLCodeEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selGLCodeEdit").val(selectedValue);
                }



            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function bindGLDropDownEdit(searchType, purchseType) {

    $("#selGLCode").empty();
    $("#selGLCode").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "GLCODE", "SearchParameter1": searchType, "SearchParameter2": purchseType
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selGLCode").append($("<option />").val(this.valueField).text(this.displayField));

                });

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}

function bindGLDropDownForEdit(materialcode) {
    $("#selGLCodeEdit").empty();
    $("#selGLCodeEdit").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "GLMasterEdit", "SearchParameter1": materialcode
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selGLCodeEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });


            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function bindMasterDropDown(searchType, selectedValue, disableflag) {

    $("#selMaterial").empty();
    $("#selMaterial").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "MaterialMaster", "SearchParameter1": searchType
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selMaterial").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selMaterial").val(selectedValue);

                }

                if (disableflag == true) {
                    $("#selMaterial").prop("disabled", true);
                }


            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function deletePRDetails(pDetailID, reqNo) {

    if (pDetailID == 0 || pDetailID == undefined) {
        alert("There is some issue in deletion!");
        return false;
    }
    if (confirm('Do you want to delete line item?')) {
        $('.loader-wrapper').show();

        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "Approval/DeletePRDetail", // Controller/View
                data: { //Passing data
                    PurchaseRequistionDetailID: pDetailID

                },
                success: function (result) {
                    if (result.responseCode == 1) {
                        $("#editDetail").modal('hide');
                        location.href = appUrl + "Approval/RequistionRaised?PRNumber=" + reqNo;
                    }
                    else if (result.responseCode == 2) {
                        location.href = appUrl + "Auth/Index";
                    }
                    else {
                        alert(result.responseMessage);
                    }

                    $('.loader-wrapper').hide();

                },
                error: function () {
                    $('.loader-wrapper').hide();
                    alert('Error while updating');

                }
            });
    }
}


/************** manage files ***********/
function opendattachmentdialog(PurchaseRequistionID) {
    $("#managePRFiles").modal('show');
    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRDetailByDetaiID", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID, SearchType: "PRFILES"
            },
            success: function (result) {

                if (result.length > 0) {
                    $.each(result, function (i, item) {
                        var downloadLink = appUrl + "assets/PRDocument/" + item.filePath;
                        var ddlLink = "/assets/PRDocument/" + item.filePath;
                        var attr = "'" + item.pRFileID + "'";
                        var ddl = "'" + item.fileName + "','" + ddlLink + "'";
                        var $tr = $('<tr>').append(
                            $('<td>').text(i + 1),
                            $('<td>').text(item.fileName),


                            $('<td >').html('&nbsp; <a href=# onclick=DownloadFile(' + ddl + ')>Download</a>'),
                            $('<td >').html('&nbsp; <a href="#" onclick=deleteFile(' + attr + ')>Remove</a>'),
                        );

                        $tr.attr("id", item.fileNo);
                        $("#bodyfiles").append($tr);

                    });


                }
                else {
                    var $tr = $('<tr>').append(
                        $('<td colspan="4" class="">').text("No records to display!"));
                    $("#bodyfiles").append($tr);
                }
                $('.loader-wrapper').hide();
            }

        });
}
function addFile() {
    var getPR = $("#hdPRFiles").val();
    var PRNo = $("#hdPRName").val();
    if (getPR == 0 || getPR == undefined) {
        alert("There is some issue in add file!");
        return false;
    }
    if (confirm('Do you want to upload file?')) {
        var fileUpload = $("#formFileMultiple").get(0);
        var files = fileUpload.files;

        if (files.length > 0) {


            for (var i = 0; i < files.length; i++) {

                var fileext = files[i].name.substr((files[i].name.lastIndexOf('.') + 1)).toLowerCase();

                if ($.inArray(fileext, ['gif', 'png', 'jpg', 'jpeg', 'pdf', 'eml', 'msg', 'xls', 'xlsx', 'PNG', 'doc', 'docx']) == -1) {
                    alert('Only (gif,png,jpg,jpeg,pdf,eml,xls,xlsx,doc,docx) are allowed!');
                    return false;
                }


            }

            var allowedSize = 0;


            for (var i = 0; i < files.length; i++) {
                const fsize = files.item(i).size;
                const file = Math.round((fsize / 1024));
                allowedSize = allowedSize + file;
                // The size of the file.

            }

            if (allowedSize > 10240) {
                alert("File too Big, please select files equal to 10 mb");


                return false;
            }

        }
        else {
            alert("Please choose the files then click on attach button!");
            return false;
        }

        $('.loader-wrapper').show();





        var data = new FormData();

        data.append("PRID", getPR);
        data.append("PRNO", PRNo);

        for (var i = 0; i < files.length; i++) {
            data.append("fileInput", files[i]);
        }
        $.ajax({

            type: "POST",

            url: appUrl + "Approval/Upload_File",

            contentType: false,

            processData: false,

            data: data,

            async: false,

            beforeSend: function () {

                $("#divloader").show()

            },

            success: function (data) {
                $('.loader-wrapper').hide();
                if (data.responseCode == 0) {
                    alert(data.responseMessage);
                    opendattachmentdialog(getPR);
                }
                else {
                    alert("file uploaded Successfully!");
                    GetEditPRFile(getPR, 'PRFILES');

                }

                //location.href = appUrl + "Cart/Index";

            },

            error: function () {

                alert("Error!");

            },

            complete: function () {

                $("#divloader").hide()

            }

        });
    }

}

function deleteFile(filename, fileContent, filepath) {
    $('.loader-wrapper').show();
    var getPR = $("#hdPRFiles").val();
    if (getPR == 0 || getPR == undefined) {
        alert("There is some issue in delete file!");
        return false;
    }
    if (confirm('Do you want to delete file?')) {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Approval/DeleteFile',
            data: {
                "filename": filename, "filecontent": fileContent, "filepath": filepath, "PRID": getPR
            },
            success: function (data) {
                $('.loader-wrapper').hide();
                if (data.responseCode == 0) {
                    alert(data.responseMessage);
                    opendattachmentdialog(getPR);
                }
                else {
                    alert("file deleted Successfully!");
                    GetEditPRFile(getPR, 'PRFILES');
                }

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }
}

/************* change to hold **********/
function changeToHold(PRID, reqNo) {
    if (PRID == 0 || PRID == undefined) {
        alert("There is some issue in change status!");
        return false;
    }
    if (confirm('Do you want to change status to hold?')) {
        $('.loader-wrapper').show();

        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "Approval/ChangeStatus", // Controller/View
                data: { //Passing data
                    PurchaseRequistionID: PRID

                },
                success: function (result) {
                    if (result.responseCode == 1) {
                        $("#editDetail").modal('hide');
                        location.href = appUrl + "Approval/RequistionRaised?PRNumber=" + reqNo;
                    }
                    else if (result.responseCode == 2) {
                        location.href = appUrl + "Auth/Index";
                    }
                    else {
                        alert(result.responseMessage);
                    }

                    $('.loader-wrapper').hide();

                },
                error: function () {
                    $('.loader-wrapper').hide();
                    alert('Error while updating');

                }
            });
    }
}
function openChangeCC(PurchaseRequistionID, reqNo, pono, oldStatus) {
    $("#changeHeaderDetails").modal('show');
    $("#hdPRHeader").val(PurchaseRequistionID);
    $("#hdPRReqNo").val(reqNo);

    $("#selPurchaseTypeEdit").empty();
    $("#selPurchaseGroupEdit").empty();
    $("#selCurrencyEdit").empty();
    $("#selVendorEdit").empty();
    $("#selPlantCodeEdit").empty();
    $("#selPurchaseOrganisationEdit").empty();
    $("#selCostCentreEdit").empty();

    $("#selPurchaseTypeEdit").append($("<option />").val("0").text("Select"));
    $("#selPurchaseGroupEdit").append($("<option />").val("0").text("Select"));
    $("#selCurrencyEdit").append($("<option />").val("0").text("Select"));
    $("#selVendorEdit").append($("<option />").val("0").text("Select"));
    $("#selPlantCodeEdit").append($("<option />").val("0").text("Select"));
    $("#selPurchaseOrganisationEdit").append($("<option />").val("0").text("Select"));
    $("#selCostCentreEdit").append($("<option />").val("0").text("Select"));

    $('.loader-wrapper').show();

    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PRCC", "SearchParameter1": PurchaseRequistionID
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    if (item.isDefault == 1) {
                        $("#selCostCentreEdit").append($("<option selected />").val(this.valueField).text(this.displayField));
                    }
                    else {
                        $("#selCostCentreEdit").append($("<option />").val(this.valueField).text(this.displayField));
                    }


                });

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });

    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PRPT", "SearchParameter1": PurchaseRequistionID
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    if (item.isDefault == 1) {
                        $("#selPurchaseTypeEdit").append($("<option selected />").val(this.valueField).text(this.displayField));
                    }
                    else {
                        $("#selPurchaseTypeEdit").append($("<option />").val(this.valueField).text(this.displayField));
                    }


                });

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });

    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PRPG", "SearchParameter1": PurchaseRequistionID
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    if (item.isDefault == 1) {
                        $("#selPurchaseGroupEdit").append($("<option selected />").val(this.valueField).text(this.displayField));
                    }
                    else {
                        $("#selPurchaseGroupEdit").append($("<option />").val(this.valueField).text(this.displayField));
                    }


                });

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });

    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PRCU", "SearchParameter1": PurchaseRequistionID
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    if (item.isDefault == 1) {
                        $("#selCurrencyEdit").append($("<option selected />").val(this.valueField).text(this.displayField));
                    }
                    else {
                        $("#selCurrencyEdit").append($("<option />").val(this.valueField).text(this.displayField));
                    }


                });

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });


    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PRV", "SearchParameter1": PurchaseRequistionID
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    if (item.isDefault == 1) {
                        $("#selVendorEdit").append($("<option selected />").val(this.valueField).text(this.displayField));
                    }
                    else {
                        $("#selVendorEdit").append($("<option />").val(this.valueField).text(this.displayField));
                    }


                });

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });

    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PRPO", "SearchParameter1": PurchaseRequistionID
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    if (item.isDefault == 1) {
                        $("#selPurchaseOrganisationEdit").append($("<option selected />").val(this.valueField).text(this.displayField));
                    }
                    else {
                        $("#selPurchaseOrganisationEdit").append($("<option />").val(this.valueField).text(this.displayField));
                    }


                });

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });

    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PRPC", "SearchParameter1": PurchaseRequistionID
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    if (item.isDefault == 1) {
                        $("#selPlantCodeEdit").append($("<option selected />").val(this.valueField).text(this.displayField));
                    }
                    else {
                        $("#selPlantCodeEdit").append($("<option />").val(this.valueField).text(this.displayField));
                    }


                });
                if (pono != '') {
                  
                    var ptypetxt = $("#selPurchaseTypeEdit option:selected").text();
                    // alert(ptypetxt);
                    if (ptypetxt == "Capex With Service" || ptypetxt == "Opex With Service" || ptypetxt == "Recovery With Service") {
                        $("#selPlantCodeEdit").prop("disabled", true);
                    }

                }

            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });

    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Approval/GetPRHeaderDetails", // Controller/View
            data: { //Passing data
                PurchaseRequistionID: PurchaseRequistionID
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    getRights();
                    var reportData = JSON.parse(data.responseJSON);
                    if (reportData.length > 0) {
                        $("#selOnBehalfOfEdit").val(reportData[0].OnBehalfOfFlag);
                        if (reportData[0].OnBehalfOfFlag == "yesOnBehalfOf") {

                            $(".hideDiv").show();
                            $(".hideDivEmp").hide();
                            //$("#inlineRadio1Edit").prop("disabled", true);
                            //$("#inlineRadio2Edit").prop("checked", true);
                            $("#txtSearchEmployee").val(reportData[0].CreatorName);
                            $("#selEmployeeEdit option:selected").val(reportData[0].CreatorCode);
                            $("#selEmployeeEdit option:selected").text(reportData[0].CreatorName);
                            /*bindEmployeeDropDown(data.employeeCode, true);*/


                        }
                        else {
                            $(".hideDiv").hide();
                            $(".hideDivEmp").hide();

                        }
                    }
                }
                else {

                }

                $('.loader-wrapper').hide();
            }

        });
    selectedPurchaseTypeCon = $("#selPurchaseTypeEdit option:selected").text();
    if (oldStatus != undefined && oldStatus == "4") {
        $("#selPurchaseTypeEdit").prop("disabled", true);
        $("#selPurchaseGroupEdit").prop("disabled", true);
        $("#selOnBehalfOfEdit").prop("disabled", true);
        $("#txtSearchEmployee").prop("disabled", true);
        $("#selEmployeeEdit").prop("disabled", true);
        $("#selPurchaseOrganisationEdit").prop("disabled", true);
        
    }

    if (pono != '') {
        $("#selCurrencyEdit").prop("disabled", true);
        $("#selVendorEdit").prop("disabled", true);

        var ptypetxt = $("#selPurchaseTypeEdit option:selected").text();
       // alert(ptypetxt);
        if (ptypetxt == "Capex With Service" || ptypetxt == "Opex With Service" || ptypetxt == "Recovery With Service") {
            $("#selPlantCodeEdit").prop("disabled", true);
        }

    }
}
function changePRHeader() {
    if ($("#hdPRHeader").val() == 0 || $("#hdPRHeader").val() == undefined) {
        alert("There is some issue in change status!");
        return false;
    }
    if (confirm('Do you want to change PR details?')) {
        $('.loader-wrapper').show();

        var ptype = $("#selPurchaseTypeEdit").val();
        if (ptype == "" || ptype == "0") {
            alert("Please Select Purchase Type!");
            $("#selPurchaseTypeEdit").focus();
            return false;
        }
        var ptypetxt=$("#selPurchaseTypeEdit option:selected").text();
        if (selectedPurchaseTypeCon == "Capex" || selectedPurchaseTypeCon == "Opex" || selectedPurchaseTypeCon == "Recovery") {
            if (ptypetxt == "Capex With Service" || ptypetxt == "Opex With Service" || ptypetxt == "Recovery With Service") {
                alert("Please select either Capex/Opex/Recovery as Purchase Type!");
                $("#selPurchaseTypeEdit").focus();
                return false;
            }



        }
        if (selectedPurchaseTypeCon == "Capex With Service" || selectedPurchaseTypeCon == "Opex With Service" || selectedPurchaseTypeCon == "Recovery With Service") {
            if (ptypetxt == "Capex" || ptypetxt == "Opex" || ptypetxt == "Recovery") {
                alert("Please select either Capex with Service/Opex with Service/Recovery with Service as Purchase Type!");
                $("#selPurchaseTypeEdit").focus();
                return false;
            }



        }
        var pgroup = $("#selPurchaseGroupEdit").val();
        if (pgroup == "" || pgroup == "0") {
            alert("Please Select Purchase Group!");
            $("#selPurchaseGroupEdit").focus();
            return false;
        }
        var pgroup = $("#selPurchaseGroupEdit").val();
        if (pgroup == "" || pgroup == "0") {
            alert("Please Select Purchase Group!");
            $("#selPurchaseGroupEdit").focus();
            return false;
        }
        var curr = $("#selCurrencyEdit").val();
        if (curr == "" || curr == "0") {
            alert("Please Select Currency");
            $("#selCurrencyEdit").focus();
            return false;
        }
        var cc = $("#selCostCentreEdit").val();
        if (cc == "" || cc == "0") {
            alert("Please Select Cost Centre");
            $("#selCostCentreEdit").focus();
            return false;
        }
        var vendor = $("#selVendorEdit").val();
        if (vendor == "" || vendor == "0") {
            alert("Please Select Vendor");
            $("#selVendorEdit").focus();
            return false;
        }
        var plant = $("#selPlantCodeEdit").val();
        if (plant == "" || plant == "0") {
            alert("Please Select Plant Code");
            $("#selPlantCodeEdit").focus();
            return false;
        }
        var po = $("#selPurchaseOrganisationEdit").val();
        if (po == "" || po == "0") {
            alert("Please Select Purchase Organisation");
            $("#selPurchaseOrganisationEdit").focus();
            return false;
        }
        var onbehalf = $("#selOnBehalfOfEdit").val();
        var searchtext = $("#txtSearchEmployee").val();
        if (onbehalf == 'yesOnBehalfOf') {
            var employee = $("#selEmployeeEdit").val();
            if (employee == "" || employee == "0") {
                alert("Please Select Employee!");
                $("#selEmployeeEdit").focus();
                return false;
            }
            if (searchtext == "" || searchtext == "0") {
                alert("Please Enter Search Text!");
                $("#txtSearchEmployee").focus();
                return false;
            }
        }

        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "Approval/ChangePRHeaderDetails", // Controller/View
                data: { //Passing data
                    PurchaseRequistionID: $("#hdPRHeader").val(), CostCenterCode: $("#selCostCentreEdit option:selected").val(), PurchaseTypeCode: $("#selPurchaseTypeEdit option:selected").val(),
                    PurchaseGroup: $("#selPurchaseGroupEdit option:selected").val(), PlantCode: $("#selPlantCodeEdit option:selected").val(), PurchaseOrganisationCode: $("#selPurchaseOrganisationEdit option:selected").val(),
                    VendorCode: $("#selVendorEdit option:selected").val(), CurrencyCode: $("#selCurrencyEdit option:selected").val(), OnBehalfOfFlag: $("#selOnBehalfOfEdit option:selected").val(), CreatorCode: $("#selEmployeeEdit option:selected").val()

                },
                success: function (result) {
                    if (result.responseCode == 1) {
                        $("#editDetail").modal('hide');
                        location.href = appUrl + "Approval/RequistionRaised?PRNumber=" + $("#hdPRReqNo").val();
                    }
                    else if (result.responseCode == 2) {
                        location.href = appUrl + "Auth/Index";
                    }
                    else {
                        alert(result.responseMessage);
                    }

                    $('.loader-wrapper').hide();

                },
                error: function () {
                    $('.loader-wrapper').hide();
                    alert('Error while updating');

                }
            });
    }
}

function searchUser() {
    $(".hideDivEmp").show();
    var searchString = $("#txtSearchEmployee").val();
    if (searchString == '') {
        alert("Please enter search text!");
        return false;

    }
    else if (searchString.length < 2) {
        alert("Please provide at least three characters to search!");
        return false;

    }
    $('.loader-wrapper').show();

    $("#selEmployeeEdit").empty();
    $("#selEmployeeEdit").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "SearchUser", "SearchParameter1": searchString
        },
        success: function (data, textstatus) {
            if (data.responseCode == 1) {

                $.each(data.masterDataResponses, function () {
                    $("#selEmployeeEdit").append($("<option />").val(this.valueField).text(this.displayField));
                });
            }

            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });


}

function getRights() {
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetUserBehalfRight',
        data: {

        },
        success: function (data, textstatus) {
            if (data == '') {
                $("#selOnBehalfOfEdit").val("noOnBehalfOf");
                $("#selOnBehalfOfEdit").prop("disabled", true);
            }



        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function bindMaterialDropDown(searchType, selectedValue, disableflag) {
    $("#selMaterialEdit").empty();
    $("#selMaterialEdit").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "MaterialMaster", "SearchParameter1": searchType
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selMaterialEdit").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selMaterialEdit").val(selectedValue);
                }

                if (disableflag == true) {
                    $("#selMaterialEdit").prop("disabled", true);
                }


            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
