﻿var appUrl = '';
var excelData = [];
var catalogueResponseData = [];
var currentPageNo = 1;
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    BindCompanyMaster();
    if ($('#tbUploadCatalogue').length) {
        emptyUploadRows();
        $("#btnUploadData").hide();
    }
    if ($('#tbManageCatalogue').length) {
        emptyManageCatalogueRows();
    }

    function selectPicker2() {
        $(".selectPicker2").select2();
    }

    selectPicker2();

    $("#btnCatalogueExport").click(function () {
        if ($("#UploadCompany").val() == "0") {
            alert("Please select Company!");
            return false;
        }
        let fromDate = $("#dtFromDateAdvance").val().substring(0, 12);
        let toDate = $("#dtFromDateAdvance").val().substring(13, 25);
        $("input[name='fromDate']").val(fromDate);
        $("input[name='toDate']").val(toDate);
        $("input[name='hdUploadCompany']").val($("#UploadCompany").val());
        $("input[name='hdtxtSupplier']").val($("#txtSupplier").val());
        $("input[name='hdtxtMaterialCode']").val($("#txtMaterialCode").val());
        $("input[name='hdddlPublishStatus']").val($("#ddlPublishStatus").val());
      
    });
    $('.loader-wrapper').hide();
});
function BindCompanyMaster() {
    $("#UploadCompany").empty();
    $("#UploadCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "GET",
            url: appUrl + "Admin/GetCompanyMaster",
            dataType: "JSON",
            data: null,
            success: function (data) {
                if (data.recordCount > 0) {
                    $.each(data.costCenter, function (i, item) {
                        $("#UploadCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }
               
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }

        }
    );
}
function uploadFile() {
    if ($("#UploadCompany").val() == "0") {
        alert("Please select Company!");
        return false;
    }
    excelData = [];
    var fileUpload = $("#formFileMultiple").get(0);

    var files = fileUpload.files;
    if (files.length == 0) {
        alert("Please select file!");
        return false;
    }

    for (var i = 0; i < files.length; i++) {

        var fileext = files[i].name.substr((files[i].name.lastIndexOf('.') + 1));

        if ($.inArray(fileext, ['xlsx', 'xls']) == -1) {
            alert('Only (xlsx,xls) are allowed!');
            return false;
        }


    }

    var data = new FormData();
    data.append("companyCode", $("#UploadCompany").val());

    for (var i = 0; i < files.length; i++) {
        data.append("fileInput", files[i]);
    }

    $('.loader-wrapper').show();
    $("#bodyExcelData").empty();
    $.ajax({

        type: "POST",

        url: appUrl + "Admin/UploadCatalogueData",

        contentType: false,

        processData: false,

        data: data,

        async: false,

        beforeSend: function () {
            $('.loader-wrapper').show();


        },

        success: function (data, textstatus) {

            if (data.responseCode == 1 || data.responseCode == 3) {
                var responseData = JSON.parse(data.responseJSON);
                var length = responseData.length;
                if (length > 0) {
                    //$("#btnVerifyData").prop("disabled", false);
                    if (data.responseCode == 1) {
                        $("#btnUploadData").show();
                    }
                    else {
                        alert(data.responseMessage);
                        $("#btnUploadData").hide();
                    }

                    excelData = responseData;
                    var arrayCount = responseData.length;
                    var loopCount = 1;
                    $.each(responseData, function (i, item) {
                        var errorText = '';
                        if (item.Error != '' && item.Error != 'SUCCESS' && item.Error != null) {
                            errorText = '<label style="color:red">' + item.Error + '</label>';
                        }
                        else {
                            errorText = item.Error;
                        }
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(i + 1),
                            $('<td>').text(item.SupplierCode),
                            $('<td>').text(item.SupplierPartID),
                            
                            $('<td>').text(item.MaterialCode),
                            $('<td>').text(item.ItemDescription),
                            $('<td class="text-center">').text(item.UnitPrice),
                            $('<td>').text(item.UOM),
                            $('<td>').text(item.Currency),
                            $('<td>').text(item.ShortName),
                            $('<td>').text(item.PlantCode),
                            $('<td>').text(item.Image),
                            $('<td>').html(errorText),

                        );
                        $("#bodyExcelData").append($tr);

                        //loopCount = parseInt(loopCount) + 1;
                        //if (arrayCount == loopCount) {
                        //    $('.loader-wrapper').hide();
                        //}
                        $('.loader-wrapper').hide();
                    });

                    
                }
                else {
                    emptyUploadRows();
                    $("#bodyExcelData").append($tr);

                    $('.loader-wrapper').hide();
                }

            }
            else if (data.responseCode == 2) {

                location.href = appUrl + "Auth/Index";

            }
            else {
                alert(data.responseMessage);
                $('.loader-wrapper').hide();
            }

            clearFileUploadControl();
        },

        error: function (data) {

            alert("Please refresh the page and select file again!");
            $('.loader-wrapper').hide();
            emptyUploadRows();
            clearFileUploadControl();

        },

        complete: function () {

            // $('.loader-wrapper').hide();

        }

    });
}
function clearFileUploadControl() {
    $("#formFileMultiple").val("");
}
function emptyUploadRows() {
    var $trManage = $('<tr>').append(
        $('<td colspan="12" class="text-center">').text("No records to display!")
    );
    $("#bodyExcelData").append($trManage);
}
function emptyManageCatalogueRows() {
    var $trManage = $('<tr>').append(
        $('<td colspan="13" class="text-center">').text("No records to display!")
    );
    $("#tbmanageCatalogueData").append($trManage);
}
function UploadData() {
    if ($("#UploadCompany").val() == "0") {
        alert("Please select Company!");
        return false;
    }
    if (excelData.length == 0 || excelData == undefined) {
        alert("Please add some data!");
        return false;
    }

    
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',

        url: appUrl + 'Admin/UploadData',
        data: { "CompanyCode": $("#UploadCompany").val(),"catalogueDataUploadRequestLines": excelData },
        success: function (data, textstatus) {
            $('.loader-wrapper').hide();
            if (data.responseCode == 1) {

                alert("Data submitted successfully!");
                $("#bodyExcelData").empty();
                $("#formFileMultiple").val("");
                excelData = [];
                $("#btnUploadData").hide();
                emptyUploadRows();
                $("#UploadCompany").val("0");
            }
            else if (data.responseCode == 2) {

                location.href = appUrl + "Auth/Index";

            }
            else {
                alert(data.responseMessage);

            }

            $('.loader-wrapper').hide();
            clearFileUploadControl();
            $("#btnUploadData").hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
            clearFileUploadControl();
        }
    });
}
function showInfo() {
    $("#viewInstruction").modal('show');
}
function advanceSearch() {
    if ($("#UploadCompany").val() == "0") {
        alert("Please select Company!");
        return false;
    }
    $("#modelAdvanceSearch").modal('show');
    //BindCompanySupplier();
}
function BindCompanySupplier() {
    $('.loader-wrapper').show();
    $("#ddlSupplier").empty();
    $("#ddlSupplier").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + "Admin/GetAdvancedSearchData",
            dataType: "JSON",
            data: { "EntityName": "CompanySupplier"},
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#ddlSupplier").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }
                $('.loader-wrapper').hide();
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function advanceSearchEnable() {
    $("#modelAdvanceSearch").modal('hide');
    GetCatalogueData(1,40);
}
function GetCatalogueData(pageNum, pageSize) {
    currentPageNo = pageNum;
    catalogueResponseData = [];
    if (!pageSize) {

        pageSize = 40;
    }

    let fromDate = $("#dtFromDateAdvance").val().substring(0, 12);
    let toDate = $("#dtFromDateAdvance").val().substring(13, 25);
    var SearchCriteria = '0';
    var SearchValue = '';
    
    $("#tbmanageCatalogueData").empty();
    $("#userPageList").empty();

    $('.loader-wrapper').show();

    $.ajax(
        {
            type: "POST", //HTTP POST Method  
            url: appUrl + 'Admin/ManageCatalogue',

            data: {
               
                "FromDate": fromDate, "ToDate": toDate,
                "RowsOfPage": pageSize, "PageNumber": pageNum,
                "PublishStatus": $("#ddlPublishStatus").val(),
                "SupplierCode": $("#txtSupplier").val(),
                "MaterialCode": $("#txtMaterialCode").val()
                
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    var responseData = JSON.parse(data.responseJSON);
                    if (responseData.length > 0) {
                        catalogueResponseData = responseData;
                        $.each(responseData, function (i, item) {
                            var checkBoxID = 'chk' + item.CatalogueDataID;
                            var checkbox;
                            if (item.PublishStatus == 'Published') {
                                checkbox = "<input checked class='form - check - input' type='checkbox' value='' id=" + checkBoxID + ">";
                            }
                            else {
                                checkbox = "<input class='form - check - input' type='checkbox' value='' id=" + checkBoxID + ">";
                            }
                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(item.SRNo),
                                $('<td>').text(item.Supplier),
                                $('<td>').text(item.SupplierPartID),
                                $('<td>').text(item.Material),
                                $('<td>').text(item.ItemDescription),
                                $('<td class="text-right">').text(item.UnitPrice),
                                $('<td>').text(item.ItemUOM),
                                $('<td>').text(item.Currency),
                                $('<td>').text(item.ShortName),
                                $('<td>').text(item.PlantCode),
                                $('<td>').text(item.UploadedDate),
                                $('<td>').text(item.PublishStatus),
                                $('<td>').html(checkbox),
                                //$('<td>').html(sendEmail),
                            );
                            $("#tbmanageCatalogueData").append($tr);


                        });
                    }
                    else {
                        emptyManageCatalogueRows();
                    }
                }
                else {
                    emptyManageCatalogueRows();
                }
                CandidatePaging(data.recordCount, pageNum);
                $('.loader-wrapper').hide();



            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        });
}
function CandidatePaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetCatalogueData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        
        '<li><a href="#" onclick="GetCatalogueData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetCatalogueData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetCatalogueData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetCatalogueData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#userPageList").append(template);
}
function updatePublishStaus() {
    var dataToSave = [];
    if (catalogueResponseData.length==0) {
        alert("No data to make action!");
        return false;
    }

    $.each(catalogueResponseData, function (i, item) {
        var checkBoxID = '#chk' + item.CatalogueDataID;

        if ($(checkBoxID).prop('checked') == true) {
            dataToSave.push({ "CatalogueDataID": item.CatalogueDataID,"PublishStatus":1});
        }
        else {
            dataToSave.push({ "CatalogueDataID": item.CatalogueDataID, "PublishStatus": 0 });
        }
        

    });
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/UpdateCataloguePublishStatus',
        data: {
            "updatePublishStatusRequestLines": dataToSave
        },
        success: function (pdata) {
            if (pdata.responseCode == 1) {

                dataToSave = [];
                //catalogueResponseData = [];
                alert("Data Updated Successfully!");
                GetCatalogueData(currentPageNo, 40);
            }
            else {
                alert(pdata.responseMessage);
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("There is some issue!");
        }
    });
}
function resetpopValues() {
    $("#txtSupplier").val("");
    $("#txtMaterialCode").val("");
    $("#ddlPublishStatus").val("0");
    $("#dtFromDateAdvance").val('');
    var singleDate = false;
    var initiateDate = true;
    $("#dtFromDateAdvance").daterangepicker({
        locale: {
            format: 'DD-MMM-YYYY'
        },
        autoUpdateInput: true,
        singleDatePicker: singleDate,
        showDropdowns: singleDate,
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    });
}