﻿var appUrl = '';
$(document).ready(function () {
    
    setAppUrl();
    
});
function setAppUrl() {
    var pageURL = $(location).attr("href");
    if (pageURL.indexOf("localhost") != -1) {
        appUrl = 'http://localhost:36733/'
    }
    else if (pageURL.indexOf("http://10.247.251.110/") != -1) {
        appUrl = 'http://10.247.251.110/P2OWeb/'
    }
    else if (pageURL.indexOf("https://hgsconnectbeta.teamhgs.com/P2OWEB") != -1) {
        appUrl = 'https://hgsconnectbeta.teamhgs.com/P2OWEB/'
    }
    else if (pageURL.indexOf("https://hgsconnectbeta.teamhgs.com/PurchaseToOrder") != -1) {
        appUrl = 'https://hgsconnectbeta.teamhgs.com/PurchaseToOrder/'
    }
    else if (pageURL.indexOf("https://hgsconnect.teamhgs.com/PurchaseToOrder") != -1) {
        appUrl = 'https://hgsconnect.teamhgs.com/PurchaseToOrder/'
    }
    return appUrl;
}

function checkReadonlyAccess() {
    
    var result = false;
    $.ajax({
        type: 'POST',
        url: appUrl + 'Home/CheckReadOnlyAccess',
        data: {

        },
        success: function (data, textstatus) {
            if (data != '') {
                result = true;
                return result;
            }
            else {
                result = false;
                return result;
            }

            
            //callback();
            

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            return false;
        }
    });


    
   
    
}
function checkFileExtensions() {

}