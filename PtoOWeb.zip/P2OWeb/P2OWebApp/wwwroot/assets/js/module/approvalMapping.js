﻿var appUrl = '';
var addedLevel = [];
$(document).ready(function () {
    
    appUrl = setAppUrl();

    selectPicker2();

    GetCompanyDDLData();

    GetRoleMasterDDLData();

    //$("#SelectCompany").change(function () {
    //    var count = 0;
    //    $('#ulAssignedList li').each(function () {
    //        count = parseInt(count) + 1;

    //    });

    //    if (count> 0 || addedLevel.length>0) {
    //        if (confirm("Do you want to change company!")) {
    //            return true;
    //        }
    //    }

    //});

    
});

function searchCostCenter() {

    $("#lstCostCenter").html("");

    if ($("#SelectCompany").val() > "0") {
        $('.loader-wrapper').show();
        $.ajax({
            type: 'POST',
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            data: {
                "EntityName": "CostCenterNotAssigned", "SearchParameter1": $("#SelectCompany").val()
            },
            success: function (pdata, textstatus) {
                if (pdata.responseCode == 1) {
                    $.each(pdata.masterDataResponses, function (i, item) {
                        var list = "<li>" + item.valueField + "</li>";

                        $("#lstCostCenter").append(list);
                    });


                    $("#lstCostCenter").focus();

                    if (pdata.masterDataResponses.length>0) {
                        $("#SelectCompany").prop("disabled", true);
                    }
                   

                }
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
    }
    else {
        $("#lstCostCenter").html("");


    }
}

function saveAppHierarchy() {

    if (addedLevel.length==0) {
        alert("Please add level data!");
        return false;
    }

    var count = 0;
    $('#ulAssignedList li').each(function () {
        count = count + 1;

    });

    if (count==0) {
        alert("Please select cost center!");
        return false;
    }


    var confirmText = 'Do you want to save details?';

    if (confirm(confirmText)) {

        $('.loader-wrapper').show();

        var costCenterAPRequestLists = [];
        

        $('#ulAssignedList li').each(function () {

            //alert($(this).text());
            costCenterAPRequestLists.push({ "CostCenterCode": $(this).text()});
        });

        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "ApprovalMapping/CreateApplicatonHierarchy", // Controller/View
                data: {
                    "costCenterAPRequestLists": costCenterAPRequestLists, "approvalLevelRequestLists": addedLevel
                },
                success: function (result) {

                    if (result.responseCode == 1) {

                        alert(result.responseMessage);

                        //GetCompanyDDLData();

                        searchCostCenter();

                        addedLevel = [];

                        bindLevelData();

                        $("#SelectLevel").val("0");
                        $("#SelectRole").val("0");

                        $("#ulAssignedList").empty();
                    }
                    else if (result.responseCode == 0) {
                        alert(result.responseMessage);
                    }
                    else if (result.responseCode == 2) {
                        location.href = appUrl + "Auth/Index";
                    }

                    $('.loader-wrapper').hide();



                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('.loader-wrapper').hide();
                }

            });

    }
}

function addLevel() {
    
    var count = 0;
    $('#ulAssignedList li').each(function () {
        count = count + 1;

    });

    if (count == 0) {
        alert("Please select cost center!");
        return false;
    }

    var appLevel = $("#SelectLevel").val();
    if (appLevel=="0") {
        alert("Please select Level!");
        return false;
    }
    var roleSelected = $("#SelectRole").val();
    if (roleSelected == "0") {
        alert("Please select Role!");
        return false;
    }

    if (addedLevel.length > 0) {
        var validate = true;
        var LastLevel = 0;

        $.each(addedLevel, function (i, item) {
            if (item.Level == appLevel && item.RoleCode == roleSelected) {
                alert("Combintion already added!");
                validate = false;
            }

            if (item.RoleCode == roleSelected) {
                alert("This roleCode already added in level data!");
                validate = false;
            }

            LastLevel = item.Level;

        });

        

        if (parseInt(LastLevel)>0) {
            if (parseInt(appLevel) - parseInt(LastLevel) > 1) {
                alert("Please add level data in sequence!");
                validate = false;
            }
        }

        

        if (validate) {
            addedLevel.push({ "Level": appLevel, "RoleCode": roleSelected, "RoleName": $("#SelectRole option:selected").text() });
            bindLevelData();
        }

    }
    else {
        if (appLevel>2) {
            alert("Please add level data in sequence!");
            return false;
        }
        addedLevel.push({ "Level": appLevel, "RoleCode": roleSelected, "RoleName": $("#SelectRole option:selected").text() });
        bindLevelData();
    }

    
}

function removeLevel(appLevel) {
   
    //var getIndex = addedLevel.findIndex(el => {
    //    return el.Level === appLevel;
    //});

    //alert(getIndex);
    //if (getIndex === -1) {
    //    return false;
    //}

    //addedLevel.splice(appLevel, 1);
    bindLevelData();
}

function clearLevel() {
    if (addedLevel.length>0) {
        if (confirm('Do you want to clear level data!')) {
            addedLevel = [];
            $("#SelectLevel").val("0");
            $("#SelectRole").val("0");

            bindLevelData();
        }
    }
    else {
        alert("Please add level data first!");
        return false;
    }
    
}

function bindLevelData() {
    $("#bodyfiles").empty();
    if (addedLevel.length > 0) {

        $.each(addedLevel, function (i, item) {
            //var attr = "'" + item.fileNo + "'";
            var $tr = $('<tr>').append(
                $('<td>').text(i + 1),
                $('<td>').text(item.Level),
                $('<td>').text(item.RoleName),
                // $('<td >').html('&nbsp; <a href=' + item.fileContent + ' download=' + item.fileName + '>Download</a>'),
                //$('<td >').html('&nbsp; <a href="#" onclick=removeLevel(' + item.Level + ')>Remove</a>'),
            );

            //$tr.attr("id", item.fileNo);
            $("#bodyfiles").append($tr);

        });
    }
}

function selectPicker2() {
    $(".selectPicker2").select2();
}

function GetRoleMasterDDLData() {
    $('.loader-wrapper').show();
    $("#SelectRole").empty();
    $("#SelectRole").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + "PurchaseRequistion/GetMasterData",
            dataType: "JSON",
            data: {
                "EntityName": "RoleMasterAPPHierarchy"
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#SelectRole").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}

function GetCompanyDDLData() {
    $('.loader-wrapper').show();
    $("#SelectCompany").empty();
    $("#SelectCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "GET",
            url: appUrl +  "Admin/GetCompanyMaster",
            dataType: "JSON",
            data: null,
            success: function (data) {
                if (data.recordCount > 0) {
                    $.each(data.costCenter, function (i, item) {
                        $("#SelectCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();
               
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}

function resetControl() {
    $("#SelectCompany").prop("disabled", false);
    addedLevel = [];
    $("#SelectLevel").val("0");
    $("#SelectRole").val("0");
    $("#lstCostCenter").empty();
    $("#ulAssignedList").empty();
    bindLevelData();
}