﻿var appUrl = '';
var cartFiles = [];
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    function selectPicker2() {
        $(".selectPicker2").select2();
    }
    selectPicker2();
    $("#selCostCentre").prop("disabled", true);
    $("#inlineRadio2").click(function () {
        $("#selCostCentre").prop("disabled", false);
    });
    $("#inlineRadio1").click(function () {

        $.ajax({
            type: 'POST',
            url: appUrl + 'PurchaseRequistion/GetSelfCostCenter',
            data: {

            },
            success: function (data, textstatus) {

                if (data != '') {
                    $("#selCostCentre").val(data).trigger('change');
                }

                $("#loading").hide();
                $("#selCostCentre").prop("disabled", true);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    });
    $("#selEmployee").change(function () {
        if ($("#selEmployee").val() != "0") {
            getOtherCostCenter();
        }
        else {
            $("#selCostCentre").val(0);
        }
    });
    setTimeout(function () {
        //$('.loader-wrapper').show();
        $.ajax({
            type: 'POST',
            url: appUrl + 'PurchaseRequistion/CheckCart',
            data: {

            },
            success: function (data, textstatus) {
                if (data != '') {

                    $("#selOnBehalfOf").val(data.onBehalfOfFlag);

                    $("#selOnBehalfOf").prop("disabled", true);

                    $("#txtSearchEmployee").prop("disabled", true);
                    $("#hrSearchUser").hide();

                    if (data.onBehalfOfFlag == "yesOnBehalfOf") {

                        $(".hideDiv").show();

                        $("#selEmployee").append($("<option />").val(data.employeeCode).text(data.creatorName));
                        $("#selEmployee").val(data.employeeCode);
                        $("#selEmployee").prop("disabled", true);


                    }
                    else {
                        $(".hideDiv").hide();
                    }

                    if (data.costCenterFlag == "SC") {
                        $("#inlineRadio1").prop("checked", true);
                        $("#inlineRadio2").prop("checked", false);
                    }
                    else if (data.costCenterFlag == "OT") {
                        $("#inlineRadio1").prop("checked", false);
                        $("#inlineRadio2").prop("checked", true);
                        $("#selCostCentre").val(data.costCenterCode).trigger('change');   
                    }
                    $("#selPurchaseType").val(data.purchaseTypeCode);
                    $("#selPurchaseType").prop("disabled", true);
                    $("#selPurchaseGroup").prop("disabled", true);
                    $("#selOnBehalfOf").prop("disabled", true);
                    $("#selPlantCode").prop("disabled", true);
                    $("#selCurrency").prop("disabled", true);
                    //$("#selVendor").prop("disabled", true);
                    $("#selPurchaseOrganisation").prop("disabled", true);
                    $("#selCostCentre").prop("disabled", true);
                   
                    $('.loader-wrapper').hide();

                }
                else {
                    //getRights();
                    
                    $("#selPurchaseGroup").focus();
                    $("#selPurchaseType").val(1);
                    //$("#selPurchaseType").prop("disabled", true);
                    $("#selOnBehalfOf").change(function () {

                        if ($("#selOnBehalfOf").val() == "yesOnBehalfOf") {
                            $("#selCostCentre").prop("disabled", false);
                            $("#inlineRadio1").prop("disabled", true);
                            $("#inlineRadio2").prop("checked", true);
                        }
                        else {
                            $("#selEmployee").html("");
                            $("#selEmployee").append($("<option />").val("0").text("Select"));
                            $("#selCostCentre").prop("disabled", true);
                            $("#inlineRadio1").prop("disabled", false);
                            $("#inlineRadio1").prop("checked", true);
                            $.ajax({
                                type: 'POST',
                                url: appUrl + 'PurchaseRequistion/GetSelfCostCenter',
                                data: {

                                },
                                success: function (data, textstatus) {

                                    if (data != '') {
                                        $("#selCostCentre").val(data).trigger('change');
                                    }

                                    $("#loading").hide();
                                    $("#selCostCentre").prop("disabled", true);
                                },
                                error: function (XMLHttpRequest, textStatus, errorThrown) {
                                    $('.loader-wrapper').hide();
                                }
                            });
                        }
                        //alert($('option:selected', this).text());
                    });
                    $("#loading").hide();
                }

                $("#loading").hide();
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
    }, 0);

    $('.loader-wrapper').hide();
});
function getOtherCostCenter() {
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetOtherCostCenter',
        data: {
            "EntityName": "CCBYEID", "SearchParameter1": $("#selEmployee").val()
        },
        success: function (data, textstatus) {
            if (data != '') {
                $("#selCostCentre").val(data).trigger('change');
            }

            $('.loader-wrapper').hide();
            //$("#selCostCentre").prop("disabled", true);
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function searchUser() {
    var searchString = $("#txtSearchEmployee").val();
    if (searchString == '') {
        alert("Please enter search text!");
        return false;

    }
    else if (searchString.length < 2) {
        alert("Please provide at least three characters to search!");
        return false;

    }
    $('.loader-wrapper').show();

    $("#selEmployee").empty();
    $("#selEmployee").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "SearchUser", "SearchParameter1": searchString
        },
        success: function (data, textstatus) {
            if (data.responseCode == 1) {

                $.each(data.masterDataResponses, function () {
                    $("#selEmployee").append($("<option />").val(this.valueField).text(this.displayField));
                });
            }

            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });


}
function addToCart() {
    var fileUpload = $("#formFileMultiple").get(0);
    var files = fileUpload.files;

    // first validate 
    var selPurchaseType = $("#selPurchaseType").val();
    if (selPurchaseType == 0) {
        alert("Please select Purchase Type");
        $("#selPurchaseType").focus();
        return false;
    }

    var selPurchaseGroup = $("#selPurchaseGroup").val();
    if (selPurchaseGroup == 0) {
        alert("Please select Purchase Group");
        $("#selPurchaseGroup").focus();
        return false;
    }

    var selOnBehalfOf = $("#selOnBehalfOf").val();
    if (selOnBehalfOf == 0) {
        alert("Please select On Behalf Of");
        $("#selOnBehalfOf").focus();
        return false;
    }
    else if (selOnBehalfOf == "yesOnBehalfOf") {
        var selEmployee = $("#selEmployee").val();
        if (selEmployee == 0) {
            alert("Please select Employee");
            $("#selEmployee").focus();
            return false;
        }
    }

    var selMaterial = $("#selMaterial").val();
    if (selMaterial == 0) {
        alert("Please select Material");
        $("#selMaterial").focus();
        return false;
    }
    var selCurrency = $("#selCurrency").val();
    if (selCurrency == 0) {
        alert("Please select Currency");
        $("#selCurrency").focus();
        return false;
    }
    var selCostCentre = $("#selCostCentre").val();
    if (selCostCentre == 0) {
        alert("Please select Cost Center");
        $("#selCostCentre").focus();
        return false;
    }
    var budgetType = $("#ddlBudgetType").val();
    if (budgetType == "") {
        alert("Please select budget!");
        $("#ddlBudgetType").focus();
        return false;
    }
    var productType = $("#txtProductType").val();
    if (productType == "") {
        alert("Please enter short text!");
        $("#txtProductType").focus();
        return false;
    }
    else if (productType.length > 40) {
        alert("Short Text cannot exceed 40 characters!");
        $("#txtProductType").focus();
        return false;
    }
    var productAmount = $("#txtAmount").val();
    if (productAmount == "" || productAmount == 0) {
        alert("Product amount required!");
        $("#txtAmount").focus();
        return false;
    }
    var selQuantity = $("#txtQuantity").val();
    if (selQuantity == 0 || selQuantity == "") {
        alert("Please enter Quantity!");
        $("#txtQuantity").focus();
        return false;
    }
   
    var selPlantCode = $("#selPlantCode").val();
    if (selPlantCode == 0) {
        alert("Please select Plant Code!");
        $("#selPlantCode").focus();
        return false;
    }
    var selPurchaseOrganisation = $("#selPurchaseOrganisation").val();
    if (selPurchaseOrganisation == 0) {
        alert("Please select Purchase Organisation!");
        $("#selPurchaseOrganisation").focus();
        return false;
    }
    var costcenterflag;
    if ($("#inlineRadio1").prop("checked")) {
        costcenterflag = 'SC';
    }
    else {
        costcenterflag = 'OT';
    }


    if ($("#txtComments").val() == "") {
        alert("Comments required!");
        $("#txtComments").focus();
        return false;
    }
    else if ($("#txtComments").length > 5000) {
        alert("Line comments cannot exceed 5000 characters!");
        $("#txtComments").focus();
        return false;
    }



    if (files.length > 0) {

        for (var i = 0; i < files.length; i++) {

            var fileext = files[i].name.substr((files[i].name.lastIndexOf('.') + 1));

            if ($.inArray(fileext, ['gif', 'png', 'jpg', 'jpeg', 'pdf', 'eml', 'msg', 'xls', 'xlsx','PNG','doc','docx']) == -1) {
                alert('Only (gif,png,jpg,jpeg,pdf,eml,xls,xlsx,doc,docx) are allowed!');
                return false;
            }


        }

        var allowedSize = 0;


        for (var i = 0; i < files.length; i++) {
            const fsize = files.item(i).size;
            const file = Math.round((fsize / 1024));
            allowedSize = allowedSize + file;
            // The size of the file.

        }

        if (allowedSize > 10240) {
            alert("File too Big, please select  files equal to 10 mb");


            return false;
        }

    }

    saveCartDetails(costcenterflag);

}
function saveCartDetails(costcenterflag) {
   
    var emcode = '';
    var emName = '';
    if ($("#selOnBehalfOf").val() == "yesOnBehalfOf") {
        emcode = $("#selEmployee").val();
        emName = $("#selEmployee option:selected").text();
    }
    else {
        emcode = '';
        emName = '';
    }
    $('.loader-wrapper').show();
    var shoppingDetails = [];
    var detailObject = {
        "MaterialCode": $("#hdmtCode").val(),
        "MaterialDescription": $("#txtFullDescription").val(),
        "GLCode": "",
        "ProductType": $("#txtProductType").val(),
        "MaterialAmount": $("#txtAmount").val(),
        "MaterialQuantity": $("#txtQuantity").val(),
        "NeededByDate": $("#txtNeededByDate").val(),
        "Comments": $("#txtComments").val(),
        "CatalogueDataID": $("#hdctID").val(),
    };
    shoppingDetails.push(detailObject);
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/AddToCartCatalogue',
        data: {
            "PurchaseTypeCode": $("#selPurchaseType").val(), "PurchaseType": $("#selPurchaseType option:selected").text(),
            "PurchaseGroup": $("#selPurchaseGroup").val(), "PurchaseGroupText": $("#selPurchaseGroup option:selected").text(), "Currency": $("#hdCurrency").val(),
            "CostCenterFlag": costcenterflag, "CostCenterCode": $("#selCostCentre").val(), "CostCenter": $("#selCostCentre option:selected").text(),
            "PlantCode": $("#selPlantCode").val(), "PlantName": $("#selPlantCode option:selected").text(),
            "PurchaseOrganisationCode": $("#selPurchaseOrganisation").val(), "PurchaseOrganisation": $("#selPurchaseOrganisation option:selected").text(),
            "VendorCode": $("#hdvdCode").val(), "Vendor": $("#txtVendor").val(),
            "OnBehalfOfFlag": $("#selOnBehalfOf").val(),
            "EmployeeCode": emcode,
            "shoppingCartDetails": shoppingDetails,
            "CreatorName": emName,
            "HeaderShortText": $("#txtHeaderShortText").val(),
            "CartType": "Catalogue",
            "BudgetMode": $("#ddlBudgetType").val()


        },
        success: function (data, textstatus) {

            if (data.responseCode == 1) {
                var fileUpload = $("#formFileMultiple").get(0);
                var files = fileUpload.files;
                if (files.length > 0) {
                    uploadFiles(data.responseReturnNo);
                }
                else {
                    location.href = appUrl + "Cart/Index";
                }


            }
            else if (data.responseCode == 2) {
                location.href = appUrl + "Auth/Index";

            }
            else {
                $('.loader-wrapper').hide();
                alert(data.responseMessage);

            }

            //UploadFile();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert("There is some issue. Please try again.");
            $('.loader-wrapper').hide();
        }
    });
}
function uploadFiles(cartdetailNo) {

    var fileUpload = $("#formFileMultiple").get(0);

    var files = fileUpload.files;

    var data = new FormData();

    data.append("DetailNo", cartdetailNo);

    for (var i = 0; i < files.length; i++) {
        data.append("fileInput", files[i]);
    }
    $.ajax({

        type: "POST",

        url: appUrl + "PurchaseRequistion/Upload_File",

        contentType: false,

        processData: false,

        data: data,

        async: false,

        beforeSend: function () {

            $("#divloader").show()

        },

        success: function (data) {
            $('.loader-wrapper').hide();
            if (data.responseCode == 0) {
                alert(data.responseMessage);

            }
            else {
                location.href = appUrl + "Cart/Index";
            }


        },

        error: function () {

            alert("Error!");

        },

        complete: function () {

            $("#divloader").hide()

        }

    });
}
function bindEmployeeDropDown(selectedValue, disableflag) {
    $("#selEmployee").empty();
    $("#selEmployee").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetEmployeeList',
        data: {

        },
        success: function (pdata, textstatus) {
            if (pdata != '') {

                $.each(pdata, function () {
                    $("#selEmployee").append($("<option />").val(this.valueField).text(this.displayField));
                });
                $("#selEmployee").val(selectedValue);
                if (disableflag == true) {
                    $("#selEmployee").prop("disabled", true);
                }
            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}