﻿var appUrl = '';
var addedLevel = [];
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    $("#btnCompanyAPFlowSearch").click(function () {
        if ($("#costCompany").val() == "0") {
            alert("Please select company!");
            return false;
        }
        GetCompanyApprovalFlow();
    });

    bindCompany('', '');

    $("#txtFromAmount").keypress(function (event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) &&

            ((event.which < 48 || event.which > 57) &&

                (event.which != 0 && event.which != 8))) {

            event.preventDefault();

        }
        var text = $(this).val();
        if ((text.indexOf('.') != -1) &&

            (text.substring(text.indexOf('.')).length > 2) &&

            (event.which != 0 && event.which != 8) &&

            ($(this)[0].selectionStart >= text.length - 2)) {

            event.preventDefault();

        }
    });
    $("#txtToAmount").keypress(function (event) {
        if ((event.which != 46 || $(this).val().indexOf('.') != -1) &&

            ((event.which < 48 || event.which > 57) &&

                (event.which != 0 && event.which != 8))) {

            event.preventDefault();

        }
        var text = $(this).val();
        if ((text.indexOf('.') != -1) &&

            (text.substring(text.indexOf('.')).length > 2) &&

            (event.which != 0 && event.which != 8) &&

            ($(this)[0].selectionStart >= text.length - 2)) {

            event.preventDefault();

        }
    });
    $("#selAppType").change(function () {

        if ($("#selAppType").val() == "0") {
            $("#divsRole").hide();
            $("#divsEMP").hide();
            $("#SelectRole").val("0");
            $("#txtEmployee").val("");
        }
        else if ($("#selAppType").val() == "Individual") {
            $("#divsRole").hide();
            $("#divsEMP").show();
            $("#SelectRole").val("0");
            $("#txtEmployee").val("");
        }
        else if ($("#selAppType").val() == "Role") {
            $("#divsRole").show();
            $("#divsEMP").hide();
            $("#SelectRole").val("0");
            $("#txtEmployee").val("");
        }
    });
    $("#selAmountApplicable").change(function () {

        if ($("#selAmountApplicable").val() == "0") {
            $("#divCalculationType").hide();
            $("#divFromAmount").hide();
            $("#divToAmount").hide();
            $("#selCalculationType").val("0");
            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
        else if ($("#selAmountApplicable").val() == "1") {
            $("#divCalculationType").show();
        }

    });
    $("#selCalculationType").change(function () {

        if ($("#selCalculationType").val() == "0") {

            $("#divFromAmount").hide();
            $("#divToAmount").hide();

            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
        else if ($("#selCalculationType").val() == "Greater") {
            $("#divFromAmount").show();
            $("#divToAmount").hide();
            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
        else if ($("#selCalculationType").val() == "Less") {
            $("#divFromAmount").show();
            $("#divToAmount").hide();
            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
        else if ($("#selCalculationType").val() == "Between") {
            $("#divFromAmount").show();
            $("#divToAmount").show();
            $("#txtFromAmount").val("");
            $("#txtToAmount").val("");
        }
    });

    $("#ddlPopUpCompany").change(function () {
        GetCompanyApprovalFlowPopUpData();

    });

});
function GetCompanyApprovalFlow() {

    $('.loader-wrapper').show();

    $("#approvalConfigBody").empty();

    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Admin/ManageCompanyApprovalFlow", // Controller/View
            data: { "Action": "GET", "CompanyCode": $("#costCompany").val() },
            success: function (result) {

                if (result.responseCode == 1) {
                    var responseData = JSON.parse(result.responseJSON);
                    if (responseData.length > 0) {
                        $.each(responseData, function (i, item) {
                            var apptype = '';
                            var amountapplicable = '';
                            var amountsymbol = '';
                            var fromAmount = '';
                            var ToAmount = '';
                            if (item.AmountApplicableFlag == 0) {
                                amountapplicable = 'NO';
                            }
                            else if (item.AmountApplicableFlag == 1) {
                                amountapplicable = 'YES';
                                amountsymbol = item.CalculateSymbol;
                                fromAmount = item.FromAmount;
                                ToAmount = item.ToAmount;
                            }
                            if (item.AppType == 'Role') {
                                apptype = item.RoleName
                            }
                            else if (item.AppType == 'Individual') {
                                apptype = item.EMPCode
                            }
                            var $tr = $('<tr>').append(
                                $('<td>').text(i + 1),
                                $('<td>').text(item.AppLevel),
                                $('<td>').text(item.PurchaseType),
                                $('<td>').text(item.PGCategory),
                                $('<td>').text(item.AppType),
                                $('<td>').text(apptype),
                                $('<td>').text(amountapplicable),
                                $('<td>').text(amountsymbol),
                                $('<td>').text(fromAmount),
                                $('<td>').text(ToAmount),
                                // $('<td >').html('')
                                //  $('<td >').html('&nbsp; <a href="#" onclick=removeLevel(' + item.AppHierarchyID + ',' + item.AppLevel + ')> <i class="fa-solid fa-trash-can"></i></a>'),
                            );
                            $("#approvalConfigBody").append($tr);
                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="10">').text('No records to display'));
                        $("#approvalConfigBody").append($tr);
                    }


                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="10">').text('No records to display'));
                    $("#approvalConfigBody").append($tr);
                }

                $('.loader-wrapper').hide();



            }

        });

}
function openApprovalPopup() {
    $("#mdAddCompanyAppFlow").modal('show');
    bindCompanypopup();
    bindPurchaseType();
    bindPurchaseCategory();
    GetRoleMasterDDLData();
    resetControl();
    
}
function bindCompany(selectedValue, selectedtext) {
    $("#costCompany").empty();
    $("#costCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "GET",
            url: "GetCompanyMaster",
            dataType: "JSON",
            data: null,
            success: function (data) {
                if (data.recordCount > 0) {
                    $.each(data.costCenter, function (i, item) {
                        $("#costCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }
                if (selectedtext != '') {
                    /*$("#costCompany option:selected").val(selectedValue).text(selectedtext);*/
                    $("#costCompany").val(selectedValue);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }

        }
    );
}
function bindCompanypopup() {
    $("#ddlPopUpCompany").empty();
    $("#ddlPopUpCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "GET",
            url: "GetCompanyMaster",
            dataType: "JSON",
            data: null,
            success: function (data) {
                if (data.recordCount > 0) {
                    $.each(data.costCenter, function (i, item) {
                        $("#ddlPopUpCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }
                
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }

        }
    );
}
function resetControl() {
    $("#divsRole").hide();
    $("#divsEMP").hide();
    $("#divCalculationType").hide();
    $("#divFromAmount").hide();
    $("#divToAmount").hide();
    $("#txtFromAmount").val("");
    $("#txtToAmount").val("");
    $("#SelectRole").val("0");
    $("#txtEmployee").val("");
    $("#selAppType").val("0")
    $("#selAmountApplicable").val("0");
    $("#selCalculationType").val("0");
    //addedLevel = [];
}
function bindPurchaseType() {
    $("#selPurchaseType").empty();
    $("#selPurchaseType").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PurchaseType", "SearchParameter1": ''
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selPurchaseType").append($("<option />").val(this.valueField).text(this.displayField));

                });
            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function bindPurchaseCategory() {
    $("#selPurchaseGroup").empty();
    $("#selPurchaseGroup").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "PurchaseCategory", "SearchParameter1": ''
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selPurchaseGroup").append($("<option />").val(this.valueField).text(this.displayField));

                });
            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function GetRoleMasterDDLData() {
    $('.loader-wrapper').show();
    $("#SelectRole").empty();
    $("#SelectRole").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + "PurchaseRequistion/GetMasterData",
            dataType: "JSON",
            data: {
                "EntityName": "RoleMasterAPPHierarchy"
            },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#SelectRole").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }

                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        }
    );
}
function addLevel() {
    /************ VALIDATION *************/
    var appLevel = $("#SelectLevel").val();
    if ($("#SelectLevel").val() == "0") {
        alert("Please select Level!");
        return false;
    }
    if ($("#selAppType").val() == "0") {
        alert("Please select app type!");
        return false;
    }

    if ($("#selAppType").val() == "Individual") {
        if ($("#txtEmployee").val() == "") {
            alert("Please enter employee code!");
            return false;
        }
    }
    else if ($("#selAppType").val() == "Role") {
        var roleSelected = $("#SelectRole").val();
        if (roleSelected == "0") {
            alert("Please select Role!");
            return false;
        }
    }
    if ($("#selAmountApplicable").val() == "1") {
        if ($("#selCalculationType").val() == "0") {
            alert("Please select calculation type!");
            return false;
        }
        else if ($("#selCalculationType").val() == "Greater") {
            if ($("#txtFromAmount").val() == "") {
                alert("Please enter from amount!");
                return false;
            }
            else if ($("#txtFromAmount").val() == "0" || parseFloat($("#txtFromAmount").val()) < 0) {
                alert("From Amount cannot be zero or less than zero!");
                return false;
            }
        }
        else if ($("#selCalculationType").val() == "Less") {
            if ($("#txtFromAmount").val() == "") {
                alert("Please enter from amount!");
                return false;
            }
            else if ($("#txtFromAmount").val() == "0" || parseFloat($("#txtFromAmount").val()) < 0) {
                alert("From Amount cannot be zero or less than zero!");
                return false;
            }
        }
        else if ($("#selCalculationType").val() == "Between") {
            if ($("#txtFromAmount").val() == "") {
                alert("Please enter from amount!");
                return false;
            }
            else if ($("#txtFromAmount").val() == "0" || parseFloat($("#txtFromAmount").val()) < 0) {
                alert("From Amount cannot be zero or less than zero!");
                return false;
            }
            if ($("#txtToAmount").val() == "") {
                alert("Please enter to amount!");
                return false;
            }
            else if ($("#txtToAmount").val() == "0" || parseFloat($("#txtToAmount").val()) < 0) {
                alert("To Amount cannot be zero or less than zero!");
                return false;
            }
        }
    }

    addedLevel.push({
                "Level": appLevel,
                "RoleCode": roleSelected,
                "RoleName": $("#SelectRole option:selected").text(),
                "EMPCode": $("#txtEmployee").val(),
                "AppType": $("#selAppType").val(),
                "PurchaseTypeID": $("#selPurchaseType").val(),
                "PurchaseType": $("#selPurchaseType option:selected").val(),
                "PGCategoryCode": $("#selPurchaseGroup").val(),
                "AmountApplicableFlag": $("#selAmountApplicable").val(),
                "CalculateSymbol": $("#selCalculationType").val(),
                "FromAmount": $("#txtFromAmount").val(),
                "ToAmount": $("#txtToAmount").val(),
            });

    var confirmText = 'Do you want to save details?';

    if (confirm(confirmText)) {
        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "Admin/ManageCompanyApprovalFlow", // Controller/View
                data: {
                    "CompanyCode": $("#ddlPopUpCompany").val(), "approvalConfigRequests": addedLevel, "Action": 'ADD'
                },
                success: function (result) {

                    if (result.responseCode == 1) {

                        alert(result.responseMessage);

                        addedLevel = [];

                        resetControl();


                    }
                    else if (result.responseCode == 0) {
                        alert(result.responseMessage);
                    }
                    else if (result.responseCode == 2) {
                        location.href = appUrl + "Auth/Index";
                    }

                    $('.loader-wrapper').hide();



                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $('.loader-wrapper').hide();
                }

            });


    }


    //if (addedLevel.length > 0) {
    //    var validate = true;
    //    var LastLevel = 0;

    //    $.each(addedLevel, function (i, item) {
    //        //&& item.RoleCode == roleSelected
    //        //if (item.Level == appLevel ) {
    //        //    alert("Combintion already added!");
    //        //    validate = false;
    //        //}

    //        //if (item.RoleCode == roleSelected) {
    //        //    alert("This roleCode already added in level data!");
    //        //    validate = false;
    //        //}

    //        LastLevel = item.Level;

    //    });



    //    if (parseInt(LastLevel) > 0) {
    //        if (parseInt(appLevel) - parseInt(LastLevel) > 1) {
    //            alert("Please add level data in sequence!");
    //            validate = false;
    //        }
    //    }



    //    if (validate) {
    //        addedLevel.push({
    //            "Level": appLevel,
    //            "RoleCode": roleSelected,
    //            "RoleName": $("#SelectRole option:selected").text(),
    //            "EMPCode": $("#txtEmployee").val(),
    //            "AppType": $("#selAppType").val(),
    //            "PurchaseTypeID": $("#selPurchaseType").val(),
    //            "PurchaseType": $("#selPurchaseType option:selected").val(),
    //            "PGCategoryCode": $("#selPurchaseGroup").val(),
    //            "AmountApplicableFlag": $("#selAmountApplicable").val(),
    //            "CalculateSymbol": $("#selCalculationType").val(),
    //            "FromAmount": $("#txtFromAmount").val(),
    //            "ToAmount": $("#txtToAmount").val(),
    //        });
    //      //  bindLevelData();
    //        $('#mdAddLevel').modal('hide');
    //    }

    //}
    //else {
    //    if (appLevel > 2) {
    //        alert("Please add level data in sequence!");
    //        return false;
    //    }
    //    addedLevel.push({
    //        "Level": appLevel,
    //        "RoleCode": roleSelected,
    //        "RoleName": $("#SelectRole option:selected").text(),
    //        "EMPCode": $("#txtEmployee").val(),
    //        "AppType": $("#selAppType").val(),
    //        "PurchaseTypeID": $("#selPurchaseType").val(),
    //        "PurchaseType": $("#selPurchaseType option:selected").val(),
    //        "PGCategoryCode": $("#selPurchaseGroup").val(),
    //        "AmountApplicableFlag": $("#selAmountApplicable").val(),
    //        "CalculateSymbol": $("#selCalculationType").val(),
    //        "FromAmount": $("#txtFromAmount").val(),
    //        "ToAmount": $("#txtToAmount").val(),
    //    });
    //         //bindLevelData();
    //    //$('#mdAddLevel').modal('hide');
    //}

    //$('#mdAddLevel').modal('hide');
}
function GetCompanyApprovalFlowPopUpData() {

    $('.loader-wrapper').show();

    $("#tbLevel").empty();

    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Admin/ManageCompanyApprovalFlow", // Controller/View
            data: { "Action": "GET", "CompanyCode": $("#ddlPopUpCompany").val() },
            success: function (result) {

                if (result.responseCode == 1) {
                    var responseData = JSON.parse(result.responseJSON);
                    if (responseData.length > 0) {
                        $.each(responseData, function (i, item) {
                            var apptype = '';
                            var amountapplicable = '';
                            var amountsymbol = '';
                            var fromAmount = '';
                            var ToAmount = '';
                            if (item.AmountApplicableFlag == 0) {
                                amountapplicable = 'NO';
                            }
                            else if (item.AmountApplicableFlag == 1) {
                                amountapplicable = 'YES';
                                amountsymbol = item.CalculateSymbol;
                                fromAmount = item.FromAmount;
                                ToAmount = item.ToAmount;
                            }
                            if (item.AppType == 'Role') {
                                apptype = item.RoleName
                            }
                            else if (item.AppType == 'Individual') {
                                apptype = item.EMPCode
                            }
                            
                            var $tr = $('<tr>').append(
                                $('<td>').text(i + 1),
                                $('<td>').text(item.AppLevel),
                                $('<td>').text(item.PurchaseType),
                                $('<td>').text(item.PGCategory),
                                $('<td>').text(item.AppType),
                                $('<td>').text(apptype),
                                $('<td>').text(amountapplicable),
                                $('<td>').text(amountsymbol),
                                $('<td>').text(fromAmount),
                                $('<td>').text(ToAmount),
                                $('<td>').html('<a href="javascript:;" class="mr-2" onclick="DeleteApprovalFlow(' + item.PrimaryID + ')"><i class="fas fa-trash-alt text-danger"></i></a>')
                                // $('<td >').html('')
                                //  $('<td >').html('&nbsp; <a href="#" onclick=removeLevel(' + item.AppHierarchyID + ',' + item.AppLevel + ')> <i class="fa-solid fa-trash-can"></i></a>'),
                            );
                            $("#tbLevel").append($tr);
                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="10">').text('No records to display'));
                        $("#tbLevel").append($tr);
                    }


                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="10">').text('No records to display'));
                    $("#tbLevel").append($tr);
                }

                $('.loader-wrapper').hide();



            }

        });

}


function DeleteApprovalFlow(PrimaryId) {
    var isDelete = window.confirm('Are you sure you want to delete this Mapping ?');
    if (isDelete) {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/DeleteApprovalFlow',
            data: {
                "PrimaryId": PrimaryId
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert(pdata.responseMessage);
                   // GetMenuUserMapping(1, 20);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }
    }


