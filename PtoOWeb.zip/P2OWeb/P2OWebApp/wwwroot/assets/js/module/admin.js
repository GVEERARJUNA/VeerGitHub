﻿var appUrl = '';
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
    if (pageURL.indexOf('/Admin/CostCenter') != -1) {

        //GetCostCenterPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/PurchaseType') != -1) {

        GetPurchaseTypePageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/PurchaseGroup') != -1) {

        GetPurchaseGroupPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/CompanyMaster') != -1) {

        GetCompanyMasterPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/CurrencyMaster') != -1) {

        GetCurrencyMasterPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/PlantCode') != -1) {

        GetPlantCodePageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/Vendor') != -1) {

        //GetVendorPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/GLMaster') != -1) {

        GetGLPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/Material') != -1) {

        GetMaterialPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/ServiceMaterial') != -1) {

        GetServiceMaterialPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/PurchaseOrganisation') != -1) {

        GetPurchaseOrganisationPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/StatusMaster') != -1) {

        GetStatusPageData(1, 20);

    }
    else if (pageURL.indexOf('/Admin/ApplicationConfig') != -1) {

        GetApplicationConfig();
    }
    else if (pageURL.indexOf('/Admin/MenuMaster') != -1) {

        GetMenuMaster(1, 20);
    }
    else if (pageURL.indexOf('/Admin/MenuUserMapping') != -1) {

        bindUserTypeSearchDropDown($("#userTypeSearch").val());
        GetMenuUserMapping(1, 20);
    }
    else if (pageURL.indexOf('/Admin/Index') != -1) {

        
    }
    else if (pageURL.indexOf('/Admin/CompanyApprovalFlow') != -1) {

        GetCostCenterCompanyMaster('','');
    }
    
});
$("#btnCompanyAPFlowSearch").click(function () {
    if ($("#costCompany").val() == "0") {
        alert("Please select company!");
        return false;
    }
    GetCompanyApprovalFlow();
})
function GetCompanyApprovalFlow() {

    $('.loader-wrapper').show();

    $("#approvalConfigBody").empty();

    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Admin/ManageCompanyApprovalFlow", // Controller/View
            data: { "Action": "GET", "CompanyCode": $("#costCompany").val() },
            success: function (result) {

                if (result.responseCode == 1) {
                    var responseData = JSON.parse(result.responseJSON);
                    if (responseData.length>0) {
                        $.each(responseData, function (i, item) {
                            var apptype = '';
                            var amountapplicable = '';
                            var amountsymbol = '';
                            var fromAmount = '';
                            var ToAmount = '';
                            if (item.AmountApplicableFlag == 0) {
                                amountapplicable = 'NO';
                            }
                            else if (item.AmountApplicableFlag == 1) {
                                amountapplicable = 'YES';
                                amountsymbol = item.CalculateSymbol;
                                fromAmount = item.FromAmount;
                                ToAmount = item.ToAmount;
                            }
                            if (item.AppType == 'Role') {
                                apptype = item.RoleName
                            }
                            else if (item.AppType == 'Individual') {
                                apptype = item.EMPCode
                            }
                            var $tr = $('<tr>').append(
                                $('<td>').text(i + 1),
                                $('<td>').text(item.AppLevel),
                                $('<td>').text(item.PurchaseType),
                                $('<td>').text(item.PGCategory),
                                $('<td>').text(item.AppType),
                                $('<td>').text(apptype),
                                $('<td>').text(amountapplicable),
                                $('<td>').text(amountsymbol),
                                $('<td>').text(fromAmount),
                                $('<td>').text(ToAmount),
                                // $('<td >').html('')
                              //  $('<td >').html('&nbsp; <a href="#" onclick=removeLevel(' + item.AppHierarchyID + ',' + item.AppLevel + ')> <i class="fa-solid fa-trash-can"></i></a>'),
                            );
                            $("#approvalConfigBody").append($tr);
                        });
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="10">').text('No records to display'));
                        $("#approvalConfigBody").append($tr);
                    }


                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="10">').text('No records to display'));
                    $("#approvalConfigBody").append($tr);
                }

                $('.loader-wrapper').hide();



            }

        });

}

function GetApplicationConfig() {

   
    $('.loader-wrapper').show();

    $("#cmApplicationConfig").empty();

    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Admin/ApplicationConfigSetting", // Controller/View
            data: {"Action":"GET"},
            success: function (result) {

                if (result.responseCode == 1) {
                    var responseData = JSON.parse(result.responseJSON);
                    $.each(responseData, function (i, item) {
                        var PName = "'" + item.PropertyName + "'";
                        var PValue = "'" + item.PropertyValue + "'";
                        var Remarks = "'" + item.Remarks + "'";
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(i + 1),
                            $('<td>').text(item.PropertyName),
                            $('<td>').text(item.PropertyValue),
                            $('<td>').text(item.Remarks),
                            $('<td>').html('<a href="#" title="Edit" onclick="editApplicationConfigDetails(' + item.ApplicationConfigID + ',' + PName + ',' + PValue + ',' + Remarks +')"> <i class="fa-solid fa-pen-to-square"></i></a>'),
                        );
                        $("#cmApplicationConfig").append($tr);
                    });

                    
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('No records to display'));
                    $("#cmApplicationConfig").append($tr);
                }

                $('.loader-wrapper').hide();



            }

        });

}

function editApplicationConfigDetails(editID, propertyName, propertyValue,remarks) {
    $('.loader-wrapper').show();
    $("#modalApplicationSetting").modal('show');
    $("#txtPropertyName").val(propertyName);
    $("#txtPropertyValue").val(propertyValue);
    $("#txtRemarks").val(remarks);
    $("#hdEditApplicationConfig").val(editID);
    $('.loader-wrapper').hide();
}

function addApplicationConfigDetails() {
    $('.loader-wrapper').show();
    $("#modalApplicationSetting").modal('show');
    $("#txtPropertyName").val("");
    $("#txtPropertyValue").val("");
    $("#txtRemarks").val("");
    $("#hdEditApplicationConfig").val("0");
    $('.loader-wrapper').hide();
}

function takeAction() {

    var Action = '';
    if ($("#hdEditApplicationConfig").val()>"0") {
        Action = 'EDIT';
    }
    else if ($("#hdEditApplicationConfig").val()=="0") {
        Action = 'ADD';
    }

    if ($("#txtPropertyName").val()=='') {
        alert("Property Name required!");
        $("#txtPropertyName").focus();
        return false;
    }
    else if ($("#txtPropertyName").val().length > 200) {
        alert("Property Name cannot exceed 200 characters!");
        $("#txtPropertyName").focus();
        return false;
    }
    if ($("#txtPropertyValue").val() == '') {
        alert("Property Value required!");
        return false;
    }
    else if ($("#txtPropertyValue").val().length > 200) {
        alert("Property Value cannot exceed 200 characters!");
        $("#txtPropertyValue").focus();
        return false;
    }

    var confirmText = 'Do you want to ' + Action + ' details?';

    if (confirm(confirmText)) {

        $('.loader-wrapper').show();

        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "Admin/ApplicationConfigSetting", // Controller/View
                data: {
                    "Action": Action, "ApplicationConfigID": $("#hdEditApplicationConfig").val(),
                    "PropertyName": $("#txtPropertyName").val(),
                    "PropertyValue": $("#txtPropertyValue").val(),
                    "Remarks": $("#txtRemarks").val()
                },
                success: function (result) {

                    if (result.responseCode == 1) {

                        alert(result.responseMessage);

                        $("#modalApplicationSetting").modal('hide');

                        GetApplicationConfig();
                    }
                    else {
                        alert(result.responseMessage);
                    }

                    $('.loader-wrapper').hide();
                    


                }

            });

    }

}

$("#costCompany").click(function () {
    GetCostCenterCompanyMaster($("#costCompany option:selected").val(), $("#costCompany option:selected").text());
})

function GetCostCenterCompanyMaster(selectedValue, selectedtext) {
    $("#costCompany").empty();
    $("#costCompany").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "GET",
            url: "GetCompanyMaster",
            dataType: "JSON",
            data: null,
            success: function (data) {
                if (data.recordCount > 0) {
                    $.each(data.costCenter, function (i, item) {
                        $("#costCompany").append($("<option />").val(item.valueField).text(item.displayField));
                    });
                }
                if (selectedtext != '') {
                    /*$("#costCompany option:selected").val(selectedValue).text(selectedtext);*/
                    $("#costCompany").val(selectedValue);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
            
        }
    );
}

function GetCostCenterMaster(searchCostString) {
    $('.loader-wrapper').show();
    $.ajax(
        {
            type: 'POST',
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            data: {
                "EntityName": "CostCenterSearch", "SearchParameter1": searchCostString
            },
            success: function (data) {
                if (data.responseCode == "1") {
                    var list = "";
                    var _result = JSON.parse(data.responseJSON);
                    $.each(_result, function (i, item) {
                        list += "<li>" + item.DisplayField + "(" + item.ValueField + ")" +"</li>";
                       
                    });
                    $("#costCenter").append(list);
                }
                $('.loader-wrapper').hide();
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        }
    );
}

$("#btnCostSearch").click(function () {
    if ($("#costCompany").val() == "0") {
        alert("Please select company!");
        return false;
    }
    GetCostCenterPageData(1, 20);
})

$("#btnCurrencySearch").click(function () {
    GetCurrencyMasterPageData(1, 20);
})

$("#btnGLSearch").click(function () {

    if ($("#costCompany").val()=="0") {
        alert("Please select company!");
        return false;
    }
    GetGLPageData(1, 20);
})

$("#btnMaterialSearch").click(function () {
    GetMaterialPageData(1, 20);
})

$("#btnServiceMaterialSearch").click(function () {
    GetServiceMaterialPageData(1, 20);
})

$("#btnPlantCodeSearch").click(function () {
    if ($("#costCompany").val() == "0") {
        alert("Please select company!");
        return false;
    }
    GetPlantCodePageData(1, 20);
})

$("#btnPurchaseGroupSearch").click(function () {
    GetPurchaseGroupPageData(1, 20);
})

$("#btnPurchaseOrganisationSearch").click(function () {
    if ($("#costCompany").val() == "0") {
        alert("Please select company!");
        return false;
    }
    GetPurchaseOrganisationPageData(1, 20);
})

$("#btnPurchaseTypeSearch").click(function () {
    GetPurchaseTypePageData(1, 20);
})

$("#btnStatusSearch").click(function () {
    GetStatusPageData(1, 20);
})

$("#btnVendorSearch").click(function () {
    if ($("#costCompany").val() == "0") {
        alert("Please select company!");
        return false;
    }
    GetVendorPageData(1, 20);
})

$("#btnMenuMasterSearch").click(function () {
    GetMenuMaster(1, 20);
})

$("#btnMenuMasterSearch").click(function () {
    GetMenuUserMapping(1, 20);
})



function OpenCostCenterConfig(costCenterCode, costCenterName) {
    $("#divRoles").hide();
    $("#configDetails").modal('show');
    $("#selCostCenterCode").text(costCenterCode);
    $("#selCostCenterName").text(costCenterName);

    $("#selCostEmployee").empty();
    $("#selRole").empty();
    document.getElementById('txtCostSearchEmployee').value = '';

    bindRoleDropDown($("#selRole").val());
    GetCostCenterConfig(costCenterCode);
}

/*Cost Center*/
function GetCostCenterPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#costcenterBody").empty();
    $("#pageList").empty();
    console.log($("#costCompany").val());
    if ($("#costCompany").val() == null || $("#costCompany").val() == "" || $("#costCompany").val() == "0") {
        var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('Please select company to get data'));
        $("#costcenterBody").append($tr);
    }
    else {
        $.ajax(
            {
                type: "GET", //HTTP POST Method  
                url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=CostCenter&CompanyCode=" + $("#costCompany").val() + "&CostCenterSearch=" + $("#costCenter").val(), // Controller/View
                data: null,
                success: function (result) {
                    if (result.recordCount > 0) {
                        $.each(result.costCenter, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(item.srNo),
                                $('<td>').text(item.valueField),
                                $('<td>').text(item.displayField),
                                $('<td>').html('<a href="javascript:;" class="btn btn-success btn-sm me-2" data-toggle="model" data-target="configDetails" id="costConfig' + (item.srNo) + '" onclick="OpenCostCenterConfig(' + "'" + item.valueField + "'" + ',' + "'" + item.displayField + "'" + ')"><i class="fas fa-plus"></i></a>'),
                            );
                            $("#costcenterBody").append($tr);
                        });

                        
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('No records to display'));
                        $("#costcenterBody").append($tr);
                    }
                    CostCenterPaging(result.recordCount, pageNum);
                    $('.loader-wrapper').hide();



                }

            });
    }
}

function CostCenterPaging(totalPage, currentPage) {
   
    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetCostCenterPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetCostCenterPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetCostCenterPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetCostCenterPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetCostCenterPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#pageList").append(template);
}

function searchEmployee() {
    var searchString = $("#txtCostSearchEmployee").val();
    if (searchString == '') {
        alert("Please enter search text!");
        return false;

    }
    else if (searchString.length < 2) {
        alert("Please provide at least three characters to search!");
        return false;

    }
    $('.loader-wrapper').show();

    $("#selCostEmployee").empty();
    $("#selCostEmployee").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "CostSearchUser", "SearchParameter1": searchString
        },
        success: function (data, textstatus) {
            if (data.responseCode == 1) {

                $.each(data.masterDataResponses, function () {
                    $("#selCostEmployee").append($("<option />").val(this.valueField).text(this.displayField));
                });
            }

            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });


}

function bindRoleDropDown(selectedValue) {
    $("#selRole").empty();
    $("#selRole").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "CCRoleMasterSearch"
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selRole").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selRole").val(selectedValue);
                }



            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function AddRoleDetails() {

    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/InsertCostCenterConfig',
        data: {
            "CostCenterCode": $("#selCostCenterCode").text(),
            "RoleMasterId": $("#selRole").val(),
            "RoleEmpCode":  $("#selCostEmployee").val(),
            "Action": "ADD"
        },
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                    OpenCostCenterConfig($("#selCostCenterCode").text(), $("#selCostCenterName").text());
                }
            else {
                   alert(pdata.responseMessage);
                }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });

    
}

function DeleteRoleDetails(configId, empID, costCenterCode) {
    var isDelate = window.confirm('Are you sure you want to delete this role?');

    if (isDelate) {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/DeleteCostCenterRoleConfig',
            data: {
                "CostCenterConfigID": configId, "CostCenterCode": costCenterCode, "RoleEmpCode": empID
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert(pdata.responseMessage);
                    GetCostCenterConfig(costCenterCode);
                }
                else {
                    alert(pdata.responseMessage);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }

}

function GetCostCenterConfig(costCenterCode) {

    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/GetCostCenterConfig',
        data: {
            "CostCenterCode": costCenterCode
        },
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                var _result = JSON.parse(pdata.responseJSON);
                $("#bodyroles").empty();
                if (_result != null && pdata.responseJSON != "[]") {
                    $.each(_result, function (i, item) {

                            var $tr = $('<tr>').append(
                                $('<td>').text(i + 1),
                                $('<td>').text(item.RoleMasterName),
                                $('<td>').text(item.RoleEMPCode),
                                $('<td>').html('<a href="javascript:;" class="mr-2" onclick="DeleteRoleDetails(' + item.CostCenterConfigID + ",'" + item.RoleEMPCode  + "','" + item.CostCenterCode + "'" + ')"><i class="fas fa-trash-alt text-danger"></i></a>')
                            );
                          $("#bodyroles").append($tr);

                        });

                    $("#divRoles").show();
                    }
                else {
                    $("#divRoles").hide();
                    }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}


/*Purchage Type :*/
function GetPurchaseTypePageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#purchageTypeBody").empty();
    $("#ptPageList").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=PurchaseType&CompanyCode=null&CostCenterSearch=" + $("#purchaseType").val(), // Controller/View
            data: null,
            success: function (result) {

                if (result.recordCount > 0) {
                    $.each(result.costCenter, function (i, item) {

                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.srNo),
                            $('<td>').text(item.valueField),
                            $('<td>').text(item.displayField),
                        );
                        $("#purchageTypeBody").append($tr);
                    });

                   
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    $("#purchageTypeBody").append($tr);
                }
                PurchaseTypePaging(result.recordCount, pageNum);
                $('.loader-wrapper').hide();



            }

        });

}

function PurchaseTypePaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetPurchaseTypePageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetPurchaseTypePageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetPurchaseTypePageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetPurchaseTypePageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetPurchaseTypePageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#ptPageList").append(template);
}


/*Purchage Group :*/
function GetPurchaseGroupPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#purchaseGroupBody").empty();
    $("#pgPageList").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=PurchaseGroup&CompanyCode=null&CostCenterSearch=" + $("#purchaseGroup").val(), // Controller/View
            data: null,
            success: function (result) {

                if (result.recordCount > 0) {
                    $.each(result.costCenter, function (i, item) {

                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.srNo),
                            $('<td>').text(item.valueField),
                            $('<td>').text(item.displayField),
                        );
                        $("#purchaseGroupBody").append($tr);
                    });

                    
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    $("#purchaseGroupBody").append($tr);
                }
                PurchaseGroupPaging(result.recordCount, pageNum);
                $('.loader-wrapper').hide();



            }

        });

}

function PurchaseGroupPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }
    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetPurchaseGroupPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetPurchaseGroupPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetPurchaseGroupPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetPurchaseGroupPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetPurchaseGroupPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#pgPageList").append(template);
}


/*Company Master :*/
function GetCompanyMasterPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#companyMasterBody").empty();
    $("#cmPageList").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=CompanyMaster&CompanyCode=" + $("#CompanyName").val(), // Controller/View
            data: null,
            success: function (result) {

                if (result.recordCount > 0) {
                    $.each(result.costCenter, function (i, item) {

                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.srNo),
                            $('<td>').text(item.valueField),
                            $('<td>').text(item.displayField),
                        );
                        $("#companyMasterBody").append($tr);
                    });

                    
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    $("#companyMasterBody").append($tr);
                }
                
                CompanyMasterPaging(result.recordCount, pageNum);

                $('.loader-wrapper').hide();



            }

        });

}

function CompanyMasterPaging(totalPage, currentPage) {
    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();

    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }
    if (TotalPages == 0) {
        CurrentPage = 0;
    }

    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetCompanyMasterPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetCompanyMasterPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetCompanyMasterPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetCompanyMasterPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetCompanyMasterPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';

    $("#cmPageList").append(template);
}


/*Currency Master :*/
function GetCurrencyMasterPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#currencyBody").empty();
    $("#currencyPageList").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=Currency&CompanyCode=null&CostCenterSearch=" + $("#currency").val(), // Controller/View
            data: null,
            success: function (result) {

                if (result.recordCount > 0) {
                    $.each(result.costCenter, function (i, item) {

                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.srNo),
                            $('<td>').text(item.valueField),
                            $('<td>').text(item.displayField),
                        );
                        $("#currencyBody").append($tr);
                    });

                    
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    $("#currencyBody").append($tr);
                }
                CurrencyMasterPaging(result.recordCount, pageNum);
                $('.loader-wrapper').hide();



            }

        });

}

function CurrencyMasterPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }
    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetCurrencyMasterPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetCurrencyMasterPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetCurrencyMasterPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetCurrencyMasterPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetCurrencyMasterPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#currencyPageList").append(template);
}


/*PlantCode Master :*/
function GetPlantCodePageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#plantCodeBody").empty();
    $("#pcPageList").empty();
    if ($("#costCompany").val() == null || $("#costCompany").val() == "" || $("#costCompany").val() == "0") {
        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('Please select company to get data'));
        $("#plantCodeBody").append($tr);
    }
    else {
        $.ajax(
            {
                type: "GET", //HTTP POST Method  
                url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=PlantCode&CompanyCode=" + $("#costCompany").val() + "&CostCenterSearch=" + $("#plantCode").val(), // Controller/View
                data: null,
                success: function (result) {

                    if (result.recordCount > 0) {
                        $.each(result.costCenter, function (i, item) {

                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(item.srNo),
                                $('<td>').text(item.valueField),
                                $('<td>').text(item.displayField),
                            );
                            $("#plantCodeBody").append($tr);
                        });

                        
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                        $("#plantCodeBody").append($tr);
                    }
                    PlantCodePaging(result.recordCount, pageNum);
                    $('.loader-wrapper').hide();



                }

            });
    }

}

function PlantCodePaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }
    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetPlantCodePageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetPlantCodePageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetPlantCodePageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetPlantCodePageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetPlantCodePageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#pcPageList").append(template);
}

/*Vendor Master :*/
function GetVendorPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#vendorBody").empty();
    $("#vendorPageList").empty();
    if ($("#costCompany").val() == null || $("#costCompany").val() == "" || $("#costCompany").val() == "0") {
        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('Please select company to get data'));
        $("#vendorBody").append($tr);
    }
    else {
        $.ajax(
            {
                type: "GET", //HTTP POST Method  
                url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=Vendor&CompanyCode=" + $("#costCompany").val() + "&CostCenterSearch=" + $("#vendorMaster").val(), // Controller/View
                data: null,
                success: function (result) {
                    if (result.recordCount > 0) {
                        $.each(result.costCenter, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(item.srNo),
                                $('<td>').text(item.valueField),
                                $('<td>').text(item.displayField),
                            );
                            $("#vendorBody").append($tr);
                        });

                       
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                        $("#vendorBody").append($tr);
                    }
                    VendorPaging(result.recordCount, pageNum);
                    $('.loader-wrapper').hide();



                }

            });
    }

}

function VendorPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetVendorPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetVendorPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetVendorPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetVendorPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetVendorPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#vendorPageList").append(template);
}

/*GL Master :*/
function GetGLPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#glBody").empty();
    $("#glPageList").empty();
    if ($("#costCompany").val() == null || $("#costCompany").val() == "" || $("#costCompany").val() == "0") {
        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('Please select company to get data'));
        $("#glBody").append($tr);
    }
    else {
        $.ajax(
            {
                type: "GET", //HTTP POST Method  
                url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=GL&CompanyCode=" + $("#costCompany").val() + "&CostCenterSearch=" + $("#gl").val(), // Controller/View
                data: null,
                success: function (result) {

                    if (result.recordCount > 0) {
                        $.each(result.costCenter, function (i, item) {

                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(item.srNo),
                                $('<td>').text(item.valueField),
                                $('<td>').text(item.displayField),
                            );
                            $("#glBody").append($tr);
                        });

                        
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                        $("#glBody").append($tr);
                    }
                    GLPaging(result.recordCount, pageNum);
                    $('.loader-wrapper').hide();



                }

            });
    }

}

function GLPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetGLPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetGLPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetGLPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetGLPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetGLPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#glPageList").append(template);
}

/*Material Master :*/
function GetMaterialPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#materialBody").empty();
    $("#materialPageList").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=Material&CompanyCode=null&CostCenterSearch=" + $("#material").val(), // Controller/View
            data: null,
            success: function (result) {

                if (result.recordCount > 0) {
                    $.each(result.costCenter, function (i, item) {
                        var image = appUrl + "assets/MaterialImage/" + item.materialImage;
                        var imagepath = "<a href=" + image + " target='_blank' >View</a> ";
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.srNo),
                            $('<td>').text(item.valueField),
                            $('<td>').text(item.displayField),
                           // <a href="#" onclick="openDialog(' + "'" + item.valueField + "'" + ',' + "'" + item.displayField + "'" + ')" > Upload</a >
                            $('<td>').html(imagepath + ' | <a href="#" onclick="openDialog(' + "'" + item.valueField + "'" + ',' + "'" + item.displayField + "'" + ')" > Upload</a>'),
                        );
                        $("#materialBody").append($tr);
                    });

                    
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    $("#materialBody").append($tr);
                }
                MaterialPaging(result.recordCount, pageNum);
                $('.loader-wrapper').hide();



            }

        });

}

function openDialog(materialCode,materialName) {
    $("#materialImageDialog").modal('show');

    $("#lblMaterialCode").text(materialCode);
    $("#lblMaterialName").text(materialName);
}

function saveMaterialImage() {

    if ($("#lblMaterialCode").text() == '' || $("#lblMaterialCode").text() == undefined) {
        alert("Material Code required!");
        return false;
    }
   
    var fileUpload = $("#formFileMultiple").get(0);

    var files = fileUpload.files;

    if (files.length > 0) {

        for (var i = 0; i < files.length; i++) {

            var fileext = files[i].name.substr((files[i].name.lastIndexOf('.') + 1));

            if ($.inArray(fileext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                alert('Only (gif,png,jpg,jpeg) are allowed!');
                return false;
            }


        }

        //var allowedSize = 0;


        //for (var i = 0; i < files.length; i++) {
        //    const fsize = files.item(i).size;
        //    const file = Math.round((fsize / 1024));
        //    allowedSize = allowedSize + file;
        //    // The size of the file.

        //}

        //if (allowedSize > 10240) {
        //    alert("File too Big, please select  files equal to 10 mb");


        //    return false;
        //}

    }
    else {
        alert("Please select file!");
        return false;
    }

    if (confirm('Do you want to update details?')) {

        var data = new FormData();

        data.append("materialCode", $("#lblMaterialCode").text());
        data.append("imageType", "MaterialMaster");

        for (var i = 0; i < files.length; i++) {
            data.append("fileInput", files[i]);
        }
        $.ajax({

            type: "POST",

            url: appUrl + "Admin/Upload_File",

            contentType: false,

            processData: false,

            data: data,

            async: false,

            beforeSend: function () {

                $('.loader-wrapper').show()

            },

            success: function (message) {
                if (message == "SUCCESS") {
                    alert("Image updated successfully.Please refresh list to see updated image!");
                    $("#materialImageDialog").modal('hide');

                }
                else {
                    alert(message);
                }
                $('.loader-wrapper').hide();


            },

            error: function () {
                $('.loader-wrapper').hide();
                alert("Error!");

            },

            complete: function () {

                $('.loader-wrapper').hide();

            }

        });

    }
}

function MaterialPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetMaterialPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetMaterialPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetMaterialPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetMaterialPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetMaterialPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#materialPageList").append(template);
}

/*ServiceMaterial Master :*/
function GetServiceMaterialPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#smBody").empty();
    $("#smPageList").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=ServiceMaterial&CompanyCode=null&CostCenterSearch=" + $("#serviceMaterial").val(), // Controller/View
            data: null,
            success: function (result) {

                if (result.recordCount > 0) {
                    $.each(result.costCenter, function (i, item) {
                        var image = appUrl + "assets/MaterialImage/" + item.materialImage;
                        var imagepath = "<a href=" + image + " target='_blank' >View</a> ";
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.srNo),
                            $('<td>').text(item.valueField),
                            $('<td>').text(item.displayField),
                            $('<td>').html(imagepath + ' | <a href="#" onclick="openDialog(' + "'" + item.valueField + "'" + ',' + "'" + item.displayField + "'" + ')" > Upload</a>'),
                        );
                        $("#smBody").append($tr);
                    });

                    

                    $("#smBody").focus();
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                    $("#smBody").append($tr);
                }
                ServiceMaterialPaging(result.recordCount, pageNum);
                $('.loader-wrapper').hide();



            }

        });

}

function ServiceMaterialPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetServiceMaterialPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetServiceMaterialPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetServiceMaterialPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetServiceMaterialPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetServiceMaterialPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#smPageList").append(template);
}

function saveServiceImage() {

    if ($("#lblMaterialCode").text() == '' || $("#lblMaterialCode").text() == undefined) {
        alert("Service Code required!");
        return false;
    }

    var fileUpload = $("#formFileMultiple").get(0);

    var files = fileUpload.files;

    if (files.length > 0) {

        for (var i = 0; i < files.length; i++) {

            var fileext = files[i].name.substr((files[i].name.lastIndexOf('.') + 1));

            if ($.inArray(fileext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
                alert('Only (gif,png,jpg,jpeg) are allowed!');
                return false;
            }


        }

    }
    else {
        alert("Please select file!");
        return false;
    }

    if (confirm('Do you want to update details?')) {

        var data = new FormData();

        data.append("materialCode", $("#lblMaterialCode").text());
        data.append("imageType", "ServiceMaster");

        for (var i = 0; i < files.length; i++) {
            data.append("fileInput", files[i]);
        }
        $.ajax({

            type: "POST",

            url: appUrl + "Admin/Upload_File",

            contentType: false,

            processData: false,

            data: data,

            async: false,

            beforeSend: function () {

                $('.loader-wrapper').show()

            },

            success: function (message) {
                if (message == "SUCCESS") {
                    alert("Image updated successfully.Please refresh list to see updated image!");
                    $("#materialImageDialog").modal('hide');

                }
                else {
                    alert(message);
                }
                $('.loader-wrapper').hide();


            },

            error: function () {

                alert("Error!");

            },

            complete: function () {

                $("#divloader").hide()

            }

        });

    }
}

/*PurchaseOrganisation Master :*/
function GetPurchaseOrganisationPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#poBody").empty();
    $("#poPageList").empty();
    if ($("#costCompany").val() == null || $("#costCompany").val() == "" || $("#costCompany").val() == "0") {
        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('Please select company to get data'));
        $("#poBody").append($tr);
    }
    else {
        $.ajax(
            {
                type: "GET", //HTTP POST Method  
                url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=PurchaseOrganisation&CompanyCode=" + $("#costCompany").val() + "&CostCenterSearch=" + $("#purchaseOrganisation").val(), // Controller/View
                data: null,
                success: function (result) {

                    if (result.recordCount > 0) {
                        $.each(result.costCenter, function (i, item) {

                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(item.srNo),
                                $('<td>').text(item.valueField),
                                $('<td>').text(item.displayField),
                            );
                            $("#poBody").append($tr);
                        });

                       
                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="3">').text('No records to display'));
                        $("#poBody").append($tr);
                    }
                    PurchaseOrganisationPaging(result.recordCount, pageNum);
                    $('.loader-wrapper').hide();



                }

            });
    }

}

function PurchaseOrganisationPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetPurchaseOrganisationPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetPurchaseOrganisationPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetPurchaseOrganisationPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetPurchaseOrganisationPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetPurchaseOrganisationPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#poPageList").append(template);
}

/*Status Master :*/
function GetStatusPageData(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    $('.loader-wrapper').show();

    $("#statusBody").empty();
    $("#statusPageList").empty();
    $.ajax(
        {
            type: "GET", //HTTP POST Method  
            url: "GetMasterData?RowsOfPage=" + pageSize + "&pageNumber=" + pageNum + "&MasterType=StatusMaster&CompanyCode=null&CostCenterSearch=" + $("#statusMaster").val(), // Controller/View
            data: null,
            success: function (result) {

                if (result.recordCount > 0) {
                    $.each(result.costCenter, function (i, item) {

                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.srNo),
                            $('<td>').text(item.displayField),
                        );
                        $("#statusBody").append($tr);
                    });

                   
                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="2">').text('No records to display'));
                    $("#statusBody").append($tr);
                }
                StatusPaging(result.recordCount, pageNum);
                $('.loader-wrapper').hide();



            }

        });

}

function StatusPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetStatusPageData(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        /* '<li><select ng-model="pageSize" id="selectedId"><option value="20" selected>20</option><option value="50">50</option><option value="100">100</option><option value="150">150</option></select> </li>' +*/
        '<li><a href="#" onclick="GetStatusPageData(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetStatusPageData(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetStatusPageData(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetStatusPageData(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#statusPageList").append(template);
}

/*Esports*/
$("#ststusExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('StatusMaster');
    $("input[name='CompanyCode']").val($("#CompanyName").val());
    $("input[name='CostCenterSearch']").val($("#statusMaster").val());

    $("#waitLoadingPanel").hide()
})

$("#vendorExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('Vendor');
    $("input[name='CompanyCode']").val($("#costCompany").val());
    $("input[name='CostCenterSearch']").val($("#vendorMaster").val());

    $("#waitLoadingPanel").hide()
})

$("#companyExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('CompanyMaster');
    $("input[name='CompanyCode']").val($("#CompanyName").val());

    $("#waitLoadingPanel").hide()
})

$("#costExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('CostCenter');
    $("input[name='CompanyCode']").val($("#costCompany").val());
    $("input[name='CostCenterSearch']").val($("#costCenter").val());

    $("#waitLoadingPanel").hide()
})

$("#currencyExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('Currency');
    $("input[name='CompanyCode']").val($("#CompanyName").val());
    $("input[name='CostCenterSearch']").val($("#currency").val());
    

    $("#waitLoadingPanel").hide()
})

$("#glExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('GL');
    $("input[name='CompanyCode']").val($("#costCompany").val());
    $("input[name='CostCenterSearch']").val($("#gl").val());

    $("#waitLoadingPanel").hide()
})

$("#materialExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('Material');
    $("input[name='CompanyCode']").val($("#CompanyName").val());
    $("input[name='CostCenterSearch']").val($("#material").val());

    $("#waitLoadingPanel").hide()
})

$("#pcExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('PlantCode');
    $("input[name='CompanyCode']").val($("#costCompany").val());
    $("input[name='CostCenterSearch']").val($("#plantCode").val());

    $("#waitLoadingPanel").hide()
})

$("#pgExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('PurchaseGroup');
    $("input[name='CompanyCode']").val($("#CompanyName").val());
    $("input[name='CostCenterSearch']").val($("#purchaseGroup").val());

    $("#waitLoadingPanel").hide()
})

$("#poExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('PurchaseOrganisation');
    $("input[name='CompanyCode']").val($("#costCompany").val());
    $("input[name='CostCenterSearch']").val($("#purchaseOrganisation").val());

    $("#waitLoadingPanel").hide()
})

$("#ptExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('PurchaseType');
    $("input[name='CompanyCode']").val($("#CompanyName").val());
    $("input[name='CostCenterSearch']").val($("#purchaseType").val());

    $("#waitLoadingPanel").hide()
})

$("#smExport").click(function () {
    $("#waitLoadingPanel").show()

    $("input[name='RowsOfPage']").val(20);
    $("input[name='pageNumber']").val(-1);
    $("input[name='MasterType']").val('ServiceMaterial');
    $("input[name='CompanyCode']").val($("#CompanyName").val());
    $("input[name='CostCenterSearch']").val($("#serviceMaterial").val());

    $("#waitLoadingPanel").hide()
})

function GetMenuMaster(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }

    var serachParm = $("#menuMaster").val();
    $('.loader-wrapper').show();
    $("#tbodyMenuMaster").empty();
    $("#mmPageList").empty();

    $.ajax(
        {
            type: "POST", //HTTP POST Method
            url: appUrl + "Admin/GetMenuMaster", // Controller/View
            data: {
                "SerachParm": serachParm,
                "RowsOfPage": pageSize,
                "pageNumber": pageNum
            },
            success: function (result) {

                if (result.responseCode == 1) {
                    var responseData = JSON.parse(result.responseJSON);
                    $.each(responseData, function (i, item) {
                        var $tr = $('<tr>').append(
                            $('<td class="text-center">').text(item.SRNo),
                            $('<td>').text(item.MenuName),
                            $('<td>').text(item.MenuUrl),
                            $('<td>').text(item.ParentMenu),
                           /* $('<td>').html('<a href="javascript:;" class="mr-2" onclick="DeleteMenuMaster(' + item.MenuID + ')"><i class="fas fa-trash-alt text-danger"></i></a>')*/
                        );
                        $("#tbodyMenuMaster").append($tr);
                    });


                }
                else {
                    var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('No records to display'));
                    $("#tbodyMenuMaster").append($tr);
                }
                MenuMasterPaging(result.recordCount, pageNum);
                $('.loader-wrapper').hide();
            }
        });
}

function MenuMasterPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetMenuMaster(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        '<li><a href="#" onclick="GetMenuMaster(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetMenuMaster(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetMenuMaster(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetMenuMaster(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#mmPageList").append(template);
}

function OpenMenuMasterConfig() {

    $("#menuDetails").modal('show');

    $("#txtMenuName").empty();
    $("#parentMenu").empty();
    $("#txtMenuURL").empty();

    
    document.getElementById('txtMenuName').value = '';
    document.getElementById('parentMenu').value = '';
    document.getElementById('txtMenuURL').value = '';

    bindParentDropDown($("#parentMenu").val());
}

function bindParentDropDown(selectedValue) {
    $("#parentMenu").empty();
    $("#parentMenu").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/GetParentMenuMaster',
        data: null,
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#parentMenu").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#parentMenu").val(selectedValue);
                }



            }


        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function AddMenuMaster() {

    var ParentMenu = $("#parentMenu").val();
    var MenuName = $("#txtMenuName").val();
    var MenuUrl = $("#txtMenuURL").val();
    if (ParentMenu == 0 || ParentMenu == null || ParentMenu == "") {
        alert("Please select the Parent Menu");
    }
    else if (MenuName == null || MenuName == "") {
        alert("Please enter Menu name");
    }
    else if (MenuUrl == null || MenuUrl == "") {
        alert("Please enter Menu Url");
    }
    else {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/InsertMenuMaster',
            data: {
                "Action": "Add",
                "ParentMenuID": ParentMenu,
                "MenuName": MenuName,
                "MenuUrl": MenuUrl
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert(pdata.responseMessage);
                    $("#menuDetails").modal('hide');
                    GetMenuMaster(1, 20);
                    //OpenMenuMasterConfig($("#selCostCenterCode").text(), $("#selCostCenterName").text());
                }
                else {
                    alert(pdata.responseMessage);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }

}

function DeleteMenuMaster(MenuId) {
    var isDelate = window.confirm('Are you sure you want to delete this Menu?');

    if (isDelate) {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/DeleteMenuMaster',
            data: {
                "MenuId": MenuId
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert(pdata.responseMessage);
                    GetMenuMaster(1, 20);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }

}

$("#userType").change(function () {
    bindMenuTypeDropDown($("#muneName").val());
})

function bindUserTypeDropDown(selectedValue) {
    $("#userType").empty();
    $("#userType").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/GetUserTypeMaster',
        data: null,
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                console.log(pdata.masterDataResponses);
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#userType").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#userType").val(selectedValue);
                }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function bindMenuTypeDropDown(selectedValue) {
    var UsertypeSearch = $("#userType").val();
    $("#muneName").empty();
    $("#muneName").append($("<option />").val("").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/GetMenuMasterType?UserType=' + UsertypeSearch,
        data: null,
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#muneName").append($("<option />").val(this.valueField).text(this.displayField));
                });
                if (selectedValue != '') {
                    $("#muneName").val(selectedValue);
                }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
        }
    });
}

function OpenMenuUserMappingConfig() {

    $("#menuUserDetails").modal('show');

    $("#userType").empty();
    $("#muneName").empty();


    document.getElementById('userType').value = '';
    document.getElementById('muneName').value = '';

    bindUserTypeDropDown($("#userType").val());
    bindMenuTypeDropDown($("#muneName").val());
}

function GetMenuUserMapping(pageNum, pageSize) {
    if (!pageSize) {

        pageSize = 20;
    }
    var serachParm = $("#menuUserMaster").val();
    var UserType = $("#userTypeSearch").val();
    $('.loader-wrapper').show();
    $("#tbodyMenuUser").empty();
    $("#muPageList").empty();
    if (UserType == "" || UserType == "0" || UserType == null) {
        var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('Please Select user type to get data'));
        $("#tbodyMenuUser").append($tr);
    }
    else {
        $.ajax(
            {
                type: "POST", //HTTP POST Method
                url: appUrl + "Admin/GetMenuUserMapping", // Controller/View
                data: {
                    "SerachParm": serachParm,
                    "RowsOfPage": pageSize,
                    "pageNumber": pageNum,
                    "UserType": UserType
                },
                success: function (result) {

                    if (result.responseCode == 1) {
                        var responseData = JSON.parse(result.responseJSON);
                        $.each(responseData, function (i, item) {
                            var $tr = $('<tr>').append(
                                $('<td class="text-center">').text(item.SRNo),
                                $('<td>').text(item.UserType),
                                $('<td>').text(item.MenuName),
                                $('<td>').html('<a href="javascript:;" class="mr-2" onclick="DeleteUserMenuMaster(' + item.MappingId + ')"><i class="fas fa-trash-alt text-danger"></i></a>')
                            );
                            $("#tbodyMenuUser").append($tr);
                        });


                    }
                    else {
                        var $tr = $('<tr>').append($('<td class="text-center" colspan="4">').text('No records to display'));
                        $("#tbodyMenuUser").append($tr);
                    }
                    MenuUserMappingPaging(result.recordCount, pageNum);
                    $('.loader-wrapper').hide();
                }
            });
    }
}

function MenuUserMappingPaging(totalPage, currentPage) {

    var template = "";
    var TotalPages = totalPage;
    var CurrentPage = currentPage;
    var PageNumberArray = Array();


    var countIncr = 1;
    for (var i = currentPage; i <= totalPage; i++) {
        PageNumberArray[0] = currentPage;
        if (totalPage != currentPage && PageNumberArray[countIncr - 1] != totalPage) {
            PageNumberArray[countIncr] = i + 1;
        }
        countIncr++;
    };
    PageNumberArray = PageNumberArray.slice(0, 5);
    var FirstPage = 1;
    var LastPage = totalPage;
    if (totalPage != currentPage) {
        var ForwardOne = currentPage + 1;
    }
    var BackwardOne = 1;
    if (currentPage > 1) {
        BackwardOne = currentPage - 1;
    }

    if (TotalPages == 0) {
        CurrentPage = 0;
    }
    template = "<p>" + CurrentPage + " of " + TotalPages + " pages</p>"
    template = template + '<ul class="pager">' +
        '<li class="previous"><a href="#" onclick="GetMenuUserMapping(' + FirstPage + ')"><i class="fa fa-fast-backward"></i>&nbsp;First</a></li>' +
        '<li><a href="#" onclick="GetMenuUserMapping(' + BackwardOne + ')"><i class="glyphicon glyphicon-backward"></i>Previous</a>';
    var numberingLoop = "";
    for (var i = 0; i < PageNumberArray.length; i++) {
        numberingLoop = numberingLoop + '<a class="page-number active" onclick="GetMenuUserMapping(' + PageNumberArray[i] + ')" href="#">' + PageNumberArray[i] + ' &nbsp;&nbsp;</a>'
    }
    template = template + numberingLoop + '<a href="#" onclick="GetMenuUserMapping(' + ForwardOne + ')" ><i class="glyphicon glyphicon-forward"></i>Next</a></li>' +
        '<li class="next"><a href="#" onclick="GetMenuUserMapping(' + LastPage + ')">Last&nbsp;<i class="fa fa-fast-forward"></i></a></li></ul>';
    $("#muPageList").append(template);
}

function AddMenuUserMapping() {

    var UserType = $("#userType").val();
    var MuneName = $("#muneName").val();
    if (UserType == null || UserType == "") {
        alert("Please Select User Type.");
    }
    else if (MuneName == 0 || MuneName == "" || MuneName == null) {
        alert("Please Select Menu.");
    }
    else {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/InsertMenuUserMapping',
            data: {
                "Action": "Add",
                "UserTypeCode": UserType,
                "MenuID": MuneName,
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert(pdata.responseMessage);
                    $("#menuUserDetails").modal('hide');
                    GetMenuUserMapping(1, 20);
                    $('.loader-wrapper').hide();
                }
                else {
                    alert(pdata.responseMessage);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
       
    }
}

function bindUserTypeSearchDropDown(selectedValue) {
    $("#userTypeSearch").empty();
    $("#userTypeSearch").append($("<option />").val("0").text("Select"));
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/GetUserTypeMaster',
        data: null,
        success: function (pdata) {
            if (pdata.responseCode == 1) {
                console.log(pdata);
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#userTypeSearch").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#userTypeSearch").val(selectedValue);
                }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}

function DeleteUserMenuMaster(MenuId) {
    var isDelate = window.confirm('Are you sure you want to delete this Mapping ?');

    if (isDelate) {
        $.ajax({
            type: 'POST',
            url: appUrl + 'Admin/DeleteUserMenuMapping',
            data: {
                "MenuId": MenuId
            },
            success: function (pdata) {
                if (pdata.responseCode == 1) {
                    alert(pdata.responseMessage);
                    GetMenuUserMapping(1, 20);
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {

            }
        });
    }

}









