﻿var appUrl = '';
var materialType = 'Capex';
var CartType = '1';
var SearchType = '2';
var catalogueData=[]
$(document).ready(function () {
    var pageURL = $(location).attr("href");
    appUrl = setAppUrl();
   
    //$("#ddlSupplierSearch").hide();

    function selectPicker2() {
        $(".selectPicker2").select2();
    }

    selectPicker2();

    checkSession();

    $("#selMaterial").change(function () {
        $("#productList").empty();
        
    });

    $('.summary-cntr .toggle-height-btn').on('click', function () {
        $(this).toggleClass('row-open');
        $(this).parents('.summary-cntr').find('.summary-card-row').toggleClass('height-0');
    });

    $('input[type=radio][name=catalogRadioBtn]').change(function () {
        if (this.value == 'itemSearch') {
            $(this).parents('.search-catelogue').find('.itemSearchInput').removeClass('d-none')
            $(this).parents('.search-catelogue').find('.supplierSearchInput').addClass('d-none')
            $("#productHeading").html("Search by Item List");
            SearchType = '1';
            $("#divSupplier").hide();
            $("#productList").empty();
            $("#txtItemSearch").val('');
        }
        else if (this.value == 'supplierSearch') {
            $(this).parents('.search-catelogue').find('.itemSearchInput').addClass('d-none')
            $(this).parents('.search-catelogue').find('.supplierSearchInput').removeClass('d-none')
            $("#productHeading").html("Search by Supplier List");
            $("#divSupplier").show();
            SearchType = '2';
            //BindCatalogueSupplier('', false);
            checkSession();
            $("#productList").empty();
            $("#txtItemSearch").val('');
        }
    });
    $('.allow_numeric').keypress(function (event) {
        return isNumber(event, this)
    });
   
});
function isNumber(evt, element) {

    var charCode = (evt.which) ? evt.which : event.keyCode

    if (
        (charCode != 45 || $(element).val().indexOf('-') != -1) &&      // “-” CHECK MINUS, AND ONLY ONE.
        (charCode != 46 || $(element).val().indexOf('.') != -1) &&      // “.” CHECK DOT, AND ONLY ONE.
        (charCode < 48 || charCode > 57))
        return false;

    return true;
}
function checkSession() {
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/CheckCart',
        data: {

        },
        success: function (data, textstatus) {
            if (data != '') {
                if (data.cartType=="NonCatalogue") {
                    if (data.purchaseTypeCode == "1" || data.purchaseTypeCode == "2") {
                        $("#inlineRadio1").prop("checked", true);
                        $("#inlineRadio2").prop("checked", false);

                        materialType = 'Capex';
                    }

                    else if (data.purchaseTypeCode == "4" || data.purchaseTypeCode == "5") {
                        $("#inlineRadio1").prop("checked", false);
                        $("#inlineRadio2").prop("checked", true);

                        materialType = 'Opex With Service';
                    }

                    $("#inlineRadio1").prop("disabled", true);
                    $("#inlineRadio2").prop("disabled", true);



                    bindMaterialDropDown(materialType, '', false)

                    $("#nonCatalogRadio").removeClass('d-none');
                    $("#catalogRadio").addClass('d-none');
                    $(".catalog-search").addClass('d-none');
                    $(".non-catalog-search").removeClass('d-none');
                    CartType = '1'
                    $("#productList").empty();
                    $("#productHeading").html("Item List");

                    $("#catalogToggle").prop("checked", false);
                    $("#catalogToggle").prop("disabled", true);
                }
                else {
                    $("#catalogToggle").prop("checked", true);
                    $("#catalogToggle").prop("disabled", true);
                    $("#catalogRadio").removeClass('d-none');  // checked
                    $("#nonCatalogRadio").addClass('d-none');
                    $(".catalog-search").removeClass('d-none');
                    $(".non-catalog-search").addClass('d-none');
                    CartType = '2'
                    $("#productList").empty();
                    $("#productHeading").html("Search by Supplier List");


                    BindCatalogueSupplier(data.vendorCode, true);
                }

               
                

            }
            else {
                $("#inlineRadio1").click(function () {
                    $("#productList").empty();
                    materialType = 'Capex';
                    bindMaterialDropDown(materialType, '', false);
                });

                $("#inlineRadio2").click(function () {
                    $("#productList").empty();
                    materialType = 'Opex With Service';
                    bindMaterialDropDown(materialType, '', false);
                });

                bindMaterialDropDown('Capex', '', false);

                $('.switch-button-checkbox').on('click', function (e) {

                    if ($("#catalogToggle").is(':checked')) {
                        $("#catalogRadio").removeClass('d-none');  // checked
                        $("#nonCatalogRadio").addClass('d-none');
                        $(".catalog-search").removeClass('d-none');
                        $(".non-catalog-search").addClass('d-none');
                        CartType = '2'
                        $("#productList").empty();
                        $("#productHeading").html("Search by Supplier List");
                        BindCatalogueSupplier('',false);

                    }
                    else {
                        $("#nonCatalogRadio").removeClass('d-none');
                        $("#catalogRadio").addClass('d-none');
                        $(".catalog-search").addClass('d-none');
                        $(".non-catalog-search").removeClass('d-none');
                        CartType = '1'
                        $("#productList").empty();
                        $("#productHeading").html("Item List");

                    }
                });
                
            }
            $('.loader-wrapper').hide();
            
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
        }
    });
}
function searchProduct() {
    /// for non catalogue
    if (CartType == '1') {
        if ($("#selMaterialhome").val() != "0") {

            loadProducts($("#selMaterialhome").val(), materialType);
        }
        else {
            alert("Please select material!");
        }
    }
    /// for catalogue
    else if (CartType == '2') {
        var ItemSearchValue = '';
        if (SearchType == '1') {
            ItemSearchValue = $("#txtItemSearch").val();
            if (ItemSearchValue == '' || ItemSearchValue.length < 4) {
                alert("Please enter search text minimum four characters!");
                return false;
            }
        }
        else if (SearchType == '2') {
            ItemSearchValue = $("#ddlSupplierSearch").val();
            if (ItemSearchValue ==0) {
                alert("Please select supplier!");
                return false;
            }

        }

        loadCatalogue(SearchType, ItemSearchValue);

    }
    
}
function bindMaterialDropDown(searchType, selectedValue, disableflag) {
    $("#selMaterialhome").empty();
    $("#selMaterialhome").append($("<option />").val("0").text("Select"));
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'PurchaseRequistion/GetMasterData',
        data: {
            "EntityName": "MaterialMaster", "SearchParameter1": searchType
        },
        success: function (pdata, textstatus) {
            if (pdata.responseCode == 1) {
                $.each(pdata.masterDataResponses, function (i, item) {
                    $("#selMaterialhome").append($("<option />").val(this.valueField).text(this.displayField));

                });


                if (selectedValue != '') {
                    $("#selMaterialhome").val(selectedValue);
                }

                if (disableflag == true) {
                    $("#selMaterialhome").prop("disabled", true);
                }


            }
            $('.loader-wrapper').hide();

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {

        }
    });
}
function loadProducts(materialCode, materialType) {
    $("#productList").empty();
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Home/ProductSearch',
        data: {
            "SearchType": materialType, "ProductCode": materialCode
        },
        success: function (data, textstatus) {

            if (data.responseCode == 1) {
                if (data.productList != '') {

                    $.each(data.productList, function (i, item) {

                        var $div = $('<div class="col-md-3">');
                        var $productcard = $('<div class="card product-card">');
                        var $productImage = $('<div class="product-image">');
                        var productImageURL = appUrl + "assets/MaterialImage/" + item.materialImage;
                        $productImage = $productImage.append('<img width="227" height="195" src=' + productImageURL + ' class="img - fluid">');

                        $productcard = $productcard.append($productImage);

                        var $productOverview = $('<div class="product-overview">');
                        var $productDesc = $('<div class="product-desc"><p>' + item.productDescription + '</p>');
                        var $productPrice = $('<div class="product-price" <h6>' + item.price + '</h6>');
                        var $productButton = $('<div class="product-button"><a href="' + appUrl + 'PurchaseRequistion?type=' + materialType + '&code=' + item.productID + '" class="btn btn-primary"> Create PR</a>');

                        $productOverview = $productOverview.append($productDesc);
                        //$productOverview = $productOverview.append($productPrice);
                        $productOverview = $productOverview.append($productButton);

                        $productcard = $productcard.append($productOverview);

                        $div = $div.append($productcard);


                        $("#productList").append($div);
                    });

                    $('.loader-wrapper').hide();
                }
                else {
                    page = -1;
                }
            }
            else if (data.responseCode == 2) {
                location.href = appUrl + "Auth/Index";

            }



           
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
            alert(errorThrown);
        }
    });
}
function BindCatalogueSupplier(selectedValue, disableflag) {
    $('.loader-wrapper').show();
    $("#ddlSupplierSearch").empty();
    $("#ddlSupplierSearch").append($("<option />").val("0").text("Select"));
    $.ajax(
        {
            type: "POST",
            url: appUrl + "Admin/GetAdvancedSearchData",
            dataType: "JSON",
            data: { "EntityName": "CatalogueSupplier" },
            success: function (data) {
                if (data.responseCode == 1) {
                    $.each(data.masterDataResponses, function (i, item) {
                        $("#ddlSupplierSearch").append($("<option />").val(item.valueField).text(item.displayField));
                    });

                    if (selectedValue != '') {
                        $("#ddlSupplierSearch").val(selectedValue);
                    }

                    if (disableflag == true) {
                        $("#ddlSupplierSearch").prop("disabled", true);
                    }
                }
                $('.loader-wrapper').hide();
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }

        }
    );
}
function loadCatalogue(searchType, searchText) {
    $("#productList").empty();
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/SearchCatalogueData',
        data: {
            "SearchType": searchType, "SearchText": searchText
        },
        success: function (data, textstatus) {

            if (data.length > 0) {
                catalogueData = data;
                $.each(data, function (i, item) {
                    //var firstName = 'Deepak';
                    //var lastName = 'Rohilla';
                    //var intials = firstName.charAt(0) + lastName.charAt(0);
                    //var profileImage = $('#profileImage').text(intials);


                    var $div = $('<div class="col-md-3">');
                    var $productcard = $('<div class="card product-card">');
                    //var $productImage = $('<div id="profileImage">');
                    var $productImage = $('<div class="product-image">');
                    var productImageURL = appUrl + "assets/MaterialImage/" + item.materialImage;
                    //var productImageURL = appUrl + "assets/images/no_image.jpg";
                    $productImage = $productImage.append('<img width="227" height="195" src=' + productImageURL + ' class="img - fluid">');

                    $productcard = $productcard.append($productImage);

                    var $productOverview = $('<div class="product-overview">');
                    var $productDesc = '';
                    if (searchType == 2) {
                        $productDesc = $('<div class="product-desc text-start"><h6>' + item.vendorName + '</h6><p class="text-start">Supplier Part #: ' + item.supplierPartID + '</p><p class="text-start">' + item.itemDescription + '</p>');
                    }
                    else if (searchType == 1) {
                        $productDesc = $('<div class="product-desc text-start"><h6>' + item.itemDescription + '</h6><p class="text-start">Supplier: ' + item.vendorName + '</p><p class="text-start">Supplier Part #: ' + item.supplierPartID + '</p><p class="text-start">' + item.itemDescription + '</p>');
                    }
                    var $PriceDIV = $('<div class="row product-price mb-3">');
                    var $PriceHeading = $('<div class="col-md-7"> <h6 class="my-2"> ' + item.priceToShow + ' / ' + item.itemUOM + '</h6>');
                    $PriceDIV = $PriceDIV.append($PriceHeading);
                    var $PriceQuantity = $('<div class="col-md-5">');
                    var $Pricegutters = $('<div class="row no-gutters"><label for="quantity1" class="col-sm-5 px-0 pt-2 fw-600">Qty:</label>');
                    var $PriceInput = $('<div class="col-sm-7 px-1"><input type="text" class="form-control p-1" onkeypress="return isNumber(event,this)" maxlength="10" id=txtquantity' + item.catalogueDataID + ' value="1">');
                    $Pricegutters = $Pricegutters.append($PriceInput);
                    $PriceQuantity = $PriceQuantity.append($Pricegutters);
                    $PriceDIV = $PriceDIV.append($PriceQuantity);

                    var $productButton = $('<div class="product-button"><a href="#" onclick=redirectToCatalogue(' + item.catalogueDataID + ') class="btn btn-primary"> Create PR</a>');

                    $productOverview = $productOverview.append($productDesc);
                    $productOverview = $productOverview.append($PriceDIV);
                    $productOverview = $productOverview.append($productButton);

                    $productcard = $productcard.append($productOverview);

                    $div = $div.append($productcard);


                    $("#productList").append($div);
                });

                $('.loader-wrapper').hide();
            }


            $('.loader-wrapper').hide();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
            alert(errorThrown);
        }
    });
}
function resetCatalogueControls() {
    $("#txtItemSearch").val('');
    $("#txtItemSearch").val('');

}
function redirectToCatalogue(cataloguedata) {
    var id = "#txtquantity" + cataloguedata;
    var quantity = $(id).val();
    if (quantity == undefined || quantity == '' || quantity=='0') {
        alert("Quantity required!");
        return false;
    }
    $('.loader-wrapper').show();
    $.ajax({
        type: 'POST',
        url: appUrl + 'Admin/RedirectToCatalogue',
        data: {
            "catalogueDataID": cataloguedata, "quantity": quantity
        },
        success: function (data, textstatus) {
            if (data.responseCode == 1) {
                location.href = appUrl + "PurchaseRequistion/PRCatalogue";
            }
            else if (data.responseCode == 2) {
                location.href = appUrl + "Auth/Index";

            }
            else {
                $('.loader-wrapper').hide();
                alert(data.responseMessage);

            }

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $('.loader-wrapper').hide();
            alert(errorThrown);
        }
    });
    
}

