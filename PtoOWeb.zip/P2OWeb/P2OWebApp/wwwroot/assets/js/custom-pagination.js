﻿
(function () {

    var customPagination = function () {

        var mainContainerId = '.customPagination';

        function Init() {
            BindEvents();
        }

        function BindEvents() {
            $(document).on('change', mainContainerId + ' select[name="Filter.Pagination.PageSize"]', Events.OnPageSizeChange);
            $(document).on('click', mainContainerId + ' button[name="Filter_Pagination_PageIndex"]', Events.OnPageIndexClick);
        }

        var Events = {

            OnPageSizeChange: function (e) {
                e.preventDefault();

                var $elem = $(this)

                //For multiple occurance of pagination control on page
                $(mainContainerId + ' select[name="Model.Filter.Pagination.PageSize"]').val($elem.val());
                $(mainContainerId + ' input[type=hidden][name="Filter.Pagination.PageIndex"]').val(0);

                var $form = $elem.parents('form');
                if ($form.length == 0) return false;

                FormSubmit($form);

                //var $search = $form.find('[type=submit][name=Command][value=Search]');
                //if ($search.length != 0) {
                //    $search.trigger('click');
                //}
                //else {
                //    //$form.append('<input type="submit" id="btnPaginationSubmit" style="display:none;" />');

                //    //if ($form.length == 0) return false;

                //    //$form.submit();
                //    FormSubmit($form);
                //}
            },

            OnPageIndexClick: function (e) {
                e.preventDefault();

                var $elem = $(this)

                //For multiple occurance of pagination control on page
                $(mainContainerId + ' input[type=hidden][name="Filter.Pagination.PageIndex"]').val($elem.val());

                var $form = $elem.parents('form');
                $form.append('<input type="submit" id="btnPaginationSubmit" style="display:none;" />');

                if ($form.length == 0) return false;

                //$form.submit();
                FormSubmit($form);

            }

        };

        return {
            Init: Init
        };

    }();

    $(function () {
        customPagination.Init();
    }());

}());