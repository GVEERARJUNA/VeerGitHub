
// Navbar  Function ===========================================================================================================//

$('.side-nav-wrapper').on('click', '.sub-menu-master', function(){
    if($(this).hasClass('open')){
        $(this).removeClass('open');
    }else{
        $('.sub-menu-master').removeClass('open');
        $(this).addClass('open');
        $(this).addClass('open');
    }
});



$('.side-nav-wrapper').on('click', '.sub-menu-level-01', function(e){
    e.stopPropagation();
    if($(this).hasClass('open')){
        $(this).removeClass('open');
    }else{
        $('.sub-menu-level-01').removeClass('open');
        $(this).addClass('open');
    }
});

$('.side-nav-wrapper').on('click', '.sub-menu-level-02', function(e){
  e.stopPropagation();
  if($(this).hasClass('open')){
      $(this).removeClass('open');
  }else{
      $('.sub-menu-level-02').removeClass('open');
      $(this).addClass('open');
  }
});

$('.hamburger-menu').on('click',  function(e){
  $('.side-nav-wrapper').toggle();
  
  
});


$('.hamburger-main-menu').on('click', function(){
  $('.side-nav-wrapper').addClass('open');
  $('.side-nav-menu-holder').removeClass('animate__animated animate__bounceOut'); 
  $('.side-nav-menu-holder').addClass('animate__animated animate__fadeInLeft'); 
  
});
  
  
  $('.nav-trigger-close').on('click', function(){
    $('.side-nav-wrapper').removeClass('open');
    $('.side-nav-menu-holder').removeClass('animate__animated animate__fadeInLeft'); 
    $('.side-nav-menu-holder').addClass('animate__animated animate__bounceOut'); 
  });
  
    
// Navbar  Function Ends Here ===========================================================================================================//


//Upload File Page   ===================================================================================================
function selectInit() {
    if ($('.customSelect').length) {
      $('.customSelect').selectpicker({
        width: '100%',
        liveSearch: true,
        size: '6',
        actionsBox: true,
        liveSearchPlaceholder: 'Search',
        //showIcon:true,
        container: 'body'
      });
    }
}
selectInit();

function activateScroll(){
    if ($('.custom-scroll').length){
        $('.custom-scroll').each(function(){
          new SimpleBar($(this)[0]);
        });
      }
}
activateScroll();


function activateCalenderSingle(){
  if ($('.daterange-single').length) {
      $('.daterange-single').daterangepicker({
          singleDatePicker: true,
          initiateDate: false,
          timePicker: false,
          startDate: moment().startOf('hour'),
         // maxDate: moment().startOf('hour').add(24, 'hour'),
          locale: {
              format: 'YYYY-MM-DD'
          }
      });
    $('input[name="fromDate"]').val('');
    $('input[name="toDate"]').val('');
    $('input[name="fromDate"]').attr("placeholder","Start Date");
    $('input[name="toDate"]').attr("placeholder","End Date");
  };
}
activateCalenderSingle();

function activateCalenderSingleDashboard() {
    if ($('.daterange-single-dashboard').length) {
       
        $('.daterange-single-dashboard').daterangepicker({
            singleDatePicker: true,
            initiateDate: false,
            timePicker: false,
            //placeholder:'Select a range',
            //startDate: moment().startOf('hour'),
            //maxDate: moment().startOf('hour').add(24, 'hour'),
            locale: {
                format: 'YYYY-MM-DD'
            }
        });
        $('input[name="fromDate"]').val('');
        $('input[name="toDate"]').val('');
        $('input[name="fromDate"]').attr("placeholder", "From Month");
        $('input[name="toDate"]').attr("placeholder", "To Month");
    };
}
activateCalenderSingleDashboard();

function activateNeedByCalenderSingle() {
    if ($('.daterange-singleneed').length) {
        $('.daterange-singleneed').daterangepicker({
            singleDatePicker: true,
            initiateDate: false,
            timePicker: false,
            startDate: moment().startOf('hour').add(1, 'days'),
            minDate: moment().startOf('hour').add(1, 'days'),
            // maxDate: moment().startOf('hour').add(24, 'hour'),
            locale: {
                format: 'YYYY-MM-DD'
            }
        });
       
    };
}
activateNeedByCalenderSingle();


function activateCalender(){
  if($('.activateCalender').length){
     $('.activateCalender').each(function(){
       var singleDate = false;
       var initiateDate = true;

       if($(this).attr('date-type') === 'single'){
         var singleDate = true;
       }

       if($(this).attr('date-initiate') === 'false'){
          initiateDate = false;
       }

         $(this).daterangepicker({
           locale: {
             format: 'DD-MMM-YYYY'
           },
           autoUpdateInput : true,
           singleDatePicker: singleDate,
           showDropdowns: singleDate,
             ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
             }
         });  
         if(!initiateDate){
           $(this).val('');
         }
        
     })  
  }
}
activateCalender();

$('.open-top-filter').on('click', function () {
  if ($(this).parents('.top-filter-outer-wrapper').find('.top-filter-wrapper').hasClass('open')) {
    $(this).parents('.top-filter-outer-wrapper').find('.top-filter-wrapper').removeClass('open');
    $(this).removeClass('open');
  } else {
    $('.top-filter-wrapper').removeClass('open');
    $(this).parents('.top-filter-outer-wrapper').find('.top-filter-wrapper').addClass('open');
    $('.open-top-filter').removeClass('open');
    $(this).addClass('open');
  }
});



$(document).on('change', '#searchOptions', function (e) {
    $('.search-row .search-textbox input').addClass('d-none');
    var selectVal = $(this).val();
    $('.search-textbox  #'+selectVal).removeClass('d-none');
});

//File Browse show name
$('input[type="file"]').change(function(e){
    var fileName = e.target.files[0].name;
    $(this).next('.custom-file-label').html(fileName);
});


//---------------- Character Count ----------------//

$(".char-textarea").on("keyup",function(event){
  checkTextAreaMaxLength(this,event);
});

/*
Checks the MaxLength of the Textarea
-----------------------------------------------------
@prerequisite:  textBox = textarea dom element
                e = textarea event
                length = Max length of characters
*/
function checkTextAreaMaxLength(textBox, e) { 
    
    var maxLength = parseInt($(textBox).data("length"));
    
  
    if (!checkSpecialKeys(e)) { 
        if (textBox.value.length > maxLength - 1) textBox.value = textBox.value.substring(0, maxLength); 
   } 
  $("#charNum .char-count").html(maxLength - textBox.value.length);
    
    return true; 
} 
/*
Checks if the keyCode pressed is inside special chars
-------------------------------------------------------
@prerequisite:  e = e.keyCode object for the key pressed
*/
function checkSpecialKeys(e) { 
    if (e.keyCode != 8 && e.keyCode != 46 && e.keyCode != 37 && e.keyCode != 38 && e.keyCode != 39 && e.keyCode != 40) 
        return false; 
    else 
        return true; 
}
//---------------- Character Count ----------------//



//Home Page =================================================================================================================
$(".file-upload-input-box").on('change','input.custom-file-input',function(){
  console.log($(this));
  var name = $(this)[0].files[0].name;
  $(this).parent('.custom-file').find('.upload-employee-label').text(name);

});

$('.reset-upload-employee').on('click', function(){
  $('.upload-employee-label').text('Choose file');
});




$('.check-box-wrap').on('change', 'input', function(){
 
  console.log('checking!!!');
  if($(this).prop('checked')){
    $('.check-box-wrap').find('input').prop('checked', false);
  }else{
    $('.check-box-wrap').find('input').prop('checked', false);
    $(this).prop('checked', true);
  }

});




//Monthly Calender
  function equalHeights(className){
    if($('.'+className).length){
    $("."+className).height('auto');
    if($(window).width()>767) {
      var heights = [];
      $("."+className).each(function(index,element) {
        heights.push(element.offsetHeight);
      });
      var maxHeight = Math.max.apply(null, heights);
      $("."+className).height(maxHeight);
    }
  }
  }
  
  equalHeights('eq-h');




//=====================================================Write your code above this Line one always==================================//
   //*** Accessibility js============================= ***//  
    //Accessibility Black color change //
    $(".clickBlackWhite").click(function() {
      var setColour = "color-white-to-black"
      document.body.className = setColour
      localStorage.setItem("background", setColour);
  });
  //Accessibility yello color change //
  $(".clickYellowWhite").click(function() {
      var setColour = "color-white-to-black-yellow"
      document.body.className = setColour
      localStorage.setItem("background", setColour);
  });
  $(".websiteDefaultColor").click(function() {
      var setColour = ""
      document.body.className = setColour
      localStorage.setItem("background", setColour);
  });
  //Accessibility Font-size increse decrese change code //
  var $affectedElements = $("body,span,h1, h2, h3, h4, h5, p, a, label");
  // Can be extended, ex. $("div, p, span.someClass")
  // Storing the original size in a data attribute so size can be reset
  $affectedElements.each(function() {
      var $this = $(this);
      $this.data("orig-size", $this.css("font-size"));
  });
  $("#btnincrease").click(function() {
      changeFontSize(1, $affectedElements);
  });
  $("#btndecrease").click(function() {
      changeFontSize(-1, $affectedElements);
  });
  $("#btnorig").click(function() {
      $affectedElements.each(function() {
          var $this = $(this);
          $this.css("font-size", $this.data("orig-size"));
      });
  });
  function changeFontSize(direction, $affectedElements) {
      $affectedElements.each(function() {
          var $this = $(this);
          $this.css("font-size", parseInt($this.css("font-size")) + direction);
      });
  }
  // $('h1,h2,h3,h4,h5,h6,a,p,li,label,table,tr,th,td').each(function() {
    $('h1,h2,h3,h4,h5,h6,a,p,li,table,tr,th,td').each(function() {
      $(this).attr('tabindex', '0');
      $(".asscibility li").removeAttr('tabindex', '0');
      $("#navbarSupportedContent li").removeAttr('tabindex', '0');
      $(".custom-tab li, .nav-pills li, .nav-wrapper li").removeAttr('tabindex', '0');
  });
  $(document).on('click', '.skipItem a', function(e) {
      var jump = $(this).attr('href');
      var new_position = $(jump).offset();
      $('html, body').stop().animate({ scrollTop: new_position.top }, 500);
      e.preventDefault();
  });
  //*** Accessibility js END =======================================***//

  // $('.daily-data-list').find('.time ').length;

  //Select all in table
$(function(){
  $('#checkAll').change(function() {
    var selAll = $(this).closest('table').find('.ApplicableCheck');
    if(this.checked) {
      selAll.attr('checked','checked');
      $('.ApplicableCheck').prop('checked', true);
    }
    else{
      selAll.removeAttr('checked');
      $('.ApplicableCheck').prop('checked', false);
    }
  });
});





$( document ).ready(function() {


    $("#ScreenOutcome").change(function(){
      $(this).find("option:selected").each(function(){
          var optionValue = $(this).attr("value");
          if(optionValue){
              $(".hideDiv").not("." + optionValue).hide();
              $("." + optionValue).show();
          } else{
              $(".hideDiv").hide();
          }
      });
  }).change();

  $("#SelectAccount").change(function(){
    $(this).find("option:selected").each(function(){
        var optionValue = $(this).attr("value");
        console.log(optionValue);
        if(optionValue){
            $(".hideDiv").not("." + optionValue).hide();
            $("." + optionValue).show();
        } else{
            $(".hideDiv").hide();
        }
    });
}).change();


$("#InternalTranfer").change(function(){
  $(this).find("option:selected").each(function(){
      var optionValue = $(this).attr("value");
      console.log(optionValue);
      if(optionValue){
          $(".hideDiv").not("." + optionValue).hide();
          $("." + optionValue).show();
      } else{
          $(".hideDiv").hide();
      }
  });
}).change();

$("#selOnBehalfOf").change(function(){
  $(this).find("option:selected").each(function(){
      var optionValue = $(this).attr("value");
      console.log(optionValue);
      if(optionValue){
          $(".hideDiv").not("." + optionValue).hide();
          $("." + optionValue).show();
      } else{
          $(".hideDiv").hide();
      }
  });
}).change();

    //$("#selPurchaseGroup").change(function () {
       
    //    if ($("#selPurchaseGroup option:selected").text().includes("(IT)")) {
    //        $("#selBudjetTracking").prop("disabled", false);
    //    }
    //    else {
    //        $("#selBudjetTracking").prop("disabled", true);
    //    }
    //}).change();

$('.catelogue-list-icon').on('click', function (e) {
  e.preventDefault();
  $('.change-catalogue-view a').removeClass('active');
  $(this).addClass('active'); 
});

$('.catelogue-list-icon.grid-view').on('click', function (e) {
  e.preventDefault();
  $('.catalogue-view').removeClass('detail-view-details');
  $('.catalogue-view').removeClass('list-view-details');
  $('.catalogue-view').addClass('grid-view-details');
 
});

$('.catelogue-list-icon.list-view').on('click', function (e) {
  e.preventDefault();
  $('.catalogue-view').removeClass('detail-view-details');
  $('.catalogue-view').removeClass('grid-view-details');
  $('.catalogue-view').addClass('list-view-details');
 
});

$('.catelogue-list-icon.detail-view').on('click', function (e) {
  e.preventDefault();
  $('.catalogue-view').removeClass('grid-view-details');
  $('.catalogue-view').removeClass('list-view-details');
  $('.catalogue-view').addClass('detail-view-details');
 
});

    $('.tableShowDetails').on('click', function (e) {
        
     e.preventDefault();
      var trigger = e.target;
      $(this).parents().parents("tr").next("tr.hiddenTR").toggle();
  
    });

    




//$('.approvetCartPop').on('click', function (e) {
//  e.preventDefault();
//  $('#approveCart').modal('show');

//});

//$('.rejectCartPop').on('click', function (e) {
//  e.preventDefault();
//  $('#rejectCart').modal('show');
//});

//$('.reworkCartPop').on('click', function (e) {
//  e.preventDefault();
//  $('#reworkCart').modal('show');
//});


//$("input[name$='costType']").click(function() {
//  var test = $(this).val();
//  $("div.costSelect").hide();
//  $("#" + test).show();

//});


$('#searchCatelogeLink').on('change', function() {
  var getLink = this.value;
  $(".ProcessMsg").empty()
  if (getLink == '') {      
    $(".ProcessMsg").append('No Product Found');
    $("a.select-process-link").attr("href",'#');
  } else {
    $("a.select-process-link").attr("href", getLink + '.html');
  } 
});


$('.place-order').on('click', function (e) {
  e.preventDefault();
  $('#placeOrderConfirmation').modal('show');
});



$('.btn-done').on('click', function () {
  $('.country-btn').removeClass('open');
  $('.location-wrapper').hide();
});


$('.assign-role').on('click', function () {
  $('#assignRole').modal('show');
});

$('.assign-company').on('click', function () {
  $('#assignCompany').modal('show');
});

$('.assign-delegator').on('click', function () {
  $('#createDelgation').modal('show');
});

$('.delete-row').on('click', function () {
  $('#deleteConfirmation').modal('show');
});


$('.hamburger-main-menu').on('click', function () {
  $('.close-nav i').addClass('animate__animated animate__rotateIn animate__repeat-2');
});

$('.close-nav').on('click', function () {
  $('.close-nav i').removeClass('animate__animated animate__rotateIn animate__repeat-2');
});

$("#user-list1-input").on("keyup", function() {
  var value = this.value.toLowerCase().trim();
  $(".user-list-1 li").show().filter(function() {
    return $(this).text().toLowerCase().trim().indexOf(value) == -1;
  }).hide();
});

$("#user-list2-input").on("keyup", function() {
  var value = this.value.toLowerCase().trim();
  $(".user-list-2 li").show().filter(function() {
    return $(this).text().toLowerCase().trim().indexOf(value) == -1;
  }).hide();
});



$(document).on("click",".pushRightList",function(e) {
  e.preventDefault();
  $('.user-list-1 .active').each(function(){
  $('.user-list-2').append('<li>'+$(this).text()+'</li>');
  });
  $('.user-list-1 .active').remove();
});


$(document).on("click",".pushLeftList",function(e) {
  e.preventDefault();
  $('.user-list-2 .active').each(function(){
  $('.user-list-1').append('<li>'+$(this).text()+'</li>');
  });
  $('.user-list-2 .active').remove();
});


$(document).on("click",".user-list-1 li",function(e) {
  e.preventDefault();
  var UserList1 = $(this).text();
  
  if (UserList1 != null) {
    $(this).toggleClass('active');  
    $('.pushRightList').removeClass('disabled');
    
  } else {  
    NoData = "Item Not Found.";
    $('.alertMessage').show();
    $('.alertMessage').addClass('show animate__animated animate__backInDown');  
    $('.alertMessage').removeClass('animate__bounceOutLeft');       
    $('.alertMessage b').text(NoData);  
    //alert('No item');
  }
});

$(document).on("click",".user-list-2 li",function(e) {
  e.preventDefault();
  var UserList2 = $(this).text();
  if (UserList2 != null) {
    $(this).toggleClass('active');  
    $('.pushLeftList').removeClass('disabled');
  } else {  
    NoData = "Item Not Found.";
    $('.alertMessage').show();
    $('.alertMessage').addClass('show animate__animated animate__backInDown');  
    $('.alertMessage').removeClass('animate__bounceOutLeft');       
    $('.alertMessage b').text(NoData); 
  
  }

});


$('.alert-close').on('click', function () {  
  $(this).parent().addClass('animate__animated animate__bounceOutLeft');     
});



  $('.country-btn').on('click', function (e) {
      e.preventDefault();
      if ($(this).hasClass('open')) {
          $(this).removeClass('open');
          $('.location-wrapper').hide();
          
      } else {
          $(this).addClass('open');
          $('.location-wrapper').addClass('animate__animated animate__fadeIn');
          $('.location-wrapper').show();
      }
  });


  var levelCount = 1;
  $(document).on('click', '.addLevel', function(e) {
    e.preventDefault();    
    levelCount ++;
    levelField ++; 
    var levelField = '<tr><td><label class="mt-1">Level '+levelCount+'</label></td><td> <select id="SelectEmployee"     class="customSelect"><option>Select</option><option>Creator</option><option>Commodity Manager</option>            <option>Finance Approver</option></select></td><td class="text-center"><a class="mt-1 btn btn-danger btn-xm deleteLevel"><i class="fa-solid fa-trash-can"></i></a></td></tr>';
    $("#levelApproval tbody").append(levelField);
    selectInit();    
  });
  
  $(document).on('click', '.deleteLevel', function(e) {
    e.preventDefault();
      $(this).parent().parent().remove();
    selectInit();  
  });
   




    $(window).on('load', function () {

        $('.loader-wrapper').hide();

    });

    $("#anchorSwitch").on('click', function (e) {
        $("#switchCompany").modal('show');
        bindSwitchDropDown();
    });

    function openCompanySwitchDialog() {
        $("#switchCompany").modal('show');
        bindSwitchDropDown();
    }
    function bindSwitchDropDown() {

        $("#ddlAssignedCompanies").empty();
        $("#ddlAssignedCompanies").append($("<option />").val("0").text("Select"));
        $('.loader-wrapper').show();
        $.ajax({
            type: 'POST',
            url: appUrl + 'PurchaseRequistion/GetMasterData',
            data: {
                "EntityName": "AssignedCompanies"
            },
            success: function (pdata, textstatus) {
                if (pdata.responseCode == 1) {
                    $.each(pdata.masterDataResponses, function (i, item) {
                        if (this.valueField == pdata.responseReturnNo) {
                            $("#ddlAssignedCompanies").append($("<option selected />").val(this.valueField).text(this.displayField));
                        }
                        else {
                            $("#ddlAssignedCompanies").append($("<option />").val(this.valueField).text(this.displayField));
                        }


                    });
                    //alert(pdata.responseReturnNo);
                    $("#selEmployee").val(pdata.responseReturnNo);

                }
                $('.loader-wrapper').hide();

            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });
    }
    $("#changeCompanyAnchor").on('click', function (e) {
        if ($("#ddlAssignedCompanies").val() == "0") {
            alert("Please select company!");
            return false;
        }
        $('.loader-wrapper').show();
        $.ajax({
            type: 'POST',
            url: appUrl + 'Home/switchCompany',
            data: {
                "CompanyName": $("#ddlAssignedCompanies").val()
            },
            success: function (pdata, textstatus) {
                $('.loader-wrapper').hide();
                if (pdata.responseCode == 1) {
                    location.href = appUrl + "Home/Index";
                }
                else if (pdata.responseCode == 2) {
                    location.href = appUrl + "Auth/Index";

                }
                else {
                    alert(pdata.responseMessage);
                }


            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                $('.loader-wrapper').hide();
            }
        });

    });
    function changeCompany() {
      
    }
});


  













