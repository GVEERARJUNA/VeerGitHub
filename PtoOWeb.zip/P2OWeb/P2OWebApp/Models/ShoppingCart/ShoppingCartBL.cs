﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.ShoppingCart
{
    public class ShoppingCartBL : IShoppingCartBL
    {
        private readonly IServiceConnect _serviceconnect;

        public ShoppingCartBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass PlaceHolder(ShoppingCart shoppingCart)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("CreatePurchaseRequistion", shoppingCart);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
           
            return response;

        }
    }
}
