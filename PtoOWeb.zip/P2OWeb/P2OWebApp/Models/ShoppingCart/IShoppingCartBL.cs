﻿using P2OWebApp.Models.Common;

namespace P2OWebApp.Models.ShoppingCart
{
    public interface IShoppingCartBL
    {
        ResponseClass PlaceHolder(ShoppingCart shoppingCart);
    }
}