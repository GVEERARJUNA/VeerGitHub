﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.ApprovalMapping
{
    public class ApprovalMappingBL : IApprovalMappingBL
    {
        private readonly IServiceConnect _serviceconnect;

        public ApprovalMappingBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass ApplicationHierarchyCreate(ApprovalMappingInsertRequestDTO approvalMappingInsertRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("ApplicationHierarchyCreate", approvalMappingInsertRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass AppHierarchyManage(AppHierarchyManageRequestDTO appHierarchyManageRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("AppHierarchyManage", appHierarchyManageRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

    }
}
