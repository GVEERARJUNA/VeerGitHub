﻿using P2OWebApp.Models.Common;

namespace P2OWebApp.Models.ApprovalMapping
{
    public interface IApprovalMappingBL
    {
        ResponseClass ApplicationHierarchyCreate(ApprovalMappingInsertRequestDTO approvalMappingInsertRequestDTO);
        ResponseClass AppHierarchyManage(AppHierarchyManageRequestDTO appHierarchyManageRequestDTO);
    }
}