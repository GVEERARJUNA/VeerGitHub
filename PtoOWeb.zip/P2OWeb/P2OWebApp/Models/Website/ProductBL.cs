﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Website
{
    public class ProductBL : IProductBL
    {
        private readonly IServiceConnect _serviceconnect;

        public ProductBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass GetProductListing(GetProductListingRequestDTO getProductListingRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<ProductResponse> productResponses = new List<ProductResponse>();
            string result = _serviceconnect.PostConnect("GetProductListing", getProductListingRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    productResponses = JsonConvert.DeserializeObject<List<ProductResponse>>(response.responseJSON.ToString());
                }

            }

            response.productList = productResponses;
            return response;

        }
    }
}
