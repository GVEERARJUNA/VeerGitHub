﻿using P2OWebApp.Models.Common;
using System.Collections.Generic;

namespace P2OWebApp.Models.Website
{
    public interface IProductBL
    {
        ResponseClass GetProductListing(GetProductListingRequestDTO getProductListingRequestDTO);
    }
}