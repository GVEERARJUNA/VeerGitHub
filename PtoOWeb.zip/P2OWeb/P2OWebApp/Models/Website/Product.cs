﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Website
{
    public class GetProductListingRequestDTO
    {
        public string UserID { get; set; }
        public string ProductSearchText { get; set; }

        public string SearchType { get; set; }
        public string ProductCode { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }

    public class ProductResponse
    {
        public string ProductID { get; set; }

        public string ProductName { get; set; }

        public int Price { get; set; }

        public string ProductDescription { get; set; }

        public string MaterialImage { get; set; }
    }
}
