﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.AppStats
{
    public class AppStatsBL : IAppStatsBL
    {
        private readonly IServiceConnect _serviceconnect;

        public AppStatsBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass AppStatInsert(AppStatsDTO appStatsBO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("AppStatInsert", appStatsBO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }
    }
}
