﻿using P2OWebApp.Models.Common;

namespace P2OWebApp.Models.AppStats
{
    public interface IAppStatsBL
    {
        ResponseClass AppStatInsert(AppStatsDTO appStatsBO);
    }
}