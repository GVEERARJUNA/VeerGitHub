﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models
{
    public class MenuMaster
    {
        public int MenuID { get; set; }
        public string MenuName { get; set; }
        public string MenuUrl { get; set; }
        public int ParentMenuID { get; set; }


    }
}
