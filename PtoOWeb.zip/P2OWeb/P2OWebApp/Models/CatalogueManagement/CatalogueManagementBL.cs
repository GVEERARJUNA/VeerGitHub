﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.CatalogueManagement
{
    public class CatalogueManagementBL : ICatalogueManagementBL
    {
        private readonly IServiceConnect _serviceconnect;

        public CatalogueManagementBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass UploadCatalogue(CatalogueDataUploadRequestDTO catalogueDataUploadRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("UploadCatalogue", catalogueDataUploadRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;
        }

        public ResponseClass ManageCatalogue(CatalogueManagementSearchRequestDTO catalogueManagementSearchRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("ManageCatalogue", catalogueManagementSearchRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;
        }

        public ResponseClass UpdateCataloguePublishStatus(UpdatePublishStatusRequestDTO updatePublishStatusRequest)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("UpdateCataloguePublishStatus", updatePublishStatusRequest);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;
        }

        public ResponseClass SearchCatalogueData(SearchCatalogueDataRequestDTO searchCatalogueDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("SearchCatalogueData", searchCatalogueDataRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;
        }
    }
}
