﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models
{
    public class LoginRequestBL : ILoginRequestBL
    {
        private readonly IServiceConnect _serviceconnect;

        public LoginRequestBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass UserLogin(LoginRequest loginRequest)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("CheckUserLogin", loginRequest);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;

        }
    }
}
