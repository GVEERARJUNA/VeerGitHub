﻿namespace P2OWebApp.Models.Service
{
    public interface IServiceConnect
    {
        string PostConnect(string MethodName, object input);
    }
}