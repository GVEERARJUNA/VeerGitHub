﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Service
{
    public class ServiceConnect : IServiceConnect
    {
        private readonly IOptions<IDBConnection> appSettings;

        public ServiceConnect(IOptions<IDBConnection> appSettings)
        {
            this.appSettings = appSettings;
        }

        public string PostConnect(string MethodName, object input)
        {
            string apiUrl = appSettings.Value.WEBAPI + MethodName;
            string inputJson = JsonConvert.SerializeObject(input);
            WebClient client = new WebClient();
            client.Headers["Content-type"] = "application/json";
            client.Encoding = Encoding.UTF8;
            string json = client.UploadString(apiUrl, inputJson);
            return json;

        }
    }
}
