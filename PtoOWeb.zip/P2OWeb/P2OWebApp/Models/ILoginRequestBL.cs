﻿using P2OWebApp.Models.Common;

namespace P2OWebApp.Models
{
    public interface ILoginRequestBL
    {
        ResponseClass UserLogin(LoginRequest loginRequest);
    }
}