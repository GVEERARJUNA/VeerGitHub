﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models
{
    public class LoginRequest
    {
        public string UserName { get; set; }
    }
}
