﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Audit
{
    public class AuditBL : IAuditBL
    {
        private readonly IServiceConnect _serviceconnect;

        public AuditBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass InsertAdminActivityLog(AdminActivityLogInsertDTO adminActivityLogInsertDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("InsertAdminActivityLog", adminActivityLogInsertDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;

        }
    }
}
