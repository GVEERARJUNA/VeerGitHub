﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Audit
{
    public class AdminActivityLogInsertDTO
    {
        public string ActionEmployeeID { get; set; }
        public string ActivityAction { get; set; }
        public string ActivitySubject { get; set; }
        public string ActivityLog { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
    }

    public class AuditProperties
    {
        public string PropertyName { get; set; }
        public string PropertyValue { get; set; }
    }

    public enum MyModuleName
    {
        CostCenterConfig,
        ApprovalMapping,
        High
    }
}
