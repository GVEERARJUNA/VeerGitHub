﻿using P2OWebApp.Models.Common;

namespace P2OWebApp.Models.Audit
{
    public interface IAuditBL
    {
        ResponseClass InsertAdminActivityLog(AdminActivityLogInsertDTO adminActivityLogInsertDTO);
    }
}