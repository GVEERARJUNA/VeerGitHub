﻿using P2OWebApp.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Models.Approval
{
    public interface IApprovalBL
    {
        List<WaitingApprovalResponceDTO>   GetWaitingApprovalList(ApprovalRequestDTO requestDTO, out int PRId);

        WaitingApproval GetRaisedRequistion(ApprovalRequestDTO requestDTO, out int PRId);
        ApprovalTreeResponse GetApproverList(ApprovalRequestDTO requestDTO);

        ResponseClass UpdateApprovalStatus(ApprovalSatatusUpdateRequestDTO updateRequestDTO);
        List<GetPREntityResponceDTO> GetPREntity(GetPREntityRequest requestDTO);
        ResponseClass GetAuditTrial(GetPREntityRequest requestDTO);
        List<GetPRFileResponceDTO> GetPRFiles(GetPREntityRequest requestDTO);

        ResponseClass GetPRRequistionDataByRequistionNo(PRRequistionDataRequestDTO requestDTO);

        List<WaitingApprovalDetails> GetPRDetailLines(GetPREntityRequest requestDTO);

        ResponseClass GetPRSAPDetails(GetPREntityRequest requestDTO);

        List<GetPRDetailSingleResponceDTO> GetPRDetailByDetailID(GetPREntityRequest requestDTO);

        ResponseClass UpdatePRDetail(UpdatePRDetailRequest updatePRDetailRequest);

        ApprovalTreeResponse GetPRVirtualFlow(PRVirtualFlowRequestDTO prVirtualFlow);
        ResponseClass UpdatePRHeaderDetail(UpdatePRRequest request);

        ResponseClass GetPRHeaderDetails(GetPREntityRequest requestDTO);
        ResponseClass AddPRFiles(PRFiles pRFilesDTO);
    }
}
