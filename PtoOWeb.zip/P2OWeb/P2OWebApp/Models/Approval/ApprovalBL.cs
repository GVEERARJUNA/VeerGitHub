﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Models.Approval
{
    public class ApprovalBL: IApprovalBL
    {

        private readonly IServiceConnect _serviceconnect;

        public ApprovalBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public WaitingApproval GetRaisedRequistion(ApprovalRequestDTO requestDTO, out int PRId)
        {
            WaitingApproval waiting = new WaitingApproval();
            PRId = 0;
            ResponseClass response = new ResponseClass();
            List<WaitingApprovalResponceDTO> WaitingApprovalResponse = new List<WaitingApprovalResponceDTO>();
            string result = _serviceconnect.PostConnect("Approval/GetWaitingForApprovalList", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    WaitingApprovalResponse = JsonConvert.DeserializeObject<List<WaitingApprovalResponceDTO>>(response.responseJSON.ToString());
                }

            }
            if (WaitingApprovalResponse.Count() > 0)
            {
                PRId = WaitingApprovalResponse[0].PurchaseRequistionID;

                foreach (var item in WaitingApprovalResponse)
                {
                    item.RequistionControlID = item.PurchaseRequistionID + "_approvallistflow";

                    GetPREntityRequest requestDTOdetails = new GetPREntityRequest();
                    requestDTOdetails.PurchaseRequistionID = item.PurchaseRequistionID;
                    requestDTOdetails.SearchType = "DETAILLINE";
                    var detailResponse = GetPRDetailLines(requestDTOdetails);
                    if (detailResponse != null)
                    {
                        item.waitingApprovalDetails = detailResponse;

                    }

                    // now check for Details 


                }
            }
    //        if (requestDTO.SearchType == "WAITING")
    //        {
    //            if (requestDTO.SearchBy == "1")
    //            {
    //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.GLCode == requestDTO.SearchText).ToList()
    //;
    //            }

    //            else if (requestDTO.SearchBy == "2")
    //            {
    //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.CostCenterName == requestDTO.SearchText).ToList()
    //;
    //            }
    //            //            else if (requestDTO.SearchBy == "2")
    //            //            {
    //            //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Company == requestDTO.SearchText).ToList()
    //            //;
    //            //            }
    //            //            else if (requestDTO.SearchBy == "3")
    //            ////            {
    //            //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Amount.ToString() == requestDTO.SearchText).ToList()
    //            //;
    //            //            }
    //            //            else if (requestDTO.SearchBy == "4")
    //            //            {
    //            //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Quantity.ToString() == requestDTO.SearchText).ToList()
    //            //;
    //            //            }

    //            else if (requestDTO.SearchBy == "3")
    //            {
    //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.PlantCode == requestDTO.SearchText).ToList()
    //;
    //            }

    //            //            else if (requestDTO.SearchBy == "6")
    //            //            {
    //            //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.PurchasingOrg == requestDTO.SearchText).ToList()
    //            //;
    //            //            }

    //            else if (requestDTO.SearchBy == "4")
    //            {
    //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.SAPPONumber == requestDTO.SearchText).ToList()
    //;
    //            }

    //            else if (requestDTO.SearchBy == "5")
    //            {
    //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Creator == requestDTO.SearchText).ToList()
    //;
    //            }
    //            else if (requestDTO.SearchBy == "6")
    //            {
    //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.RaisedBy == requestDTO.SearchText).ToList()
    //;
    //            }

    //            else if (requestDTO.SearchBy == "7")
    //            {
    //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Status == requestDTO.SearchText).ToList()
    //;
    //            }

    //            else if (requestDTO.SearchBy == "10")
    //            {
    //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Vendor == requestDTO.SearchText).ToList()
    //;
    //            }
    //        }

            waiting.waitingApprovalRes = WaitingApprovalResponse;
            waiting.PageCount = response.recordCount;
            return waiting;

        }

        public List<WaitingApprovalResponceDTO> GetWaitingApprovalList(ApprovalRequestDTO requestDTO, out int PRId)
        {

            PRId = 0;
            ResponseClass response = new ResponseClass();
            List<WaitingApprovalResponceDTO> WaitingApprovalResponse = new List<WaitingApprovalResponceDTO>();
            string result = _serviceconnect.PostConnect("Approval/GetWaitingForApprovalList", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    WaitingApprovalResponse = JsonConvert.DeserializeObject<List<WaitingApprovalResponceDTO>>(response.responseJSON.ToString());
                }

            }
            if (WaitingApprovalResponse.Count() > 0)
            {
                PRId = WaitingApprovalResponse[0].PurchaseRequistionID;

                foreach (var item in WaitingApprovalResponse)
                {
                    item.RequistionControlID = item.PurchaseRequistionID + "_approvallistflow";

                    GetPREntityRequest requestDTOdetails = new GetPREntityRequest();
                    requestDTOdetails.PurchaseRequistionID = item.PurchaseRequistionID;
                    requestDTOdetails.SearchType = "DETAILLINE";
                    var detailResponse = GetPRDetailLines(requestDTOdetails);
                    if (detailResponse!=null)
                    {
                        item.waitingApprovalDetails = detailResponse;

                    }

                    // now check for Details 


                }
            }
            if (requestDTO.SearchType == "WAITING")
            {
                if (requestDTO.SearchBy == "1")
                {
                    WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.GLCode == requestDTO.SearchText).ToList()
    ;
                }

                else if (requestDTO.SearchBy == "2")
                {
                    WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.CostCenterName.Contains( requestDTO.SearchText)).ToList()
    ;
                }
                //            else if (requestDTO.SearchBy == "2")
                //            {
                //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Company == requestDTO.SearchText).ToList()
                //;
                //            }
                //            else if (requestDTO.SearchBy == "3")
                ////            {
                //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Amount.ToString() == requestDTO.SearchText).ToList()
                //;
                //            }
                //            else if (requestDTO.SearchBy == "4")
                //            {
                //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Quantity.ToString() == requestDTO.SearchText).ToList()
                //;
                //            }

                else if (requestDTO.SearchBy == "3")
                {
                    WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.PlantCode.Contains(requestDTO.SearchText)).ToList()
    ;
                }

                //            else if (requestDTO.SearchBy == "6")
                //            {
                //                WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.PurchasingOrg == requestDTO.SearchText).ToList()
                //;
                //            }

                else if (requestDTO.SearchBy == "4")
                {
                    WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.SAPPONumber == requestDTO.SearchText).ToList()
    ;
                }

                else if (requestDTO.SearchBy == "5")
                {
                    WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Creator == requestDTO.SearchText).ToList()
    ;
                }
                else if (requestDTO.SearchBy == "6")
                {
                    WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.RaisedBy == requestDTO.SearchText).ToList()
    ;
                }

                else if (requestDTO.SearchBy == "7")
                {
                    WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Status == requestDTO.SearchText).ToList()
    ;
                }

                else if (requestDTO.SearchBy == "10")
                {
                    WaitingApprovalResponse = WaitingApprovalResponse.Where(d => d.Vendor.Contains(requestDTO.SearchText)).ToList()
    ;
                }
            }
            return WaitingApprovalResponse;

        }

        //public List<ApprovalStatusResponceDTO> GetApproverList(ApprovalRequestDTO requestDTO)
        //{
        //    ResponseClass response = new ResponseClass();
        //    List<ApprovalStatusResponceDTO> ApproverResponse = new List<ApprovalStatusResponceDTO>();
        //    string result = _serviceconnect.PostConnect("Approval/GetApprovalLevels", requestDTO);
        //    response = JsonConvert.DeserializeObject<ResponseClass>(result);
        //    if (response.responseCode == 1)
        //    {
        //        if (response.responseJSON.ToString().Length > 0)
        //        {
        //            ApproverResponse = JsonConvert.DeserializeObject<List<ApprovalStatusResponceDTO>>(response.responseJSON.ToString());
        //        }

        //    }

        //    return ApproverResponse;

        //}

        public ApprovalTreeResponse GetApproverList(ApprovalRequestDTO requestDTO)
        {
            ResponseClass response = new ResponseClass();
            ApprovalTreeResponse ApproverResponse = new ApprovalTreeResponse();
            string result = _serviceconnect.PostConnect("Approval/GetApprovalLevels", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    ApproverResponse = JsonConvert.DeserializeObject<ApprovalTreeResponse>(response.responseJSON.ToString());
                }

            }

            return ApproverResponse;

        }

        public ResponseClass UpdateApprovalStatus(ApprovalSatatusUpdateRequestDTO updateRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("Approval/UpdateApprovalStatus", updateRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public List<GetPREntityResponceDTO> GetPREntity(GetPREntityRequest requestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<GetPREntityResponceDTO> GetPREntityResponse = new List<GetPREntityResponceDTO>();
            string result = _serviceconnect.PostConnect("Approval/GetPREntity", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    GetPREntityResponse = JsonConvert.DeserializeObject<List<GetPREntityResponceDTO>>(response.responseJSON.ToString());
                }

            }

            return GetPREntityResponse;

        }

        public ResponseClass GetAuditTrial(GetPREntityRequest requestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<GetPREntityResponceDTO> GetPREntityResponse = new List<GetPREntityResponceDTO>();
            string result = _serviceconnect.PostConnect("Approval/GetPREntity", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
           
            return response;

        }

        public List<WaitingApprovalDetails> GetPRDetailLines(GetPREntityRequest requestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<WaitingApprovalDetails> GetPREntityResponse = new List<WaitingApprovalDetails>();
            string result = _serviceconnect.PostConnect("Approval/GetPREntity", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    GetPREntityResponse = JsonConvert.DeserializeObject<List<WaitingApprovalDetails>>(response.responseJSON.ToString());
                }

            }

            return GetPREntityResponse;

        }
        public List<GetPRFileResponceDTO> GetPRFiles(GetPREntityRequest requestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<GetPRFileResponceDTO> GetPRFileResponse = new List<GetPRFileResponceDTO>();
            string result = _serviceconnect.PostConnect("Approval/GetPREntity", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    GetPRFileResponse = JsonConvert.DeserializeObject<List<GetPRFileResponceDTO>>(response.responseJSON.ToString());
                }

            }

            return GetPRFileResponse;

        }

        public List<GetPRDetailSingleResponceDTO> GetPRDetailByDetailID(GetPREntityRequest requestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<GetPRDetailSingleResponceDTO> GetPRDetailResponse = new List<GetPRDetailSingleResponceDTO>();
            string result = _serviceconnect.PostConnect("Approval/GetPREntity", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    GetPRDetailResponse = JsonConvert.DeserializeObject<List<GetPRDetailSingleResponceDTO>>(response.responseJSON.ToString());
                }

            }

            return GetPRDetailResponse;

        }

        public ResponseClass GetPRSAPDetails(GetPREntityRequest requestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<GetPREntityResponceDTO> GetPREntityResponse = new List<GetPREntityResponceDTO>();
            string result = _serviceconnect.PostConnect("Approval/GetPREntity", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            
            return response;

        }

        public ResponseClass GetPRRequistionDataByRequistionNo(PRRequistionDataRequestDTO requestDTO)
        {
            //PRId = 0;
            ResponseClass response = new ResponseClass();
            //List<WaitingApprovalResponceDTO> WaitingApprovalResponse = new List<WaitingApprovalResponceDTO>();
            string result = _serviceconnect.PostConnect("Approval/GetPRRequistionDataByRequistionNo", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            //if (response.responseCode == 1)
            //{
            //    if (response.responseJSON.ToString().Length > 0)
            //    {
            //        WaitingApprovalResponse = JsonConvert.DeserializeObject<List<WaitingApprovalResponceDTO>>(response.responseJSON.ToString());
            //    }

            //}
            //if (WaitingApprovalResponse.Count() > 0)
            //{
            //    PRId = WaitingApprovalResponse[0].PurchaseRequistionID;

            //    foreach (var item in WaitingApprovalResponse)
            //    {
            //        item.RequistionControlID = item.PurchaseRequistionID + "_approvallistflow";

            //        GetPREntityRequest requestDTOdetails = new GetPREntityRequest();
            //        requestDTOdetails.PurchaseRequistionID = item.PurchaseRequistionID;
            //        requestDTOdetails.SearchType = "DETAILLINE";
            //        var detailResponse = GetPRDetailLines(requestDTOdetails);
            //        if (detailResponse != null)
            //        {
            //            item.waitingApprovalDetails = detailResponse;

            //        }

            //        // now check for Details 


            //    }
            //}
            return response;

        }

        public ResponseClass UpdatePRDetail(UpdatePRDetailRequest updatePRDetailRequest)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("Approval/UpdatePRDetail", updatePRDetailRequest);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass UpdatePRHeaderDetail(UpdatePRRequest request)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("Approval/UpdatePRHeaderDetail", request);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ApprovalTreeResponse GetPRVirtualFlow(PRVirtualFlowRequestDTO prVirtualFlow)
        {
            ResponseClass response = new ResponseClass();
            ApprovalTreeResponse ApproverResponse = new ApprovalTreeResponse();
            string result = _serviceconnect.PostConnect("Approval/GetPRVirtualFlow", prVirtualFlow);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    ApproverResponse = JsonConvert.DeserializeObject<ApprovalTreeResponse>(response.responseJSON.ToString());
                }

            }

            return ApproverResponse;

        }

        public ResponseClass GetPRHeaderDetails(GetPREntityRequest requestDTO)
        {
            ResponseClass response = new ResponseClass();
           
            string result = _serviceconnect.PostConnect("Approval/GetPREntity", requestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
           
            return response;

        }

        public ResponseClass AddPRFiles(PRFiles pRFilesDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("Approval/AddPRFiles", pRFilesDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

    }
}
