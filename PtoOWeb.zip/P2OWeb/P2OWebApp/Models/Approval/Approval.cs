﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Approval
{
    public class Approval
    {
        public class WaitingApprovalResponceDTO
        {
            public int SRNo { get; set; }
            public int PurchaseRequistionID { get; set; }
            public string CostCenterName { get; set; }
            public string RequistionNo { get; set; }
            public string GLCode { get; set; }
            public string Company { get; set; }
            public double Amount { get; set; }
            public double Quantity { get; set; }
            public string Vendor { get; set; }
            
            public int? VendorApplicable { get; set; }
            public string PlantCode { get; set; }
            public string PurchasingOrg { get; set; }
            public string Status { get; set; }
            public string RequistionControlID { get; set; }
            public int ApprovalLevel { get; set; }
            public int PRApprovalMatrixID { get; set; }
            public string Currency { get; set; }

            public string Creator { get; set; }

            public string RaisedBy { get; set; }

            public string OnBehalfOfFlag { get; set; }
            public List<WaitingApprovalDetails> waitingApprovalDetails { get; set; }

            public string PurchaseTypeName { get; set; }
            public string PurchaseGroupName { get; set; }

            public string SAPPRNumber { get; set; }
            public string SAPPONumber { get; set; }
            public string SAPPODate { get; set; }

            public int ApprovalStatus { get; set; }

            public string InsertedBy { get; set; }
            public string AmountToShow { get; set; }
            public DateTime InsertedDateTime { get; set; }
            public string MaterialDescription { get; set; }
            public string ProductType { get; set; }
            public string WarrantyStartDate { get; set; }
            public string WarrantyEndDate { get; set; }

            public int HoldApplicable { get; set; }

            public int oldStatus { get; set; }
            public int? GRNDone { get; set; }
            public int? DistributionDone { get; set; }
        }

        public class WaitingApprovalDetails
        {
            public int SRNo { get; set; }
            public string Material { get; set; }
           
            public string GLCode { get; set; }
            public string ProductType { get; set; }
            public double Amount { get; set; }
            public double Quantity { get; set; }

            public double NetAmount { get; set; }
            public string UOM { get; set; }
            public string LineComments { get; set; }

            public string MaterialImage { get; set; }
            public int PurchaseRequistionDetailID { get; set; }

            public string amountToShow { get; set; }
            public string netAmountToShow { get; set; }
            public string Currency { get; set; }
            public string WarrantyStartDate { get; set; }
            public string WarrantyEndDate { get; set; }


        }

        public class ApprovalTreeResponse
        {
            public List<ApprovalLevelResponse> DistinctLevel { get;set;}
            public List<ApprovalResponseTreeData> ApprovalData { get; set; }
        }

        public class ApprovalLevelResponse
        {
            public int ApprovalLevel { get; set; }

            public string SubmittedBy { get; set; }
            public string PRStatus { get; set; }
        }

        public class ApprovalResponseTreeData
        {
            public int ApprovalLevel { get; set; }
            public string ApprovalName { get; set; }
            public string DelegatorName { get; set; }
            public int IsDelegator { get; set; }
            public string ApprovalStatus { get; set; }
        }

        public class ApprovalStatusResponceDTO
        {
            public int Level { get; set; }
            public string FirstApprovalPerson { get; set; }
            public string FirstApprovalStatus { get; set; }
            public string SecondApprovalPerson { get; set; }
            public string SecondApprovalStatus { get; set; }
            public string Delegator { get; set; }
            public string DelegatorApprovalStatus { get; set; }
        }

        public class ApprovalRequestDTO
        {
            public string SAPCompanyCode { get; set; }
            public string LoggedInEmpId { get; set; }
            public long PurchaseRequistionID { get; set; }
            public string CostCentre { get; set; }
            public string SearchText { get; set; }
            public string SearchBy { get; set; }
            public string requistionNo { get; set; }
            public string SearchType { get; set; }

            public int PageNumber { get; set; }
            public int RowsOfPage { get; set; }
        }

        public class WaitingApproval
        {
            public int Count { get; set; }

            public int PageCount { get; set; }

            public int PageNumber { get; set; }

            public int CurrentPageIndex { get; set; }
            public IEnumerable<WaitingApprovalResponceDTO> waitingApprovalRes { get; set; }
            //public IEnumerable<ApprovalStatusResponceDTO> approvalStatuses { get; set; }
        }

        public class ApprovalSatatusUpdateRequestDTO
        {
            public string ApproverId { get; set; }
            public int PRApprovalMatrixID { get; set; }
            public int PurchaseRequistionID { get; set; }
            public int ApprovalLevel { get; set; }
            public int ApprovalStatus { get; set; }
            public string Remark { get; set; }
        }

        public class GetPREntityRequest
        {
            public int PurchaseRequistionID { get; set; }
            public string SearchType { get; set; }
        }
        public class GetPREntityResponceDTO
        {
            public string FullName { get; set; }

            public string StatusText { get; set; }
            public string Remarks { get; set; }
        }

        public class GetPRFileResponceDTO
        {
            public string FileName { get; set; }
            public string FileContent { get; set; }
            public string FilePath { get; set; }
            public string Role { get; set; }
            public string SubmittedBy { get; set; }
            public string RequisitionNo { get; set; }
            public string PRID { get; set; }
            public List<PRFiles> PRFiles { get; set; }
        }

        public class PRRequistionDataRequestDTO
        {
            public string LoggedInEmpId { get; set; }
            public string requistionNo { get; set; }

            public string AppSource { get; set; }
        }

        public class GetPRDetailSingleResponceDTO
        {
            public string PurchaseRequistionDetailID { get; set; }
            public string Amount { get; set; }
            public double Quantity { get; set; }
            public string Material { get; set; }
            public string MaterialCode { get; set; }
            public string ProductType { get; set; }

            public string RequistionNo { get; set; }
            public string PurchaseTypeName { get; set; }
            public string PurchaseTypeID { get; set; }
            public string GLCode { get; set; }
            public int GLCodeApplicable { get; set; }
            public int PRFileID { get; set; }
            public string FILEName { get; set; }
            public string FilePath { get; set; }
            public string LineComments { get; set; }
            public string NeedByDate { get; set; }
            public string WSDate { get; set; }
            public string WEDate { get; set; }
        }

        public class UpdatePRDetailRequest
        {
            public int PurchaseRequistionDetailID { get; set; }
            public double Amount { get; set; }
            public double Quantity { get; set; }
            public string InsertedBy { get; set; }
            public string InsertedIPAddress { get; set; }
            public int PurchaseRequistionID { get; set; }
            public string Action { get; set; }
            public string MaterialCode { get; set; }
            public string ShortText { get; set; }
            public string GLCode { get; set; }
            public string LineComments { get; set; }
            public int CatalogueDataID { get; set; }
            public string WarrantyStartDate { get; set; }
            public string WarrantyEndDate { get; set; }
            public string NeededByDate { get; set; }
            public List<GetPRFileResponceDTO> PRFiles { get; set; }

        }

        public class PRFiles
        {
            public int PRID { get; set; }
            public string fileNo { get; set; }
            public string FileName { get; set; }
            public string Action { get; set; }
            public string RequisitionNo { get; set; }
            public string FileContent { get; set; }
            public string FilePath { get; set; }
            public string InsertedEMPCode { get; set; }
            public string InsertedIPAddress { get; set; }
            public int fileSize { get; set; }
        }

        public class PRVirtualFlowRequestDTO
        {
            public string CostCenterCode { get; set; }
            public int PurchaseTypeID { get; set; }
            public string PurchaseGroup { get; set; }
            public double TotalAmount { get; set; }
            public string CreatorCode { get; set; }
        }
        public class UpdatePRRequest
        {
            public int PurchaseRequistionID { get; set; }
            public string CostCenterCode { get; set; }
            public string PurchaseTypeCode { get; set; }
            public string PurchaseGroup { get; set; }
            public string PlantCode { get; set; }
            public string PurchaseOrganisationCode { get; set; }
            public string VendorCode { get; set; }
            public string CurrencyCode { get; set; }
            public string InsertedBy { get; set; }
            public string InsertedIPAddress { get; set; }
            public string OnBehalfOfFlag { get; set; }
            public string CreatorCode { get; set; }
        }

    }
}
