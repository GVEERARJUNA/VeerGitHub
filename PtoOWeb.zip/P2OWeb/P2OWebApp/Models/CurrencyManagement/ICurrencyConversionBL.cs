﻿using P2OWebApp.Models.Common;

namespace P2OWebApp.Models.CurrencyManagement
{
    public interface ICurrencyConversionBL
    {
        ResponseClass CurrencyConversion(CurrencyConversionMGTDTO currencyConversionMGTDTO);
    }
}