﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.CurrencyManagement
{
    public class CurrencyConversionMGTDTO
    {
        public int CurrencyConversionID { get; set; }
        public int ConversionYear { get; set; }
        public int ConversionMonth { get; set; }
        public string Action { get; set; }
        public string FromCurrency { get; set; }
        public string ToCurrency { get; set; }
        public double ConversionRate { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }
}
