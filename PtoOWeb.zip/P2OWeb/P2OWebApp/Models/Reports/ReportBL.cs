﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Models.Reports
{
    public class ReportBL : IReportBL
    {
        private readonly IServiceConnect _serviceconnect;

        public ReportBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass GetPRReport(PRReportRequestDTO pRReportRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("GetPRReport", pRReportRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }
        public ResponseClass GetHistoricalReport(HistoricalReportDTO historicalReportDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("GetHistoricalReport", historicalReportDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass GetUserDashboard(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("GetUserDashboard", userDashboardRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            string displayAmountUSD = string.Empty;
            string displayAmountGBP = string.Empty;
            dynamic dynamicJson = JsonConvert.DeserializeObject(response.responseJSON.ToString());
            dynamic json = dynamicJson.TileCount;
            try
            {
                double UsdAmount = json[0].TotalPOAmountUSD;
                displayAmountUSD = NumberExtensions.numberFormat(UsdAmount);
                double GBPAmount = json[0].TotalPOAmountGBP;
                displayAmountGBP= NumberExtensions.numberFormat(GBPAmount);
                // object myobject = "{'AmountUSD':" + displayAmountUSD + ",'AmountGBP':" + displayAmountGBP + " }";
                //response.responsedynamic = myobject;
                //response.
                response.usdamount = displayAmountUSD;
                response.gbpamount = displayAmountGBP;
            }
            catch (Exception)
            {

               
            }
            
            return response;

        }

        public List<WaitingApprovalResponceDTO> GetLatestPRDashboard(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<WaitingApprovalResponceDTO> WaitingApprovalResponse = new List<WaitingApprovalResponceDTO>();
            string result = _serviceconnect.PostConnect("GetUserDashboard", userDashboardRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    WaitingApprovalResponse = JsonConvert.DeserializeObject<List<WaitingApprovalResponceDTO>>(response.responseJSON.ToString());
                }

            }
            return WaitingApprovalResponse;

        }

        public ResponseClass GetRDAccress(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<WaitingApprovalResponceDTO> WaitingApprovalResponse = new List<WaitingApprovalResponceDTO>();
            string result = _serviceconnect.PostConnect("GetRDAccress", userDashboardRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (userDashboardRequestDTO.ReportType=="HeaderCount")
            {
                if (response.responseJSONSecondary.ToString().Length > 0)
                {

                    WaitingApprovalResponse = JsonConvert.DeserializeObject<List<WaitingApprovalResponceDTO>>(response.responseJSONSecondary.ToString());
                    response.prList = WaitingApprovalResponse;
                }
            }
            
            return response;

        }

        public List<WaitingApprovalResponceDTO> GetRDAccessPRList(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<WaitingApprovalResponceDTO> WaitingApprovalResponse = new List<WaitingApprovalResponceDTO>();
            string result = _serviceconnect.PostConnect("GetRDAccress", userDashboardRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    WaitingApprovalResponse = JsonConvert.DeserializeObject<List<WaitingApprovalResponceDTO>>(response.responseJSON.ToString());
                }

            }
            return WaitingApprovalResponse;

        }

        public ResponseClass GetWorkFlowReport(WorkflowReportrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("GetWorkFlowReport", request);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }
    }
}
