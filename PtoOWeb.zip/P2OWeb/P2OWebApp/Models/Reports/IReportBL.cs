﻿using P2OWebApp.Models.Common;
using System.Collections.Generic;
using static P2OWebApp.Models.Approval.Approval;

namespace P2OWebApp.Models.Reports
{
    public interface IReportBL
    {
        ResponseClass GetPRReport(PRReportRequestDTO pRReportRequestDTO);
        ResponseClass GetHistoricalReport(HistoricalReportDTO historicalReportDTO);

        ResponseClass GetUserDashboard(UserDashboardRequestDTO userDashboardRequestDTO);

        List<WaitingApprovalResponceDTO> GetLatestPRDashboard(UserDashboardRequestDTO userDashboardRequestDTO);
        ResponseClass GetRDAccress(UserDashboardRequestDTO userDashboardRequestDTO);
        List<WaitingApprovalResponceDTO> GetRDAccessPRList(UserDashboardRequestDTO userDashboardRequestDTO);

        ResponseClass GetWorkFlowReport(WorkflowReportrequestDTO request);
    }
}