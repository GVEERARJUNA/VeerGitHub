﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.AdminManagement
{
    public class UserManagement
    {
        public string UserName { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }

    public class UserManagementResponse
    {
        public int SRNo { get; set; }
        public string EmployeeId { get; set; }
        public string FullName { get; set; }
        public string EmailId { get; set; }
        public string DepartmentName { get; set; }
        public string CurrentRole { get; set; }
        public string UserID { get; set; }
    }

    public class AddUserRequestDTO
    {
        public string UserName { get; set; }
        public string Action { get; set; }
        public string Roles { get; set; }
        public string Companies { get; set; }
    }
    public class AddDelegatorRequestDTO
    {
        public string LoggedInEmpId { get; set; }
        public string Action { get; set; }
        public int DelegatorMappingID { get; set; }
        public string DelgatorEMPCode { get; set; }
        public string DelegateeEMPCode { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string DelegationReason { get; set; }
        public string IPAddress { get; set; }
    }

    public class DelegationGetRequestDTO
    {
        public string EmployeeId { get; set; }
    }

    public class UserRight
    {
        public string UserRightCode { get; set; }
        public string UserRightTitle { get; set; }
    }
    public class SupplierEmployeeMappingRequestDTO
    {
        public string SupplierCode { get; set; }
        public string EmpCode { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public string Action { get; set; }
    }

    public class SupplierList
    {
        public string SupplierCode { get; set; }
    }

    public class ChangeUserTypeDTO
    {
        public string UserName { get; set; }
        public string Action { get; set; }
        public string UserType { get; set; }

    }
}
