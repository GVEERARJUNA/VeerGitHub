﻿using P2OWebApp.Models.Common;
using System.Collections.Generic;

namespace P2OWebApp.Models.AdminManagement
{
    public interface IUserManagementBL
    {
        //List<UserManagementResponse> ManageUsers(UserManagement userManagement);
        ResponseClass ManageUsers(UserManagement userManagement);
        ResponseClass AddUser(AddUserRequestDTO addUserRequestDTO);
        ResponseClass AddDelegator(AddDelegatorRequestDTO addDelegatorRequestDTO);

        ResponseClass GetDelegationDetails(string EmployeeId);
        ResponseClass SupplierEmployeeAssign(SupplierEmployeeMappingRequestDTO supplierEmployeeMappingRequestDTO);
        ResponseClass ChangeUserType(ChangeUserTypeDTO changeUserTypeDTO);
    }
}