﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.AdminManagement
{
    public class UserManagementBL : IUserManagementBL
    {
        private readonly IServiceConnect _serviceconnect;

        public UserManagementBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        //public List<UserManagementResponse> ManageUsers(UserManagement userManagement)
         public ResponseClass ManageUsers(UserManagement userManagement)
        {
            ResponseClass response = new ResponseClass();
            List<UserManagementResponse> responseList = new List<UserManagementResponse>();
            string result = _serviceconnect.PostConnect("ManageUser", userManagement);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    responseList = JsonConvert.DeserializeObject<List<UserManagementResponse>>(response.responseJSON.ToString());
                }

            }
            response.userManagementResponses = responseList;
            return response;

        }

        public ResponseClass AddUser(AddUserRequestDTO addUserRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("AddUser", addUserRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;
        }

        public ResponseClass AddDelegator(AddDelegatorRequestDTO addDelegatorRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("AddDelegator", addDelegatorRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;
        }

        public ResponseClass GetDelegationDetails(string EmployeeId)
        {
            DelegationGetRequestDTO delegationGetRequestDTO = new DelegationGetRequestDTO();
            delegationGetRequestDTO.EmployeeId = EmployeeId;
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("GetDelegationDetails", delegationGetRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass SupplierEmployeeAssign(SupplierEmployeeMappingRequestDTO supplierEmployeeMappingRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("SupplierEmployeeAssign", supplierEmployeeMappingRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;
        }

        public ResponseClass ChangeUserType(ChangeUserTypeDTO changeUserTypeDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("ChangeUserType", changeUserTypeDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;
        }
    }
}
