﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Header
{
    public class HeaderDataResponse
    {
        public List<MenuMaster> MenuMaster { get; set; }
        public List<CompanyCode> CompanyCode { get; set; }
        public List<ToDoTask> ToDoTask { get; set; }
        public List<RecentPR> RecentPR { get; set; }
    }

    public class HeaderDataRequestBO
    {
        public string UserName { get; set; }
        public string CurrentRole { get; set; }
        public string SAPCompanyCode { get; set; }

    }

    public class ToDoTask
    {
        public int TotalNo { get; set; }
        public string RowType { get; set; }
    }

    public class RecentPR
    {
        public string RequistionNo { get; set; }

        public string OrgReqNo { get; set; }
    }
}
