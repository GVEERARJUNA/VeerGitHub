﻿namespace P2OWebApp.Models.Header
{
    public interface IHeaderDataBL
    {
        HeaderDataResponse GetDashboardData(HeaderDataRequestBO headerDataRequestBO);
    }
}