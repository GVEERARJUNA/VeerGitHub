﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Header
{
    public class HeaderDataBL : IHeaderDataBL
    {
        private readonly IServiceConnect _serviceconnect;

        public HeaderDataBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public HeaderDataResponse GetDashboardData(HeaderDataRequestBO headerDataRequestBO)
        {
            ResponseClass response = new ResponseClass();
            HeaderDataResponse headerData = new HeaderDataResponse();
            string result = _serviceconnect.PostConnect("GetDashboardData", headerDataRequestBO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length>0)
                {
                    headerData = JsonConvert.DeserializeObject<HeaderDataResponse>(response.responseJSON.ToString());
                }
                
            }
            return headerData;

        }
    }
}
