﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Masters
{
    public class MasterDataRequest
    {
        public string EntityName { get; set; }
        public string SearchParameter1 { get; set; }
        public string SearchParameter2 { get; set; }
        public string EmployeeID { get; set; }
        public string SearchAs { get; set; }
        public string CompanyCode { get; set; }
    }
    public class MasterDataResponse
    {
        public int SRNo { get; set; }
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
        public string Companycode { get; set; }
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string AddedOnDate { get; set; }
        public string InsertedBy { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedOn { get; set; }
        public string materialImage { get; set; }
        public int CheckStatus { get; set; }
        public int isDefault { get; set; }
        public int isCompanyVisible { get; set; }
        public string DisplayControl { get; set; }



    }

    public class purchaseRequistionMaster
    {
        public List<PurchaseType> purchaseTypes { get; set; }
        public List<PurchaseGroup> purchaseGroups { get; set; }
        public List<Currency> currencies { get; set; }
        public List<GLCode> gLCodes { get; set; }
        public List<Vendor> vendors { get; set; }
        public List<PurchaseOrganisation> purchaseOrganisations { get; set; }
        public List<PlantCode> plantCodes { get; set; }
        public List<CostCenter> costCenters { get; set; }

        public List<FormFields> formFields { get; set; }

    }

    public class MyMasterData
    {
        public List<PurchaseType> purchaseTypes { get; set; }
        public List<PurchaseGroup> purchaseGroups { get; set; }
        public List<Currency> currencies { get; set; }
        public List<GLCode> gLCodes { get; set; }
        public List<Vendor> vendors { get; set; }
        public List<PurchaseOrganisation> purchaseOrganisations { get; set; }
        public List<PlantCode> plantCodes { get; set; }
        public List<CostCenter> costCenters { get; set; }
        public List<MaterialMaster> materialMasters { get; set; }
        public List<UserMaster> userMasters { get; set; }
        public List<ServiceMaterial> serviceMaterial { get; set; }
        public List<StatusMaster> statusMaster { get; set; }
    }

    public class PurchaseType
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }
    public class PurchaseGroup
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }
    public class Currency
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }
    public class CostCenter
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
        
    }
    public class GLCode
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }
    public class Vendor
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }
    public class PurchaseOrganisation
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }

    public class PlantCode
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }

    public class MaterialMaster
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }

    public class UserMaster
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }

    public class ServiceMaterial
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }
    public class StatusMaster
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }

    public class MasterData
    {
        public string MasterType { get; set; }
        public List<PurchaseType> purchaseTypes { get; set; }
        public List<PurchaseGroup> purchaseGroups { get; set; }
        public List<Currency> currencies { get; set; }
        public List<GLCode> gLCodes { get; set; }
        public List<Vendor> vendors { get; set; }
        public List<PurchaseOrganisation> purchaseOrganisations { get; set; }
        public List<PlantCode> plantCodes { get; set; }
        public List<CostCenter> costCenters { get; set; }
        public List<MaterialMaster> materialMasters { get; set; }
        public List<ServiceMaterial> serviceMaterial { get; set; }
        public List<StatusMaster> statusMaster { get; set; }
    }

    public class MasterDataRequestDTO
    {
        public string MasterType { get; set; }
        public string CompanyCode { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public string CostCenterSearch { get; set; }
    }

    public class CompanyMaster
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }

    public class ApplicationConfigDTORequest
    {
        public int ApplicationConfigID { get; set; }
        public string SearchString { get; set; }
        public string Action { get; set; }
        public string PropertyName { get; set; }
        public string PropertyValue { get; set; }
        public string Remarks { get; set; }
        public string InsertdBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }

     public class CostConfigInsertRequestDTO
    {
        public int CostCenterConfigID { get; set; }
        public string CostCenterCode { get; set; }
        public int RoleMasterId { get; set; }
        public string RoleEmpCode { get; set; }
        public string Action { get; set; }
    }

    public class CostConfigGetRequestDTO
    {
        public int CostCenterConfigID { get; set; }
        public string CostCenterCode { get; set; }

        public string RoleEmpCode { get; set; }
        public string DeletedBy { get; set; }
        
    }

    public class MaterialImagaeManageDTO
    {

        public string Action { get; set; }
        public string Type { get; set; }
        public string MatCode { get; set; }
        public string MatImage { get; set; }
        public string InsertedBy { get; set; }
        public string InsetedIPAddresss { get; set; }
    }

    //public class GetMenueMasterDetailsDTO
    //{
    //    public string MenuName { get; set; }
    //    public string MenuUrl { get; set; }
    //    public string ParentMenu { get; set; }
    //}
    public class MenuMasterDetailsRequestDTO
    {
        public string SerachParm { get; set; }
        public string Action { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public int MenuMasteId { get; set; }
        public int LoggedInEmpId { get; set; }
    }

    public class MenuMasterDetailsInsertDTO
    {
        public string Action { get; set; }
        public int ParentMenuID { get; set; }
        public string MenuName { get; set; }
        public string MenuUrl { get; set; }
        public int LoggedInEmpId { get; set; }
    }

    public class MenuUserMappingDetailsRequestDTO
    {
        public string SerachParm { get; set; }
        public string Action { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public int LoggedInEmpId { get; set; }
        public string UserType { get; set; }
        public int MappingId { get; set; }
    }

    public class MenuUserMappingInsertDTO
    {
        public string Action { get; set; }
        public string UserTypeCode { get; set; }
        public int MenuID { get; set; }
    }
    public class PRSPOCRequestDTO
    {
        public string Action { get; set; }
        public int PRSPOCGroupID { get; set; }
        public string EmployeeID { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

        public int PRSPOCMemberID { get; set; }
        public string PRSPOCGroupTitle { get; set; }
    }

    public class FormFields
    {
        public string ValueField { get; set; }
        public string DisplayField { get; set; }
    }
    public class MastersInsertRequestDTO
    {
        public string Action { get; set; }
        public string CompanyCode { get; set; }
        public string IParam1 { get; set; }
        public string IParam2 { get; set; }
        public string IParam3 { get; set; }
        public string IParam4 { get; set; }
        public string IParam5 { get; set; }
        public string IParam6 { get; set; }
        public string IParam7 { get; set; }
        public string IParam8 { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }

    public class ApprovalConfigRequestDTO
    {
        public string Action { get; set; }
        public string CompanyCode { get; set; }
        public List<ApprovalConfigRequest> approvalConfigRequests { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public int PrimaryID { get; set; }
    }

    public class ApprovalConfigRequest
    {

        public int Level { get; set; }

        public string RoleName { get; set; }

        public int RoleCode { get; set; }
        public string EMPCode { get; set; }
        public string AppType { get; set; }
        public int PurchaseTypeID { get; set; }
        public string PGCategoryCode { get; set; }
        public int AmountApplicableFlag { get; set; }
        public string CalculateSymbol { get; set; }
        public double FromAmount { get; set; }
        public double ToAmount { get; set; }
    }
}
