﻿using P2OWebApp.Models.Common;
using System.Collections.Generic;

namespace P2OWebApp.Models.Masters
{
    public interface IMasterDataBL
    {
        ResponseClass GetCommonEntity(MasterDataRequest masterDataRequest);
        ResponseClass GetMasterData(MasterDataRequestDTO masterDataRequestDTO);

        purchaseRequistionMaster GetPRRequistionMaster(MasterDataRequest masterDataRequest);
        ResponsePagination GetMasterData_V1(MasterDataRequestDTO masterDataRequestDTO);

        ResponseClass ApplicationConfigSetting(ApplicationConfigDTORequest applicationConfigDTORequest);
        ResponseClass InsertCostCenterConfig(CostConfigInsertRequestDTO updateRequestDTO);
        ResponseClass GetCostCenterConfig(CostConfigGetRequestDTO masterDataRequestDTO);
        ResponseClass DeleteCostCenterRoleConfig(CostConfigGetRequestDTO masterDataRequestDTO);

        ResponseClass MaterialImageManage(MaterialImagaeManageDTO materialImagaeManageDTO);
        ResponseClass GetMenuMaster(MenuMasterDetailsRequestDTO menueMasterRequestDTO);
        ResponseClass GetParentMenuMaster();
        ResponseClass InsertMenuMaster(MenuMasterDetailsInsertDTO masterDetailsInsertDTO);
        ResponseClass DeleteMenuMaster(int MenuId, int LoggedInEmpId);
        ResponseClass GetUserTypeMaster();
        ResponseClass GetMenuMasterType(string UserType);
        ResponseClass GetMenuUserMapping(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO);
        ResponseClass InsertMenuUserMapping(MenuUserMappingInsertDTO userMappingInsertDTO);
        ResponseClass DeleteUserMenuMapping(int MenuId);
        ResponseClass PRSPOCGroupManage(PRSPOCRequestDTO pRSPOCRequestDTO);
        ResponseClass MastersInsert(MastersInsertRequestDTO mastersInsertRequestDTO);
        ResponseClass ManageCompanyApprovalFlow(ApprovalConfigRequestDTO request);
        ResponseClass DeleteApprovalFlow(int PrimaryId);
    }
}