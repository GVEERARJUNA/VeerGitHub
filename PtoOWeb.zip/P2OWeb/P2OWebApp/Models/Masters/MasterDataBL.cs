﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Masters
{
    public class MasterDataBL : IMasterDataBL
    {
        private readonly IServiceConnect _serviceconnect;

        public MasterDataBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass GetCommonEntity(MasterDataRequest masterDataRequest)
        {
            ResponseClass response = new ResponseClass();
            List<MasterDataResponse> MasterDataResponse = new List<MasterDataResponse>();
            string result = _serviceconnect.PostConnect("GetCommonEntity", masterDataRequest);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                try
                {
                    if (response.responseJSON.ToString().Length > 0)
                    {
                        MasterDataResponse = JsonConvert.DeserializeObject<List<MasterDataResponse>>(response.responseJSON.ToString());
                    }
                }
                catch (Exception)
                {

                   
                }
               
            }

            response.masterDataResponses = MasterDataResponse;
            return response;

        }

        public purchaseRequistionMaster GetPRRequistionMaster(MasterDataRequest masterDataRequest)
        {
            ResponseClass response = new ResponseClass();
            //List<MasterDataResponse> MasterDataResponse = new List<MasterDataResponse>();
            purchaseRequistionMaster purchaseRequistionMaster = new purchaseRequistionMaster();

            string result = _serviceconnect.PostConnect("GetCommonEntity", masterDataRequest);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {

                    purchaseRequistionMaster = JsonConvert.DeserializeObject<purchaseRequistionMaster>(Base64Decode(response.responseJSON.ToString()));

                }
            }

            
            return purchaseRequistionMaster;

        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public ResponseClass GetMasterData(MasterDataRequestDTO masterDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<MasterDataResponse> MasterDataResponse = new List<MasterDataResponse>();
            string result = _serviceconnect.PostConnect("GetMasterData", masterDataRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    MasterDataResponse = JsonConvert.DeserializeObject<List<MasterDataResponse>>(response.responseJSON.ToString());
                }

            }
            response.masterDataResponses = MasterDataResponse;
            return response;

        }
        public ResponsePagination GetMasterData_V1(MasterDataRequestDTO masterDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<MasterDataResponse> MasterDataResponse = new List<MasterDataResponse>();
            string result = _serviceconnect.PostConnect("GetMasterData", masterDataRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    MasterDataResponse = JsonConvert.DeserializeObject<List<MasterDataResponse>>(response.responseJSON.ToString());
                }
            }
            ResponsePagination responsePagination = new ResponsePagination();
            responsePagination.RecordCount = response.recordCount;
            responsePagination.costCenter = MasterDataResponse;

            return responsePagination;

        }

        public ResponseClass ApplicationConfigSetting(ApplicationConfigDTORequest applicationConfigDTORequest)
        {
            ResponseClass response = new ResponseClass();
            List<MasterDataResponse> MasterDataResponse = new List<MasterDataResponse>();
            string result = _serviceconnect.PostConnect("ApplicationConfigSetting", applicationConfigDTORequest);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            //if (response.responseCode == 1)
            //{
            //    if (response.responseJSON.ToString().Length > 0)
            //    {
            //        MasterDataResponse = JsonConvert.DeserializeObject<List<MasterDataResponse>>(response.responseJSON.ToString());
            //    }
            //}

            //response.masterDataResponses = MasterDataResponse;
            return response;

        }

        public ResponseClass InsertCostCenterConfig(CostConfigInsertRequestDTO updateRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("InsertCostCenterConfig", updateRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }


        public ResponseClass GetCostCenterConfig(CostConfigGetRequestDTO masterDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("CostConfigGet", masterDataRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass DeleteCostCenterRoleConfig(CostConfigGetRequestDTO masterDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("DeleteCostCenterRoleConfig", masterDataRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass MaterialImageManage(MaterialImagaeManageDTO materialImagaeManageDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("MaterialImageManage", materialImagaeManageDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
           
            return response;

        }

        public ResponseClass GetMenuMaster(MenuMasterDetailsRequestDTO menueMasterRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("GetMenuMaster", menueMasterRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;

        }

        public ResponseClass GetParentMenuMaster()
        {
            ResponseClass response = new ResponseClass();
            List<MasterDataResponse> MasterDataResponse = new List<MasterDataResponse>();
            string result = _serviceconnect.PostConnect("GetParentMenuMaster", null);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    MasterDataResponse = JsonConvert.DeserializeObject<List<MasterDataResponse>>(response.responseJSON.ToString());
                }
            }
            response.masterDataResponses = MasterDataResponse;
            return response;
        }

        public ResponseClass InsertMenuMaster(MenuMasterDetailsInsertDTO masterDetailsInsertDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("InsertMenuMaster", masterDetailsInsertDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;
        }

        public ResponseClass DeleteMenuMaster(int MenuId , int LoggedInEmpId)
        {
            MenuMasterDetailsRequestDTO masterDetailsRequestDTO = new MenuMasterDetailsRequestDTO();
            masterDetailsRequestDTO.MenuMasteId = MenuId;
            masterDetailsRequestDTO.Action = "Delete";
            masterDetailsRequestDTO.LoggedInEmpId = LoggedInEmpId;
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("DeleteMenuMaster", masterDetailsRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass GetUserTypeMaster()
        {
            ResponseClass response = new ResponseClass();
            List<MasterDataResponse> MasterDataResponse = new List<MasterDataResponse>();
            string result = _serviceconnect.PostConnect("GetUserTypeMaster", null);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    MasterDataResponse = JsonConvert.DeserializeObject<List<MasterDataResponse>>(response.responseJSON.ToString());
                }
            }
            response.masterDataResponses = MasterDataResponse;
            return response;
        }

        public ResponseClass GetMenuMasterType(string UserType)
        {
            MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO = new MenuUserMappingDetailsRequestDTO();
            userMappingDetailsRequestDTO.UserType = (UserType == null || UserType == "0") ? "" : UserType;
            ResponseClass response = new ResponseClass();
            List<MasterDataResponse> MasterDataResponse = new List<MasterDataResponse>();
            string result = _serviceconnect.PostConnect("GetMenuMasterType", userMappingDetailsRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    MasterDataResponse = JsonConvert.DeserializeObject<List<MasterDataResponse>>(response.responseJSON.ToString());
                }
            }
            response.masterDataResponses = MasterDataResponse;
            return response;
        }

        public ResponseClass GetMenuUserMapping(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("GetMenuUserMapping", userMappingDetailsRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;

        }


        public ResponseClass InsertMenuUserMapping(MenuUserMappingInsertDTO userMappingInsertDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("InsertMenuUserMapping", userMappingInsertDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;
        }

        public ResponseClass DeleteUserMenuMapping(int MenuId)
        {
            MenuUserMappingDetailsRequestDTO masterDetailsRequestDTO = new MenuUserMappingDetailsRequestDTO();
            masterDetailsRequestDTO.MappingId = MenuId;
            masterDetailsRequestDTO.Action = "Delete";
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("DeleteUserMenuMapping", masterDetailsRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass PRSPOCGroupManage(PRSPOCRequestDTO pRSPOCRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("PRSPOCGroupManage", pRSPOCRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            return response;

        }

        public ResponseClass MastersInsert(MastersInsertRequestDTO mastersInsertRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("MastersInsert", mastersInsertRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass ManageCompanyApprovalFlow(ApprovalConfigRequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            string result = _serviceconnect.PostConnect("ManageCompanyApprovalFlow", request);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }

        public ResponseClass DeleteApprovalFlow(int PrimaryId)
        {
           ApprovalConfigRequestDTO approvalConfigRequestDTO = new ApprovalConfigRequestDTO();
            // masterDetailsRequestDTO.MappingId = MenuId;
            approvalConfigRequestDTO.PrimaryID = PrimaryId;
            approvalConfigRequestDTO.Action = "Delete";
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("DeleteApprovalFlow", approvalConfigRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);

            return response;

        }
    }
}
