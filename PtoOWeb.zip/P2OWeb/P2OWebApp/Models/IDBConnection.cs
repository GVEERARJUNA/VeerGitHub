﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models
{
    public class IDBConnection
    {
        public string WEBAPI { get; set; }
        public int isRedirect { get; set; }
        public string RedirectLink { get; set; }
        public string P2OBaseURL { get; set; }
        public string BucketName { get; set; }
        public string AccessKey { get; set; }
        public string SecretKey { get; set; }
    }
}
