﻿using P2OWebApp.Models.Masters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Common
{
    public class ResponsePagination
    {
        public int RecordCount { get; set; }
        public List<MasterDataResponse> costCenter { get; set; }
    }
}
