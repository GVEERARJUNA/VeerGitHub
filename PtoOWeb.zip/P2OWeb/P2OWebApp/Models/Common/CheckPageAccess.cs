﻿using Microsoft.AspNetCore.Http;
using P2OWebApp.Models.Header;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Common
{
    public static class CheckPageAccess
    {
        static List<AccessEntity> accessEntities = new List<AccessEntity>();


        public static Boolean PageAccess(string PageName, List<MenuMaster> menus)
        {
            
            var checkAccess = menus.Where(x => x.MenuUrl.Trim()==PageName.Trim()).FirstOrDefault();
            if (checkAccess != null && !string.IsNullOrEmpty(checkAccess.MenuUrl))
            {
                return true;
            }

            return false;
        }
    }

    public class AccessEntity
    {
        public string RoleCode { get; set; }
        public string PageName { get; set; }
    }
}
