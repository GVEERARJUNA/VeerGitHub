﻿using Microsoft.AspNetCore.Http;
using P2OWebApp.Models.AdminManagement;
using P2OWebApp.Models.EmailManagement;
using P2OWebApp.Models.Masters;
using P2OWebApp.Models.Website;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using static P2OWebApp.Models.Approval.Approval;
namespace P2OWebApp.Models.Common
{
    public class ResponseClass
    {
        public int recordCount { get; set; }
        public int responseCode { get; set; }
        public string responseMessage { get; set; }
        public object responseJSON { get; set; }
        public object responseJSONSecondary { get; set; }
        public string responsecompress { get; set; }
        public string responseReturnNo { get; set; }
        public List<ProductResponse> productList { get; set; }
        public List<MasterDataResponse> masterDataResponses { get; set; }
        public List<UserManagementResponse> userManagementResponses { get; set; }
        public List<EmailMGTResponseDTO>  emailMGTResponses { get; set; }

        public List<WaitingApprovalResponceDTO> prList { get; set; }
        public dynamic responsedynamic { get; set; }
        public string usdamount { get; set; }
        public string gbpamount { get; set; }

    }
}
