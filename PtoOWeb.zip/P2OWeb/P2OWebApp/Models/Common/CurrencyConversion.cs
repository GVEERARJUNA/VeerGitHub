﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Common
{
    public static class CurrencyConversion
    {
        public static string FormatCurrency(string CurrencyCode, double Amount)
        {
            //https://csharp.net-tutorials.com/working-with-culture-and-regions/the-cultureinfo-class/
            string currencyText = string.Empty;
            if (CurrencyCode == "INR")
            {
                decimal parsed = decimal.Parse(Amount.ToString(), CultureInfo.InvariantCulture);
                CultureInfo hindi = new CultureInfo("hi-IN");
                currencyText = string.Format(hindi, "{0:c}", parsed);
            }
            else if (CurrencyCode == "USD")
            {
                decimal parsed = decimal.Parse(Amount.ToString(), CultureInfo.InvariantCulture);
                CultureInfo hindi = new CultureInfo("en-US");
                currencyText = string.Format(hindi, "{0:c}", parsed);
            }
            else if (CurrencyCode == "GBP")
            {
                decimal parsed = decimal.Parse(Amount.ToString(), CultureInfo.InvariantCulture);
                CultureInfo hindi = new CultureInfo("en-GB");
                currencyText = string.Format(hindi, "{0:c}", parsed);
            }
            else if (CurrencyCode == "AED")
            {
                decimal parsed = decimal.Parse(Amount.ToString(), CultureInfo.InvariantCulture);
                CultureInfo hindi = new CultureInfo("ar-AE");
                currencyText = string.Format(hindi, "{0:c}", parsed);
            }
            else if (CurrencyCode == "PHP")
            {
                decimal parsed = decimal.Parse(Amount.ToString(), CultureInfo.InvariantCulture);
                CultureInfo hindi = new CultureInfo("fil-PH");
                currencyText = string.Format(hindi, "{0:c}", parsed);
            }
            else if (CurrencyCode == "CAD")
            {
                decimal parsed = decimal.Parse(Amount.ToString(), CultureInfo.InvariantCulture);
                CultureInfo hindi = new CultureInfo("en-CA");
                currencyText = string.Format(hindi, "{0:c}", parsed);
            }
            else
            {
                decimal parsed = decimal.Parse(Amount.ToString(), CultureInfo.InvariantCulture);
               
                currencyText = CurrencyCode + " " + string.Format("{0:0,0.00}", parsed);
            }



            return currencyText;

        }
    }
}
