﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.Common
{
	public static class NumberExtensions
	{
		/// <summary>
		///     Formats a large number to 5 digits (2 decimal places) with a suffix. (e.g. 123,456,789,123 (123 Billion) ->
		///     123.45B)
		/// </summary>
		/// <param name="numberToFormat"> The number to format. </param>
		/// <param name="decimalPlaces"> The number of decimal places to include - <i> defaults to <c> 2 </c> </i> </param>
		/// <returns> A <see cref="string" />. </returns>
		public enum suffixes
		{
			p, // p is a placeholder if the value is under 1 thousand
			K, // Thousand
			M, // Million
			B, // Billion
			T, // Trillion
			Q, //Quadrillion
		}

		//Formats numbers in Millions, Billions, etc.
		public static string numberFormat(double money)
		{
			int decimals = 2; //How many decimals to round to
			string r = money.ToString(); //Get a default return value

			foreach (suffixes suffix in Enum.GetValues(typeof(suffixes))) //For each value in the suffixes enum
			{
				var currentVal = 1 * Math.Pow(10, (int)suffix * 3); //Assign the amount of digits to the base 10
				var suff = Enum.GetName(typeof(suffixes), (int)suffix); //Get the suffix value
				if ((int)suffix == 0) //If the suffix is the p placeholder
					suff = String.Empty; //set it to an empty string

				if (money >= currentVal)
					r = Math.Round((money / currentVal), decimals, MidpointRounding.ToEven).ToString() + suff; //Set the return value to a rounded value with suffix
				else
					return r; //If the value wont go anymore then return
			}
			return r; // Default Return
		}
	}
}
