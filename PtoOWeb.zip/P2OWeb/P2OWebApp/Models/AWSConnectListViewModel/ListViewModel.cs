﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.AWSConnectListViewModel
{
    public class ListViewModel
    {
        public string PRNumber { get; set; }
        public string CompanyCode { get; set; }
        public IEnumerable<DataModel> FileDetails { get; set; }
        public string BaseURL { get; set; }
    }
}
