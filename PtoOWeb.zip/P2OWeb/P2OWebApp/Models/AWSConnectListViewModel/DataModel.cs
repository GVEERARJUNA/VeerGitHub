﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.AWSConnectListViewModel
{
    public class DataModel
    {
        public string UserFileName { get; set; }
        public string ActualFileName { get; set; }
        public string CompanyCode { get; set; }
        public string PrNumber { get; set; }
    }

    public class NodeDetails
    {
        public string id { get; set; }
        public string pId { get; set; }
        public string file { get; set; }
        public string name { get; set; }
        public string open { get; set; }
    }
    public class FileModel
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public bool IsSelected { get; set; }
    }
}

