﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.SessionManagement
{
    public class LoggedInUserModel
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string FullName
        {
            get
            {
                return $"{FirstName} {LastName}";
            }
        }

        public string EmployeeId { get; set; }
        public string EmailId { get; set; }

        public string CountryName { get; set; }
        public string CompanyCode { get; set; }
        public string CompanyName { get; set; }
        public string DepartmentName { get; set; }
        public string SubprocessName { get; set; }

        public string CurrentRoleName { get; set; }
        public IEnumerable<string> AssignedRoles { get; set; }

        public string Photo { get; set; }
        public string CostCenter { get; set; }

        public string SAPCompanyCode { get; set; }
        public int IsCatalogueEnable { get; set; }
    }
}
