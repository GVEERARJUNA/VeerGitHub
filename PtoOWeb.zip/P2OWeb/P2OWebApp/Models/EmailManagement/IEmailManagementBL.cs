﻿using P2OWebApp.Models.Common;

namespace P2OWebApp.Models.EmailManagement
{
    public interface IEmailManagementBL
    {
        ResponseClass EmailManagementSetting(EmailMGTRequestDTO emailMGTRequestDTO);
        ResponseClass UpdateEmailManagementSetting(EmailMGTUpdateDTO emailMGTUpdateDTO);
    }
}