﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.EmailManagement
{
    public class EmailMGTRequestDTO
    {
        public int EmailMasterID { get; set; }
        public string Action { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

    }
    public class EmailMGTUpdateDTO
    {
        public int EmailMasterID { get; set; }
        public string Action { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public string EmailSubject { get; set; }
        public string EmailTemplate { get; set; }

    }
}
