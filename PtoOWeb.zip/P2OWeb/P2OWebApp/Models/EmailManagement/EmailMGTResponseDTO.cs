﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.EmailManagement
{
    public class EmailMGTResponseDTO
    {
        public int EmailMasterID { get; set; }
        public string EmailSubject { get; set; }
        public string EmailTemplate { get; set; }

    }
}
