﻿using Newtonsoft.Json;
using P2OWebApp.Models.Common;
using P2OWebApp.Models.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp.Models.EmailManagement
{
    public class EmailManagementBL : IEmailManagementBL
    {
        private readonly IServiceConnect _serviceconnect;

        public EmailManagementBL(IServiceConnect serviceconnect)
        {
            _serviceconnect = serviceconnect;
        }

        public ResponseClass EmailManagementSetting(EmailMGTRequestDTO emailMGTRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            List<EmailMGTResponseDTO> emailMGTResponse = new List<EmailMGTResponseDTO>();
            string result = _serviceconnect.PostConnect("EmailManagementSetting", emailMGTRequestDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);
            if (response.responseCode == 1)
            {
                if (response.responseJSON.ToString().Length > 0)
                {
                    emailMGTResponse = JsonConvert.DeserializeObject<List<EmailMGTResponseDTO>>(response.responseJSON.ToString());
                }

            }
            response.responseCode = 1;
            response.recordCount = emailMGTResponse.Count();
            response.emailMGTResponses = emailMGTResponse;
            return response;

        }

        public ResponseClass UpdateEmailManagementSetting(EmailMGTUpdateDTO emailMGTUpdateDTO)
        {
            ResponseClass response = new ResponseClass();
            string result = _serviceconnect.PostConnect("UpdateEmailDetails", emailMGTUpdateDTO);
            response = JsonConvert.DeserializeObject<ResponseClass>(result);            
            return response;

        }
    }
}
