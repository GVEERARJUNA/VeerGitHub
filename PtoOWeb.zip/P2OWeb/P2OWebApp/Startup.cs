using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using P2OWebApp.Models;
using P2OWebApp.Models.AdminManagement;
using P2OWebApp.Models.Approval;
using P2OWebApp.Models.ApprovalMapping;
using P2OWebApp.Models.AppStats;
using P2OWebApp.Models.Audit;
using P2OWebApp.Models.CatalogueManagement;
using P2OWebApp.Models.CurrencyManagement;
using P2OWebApp.Models.EmailManagement;
using P2OWebApp.Models.Header;
using P2OWebApp.Models.Masters;
using P2OWebApp.Models.Reports;
using P2OWebApp.Models.Service;
using P2OWebApp.Models.ShoppingCart;
using P2OWebApp.Models.Website;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace P2OWebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();

            services.Configure<IDBConnection>(Configuration.GetSection("Configuration"));
            services.AddScoped<IServiceConnect, ServiceConnect>();
            services.AddScoped<ILoginRequestBL, LoginRequestBL>();
            services.AddScoped<IHeaderDataBL, HeaderDataBL>();
            services.AddScoped<IProductBL, ProductBL>();
            services.AddScoped<IMasterDataBL, MasterDataBL>();
            services.AddScoped<IShoppingCartBL, ShoppingCartBL>();
            services.AddScoped<IApprovalBL, ApprovalBL>();
            services.AddScoped<IUserManagementBL, UserManagementBL>();
            services.AddScoped<IApprovalMappingBL, ApprovalMappingBL>();
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<IReportBL, ReportBL>();
            services.AddScoped<IEmailManagementBL, EmailManagementBL>();
            services.AddScoped<IAuditBL, AuditBL>();
            services.AddScoped<ICatalogueManagementBL, CatalogueManagementBL>();
            services.AddScoped<IAppStatsBL, AppStatsBL>();
            services.AddScoped<ICurrencyConversionBL, CurrencyConversionBL>();
            //Added for session state
            services.AddDistributedMemoryCache();

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30);
            });

            //services.AddMvc(options =>
            //{
            //    options.CacheProfiles.Add("default", new CacheProfile
            //    {
            //        Duration = 30,
            //        Location = ResponseCacheLocation.None,
            //        NoStore = false
            //    });
            //});
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            var path = Directory.GetCurrentDirectory();
            loggerFactory.CreateLogger($"{path}\\Logs\\Log.txt");
            

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }
            // Set up custom content types - associating file extension to MIME type    var provider = new FileExtensionContentTypeProvider();
            // Replace an existing mapping    provider.Mappings[".msg"] = "application/vnd.ms-outlook";


            // Set up custom content types - associating file extension to MIME type
            //var provider = new FileExtensionContentTypeProvider();
            //// Replace an existing mapping
            //provider.Mappings[".msg"] = "application/vnd.ms-outlook";
            // Set up custom content types - associating file extension to MIME type
            var provider = new FileExtensionContentTypeProvider();
            // Add new mappings
            //provider.Mappings[".myapp"] = "application/x-msdownload";
            //provider.Mappings[".htm3"] = "text/html";
            //provider.Mappings[".image"] = "image/png";
            //provider.Mappings[".image"] = "image/jpg";
            provider.Mappings[".msg"] = "application/vnd.ms-outlook";
            // Replace an existing mapping
            provider.Mappings[".rtf"] = "application/x-msdownload";
           
            app.UseStaticFiles(new StaticFileOptions
            {
                OnPrepareResponse = ctx =>
                {

                    ctx.Context.Response.Headers[HeaderNames.CacheControl] =
                        "no-cache, no-store,private,Pragma:no-cache,max-age=0";
                },
                ContentTypeProvider = provider
                //FileProvider = new PhysicalFileProvider(
                //    Path.Combine(Directory.GetCurrentDirectory(), "wwwroot","assets", "documents")),
                //RequestPath = "/StaticContentDir",
                //ContentTypeProvider = provider
            });
            //app.Use(async (context, next) =>
            //{
            //    context.Response.GetTypedHeaders().CacheControl =
            //     new Microsoft.Net.Http.Headers.CacheControlHeaderValue()
            //     {
            //         Public = false,
            //         MaxAge = TimeSpan.FromSeconds(60),
            //         NoStore = false,
            //         NoCache=true,
            //         Private=true
            //     };
            //    await next();
            //});

            app.UseRouting();

            app.UseAuthorization();

            app.UseSession();

          //  app.UseCookiePolicy(
          //new CookiePolicyOptions
          //{
          //    HttpOnly = HttpOnlyPolicy.Always,
          //    Secure = CookieSecurePolicy.Always
          //});

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Auth}/{action=Index}/{id?}");
            });
        }
    }
}
