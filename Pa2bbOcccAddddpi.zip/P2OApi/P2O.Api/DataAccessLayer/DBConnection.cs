﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace P2ODAL
{
	public class DBConnection
	{
		string connString = string.Empty;

		private IConfiguration configuration;

		public DBConnection()
        {
			
		}
		public DBConnection(string dbConnection)
	    {
			connString = dbConnection;
			

		}

		

		public  DataSet ExecuteDataSet(string procName, SqlParameter[] paramters, List<OutParameter> outparameter)

		{
			DataSet result = null;
			
			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					using (SqlDataAdapter sda = new SqlDataAdapter(command))
					{
						command.CommandType = System.Data.CommandType.StoredProcedure;
						command.CommandText = procName;
						if (paramters != null)
						{
							command.Parameters.AddRange(paramters);
						}
						result = new DataSet();
						sda.Fill(result);

						foreach (SqlParameter item in paramters)
						{
							if (item.Direction == ParameterDirection.Output)
							{
								outparameter.Add(new OutParameter { ParameterName = item.ParameterName, ParameterValue = Convert.ToString(item.Value) });

							}

						}
					}
				}
			}
			return result;
		}

		public  int ExecuteNonQuery(string procName,SqlParameter[] paramters,List<OutParameter> outparameter)

		{
			//connString = configuration.GetSection("ConnectionStrings").GetSection("MasterDatabase").Value;
			int result= 0;
			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					command.CommandType = System.Data.CommandType.StoredProcedure;
					command.CommandText = procName;
					if (paramters != null)
					{
						command.Parameters.AddRange(paramters);
					}
					sqlConnection.Open();
					result = command.ExecuteNonQuery();

					foreach (SqlParameter item in paramters)
					{
						if (item.Direction == ParameterDirection.Output)
						{
							outparameter.Add(new OutParameter { ParameterName = item.ParameterName, ParameterValue = Convert.ToString(item.Value) });

						}

					}
					
					sqlConnection.Close();

					
				}
			}
			return result;
		}

		public int ExecuteNonQueryTransaction(string procName, SqlParameter[] paramters, List<OutParameter> outparameter)
		{
			//connString = configuration.GetSection("ConnectionStrings").GetSection("MasterDatabase").Value;
			int result = 0;
			SqlTransaction objTrans = null;

			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					command.CommandType = System.Data.CommandType.StoredProcedure;
					command.CommandText = procName;
					if (paramters != null)
					{
						command.Parameters.AddRange(paramters);
					}
					sqlConnection.Open();
					objTrans = sqlConnection.BeginTransaction();
                    try
                    {
						result = command.ExecuteNonQuery();
						objTrans.Commit();

						foreach (SqlParameter item in paramters)
						{
							if (item.Direction == ParameterDirection.Output)
							{
								outparameter.Add(new OutParameter { ParameterName = item.ParameterName, ParameterValue = Convert.ToString(item.Value) });

							}

						}
					}
					catch (Exception ex)
					{
						objTrans.Rollback();
					}
					
					sqlConnection.Close();


				}
			}
			return result;
		}

		public  int ExecuteNonQueryInline(string inlineQuery)

		{
			
			int result = 0;
			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					command.CommandType = System.Data.CommandType.Text;
					command.CommandText = inlineQuery;
					
					sqlConnection.Open();
					result = command.ExecuteNonQuery();

					

					sqlConnection.Close();


				}
			}
			return result;
		}

		public  DataSet ExecuteDataSetQualtrics(string procName, SqlParameter[] paramters, List<OutParameter> outparameter)

		{
			DataSet result = null;
			

			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					using (SqlDataAdapter sda = new SqlDataAdapter(command))
					{
						command.CommandType = System.Data.CommandType.StoredProcedure;
						command.CommandText = procName;
						if (paramters != null)
						{
							command.Parameters.AddRange(paramters);
						}
						result = new DataSet();
						sda.Fill(result);

						foreach (SqlParameter item in paramters)
						{
							if (item.Direction == ParameterDirection.Output)
							{
								outparameter.Add(new OutParameter { ParameterName = item.ParameterName, ParameterValue = Convert.ToString(item.Value) });

							}

						}
					}
				}
			}
			return result;
		}

		public  DataSet ExecuteDataSetQualtricsInline(string inlineQuery)

		{
			DataSet result = null;
			//string connString = ConfigurationManager.ConnectionStrings["Qualtrics_SQLConnectionString"].ConnectionString;

			using (var sqlConnection = new SqlConnection(connString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					using (SqlDataAdapter sda = new SqlDataAdapter(command))
					{
						command.CommandType = System.Data.CommandType.Text;
						command.CommandText = inlineQuery;
						
						result = new DataSet();
						sda.Fill(result);

						
					}
				}
			}
			return result;
		}

		public DataSet ExecuteNonQueryInlineMobile(string inlineQuery,string DBString)

		{

			DataSet result = null;
			//string connString = ConfigurationManager.ConnectionStrings["Qualtrics_SQLConnectionString"].ConnectionString;

			using (var sqlConnection = new SqlConnection(DBString))
			{
				using (var command = sqlConnection.CreateCommand())
				{
					using (SqlDataAdapter sda = new SqlDataAdapter(command))
					{
						command.CommandType = System.Data.CommandType.Text;
						command.CommandText = inlineQuery;

						result = new DataSet();
						sda.Fill(result);


					}
				}
			}
			return result;
		}
	}
}
