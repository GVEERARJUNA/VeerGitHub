﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Error
{
    public class ErrorDTO
    {
        public string ErrorDescription { get; set; }
        public string Url { get; set; }
        public string Source { get; set; }
        public string FileName { get; set; }
    }
}
