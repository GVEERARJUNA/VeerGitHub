﻿using Microsoft.Extensions.Options;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace P2OBAL.AppStats
{
    public class AppStatsBL : IAppStatsBL
    {

        private readonly IOptions<IDBConnection> appSettings;
        public AppStatsBL(IOptions<IDBConnection> app)
        {
            appSettings = app;
        }
        public ResponseClass AppStatInsert(AppStatsBO appStatsBO)
        {
            ResponseClass response = new ResponseClass();

            DBConnection dBConnection = new DBConnection(appSettings.Value.DbConnection);

            if (appStatsBO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "appStatsBO required";
                return response;
            }


            try
            {
                SqlParameter[] parameter = {
                new SqlParameter("@employee_code", Convert.ToString(appStatsBO.employee_code)),
                new SqlParameter("@employee_name", Convert.ToString(appStatsBO.employee_name)),
                new SqlParameter("@country", Convert.ToString(appStatsBO.country)),
                new SqlParameter("@ip_address", Convert.ToString(appStatsBO.ip_address)),
                new SqlParameter("@page_url", Convert.ToString(appStatsBO.page_url)),
                new SqlParameter("@module_name", Convert.ToString(appStatsBO.module_name)),
                new SqlParameter("@page_name", Convert.ToString(appStatsBO.page_name)),
                new SqlParameter("@is_active", Convert.ToInt32(appStatsBO.is_active)),
                new SqlParameter("@appName", Convert.ToString(appStatsBO.appName)),
                new SqlParameter("@applicationCode", Convert.ToString(appStatsBO.applicationCode)),
                new SqlParameter("@session_id", Convert.ToString(appStatsBO.session_id)),
                new SqlParameter("@source", Convert.ToString(appStatsBO.source)),
                new SqlParameter("@medium", Convert.ToString(appStatsBO.medium)),
                new SqlParameter("@device_type", Convert.ToString(appStatsBO.device_type)),
                new SqlParameter("@device_software", Convert.ToString(appStatsBO.device_software)),
                new SqlParameter("@device_model", Convert.ToString(appStatsBO.device_model)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                };


                DataSet dsResult = new DataSet();
                List<OutParameter> outParameters = new List<OutParameter>();
                int result = dBConnection.ExecuteNonQuery("app_usage_stats_insert", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");


                if (result != 0)
                {
                    response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                    response.responseMessage = resultMessage.ParameterValue;


                }
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }


            return response;
        }
    }


}
