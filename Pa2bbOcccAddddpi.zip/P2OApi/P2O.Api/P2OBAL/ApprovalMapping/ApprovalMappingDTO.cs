﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.ApprovalMapping
{
  public  class ApprovalMappingDTO
    {

    }

    public class CostCenterAPRequestList
    {
        public string CostCenterCode { get; set; }
    }

    public class ApprovalLevelRequestList
    {
        public int Level { get; set; }

        public string RoleName { get; set; }

        public int RoleCode { get; set; }
        public string EMPCode { get; set; }
        public string AppType { get; set; }
        public int PurchaseTypeID { get; set; }
        public string PGCategoryCode { get; set; }
        public int AmountApplicableFlag { get; set; }
        public string CalculateSymbol { get; set; }
        public double FromAmount { get; set; }
        public double ToAmount { get; set; }
    }

    public class ApprovalMappingInsertRequestDTO
    {

        public string InsertdBy { get; set; }
        public string InsertedIPAddress { get; set; }

        public List<CostCenterAPRequestList> costCenterAPRequestLists { get; set; }
        public List<ApprovalLevelRequestList> approvalLevelRequestLists { get; set; }
    }

    public class AppHierarchyManageRequestDTO
    {
        public string CostCenterCode { get; set; }
        public string Action { get; set; }
        public string AppHierarchyID { get; set; }
        public int AppLevel { get; set; }
        public int RoleMasterID { get; set; }
        public string RequistionNo { get; set; }
        public string EMPCode { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

        public string AppType { get; set; }
        public int PurchaseTypeID { get; set; }
        public string PGCategoryCode { get; set; }
        public int AmountApplicableFlag { get; set; }
        public string CalculateSymbol { get; set; }
        public double FromAmount { get; set; }
        public double ToAmount { get; set; }

        public List<PRApprovalMatrix> pRApprovalMatrices { get; set; }


    }

    public class PRApprovalMatrix
    {
        public int PRApprovalMatrixID { get; set; }
        public int ApprovalLevel { get; set; }
        public int updateRequired { get; set; }
    }

    public class  CompanyAppFlowRequestDTO
    {
        public string companyCode { get; set; }
        public string InsertdBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public List<ApprovalLevelRequestList> approvalLevelRequestLists { get; set; }
    }
}
