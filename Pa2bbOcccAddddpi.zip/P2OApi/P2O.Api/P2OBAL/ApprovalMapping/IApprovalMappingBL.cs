﻿using P2OBAL.Common;

namespace P2OBAL.ApprovalMapping
{
    public interface IApprovalMappingBL
    {
        ResponseClass ApplicationHierarchyCreate(ApprovalMappingInsertRequestDTO approvalMappingInsertRequestDTO);

        ResponseClass AppHierarchyManage(AppHierarchyManageRequestDTO appHierarchyManageRequestDTO);

    }
}