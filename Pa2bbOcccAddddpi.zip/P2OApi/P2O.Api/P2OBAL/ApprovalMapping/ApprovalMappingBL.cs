﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace P2OBAL.ApprovalMapping
{
    public class ApprovalMappingBL : IApprovalMappingBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;


        public ApprovalMappingBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass ApplicationHierarchyCreate(ApprovalMappingInsertRequestDTO approvalMappingInsertRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (approvalMappingInsertRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "approvalMappingInsertRequestDTO required";
                return response;
            }

            if (!string.IsNullOrEmpty(approvalMappingInsertRequestDTO.InsertdBy) && approvalMappingInsertRequestDTO.InsertdBy.Length > 50)
            {
                response.responseCode = 0;
                response.responseMessage = "approvalMappingInsertRequestDTO.InsertdBy cannot exceed 50 characters!";
                return response;
            }

            if (!string.IsNullOrEmpty(approvalMappingInsertRequestDTO.InsertedIPAddress) && approvalMappingInsertRequestDTO.InsertedIPAddress.Length > 50)
            {
                response.responseCode = 0;
                response.responseMessage = "approvalMappingInsertRequestDTO.InsertedIPAddress cannot exceed 100 characters!";
                return response;
            }

            if (approvalMappingInsertRequestDTO.costCenterAPRequestLists == null || approvalMappingInsertRequestDTO.costCenterAPRequestLists.Count == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "approvalMappingInsertRequestDTO.costCenterAPRequestLists required!";
                return response;
            }

            if (approvalMappingInsertRequestDTO.approvalLevelRequestLists == null || approvalMappingInsertRequestDTO.approvalLevelRequestLists.Count == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "approvalMappingInsertRequestDTO.approvalLevelRequestLists required!";
                return response;
            }

            string costCenterXML = string.Empty;
            costCenterXML = "<CostCenters>";
            foreach (var item in approvalMappingInsertRequestDTO.costCenterAPRequestLists)
            {
                costCenterXML += "<CostCenter>";
                costCenterXML += "<CostCenterCode>";
                costCenterXML += item.CostCenterCode;
                costCenterXML += "</CostCenterCode>";
                costCenterXML += "</CostCenter>";
            }

            costCenterXML += "</CostCenters>";

            string MatrixXML = string.Empty;
            MatrixXML = "<ApprovalLevels>";
            foreach (var item in approvalMappingInsertRequestDTO.approvalLevelRequestLists)
            {
                //MatrixXML += "<ApprovalLevel>";
                //MatrixXML += "<Level>";
                //MatrixXML += item.Level;
                //MatrixXML += "</Level>";
                //MatrixXML += "<RoleCode>";
                //MatrixXML += item.RoleCode;
                //MatrixXML += "</RoleCode>";
                //MatrixXML += "</ApprovalLevel>";

                MatrixXML += "<ApprovalLevel>";
                MatrixXML += "<Level>";
                MatrixXML += item.Level;
                MatrixXML += "</Level>";
                MatrixXML += "<RoleCode>";
                MatrixXML += item.RoleCode;
                MatrixXML += "</RoleCode>";
                
                MatrixXML += "<AppType>";
                MatrixXML += item.AppType;
                MatrixXML += "</AppType>";
                MatrixXML += "<EMPCode>";
                MatrixXML += item.EMPCode;
                MatrixXML += "</EMPCode>";
                MatrixXML += "<PuchaseTypeID>";
                MatrixXML += item.PurchaseTypeID;
                MatrixXML += "</PuchaseTypeID>";
                MatrixXML += "<PGCategoryCode>";
                MatrixXML += item.PGCategoryCode;
                MatrixXML += "</PGCategoryCode>";
                MatrixXML += "<AmountApplicableFlag>";
                MatrixXML += item.AmountApplicableFlag;
                MatrixXML += "</AmountApplicableFlag>";
                MatrixXML += "<CalculateSymbol>";
                MatrixXML += item.CalculateSymbol;
                MatrixXML += "</CalculateSymbol>";

                MatrixXML += "<FromAmount>";
                MatrixXML += item.FromAmount;
                MatrixXML += "</FromAmount>";
                MatrixXML += "<ToAmount>";
                MatrixXML += item.ToAmount;
                MatrixXML += "</ToAmount>";
                MatrixXML += "</ApprovalLevel>";
            }

            MatrixXML += "</ApprovalLevels>";

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {


                    new SqlParameter("@CostCenter", costCenterXML),
                    new SqlParameter("@Matrix",MatrixXML),
                    new SqlParameter("@InsertdBy", Convert.ToString(approvalMappingInsertRequestDTO.InsertdBy)),
                    new SqlParameter("@InsertedIPAddress", Convert.ToString(approvalMappingInsertRequestDTO.InsertedIPAddress)),
                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("PRC_ApprovalMatrix_Insert", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass AppHierarchyManage(AppHierarchyManageRequestDTO appHierarchyManageRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (appHierarchyManageRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "appHierarchyManageRequestDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(appHierarchyManageRequestDTO.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "appHierarchyManageRequestDTO.Action required!";
                return response;
            }

            string MatrixXML = string.Empty;
            if (appHierarchyManageRequestDTO.Action == "PRMAppingEDIT")
            {
                if (appHierarchyManageRequestDTO.pRApprovalMatrices == null || appHierarchyManageRequestDTO.pRApprovalMatrices.Count==0)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Edit data required!";
                    return response;
                }

                //var editedCount= appHierarchyManageRequestDTO.pRApprovalMatrices.

                MatrixXML = "<ApprovalLevels>";
                foreach (var item in appHierarchyManageRequestDTO.pRApprovalMatrices)
                {
                    if (item.updateRequired==1)
                    {
                        MatrixXML += "<ApprovalLevel>";
                        MatrixXML += "<Level>";
                        MatrixXML += item.ApprovalLevel;
                        MatrixXML += "</Level>";
                        MatrixXML += "<MatrixID>";
                        MatrixXML += item.PRApprovalMatrixID;
                        MatrixXML += "</MatrixID>";
                        MatrixXML += "</ApprovalLevel>";
                    }
                    
                }

                MatrixXML += "</ApprovalLevels>";
            }

           

            SqlParameter[] parameter = {
                new SqlParameter("@CostCenterCode", Convert.ToString(appHierarchyManageRequestDTO.CostCenterCode)),
                 new SqlParameter("@Action", Convert.ToString(appHierarchyManageRequestDTO.Action)),
                 new SqlParameter("@AppHierarchyID", Convert.ToString(appHierarchyManageRequestDTO.AppHierarchyID)),
                 
                 new SqlParameter("@InsertedBy", Convert.ToString(appHierarchyManageRequestDTO.InsertedBy)),
                 new SqlParameter("@InsertedIPAddress", Convert.ToString(appHierarchyManageRequestDTO.InsertedIPAddress)),
                 new SqlParameter("@RequistionNo", Convert.ToString(appHierarchyManageRequestDTO.RequistionNo)),
                  new SqlParameter("@EMPCode", Convert.ToString(appHierarchyManageRequestDTO.EMPCode)),
                 new SqlParameter("@AppLevel", appHierarchyManageRequestDTO.AppLevel),
                 new SqlParameter("@RoleMasterID", appHierarchyManageRequestDTO.RoleMasterID),
                 new SqlParameter("@AppType", Convert.ToString(appHierarchyManageRequestDTO.AppType)),
                 new SqlParameter("@PurchaseTypeID", Convert.ToInt32(appHierarchyManageRequestDTO.PurchaseTypeID)),
                 new SqlParameter("@PGCategoryCode", Convert.ToString(appHierarchyManageRequestDTO.PGCategoryCode)),
                 new SqlParameter("@AmountApplicableFlag", Convert.ToInt32(appHierarchyManageRequestDTO.AmountApplicableFlag)),
                 new SqlParameter("@CalculateSymbol", Convert.ToString(appHierarchyManageRequestDTO.CalculateSymbol)),
                 new SqlParameter("@FromAmount", Convert.ToDouble(appHierarchyManageRequestDTO.FromAmount)),
                  new SqlParameter("@ToAmount", Convert.ToDouble(appHierarchyManageRequestDTO.ToAmount)),

                  new SqlParameter("@EditedData", Convert.ToString(MatrixXML)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_Manage_AppHierarchy", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (Convert.ToString(appHierarchyManageRequestDTO.Action)=="GET" || Convert.ToString(appHierarchyManageRequestDTO.Action) == "PRDETAILS")
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    }
                }
                
            }

            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            return response;

        }

    //    public ResponseClass AppConfigFlowCreate(CompanyAppFlowRequestDTO request)
    //    {
    //        ResponseClass response = new ResponseClass();

    //        if (request == null)
    //        {
    //            response.responseCode = 0;
    //            response.responseMessage = "request required";
    //            return response;
    //        }

    //        if (!string.IsNullOrEmpty(request.InsertdBy) && request.InsertdBy.Length > 50)
    //        {
    //            response.responseCode = 0;
    //            response.responseMessage = "approvalMappingInsertRequestDTO.InsertdBy cannot exceed 50 characters!";
    //            return response;
    //        }

    //        if (!string.IsNullOrEmpty(request.InsertedIPAddress) && request.InsertedIPAddress.Length > 100)
    //        {
    //            response.responseCode = 0;
    //            response.responseMessage = "request.InsertedIPAddress cannot exceed 100 characters!";
    //            return response;
    //        }

           
    //        if (request.approvalLevelRequestLists == null || request.approvalLevelRequestLists.Count == 0)
    //        {
    //            response.responseCode = 0;
    //            response.responseMessage = "request.approvalLevelRequestLists required!";
    //            return response;
    //        }

           
    //        string MatrixXML = string.Empty;
    //        MatrixXML = "<ApprovalLevels>";
    //        foreach (var item in request.approvalLevelRequestLists)
    //        {
               
    //            MatrixXML += "<ApprovalLevel>";
    //            MatrixXML += "<Level>";
    //            MatrixXML += item.Level;
    //            MatrixXML += "</Level>";
    //            MatrixXML += "<RoleCode>";
    //            MatrixXML += item.RoleCode;
    //            MatrixXML += "</RoleCode>";

    //            MatrixXML += "<AppType>";
    //            MatrixXML += item.AppType;
    //            MatrixXML += "</AppType>";
    //            MatrixXML += "<EMPCode>";
    //            MatrixXML += item.EMPCode;
    //            MatrixXML += "</EMPCode>";
    //            MatrixXML += "<PuchaseTypeID>";
    //            MatrixXML += item.PurchaseTypeID;
    //            MatrixXML += "</PuchaseTypeID>";
    //            MatrixXML += "<PGCategoryCode>";
    //            MatrixXML += item.PGCategoryCode;
    //            MatrixXML += "</PGCategoryCode>";
    //            MatrixXML += "<AmountApplicableFlag>";
    //            MatrixXML += item.AmountApplicableFlag;
    //            MatrixXML += "</AmountApplicableFlag>";
    //            MatrixXML += "<CalculateSymbol>";
    //            MatrixXML += item.CalculateSymbol;
    //            MatrixXML += "</CalculateSymbol>";

    //            MatrixXML += "<FromAmount>";
    //            MatrixXML += item.FromAmount;
    //            MatrixXML += "</FromAmount>";
    //            MatrixXML += "<ToAmount>";
    //            MatrixXML += item.ToAmount;
    //            MatrixXML += "</ToAmount>";
    //            MatrixXML += "</ApprovalLevel>";
    //        }

    //        MatrixXML += "</ApprovalLevels>";

    //        try
    //        {
    //            List<OutParameter> outParameters = new List<OutParameter>();

    //            SqlParameter[] parameter = {


    //                new SqlParameter("@CostCenter", costCenterXML),
    //                new SqlParameter("@Matrix",MatrixXML),
    //                new SqlParameter("@InsertdBy", Convert.ToString(approvalMappingInsertRequestDTO.InsertdBy)),
    //                new SqlParameter("@InsertedIPAddress", Convert.ToString(approvalMappingInsertRequestDTO.InsertedIPAddress)),
    //                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
    //                 new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
    //                };

    //            int result = dBConnection.ExecuteNonQuery("PRC_ApprovalMatrix_Insert", parameter, outParameters);

    //            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
    //            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

    //            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
    //            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
    //        }
    //        catch (Exception ex)
    //        {

    //            response.responseCode = 0;
    //            response.responseMessage = ex.Message;
    //        }

    //        return response;
    //    }
    }
}
