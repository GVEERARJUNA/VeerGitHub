﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;

namespace P2OBAL.Masters
{
    public class MasterDataBL : IMasterDataBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        public MasterDataBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass GetCommonEntity(MasterSelectRequestDTO masterSelectRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (masterSelectRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "masterSelectRequestDTO required";
                return response;
            }



            if (string.IsNullOrEmpty(masterSelectRequestDTO.EntityName))
            {
                response.responseCode = 0;
                response.responseMessage = "masterSelectRequestDTO.EntityName required!";
                return response;
            }
            if (string.IsNullOrEmpty(masterSelectRequestDTO.CompanyCode))
            {
                response.responseCode = 0;
                response.responseMessage = "masterSelectRequestDTO.CompanyCode required!";
                return response;
            }
            if (string.IsNullOrEmpty(masterSelectRequestDTO.EmployeeID))
            {
                response.responseCode = 0;
                response.responseMessage = "masterSelectRequestDTO.EmployeeID required!";
                return response;
            }

            SqlParameter[] parameter = {
                new SqlParameter("@EntityName", Convert.ToString(masterSelectRequestDTO.EntityName)),
                new SqlParameter("@SearchParameter1", Convert.ToString(masterSelectRequestDTO.SearchParameter1)),
                new SqlParameter("@SearchParameter2", Convert.ToString(masterSelectRequestDTO.SearchParameter2)),
                new SqlParameter("@EmployeeID", Convert.ToString(masterSelectRequestDTO.EmployeeID)),
                new SqlParameter("@SearchAs", Convert.ToString(masterSelectRequestDTO.SearchAs)),
                new SqlParameter("@CompanyCode", Convert.ToString(masterSelectRequestDTO.CompanyCode)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_GetCommon_Entity", parameter, outParameters);
            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    if (masterSelectRequestDTO.EntityName != "PRMasterData")
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    }
                    else
                    {
                        dsResult.Tables[0].TableName = "purchaseTypes";
                        dsResult.Tables[1].TableName = "purchaseGroups";
                        dsResult.Tables[2].TableName = "currencies";
                        dsResult.Tables[3].TableName = "gLCodes";
                        dsResult.Tables[4].TableName = "vendors";
                        dsResult.Tables[5].TableName = "purchaseOrganisations";
                        dsResult.Tables[6].TableName = "plantCodes";
                        dsResult.Tables[7].TableName = "costCenters";
                        dsResult.Tables[8].TableName = "formFields";

                        string JsonLength = string.Empty;
                        JsonLength = JsonConvert.SerializeObject(dsResult);

                        if (Convert.ToString(JsonLength).Length > 0)
                        {
                            response.responseJSON = Base64Encode(JsonConvert.SerializeObject(dsResult));
                        }
                    }
                    
                }
            }


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;
            return response;
        }

        public ResponseClass GetMasterData(MasterDataRequestDTO masterDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                if (masterDataRequestDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "masterDataRequestDTO required";
                    return response;
                }

                if (string.IsNullOrEmpty(masterDataRequestDTO.MasterType))
                {
                    response.responseCode = 0;
                    response.responseMessage = "masterDataRequestDTO.MasterType required!";
                    return response;
                }


                SqlParameter[] parameter = {
                new SqlParameter("@MasterType", Convert.ToString(masterDataRequestDTO.MasterType)),
                new SqlParameter("@CompanyCode", masterDataRequestDTO.CompanyCode == null ? "" :  Convert.ToString(masterDataRequestDTO.CompanyCode)),
                new SqlParameter("@PageNumber", masterDataRequestDTO.PageNumber),
                new SqlParameter("@RowsOfPage", masterDataRequestDTO.RowsOfPage),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@CostCenterSearch", masterDataRequestDTO.CostCenterSearch == null ? "" : masterDataRequestDTO.CostCenterSearch)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_GetMasterData", parameter, outParameters);
                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");
                OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                if (resultrcode.ParameterValue == "1")
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / masterDataRequestDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;

                    }
                }
                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = resultMessage.ParameterValue;
            }
            catch(Exception ex)
            {
                response.responseCode = -1 ;
                response.responseMessage = "Error !!";
            }
            return response;
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public ResponseClass InsertCostCenterConfig(CostConfigInsertRequestDTO configInsertRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (configInsertRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Input Data is required";
                return response;
            }
            if (configInsertRequestDTO.Action == "" || configInsertRequestDTO.Action == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Action is required";
                return response;
            }
            if (configInsertRequestDTO.CostCenterCode == "" || configInsertRequestDTO.CostCenterCode == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Cost Center Code is required";
                return response;
            }
            if (configInsertRequestDTO.RoleMasterId == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Please Select Role";
                return response;
            }
            if (configInsertRequestDTO.RoleEmpCode == "" || configInsertRequestDTO.RoleEmpCode == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Please Select Employee";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                    new SqlParameter("@Action", configInsertRequestDTO.Action),
                    new SqlParameter("@CostCenterConfigID", configInsertRequestDTO.CostCenterConfigID),
                    new SqlParameter("@CostCenterCode", configInsertRequestDTO.CostCenterCode),
                    new SqlParameter("@RoleMasterId",configInsertRequestDTO.RoleMasterId),
                    new SqlParameter("@RoleEmpCode",configInsertRequestDTO.RoleEmpCode),
                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("USP_InsertCostCenterConfig", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass CostConfigGet(CostConfigGetRequestDTO CostCenterRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                if (CostCenterRequestDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "CostCenterRequestDTO required";
                    return response;
                }

                //if (string.IsNullOrEmpty(CostCenterRequestDTO.CostCenterCode))
                //{
                //    response.responseCode = 0;
                //    response.responseMessage = "CostCenterCode required!";
                //    return response;
                //}

                //if (CostCenterRequestDTO.CostCenterConfigID == 0)
                //{
                //    response.responseCode = 0;
                //    response.responseMessage = "CostCenterConfigID required!";
                //    return response;
                //}

                SqlParameter[] parameter = {
                new SqlParameter("@CostCenterConfigID", CostCenterRequestDTO.CostCenterConfigID),
                new SqlParameter("@CostCenterCode", CostCenterRequestDTO.CostCenterCode == null ? "" :  CostCenterRequestDTO.CostCenterCode),
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_GetCostCenterConfig", parameter, outParameters);


                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                response.responseCode = -1;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }

        public ResponseClass DeleteCostCenterRoleConfig(CostConfigGetRequestDTO costCenterRoleDeleteRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (costCenterRoleDeleteRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "configInsertRequestDTO required";
                return response;
            }
            if (costCenterRoleDeleteRequestDTO.CostCenterConfigID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "CostCenter Config RoleID is required";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                    new SqlParameter("@CostCenterConfigID", costCenterRoleDeleteRequestDTO.CostCenterConfigID),
                    new SqlParameter("@DeletedBy", costCenterRoleDeleteRequestDTO.DeletedBy),
                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                   };

                int result = dBConnection.ExecuteNonQuery("USP_DeleteCostCenterConfig", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass MaterialImagaeManage(MaterialImagaeManageDTO materialImagaeManageDTO)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                if (materialImagaeManageDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "materialImagaeManageDTO required";
                    return response;
                }

               

                SqlParameter[] parameter = {
                    new SqlParameter("@Action", Convert.ToString(materialImagaeManageDTO.Action)),
                    new SqlParameter("@Type", Convert.ToString(materialImagaeManageDTO.Type)),
                    new SqlParameter("@MatCode", Convert.ToString(materialImagaeManageDTO.MatCode)),
                    new SqlParameter("@MatImage", Convert.ToString(materialImagaeManageDTO.MatImage)),
                    new SqlParameter("@InsertedBy", Convert.ToString(materialImagaeManageDTO.InsertedBy)),
                    new SqlParameter("@InsetedIPAddresss",Convert.ToString(materialImagaeManageDTO.InsetedIPAddresss)),
                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                    new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_Material_Image_Manage", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

                if (response.responseCode==1)
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    }
                }
                
               
            }
            catch (Exception ex)
            {
                response.responseCode = -1;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }


        public ResponseClass GetMenuMaster(MenuMasterDetailsRequestDTO menueMasterRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                if (menueMasterRequestDTO.Action == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Action is required";
                    return response;
                }
                SqlParameter[] parameter = {
                new SqlParameter("@Action", menueMasterRequestDTO.Action),
                new SqlParameter("@SerachParm", menueMasterRequestDTO.SerachParm == null ? "" :  menueMasterRequestDTO.SerachParm),
                 new SqlParameter("@PageNumber", menueMasterRequestDTO.PageNumber),
                new SqlParameter("@RowsOfPage", menueMasterRequestDTO.RowsOfPage),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_ManageMenueMaster", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");
                OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
                response.recordCount = Convert.ToInt32(RecordCount.ParameterValue);
                if (response.responseCode == 1)
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / menueMasterRequestDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;

                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = -1;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }

        public ResponseClass GetParentMenuMaster()
        {
            ResponseClass response = new ResponseClass();
            try
            {
                SqlParameter[] parameter = {};

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_ParentMenueMaster", parameter, outParameters);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = -1;
                    response.responseMessage = "Error !!";
                }
            }
            catch (Exception ex)
            {
                response.responseCode = -1;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }

        public ResponseClass InsertMenuMaster(MenuMasterDetailsInsertDTO masterDetailsInsertDTO)
        {
            ResponseClass response = new ResponseClass();

            if (masterDetailsInsertDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Input Data is required";
                return response;
            }
            if (masterDetailsInsertDTO.Action == "" || masterDetailsInsertDTO.Action == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Action is required";
                return response;
            }
            if (masterDetailsInsertDTO.ParentMenuID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Please select Parent Menu";
                return response;
            }
            if (masterDetailsInsertDTO.MenuName == "" || masterDetailsInsertDTO.MenuName == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Please enter Menu Name";
                return response;
            }
            if (masterDetailsInsertDTO.MenuUrl == "" || masterDetailsInsertDTO.MenuUrl == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Please enter Menu Url";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                new SqlParameter("@Action", masterDetailsInsertDTO.Action),
                new SqlParameter("@ParentMenuID", masterDetailsInsertDTO.ParentMenuID),
                new SqlParameter("@MenuName", masterDetailsInsertDTO.MenuName),
                new SqlParameter("@MenuUrl", masterDetailsInsertDTO.MenuUrl),
                new SqlParameter("@LoggedInEmpId", masterDetailsInsertDTO.LoggedInEmpId),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                };

                int result = dBConnection.ExecuteNonQuery("USP_ManageMenueMaster", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass DeleteMenuMaster(MenuMasterDetailsRequestDTO menueMasterRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (menueMasterRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Input data is required";
                return response;
            }
            if (menueMasterRequestDTO.MenuMasteId == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Please select Menu Master";
                return response;
            }
            if (menueMasterRequestDTO.Action == "" || menueMasterRequestDTO.Action == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Action is required";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                new SqlParameter("@Action", menueMasterRequestDTO.Action),
                new SqlParameter("@MenuMasteId", menueMasterRequestDTO.MenuMasteId),
                new SqlParameter("@LoggedInEmpId", menueMasterRequestDTO.LoggedInEmpId),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                };

                int result = dBConnection.ExecuteNonQuery("USP_ManageMenueMaster", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass GetUserTypeMaster()
        {
            ResponseClass response = new ResponseClass();
            try
            {
                SqlParameter[] parameter = { };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_UserTypeMaster", parameter, outParameters);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = -1;
                    response.responseMessage = "Error !!";
                }
            }
            catch (Exception ex)
            {
                response.responseCode = -1;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }

        public ResponseClass GetMenuMasterType(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                SqlParameter[] parameter = {
                 new SqlParameter("@UserType", userMappingDetailsRequestDTO.UserType)
                };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_MenuMasterType", parameter, outParameters);

                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    response.responseCode = 1;
                    response.responseMessage = "Success";
                }
                else
                {
                    response.responseCode = -1;
                    response.responseMessage = "Error !!";
                }
            }
            catch (Exception ex)
            {
                response.responseCode = -1;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }

        public ResponseClass GetMenuUserMapping(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                if (userMappingDetailsRequestDTO.Action == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Action is required";
                    return response;
                }
                SqlParameter[] parameter = {
                new SqlParameter("@Action", userMappingDetailsRequestDTO.Action),
                new SqlParameter("@SerachParm", userMappingDetailsRequestDTO.SerachParm == null ? "" :  userMappingDetailsRequestDTO.SerachParm),
                 new SqlParameter("@PageNumber", userMappingDetailsRequestDTO.PageNumber),
                new SqlParameter("@RowsOfPage", userMappingDetailsRequestDTO.RowsOfPage),
                new SqlParameter("@UserType", userMappingDetailsRequestDTO.UserType),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_UserMenuMapping", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");
                OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
                response.recordCount = Convert.ToInt32(RecordCount.ParameterValue);
                if (response.responseCode == 1)
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / userMappingDetailsRequestDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;

                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = -1;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }


        public ResponseClass InsertMenuUserMapping(MenuUserMappingInsertDTO userMappingInsertDTO)
        {
            ResponseClass response = new ResponseClass();

            if (userMappingInsertDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Input Data is required";
                return response;
            }
            if (userMappingInsertDTO.Action == "" || userMappingInsertDTO.Action == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Action is required";
                return response;
            }
            if (userMappingInsertDTO.UserTypeCode == "" || userMappingInsertDTO.UserTypeCode == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Please Select User Type";
                return response;
            }
            if (userMappingInsertDTO.MenuID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Please Select Menu";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                new SqlParameter("@Action", userMappingInsertDTO.Action),
                new SqlParameter("@UserTypeCode", userMappingInsertDTO.UserTypeCode),
                new SqlParameter("@MenuID", userMappingInsertDTO.MenuID),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                };

                int result = dBConnection.ExecuteNonQuery("USP_UserMenuMapping", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }


        public ResponseClass DeleteUserMenuMapping(MenuUserMappingDetailsRequestDTO userMappingDetailsRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (userMappingDetailsRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Input data is required";
                return response;
            }
            if (userMappingDetailsRequestDTO.MappingId == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Please select Menu Master";
                return response;
            }
            if (userMappingDetailsRequestDTO.Action == "" || userMappingDetailsRequestDTO.Action == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Action is required";
                return response;
            }

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                new SqlParameter("@Action", userMappingDetailsRequestDTO.Action),
                new SqlParameter("@MappingId", userMappingDetailsRequestDTO.MappingId),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                };

                int result = dBConnection.ExecuteNonQuery("USP_UserMenuMapping", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass PRSPOCGroupManage(PRSPOCRequestDTO pRSPOCRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                if (pRSPOCRequestDTO.Action == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Action is required";
                    return response;
                }
                SqlParameter[] parameter = {
                new SqlParameter("@Action", Convert.ToString(pRSPOCRequestDTO.Action)),
                new SqlParameter("@PRSPOCGroupID", Convert.ToInt32(pRSPOCRequestDTO.PRSPOCGroupID)),
                new SqlParameter("@PRSPOCMemberID", Convert.ToInt32(pRSPOCRequestDTO.PRSPOCMemberID)),
                new SqlParameter("@PRSPOCGroupTitle", Convert.ToString(pRSPOCRequestDTO.PRSPOCGroupTitle)),
                new SqlParameter("@EmployeeID", Convert.ToString(pRSPOCRequestDTO.EmployeeID)),
                new SqlParameter("@InsertedBy", Convert.ToString(pRSPOCRequestDTO.InsertedBy)),
                new SqlParameter("@InsertedIPAddress", Convert.ToString(pRSPOCRequestDTO.InsertedIPAddress)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
               
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_PRSPOC_Group_manage", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");
                
                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

                if (response.responseCode==1)
                {
                    if (Convert.ToString(pRSPOCRequestDTO.Action)== "MANAGE" || Convert.ToString(pRSPOCRequestDTO.Action) == "GETMEMBER")
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    }
                }
                
            }
            catch (Exception ex)
            {
                response.responseCode = 0;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }

        public ResponseClass MastersInsert(MastersInsertRequestDTO mastersInsertRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (mastersInsertRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Input Data is required";
                return response;
            }
            if (mastersInsertRequestDTO.Action == "" || mastersInsertRequestDTO.Action == null)
            {
                response.responseCode = 0;
                response.responseMessage = "Action is required";
                return response;
            }
            if (mastersInsertRequestDTO.CompanyCode == "" || mastersInsertRequestDTO.CompanyCode == null)
            {
                response.responseCode = 0;
                response.responseMessage = "CompanyCode is required";
                return response;
            }
          

            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                    new SqlParameter("@Action", mastersInsertRequestDTO.Action),
                    new SqlParameter("@CompanyCode", mastersInsertRequestDTO.CompanyCode),
                    new SqlParameter("@IParam1", mastersInsertRequestDTO.IParam1),
                    new SqlParameter("@IParam2", mastersInsertRequestDTO.IParam2),
                    new SqlParameter("@IParam3", mastersInsertRequestDTO.IParam3),
                    new SqlParameter("@IParam4", mastersInsertRequestDTO.IParam4),
                    new SqlParameter("@IParam5", mastersInsertRequestDTO.IParam5),
                    new SqlParameter("@IParam6", mastersInsertRequestDTO.IParam6),
                    new SqlParameter("@IParam7", mastersInsertRequestDTO.IParam7),
                    new SqlParameter("@IParam8", mastersInsertRequestDTO.IParam8),
                    new SqlParameter("@InsertedBy", mastersInsertRequestDTO.InsertedBy),
                    new SqlParameter("@InsertedIPAddress",mastersInsertRequestDTO.InsertedIPAddress),
                    
                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,500,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("PRC_Masters_Insert", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }
    }
}
