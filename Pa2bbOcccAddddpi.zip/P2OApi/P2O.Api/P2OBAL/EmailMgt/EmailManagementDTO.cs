﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.EmailMgt
{
   public class EmailManagementDTO
    {
        public string RequistionNo { get; set; }

        public string PRID { get; set; }
        public string CostCenter { get; set; }
        public string Requestor { get; set; }
        public string Approver { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }

        public string EmailType { get; set; }
    }

    public class MailDetails
    {
        public string Sender { get; set; }
        public string SenderName { get; set; }
        public string Subject { get; set; }
       // public string ToList { get; set; }
        public string CcList { get; set; }
        public string BccList { get; set; }
        public List<AtatchmentList> Attachment { get; set; }
        public string ImagePathHeader { get; set; }
        public string SmtpHostName { get; set; }
        public string MailActualBody { get; set; }

        public List<BCCList> bCCLists { get; set; }
        public List<ToList> ToList { get; set; }



    }

    public class AtatchmentList
    {
        public string Attachment { get; set; }
    }

    public class ToList
    {
        public string EmailAddress { get; set; }
    }

    public class BCCList
    {
        public string EmailAddress { get; set; }
    }

    public class EmailClass
    {
        public string EmailSubject { get; set; }
        public string EmailTemplate { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }

        public string BCCList { get; set; }
    }

    public class EmailEntity
    {
        public int ApprovalMatrixID { get; set; }
        public string ApprovalName { get; set; }
        public string ApprovalEmail { get; set; }
        public string RequistionNo { get; set; }
        public string CostCenterCode { get; set; }
        public string CostCenterName { get; set; }
        public string RaisedBy { get; set; }
        public string Material { get; set; }
        public string POCost { get; set; }

        public string EmailLink { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }

        public string EmailSubject { get; set; }
        public string EmailTemplate { get; set; }

        public string EmailType { get; set; }

        public string BCCList { get; set; }
        public string Comments { get; set; }

        public string CurrencyCode { get; set; }
        public string Atatchments { get; set; }

        public string GCMNotifictionTitle { get; set; }
        public string GCMNotifictionBody { get; set; }

        public string PurchaseType { get; set; }

    }

    public class EmailHistoryRequestDTO
    {
        public int ApprovalMatrixID { get; set; }
        public string EmailTo { get; set; }
        public string CCTo { get; set; }
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }

        public string EmailStatus { get; set; }

    }

    public class EmailMGTRequestDTO
    {
        public int EmailMasterID { get; set; }
        public string Action { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

    }
    public class EmailMGTUpdateDTO
    {
        public int EmailMasterID { get; set; }
        public string Action { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public string EmailSubject { get; set; }
        public string EmailTemplate { get; set; }

    }

    public class POGenerateNotificationRequest
    {
        public string P2OPRNumber { get; set; }

    }

    public class POGenerateEmailEntity
    {
        public string SAPPONo { get; set; }
        public string SAPPODate { get; set; }
        public double TotalPOValue { get; set; }
        public string EmailSubject { get; set; }
        public string EmailTemplate { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }
        public string BCCList { get; set; }
        public string VendorCode { get; set; }
        public string CurrencyCode { get; set; }
        public string Material { get; set; }


    }

    public class InactiveUserEmailEntity
    {
        public string MissingType { get; set; }
        public string MissingPlace { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }

    }
}
