﻿using P2OBAL.Common;

namespace P2OBAL.UserManagement
{
    public interface IUserManagementBL
    {
        ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO);
        ResponseClass GetDashboardData(DashboardDataRequestBO dashboardDataRequestBO);
        ResponseClass ManageUser(DashboardDataRequestBO dashboardDataRequestBO);

        ResponseClass GetRequistionDataCount(GetRequistionDataCountRequest getRequistionDataCountRequest);

        ResponseClass AddUser(AddUserRequestDTO addUserRequestDTO);
        ResponseClass AddDelegator(AddDelegatorRequestDTO addDelegatorRequestDTO);
        ResponseClass GetDelegationDetails(string EmployeeId);

        ResponseClass SupplierEmployeeAssign(SupplierEmployeeMappingRequestDTO supplierEmployeeMappingRequestDTO);
        ResponseClass ChangeUserType(ChangeUserTypeDTO changeUserTypeDTO);

    }
}