﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;

namespace P2OBAL.UserManagement
{
    public class UserManagementBL : IUserManagementBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        public UserManagementBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass CheckUserLogin(LoginRequestBO loginRequestBO)
        {
            ResponseClass response = new ResponseClass();

            if (loginRequestBO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "loginRequestBO required";
                return response;
            }


            if (string.IsNullOrEmpty(loginRequestBO.UserName))
            {
                response.responseCode = 0;
                response.responseMessage = "loginRequestBO.UserName required!";
                return response;
            }

           
            SqlParameter[] parameter = {
                new SqlParameter("@LoginID", loginRequestBO.UserName),
                
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_User_Login", parameter, outParameters);

            //int userLogin = Convert.ToInt32("ABC");
            //throw new Exception();

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    dsResult.Tables[0].Columns.Add("AssignedRoles");
                    dsResult.Tables[0].Columns.Add("Photo");
                    string roles = string.Empty;

                    if (dsResult.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow item in dsResult.Tables[1].Rows)
                        {
                            roles += Convert.ToString(item["RoleName"]) + ",";
                        }

                        roles = roles.TrimEnd(',');

                        //dsResult.Tables[0].Rows[0]["AssignedRoles"] = roles;
                    }

                    string photo = GetEmployeePhoto(Convert.ToString(dsResult.Tables[0].Rows[0]["EmployeeId"]), Convert.ToString(dsResult.Tables[0].Rows[0]["CompanyCode"]));
                    bool fileExist = false;
                    fileExist = CheckFileExist(photo);
                    if (fileExist)
                    {
                        dsResult.Tables[0].Rows[0]["Photo"] = photo;

                    }
                    else
                    {
                        dsResult.Tables[0].Rows[0]["Photo"] = "https://hgsconnect.teamhgs.com/PurchaseToOrder/assets/images/no_image.jpg";
                    }

                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                    if (dsResult.Tables.Count>1)
                    {
                        response.responseJSONSecondary = JsonConvert.SerializeObject(dsResult.Tables[2]);
                    }
                }
            }



            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;

            return response;
        }

        public ResponseClass GetDashboardData(DashboardDataRequestBO dashboardDataRequestBO)
        {
            ResponseClass response = new ResponseClass();

            if (dashboardDataRequestBO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "dashboardDataRequestBO required";
                return response;
            }


            if (string.IsNullOrEmpty(dashboardDataRequestBO.UserName))
            {
                response.responseCode = 0;
                response.responseMessage = "dashboardDataRequestBO.UserName required!";
                return response;
            }

            if (string.IsNullOrEmpty(dashboardDataRequestBO.CurrentRole))
            {
                response.responseCode = 0;
                response.responseMessage = "dashboardDataRequestBO.CurrentRole required!";
                return response;
            }


            SqlParameter[] parameter = {
                new SqlParameter("@LoginID", dashboardDataRequestBO.UserName),
                new SqlParameter("@CurrentRole", dashboardDataRequestBO.CurrentRole),
                new SqlParameter("@SAPCompanyCode", Convert.ToString(dashboardDataRequestBO.SAPCompanyCode)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_User_GetDashboardData", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    dsResult.Tables[0].TableName = "MenuMaster";
                    dsResult.Tables[1].TableName = "CompanyCode";
                    dsResult.Tables[2].TableName = "ToDoTask";
                    dsResult.Tables[3].TableName = "RecentPR";
                    response.responseJSON = JsonConvert.SerializeObject(dsResult);
                }
            }


           
            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;

            return response;
        }

        public ResponseClass ManageUser(DashboardDataRequestBO dashboardDataRequestBO)
        {
            ResponseClass response = new ResponseClass();

            if (dashboardDataRequestBO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "dashboardDataRequestBO required";
                return response;
            }


            //if (string.IsNullOrEmpty(dashboardDataRequestBO.UserName))
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "dashboardDataRequestBO.UserName required!";
            //    return response;
            //}

            if (dashboardDataRequestBO.PageNumber == 0)
            {
                dashboardDataRequestBO.PageNumber = 1;
            }

            if (dashboardDataRequestBO.RowsOfPage == 0)
            {
                dashboardDataRequestBO.PageNumber = 20;
            }


            SqlParameter[] parameter = {
                new SqlParameter("@UserName", dashboardDataRequestBO.UserName),
                 new SqlParameter("@PageNumber", dashboardDataRequestBO.PageNumber),
                new SqlParameter("@RowsOfPage", dashboardDataRequestBO.RowsOfPage),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_manage_users", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");
            OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

            if (resultrcode.ParameterValue == "1")
            {
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / dashboardDataRequestBO.RowsOfPage));

                    int recordPages = Convert.ToInt32(noOfPages);

                    if (noOfPages > recordPages)
                    {
                        recordPages = recordPages + 1;
                    }

                    response.recordCount = recordPages;

                }
                //if (dsResult != null && dsResult.Tables.Count > 0)
                //{
                   
                //    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                //}
            }



            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;

            return response;
        }

        private bool CheckFileExist(string fileName)
        {
            try
            {
                HttpWebRequest httpReq = (HttpWebRequest)WebRequest.Create(fileName);

                HttpWebResponse httpRes = (HttpWebResponse)httpReq.GetResponse(); // Error 404 right here,

                if (httpRes.StatusCode == HttpStatusCode.NotFound)
                {
                    return false;
                }

                // Close the response.
                httpRes.Close();
                return true;
            }
            catch (Exception)
            {

                return false;
            }


        }

        private string GetEmployeePhoto(string employeeId, string companyCode)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(employeeId) || string.IsNullOrWhiteSpace(companyCode))
                {
                    return string.Empty;
                }


                var employeeProfilePhotoUrl = appSettings.Value.EmployeePhoto;
                if (string.IsNullOrWhiteSpace(employeeProfilePhotoUrl))
                {
                    return string.Empty;
                }

                return employeeProfilePhotoUrl
                        .Replace("{CompanyCode}", companyCode)
                        .Replace("{EmployeeId}", employeeId);
            }
            catch
            {

                return string.Empty;
            }
        }

        public ResponseClass GetRequistionDataCount(GetRequistionDataCountRequest getRequistionDataCountRequest)
        {
            ResponseClass response = new ResponseClass();

            if (getRequistionDataCountRequest == null)
            {
                response.responseCode = 0;
                response.responseMessage = "getRequistionDataCountRequest required";
                return response;
            }


            if (string.IsNullOrEmpty(getRequistionDataCountRequest.UserName))
            {
                response.responseCode = 0;
                response.responseMessage = "getRequistionDataCountRequest.UserName required!";
                return response;
            }

            if (string.IsNullOrEmpty(getRequistionDataCountRequest.CurrentRole))
            {
                response.responseCode = 0;
                response.responseMessage = "getRequistionDataCountRequest.CurrentRole required!";
                return response;
            }


            SqlParameter[] parameter = {
                new SqlParameter("@LoginID", getRequistionDataCountRequest.UserName),
                new SqlParameter("@CurrentRole", getRequistionDataCountRequest.CurrentRole),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_getRequistionCount", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult);
                }
            }



            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;

            return response;
        }

        // add user
        public ResponseClass AddUser(AddUserRequestDTO addUserRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                if (addUserRequestDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "addUserRequestDTO required";
                    return response;
                }


                if (string.IsNullOrEmpty(addUserRequestDTO.UserName))
                {
                    response.responseCode = 0;
                    response.responseMessage = "addUserRequestDTO.UserName required!";
                    return response;
                }

                if (string.IsNullOrEmpty(addUserRequestDTO.Action))
                {
                    response.responseCode = 0;
                    response.responseMessage = "addUserRequestDTO.Action required!";
                    return response;
                }

                if (addUserRequestDTO.Action == "ASSIGNROLE")
                {
                    if (string.IsNullOrEmpty(addUserRequestDTO.Roles))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "addUserRequestDTO.Roles required!";
                        return response;
                    }
                }
                if (addUserRequestDTO.Action == "ASSIGNCOMPANY")
                {
                    if (string.IsNullOrEmpty(addUserRequestDTO.Companies))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "addUserRequestDTO.Companies required!";
                        return response;
                    }
                }

                SqlParameter[] parameter = {
                 new SqlParameter("@LoginID", Convert.ToString(addUserRequestDTO.UserName)),
                 new SqlParameter("@Action", Convert.ToString(addUserRequestDTO.Action)),
                 new SqlParameter("@RoleMasterID", Convert.ToString(addUserRequestDTO.Roles)),
                 new SqlParameter("@CompanyCode", Convert.ToString(addUserRequestDTO.Companies)),

                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("Prc_User_Create", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = resultMessage.ParameterValue;
            }
            catch(Exception ex)
            {
                response.responseCode = Convert.ToInt32("-1");
                response.responseMessage = ex.Message;
            }
            return response;
        }

        //Add delegator
        public ResponseClass AddDelegator(AddDelegatorRequestDTO addDelegatorRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                if (addDelegatorRequestDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Input required!";
                    return response;
                }


                if (string.IsNullOrEmpty(addDelegatorRequestDTO.Action))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Action required!";
                    return response;
                }

                if (string.IsNullOrEmpty(addDelegatorRequestDTO.LoggedInEmpId))
                {
                    response.responseCode = 0;
                    response.responseMessage = "LoggedIn employee code  required!";
                    return response;
                }
                if (string.IsNullOrEmpty(addDelegatorRequestDTO.DelgatorEMPCode))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Delegator Employee Code required!";
                    return response;
                }

                if (string.IsNullOrEmpty(addDelegatorRequestDTO.DelegateeEMPCode))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Delegatee Employee Code required!";
                    return response;
                }
                if (addDelegatorRequestDTO.StartDate == DateTime.MinValue)
                {
                    response.responseCode = 0;
                    response.responseMessage = "StartDate required!";
                    return response;
                }

                if (addDelegatorRequestDTO.EndDate == DateTime.MinValue)
                {
                    response.responseCode = 0;
                    response.responseMessage = "EndDate required!";
                    return response;
                }


                SqlParameter[] parameter = {
                 new SqlParameter("@LoggedInEmpId", Convert.ToString(addDelegatorRequestDTO.LoggedInEmpId)),
                 new SqlParameter("@Action", Convert.ToString(addDelegatorRequestDTO.Action)),
                 new SqlParameter("@DelegatorMappingID", Convert.ToString(addDelegatorRequestDTO.DelegatorMappingID)),
                 new SqlParameter("@DelegateeEMPCode", Convert.ToString(addDelegatorRequestDTO.DelegateeEMPCode)),
                 new SqlParameter("@DelgatorEMPCode", Convert.ToString(addDelegatorRequestDTO.DelgatorEMPCode)),
                 new SqlParameter("@StartDate", Convert.ToString(addDelegatorRequestDTO.StartDate)),
                 new SqlParameter("@EndDate", Convert.ToString(addDelegatorRequestDTO.EndDate)),
                  new SqlParameter("@DelegationReason", Convert.ToString(addDelegatorRequestDTO.DelegationReason)),
                 new SqlParameter("@IPAddress", Convert.ToString(addDelegatorRequestDTO.IPAddress)),

                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_InsertEditDelegatorMapping", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = resultMessage.ParameterValue;
            }
            catch (Exception ex)
            {
                response.responseCode = Convert.ToInt32("-1");
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass GetDelegationDetails(string EmployeeId)
        {
            ResponseClass response = new ResponseClass();
            try
            {
                if (EmployeeId == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Please select employee";
                    return response;
                }

                SqlParameter[] parameter = {
                new SqlParameter("@EmployeeId", EmployeeId),
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("USP_GetDelegationDetilsForEmployee", parameter, outParameters);


                if (dsResult != null && dsResult.Tables.Count > 0)
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                }
                response.responseCode = 1;
                response.responseMessage = "Success";
            }
            catch (Exception ex)
            {
                response.responseCode = -1;
                response.responseMessage = "Error !!  : " + ex.Message;
            }
            return response;
        }

        // supplier mapping
        public ResponseClass SupplierEmployeeAssign(SupplierEmployeeMappingRequestDTO supplierEmployeeMappingRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                if (supplierEmployeeMappingRequestDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "supplierEmployeeMappingRequestDTO required!";
                    return response;
                }


                if (string.IsNullOrEmpty(supplierEmployeeMappingRequestDTO.Action))
                {
                    response.responseCode = 0;
                    response.responseMessage = "Action required!";
                    return response;
                }

                if (string.IsNullOrEmpty(supplierEmployeeMappingRequestDTO.InsertedBy))
                {
                    response.responseCode = 0;
                    response.responseMessage = "supplierEmployeeMappingRequestDTO.InsertedBy  required!";
                    return response;
                }
                if (string.IsNullOrEmpty(supplierEmployeeMappingRequestDTO.InsertedIPAddress))
                {
                    response.responseCode = 0;
                    response.responseMessage = "supplierEmployeeMappingRequestDTO.InsertedIPAddress required!";
                    return response;
                }
                else if (supplierEmployeeMappingRequestDTO.InsertedIPAddress.Length>100)
                {
                    response.responseCode = 0;
                    response.responseMessage = "supplierEmployeeMappingRequestDTO.InsertedIPAddress length cannot be greater than 100 characters!";
                    return response;
                }
                if (supplierEmployeeMappingRequestDTO.Action=="Assign")
                {
                    if (string.IsNullOrEmpty(supplierEmployeeMappingRequestDTO.SupplierCode))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "supplierEmployeeMappingRequestDTO.SupplierCode required!";
                        return response;
                    }

                    if (string.IsNullOrEmpty(supplierEmployeeMappingRequestDTO.EmpCode))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "supplierEmployeeMappingRequestDTO.EmpCode required!";
                        return response;
                    }
                }
                
                //string MyXML = string.Empty;
                //if (supplierEmployeeMappingRequestDTO.Action== "ASSIGN")
                //{
                //    if (supplierEmployeeMappingRequestDTO.supplierLists==null || supplierEmployeeMappingRequestDTO.supplierLists.Count==0)
                //    {
                //        response.responseCode = 0;
                //        response.responseMessage = "supplierEmployeeMappingRequestDTO.supplierLists required!";
                //        return response;
                //    }
                //    else
                //    {
                //        MyXML = "<detailLines>";
                //        foreach (var item in supplierEmployeeMappingRequestDTO.supplierLists)
                //        {
                //            MyXML += "<detailLine>";
                //            MyXML += "<VendorCode>" + Convert.ToString(item.SupplierCode) + "</VendorCode>";
                //            MyXML += "</detailLine>";
                //        }
                //        MyXML = "</detailLines>";

                //    }
                //}


                SqlParameter[] parameter = {
                 new SqlParameter("@Action", Convert.ToString(supplierEmployeeMappingRequestDTO.Action)),
                 new SqlParameter("@SupplierEntry", Convert.ToString(supplierEmployeeMappingRequestDTO.SupplierCode)),
                 new SqlParameter("@EmpCode", Convert.ToString(supplierEmployeeMappingRequestDTO.EmpCode)),
                 new SqlParameter("@InsertedBy", Convert.ToString(supplierEmployeeMappingRequestDTO.InsertedBy)),
                 new SqlParameter("@InsertedIPAddress", Convert.ToString(supplierEmployeeMappingRequestDTO.InsertedIPAddress)),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_Supplier_UserManage", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = resultMessage.ParameterValue;

                if (response.responseCode==1 && Convert.ToString(supplierEmployeeMappingRequestDTO.Action)== "GETASSIGN")
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                    }
                }
            }
            catch (Exception ex)
            {
                response.responseCode = Convert.ToInt32("-1");
                response.responseMessage = ex.Message;
            }
            return response;
        }

        public ResponseClass ChangeUserType(ChangeUserTypeDTO changeUserTypeDTO)
        {
            ResponseClass response = new ResponseClass();

            try
            {
                if (changeUserTypeDTO == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "changeUserTypeDTO required";
                    return response;
                }


                if (string.IsNullOrEmpty(changeUserTypeDTO.UserName))
                {
                    response.responseCode = 0;
                    response.responseMessage = "changeUserTypeDTO.UserName required!";
                    return response;
                }

                if (string.IsNullOrEmpty(changeUserTypeDTO.Action))
                {
                    response.responseCode = 0;
                    response.responseMessage = "changeUserTypeDTO.Action required!";
                    return response;
                }
                if (changeUserTypeDTO.Action == "CHANGEUSERTYPE")
                {
                    if (string.IsNullOrEmpty(changeUserTypeDTO.UserType))
                    {
                        response.responseCode = 0;
                        response.responseMessage = "changeUserTypeDTO.UserType required!";
                        return response;
                    }
                }


                SqlParameter[] parameter = {
                 new SqlParameter("@LoginID", Convert.ToString(changeUserTypeDTO.UserName)),
                 new SqlParameter("@RoleMasterID", Convert.ToString(changeUserTypeDTO.UserType)),
                 new SqlParameter("@Action", Convert.ToString(changeUserTypeDTO.Action)),

                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

                List<OutParameter> outParameters = new List<OutParameter>();
                DataSet dsResult = new DataSet();
                dsResult = dBConnection.ExecuteDataSet("PRC_Change_UserType", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = resultMessage.ParameterValue;
            }
            catch (Exception ex)
            {
                response.responseCode = Convert.ToInt32("-1");
                response.responseMessage = ex.Message;
            }
            return response;
        }
    }
}
