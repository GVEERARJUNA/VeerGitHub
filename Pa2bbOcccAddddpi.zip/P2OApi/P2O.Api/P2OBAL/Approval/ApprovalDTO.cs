﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Approval
{
    public class ApprovalRequestDTO
    {
        public string LoggedInEmpId { get; set; }
        public long PurchaseRequistionID { get; set; }
       // public string CostCentre { get; set; }
        public string SearchType { get; set; }
        public string SearchText { get; set; }
        public string SearchBy { get; set; }
        public string requistionNo { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }

        public string SearchCriteria1 { get; set; }

        public string SAPCompanyCode { get; set; }
    }
    public class ApprovalSatatusUpdateRequestDTO
    {
        public string ApproverId { get; set; }
        public int PRApprovalMatrixID { get; set; }
        public int PurchaseRequistionID { get; set; }
        public int ApprovalLevel { get; set; }
        public int ApprovalStatus { get; set; }
        public string Remark { get; set; }
    }

    public class GetPREntityRequest
    {
        public int PurchaseRequistionID { get; set; }
        public string SearchType { get; set; }
    }

    public class WaitingApprovalResponceDTO
    {
        public int PurchaseRequistionID { get; set; }
        public string CostCenterName { get; set; }
        public string GLCode { get; set; }
        public string Company { get; set; }
        public decimal Amount { get; set; }
        public int Quantity { get; set; }
        public string Vendor { get; set; }
        public string PlantCode { get; set; }
        public string PurchasingOrg { get; set; }
        public string Status { get; set; }
        public string RequistionControlID { get; set; }
        public int ApprovalLevel { get; set; }
        public int PRApprovalMatrixID { get; set; }
        public string Currency { get; set; }
        public List<WaitingApprovalDetails> waitingApprovalDetails { get; set; }
    }

    public class WaitingApprovalDetails
    {

        public string MaterialCode { get; set; }
        public string MaterialDescription { get; set; }
        public string GLCode { get; set; }
        public string ProductType { get; set; }
        public double MaterialAmount { get; set; }
        public int MaterialQuantity { get; set; }

        public double NetAmount { get; set; }
        public string NeededByDate { get; set; }
        public string Comments { get; set; }
    }

    public class PRRequistionDataRequestDTO
    {
        public string LoggedInEmpId { get; set; }
        public string requistionNo { get; set; }

        public string AppSource { get; set; }
    }

    public class ApprovalTreeResponse
    {
        public List<ApprovalLevelResponse> DistinctLevel { get; set; }
        public List<ApprovalResponseTreeData> ApprovalData { get; set; }
    }

    public class ApprovalLevelResponse
    {
        public int ApprovalLevel { get; set; }

        public string SubmittedBy { get; set; }
    }

    public class ApprovalResponseTreeData
    {
        public int ApprovalLevel { get; set; }
        public string ApprovalName { get; set; }
        public string DelegatorName { get; set; }
        public int IsDelegator { get; set; }
        public string ApprovalStatus { get; set; }

        public int PRApprovalMatrixID { get; set; }
    }

    public class UpdatePRDetailRequest
    {
        public int PurchaseRequistionDetailID { get; set; }
        public double Amount { get; set; }
        public double Quantity { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public int PurchaseRequistionID { get; set; }
        public string Action { get; set; }
        public string MaterialCode { get; set; }
        public string ShortText { get; set; }
        public string GLCode { get; set; }
        public string LineComments { get; set; }
        public int CatalogueDataID { get; set; }
        public string WarrantyStartDate { get; set; }
        public string WarrantyEndDate { get; set; }
        public string NeededByDate { get; set; }

    }

    public class PRVirtualFlowRequestDTO
    {
        public string CostCenterCode { get; set; }
        public int PurchaseTypeID { get; set; }
        public string PurchaseGroup { get; set; }
        public double TotalAmount { get; set; }
        public string CreatorCode { get; set; }
    }

    public class UpdatePRRequest
    {
        public int PurchaseRequistionID { get; set; }
        public string CostCenterCode { get; set; }
        public string PurchaseTypeCode { get; set; }
        public string PurchaseGroup { get; set; }
        public string PlantCode { get; set; }
        public string PurchaseOrganisationCode { get; set; }
        public string VendorCode { get; set; }
        public string CurrencyCode { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
        public string OnBehalfOfFlag { get; set; }
        public string CreatorCode { get; set; }
    }

    public class PRFilesDTO
    {
        public int PRID { get; set; }
        public string fileNo { get; set; }
        public string FileName { get; set; }
        public string Action { get; set; }
        public string RequisitionNo { get; set; }
        public string FileContent { get; set; }
        public string FilePath { get; set; }
        public string InsertedEMPCode { get; set; }
        public string InsertedIPAddress { get; set; }
        public int fileSize { get; set; }
    }

}
