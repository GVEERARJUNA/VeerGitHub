﻿using P2OBAL.Common;
using System;
using System.Collections.Generic;
using System.Text;


namespace P2OBAL.Approval
{
    public interface IApprovalBL
    {
        ResponseClass GetApprovalLevels(ApprovalRequestDTO approvalRequestBO);

        ResponseClass GetWaitingForApprovalList(ApprovalRequestDTO approvalRequestBO);

        ResponseClass ApprovalstatusUpdate(ApprovalSatatusUpdateRequestDTO updateRequestDTO);

        ResponseClass GetPREntity(GetPREntityRequest getPRNotesRequest);

        ResponseClass GetPRRequistionDataByRequistionNo(PRRequistionDataRequestDTO pRRequistionDataRequestDTO);

        ResponseClass UpdatePRDetail(UpdatePRDetailRequest updatePRDetailRequest);
        ResponseClass GetPRVirtualFlow(PRVirtualFlowRequestDTO prVirtualFlow);
        ResponseClass UpdatePRHeaderRequest(UpdatePRRequest request);
        ResponseClass AddPRFiles(PRFilesDTO pRFilesDTO);
    }
}
