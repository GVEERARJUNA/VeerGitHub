﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace P2OBAL.Reports
{
    public class ReportsBL : IReportsBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;


        public ReportsBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass GetPRReport(PRReportRequestDTO pRReportRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (pRReportRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "getPRNotesRequest required";
                return response;
            }


            if (string.IsNullOrEmpty(pRReportRequestDTO.ReportType))
            {
                response.responseCode = 0;
                response.responseMessage = "pRReportRequestDTO.ReportType required!";
                return response;
            }

            if (pRReportRequestDTO.PageNumber==0)
            {
                pRReportRequestDTO.PageNumber = 1;
            }

            if (pRReportRequestDTO.RowsOfPage == 0)
            {
                pRReportRequestDTO.PageNumber = 20;
            }

            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();

            string fromDate = string.Empty;
            string toDate = string.Empty;
            if (!string.IsNullOrEmpty(pRReportRequestDTO.FromDate))
            {
                dtFrom = Convert.ToDateTime(pRReportRequestDTO.FromDate);
                fromDate = dtFrom.ToString("yyyy-MM-dd");
            }
            if (!string.IsNullOrEmpty(pRReportRequestDTO.FromDate))
            {
                dtTo = Convert.ToDateTime(pRReportRequestDTO.ToDate);
                toDate = dtTo.ToString("yyyy-MM-dd");
            }

            if (pRReportRequestDTO.ReportType== "PRSummary" || pRReportRequestDTO.ReportType == "PRAGING")
            {
                if (dtFrom > dtTo)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid date range selected!";
                    return response;
                }

                TimeSpan difference = dtTo - dtFrom;

                if (difference.TotalDays > 180)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    return response;
                }
            }

            SqlParameter[] parameter = {
                new SqlParameter("@ReportType", Convert.ToString(pRReportRequestDTO.ReportType)),
                new SqlParameter("@FromDate", fromDate),
                new SqlParameter("@ToDate", toDate),
                new SqlParameter("@SearchCriteria1", Convert.ToString(pRReportRequestDTO.SearchCriteria1)),
                new SqlParameter("@SearchCriteria2", Convert.ToString(pRReportRequestDTO.SearchCriteria2)),
                new SqlParameter("@PageNumber", pRReportRequestDTO.PageNumber),
                new SqlParameter("@RowsOfPage", pRReportRequestDTO.RowsOfPage),
                 new SqlParameter("@LoginID", Convert.ToString(pRReportRequestDTO.UserName)),
                new SqlParameter("@CurrentRole", Convert.ToString(pRReportRequestDTO.CurrentRole)),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("RPT_PurchaseRequistion", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");
            

            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                if (Convert.ToString(pRReportRequestDTO.ReportType)== "PRSummary")
                {
                    if (pRReportRequestDTO.PageNumber != -1)
                    {
                        OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / pRReportRequestDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }
               
                

                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

               
            }


            return response;
        }

        public ResponseClass GetHistoricalReport(HistoricalReportDTO historicalReportDTO)
        {
            ResponseClass response = new ResponseClass();

            if (historicalReportDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "historicalReportDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(historicalReportDTO.ReportName))
            {
                response.responseCode = 0;
                response.responseMessage = "historicalReportDTO.ReportName required!";
                return response;
            }

            if (historicalReportDTO.PageNumber == 0)
            {
                historicalReportDTO.PageNumber = 1;
            }

            if (historicalReportDTO.RowsOfPage == 0)
            {
                historicalReportDTO.PageNumber = 20;
            }

            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();

            string fromDate = string.Empty;
            string toDate = string.Empty;
            if (!string.IsNullOrEmpty(historicalReportDTO.FromDate))
            {
                dtFrom = Convert.ToDateTime(historicalReportDTO.FromDate);
                fromDate = dtFrom.ToString("yyyy-MM-dd");
            }
            if (!string.IsNullOrEmpty(historicalReportDTO.FromDate))
            {
                dtTo = Convert.ToDateTime(historicalReportDTO.ToDate);
                toDate = dtTo.ToString("yyyy-MM-dd");
            }

            if (historicalReportDTO.ReportName=="OrderReport")
            {
                if (dtFrom>dtTo)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Invalid date range selected!";
                    return response;
                }

                TimeSpan difference = dtTo - dtFrom;

                if (difference.TotalDays>180)
                {
                    response.responseCode = 0;
                    response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                    return response;
                }
            }
            if (historicalReportDTO.ReportName == "ReceiptReport")
            {
                if (Convert.ToString(historicalReportDTO.CustomParam2)=="3" || Convert.ToString(historicalReportDTO.CustomParam2) == "4")
                {
                    if (dtFrom > dtTo)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Invalid date range selected!";
                        return response;
                    }
                    TimeSpan difference = dtTo - dtFrom;
                    if (difference.TotalDays > 180)
                    {
                        response.responseCode = 0;
                        response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                        return response;
                    }
                }
                
            }

            SqlParameter[] parameter = {
                new SqlParameter("@ReportName", Convert.ToString(historicalReportDTO.ReportName)),
                new SqlParameter("@FromDate", fromDate),
                new SqlParameter("@ToDate", toDate),
                new SqlParameter("@CustomParam1", Convert.ToString(historicalReportDTO.CustomParam1)),
                new SqlParameter("@CustomParam2", Convert.ToString(historicalReportDTO.CustomParam2)),
                new SqlParameter("@CustomParam3", Convert.ToString(historicalReportDTO.CustomParam3)),
                new SqlParameter("@CustomParam4", Convert.ToString(historicalReportDTO.CustomParam4)),
                new SqlParameter("@CustomParam5", Convert.ToString(historicalReportDTO.CustomParam5)),
                new SqlParameter("@CustomParam6", Convert.ToString(historicalReportDTO.CustomParam6)),
                new SqlParameter("@CustomParam7", Convert.ToString(historicalReportDTO.CustomParam7)),
                new SqlParameter("@PageNumber", historicalReportDTO.PageNumber),
                new SqlParameter("@RowsOfPage", historicalReportDTO.RowsOfPage),
                new SqlParameter("@LoginID", Convert.ToString(historicalReportDTO.LoginID)),
                new SqlParameter("@CurrentRole", Convert.ToString(historicalReportDTO.CurrentRole)),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_Historical_Report", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                if (Convert.ToString(historicalReportDTO.ReportName) == "OrderReport" || Convert.ToString(historicalReportDTO.ReportName) == "ReceiptReport" || Convert.ToString(historicalReportDTO.ReportName) == "RequistionReport")
                {
                    if (historicalReportDTO.PageNumber != -1)
                    {
                        OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / historicalReportDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                }



                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);


            }


            return response;
        }

        public ResponseClass GetUserDashboard(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (userDashboardRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "userDashboardRequestDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(userDashboardRequestDTO.ReportType))
            {
                response.responseCode = 0;
                response.responseMessage = "userDashboardRequestDTO.ReportType required!";
                return response;
            }

           
            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();

            string fromDate = string.Empty;
            string toDate = string.Empty;
            if (!string.IsNullOrEmpty(userDashboardRequestDTO.FromDate))
            {
                dtFrom = Convert.ToDateTime(userDashboardRequestDTO.FromDate);
                fromDate = dtFrom.ToString("yyyy-MM-dd");
            }
            if (!string.IsNullOrEmpty(userDashboardRequestDTO.ToDate))
            {
                dtTo = Convert.ToDateTime(userDashboardRequestDTO.ToDate);
                toDate = dtTo.ToString("yyyy-MM-dd");
            }

            if (dtFrom > dtTo)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid date range selected!";
                return response;
            }

            TimeSpan difference = dtTo - dtFrom;

            if (difference.TotalDays > 180)
            {
                response.responseCode = 0;
                response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                return response;
            }

            if (userDashboardRequestDTO.ReportType=="PRList")
            {
                if (userDashboardRequestDTO.PageNumber == 0)
                {
                    userDashboardRequestDTO.PageNumber = 1;
                }

                if (userDashboardRequestDTO.RowsOfPage == 0)
                {
                    userDashboardRequestDTO.PageNumber = 3;
                }
            }
           
            SqlParameter[] parameter = {
                new SqlParameter("@LoginID", Convert.ToString(userDashboardRequestDTO.LoginID)),
                new SqlParameter("@CurrentRole", Convert.ToString(userDashboardRequestDTO.CurrentRole)),
                new SqlParameter("@CompanyCode", Convert.ToString(userDashboardRequestDTO.CompanyCode)),
                new SqlParameter("@ReportType", Convert.ToString(userDashboardRequestDTO.ReportType)),
                new SqlParameter("@FromDate", fromDate),
                new SqlParameter("@ToDate", toDate),
                new SqlParameter("@SearchCriteria1", Convert.ToString(userDashboardRequestDTO.SearchCriteria1)),
                new SqlParameter("@SearchCriteria2", Convert.ToString(userDashboardRequestDTO.SearchCriteria2)),
                 new SqlParameter("@SearchCriteria3", Convert.ToString(userDashboardRequestDTO.SearchCriteria3)),
                new SqlParameter("@PageNumber", Convert.ToInt32(userDashboardRequestDTO.PageNumber)),
                new SqlParameter("@RowsOfPage", Convert.ToInt32(userDashboardRequestDTO.RowsOfPage)),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_GetUserDashboard", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                if (Convert.ToString(userDashboardRequestDTO.ReportType)=="HeaderCount")
                {
                    dsResult.Tables[0].TableName = "TileCount";
                    dsResult.Tables[0].Columns.Add("AmountToShow");
                    try
                    {
                        
                        // INR
                        string displayAmount = string.Empty;
                        double convertToAmount = 0;
                        convertToAmount = Convert.ToDouble(dsResult.Tables[0].Rows[0]["TotalPOAmount"]);
                        displayAmount = NumberExtensions.numberFormat(convertToAmount);
                        dsResult.Tables[0].Rows[0]["AmountToShow"] = displayAmount;

                    }
                    catch (Exception)
                    {

                        dsResult.Tables[0].Rows[0]["AmountToShow"] = 0;
                    }
                    dsResult.Tables[1].TableName = "GEOCount";
                    dsResult.Tables[2].TableName = "ChartCount";
                    response.responseJSON = JsonConvert.SerializeObject(dsResult);
                }
                else if (Convert.ToString(userDashboardRequestDTO.ReportType) == "PRList")
                {
                    if (userDashboardRequestDTO.PageNumber != -1)
                    {
                        OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / userDashboardRequestDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                }
                
                
            }


            return response;
        }

        public ResponseClass GetRDAccress(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (userDashboardRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "userDashboardRequestDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(userDashboardRequestDTO.ReportType))
            {
                response.responseCode = 0;
                response.responseMessage = "userDashboardRequestDTO.ReportType required!";
                return response;
            }


            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();

            string fromDate = string.Empty;
            string toDate = string.Empty;
            if (!string.IsNullOrEmpty(userDashboardRequestDTO.FromDate))
            {
                dtFrom = Convert.ToDateTime(userDashboardRequestDTO.FromDate);
                fromDate = dtFrom.ToString("yyyy-MM-dd");
            }
            if (!string.IsNullOrEmpty(userDashboardRequestDTO.ToDate))
            {
                dtTo = Convert.ToDateTime(userDashboardRequestDTO.ToDate);
                toDate = dtTo.ToString("yyyy-MM-dd");
            }

            if (dtFrom > dtTo)
            {
                response.responseCode = 0;
                response.responseMessage = "Invalid date range selected!";
                return response;
            }

            TimeSpan difference = dtTo - dtFrom;

            if (difference.TotalDays > 180)
            {
                response.responseCode = 0;
                response.responseMessage = "Maximum date range should be 180 days(6 Months)!";
                return response;
            }

            //if (userDashboardRequestDTO.ReportType == "PRList")
            //{

            //}
            if (userDashboardRequestDTO.PageNumber == 0)
            {
                userDashboardRequestDTO.PageNumber = 1;
            }

            if (userDashboardRequestDTO.RowsOfPage == 0)
            {
                userDashboardRequestDTO.PageNumber = 3;
            }

            SqlParameter[] parameter = {
                new SqlParameter("@LoginID", Convert.ToString(userDashboardRequestDTO.LoginID)),
                new SqlParameter("@CurrentRole", Convert.ToString(userDashboardRequestDTO.CurrentRole)),
                new SqlParameter("@CompanyCode", Convert.ToString(userDashboardRequestDTO.CompanyCode)),
                new SqlParameter("@ReportType", Convert.ToString(userDashboardRequestDTO.ReportType)),
                new SqlParameter("@FromDate", fromDate),
                new SqlParameter("@ToDate", toDate),
                new SqlParameter("@SearchCriteria1", Convert.ToString(userDashboardRequestDTO.SearchCriteria1)),
                new SqlParameter("@SearchCriteria2", Convert.ToString(userDashboardRequestDTO.SearchCriteria2)),
                new SqlParameter("@SearchCriteria3", Convert.ToString(userDashboardRequestDTO.SearchCriteria3)),
                new SqlParameter("@SearchCriteria4", Convert.ToString(userDashboardRequestDTO.SearchCriteria4)),
                new SqlParameter("@PageNumber", Convert.ToInt32(userDashboardRequestDTO.PageNumber)),
                new SqlParameter("@RowsOfPage", Convert.ToInt32(userDashboardRequestDTO.RowsOfPage)),
                new SqlParameter("@recordCount",SqlDbType.Int,10,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_RDAccess", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                if (Convert.ToString(userDashboardRequestDTO.ReportType) == "HeaderCount")
                {
                    dsResult.Tables[0].TableName = "TileCount";
                    dsResult.Tables[0].Columns.Add("AmountToShow");
                    //try
                    //{

                    //    // INR
                    //    string displayAmount = string.Empty;
                    //    double convertToAmount = 0;
                    //    convertToAmount = Convert.ToDouble(dsResult.Tables[0].Rows[0]["TotalPOAmount"]);
                    //    displayAmount = NumberExtensions.numberFormat(convertToAmount);
                    //    dsResult.Tables[0].Rows[0]["AmountToShow"] = displayAmount;

                    //}
                    //catch (Exception)
                    //{

                    //    dsResult.Tables[0].Rows[0]["AmountToShow"] = 0;
                    //}
                    //dsResult.Tables[1].TableName = "GEOCount";
                    //dsResult.Tables[2].TableName = "ChartCount";
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                    if (userDashboardRequestDTO.PageNumber != -1)
                    {
                        OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / userDashboardRequestDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                    response.responseJSONSecondary = JsonConvert.SerializeObject(dsResult.Tables[1]);
                }
                else if (Convert.ToString(userDashboardRequestDTO.ReportType) == "PRList")
                {
                    if (userDashboardRequestDTO.PageNumber != -1)
                    {
                        OutParameter RecordCount = outParameters.Find(x => x.ParameterName == "@recordCount");

                        decimal noOfPages = Convert.ToDecimal(Convert.ToDouble(Convert.ToDouble(RecordCount.ParameterValue) / userDashboardRequestDTO.RowsOfPage));

                        int recordPages = Convert.ToInt32(noOfPages);

                        if (noOfPages > recordPages)
                        {
                            recordPages = recordPages + 1;
                        }

                        response.recordCount = recordPages;
                    }
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
                }


            }


            return response;
        }

        public ResponseClass GetWorkFlowReport(WorkflowReportrequestDTO request)
        {
            ResponseClass response = new ResponseClass();

            
            SqlParameter[] parameter = {
                new SqlParameter("@CompanyCode", Convert.ToString(request.CompanyCode)),
               
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("rpt_workflow_summary", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                List<WorkFlowLevelResponse> workFlow = new List<WorkFlowLevelResponse>();
                //var filteredResultsTwo = workFlow.Where(employee => employee.Department == "Software");

                string responseEmailEntity = JsonConvert.SerializeObject(dsResult.Tables[2]);
                workFlow = JsonConvert.DeserializeObject<List<WorkFlowLevelResponse>>(responseEmailEntity);

                StringBuilder emailBodyText = new StringBuilder();
                emailBodyText.Append("<table class='table table-hover table-striped table-blue' border='1'>");
                emailBodyText.Append("<thead>");
                emailBodyText.Append("<tr>");
                emailBodyText.Append("<th>#</th>");
                emailBodyText.Append("<th>Company Code</th>");
                emailBodyText.Append("<th>Company Name</th>");
                emailBodyText.Append("<th>CC Number</th>");

                foreach (DataRow itemHeader in dsResult.Tables[1].Rows)
                {
                    emailBodyText.Append("<th>" + Convert.ToString(itemHeader["HeaderSymbol"])  + " </th>");
                }
              
                emailBodyText.Append("</tr>");
                emailBodyText.Append("</thead>");
                emailBodyText.Append("<tbody>");
                
                int i = 1;
                foreach (DataRow item in dsResult.Tables[0].Rows)
                {

                    var ccResult = workFlow.Where(x => x.CostCenterCode == Convert.ToString(item["CostCenterCode"])).ToList();
                    emailBodyText.Append("<tr>");
                    emailBodyText.Append("<td>" + i + "</td>");
                    emailBodyText.Append("<td>" + Convert.ToString(item["CompanyCode"]) + "</td>");
                    emailBodyText.Append("<td>" + Convert.ToString(item["DisplayName"]) + "</td>");
                    emailBodyText.Append("<td>" + Convert.ToString(item["CostCenterCode"]) + "</td>");
                    if (ccResult!=null && ccResult.Count>0)
                    {
                        foreach (DataRow itemHeader in dsResult.Tables[1].Rows)
                        {
                            StringBuilder appLevelBuilder = new StringBuilder();
                            string CalculateSymbol = Convert.ToString(itemHeader["CalculateSymbol"]);
                            double fromAmount = Convert.ToDouble(itemHeader["FromAmount"]);
                            double toAmount = Convert.ToDouble(itemHeader["ToAmount"]);

                            var symbolResult = ccResult.Where(x => x.CalculateSymbol == CalculateSymbol && x.FromAmount == fromAmount && x.ToAmount == toAmount).FirstOrDefault();

                            if (symbolResult != null && symbolResult.AppLevel != 0)
                            {
                                appLevelBuilder.Append("<table width='100%' border='1' class='amountcell'><tr>");

                                string LastEMPCode = string.Empty;
                                foreach (var ccItem in ccResult)
                                {
                                    
                                    if (ccItem.AppLevel <= symbolResult.AppLevel)
                                    {
                                        if (!string.IsNullOrEmpty(LastEMPCode))
                                        {
                                            if (LastEMPCode!= ccItem.EMPCode)
                                            {
                                                appLevelBuilder.Append("<td>" + ccItem.EMPCode + "    </td>");
                                            }
                                        }
                                        else
                                        {
                                            appLevelBuilder.Append("<td>" + ccItem.EMPCode + "    </td>");
                                        }


                                        LastEMPCode = ccItem.EMPCode;
                                        //appLevelBuilder.Append("<td>" + ccItem.EMPCode + "    </td>");
                                    }
                                }
                                appLevelBuilder.Append("</tr></table>");
                            }

                            emailBodyText.Append("<td>" + appLevelBuilder.ToString() + "</td>");


                        }
                    }
                    
                    emailBodyText.Append("</tr>");


                    i = i + 1;
                }


                
                emailBodyText.Append("</tbody>");
                emailBodyText.Append("<table>");
                response.responseJSON = emailBodyText.ToString();


            }


            return response;
        }
    }
}
