﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Approval;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2OBAL.EmailMgt;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace P2OBAL.MobApp
{
    public class MOBAPPBL : IMOBAPPBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        private IApprovalBL _approvalBl;

        DBConnection dBConnection;

        private IEmailManagementBL _emailManagementBL;

        IFireBaseAPICallBL _apiCall;


        public MOBAPPBL(IOptions<IDBConnection> app, IApprovalBL approvalBL, 
            IEmailManagementBL emailManagementBL, IFireBaseAPICallBL apiCall)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);

            _approvalBl = approvalBL;

            _emailManagementBL = emailManagementBL;
            _apiCall = apiCall;


        }

        public responsePRList MOBAPPManage(MOBAPPDTO mOBAPPDTO)
        {
            responsePRList response = new responsePRList();

            if (mOBAPPDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "mOBAPPDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(mOBAPPDTO.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "mOBAPPDTO.Action required!";
                return response;
            }
            if (string.IsNullOrEmpty(mOBAPPDTO.LoginID))
            {
                response.responseCode = 0;
                response.responseMessage = "mOBAPPDTO.LoginID required!";
                return response;
            }


            DateTime dtFrom = new DateTime();
            DateTime dtTo = new DateTime();

            string fromDate = string.Empty;
            string toDate = string.Empty;
            if (!string.IsNullOrEmpty(mOBAPPDTO.FromDate))
            {
                dtFrom = Convert.ToDateTime(mOBAPPDTO.FromDate);
                fromDate = dtFrom.ToString("yyyy-MM-dd");
            }
            if (!string.IsNullOrEmpty(mOBAPPDTO.FromDate))
            {
                dtTo = Convert.ToDateTime(mOBAPPDTO.ToDate);
                toDate = dtTo.ToString("yyyy-MM-dd");
            }



            SqlParameter[] parameter = {
                new SqlParameter("@SAPCompanyCode", string.Empty),
                new SqlParameter("@Action", Convert.ToString(mOBAPPDTO.Action)),
                new SqlParameter("@LoginID", Convert.ToString(mOBAPPDTO.LoginID)),
                new SqlParameter("@CurrentRole", Convert.ToString(mOBAPPDTO.CurrentRole)),
                new SqlParameter("@FromDate", fromDate),
                new SqlParameter("@ToDate", toDate),
                new SqlParameter("@PRID", Convert.ToString(mOBAPPDTO.PRID)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("USP_MOB_APP_MGT", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                if (Convert.ToString(mOBAPPDTO.Action) == "TODOC")
                {
                    string responseJSON = string.Empty;

                    responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]).ToString();

                    List<PRCountResponse> prCount = new List<PRCountResponse>();

                    if (responseJSON.Length > 0)
                    {
                        prCount = JsonConvert.DeserializeObject<List<PRCountResponse>>(responseJSON);

                        response.responseList = prCount;
                    }
                }

                if (Convert.ToString(mOBAPPDTO.Action) == "TODOL")
                {
                    string responseJSON = string.Empty;

                    responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]).ToString();

                    List<PRList> prList = new List<PRList>();

                    if (responseJSON.Length > 0)
                    {
                        prList = JsonConvert.DeserializeObject<List<PRList>>(responseJSON);



                        if (prList.Count > 0)
                        {

                            foreach (var item in prList)
                            {

                                GetPREntityRequest requestDTOdetails = new GetPREntityRequest();
                                requestDTOdetails.PurchaseRequistionID = item.PurchaseRequistionID;
                                requestDTOdetails.SearchType = "DETAILLINE";
                                var detailResponse = _approvalBl.GetPREntity(requestDTOdetails);
                                if (detailResponse.responseCode == 1)
                                {
                                    List<PRDetailList> prDetailList = new List<PRDetailList>();
                                    if (detailResponse.responseJSON.ToString().Length > 0)
                                    {
                                        prDetailList = JsonConvert.DeserializeObject<List<PRDetailList>>(detailResponse.responseJSON.ToString());
                                        if (prDetailList.Count > 0)
                                        {
                                            foreach (var itemdetail in prDetailList)
                                            {
                                                itemdetail.MaterialImage = appSettings.Value.MaterialImagePath + itemdetail.MaterialImage.Replace("~/", "");
                                            }
                                        }
                                        item.prDetails = prDetailList;
                                    }

                                }


                            }


                            response.responseList = prList;
                        }
                    }

                    response.responseJSON = "";

                }

                if (Convert.ToString(mOBAPPDTO.Action) == "APPROVEDL")
                {
                    string responseJSON = string.Empty;

                    responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]).ToString();

                    List<PRList> prList = new List<PRList>();

                    if (responseJSON.Length > 0)
                    {
                        prList = JsonConvert.DeserializeObject<List<PRList>>(responseJSON);



                        if (prList.Count > 0)
                        {

                            foreach (var item in prList)
                            {

                                GetPREntityRequest requestDTOdetails = new GetPREntityRequest();
                                requestDTOdetails.PurchaseRequistionID = item.PurchaseRequistionID;
                                requestDTOdetails.SearchType = "DETAILLINE";
                                var detailResponse = _approvalBl.GetPREntity(requestDTOdetails);
                                if (detailResponse.responseCode == 1)
                                {
                                    List<PRDetailList> prDetailList = new List<PRDetailList>();
                                    if (detailResponse.responseJSON.ToString().Length > 0)
                                    {
                                        prDetailList = JsonConvert.DeserializeObject<List<PRDetailList>>(detailResponse.responseJSON.ToString());
                                        if (prDetailList.Count > 0)
                                        {
                                            foreach (var itemdetail in prDetailList)
                                            {
                                                itemdetail.MaterialImage = appSettings.Value.LinkUrl + itemdetail.MaterialImage.Replace("~/", "");
                                            }
                                        }
                                        item.prDetails = prDetailList;
                                    }

                                }


                            }


                            response.responseList = prList;
                        }
                    }

                    response.responseJSON = "";

                }

                if (Convert.ToString(mOBAPPDTO.Action) == "COMMENTS")
                {
                    response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);

                    if (response.responseJSON.ToString().Length > 0)
                    {

                        List<PRCommentsResponse> prComents = new List<PRCommentsResponse>();

                        prComents = JsonConvert.DeserializeObject<List<PRCommentsResponse>>(response.responseJSON.ToString());

                        response.responseList = prComents;
                    }

                    response.responseJSON = "";
                }

                if (Convert.ToString(mOBAPPDTO.Action) == "APPFLOW")
                {
                    string responseJSON = string.Empty;

                    responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]).ToString();

                    List<ApprovalResponseTreeData> appFlow = new List<ApprovalResponseTreeData>();

                    if (responseJSON.Length > 0)
                    {
                        appFlow = JsonConvert.DeserializeObject<List<ApprovalResponseTreeData>>(responseJSON);

                        response.responseList = appFlow;
                    }
                }

            }
            return response;
        }

        public responsePRList ApprovalstatusUpdate(UpdatePRApprovalRequestDTO updateRequestDTO)
        {
            responsePRList response = new responsePRList();


            if (updateRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "updateRequestDTO required";
                return response;
            }
            if (updateRequestDTO.ApproverId == "")
            {
                response.responseCode = 0;
                response.responseMessage = "ApproverId is required";
                return response;
            }
            if (updateRequestDTO.PRApprovalMatrixID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "MatrixId is required";
                return response;
            }
            if (updateRequestDTO.PurchaseRequistionID == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "PurchaseRequistionID is required";
                return response;
            }
            
            if (updateRequestDTO.ApprovalStatus == 0)
            {
                response.responseCode = 0;
                response.responseMessage = "Approval Status is required";
                return response;
            }


            try
            {
                List<OutParameter> outParameters = new List<OutParameter>();

                SqlParameter[] parameter = {
                     new SqlParameter("@PRApprovalMatrixID", updateRequestDTO.PRApprovalMatrixID),
                     new SqlParameter("@PurchaseRequistionID", updateRequestDTO.PurchaseRequistionID),
                     new SqlParameter("@ApprovalStatus",updateRequestDTO.ApprovalStatus),
                     new SqlParameter("@Remark",updateRequestDTO.Remark),
                    new SqlParameter("@ApproverId", updateRequestDTO.ApproverId),
                   new SqlParameter("@ApproverDeviceID",updateRequestDTO.ApproverDeviceID),

                    new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                     new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
                    };

                int result = dBConnection.ExecuteNonQuery("MOB_update_approval_status", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

                if (response.responseCode == 1)
                {
                    try
                    {
                        EmailManagementDTO emailManagementDTO = new EmailManagementDTO();
                        if (updateRequestDTO.ApprovalStatus == 4)
                        {
                            emailManagementDTO.EmailType = "Approver";
                        }
                        if (updateRequestDTO.ApprovalStatus == 3)
                        {
                            emailManagementDTO.EmailType = "Reject";
                        }

                        //emailManagementDTO.RequistionNo = response.responseReturnNo;
                        emailManagementDTO.PRID = Convert.ToString(updateRequestDTO.PurchaseRequistionID);

                        ResponseClass responseEmail = new ResponseClass();
                        responseEmail = _emailManagementBL.GetEmailContent(emailManagementDTO);
                    }
                    catch (Exception)
                    {


                    }
                }
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = ex.Message;
            }

            return response;
        }

        public ResponseClass SendFCMNotification(fcmnotificationresponseDTO fcmnotificationresponseDTO)
        {
            ResponseClass response = new ResponseClass();
            //FireBaseAPICallBL fireBaseAPICallBL = new FireBaseAPICallBL();
            if (string.IsNullOrEmpty(fcmnotificationresponseDTO.EMPID))
            {
                response.responseCode = 0;
                response.responseMessage = "fcmnotificationresponseDTO.EMPID required!";
                return response;
            }
            if (string.IsNullOrEmpty(fcmnotificationresponseDTO.FCMTitle))
            {
                response.responseCode = 0;
                response.responseMessage = "fcmnotificationresponseDTO.FCMTitle required!";
                return response;
            }
            if (string.IsNullOrEmpty(fcmnotificationresponseDTO.FCMBody))
            {
                response.responseCode = 0;
                response.responseMessage = "fcmnotificationresponseDTO.FCMBody required!";
                return response;
            }

            // first get device token
            string deviceTokenQuery = string.Empty;
            string deviceToken = string.Empty;
            deviceTokenQuery = "select FireBaseToken,DeviceId  from FireBaseTokenDetails where EmployeeId ='" + fcmnotificationresponseDTO.EMPID + "' ";
            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteNonQueryInlineMobile(deviceTokenQuery, appSettings.Value.MobileTokenDbConnection);
            if (dsResult!=null && dsResult.Tables.Count>0)
            {
                if (dsResult.Tables[0].Rows.Count>0)
                {
                    deviceToken = Convert.ToString(dsResult.Tables[0].Rows[0]["FireBaseToken"]);
                }
            }

            if (!string.IsNullOrEmpty(deviceToken))
            {
                var fcmResponse = _apiCall.FBCall(deviceToken,Convert.ToString(fcmnotificationresponseDTO.FCMTitle), Convert.ToString(fcmnotificationresponseDTO.FCMBody));
            }
            return response;
        }

        public responsePRList getPODetail(getPODetailRequestDTO request)
        {
            responsePRList response = new responsePRList();

            if (request == null)
            {
                response.responseCode = 0;
                response.responseMessage = "request required";
                return response;
            }


            if (string.IsNullOrEmpty(request.PRNumber))
            {
                response.responseCode = 0;
                response.responseMessage = "request.PRNumber required!";
                return response;
            }
           
            SqlParameter[] parameter = {
                new SqlParameter("@PRNumber", request.PRNumber),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_getPODetail_by_PRNo", parameter, outParameters);

            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = Convert.ToString(resultMessage.ParameterValue);

            if (dsResult != null && dsResult.Tables.Count > 0)
            {
                string responseJSON = string.Empty;

                responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]).ToString();

                List<getPODetailResponseDTO> prCount = new List<getPODetailResponseDTO>();

                if (responseJSON.Length > 0)
                {
                    prCount = JsonConvert.DeserializeObject<List<getPODetailResponseDTO>>(responseJSON);

                    response.responseList = prCount;
                }
            }
            return response;
        }
    }
}
