﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.CatalogueManagement
{
    public class CatalogueManagementSearchRequestDTO
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string SupplierCode { get; set; }
        public string MaterialCode { get; set; }
        public string PlantCode { get; set; }
        public int PublishStatus { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }

    public class CatalogueDataUploadRequestDTO
    {
        public string CompanyCode { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }

        public List<CatalogueDataUploadRequestLines> catalogueDataUploadRequestLines { get; set; }
    }

    public class CatalogueDataUploadRequestLines
    {
      
        public string CatalogueDataID { get; set; }
        public string SupplierCode { get; set; }
        public string SupplierPartID { get; set; }
        public string MaterialCode { get; set; }
        public string ItemDescription { get; set; }
        public string UnitPrice { get; set; }
        public string UOM { get; set; }
        public string Currency { get; set; }
        public string ShortName { get; set; }
        public string PlantCode { get; set; }
        public string Image { get; set; }
    }

    public class UpdatePublishStatusRequestDTO
    {
        public List<UpdatePublishStatusRequestLinesDTO> updatePublishStatusRequestLines { get; set; }
        public string InsertedBy { get; set; }
        public string InsertedIPAddress { get; set; }
    }

    public class UpdatePublishStatusRequestLinesDTO
    {
        public string CatalogueDataID { get; set; }
        public int PublishStatus { get; set; }
    }

    public class SearchCatalogueDataRequestDTO
    {
        public int SearchType { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
        public string SearchText { get; set; }
        public string CompanyCode { get; set; }
        public string EmpCode { get; set; }
    }
}
