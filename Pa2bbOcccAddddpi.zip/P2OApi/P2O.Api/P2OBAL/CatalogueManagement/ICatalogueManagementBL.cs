﻿using P2OBAL.Common;

namespace P2OBAL.CatalogueManagement
{
    public interface ICatalogueManagementBL
    {
        ResponseClass UploadCatalogue(CatalogueDataUploadRequestDTO catalogueDataUploadRequestDTO);
        ResponseClass ManageCatalogue(CatalogueManagementSearchRequestDTO catalogueManagementSearchRequestDTO);
        ResponseClass UpdateCataloguePublishStatus(UpdatePublishStatusRequestDTO updatePublishStatusRequest);
        ResponseClass SearchCatalogueData(SearchCatalogueDataRequestDTO searchCatalogueDataRequestDTO);
    }
}