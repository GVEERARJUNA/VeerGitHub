﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2OBAL.EmailMgt;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;
using System.Web;
using System.Xml;

namespace P2OBAL.PurchaseRequistion
{
    public class PurchaseRequistionBL : IPurchaseRequistionBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        private IEmailManagementBL _emailManagementBL;

        public PurchaseRequistionBL(IOptions<IDBConnection> app, IEmailManagementBL managementBL)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);

            _emailManagementBL = managementBL;
        }

        public ResponseClass CreatePurchaseRequistion(PurchaseRequistionDTO shoppingCart)
        {
            ResponseClass response = new ResponseClass();
            string MyXML = string.Empty;
            string MyFileXML = string.Empty;

            try
            {
                if (shoppingCart == null)
                {
                    response.responseCode = 0;
                    response.responseMessage = "shoppingCart required";
                    return response;
                }


                if (string.IsNullOrEmpty(shoppingCart.CostCenterCode))
                {
                    response.responseCode = 0;
                    response.responseMessage = "shoppingCart.CostCenterCode required!";
                    return response;
                }

                string insertQuery = string.Empty;

                XmlDocument xmlDocument = new XmlDocument();

                //insertQuery = "insert into PurchaseRequistionDetails(PurchaseRequistionID,MaterialCode,GLCode," +
                //    "ProductType,Amount,Quantity,NetAmount,LineComments,InsertedBy,InsertedIPAddress)values";
                
                MyXML = "<detailLines>";
                
                int fileCount = 0;
                
                

                if (shoppingCart.shoppingCartDetails != null && shoppingCart.shoppingCartDetails.Count > 0)
                {
                    
                    foreach (var item in shoppingCart.shoppingCartDetails)
                    {
                        string nDate = string.Empty;
                        string WSDate = string.Empty;
                        string WEDate = string.Empty;
                        try
                        {
                            nDate = Convert.ToDateTime(item.NeededByDate).ToString("yyyy-MM-dd");

                        }
                        catch (Exception ex)
                        {
                            WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion needed by date :" + ex.Message);

                        }
                        if (shoppingCart.PurchaseTypeCode=="4" || shoppingCart.PurchaseTypeCode == "5" || shoppingCart.PurchaseTypeCode == "7")
                        {
                            
                            try
                            {
                                WSDate = Convert.ToDateTime(item.WarrantyStartDate).ToString("yyyy-MM-dd");
                            }
                            catch (Exception ex)
                            {

                                WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion Warranty start date :" + ex.Message);
                            }
                            try
                            {
                                WEDate = Convert.ToDateTime(item.WarrantyEndDate).ToString("yyyy-MM-dd");
                            }
                            catch (Exception ex)
                            {

                                WriteLogFile.WriteLog("Exception", "Exception in creating purchase requistion Warranty end date :" + ex.Message);
                            }
                        }
                        


                        MyXML += "<detailLine>";
                        MyXML += "<MaterialCode>" + Convert.ToString(item.MaterialCode) + "</MaterialCode>";
                        MyXML += "<GLCode>" + Convert.ToString(item.GLCode) + "</GLCode>";
                        MyXML += "<ProductType>" + HttpUtility.HtmlEncode(item.ProductType) + "</ProductType>";
                        MyXML += "<MaterialAmount>" + item.MaterialAmount + "</MaterialAmount>";
                        MyXML += "<MaterialQuantity>" + item.MaterialQuantity + "</MaterialQuantity>";
                        MyXML += "<NetAmount>" + item.NetAmount + "</NetAmount>";
                        MyXML += "<Comments>" + HttpUtility.HtmlEncode(item.Comments) + "</Comments>";
                        MyXML += "<CatalogueDataID>" + Convert.ToString(item.CatalogueDataID) + "</CatalogueDataID>";
                        MyXML += "<NeededByDate>" + Convert.ToString(nDate) + "</NeededByDate>";
                        MyXML += "<WarrantyStartDate>" + Convert.ToString(WSDate) + "</WarrantyStartDate>";
                        MyXML += "<WarrantyEndDate>" + Convert.ToString(WEDate) + "</WarrantyEndDate>";
                        MyXML += "<TaxCode>" + Convert.ToString(item.TaxCode) + "</TaxCode>";
                        MyXML += "</detailLine>";
                        if (item.cartFiles!=null)
                        {
                            fileCount = item.cartFiles.Count;
                        }
                        

                    }

                    MyXML += "</detailLines>";

                    if (fileCount > 0)
                    {
                        MyFileXML = "<detailLines>";

                        foreach (var itemFile in shoppingCart.shoppingCartDetails)
                        {
                            if (itemFile.cartFiles!=null && itemFile.cartFiles.Count>0)
                            {
                                foreach (var itemfiles in itemFile.cartFiles)
                                {
                                    MyFileXML += "<detailLine>";

                                    MyFileXML += "<FileName>" + Convert.ToString(itemfiles.FileName) + "</FileName>";
                                    MyFileXML += "<FileContent>" + HttpUtility.HtmlEncode(itemfiles.FileContent) + "</FileContent>";
                                    MyFileXML += "<FilePath>" + Convert.ToString(itemfiles.FilePath) + "</FilePath>";
                                    MyFileXML += "</detailLine>";
                                }
                            }
                            
                        }

                        MyFileXML += "</detailLines>";
                    }


                }
                else
                {
                    response.responseCode = 0;
                    response.responseMessage = "There is no item added in cart!";
                    return response;
                }


                SqlParameter[] parameter = {
                 new SqlParameter("@CartType", Convert.ToString(shoppingCart.CartType)),
                 new SqlParameter("@BudgetMode", Convert.ToString(shoppingCart.BudgetMode)),
                 new SqlParameter("@PurchaseTypeCode", shoppingCart.PurchaseTypeCode),
                 new SqlParameter("@PurchaseGroup", shoppingCart.PurchaseGroup),
                 new SqlParameter("@CostCenterFlag", shoppingCart.CostCenterFlag),
                 new SqlParameter("@CostCenterCode", shoppingCart.CostCenterCode),
                 new SqlParameter("@PlantCode", shoppingCart.PlantCode),
                 new SqlParameter("@ShippingPlantCode", Convert.ToString(shoppingCart.ShippingPlantCode)),
                 new SqlParameter("@PurchaseOrganisationCode", shoppingCart.PurchaseOrganisationCode),
                 new SqlParameter("@VendorCode", shoppingCart.VendorCode),
                 new SqlParameter("@OnBehalfOfFlag", shoppingCart.OnBehalfOfFlag),
                 new SqlParameter("@CreatorCode", shoppingCart.CreatorCode),
                 new SqlParameter("@CurrencyCode", shoppingCart.Currency),
                 new SqlParameter("@InsertedBy", shoppingCart.InsertedBy),
                 new SqlParameter("@InsertedIPAddress", shoppingCart.InsertedIPAddress),
                  new SqlParameter("@HeaderShortText", Convert.ToString(shoppingCart.HeaderShortText)),
                // string encodedXml = HttpUtility.HtmlEncode(MyXML);
                new SqlParameter("@DetailText", (MyXML)),
                new SqlParameter("@fileText", (MyFileXML)),
                 new SqlParameter("@PurchaseRequistionID",SqlDbType.Int,11,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@RequistionNo",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)
            };

                List<OutParameter> outParameters = new List<OutParameter>();

                int result = dBConnection.ExecuteNonQuery("PRC_PurchaseRequistion_Create", parameter, outParameters);

                OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
                OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");
                OutParameter requistionNo = outParameters.Find(x => x.ParameterName == "@RequistionNo");

                if (Convert.ToInt32(resultrcode.ParameterValue) > 0)
                {
                    response.responseReturnNo = requistionNo.ParameterValue;
                    try
                    {
                        EmailManagementDTO emailManagementDTO = new EmailManagementDTO();
                        emailManagementDTO.RequistionNo = response.responseReturnNo;
                        emailManagementDTO.EmailType = "Approver";
                        ResponseClass responseEmail = new ResponseClass();
                        responseEmail = _emailManagementBL.GetEmailContent(emailManagementDTO);
                    }
                    catch (Exception ex)
                    {
                        WriteLogFile.WriteLog("Exception", "Exception in sending email when PR created :" + ex.Message);

                    }
                   
                }



                response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
                response.responseMessage = resultMessage.ParameterValue;
            }
            catch (Exception ex)
            {

                response.responseCode = 0;
                response.responseMessage = "There is some issue when saving Purchase requistion.Please contact to technical team.";
                WriteLogFile.WriteLog("Exception", "Exception in generate when PR created :" + ex.Message + MyXML + "File Data" + MyFileXML);
            }

            

            return response;
        }
    }
}
