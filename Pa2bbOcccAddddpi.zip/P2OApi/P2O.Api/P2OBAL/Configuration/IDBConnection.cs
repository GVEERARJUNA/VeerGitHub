﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Configuration
{
    public class IDBConnection
    {
        public string DbConnection { get; set; }
        public string EmployeePhoto { get; set; }
        public string MasterPassword { get; set; }
        public string SmtpHostName { get; set; }
        public string BccList { get; set; }
        public string Sender { get; set; }
        public string SenderName { get; set; }
        public string Redirection { get; set; }
        public string MailRedirectionTo { get; set; }
        public string MailRedirectionCc { get; set; }

        public string LinkUrl { get; set; }

        public string FileAccessPath { get; set; }
        public string WEBAPI { get; set; }
        public string MaterialImagePath { get; set; }
        public string ApproverLink { get; set; }
        public string FirebaseAPIUrl { get; set; }
        public string FirebaseKey { get; set; }
        public string FirebaseSenderId { get; set; }
        public string FingerPrintToken { get; set; }
        public string MobileTokenDbConnection { get; set; }
    }
}
