﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Text;

namespace P2OBAL.CurrencyConversionManagement
{
    public class CurrencyConversionBL : ICurrencyConversionBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        public CurrencyConversionBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass ManageCurrencyConversion(ManageCurrencyConversionDTO currencyConversionDTO)
        {
            ResponseClass response = new ResponseClass();

            if (currencyConversionDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "currencyConversionDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(currencyConversionDTO.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "currencyConversionDTO.Action required!";
                return response;
            }


            SqlParameter[] parameter = {
                new SqlParameter("@Action", Convert.ToString(currencyConversionDTO.Action)),
                new SqlParameter("@FromCurrency", Convert.ToString(currencyConversionDTO.FromCurrency)),
                new SqlParameter("@ToCurrency", Convert.ToString(currencyConversionDTO.ToCurrency)),
                new SqlParameter("@ConversionRate", Convert.ToDouble(currencyConversionDTO.ConversionRate)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_ManageCurrencyConversion", parameter, outParameters);
            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (currencyConversionDTO.Action == "L")
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        //response.responseJSON = (JsonConvert.SerializeObject(dsResult));
                        foreach (DataRow item in dsResult.Tables[0].Rows)
                        {
                            double conversionRate = 0.0;
                            string fromCurrency = string.Empty;
                            string toCurrency = string.Empty;
                            fromCurrency = Convert.ToString(item["FromCurrency"]);
                            toCurrency = Convert.ToString(item["ToCurrency"]);
                            conversionRate = GetConversionRates(toCurrency,fromCurrency);
                            ManageCurrencyConversionDTO saveCurrencyConversion = new ManageCurrencyConversionDTO();
                            saveCurrencyConversion.Action = "A";
                            saveCurrencyConversion.FromCurrency = toCurrency;
                            saveCurrencyConversion.ToCurrency = fromCurrency;
                            saveCurrencyConversion.ConversionRate = conversionRate;
                            try
                            {
                                var saveResponse = SaveCurrencyConversion(saveCurrencyConversion);
                            }
                            catch (Exception)
                            {

                                
                            }
                            
                        }

                    }
                }

            }


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;
            return response;
        }

        public double GetConversionRates(string fromCurrency, string toCurrency)
        {
            var url = "https://api.apilayer.com/currency_data/convert?to=" + toCurrency + "&from=" + fromCurrency + "&amount=1";
            var httpRequest = (HttpWebRequest)WebRequest.Create(url);
            CCDTO ccDTO = new CCDTO();


            httpRequest.Accept = "application/json";
            httpRequest.Headers["apikey"] = "2uFC0jfYhwupADZsTUNVGVWtLvsX0oP2";
            var httpResponse = (HttpWebResponse)httpRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {

                var result = streamReader.ReadToEnd();
                ccDTO = JsonConvert.DeserializeObject<CCDTO>(result);
                if (ccDTO != null)
                {
                    if (ccDTO.success == "true")
                    {
                        return Convert.ToDouble(ccDTO.result);
                    }
                }

            }

            return 0.0;
        }

        public ResponseClass SaveCurrencyConversion(ManageCurrencyConversionDTO currencyConversionDTO)
        {
            ResponseClass response = new ResponseClass();
            SqlParameter[] parameter = {
                new SqlParameter("@Action", Convert.ToString(currencyConversionDTO.Action)),
                new SqlParameter("@FromCurrency", Convert.ToString(currencyConversionDTO.FromCurrency)),
                new SqlParameter("@ToCurrency", Convert.ToString(currencyConversionDTO.ToCurrency)),
                new SqlParameter("@ConversionRate", Convert.ToDouble(currencyConversionDTO.ConversionRate)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_ManageCurrencyConversion", parameter, outParameters);
            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            return response;
        }

        public ResponseClass CurrencyConversion(CurrencyConversionMGTDTO currencyConversionMGTDTO)
        {
            ResponseClass response = new ResponseClass();

            if (currencyConversionMGTDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "currencyConversionMGTDTO required";
                return response;
            }


            if (string.IsNullOrEmpty(currencyConversionMGTDTO.Action))
            {
                response.responseCode = 0;
                response.responseMessage = "currencyConversionMGTDTO.Action required!";
                return response;
            }

            if (string.IsNullOrEmpty(currencyConversionMGTDTO.InsertedBy))
            {
                response.responseCode = 0;
                response.responseMessage = "currencyConversionMGTDTO.InsertedBy required!";
                return response;
            }
            if (string.IsNullOrEmpty(currencyConversionMGTDTO.InsertedIPAddress))
            {
                response.responseCode = 0;
                response.responseMessage = "currencyConversionMGTDTO.InsertedIPAddress required!";
                return response;
            }
            else if (Convert.ToString(currencyConversionMGTDTO.InsertedIPAddress).Length > 100)
            {
                response.responseCode = 0;
                response.responseMessage = "currencyConversionMGTDTO.InsertedIPAddress lenght cannot exceed 100 characters!";
                return response;
            }
            
            SqlParameter[] parameter = {
                new SqlParameter("@CurrencyConversionID", Convert.ToInt32(currencyConversionMGTDTO.CurrencyConversionID)),
                new SqlParameter("@ConversionYear", Convert.ToInt32(currencyConversionMGTDTO.ConversionYear)),
                new SqlParameter("@ConversionMonth", Convert.ToInt32(currencyConversionMGTDTO.ConversionMonth)),
                new SqlParameter("@Action", Convert.ToString(currencyConversionMGTDTO.Action)),
                new SqlParameter("@FromCurrency", Convert.ToString(currencyConversionMGTDTO.FromCurrency)),
                new SqlParameter("@ToCurrency", Convert.ToString(currencyConversionMGTDTO.ToCurrency)),
                new SqlParameter("@ConversionRate", Convert.ToDouble(currencyConversionMGTDTO.ConversionRate)),
                new SqlParameter("@InsertedBy", Convert.ToString(currencyConversionMGTDTO.InsertedBy)),
                new SqlParameter("@InsertedIPAddress", Convert.ToString(currencyConversionMGTDTO.InsertedIPAddress)),
                new SqlParameter("@rcode",SqlDbType.Int,4,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0),
                 new SqlParameter("@rmessage",SqlDbType.VarChar,50,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_CurrencyConversionManage", parameter, outParameters);
            OutParameter resultrcode = outParameters.Find(x => x.ParameterName == "@rcode");
            OutParameter resultMessage = outParameters.Find(x => x.ParameterName == "@rmessage");

            if (resultrcode.ParameterValue == "1")
            {
                if (currencyConversionMGTDTO.Action == "L")
                {
                    if (dsResult != null && dsResult.Tables.Count > 0)
                    {
                        response.responseJSON = (JsonConvert.SerializeObject(dsResult.Tables[0]));
                       

                    }
                }

            }


            response.responseCode = Convert.ToInt32(resultrcode.ParameterValue);
            response.responseMessage = resultMessage.ParameterValue;
            return response;
        }
    }
    public class CCDTO
    {
        public string success { get; set; }
        public string result { get; set; }
    }

    
}
