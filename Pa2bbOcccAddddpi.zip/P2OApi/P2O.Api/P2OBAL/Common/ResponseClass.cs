﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Common
{
    public class ResponseClass
    {
        public int recordCount { get; set; }
        public int responseCode { get; set; }
        public string responseMessage { get; set; }
        public object responseJSON { get; set; }
        public object responseJSONSecondary { get; set; }
        public string responsecompress { get; set; }
        public string responseReturnNo {get;set;}

    }
}
