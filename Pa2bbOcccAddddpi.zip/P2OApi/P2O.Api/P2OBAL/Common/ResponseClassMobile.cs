﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.Common
{
   public class ResponseClassMobile
    {
        public string output { get; set; }
    }
}
