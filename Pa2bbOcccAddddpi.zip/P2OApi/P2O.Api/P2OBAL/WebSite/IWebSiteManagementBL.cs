﻿using P2OBAL.Common;

namespace P2OBAL.WebSite
{
    public interface IWebSiteManagementBL
    {
        ResponseClass GetProductListing(GetProductListingRequestDTO getProductListingRequestDTO);
    }
}