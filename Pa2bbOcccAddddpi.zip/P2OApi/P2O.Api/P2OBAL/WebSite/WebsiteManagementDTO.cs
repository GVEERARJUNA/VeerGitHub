﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2OBAL.WebSite
{
   public class GetProductListingRequestDTO
    {
        public string UserID { get; set; }
        public string ProductSearchText { get; set; }

        public string SearchType { get; set; }
        public string ProductCode { get; set; }
        public int PageNumber { get; set; }
        public int RowsOfPage { get; set; }
    }
}
