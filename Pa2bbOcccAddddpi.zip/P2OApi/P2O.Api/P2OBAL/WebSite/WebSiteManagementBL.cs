﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2ODAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Text;

namespace P2OBAL.WebSite
{
    public class WebSiteManagementBL : IWebSiteManagementBL
    {
        private readonly IOptions<IDBConnection> appSettings;

        DBConnection dBConnection;

        public WebSiteManagementBL(IOptions<IDBConnection> app)
        {
            appSettings = app;

            dBConnection = new DBConnection(appSettings.Value.DbConnection);
        }

        public ResponseClass GetProductListing(GetProductListingRequestDTO getProductListingRequestDTO)
        {
            ResponseClass response = new ResponseClass();

            if (getProductListingRequestDTO == null)
            {
                response.responseCode = 0;
                response.responseMessage = "getProductListingRequestDTO required";
                return response;
            }


            //if (string.IsNullOrEmpty(getProductListingRequestDTO.UserID))
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "getProductListingRequestDTO.UserID required!";
            //    return response;
            //}

            //if (getProductListingRequestDTO.PageNumber == 0)
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "getProductListingRequestDTO.PageNumber required!";
            //    return response;
            //}

            //if (getProductListingRequestDTO.RowsOfPage == 0)
            //{
            //    response.responseCode = 0;
            //    response.responseMessage = "getProductListingRequestDTO.RowsOfPage required!";
            //    return response;
            //}


            SqlParameter[] parameter = {
                new SqlParameter("@UserID", getProductListingRequestDTO.UserID),
                new SqlParameter("@ProductSearchText", getProductListingRequestDTO.ProductSearchText),

                new SqlParameter("@SearchType", Convert.ToString(getProductListingRequestDTO.SearchType)),
                new SqlParameter("@ProductCode", Convert.ToString(getProductListingRequestDTO.ProductCode)),

                 new SqlParameter("@PageNumber", getProductListingRequestDTO.PageNumber),
                  new SqlParameter("@RowsOfPage", getProductListingRequestDTO.RowsOfPage),
                 new SqlParameter("@recordCount",SqlDbType.Int,11,ParameterDirection.Output,false,0,0,"",DataRowVersion.Default,0)

            };

            List<OutParameter> outParameters = new List<OutParameter>();
            DataSet dsResult = new DataSet();
            dsResult = dBConnection.ExecuteDataSet("PRC_Product_Listing", parameter, outParameters);

            OutParameter recordCount = outParameters.Find(x => x.ParameterName == "@recordCount");


            if (dsResult != null && dsResult.Tables.Count > 0)
            {

                if (getProductListingRequestDTO.PageNumber != -1)
                {

                    response.recordCount = Convert.ToInt32(recordCount.ParameterValue);
                }

                response.responseJSON = JsonConvert.SerializeObject(dsResult.Tables[0]);
            }
            response.responseCode = 1;
            response.responseMessage = "SUCCESS";

            return response;
        }
    }
}
