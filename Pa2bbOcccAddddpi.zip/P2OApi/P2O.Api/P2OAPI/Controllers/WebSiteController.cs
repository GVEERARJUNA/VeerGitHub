﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OBAL.Common;
using P2OBAL.WebSite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class WebSiteController : Controller
    {
        private IWebSiteManagementBL _webSiteManagementBL;

        private readonly ILogger<UserManagementController> _logger;

        public WebSiteController(IWebSiteManagementBL webSiteManagementBL, ILogger<UserManagementController> logger)
        {
            _webSiteManagementBL = webSiteManagementBL;
            _logger = logger;
        }

        [HttpPost]
        public ResponseClass GetProductListing(GetProductListingRequestDTO getProductListingRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _webSiteManagementBL.GetProductListing(getProductListingRequestDTO);
            return response;
        }
    }
}
