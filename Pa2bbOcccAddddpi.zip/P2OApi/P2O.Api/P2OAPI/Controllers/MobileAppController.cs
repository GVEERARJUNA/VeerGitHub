﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using P2OAPI.ServiceConnect;
using P2OBAL.Common;
using P2OBAL.MobApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace P2OAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class MobileAppController : Controller
    {
        private IMOBAPPBL _IMOBAPPBL;

        private readonly ILogger<MobileAppController> _logger;
        private readonly IMyServiceConnect _serviceconnect;

        public MobileAppController(IMOBAPPBL mobAppBL, ILogger<MobileAppController> logger, IMyServiceConnect serviceconnect)
        {
            _IMOBAPPBL = mobAppBL;
            _logger = logger;
            _serviceconnect = serviceconnect;
        }

        [HttpPost]
        public ResponseClassMobile MOBAPPManage(MOBAPPRequest mOBAPPRequest)
        {
            ResponseClassMobile responseclass = new ResponseClassMobile();
            responsePRList response = new responsePRList();
            //if (!string.IsNullOrEmpty(mOBAPPRequest.input))
            //{
            //   // CommonFunction commonFunction = new CommonFunction();
            //    //string approvalEmpCode = commonFunction.Decrypt(HttpUtility.HtmlEncode(mOBAPPDTO.LoginID));
            //   // mOBAPPDTO.LoginID = approvalEmpCode;
            //}
            MOBAPPDTO mOBAPPDTO = new MOBAPPDTO();
            mOBAPPDTO = JsonConvert.DeserializeObject<MOBAPPDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));
            response = _IMOBAPPBL.MOBAPPManage(mOBAPPDTO);
            responseclass.output = (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            var decrypt= JsonConvert.DeserializeObject(EncryptDecryptAES.DecryptStringAES(responseclass.output));
            return responseclass;
        }

        [HttpPost]
        public ResponseClassMobile ApprovalstatusUpdate(MOBAPPRequest mOBAPPRequest)
        {
            string Path = HttpContext.Request.Host.ToString();
            WriteLogFile.WriteLog("Information", "API Call");
            WriteLogFile.WriteLog("Information", Path);
            ResponseClassMobile responseclass = new ResponseClassMobile();
            responsePRList response = new responsePRList();
            
            UpdatePRApprovalRequestDTO updateRequestDTO = new UpdatePRApprovalRequestDTO();
            updateRequestDTO = JsonConvert.DeserializeObject<UpdatePRApprovalRequestDTO>(EncryptDecryptAES.DecryptStringAES(mOBAPPRequest.input));

            //if (Path== "apps.teamhgs.com")
            //{
            //    WriteLogFile.WriteLog("Information", "Different server api called");
            //    try
            //    {
            //        updateRequestDTO.ApprovalLevel = 1;
            //        string result = _serviceconnect.PostConnect("Approval/UpdateApprovalStatus", updateRequestDTO);
            //        response = JsonConvert.DeserializeObject<responsePRList>(result);
            //        WriteLogFile.WriteLog("Information", response.responseCode.ToString() + "-" + response.responseMessage);

            //    }
            //    catch (Exception ex)
            //    {
            //        WriteLogFile.WriteLog("Exception", ex.Message);
            //        response.responseCode = 0;
            //        response.responseMessage = "There is some issue. " + ex;
            //    }

            //}
            //else
            //{
            //    response = _IMOBAPPBL.ApprovalstatusUpdate(updateRequestDTO);
            //}
            response = _IMOBAPPBL.ApprovalstatusUpdate(updateRequestDTO);
            responseclass.output= (EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(response)));
            return responseclass;
        }

        [HttpPost]
        public string EncryptString(string encrypt)
        {

            return EncryptDecryptAES.EncryptStringAES(encrypt);
        }

        [HttpPost]
        public ResponseClass SendFCMNotification(fcmnotificationresponseDTO fcmnotificationresponseDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _IMOBAPPBL.SendFCMNotification(fcmnotificationresponseDTO);
            return response;
        }

        [HttpPost]
        public responsePRList GetPODetail(getPODetailRequestDTO request)
        {
            responsePRList response = new responsePRList();
            response = _IMOBAPPBL.getPODetail(request);
            return response;
        }
    }
}
