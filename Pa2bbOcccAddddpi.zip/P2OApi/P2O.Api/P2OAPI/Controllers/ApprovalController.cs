﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using P2OAPI.ServiceConnect;
using P2OBAL.Approval;
using P2OBAL.Common;
using P2OBAL.EmailMgt;
using P2OBAL.MobApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace P2OAPI.Controllers
{
    [ApiController]
    public class ApprovalController : Controller
    {
        private IApprovalBL _approvalBl;
        private IEmailManagementBL _emailManagementBL;
        
        private readonly ILogger<ApprovalController> _logger;

        public ApprovalController(IApprovalBL approvalBl, ILogger<ApprovalController> logger,
            IEmailManagementBL emailManagementBL)
        {
            _approvalBl = approvalBl;
            _logger = logger;
            _emailManagementBL = emailManagementBL;
          
        }

        [Route("api/Approval/GetApprovalLevels")]
        [HttpPost]
        public ResponseClass GetApprovalLevels(ApprovalRequestDTO approvalRequestBO)
        {
            ResponseClass response = new ResponseClass();
            response = _approvalBl.GetApprovalLevels(approvalRequestBO);
            return response;
        }

        [Route("api/Approval/GetWaitingForApprovalList")]
        [HttpPost]
        public ResponseClass GetWaitingForApprovalList(ApprovalRequestDTO approvalRequestBO)
        {
            ResponseClass response = new ResponseClass();
            response = _approvalBl.GetWaitingForApprovalList(approvalRequestBO);
            return response;
        }

        [Route("api/Approval/UpdateApprovalStatus")]
        [HttpPost]
        public ResponseClass UpdateApprovalStatus(ApprovalSatatusUpdateRequestDTO updateRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            //string myoutput=(EncryptDecryptAES.EncryptStringAES(JsonConvert.SerializeObject(updateRequestDTO)));
            string Path = HttpContext.Request.Host.ToString();
            //if (Path.Contains("https://apps.teamhgs.com"))
            //{
            //    WriteLogFile.WriteLog("Information", "Different server api called");
            //    try
            //    {
            //        string result = _serviceconnect.PostConnect("Approval/UpdateApprovalStatus", updateRequestDTO);
            //        response = JsonConvert.DeserializeObject<ResponseClass>(result);
            //        WriteLogFile.WriteLog("Information", "Different server api called Success");

            //    }
            //    catch (Exception ex)
            //    {
            //        WriteLogFile.WriteLog("Exception",ex.Message);
            //        response.responseCode = 0;
            //        response.responseMessage = "There is some issue. " + ex;
            //    }

            //}
            //else
            //{
            //    response = _approvalBl.ApprovalstatusUpdate(updateRequestDTO);
            //}
            response = _approvalBl.ApprovalstatusUpdate(updateRequestDTO);
            return response;
        }

        [Route("api/Approval/GetPREntity")]
        [HttpPost]
        public ResponseClass GetPREntity(GetPREntityRequest getPREntityRequest)
        {
            ResponseClass response = new ResponseClass();
            response = _approvalBl.GetPREntity(getPREntityRequest);
            return response;
        }

        [Route("api/Approval/GetPRRequistionDataByRequistionNo")]
        [HttpPost]
        public ResponseClass GetPRRequistionDataByRequistionNo(PRRequistionDataRequestDTO pRRequistionDataRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _approvalBl.GetPRRequistionDataByRequistionNo(pRRequistionDataRequestDTO);
            return response;
        }

        [Route("api/Approval/GetEmailContent")]
        [HttpPost]
        public ResponseClass GetEmailContent(EmailManagementDTO emailManagementDTO)
        {
            ResponseClass response = new ResponseClass();
           
            response = _emailManagementBL.GetEmailContent(emailManagementDTO);
            return response;
        }

        [Route("api/Approval/UpdatePRDetail")]
        [HttpPost]
        public ResponseClass UpdatePRDetail(UpdatePRDetailRequest updatePRDetailRequest)
        {
            ResponseClass response = new ResponseClass();
            response = _approvalBl.UpdatePRDetail(updatePRDetailRequest);
            return response;
        }

        [Route("api/Approval/UpdatePRHeaderDetail")]
        [HttpPost]
        public ResponseClass UpdatePRHeaderRequest(UpdatePRRequest request)
        {
            ResponseClass response = new ResponseClass();
            response = _approvalBl.UpdatePRHeaderRequest(request);
            return response;
        }

        [Route("api/Approval/SendFCMMessage")]
        [HttpPost]
        public string SendFCMMessage(fcmnotificationresponseDTO fcmnotificationresponseDTO)
        {
            string response = string.Empty;
            response = _emailManagementBL.SendNotification(fcmnotificationresponseDTO);
            return response;
        }

        [Route("api/Approval/POGenerateNotification")]
        [HttpGet]
        public ResponseClass POGenerateNotification(string P2OPRNumber)
        {
            ResponseClass response = new ResponseClass();
            POGenerateNotificationRequest poGenerateNotification = new POGenerateNotificationRequest();
            poGenerateNotification.P2OPRNumber = P2OPRNumber;
            response = _emailManagementBL.POGenerateNotification(poGenerateNotification);
            return response;
        }

        [Route("api/Approval/GetPRVirtualFlow")]
        [HttpPost]
        public ResponseClass GetPRVirtualFlow(PRVirtualFlowRequestDTO prVirtualFlow)
        {
            ResponseClass response = new ResponseClass();
            response = _approvalBl.GetPRVirtualFlow(prVirtualFlow);
            return response;
        }

        [Route("api/InActiveEmployeeList")]
        [HttpGet]
        public ResponseClass InActiveEmployeeList()
        {
            ResponseClass response = new ResponseClass();
            POGenerateNotificationRequest poGenerateNotification = new POGenerateNotificationRequest();
            //poGenerateNotification.P2OPRNumber = P2OPRNumber;
            response = _emailManagementBL.InActiveEmployeeList(poGenerateNotification);
            return response;
        }

        [Route("api/Approval/AddPRFiles")]
        [HttpPost]
        public ResponseClass AddPRFiles(PRFilesDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _approvalBl.AddPRFiles(request);
            return response;
        }

        [HttpPost]
        [Route("api/Approval/TestEmail")]
        public ResponseClass TestEmail(EmailClass emailTo)
        {
            ResponseClass response = new ResponseClass();
            response = _emailManagementBL.SendEmailResponse("", emailTo.EmailTo, "UK test email","");
            return response;
        }
    }
}
