﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using P2OBAL.Auditor;
using P2OBAL.Common;
using P2OBAL.Reports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OAPI.Controllers
{
    [EnableCors("AllowAllHeaders")]
    [Route("api/[action]")]
    [ApiController]
    public class ReportsController : Controller
    {
        private IReportsBL _ReportsBL;

        private IAuditBL _AuditBL;

        private readonly ILogger<ReportsController> _logger;

        public ReportsController(IReportsBL reportsBL, ILogger<ReportsController> logger, IAuditBL auditBL)
        {
            _ReportsBL = reportsBL;
            _logger = logger;
            _AuditBL = auditBL;
        }

        [HttpPost]
        public ResponseClass GetPRReport(PRReportRequestDTO pRReportRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _ReportsBL.GetPRReport(pRReportRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass InsertAdminActivityLog(AdminActivityLogInsertDTO adminActivityLogInsertDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _AuditBL.InsertAdminActivityLog(adminActivityLogInsertDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetHistoricalReport(HistoricalReportDTO historicalReportDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _ReportsBL.GetHistoricalReport(historicalReportDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetUserDashboard(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _ReportsBL.GetUserDashboard(userDashboardRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetRDAccress(UserDashboardRequestDTO userDashboardRequestDTO)
        {
            ResponseClass response = new ResponseClass();
            response = _ReportsBL.GetRDAccress(userDashboardRequestDTO);
            return response;
        }

        [HttpPost]
        public ResponseClass GetWorkFlowReport(WorkflowReportrequestDTO request)
        {
            ResponseClass response = new ResponseClass();
            response = _ReportsBL.GetWorkFlowReport(request);
            return response;
        }
    }
}
