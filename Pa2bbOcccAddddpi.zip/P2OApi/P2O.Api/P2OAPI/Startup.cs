using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using Microsoft.OpenApi.Models;
using P2OAPI.Extension;
using P2OAPI.Logging;
using P2OAPI.ServiceConnect;
using P2OBAL.Approval;
using P2OBAL.ApprovalMapping;
using P2OBAL.AppStats;
using P2OBAL.Auditor;
using P2OBAL.CatalogueManagement;
using P2OBAL.Common;
using P2OBAL.Configuration;
using P2OBAL.CurrencyConversionManagement;
using P2OBAL.EmailMgt;
using P2OBAL.Error;
using P2OBAL.Masters;
using P2OBAL.MobApp;
using P2OBAL.PurchaseRequistion;
using P2OBAL.Reports;
using P2OBAL.UserManagement;
using P2OBAL.WebSite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace P2OAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddScoped<IUserManagementBL, UserManagementBL>();
            services.AddScoped<IWebSiteManagementBL, WebSiteManagementBL>();
            services.AddScoped<IMasterDataBL, MasterDataBL>();
            services.AddScoped<IPurchaseRequistionBL, PurchaseRequistionBL>();
            services.AddScoped<IApprovalBL, ApprovalBL>();
            services.AddScoped<IErrorBL, ErrorBL>();
            services.AddScoped<IApplicationConfigBL, ApplicationConfigBL>();
            services.AddScoped<IApprovalMappingBL, ApprovalMappingBL>();
            services.AddScoped<IEmailManagementBL, EmailManagementBL>();
            services.AddScoped<IReportsBL, ReportsBL>();
            services.AddSingleton<ILog,LogNLog>();
            services.AddScoped<IMOBAPPBL, MOBAPPBL>();
            services.AddScoped<IAuditBL, AuditBL>();
            services.AddScoped<ICatalogueManagementBL, CatalogueManagementBL>();
            services.AddScoped<IMyServiceConnect, MyServiceConnect>();
            services.AddScoped<IFireBaseAPICallBL, FireBaseAPICallBL>();
            services.AddScoped<IAppStatsBL, AppStatsBL>();
            services.AddScoped<ICurrencyConversionBL, CurrencyConversionBL>();
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "AppStatsRepository_veer", Version = "v1" });
                c.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
                {
                    Name = "Authorization",
                    Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = Microsoft.OpenApi.Models.ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme."
                });
                
            });

            services.Configure<P2ODAL.DBConnection>(Configuration);

            services.Configure<IDBConnection>(Configuration.GetSection("ConnectionStrings"));
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAllHeaders",
                builder =>
                {
                    builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();

                }


                 );


            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILog logger)
        {
            if (env.IsDevelopment() || env.IsProduction())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "AppStatsRepository v1"));
            }
            app.ConfigureExceptionHandler(logger);
            
            app.UseRouting();
            app.UseCors("AllowAllHeaders"); // allow credentials

            app.UseAuthorization();
            app.UseStaticFiles(new StaticFileOptions
            {
                OnPrepareResponse = ctx =>
                {

                    ctx.Context.Response.Headers[HeaderNames.CacheControl] =
                        "no-cache, no-store,private,Pragma:no-cache,max-age=0";
                    
                }
               
            });
            app.UseMiddleware(typeof(CustomResponseHeaderMiddleware));
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
