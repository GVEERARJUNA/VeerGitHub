﻿﻿Poject/Solution: single entry ledger system solution
===========


### Key features ###

* the project has the SingleEntryLedgerDTO as entity and as Schema for the storage.
* SingleEntryLedger is as the implementation of SingleEntryLedgerDTO as creating object and making 
  validation for its attributes and it will be as value object too.
  
* Secification class for validation of value object SingleEntryLedger 


### The advantages of working with SingleEntryLedger ###
* it will be like as Simple Domain-Driven Design architectural style and distingush between Entity and value object.
clear picture of entity->mutable  and value object-> immutable

