﻿using System;
using System.Diagnostics;

namespace SingleLedger.Domain
{
    [DebuggerDisplay("{Transaction}")]
    public class SingleEntryLedger
    {
        public Guid Id { get; }
        public string Note { get; }
        public string Desc { get; }
        public Transaction Transaction { get; }

        public decimal Balance { get; }

        public SingleEntryLedger(Guid id, string note, string desc, Transaction transaction,decimal balance)
        {
            if (id == Guid.Empty) throw new Exception("Id is invalid");
            if (Desc == null) throw new Exception("Desc is required");
            if (transaction == null) throw new Exception("Transaction should be successful");

            Id = id;
            Note = note;
            Desc = desc;
            Transaction = transaction;
            Balance = balance;
        }
    }

    [DebuggerDisplay("{Debit,nq} {Credit,nq}")]
    public class Transaction
    {
        public decimal Debit { get; }

        public decimal Credit { get; }

        public Transaction(decimal debit, decimal credit)
        {
            if (Debit <= decimal.MinValue) throw new Exception("Debit should have min value");
            if (Credit <= decimal.MinValue) throw new Exception("Credit should have min value");

            Debit = debit;
            Credit = credit;
        }
    }
    
}