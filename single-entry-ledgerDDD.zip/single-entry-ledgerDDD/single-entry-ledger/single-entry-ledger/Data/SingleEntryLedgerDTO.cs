﻿using System;

namespace SingleEntryLedgerDTO.Data
{
    public class SingleEntryLedgerDTO
    {
        public Guid Id { get; set; }
        public string Desc { get; set; }

        public string Note { get; set; }

        public TransactionDto Transaction { get; set; }
        public decimal Balance { get; set; }

    }

    public class TransactionDto
    {
        public decimal Debit { get; set; }

        public decimal Credit { get; set; }
    }

    
}
