﻿using System;
using SingleLedger.Domain;
using Machine.Specifications;

namespace SingleLedgerSpecs.Specs
{
    [Subject(typeof(SingleEntryLedger))]
    public class SingleEntryLedgerSpecs
    {
        public class Ctor
        {
            It should_create_an_instance_with_valid_state_via_ctor_parameters = () =>
            {
                var subject = new SingleEntryLedger(Guid.NewGuid(),"transaction info","", new Transaction(1000, 500),5000);

                subject.ShouldNotBeNull();
            };


            //if this is failed raise error log to "Id is invalid"
            It should_validate__Id__ = () => Catch.Exception(() => new SingleEntryLedger(Guid.Empty, "transaction info", "", new Transaction(1000, 500), 5000));

            //if this is failed raise error log to "transaction should be valid and success"
            It should_validate__Transaction__ = () => Catch.Exception(() => new SingleEntryLedger(Guid.NewGuid(), "transaction info", "", new Transaction(0, 0), 3500));

        }
    }
}