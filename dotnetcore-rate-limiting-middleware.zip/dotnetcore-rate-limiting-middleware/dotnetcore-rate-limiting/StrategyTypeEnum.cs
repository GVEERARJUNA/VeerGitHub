﻿namespace dotnetcore_rate_limiting_IP
{
    public enum TypeOfStrategy
    {
        IpAddress,
        PerUser,
        PerApiKey
    }
}