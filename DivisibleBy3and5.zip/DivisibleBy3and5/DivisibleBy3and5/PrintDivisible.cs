﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DivisibleBy3and5
{
    public class PrintDivisible
    {
        public static void Main(string[] args)
        {
            int num1 = 0;

            // Display title as the C# console calculator app.
            Console.WriteLine("Please enter valid Integer value");

            num1 = Convert.ToInt32(Console.ReadLine());

            PrintDivisibleBy3and5Result(num1);
        }
        public static void PrintDivisibleBy3and5Result(Int32 num1,Boolean isUnitTest=false)
        {
            string res = num1 > 0 && (num1 % 3 == 0 && num1 % 5 == 0) ? "FizzBuzz" : num1 % 5 == 0 ? "Buzz" : num1 % 3 == 0 ? "Fizz" : num1.ToString();
            Console.WriteLine("Result: " + res);
            //Console.WriteLine("");
            Console.Write("Press any key to close the console app...");
            if(!isUnitTest) Console.ReadLine();

            
            //return;
        }
    }
}
