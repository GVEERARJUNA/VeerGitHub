﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            DivisibleBy3and5.PrintDivisible.PrintDivisibleBy3and5Result(9,true);
        }

        [TestMethod]
        public void TestMethod2()
        {
            DivisibleBy3and5.PrintDivisible.PrintDivisibleBy3and5Result(15, true);
        }

        [TestMethod]
        public void TestMethod3()
        {
            DivisibleBy3and5.PrintDivisible.PrintDivisibleBy3and5Result(11, true);
        }
    }
}
